# -*- coding: utf-8 -*-
"""Watched state read from Kodi, which is where it lives now.

This add-on used to keep its own `watched_state` table. It was one of three
stores of the same fact - Kodi's own playcounts, this table, and a hub add-on -
and they disagreed: a season marked here never reached the recommendations, and
a title cleared elsewhere kept its tick here.

The owner's decision settled it: Kodi holds the history, everyone else reads it.
So this module answers one question - "what does Kodi know about these paths" -
in a single read, and the list builder stamps the answer onto its rows. Writing
is not done here at all: the context menu asks the skin's hub, which writes
through Kodi's public API, so there is exactly one writer.
"""
import glob
import os
import re
import sqlite3
import time

import xbmc
import xbmcvfs

_CACHE = {'stamp': 0.0, 'rows': None}
CACHE_TTL = 20.0


def _log(message, level=xbmc.LOGDEBUG):
    try:
        xbmc.log('[plugin.video.filmix][kodi state] {0}'.format(message), level)
    except Exception:
        pass


_MYVIDEOS_RE = re.compile(r'^MyVideos(\d+)\.db$')


def newest_myvideos_db():
    """База видео, с которой работает Kodi: MyVideos<N>.db с наибольшим N. '' - базы нет.

    21.11.2026: одно правило на всё дополнение. Было пять разных: по алфавиту
    (MyVideos99 «новее» MyVideos131) и по времени файла (старая база, которую
    тронули, «новее» рабочей).
    """
    try:
        folder = xbmcvfs.translatePath('special://database/')
    except Exception:
        return ''
    best, best_version = '', -1
    try:
        for path in glob.glob(os.path.join(folder, 'MyVideos*.db')):
            found = _MYVIDEOS_RE.match(os.path.basename(path))
            if found and int(found.group(1)) > best_version:
                best, best_version = path, int(found.group(1))
    except Exception:
        return ''
    return best


def _full_path(strpath, filename):
    """Kodi splits a file into a directory and a name, and for a plugin item it
    stores the whole URL in the NAME - so gluing the two together doubles it:
    "plugin://plugin.video.filmix/plugin://plugin.video.filmix/movies/...".
    Seen in the live database, and it matters: a doubled URL is not playable and
    is not the key Kodi itself uses.
    """
    name = str(filename or '')
    if name.startswith('plugin://'):
        return name
    return '%s%s' % (str(strpath or ''), name)


def _load():
    """{path: (playcount, position, total)} for every plugin path Kodi knows.

    One read for the whole listing, cached for a few seconds: a per-row query
    would put hundreds of statements in the way of drawing a screen.
    """
    now = time.time()
    if _CACHE['rows'] is not None and now - _CACHE['stamp'] < CACHE_TTL:
        return _CACHE['rows']
    path = newest_myvideos_db()
    rows = {}
    if not path or not os.path.isfile(path):
        _CACHE.update({'rows': rows, 'stamp': now})
        return rows
    conn = None
    try:
        conn = sqlite3.connect('file:%s?mode=ro' % path, uri=True, timeout=5)
        for strpath, filename, playcount, position, total in conn.execute(
                'SELECT p.strPath, f.strFilename, f.playCount,'
                '       b.timeInSeconds, b.totalTimeInSeconds'
                ' FROM files f JOIN path p ON p.idPath = f.idPath'
                ' LEFT JOIN bookmark b ON b.idFile = f.idFile'):
            full = _full_path(strpath, filename)
            if not full.startswith('plugin://'):
                continue
            rows[full] = (int(playcount or 0), float(position or 0),
                          float(total or 0))
    except Exception as exc:
        _log('база Kodi не прочитана: {0}'.format(exc), xbmc.LOGWARNING)
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
    _CACHE.update({'rows': rows, 'stamp': now})
    return rows


def invalidate():
    _CACHE.update({'rows': None, 'stamp': 0.0})


def state_for(path):
    """(playcount, position, total) for one path; zeros when Kodi has nothing."""
    if not path:
        return (0, 0.0, 0.0)
    return _load().get(path) or (0, 0.0, 0.0)


def is_watched(path):
    return state_for(path)[0] > 0




