"""Channel logos in one style: it999/epg.one "transparent 220x132".

Order for a channel without a logo of that style on disk:
  1. resources/logos/<id>.png shipped with the add-on (Србија, a few loops;
     made by tools/make_logo.py in the pack's style),
  2. the pack itself (zip, refreshed weekly): exact id of the channel or an
     alias, else the same name without quality words ("BCU Action HDR" takes
     "BCU Action HD"),
  3. the logo guide's channel list (config logo_guide, iptvx.one by default; several names
     each, icons in the same transparent style) by the same name rules,
  4. the playlist's or the guide's own picture - only when nothing else exists.
Files migrated from TVLINK are the pack already and stay. Every file written
here is recorded in cache/logo_sources.json with a version, which goes into the
logo URL so Kodi drops the picture it cached before.
"""
import os
import re
import time
import urllib.request
import zlib
import zipfile

from . import ids, normalize
from .store import age_hours, read_json, write_atomic, write_json

RESOURCES = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BUNDLED = os.path.join(RESOURCES, "logos")
_QUALITY = re.compile(r"\b(HDR|FHD|UHD|HD|4K|orig|OLD)\b", re.I)


def _base(name):
    return " ".join(_QUALITY.sub(" ", name).split()).casefold()


_TRANSLIT = {"а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z",
             "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
             "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
             "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya"}
_NOISE = re.compile(r"\([^)]*\)|\[[^\]]*\]|\b(hd|fhd|uhd|4k|hdr|sd|orig|old|tv|тв|channel|канал|"
                    r"live|russia|россия|ru)\b", re.I)


def _loose(name):
    """Name for a fuzzy match: no brackets, quality, "TV"/"канал", punctuation; Latin letters
    ("Belgorod 24" and "Белгород 24" give the same key)."""
    low = _NOISE.sub(" ", (name or "").casefold())
    low = "".join(_TRANSLIT.get(ch, ch) for ch in low)
    low = low.replace("kh", "h").replace("ts", "c").replace("iy", "y").replace("yy", "y")
    return re.sub(r"[^a-z0-9]", "", low)


class Pack:
    def __init__(self, path):
        self.zip = zipfile.ZipFile(path)
        self.by_id, self.by_base, self.by_loose, self.by_norm = {}, {}, {}, {}
        for n in self.zip.namelist():
            if not n.lower().endswith(".png"):
                continue
            title = n.rsplit("/", 1)[-1][:-4]
            self.by_id.setdefault(ids.chid(title, ["orig"]), n)
            self.by_base.setdefault(_base(title), n)
            key = _loose(title)
            if len(key) >= 3:
                self.by_loose.setdefault(key, n)
            key = normalize.key(title)
            if len(key) >= 2:
                self.by_norm.setdefault(key, n)

    def find(self, channel):
        for k in channel.get("match_ids") or [channel["id"]] + channel.get("aliases", []):
            if k in self.by_id:
                return self.by_id[k]
        hit = self.by_base.get(_base(channel["title"]))
        if hit:
            return hit
        # похожее название: «Первый канал (+4)», «Belgorod 24 (1080p)», «ТНТ4 (-3)»
        key = _loose(channel["title"])
        hit = self.by_loose.get(key) if len(key) >= 3 else None
        if hit:
            return hit
        # стандарт названий (только каналы встроенных плейлистов): «Euronews» - «Euronews
        # Russia», «Белгород 24 HD» - «Belgorod 24»
        if not channel.get("norm"):
            return None
        key = normalize.key(channel["title"])
        return self.by_norm.get(key) if len(key) >= 2 else None

    def read(self, member):
        return self.zip.read(member)


# сдвиг времени в конце названия: «(+4)», « -3» - но не дефис в названии («Россия-1», «Матч-2»)
_SHIFT = re.compile(r"\s*(?:\(\s*|\s)[+-]\s*(\d{1,2})\s*\)?\s*$")
GUIDE_HEAD = 30 * 1024 * 1024      # characters of the guide read at most (its <channel> list)


class Guide:
    """name -> icon URL from the guide's <channel> list (the head of the file, before <programme>)."""
    def __init__(self, index):
        self.by_base, self.by_loose = index.get("base") or {}, index.get("loose") or {}
        self.by_norm = index.get("norm") or {}

    def find(self, channel):
        # a time-shifted copy ("Россия 1 (+4)") takes the original's logo
        title = _SHIFT.sub("", channel["title"]) or channel["title"]
        hit = self.by_base.get(_base(title))
        if hit:
            return hit
        key = _loose(title)
        hit = self.by_loose.get(key) if len(key) >= 3 else None
        if hit or not channel.get("norm"):
            return hit
        key = normalize.key(title)
        return self.by_norm.get(key) if len(key) >= 2 else None


def guide_index(text):
    """{"base", "loose", "norm": {name key: icon URL}} of an XMLTV head (its <channel> list)."""
    base, loose, norm = {}, {}, {}
    for ch in re.findall(r"<channel[ >].*?</channel>", text.split("<programme", 1)[0], re.S):
        icon = re.search(r'<icon\s+src="([^"]+)"', ch)
        if not icon:
            continue
        for name in re.findall(r"<display-name[^>]*>([^<]+)<", ch):
            name = name.replace("&amp;", "&").strip()
            base.setdefault(_base(name), icon.group(1))
            key = _loose(name)
            if len(key) >= 3:
                loose.setdefault(key, icon.group(1))
            shifted = _SHIFT.search(name)
            if not (shifted and int(shifted.group(1))):           # not a time-shifted copy
                key = normalize.key(name)
                if len(key) >= 2:
                    norm.setdefault(key, icon.group(1))
    return {"base": base, "loose": loose, "norm": norm}


def _guide(cfg, paths, log):
    url = cfg.get("logo_guide") or ""
    if not url:
        return None
    # свой файл индекса на каждый адрес: другой адрес гида - индекс строится сразу
    tag = "%08x" % (zlib.crc32(url.encode("utf-8")) & 0xFFFFFFFF)
    path = os.path.join(paths.cache, "logo_guide_%s.json" % tag)
    tried = os.path.join(paths.cache, "logo_guide_%s.try" % tag)
    try:
        names = os.listdir(paths.cache)
    except OSError:
        names = []
    for old in names:
        if old.startswith("logo_guide") and tag not in old:
            try:
                os.unlink(os.path.join(paths.cache, old))
            except OSError:
                pass
    # неудачная загрузка (сеть, пустой индекс) повторяется не чаще раза в сутки, а не при
    # каждой перестройке каталога
    if age_hours(path) > 24 * 7 and age_hours(tried) > 24:
        try:
            with open(tried, "w"):
                pass
        except OSError:
            pass
        try:
            import codecs
            req = urllib.request.Request(url, headers={"User-Agent": cfg["user_agent"]})
            parts, size, tail = [], 0, ""
            with urllib.request.urlopen(req, timeout=120) as r:
                dec = zlib.decompressobj(16 + zlib.MAX_WBITS)
                utf = codecs.getincrementaldecoder("utf-8")("replace")
                while size < GUIDE_HEAD:
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    piece = utf.decode(dec.decompress(chunk, GUIDE_HEAD - size + 1))
                    parts.append(piece)
                    size += len(piece)
                    # маркер ищется только в новом куске (с перекрытием), не во всём тексте
                    if "<programme" in tail + piece:
                        break
                    tail = (tail + piece)[-16:]
            text = "".join(parts)
            index = guide_index(text)
            if index["base"]:
                write_json(path, index)
                log("logo guide: %d names" % len(index["base"]))
        except (OSError, ValueError, zlib.error) as e:
            log("logo guide: kept previous (%s)" % e)
    index = read_json(path, None)
    if index and "norm" not in index:
        # index of an older version: the normalized-name keys are added once from the names
        # we no longer have - rebuild on the next download instead (age forced)
        try:
            os.utime(path, (0, 0))
        except OSError:
            pass
    return Guide(index) if index else None


def _pack(cfg, paths, log):
    url = cfg.get("logo_pack") or ""
    if not url:
        return None
    path = os.path.join(paths.cache, "logopack.zip")
    if age_hours(path) > 24 * 7:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": cfg["user_agent"]})
            with urllib.request.urlopen(req, timeout=120) as r:
                data = r.read(200 * 1024 * 1024)
            zipfile.ZipFile(__import__("io").BytesIO(data)).testzip()
            write_atomic(path, data, binary=True)
            log("logo pack: %d KB" % (len(data) // 1024))
        except (OSError, ValueError, zipfile.BadZipFile) as e:
            log("logo pack: kept previous (%s)" % e)
    # 21.11.2026: набор открывается и индексируется один раз на процесс, заново - только
    # когда файл сменился (еженедельная загрузка выше)
    try:
        st = os.stat(path)
    except OSError:
        return None
    key = (st.st_mtime, st.st_size)
    if _PACK.get("key") != key:
        old = _PACK.pop("pack", None)
        _PACK.pop("key", None)
        if old is not None:
            old.zip.close()
        try:
            _PACK["pack"], _PACK["key"] = Pack(path), key
        except (OSError, zipfile.BadZipFile):
            return None
    return _PACK["pack"]


_PACK = {}                 # {"key": (mtime, size) logopack.zip, "pack": Pack}
NONE_RETRY = 7 * 24 * 3600  # канал без логотипа: картинки из сети - не чаще раза в неделю


def refresh(state, channels):
    """Make every channel's logo the pack's style where possible. Returns files written."""
    paths, cfg, log = state.paths, state.cfg, state.log
    src_path = os.path.join(paths.cache, "logo_sources.json")
    sources = read_json(src_path, {}) or {}
    pack = guide = None
    wrote = 0
    dirty = False           # записи «логотипа нет» сохраняются, но каталог не перестраивают
    now = int(time.time())
    # один стиль логотипов - на коробках, поставленных установщиком (флажок standard_groups);
    # на коробках автора старые файлы TVLINK остаются как были
    strict = not cfg.get("logo_mixed") and os.path.exists(os.path.join(paths.root, "standard_groups"))
    for c in channels:
        if state.stop.is_set():
            break
        dest = os.path.join(paths.logos, c["id"] + ".png")
        have = os.path.exists(dest)
        rec = sources.get(c["id"])
        if have and rec and rec.get("src") == "url" and strict and not _transparent_file(dest):
            os.remove(dest)                    # логотип из плейлиста - другой стиль: убрать
            sources.pop(c["id"], None)
            have, rec = False, None
            wrote += 1
        if have and rec is not None and rec.get("src") in ("bundled", "pack", "guide"):
            continue            # already in style
        if have and rec is None and not strict:
            continue            # TVLINK's own file (owner's boxes keep the old behaviour)
        data, how = None, None
        # 21.11.2026: канал, для которого в сети не нашлось картинки, неделю не скачивает
        # заново иконку гида и картинку плейлиста (раньше - сотни запросов при каждом
        # старте Kodi и каждой перестройке); свои файлы и набор проверяются как прежде
        net = not (rec and rec.get("src") == "none" and now - rec.get("checked", 0) < NONE_RETRY)
        tried = False
        b = os.path.join(BUNDLED, c["id"] + ".png")
        if os.path.exists(b):
            with open(b, "rb") as f:
                data, how = f.read(), "bundled"
        else:
            if pack is None:
                pack = _pack(cfg, paths, log) or False
            m = pack.find(c) if pack else None
            if m:
                data, how = pack.read(m), "pack"
            else:
                if guide is None:
                    guide = _guide(cfg, paths, log) or False
                icon = guide.find(c) if guide else None
                tried = bool(icon and net)
                got = _download(icon, cfg) if tried else None
                if got and _transparent_png(got):
                    data, how = got, "guide"
        # картинка из плейлиста - другой стиль; по умолчанию не берём: без логотипа набора
        # скин рисует свою заглушку, и все иконки остаются одного вида
        if data is None and not have and c.get("logo") and net:
            tried = True
            got = _download(c["logo"], cfg)
            # in one style only a transparent PNG (pictures on a background look mixed)
            if got and (not strict or _transparent_png(got)):
                data, how = got, "url"
        if data is None and have and rec is None and strict:
            os.remove(dest)                    # чужого стиля и не из набора - заглушка скина
            wrote += 1
            continue
        if data:
            write_atomic(dest, data, binary=True)
            sources[c["id"]] = {"src": how, "v": int(time.time())}
            wrote += 1
        elif not have and tried:
            sources[c["id"]] = {"src": "none", "checked": now}
            dirty = True
    if wrote or dirty:
        write_json(src_path, sources)
    if wrote:
        log("logos written: %d" % wrote)
    return wrote


def _transparent_png(data):
    """PNG with transparency: colour type with alpha (4, 6) or a tRNS chunk."""
    if data[:8] != b"\x89PNG\r\n\x1a\n" or len(data) < 26:
        return False
    return data[25] in (4, 6) or b"tRNS" in data[:4096]


def _transparent_file(path):
    try:
        with open(path, "rb") as fh:
            return _transparent_png(fh.read(4096))
    except OSError:
        return False


def _download(url, cfg):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": cfg["user_agent"]})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = r.read(2 * 1024 * 1024)
        if data[:4] == b"\x89PNG" or data[:3] == b"\xff\xd8\xff":
            return data
    except (OSError, ValueError):
        pass
    return None
