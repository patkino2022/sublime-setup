Sublime Online Helper
=====================
Embedded metadata helper for skin.sublime, designed as a small action-oriented service.
It talks directly to TMDb and can enrich metadata with Fanart.tv, OMDb, MDBList and Trakt.
All credentials and provider switches are stored in skin.sublime settings. No external
external metadata helper add-on, foreign window properties or foreign plugin routes are used.

Implemented skin routes include details, cast, crew, artwork/images, videos, seasons,
episodes, collections, recommendations, person credits, search/discovery, ratings,
Trakt comments/recommendations/sync, local My List tagging and trailer playback.
