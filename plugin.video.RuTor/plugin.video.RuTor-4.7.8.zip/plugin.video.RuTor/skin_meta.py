# -*- coding: utf-8 -*-
"""Метки строки РуТора для нашего скина - по тем же правилам, что у филмикса.

Владелец 11.09.2026: «переделай в нем всё так, чтобы он работал в нашем скине
как филмикс (метаданные, арт, обогащение, рейтинги, качество и тд и тп)».

Что читает скин у строки (skin.sublime, sublime_helper/core.py,
local_model_from_current) - тот самый список, под который здесь всё и ставится:

  название      Title, затем Label;
  оригинал      OriginalTitle, Property(original_title);
  год           Property(SourceYear) (предпочитается), затем Year;
  страна        Property(SourceCountry), затем Country;
  описание      Plot; жанры Genre; студия Studio;
  опознание     UniqueID(tmdb|imdb|kinopoisk) и Property(tmdb_id|imdb_id|
                kinopoisk_id) - по ним обогащение не ищет заново, а берёт
                нужную запись сразу;
  качество      Property(sublime_release_quality) и
                Property(sublime_release_resolution) - из них скин собирает
                чип в инфостроке;
  вид           Property(sublime_kind): movies или shows;
  арт           Art(poster|fanart|thumb).

Почему название и видимая метка - разные вещи. В списке релизов владелец
должен видеть, чем релизы отличаются («1080p | 7.43GB | 85 сидов»), а скину для
опознания нужно ЧИСТОЕ название фильма. Kodi это различает: видимая метка -
label строки, а Title ставится в infoLabels, и скин читает именно Title.
Поэтому метку оставляем говорящей, а Title делаем чистым.
"""
from __future__ import absolute_import, unicode_literals

import re

try:
    import image_host
except Exception:  # на боксе модуль лежит рядом, вне бокса его нет
    image_host = None

_TAGS = re.compile(r'\[/?(?:B|I|COLOR[^\]]*|UPPERCASE|LOWERCASE|CAPITALIZE|CR)\]',
                   re.IGNORECASE)
_SPACES = re.compile(r'\s+')
# То же число, что в скине (hub/identity.py): высота кадра из названия релиза.
_RESOLUTION = re.compile(r'(?<!\d)(2160|1440|1080|720|576|480|360)(?!\d)')
# Вид релиза: слова, которыми РуТор называет источник. Список закрытый, потому
# что в названии раздачи рядом стоят и звук, и кодек, и группа - «WEB-DLRip
# 1080p | D | AlexFilm», - и всё, кроме вида, в чип попадать не должно.
_KINDS = (
    'WEB-DLRip', 'WEB-DL', 'WEBRip', 'HDTVRip', 'BDRemux', 'BDRip', 'Blu-Ray',
    'BluRay', 'HDRip', 'DVDRip', 'DVDScr', 'DVD5', 'DVD9', 'SATRip', 'TVRip',
    'CAMRip', 'HDCAM', 'HDTV', 'WEB', 'DVB', 'CAM', 'UHD', 'Remux', 'TS', 'TC',
)


def strip_tags(text):
    """Метка без разметки Kodi: [COLOR], [B] и прочее."""
    return _SPACES.sub(' ', _TAGS.sub(' ', str(text or ''))).strip()


def release_parts(text):
    """Качество и вид релиза из названия раздачи: («WEB-DLRip», «1080»).

    Разбор тот же по смыслу, что у скина (hub/identity.release_parts), но вход
    другой: у филмикса это отдельное поле «WEB-DLRip 1080», а у РуТора - всё
    название раздачи целиком, где рядом стоит и звук, и озвучка, и группа.
    Поэтому вид ищется по закрытому списку слов, а высота - по числу.
    """
    raw = strip_tags(text)
    if not raw:
        return '', ''
    resolution = ''
    hit = _RESOLUTION.search(raw)
    if hit:
        resolution = hit.group(1)
    kind = ''
    lowered = raw.lower()
    for name in _KINDS:
        where = lowered.find(name.lower())
        if where < 0:
            continue
        # «TS» и «TC» - две буквы, их легко встретить внутри слова: «RUS TS»
        # годится, «Artsland» нет.
        before = raw[where - 1] if where > 0 else ' '
        after_at = where + len(name)
        after = raw[after_at] if after_at < len(raw) else ' '
        if before.isalpha() or after.isalpha():
            continue
        if len(name) > len(kind):
            kind = name
    return kind, resolution


def film_title(info, source=None):
    """Чистое название фильма - то, по которому скин опознаёт строку."""
    source = source or {}
    info = info or {}
    for value in (info.get('title'), source.get('title'),
                  info.get('originaltitle'), source.get('originaltitle')):
        text = strip_tags(value)
        if not text:
            continue
        # «Моана / Moana» в одной метке опознанию мешает: русское и английское
        # название - это два разных названия, а не одно длинное.
        if ' / ' in text:
            text = text.split(' / ')[0].strip()
        return text
    return ''


def _int(value):
    try:
        return int(str(value).strip())
    except Exception:
        return 0


def _split(value):
    text = strip_tags(value)
    if not text:
        return []
    return [part.strip() for part in re.split(r'[,/|]', text) if part.strip()]


def _https(url):
    # Постеры и кадры Кинопоиска отдаются и по https; часть сетей режет http.
    for host in ('http://st.kp.yandex.net', 'http://avatars.mds.yandex.net'):
        if url.startswith(host):
            return 'https://' + url[len('http://'):]
    return url


def art_of(info):
    """Картинки строки, из которых убраны адреса молчащих складов."""
    info = info or {}
    cover = _https(str(info.get('cover') or '').strip())
    fanart = _https(str(info.get('fanart') or '').strip())
    art = {}
    for key, value in (('poster', cover), ('thumb', cover), ('icon', cover),
                       ('fanart', fanart or cover)):
        if value:
            art[key] = value
    if image_host is not None:
        try:
            art = {k: v for k, v in art.items() if image_host.usable(v)}
        except Exception:
            pass
    return art


def kinopoisk_id(info):
    """Номер Кинопоиска, если запись пришла оттуда.

    Запись Кинопоиска (kpdb.get_info) кладёт свой номер в поле id, а строка
    списка РуТора кладёт туда НОМЕР РАЗДАЧИ - их нельзя путать, иначе скин
    получит опознание чужого фильма. Отличаем по признакам самой записи: у
    кинопоисковой есть оценка и обложка на их складе.
    """
    info = info or {}
    explicit = str(info.get('kp_id') or '').strip()
    if explicit.isdigit():
        return explicit
    number = str(info.get('id') or '').strip()
    if not number.isdigit():
        return ''
    cover = str(info.get('cover') or '')
    if 'kp.yandex.net' in cover or 'kinopoisk' in cover:
        return number
    return ''


def release_line(release, source=None, quality='', resolution=''):
    """Вторая строка строки релиза: чем этот релиз отличается от соседних.

    Владелец 11.09.2026: «нужно оставить сведения о релизе, может быть в
    качестве второй строки». Первая строка - чистое название фильма (по нему
    скин опознаёт строку и так же выглядят все остальные строки в скине),
    вторая - вид и высота, размер, сиды и хвост названия раздачи: озвучка и
    группа, ради которых релизы и выбирают.
    """
    release = release or {}
    source = source or {}
    full = strip_tags(release.get('release_fulltitle') or release.get('fulltitle')
                      or source.get('fulltitle'))
    size = strip_tags(release.get('release_size') or source.get('size'))
    seeds = strip_tags(release.get('release_seeds') or source.get('seeds'))
    parts = []
    frame = strip_tags(release.get('release_frame'))
    if frame:
        # Точный размер кадра - здесь, а не в чипе: чип говорит класс («480»),
        # а «656x352» - это то, что действительно лежит в файле. Вид и класс в
        # этой строке при этом не повторяются: они стоят рядом, в чипе.
        parts.append(frame)
    else:
        head = ' '.join(x for x in (quality, ('%sp' % resolution) if resolution else '') if x)
        if head:
            parts.append(head)
    if size:
        parts.append(size)
    if seeds:
        parts.append('%s сид.' % seeds)
    tail = _release_tail(full, quality, resolution)
    if tail:
        parts.append(tail)
    return ' · '.join(parts)


def _release_tail(full, quality='', resolution=''):
    """Хвост названия раздачи: то, что стоит после года - озвучка и группа."""
    text = strip_tags(full)
    if not text:
        return ''
    hit = re.search(r'\((?:19|20)\d{2}(?:\s*-\s*(?:19|20)?\d{2,4})?\)', text)
    if hit:
        text = text[hit.end():]
    else:
        # Года в названии нет - оставляем всё после первого разделителя.
        text = text.split(' / ')[-1]
    text = text.strip(' |,-–—')
    if quality:
        # Вид и высота уже стоят первыми в строке, второй раз они не нужны.
        text = re.sub(re.escape(quality), '', text, count=1, flags=re.IGNORECASE)
    if resolution:
        text = re.sub(r'(?<!\d)%sp?(?!\d)' % re.escape(resolution), '', text,
                      count=1, flags=re.IGNORECASE)
    text = _SPACES.sub(' ', text.replace('|', ' · ')).strip(' ·,-')
    return text[:70]


def apply(listitem, info, source=None, release=None, kind_hint=''):
    """Поставить строке всё, что читает скин. Возвращает поставленные картинки.

    info    - запись о фильме (из info.db, с Кинопоиска или со страницы раздачи);
    source  - строка списка РуТора: в ней название раздачи, сиды и размер;
    release - те же поля, когда строка играбельная (релиз).
    """
    info = info or {}
    source = source or {}
    release = release or {}

    is_show = str(info.get('type') or source.get('type') or kind_hint
                  or '').strip().lower() in ('show', 'shows', 'tvshow', 'series')
    title = film_title(info, source)
    original = strip_tags(info.get('originaltitle') or source.get('originaltitle'))
    if ' / ' in original:
        original = original.split(' / ')[-1].strip()
    year = _int(info.get('year') or source.get('year'))
    plot = strip_tags(info.get('plot'))
    genres = _split(info.get('genre'))
    # У записи со страницы раздачи страна попадает в поле studio - так её
    # кладёт rutor.get_info («Страна: ...»), - а у записи Кинопоиска есть и
    # country, и studio с тем же значением.
    countries = _split(info.get('country') or info.get('studio'))

    labels = {'mediatype': 'tvshow' if is_show else 'movie'}
    if title:
        labels['title'] = title
    if original:
        labels['originaltitle'] = original
    if year:
        labels['year'] = year
    if plot:
        labels['plot'] = plot
    if genres:
        labels['genre'] = genres
    if countries:
        labels['country'] = countries
    duration = _int(info.get('duration'))
    if duration:
        # У Кинопоиска длительность в минутах, у Kodi в секундах.
        labels['duration'] = duration * 60 if duration < 1000 else duration
    try:
        listitem.setInfo('video', labels)
    except Exception:
        pass

    ids = {}
    kp_id = kinopoisk_id(info)
    tmdb_id = str(info.get('tmdb_id') or info.get('tmdb') or '').strip()
    imdb_id = str(info.get('imdb_id') or info.get('imdb') or '').strip()
    if kp_id:
        ids['kinopoisk'] = kp_id
    if tmdb_id.isdigit():
        ids['tmdb'] = tmdb_id
    if imdb_id.startswith('tt'):
        ids['imdb'] = imdb_id
    if ids:
        try:
            listitem.setUniqueIDs(ids)
        except Exception:
            pass

    try:
        rating = float(str(info.get('rating') or '').replace(',', '.'))
    except Exception:
        rating = 0.0
    if rating > 0:
        try:
            listitem.setRating('kinopoisk', rating, 0, True)
        except Exception:
            pass

    quality, resolution = release_parts(
        release.get('release_fulltitle') or release.get('fulltitle')
        or source.get('fulltitle') or '')
    if not resolution:
        # В названии раздачи высоты нет - берём класс, посчитанный по размеру
        # кадра со страницы релиза (release_tech). Владелец 11.09.2026: «как
        # понять какое разрешение у BDRip?».
        resolution = str(release.get('release_frame_class') or '').strip()

    props = {'sublime_kind': 'shows' if is_show else 'movies'}
    if quality:
        props['sublime_release_quality'] = quality
    if resolution:
        props['sublime_release_resolution'] = resolution
    if year:
        props['SourceYear'] = str(year)
    if countries:
        props['SourceCountry'] = ' / '.join(countries)
    if kp_id:
        props['kinopoisk_id'] = kp_id
    if tmdb_id.isdigit():
        props['tmdb_id'] = tmdb_id
    if imdb_id.startswith('tt'):
        props['imdb_id'] = imdb_id
    if original:
        props['original_title'] = original
    seeds = strip_tags(release.get('release_seeds') or source.get('seeds'))
    size = strip_tags(release.get('release_size') or source.get('size'))
    if seeds:
        props['rutor_seeds'] = seeds
    if size:
        props['rutor_size'] = size
    for name, value in props.items():
        try:
            listitem.setProperty(name, str(value))
        except Exception:
            pass

    # ВИДИМАЯ МЕТКА. У строки фильма - чистое название, как у всех строк в
    # скине. У строки релиза - сведения о релизе: вид и высота, размер, сиды,
    # озвучка. Владелец 11.09.2026: «нужно оставить сведения о релизе».
    #
    # Вторая строка (label2) для этого не годится, и это замерено: в списке
    # Kodi сам пишет в неё длительность - на .30 в списке релизов «Одного
    # дома» вместо нашей строки стояло «1:43:00». Поэтому сведения идут в
    # первую строку, а чистое название - в Title, откуда его и читает скин
    # (и опознание, и заголовок в панели берут Title, а не метку).
    if release:
        second = release_line(release, source, quality, resolution)
        if second:
            try:
                listitem.setLabel(second)
                # Имя свойства общее, не «rutor_»: показывает эту строку скин
                # (Includes_Info.xml, Info_Combined_Row), и знать про РуТор ему
                # незачем - так же сможет любой другой торрент-плагин.
                listitem.setProperty('sublime_release_details', second)
                listitem.setProperty('rutor_release', second)
            except Exception:
                pass
    elif title:
        try:
            listitem.setLabel(title)
        except Exception:
            pass

    art = art_of(info)
    if art:
        try:
            listitem.setArt(art)
        except Exception:
            pass
    return art
