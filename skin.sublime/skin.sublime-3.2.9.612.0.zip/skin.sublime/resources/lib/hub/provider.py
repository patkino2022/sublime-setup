# -*- coding: utf-8 -*-
"""Talking to the video add-on and to Kodi, for the hub's own needs.

Ported from plugin.video.watchhub's common.py: the provider's catalogue paths,
a JSON-RPC call that cannot hang the service forever, and the name this box
signs its shared lists with.
"""
from __future__ import absolute_import, unicode_literals

import json
import threading

import xbmc

from .config import get_str, log
from .store import db


def video_addon():
    return get_str('video_addon_id', 'plugin.video.filmix') or 'plugin.video.filmix'


def catalog_path(category):
    key = 'movies_catalog_path' if category == 'movies' else 'shows_catalog_path'
    default = '/movies/' if category == 'movies' else '/serials/'
    return get_str(key, default) or default


def catalog_directory(category, page=1):
    path = catalog_path(category)
    if '://' in path:   # sublime-setup: полный адрес - другое дополнение или библиотека Kodi
        if path.startswith(('videodb://', 'library://')):
            return path if not page or page <= 1 else ''
        if page and page > 1:
            path = '%s%spage=%d' % (path, '&' if '?' in path else '?', page)
        return path
    if page and page > 1:
        joiner = '&' if '?' in path else '?'
        path = '%s%spage=%d' % (path, joiner, page)
    return 'plugin://%s%s' % (video_addon(), path)


def jsonrpc(method, params, timeout=25):
    """In-process JSON-RPC with a hard timeout.

    xbmc.executeJSONRPC has no timeout of its own, and a stuck target route
    would otherwise hang the caller forever - the exact failure the retired
    recommendation add-on hit repeatedly. Python cannot kill a thread, so a
    truly wedged call is abandoned (daemon=True) rather than waited on.
    """
    result = {}

    def _worker():
        try:
            result['raw'] = xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'method': method, 'params': params, 'id': 1,
            }))
        except Exception as exc:
            result['error'] = exc

    thread = threading.Thread(target=_worker)
    thread.daemon = True
    thread.start()
    thread.join(timeout)
    if thread.is_alive():
        log('jsonrpc %s: таймаут %s с' % (method, timeout), xbmc.LOGWARNING)
        return {}
    if 'error' in result:
        log('jsonrpc %s: %s' % (method, result['error']), xbmc.LOGWARNING)
        return {}
    try:
        return json.loads(result.get('raw') or '{}')
    except Exception as exc:
        log('jsonrpc %s: ответ не разобран (%s)' % (method, exc), xbmc.LOGWARNING)
        return {}


def get_directory(directory, properties=None, timeout=25):
    payload = jsonrpc('Files.GetDirectory', {
        'directory': directory,
        'media': 'video',
        'properties': properties or ['art', 'year', 'plot', 'genre', 'country',
                                     'rating', 'playcount', 'title',
                                     'originaltitle', 'studio', 'mpaa', 'uniqueid'],
    }, timeout=timeout)
    return ((payload.get('result') or {}).get('files') or [])


def instance_id():
    """A stable name for this box, used to record who built a shared list.

    Kodi's own device name is what a human recognises in a log line ("4k" /
    "Bedroom"), with a random suffix only if that is unavailable.
    """
    store = db()
    existing = store.get_flag('instance_id')
    if existing:
        return existing
    # The machine's hostname, not System.FriendlyName: reading a GUI info label
    # can be reached from a background thread through the sync path, and Kodi
    # 22-BETA1 segfaults on exactly that (CGUIInfoManager::GetMultiInfoLabel).
    # On these boxes the hostname is already what a human calls them - "4k" and
    # "Bedroom" - so nothing is lost.
    name = ''
    try:
        import socket
        name = (socket.gethostname() or '').strip()
    except Exception:
        name = ''
    if not name:
        import uuid
        name = 'box-%s' % uuid.uuid4().hex[:8]
    store.set_flag('instance_id', name)
    return name
