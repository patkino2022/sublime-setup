# -*- coding: utf-8 -*-
"""Giving the shared history the paths it is missing.

Kodi keys watched state by the path that plays the film, so a row in the shared
store without a path cannot be applied anywhere - it travels between the boxes
and does nothing. Measured on the store on <коробка>: 2811 watched rows, of
which 1298 carry no path. That is exactly the gap the owner sees - 2428 watched
files in Kodi on .20 against 1758 on .30, with both boxes' sync cursors equal and
both convinced they are up to date - and it is why the same series can be ticked
in one list and show an unwatched episode in another.

The path is recoverable. Every row knows its title, its year and, for an episode,
its season and number; the provider's own catalogue knows the URL that plays it.
So the path is recovered here, applied to this box's Kodi, and pushed back to the
store with the row - once, for every box.

Rows the catalogue cannot match are counted and left alone rather than guessed
at: a wrong path would mark the wrong film watched everywhere.
"""
from __future__ import absolute_import, unicode_literals

import time

import xbmc

from . import catalog, history, identity, sync
from .config import log
from ..l10n import tr
from .import_legacy import _episode_path
from .store import db

DONE_FLAG = 'paths_repaired_at'
# When a pass repairs nothing, the leftovers are unknown to the catalogue; there
# is no point parsing 16 thousand posts again for a week.
EXHAUSTED_FLAG = 'paths_repair_exhausted_at'
EXHAUSTED_FOR = 7 * 24 * 3600
# One pass covers this many rows of the store. The whole store is under three
# thousand rows, so a couple of passes finish it, and a bounded pass cannot hold
# the box for long.
PAGE_LIMIT = 400
PUSH_BATCH = 100


def _path_index():
    """{(normalised title, year): play path} from the provider's catalogue."""
    index = {}
    for row in catalog.iter_post_rows():
        label = row.get('label') or row.get('title') or ''
        path = row.get('file') or ''
        if not label or not path:
            continue
        key = (identity.normalize_title(label), str(row.get('year') or '')[:4])
        index.setdefault(key, path)
    return index


def _resolve(row, index):
    """The path that plays this row, or '' when the catalogue does not know it."""
    label = row.get('label') or ''
    if not label:
        return ''
    key = (identity.normalize_title(label), str(row.get('year') or '')[:4])
    show_path = index.get(key)
    if not show_path:
        return ''
    try:
        season = int(row.get('season') or 0)
        episode = int(row.get('episode') or 0)
    except (TypeError, ValueError):
        season = episode = 0
    if episode > 0:
        return _episode_path(show_path, season, episode)
    return show_path


def run(limit=0):
    """Repair one bounded slice of the store. Returns a short report."""
    if not sync.enabled():
        return {'ok': False, 'reason': tr(31943)}
    store = db()
    # Building the title index means parsing the provider's whole catalogue, so
    # a pass that has nothing left to fix must not do it. After a pass that
    # repaired nothing, the rows that remain are titles the catalogue does not
    # know at all - they will not become known next hour.
    if int(store.get_flag(EXHAUSTED_FLAG) or 0) > int(time.time()) - EXHAUSTED_FOR:
        return {'ok': False, 'reason': tr(31944)}
    index = _path_index()
    if not index:
        return {'ok': False, 'reason': tr(31945)}
    limit = limit or PAGE_LIMIT
    seen = missing = fixed = applied = unmatched = 0
    since = 0
    pending = []
    while seen < limit:
        result = sync._request('changes?w_since=%d&w_key=&p_since=%d&p_key=&f_since=%d&f_key='
                               % (since, since, int(time.time())))
        if not result.get('ok'):
            return {'ok': False, 'reason': tr(31946) % (result.get('error') or '?')}
        rows = result.get('watched') or []
        if not rows:
            break
        for row in rows:
            seen += 1
            if str(row.get('path') or '').strip():
                continue
            missing += 1
            path = _resolve(row, index)
            if not path:
                unmatched += 1
                continue
            fixed += 1
            if history.mark_watched(path, int(row.get('playcount') or 1),
                                    int(row.get('last_watched') or 0)):
                applied += 1
            filled = dict(row)
            filled['path'] = path
            filled['source'] = 'kodi'
            pending.append(filled)
            if len(pending) >= PUSH_BATCH:
                _push(pending)
                pending = []
        nxt = int(result.get('next_w_since') or 0)
        if nxt <= since:
            break
        since = nxt
        if not result.get('truncated'):
            break
    if pending:
        _push(pending)
    history.invalidate()
    store.set_flag(DONE_FLAG, str(int(time.time())))
    if not fixed:
        store.set_flag(EXHAUSTED_FLAG, str(int(time.time())))
    report = {'ok': True, 'seen': seen, 'missing': missing, 'fixed': fixed,
              'applied': applied, 'unmatched': unmatched}
    log('восстановление путей: просмотрено %d, без пути %d, восстановлено %d, '
        'применено %d, без совпадения %d'
        % (seen, missing, fixed, applied, unmatched))
    return report


def _push(rows):
    """Send the repaired rows back, so no box has to repair them again."""
    try:
        result = sync._request('push', payload={'watched': rows, 'progress': [],
                                               'feedback': []})
        if not result.get('ok'):
            log('восстановленные пути не отправлены: %s'
                % (result.get('error') or '?'), xbmc.LOGWARNING)
    except Exception as exc:
        log('восстановленные пути не отправлены: %s' % exc, xbmc.LOGWARNING)
