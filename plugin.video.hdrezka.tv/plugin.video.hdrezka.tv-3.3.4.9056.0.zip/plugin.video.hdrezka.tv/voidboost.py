import re
import base64
import logging
from typing import List, Tuple, Optional

logger = logging.getLogger(__name__)

BK_SEP = '//_//'
BK_BLOCKS = [
    'JCQhIUAkJEBeIUAjJCRA',
    'QEBAQEAhIyMhXl5e',
    'IyMjI14hISMjIUBA',
    'Xl5eIUAjIyEhIyM=',
    'JCQjISFAIyFAIyM='
]

# Компилируем один раз
QUALITY_PATTERN = re.compile(r'\[((\d+)[^]]+)].*?(http.+?mp4)', re.DOTALL)

# Сайт подписывает 2K и 4K не строками, а «2K»/«4K»: первое число в подписи было бы 2 и 4,
# ниже 360p, и такой вариант не выбирался никогда (17.11.2026, «Дюна 2», «Аватар 2»)
_K_LINES = {1: 1080, 2: 1440, 4: 2160, 8: 4320}


def _quality_number(name, number):
    m = re.match(r'\s*(\d+)\s*[Kk]\b', name or '')
    if m:
        return _K_LINES.get(int(m.group(1)), int(m.group(1)) * 1000)
    return number


def parse_streams(data: str, stream_type: str = 'hls') -> List[Tuple[str, int, str]]:
    """
    Парсит потоки из обфусцированной или plain text строки.
    stream_type: 'hls' (адаптивный HLS поток через inputstream.adaptive) или 'mp4' (прямой файл).

    Returns:
        [(quality_name, quality_num, url), ...] отсортировано по качеству desc

    Raises:
        ValueError: Если нет валидных потоков
    """
    if not isinstance(data, str) or not data.strip():
        raise ValueError("Input must be non-empty string")

    # Шаг 1: Очистка (как в оригинале)
    cleaned = _clean_obfuscation(data)

    # Шаг 2: Декодирование с автоопределением формата
    decoded = _decode(cleaned)
    if not decoded:
        raise ValueError("Failed to decode streams data")

    # Шаг 3: Парсинг (с учетом типа потока HLS/MP4)
    streams = _parse_quality_blocks(decoded, stream_type=stream_type)

    if not streams:
        logger.warning(f"No streams parsed from: {decoded[:200]}...")
        raise ValueError("No streams found in decoded data")

    # Шаг 4: Сортировка: по разрешению, а при равном - сначала вариант с пометкой
    # («1080p Ultra» у премиум-аккаунта - тот же 1080p с битрейтом выше). Прежде
    # равные шли в порядке ответа сайта, «1080p» раньше «1080p Ultra», и при
    # настройке 2160p играл обычный 1080p (.20, 17.11.2026)
    return sorted(streams, key=lambda s: (s[1], s[0].strip().lower() != '%dp' % s[1]), reverse=True)


def _clean_obfuscation(data: str) -> str:
    """Удаляет escape-символы и мусорные блоки."""
    result = data.replace('\\', '')
    for block in BK_BLOCKS:
        result = result.replace(BK_SEP + block, '')
    return result


def _decode(data: str) -> Optional[str]:
    """
    Определяет формат и декодирует.
    Plain text: начинается с [
    Base64: остальное
    """
    # Plain text (новый формат без обфускации)
    if data.startswith('['):
        logger.debug("Detected plain text format")
        return data

    # Base64 (старый формат)
    try:
        # Проверяем минимальную длину для base64
        if len(data) < 4:
            return None

        decoded_bytes = base64.b64decode(data[2:])
        return decoded_bytes.decode('utf-8')
    except (ValueError, UnicodeDecodeError) as e:
        logger.debug(f"Base64 decode failed: {e}")
        return None


def _parse_quality_blocks(decoded: str, stream_type: str = 'hls') -> List[Tuple[str, int, str]]:
    """
    Парсит блоки качества и извлекает ссылки нужного типа (HLS или MP4).
    """
    streams = []

    for part in decoded.split(','):
        m = re.search(r'\[((\d+)[^]]+)\](.*)', part)
        if not m:
            continue
        quality_name = m.group(1).strip()
        quality_num = _quality_number(quality_name, int(m.group(2)))
        urls_raw = m.group(3)
        urls = [u.strip() for u in urls_raw.split(' or ') if u.strip().startswith(('http://', 'https://'))]
        if not urls:
            continue

        selected_url = None
        if stream_type.lower() == 'hls':
            hls_urls = [u for u in urls if ':hls:manifest.m3u8' in u or '.m3u8' in u]
            selected_url = hls_urls[0] if hls_urls else urls[0].replace(':hls:manifest.m3u8', '')
        else:
            mp4_urls = [u for u in urls if ':hls:manifest.m3u8' not in u and '.m3u8' not in u]
            selected_url = mp4_urls[0] if mp4_urls else urls[0].replace(':hls:manifest.m3u8', '')

        if selected_url and _is_valid_url(selected_url):
            streams.append((quality_name, quality_num, selected_url))

    if not streams:
        for match in QUALITY_PATTERN.finditer(decoded):
            quality_name = match.group(1)
            quality_num = _quality_number(quality_name, int(match.group(2)))
            url = match.group(3)
            if _is_valid_url(url):
                clean_url = url.replace(':hls:manifest.m3u8', '')
                streams.append((quality_name, quality_num, clean_url))

    return streams


def _is_valid_url(url: str) -> bool:
    """Проверяет что URL начинается с http и содержит домен."""
    return (
            url.startswith(('http://', 'https://')) and
            len(url) > 10 and
            '.' in url[8:]  # после http:// или https://
    )
