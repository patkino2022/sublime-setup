# -*- coding: utf-8 -*-
"""Лента подписок YouTube - из самого дополнения (plugin.video.youtube 8).

Дополнение 8 после входа по коду с телевизора (youtube.com/activate) отдаёт страницу
подписок телевизора (browse?id=FEsubscriptions): новые видео всех каналов, и у каждого -
описание (дополнение читает страницы роликов заранее, describe.py). Скин берёт строки оттуда
и добавляет только своё: точное время публикации (плитка знает лишь «2 days ago») и
крупную обложку. Своего клиента и токена у скина нет - вход и запросы целиком у дополнения.
"""
from __future__ import absolute_import, unicode_literals

import io
import json
import time

import xbmc

from .config import log
from ..sublime_helper import tls as _tls
from ..sublime_helper.config import youtube_addon, youtube_play_url, youtube_video_id

_tls.install()   # https при испорченном хранилище сертификатов системы (Windows)
from .youtube_inner import _best_art
from .youtube_trending import _region

ACCOUNTS = 'special://profile/addon_data/plugin.video.youtube/accounts.json'
TIMEOUT = 15.0
PAGES = 3


def _path(special):
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(special)
    except Exception:
        return xbmc.translatePath(special)


def _user():
    """Активная учётная запись дополнения: {access_token, refresh_token, expires_at, name}."""
    with io.open(_path(ACCOUNTS), encoding='utf-8') as fh:
        data = json.load(fh) or {}
    return (data.get('accounts') or {}).get(data.get('active') or '') or {}


def signed_in():
    """Выполнен ли вход в учётную запись в дополнении YouTube."""
    try:
        user = _user()
    except Exception:
        return False
    return bool(user.get('refresh_token') or user.get('access_token'))


PLAYER_URL = 'https://www.youtube.com/youtubei/v1/player?prettyPrint=false'
PUBLISHED = 'special://profile/addon_data/skin.sublime/youtube_published_v2.json'
PUBLISHED_KEEP = 2000
_published_cache = {}


def _publish_time(video_id):
    """[unix-время публикации, есть ли maxresdefault] из player сайта, без ключа и
    входа; None - не вышло."""
    import urllib.request
    from datetime import datetime
    body = {'context': {'client': {'clientName': 'WEB', 'clientVersion': '2.20251110.01.00',
                                   'hl': 'en', 'gl': _region()}},
            'videoId': video_id}
    request = urllib.request.Request(
        PLAYER_URL, data=json.dumps(body).encode('utf-8'),
        headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0',
                 'Origin': 'https://www.youtube.com'})
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT) as answer:
            data = json.loads(answer.read().decode('utf-8'))
        micro = (data.get('microformat') or {}).get('playerMicroformatRenderer') or {}
        value = micro.get('publishDate') or micro.get('uploadDate')
        if not value:
            return None
        listed = ' '.join(str(t.get('url') or '') for t in
                          (((data.get('videoDetails') or {}).get('thumbnail') or {})
                           .get('thumbnails') or []))
        # крупная обложка есть не у всех роликов; player перечисляет только существующие
        return [int(datetime.fromisoformat(value).timestamp()), '/maxresdefault' in listed]
    except Exception:
        return None


def published_times(ids):
    """{id: unix} для роликов ленты. Плитка телевизора знает только «1 day ago», и
    дата съезжала на сутки («чё происходит #351» 16.11 вместо 15.11, .20, 17.11.2026).
    Время ролика не меняется, поэтому однажды узнанное хранится на диске."""
    path = _path(PUBLISHED)
    if not _published_cache:
        try:
            with io.open(path, encoding='utf-8') as fh:
                _published_cache.update(json.load(fh))
        except Exception:
            pass
    missing = [i for i in ids if i and i not in _published_cache]
    if missing:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=min(8, len(missing))) as pool:
            for video_id, when in zip(missing, pool.map(_publish_time, missing)):
                if when:
                    _published_cache[video_id] = when
        keep = sorted(_published_cache.items(), key=lambda kv: kv[1][0])[-PUBLISHED_KEEP:]
        _published_cache.clear()
        _published_cache.update(keep)
        try:
            tmp = path + '.tmp'
            with io.open(tmp, 'w', encoding='utf-8') as fh:
                fh.write(json.dumps(_published_cache))
            import os
            os.replace(tmp, path)
        except Exception as exc:
            log('время роликов YouTube не сохранено: %s' % exc, xbmc.LOGWARNING)
    return {i: _published_cache[i] for i in ids if i in _published_cache}


def _video_id(row):
    return youtube_video_id((row or {}).get('file'))


def finish_rows(rows):
    """Полоса YouTube перед записью: точная дата, крупная обложка, новое сверху.

    Полосы без ключа (тренды, эфиры, новости, чарты, подписки) знали дату только как
    «2 days ago», а обложку - как hqdefault/sddefault; до maxresdefault её поднимал
    отдельный проход в конце заполнения, когда Kodi уже показал строки и построил фоны
    из 480x360 (.20, 17.11.2026: «фоны качественные только в подписках и рекомендациях»,
    «виджеты не сортированы по убыванию даты»). Один запрос player на ролик (с кэшем на
    диске) даёт и точное время, и наличие крупной обложки."""
    if not rows:
        return rows
    from .youtube_inner import _best_art
    exact = published_times([_video_id(r) for r in rows])
    for row in rows:
        video_id = _video_id(row)
        known = exact.get(video_id)
        if not known:
            continue
        when = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(known[0]))
        row['dateadded'] = when
        row['premiered'] = when[:10]
        if known[1]:
            art = row.get('art') or {}
            best = _best_art(video_id, [{'width': 1280}])
            for key in ('thumb', 'fanart', 'landscape'):
                if key in art or key == 'thumb':
                    art[key] = best[key]
            row['art'] = art
    rows.sort(key=lambda r: str(r.get('dateadded') or ''), reverse=True)
    return rows


def _plain(url):
    """Адрес картинки из ответа Kodi (image://<адрес>/) - обычным адресом, как в снимках."""
    url = str(url or '')
    if url.startswith('image://'):
        import urllib.parse
        url = urllib.parse.unquote(url[len('image://'):].rstrip('/'))
    return url


def _studio(value):
    if isinstance(value, (list, tuple)):
        return str(value[0]) if value else ''
    return str(value or '')


def feed_path():
    return 'plugin://%s/browse?id=FEsubscriptions' % youtube_addon()


def _listing(limit):
    """[(id ролика, строка Kodi)] ленты подписок дополнения, до limit, с продолжением страниц."""
    from .provider import get_directory
    path, found, seen = feed_path(), [], set()
    for _page in range(PAGES):
        files = get_directory(path, properties=['title', 'plot', 'studio', 'art'], timeout=90)
        path = None
        for row in files:
            video_id = youtube_video_id(row.get('file'))
            if video_id:
                if video_id not in seen:
                    seen.add(video_id)
                    found.append((video_id, row))
            elif '/page?' in str(row.get('file') or ''):
                path = row['file']           # «Next page» дополнения
        if not path or len(found) >= limit:
            break
    return found[:limit]


def subscriptions(limit=60):
    """Строки ленты подписок (новое сверху). [] - если входа нет или дополнение ничего не дало."""
    if not signed_in():
        return []
    try:
        found = _listing(limit)
    except Exception as exc:
        log('подписки YouTube: лента дополнения не получена: %s' % exc, xbmc.LOGWARNING)
        return []
    exact = published_times([video_id for video_id, _row in found])
    rows, last = [], time.time()
    for video_id, item in found:
        known = exact.get(video_id)
        # точного времени нет - ролик встаёт следом за предыдущим (лента и так новым вперёд)
        when = known[0] if known else last - 1
        last = min(last, when)
        given = (item.get('art') or {}).get('thumb')
        art = _best_art(video_id, [{'width': 1280}] if known and known[1]
                        else [{'url': _plain(given)}] if given else [])
        rows.append({
            'label': item.get('title') or item.get('label') or '',
            'file': youtube_play_url(video_id),
            'filetype': 'file',
            'plot': item.get('plot') or '',
            'dateadded': time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(when)),
            'premiered': time.strftime('%Y-%m-%d', time.localtime(when)) if known else '',
            'art': art,
            'studio': _studio(item.get('studio')),
            'channel_id': '',
            'genre': [],
            'playcount': 0,
            'episode': -1,
            '_api': True,
        })
    try:
        from .youtube_meta import fill_channels
        fill_channels(rows)                  # id канала - из описаний дополнения (descriptions.json)
    except Exception as exc:
        log('подписки YouTube: каналы не проставлены: %s' % exc, xbmc.LOGWARNING)
    rows.sort(key=lambda r: str(r.get('dateadded') or ''), reverse=True)
    log('подписки YouTube: %d роликов из ленты дополнения, с описанием %d'
        % (len(rows), sum(1 for r in rows if r['plot'])))
    return rows
