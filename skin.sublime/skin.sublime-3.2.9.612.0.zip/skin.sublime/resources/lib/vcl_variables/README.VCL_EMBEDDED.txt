Embedded VCL Variables engine
Source: script.skinvariables 2.2.1 by jurialmunkey
Purpose: keep the SkinVariables mechanisms used by this skin without requiring script.skinvariables as an external Kodi addon dependency.
Namespace: script.skinvariables / skinvariables-* calls are renamed to the skin addon id and vclvariables-* includes/properties.
