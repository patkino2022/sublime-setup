# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import hashlib
import json
import threading
import time

import simplemedia
import xbmc
import xbmcgui

from .cache import FilmixCache
from .filters import Filters
from .tmdbresolver import TMDbResolver
from .utilities import Utilities, plugin
from .listitems import _clean_text, _looks_ukrainian_text, _select_plot
from .textutils import (
    normalize_filter_label as _normalize_filter_label,
    is_blocked_custom_filter_label as _is_blocked_custom_filter_label,
    find_filter_ids as _find_filter_ids,
)
from .web import Filmix, FilmixError


class FilmixPrewarm(object):
    # Only list endpoints. No post(), no TMDb, no artwork downloads.
    # FAST_CACHE_SAFE: startup warms only main sections. Genre lists are lazy:
    # opened/refreshed one exact genre at a time, never all 25x2 on Kodi startup.
    REFRESH_INTERVAL = 60
    PREWARM_BATCH_SIZE = 3
    CATALOG_MAIN_MAX_AGE = 15 * 60
    CATALOG_PERSONAL_MAX_AGE = 10 * 60
    CATALOG_GENRE_MAX_AGE = 30 * 60
    CATALOG_MAX_AGE = CATALOG_MAIN_MAX_AGE
    REQUEST_THROTTLE = 180
    FORCE_FLAG = 'prewarm_force_sections'
    BUSY_FLAG = 'prewarm_busy'
    REQUEST_FLAG_PREFIX = 'prewarm_req_'
    # 2.2.21 METADATA_QUEUE_NO_DROP:
    # Keep Home/widget route rendering fast, but do not lose fresh IDs. 2.2.14
    # accepted only 12 IDs per route and kept a 60-ID queue, so active widgets
    # logged skipped_by_route_cap/dropped and new items could remain without
    # dates/plots/episode counts until several later passes.
    # 2.2.46 PRIORITY_METADATA_ENRICH:
    # Background metadata was too polite for AM8 4GB: visible rows could sit in
    # a 120-id queue for 20-30 minutes because duplicate requests were not
    # promoted and the service processed only 10 ids/minute.  Keep widget/search
    # routes fast-first, but drain the background queue faster and prioritise
    # the currently visible rows.
    # 2.2.47: keep the queue priority-first, but never let one background
    # metadata tick block Kodi for minutes.  The 2.2.46 batch=24 worked for
    # quick skips, but if 12+ items needed Filmix.post/TMDb details one batch
    # could run for ~175s.  Limit heavy calls and defer the rest back to the
    # front of the queue.
    # Refresh serial playback trees occasionally in the background. Interactive
    # opens use a much shorter TTL; this only prevents a permanently stale cache.
    TMDB_MISS_TTL = 6 * 60 * 60
    # Bumped in the series year gate no longer compares a Filmix
    # post's release year against a show's FIRST air year, so every miss cached
    # under the old rule - «Безумцы» recorded `year_mismatch:2010!=2007`, and
    # any other series whose Filmix release year fell inside its airing range
    # rather than on its premiere - is now wrong and must be retried rather than
    # sat on for the TTL. That is exactly what this marker is for.
    TMDB_MISS_BUILD = '2.2.59.56.9'
    # Refresh state is isolated per actual Kodi window. One hub must never
    # consume invalidations belonging to another hub/skin window.
    # 2.2.59 AM8_4GB_METADATA_REFRESH_ONLY:
    # Restore metadata-only Home refresh so plot/date written by background
    # enrich becomes visible in AF3 widgets again.  Keep prewarm/catalog refresh
    # disabled to avoid the previous 5-8 widget reroute storm on AM8 4GB.
    HOME_AUTO_REFRESH_ENABLED = True
    # this is not populated by ordinary in-addon catalog browsing and can therefore
    # drive periodic player-topology checks without crawling unrelated lists.
    LIVE_TOPOLOGY_WIDGET_MAX_AGE = 36 * 60 * 60
    #     # Register the exact Kodi window that requested each Filmix widget route.
    # This replaces skin/window-id allowlists and works with arbitrary skins.
    # Kodi's normal Videos navigation window is regular in-addon browsing, not
    # a skin widget host.  This is a Kodi core window id, not a skin-specific id.
    STANDARD_ADDON_BROWSER_WINDOW_IDS = (10025,)
    PLAYER_TOPOLOGY_ACTIVE_TTL = 15 * 60
    PLAYER_TOPOLOGY_ARCHIVE_TTL = 6 * 60 * 60
    PLAYER_TOPOLOGY_RECENT_CHANGE_TTL = 24 * 60 * 60
    PLAYER_TOPOLOGY_DISCOVERY_INTERVAL = 60
    PLAYER_TOPOLOGY_DISCOVERY_BATCH = 4
    PLAYER_TOPOLOGY_CURSOR_PREFIX = 'player_topology_cursor_'
    PLAYER_TOPOLOGY_RECENT_PREFIX = 'player_topology_recent_'
    PLAYER_TOPOLOGY_DISCOVERY_FLAG = 'player_topology_discovery_last'
    STALE_FAIL_PREFIX = 'prewarm_stale_fail_'
    STALE_FAIL_BACKOFF = 10 * 60
    SYNC_ROUTE_LOCK_PREFIX = 'prewarm_sync_route_lock_'
    SYNC_ROUTE_LOCK_TTL = 90
    # 2.2.31 FILTER_AVAILABILITY_SERVICE_TICK_FIX:
    # Visibility of Genre/Country menu entries is based on each exact first-page
    # filter result, separately for movies and serials.  Empty filters are hidden
    # only after repeated successful empty checks, so a temporary Filmix/API glitch
    # cannot remove a valid country/genre from the menu.
    FILTER_AVAIL_STATE_PREFIX = 'filter_availability_state_'
    FILTER_AVAIL_QUEUE_FLAG = 'filter_availability_queue'
    FILTER_AVAIL_BUSY_FLAG = 'filter_availability_busy'
    FILTER_AVAIL_QUEUE_MAX = 600
    FILTER_AVAIL_BATCH_SIZE = 4
    FILTER_AVAIL_RECHECK_INTERVAL = 24 * 60 * 60
    FILTER_AVAIL_EMPTY_CONFIRMATIONS = 2
    # 2.2.31: first empty result is only a suspicion. Re-check it soon so
    # empty genre/country rows disappear during the same session, not after 24h.
    FILTER_AVAIL_EMPTY_CONFIRM_RETRY_INTERVAL = 5 * 60
    JOB_FORCE = 'prewarm_force'
    JOB_FILTER_AVAIL = 'filter_availability'
    JOB_PLAYER_TOPOLOGY = 'player_topology'
    # A post we have never cached, queued so its own description exists before
    # anyone opens the film. Deliberately a separate kind from the topology
    # refresh above: that one re-fetches posts we already have (expensive, and
    # switched off on these boxes), this one fetches what is simply missing.
    JOB_POST_DETAILS = 'post_details'
    PLAYER_TOPOLOGY_QUEUE_MAX = 120
    PLAYER_TOPOLOGY_BATCH_SIZE = 2
    PLAYER_TOPOLOGY_RETRY = 5 * 60
    JOB_LEASE_SECONDS = 15 * 60

    _thread = None
    _filter_avail_thread = None
    _player_topology_thread = None
    _last_round = 0
    _refresh_queue_lock = threading.RLock()

    @staticmethod
    def _bool_setting(setting_id, default=True):
        try:
            value = plugin.get_setting(setting_id)
        except Exception:
            return bool(default)
        if isinstance(value, bool):
            return value
        text = str(value if value is not None else '').strip().lower()
        if text in ('', 'none'):
            return bool(default)
        if text in ('true', '1', 'yes', 'on', 'enabled'):
            return True
        if text in ('false', '0', 'no', 'off', 'disabled'):
            return False
        return bool(default)


    @classmethod
    def is_background_prewarm_enabled(cls):
        # 21.11.2026: запасной cache_prewarm_enabled убран - background_prewarm_enabled
        # объявлен в settings.xml со значением по умолчанию, пустым Kodi его не отдаёт.
        return cls._bool_setting('background_prewarm_enabled', True)


    @classmethod
    def is_cache_prewarm_enabled(cls):
        # Backwards-compatible name used by background-worker code.
        return cls.is_background_prewarm_enabled()

    def _cache_prewarm_disabled_log(self, action):
        try:
            self._log('cache/prewarm disabled: ' + str(action))
        except Exception:
            pass

    MAIN_SECTIONS = (
        'movies',
        'serials',
        'multfilms',
        'multserials',
        'popular',
        'top_views',
    )

    GENRE_SECTIONS = (
        'movies',
        'serials',
    )

    # 21.11.2026: избранное и «отложенное» только здесь - раньше они стояли и в
    # MAIN_SECTIONS, и фоновый проход tick() обходил их второй раз вслед за
    # tick_personal_sections().
    PERSONAL_SECTIONS = (
        'favorites',
        'deferred',
    )

    FILTER_INDEXES_TO_WARM = (
        'categories',
        'countries',
    )
    FILTER_INDEX_WARM_INTERVAL = 60 * 60
    FILTER_INDEX_LAST_FLAG = 'filter_index_warm_last'

    CUSTOM_COUNTRIES = [
        {'label': 'Россия', 'countries': ['русские', 'россия', 'ссср', 'ссср/россия', 'ussr', 'soviet', 'russia']},
    ]

    CUSTOM_GENRES = [
        {'label': 'Аниме', 'categories': ['аниме', 'anime']},
        {'label': 'Биография', 'categories': ['биография', 'biography']},
        {'label': 'Боевики', 'categories': ['боевик', 'боевики', 'action']},
        {'label': 'Вестерн', 'categories': ['вестерн', 'western']},
        {'label': 'Военный', 'categories': ['военный', 'war']},
        {'label': 'Детектив', 'categories': ['детектив', 'криминал', 'detective', 'crime']},
        {'label': 'Детский', 'categories': ['детский', 'children', 'kids']},
        {'label': 'Для взрослых', 'categories': ['для взрослых', 'adult']},
        {'label': 'Документальные', 'categories': ['документальный', 'документальные', 'documentary']},
        {'label': 'Дорамы', 'categories': ['дорамы', 'дорама', 'drama asia', 'dorama']},
        {'label': 'Драмы', 'categories': ['драма', 'драмы', 'drama']},
        {'label': 'Исторический', 'categories': ['исторический', 'history', 'historical']},
        {'label': 'Комедия', 'categories': ['комедия', 'ситком', 'comedy', 'sitcom']},
        {'label': 'Мелодрама', 'categories': ['мелодрама', 'melodrama', 'romance']},
        {'label': 'Мистика', 'categories': ['мистика', 'mystic', 'mystery']},
        {'label': 'Музыка', 'categories': ['музыка', 'мюзикл', 'music', 'musical']},
        {'label': 'Приключения', 'categories': ['приключения', 'adventure']},
        {'label': 'Семейный', 'categories': ['семейный', 'family']},
        {'label': 'Спорт', 'categories': ['спорт', 'sport']},
        {'label': 'Триллеры', 'categories': ['триллер', 'триллеры', 'thriller']},
        {'label': 'Ужасы', 'categories': ['ужасы', 'horror']},
        {'label': 'Фантастика', 'categories': ['фантастика', 'sci-fi', 'science fiction']},
        {'label': 'Фэнтези', 'categories': ['фэнтези', 'fantasy']},
    ]

    def __init__(self, addon=None):
        self.addon = addon or plugin
        self.cache = FilmixCache(self.addon.profile_dir)

    def clear_stale_busy_flags(self, max_age=15 * 60, force=False):
        now = FilmixCache._ts()
        cleared = []
        live_threads = {
            self.BUSY_FLAG: getattr(self.__class__, '_thread', None),
            self.FILTER_AVAIL_BUSY_FLAG: getattr(self.__class__, '_filter_avail_thread', None),
        }
        for flag in (self.BUSY_FLAG, self.FILTER_AVAIL_BUSY_FLAG):
            thread = live_threads.get(flag)
            if (not force) and thread is not None:
                try:
                    if thread.is_alive():
                        continue
                except Exception:
                    pass
            try:
                row = self.cache.get_control_flag(flag)
            except Exception:
                row = None
            if not row:
                continue
            try:
                age = now - int(row.get('updated_ts') or 0)
            except Exception:
                age = int(max_age or 0) + 1
            if force or age >= int(max_age or 0):
                try:
                    self.cache.clear_control_flag(flag)
                    cleared.append(flag)
                except Exception:
                    pass
        if cleared:
            self._log('cleared stale busy flags: {0}'.format(','.join(cleared)))
        return cleared


    def _player_topology_ttl_for_item(self, item, post_id):
        try:
            recent = self.cache.get_control_flag(self.PLAYER_TOPOLOGY_RECENT_PREFIX + str(post_id))
            if recent and (self._now() - int(recent.get('updated_ts') or 0)) < int(self.PLAYER_TOPOLOGY_RECENT_CHANGE_TTL):
                return int(self.PLAYER_TOPOLOGY_ACTIVE_TTL)
        except Exception:
            pass
        # Do not infer that an old premiere year means a finished show: many
        # long-running series receive new seasons years later. Use the longer
        # archive TTL only when Filmix/TMDb explicitly marks the title finished.
        status = str((item or {}).get('status') or (item or {}).get('show_status') or '').strip().lower()
        ended = bool((item or {}).get('ended') or (item or {}).get('is_ended'))
        if ended or status in ('ended', 'finished', 'completed', 'complete', 'cancelled',
                              'завершен', 'завершён', 'закончен'):
            return int(self.PLAYER_TOPOLOGY_ARCHIVE_TTL)
        return int(self.PLAYER_TOPOLOGY_ACTIVE_TTL)


    @staticmethod
    def _log(message):
        try:
            xbmc.log('[plugin.video.filmix][lite prewarm] {0}'.format(message), xbmc.LOGINFO)
        except Exception:
            try:
                plugin.log_debug('Filmix lite prewarm: {0}'.format(message))
            except Exception:
                pass

    @staticmethod
    def _now():
        try:
            return int(time.time())
        except Exception:
            return 0

    @classmethod
    def make_task_key(cls, section, page='1', filters=''):
        return FilmixCache.make_catalog_cache_key(section, page or '1', filters or '')

    @classmethod
    def parse_task(cls, task):
        if isinstance(task, dict):
            return {
                'section': str(task.get('section') or ''),
                'page': str(task.get('page') or '1'),
                'filters': str(task.get('filters') or ''),
            }
        value = str(task or '')
        parts = value.split('|', 2)
        if len(parts) == 3:
            return {'section': parts[0], 'page': parts[1] or '1', 'filters': parts[2] or ''}
        return {'section': value, 'page': '1', 'filters': ''}

    @classmethod
    def filter_availability_flag_for(cls, section, filters):
        key = cls.make_task_key(section or '', '1', filters or '')
        return cls.FILTER_AVAIL_STATE_PREFIX + cls._probe_digest(key)

    @classmethod
    def _normalize_filter_availability_task(cls, task):
        if not isinstance(task, dict):
            task = cls.parse_task(task)
        section = str(task.get('section') or '')
        filters = str(task.get('filters') or '')
        if not section or not filters:
            return None
        if not cls.is_cacheable_catalog(section, '1', filters):
            return None
        return {
            'section': section,
            'page': '1',
            'filters': filters,
            'kind': str(task.get('kind') or ''),
            'label': str(task.get('label') or ''),
        }

    def _read_filter_availability_queue(self):
        # One-time migration from the old read/modify/write JSON flag.  Jobs are
        # idempotent by identity, so multiple Kodi processes can safely attempt it.
        try:
            row = self.cache.get_control_flag(self.FILTER_AVAIL_QUEUE_FLAG)
        except Exception:
            row = None
        value = (row or {}).get('flag_value') or ''
        if value:
            try:
                legacy = json.loads(value)
                if not isinstance(legacy, list):
                    legacy = []
            except Exception:
                legacy = []
            for raw in legacy:
                task = self._normalize_filter_availability_task(raw)
                if not task:
                    continue
                key = self.make_task_key(task.get('section'), '1', task.get('filters'))
                try:
                    self.cache.enqueue_job(self.JOB_FILTER_AVAIL, key, task)
                except Exception:
                    pass
            try:
                self.cache.clear_control_flag(self.FILTER_AVAIL_QUEUE_FLAG)
            except Exception:
                pass

        try:
            rows = self.cache.list_jobs(self.JOB_FILTER_AVAIL, states=('queued', 'leased'),
                                        limit=self.FILTER_AVAIL_QUEUE_MAX)
        except Exception:
            rows = []
        result = []
        seen = set()
        for row in rows or []:
            item = self.cache.job_payload(row, {})
            task = self._normalize_filter_availability_task(item)
            if not task:
                continue
            key = self.make_task_key(task.get('section'), '1', task.get('filters'))
            if key in seen:
                continue
            seen.add(key)
            result.append(task)
        return result


    def request_filter_availability_checks(self, tasks, force=False):
        if not self.is_cache_prewarm_enabled():
            self._cache_prewarm_disabled_log('skip filter availability queue')
            return False
        now = self._now()
        existing = self._read_filter_availability_queue()
        queued_keys = set([self.make_task_key(t.get('section'), '1', t.get('filters')) for t in existing])
        added = 0
        for raw in tasks or []:
            task = self._normalize_filter_availability_task(raw)
            if not task:
                continue
            key = self.make_task_key(task.get('section'), '1', task.get('filters'))
            if key in queued_keys and not force:
                continue
            if not force:
                try:
                    state_row = self.cache.get_control_flag(self.filter_availability_flag_for(task.get('section'), task.get('filters')))
                    if state_row is not None:
                        age = now - int(state_row.get('updated_ts') or 0)
                        retry_wait = int(self.FILTER_AVAIL_RECHECK_INTERVAL)
                        try:
                            state = json.loads((state_row or {}).get('flag_value') or '')
                            if isinstance(state, dict):
                                empty_count = int(state.get('empty_count') or 0)
                                if (state.get('status') == 'empty') and (0 < empty_count < int(self.FILTER_AVAIL_EMPTY_CONFIRMATIONS)):
                                    retry_wait = int(self.FILTER_AVAIL_EMPTY_CONFIRM_RETRY_INTERVAL)
                        except Exception:
                            pass
                        if age < retry_wait:
                            continue
                except Exception:
                    pass
            try:
                self.cache.enqueue_job(self.JOB_FILTER_AVAIL, key, task,
                                       priority=(100 if force else 10), due_ts=0)
            except Exception:
                continue
            queued_keys.add(key)
            added += 1
        if added:
            try:
                self.cache.prune_jobs(self.JOB_FILTER_AVAIL, self.FILTER_AVAIL_QUEUE_MAX,
                                      states=('queued',))
            except Exception:
                pass
            total = self.cache.count_jobs(self.JOB_FILTER_AVAIL, states=('queued', 'leased'))
            self._log('filter availability queued: added={0} total={1} priority={2}'.format(added, total, int(bool(force))))
            return True
        return False

    def _consume_filter_availability_batch(self, limit=None):
        limit = int(limit or self.FILTER_AVAIL_BATCH_SIZE)
        self._read_filter_availability_queue()  # migrate legacy flag first
        owner = 'filter:{0}:{1}'.format(int(time.time()), id(self))
        claims = self.cache.claim_jobs(self.JOB_FILTER_AVAIL, limit=limit,
                                      lease_seconds=self.JOB_LEASE_SECONDS, owner=owner)
        self._active_filter_claims = claims
        self._active_filter_owner = owner
        return [self.cache.job_payload(row, {}) for row in claims]

    def _get_filter_availability_state(self, section, filters):
        try:
            row = self.cache.get_control_flag(self.filter_availability_flag_for(section, filters))
        except Exception:
            row = None
        value = (row or {}).get('flag_value') or ''
        if not value:
            return None
        try:
            data = json.loads(value)
            if isinstance(data, dict):
                data['_updated_ts'] = int((row or {}).get('updated_ts') or 0)
                return data
        except Exception:
            pass
        return None

    def requeue_pending_filter_confirmations(self, max_tasks=120):
        if not self.is_cache_prewarm_enabled():
            self._cache_prewarm_disabled_log('skip filter availability retry')
            return False
        # 2.2.31: after an empty first pass, schedule a second confirmation
        # quickly. Non-empty rows keep the normal 24h recheck interval.
        now = self._now()
        tasks = []
        try:
            rows = self.cache.list_control_flags(self.FILTER_AVAIL_STATE_PREFIX)
        except Exception:
            rows = []
        for row in rows or []:
            if len(tasks) >= int(max_tasks or 120):
                break
            try:
                data = json.loads((row or {}).get('flag_value') or '')
            except Exception:
                data = None
            if not isinstance(data, dict):
                continue
            try:
                empty_count = int(data.get('empty_count') or 0)
            except Exception:
                empty_count = 0
            if not (0 < empty_count < int(self.FILTER_AVAIL_EMPTY_CONFIRMATIONS)):
                continue
            if bool(data.get('hide')):
                continue
            try:
                age = now - int((row or {}).get('updated_ts') or data.get('checked_ts') or 0)
            except Exception:
                age = int(self.FILTER_AVAIL_EMPTY_CONFIRM_RETRY_INTERVAL)
            if age < int(self.FILTER_AVAIL_EMPTY_CONFIRM_RETRY_INTERVAL):
                continue
            task = self._normalize_filter_availability_task({
                'section': data.get('section') or '',
                'page': '1',
                'filters': data.get('filters') or '',
                'kind': data.get('kind') or '',
                'label': data.get('label') or '',
            })
            if task:
                tasks.append(task)
        if tasks:
            ok = self.request_filter_availability_checks(tasks, force=True)
            try:
                self._log('filter availability confirm retry queued: pending={0} queued={1}'.format(len(tasks), int(bool(ok))))
            except Exception:
                pass
            return ok
        return False

    def _set_filter_availability_state(self, task, item_count=None, error=None):
        task = self._normalize_filter_availability_task(task)
        if not task:
            return False
        section = task.get('section') or ''
        filters = task.get('filters') or ''
        previous = self._get_filter_availability_state(section, filters) or {}
        now = self._now()
        empty_count = int(previous.get('empty_count') or 0)
        if error:
            payload = {
                'section': section,
                'filters': filters,
                'kind': task.get('kind') or previous.get('kind') or '',
                'label': task.get('label') or previous.get('label') or '',
                'status': 'error',
                'item_count': int(previous.get('item_count') or 0),
                'empty_count': empty_count,
                'hide': bool(previous.get('hide') and empty_count >= int(self.FILTER_AVAIL_EMPTY_CONFIRMATIONS)),
                'last_error': str(error)[:180],
                'checked_ts': now,
            }
        else:
            count = int(item_count or 0)
            if count > 0:
                empty_count = 0
                status = 'nonempty'
                hide = False
            else:
                empty_count += 1
                status = 'empty'
                hide = empty_count >= int(self.FILTER_AVAIL_EMPTY_CONFIRMATIONS)
            payload = {
                'section': section,
                'filters': filters,
                'kind': task.get('kind') or previous.get('kind') or '',
                'label': task.get('label') or previous.get('label') or '',
                'status': status,
                'item_count': count,
                'empty_count': empty_count,
                'hide': bool(hide),
                'checked_ts': now,
            }
        try:
            self.cache.set_control_flag(self.filter_availability_flag_for(section, filters), json.dumps(payload, ensure_ascii=False, sort_keys=True))
            return True
        except Exception:
            return False

    def check_filter_availability_batch(self, tasks, silent=True):
        api = Filmix(background=True)
        checked = 0
        nonempty = 0
        empty = 0
        failed = 0
        hidden = 0
        retry_empty = []
        for task in tasks or []:
            task = self._normalize_filter_availability_task(task)
            if not task:
                continue
            try:
                section_item = self._section_item(task.get('section'))
                if not section_item or not section_item.get('id'):
                    raise FilmixError('missing section item for availability check: {0}'.format(task.get('section')))
                items = api.catalog('1', section_item.get('id'), task.get('filters'))
                count = len(items or [])
                checksum = self._checksum(items)
                # Availability probes must never replace a previously valid
                # filtered catalog with a transient empty API response. A
                # confirmed empty state can hide the filter, but cached content
                # remains available until a later successful refresh replaces it.
                if count > 0:
                    try:
                        self.cache.set_catalog_cache(task.get('section'), '1', task.get('filters'), items, checksum)
                    except Exception:
                        pass
                self._set_filter_availability_state(task, item_count=count)
                checked += 1
                if count > 0:
                    nonempty += 1
                else:
                    empty += 1
                    state = self._get_filter_availability_state(task.get('section'), task.get('filters')) or {}
                    if state.get('hide'):
                        hidden += 1
                    else:
                        try:
                            if int(state.get('empty_count') or 0) < int(self.FILTER_AVAIL_EMPTY_CONFIRMATIONS):
                                retry_empty.append(task)
                        except Exception:
                            pass
            except (FilmixError, simplemedia.WebClientError) as e:
                failed += 1
                self._set_filter_availability_state(task, error=e)
                if not silent:
                    raise
            except Exception as e:
                failed += 1
                self._set_filter_availability_state(task, error=e)
                if not silent:
                    raise
        if retry_empty:
            # The service requeues first-pass empty probes only after
            # FILTER_AVAIL_EMPTY_CONFIRM_RETRY_INTERVAL. Do not immediately
            # repeat the same request and hide a filter on two transient empty
            # responses seconds apart.
            self._log('filter availability confirmation deferred: pending={0}'.format(len(retry_empty)))
        self._log('filter availability done: batch={0} checked={1} nonempty={2} empty={3} hidden={4} failed={5} retry_empty={6}'.format(
            len(tasks or []), checked, nonempty, empty, hidden, failed, len(retry_empty)))
        return {'checked': checked, 'nonempty': nonempty, 'empty': empty, 'hidden': hidden, 'failed': failed, 'retry_empty': len(retry_empty)}

    def tick_filter_availability(self, limit=None):
        if not self.is_cache_prewarm_enabled():
            self._cache_prewarm_disabled_log('skip filter availability tick')
            return False
        if self.__class__._filter_avail_thread is not None and self.__class__._filter_avail_thread.is_alive():
            return False
        try:
            busy_row = self.cache.get_control_flag(self.BUSY_FLAG)
            if busy_row:
                try:
                    busy_age = self._now() - int((busy_row or {}).get('updated_ts') or 0)
                except Exception:
                    busy_age = 0
                # 2.2.31: do not let a stale prewarm busy flag block the
                # genre/country availability queue forever. A live prewarm thread
                # still wins; only stale flags are cleared.
                if busy_age > 180:
                    try:
                        self.cache.clear_control_flag(self.BUSY_FLAG)
                    except Exception:
                        pass
                    self._log('filter availability cleared stale prewarm busy flag age={0}'.format(busy_age))
                else:
                    return False
        except Exception:
            pass
        batch = self._consume_filter_availability_batch(limit or self.FILTER_AVAIL_BATCH_SIZE)
        if not batch:
            return False
        claims = list(getattr(self, '_active_filter_claims', []) or [])
        owner = str(getattr(self, '_active_filter_owner', '') or '')
        self._log('filter availability start: batch={0}'.format(len(batch)))

        def _runner():
            worker = FilmixPrewarm(self.addon)
            try:
                worker.cache.set_control_flag(self.FILTER_AVAIL_BUSY_FLAG, '1')
                worker.check_filter_availability_batch(batch, silent=True)
                for claim in claims:
                    try:
                        worker.cache.ack_job(self.JOB_FILTER_AVAIL, claim.get('identity'), owner=owner)
                    except Exception:
                        pass
            except Exception as e:
                for claim in claims:
                    try:
                        worker.cache.retry_job(self.JOB_FILTER_AVAIL, claim.get('identity'),
                                               delay_seconds=60, error=e, owner=owner)
                    except Exception:
                        pass
                raise
            finally:
                try:
                    worker.cache.clear_control_flag(self.FILTER_AVAIL_BUSY_FLAG)
                except Exception:
                    pass
                try:
                    worker.cache.close()
                except Exception:
                    pass

        t = threading.Thread(target=_runner)
        t.daemon = True
        self.__class__._filter_avail_thread = t
        try:
            t.start()
        except Exception:
            self.__class__._filter_avail_thread = None
            for claim in claims:
                try:
                    self.cache.release_job(self.JOB_FILTER_AVAIL, claim.get('identity'), owner=owner)
                except Exception:
                    pass
            raise
        return True

    @classmethod
    def is_cacheable_catalog(cls, section, page='1', filters=''):
        if not cls.is_cache_prewarm_enabled():
            return False
        if str(page or '1') != '1':
            return False
        filters = filters or ''
        if filters:
            # Custom-filter widgets for Movies/TV only. They are not all globally
            # prewarmed; service updates Russia/Serbia and active widget keys.
            return section in cls.GENRE_SECTIONS
        return section in cls.MAIN_SECTIONS or section in cls.PERSONAL_SECTIONS

    @staticmethod
    def _checksum(items):
        try:
            payload = json.dumps(items or [], ensure_ascii=False, sort_keys=True)
        except Exception:
            payload = repr(items)
        return hashlib.md5(payload.encode('utf-8')).hexdigest()

    @staticmethod
    def _is_logged_in():
        try:
            return bool(plugin.get_setting('user_login') or plugin.get_setting('user_dev_token'))
        except Exception:
            return False

    @staticmethod
    def _normalize_filter_label(label):
        return _normalize_filter_label(label)

    @classmethod
    def _is_blocked_custom_filter_label(cls, label):
        return _is_blocked_custom_filter_label(label)

    @classmethod
    def _find_filter_ids(cls, values, aliases):
        return _find_filter_ids(values, aliases)

    @classmethod
    def _build_custom_genre_filters(cls):
        # Internal lists inside every genre are no longer globally prewarmed.
        # Keep this helper only for explicit force/debug paths; Russia/Serbia
        # moved from Genres to Countries.
        categories_values = Filters._get_filter_values('categories')
        result = []
        for entry in cls.CUSTOM_GENRES:
            filter_ids = cls._find_filter_ids(categories_values, entry.get('categories'))
            unique_ids = []
            for value in filter_ids:
                if value not in unique_ids:
                    unique_ids.append(value)
            if unique_ids:
                result.append('-'.join(unique_ids))
        return result

    @classmethod
    def _build_country_filters(cls):
        countries_values = Filters._get_filter_values('countries')
        result = []
        for entry in cls.CUSTOM_COUNTRIES:
            filter_ids = cls._find_filter_ids(countries_values, entry.get('countries'))
            unique_ids = []
            for value in filter_ids:
                if value not in unique_ids:
                    unique_ids.append(value)
            if unique_ids:
                result.append({'label': entry['label'], 'filters': '-'.join(unique_ids)})
        return result

    def warm_filter_indexes(self, force=False, reason='tick'):
        if not self.is_cache_prewarm_enabled():
            self._cache_prewarm_disabled_log('skip filter index warm reason={0}'.format(reason))
            return []
        # 2.2.21 INDEX_THROTTLE:
        # categories/countries are only index directories, not widget result lists.
        # Do not hit/rebuild them on every service tick or every exact widget refresh.
        # Warm them on service start, then at most once per hour; manual opening of
        # Genres/Countries still calls Filters._get_filter_values() on demand.
        now = self._now()
        if not force:
            try:
                row = self.cache.get_control_flag(self.FILTER_INDEX_LAST_FLAG)
                if row is not None:
                    age = now - int(row.get('updated_ts') or 0)
                    if age < int(self.FILTER_INDEX_WARM_INTERVAL):
                        return []
            except Exception:
                pass

        warmed = []
        ok_count = 0
        for filter_id in self.FILTER_INDEXES_TO_WARM:
            try:
                values = Filters._get_filter_values(filter_id)
                warmed.append('{0}:{1}'.format(filter_id, len(values or [])))
                ok_count += 1
            except Exception:
                warmed.append('{0}:err'.format(filter_id))
        try:
            # Back off after an attempt as well, otherwise a temporary API issue can
            # cause a retry storm every minute. A manual section open still works.
            self.cache.set_control_flag(self.FILTER_INDEX_LAST_FLAG, str(reason or 'tick'))
        except Exception:
            pass
        if warmed:
            self._log('filter indexes warmed: {0} reason={1} force={2}'.format(', '.join(warmed), reason, int(bool(force))))
        return warmed

    @classmethod
    def _probe_digest(cls, value):
        try:
            return hashlib.md5(str(value).encode('utf-8')).hexdigest()[:16]
        except Exception:
            try:
                return str(abs(hash(str(value))))[:16]
            except Exception:
                return 'unknown'


    @classmethod
    def _stale_fail_flag_for_key(cls, cache_key):
        return cls.STALE_FAIL_PREFIX + cls._probe_digest(cache_key)

    def _mark_task_success(self, cache_key):
        try:
            self.cache.clear_control_flag(self._stale_fail_flag_for_key(cache_key))
        except Exception:
            pass

    def _mark_task_failure(self, cache_key, error=''):
        try:
            self.cache.set_control_flag(self._stale_fail_flag_for_key(cache_key), str(error or 'failed')[:180])
        except Exception:
            pass

    def _task_failure_backoff_active(self, cache_key):
        try:
            row = self.cache.get_control_flag(self._stale_fail_flag_for_key(cache_key))
            if row is None:
                return False
            age = self._now() - int(row.get('updated_ts') or 0)
            return age < int(self.STALE_FAIL_BACKOFF)
        except Exception:
            return False


    @classmethod
    def enabled_sections(cls, include_genres=False, include_personal=True):
        tasks = []

        for section in cls.MAIN_SECTIONS:
            tasks.append(cls.make_task_key(section, '1', ''))
        # личные разделы - только со входом; проход tick() их не берёт, у них
        # свой tick_personal_sections() (21.11.2026)
        if include_personal and cls._is_logged_in():
            for section in cls.PERSONAL_SECTIONS:
                tasks.append(cls.make_task_key(section, '1', ''))

        # Do NOT prewarm every internal genre/country list anymore. Keep only
        # Russia/Serbia country widgets hot for movies and TV series.
        try:
            for country in cls._build_country_filters():
                if country.get('label') in ('Россия', 'Сербия'):
                    tasks.append(cls.make_task_key('movies', '1', country.get('filters') or ''))
                    tasks.append(cls.make_task_key('serials', '1', country.get('filters') or ''))
        except Exception:
            pass

        if include_genres:
            # Explicit force/debug mode only. Startup/tick uses active widget registry.
            try:
                genre_filters = cls._build_custom_genre_filters()
            except Exception:
                genre_filters = []
            for filters in genre_filters:
                for section in cls.GENRE_SECTIONS:
                    tasks.append(cls.make_task_key(section, '1', filters))

        result = []
        seen = set()
        for task in tasks:
            if task and task not in seen:
                seen.add(task)
                result.append(task)
        return result

    @classmethod
    def startup_sections(cls):
        return cls.enabled_sections(include_genres=False)

    @classmethod
    def max_age_for_catalog(cls, section, filters=''):
        if filters:
            return cls.CATALOG_GENRE_MAX_AGE
        if section in cls.PERSONAL_SECTIONS:
            return cls.CATALOG_PERSONAL_MAX_AGE
        return cls.CATALOG_MAIN_MAX_AGE

    @classmethod
    def is_catalog_stale(cls, cached, section, filters=''):
        if not cached:
            return True
        try:
            age = cls._now() - int(cached.get('updated_ts') or 0)
        except Exception:
            return True
        return age > cls.max_age_for_catalog(section, filters)

    @staticmethod
    def _section_item(section):
        try:
            return Utilities.get_section_item(section)
        except Exception:
            return None


    def fetch_task(self, task):
        task = self.parse_task(task)
        section = task['section']
        page = task['page'] or '1'
        filters = task['filters'] or ''
        api = Filmix(background=True)

        if section == 'favorites':
            return api.favourites(page)
        if section == 'deferred':
            return api.deferred(page)
        if section == 'popular':
            return api.popular(page)
        if section == 'top_views':
            return api.top_views(page)

        section_item = self._section_item(section)
        if not section_item or not section_item.get('id'):
            return []
        return api.catalog(page, section_item['id'], filters)


    def refresh_sections(self, sections=None, force=False, silent=True):
        if not self.is_cache_prewarm_enabled():
            self._cache_prewarm_disabled_log('skip refresh_sections')
            return []
        sections = list(sections or self.startup_sections())
        try:
            self.warm_filter_indexes(force=False, reason='refresh_sections')
        except Exception:
            pass
        total = 0
        skipped = 0
        unchanged = 0
        touched = 0
        failed = 0
        refreshed = []
        started = time.time()
        for raw_task in sections:
            task = self.parse_task(raw_task)
            section = task['section']
            page = task['page'] or '1'
            filters = task['filters'] or ''
            cache_key = self.make_task_key(section, page, filters)
            if not self.is_cacheable_catalog(section, page, filters):
                skipped += 1
                continue
            total += 1
            try:
                cached = self.cache.get_any_catalog_cache(section, page, filters)
                items = self.fetch_task(task)
                checksum = self._checksum(items)
                if force or not cached or cached.get('checksum') != checksum:
                    self.cache.set_catalog_cache(section, page, filters, items, checksum)
                    refreshed.append(cache_key)
                else:
                    # 2.2.21 STALE_TOUCH:
                    # A successful check with the same checksum must still refresh
                    # updated_ts. Older builds left the old timestamp untouched, so the
                    # same stale cache key was fetched again every service tick.
                    self.cache.set_catalog_cache(section, page, filters, items, checksum)
                    unchanged += 1
                    touched += 1
                self._mark_task_success(cache_key)
            except (FilmixError, simplemedia.WebClientError) as e:
                failed += 1
                self._mark_task_failure(cache_key, e)
                if not silent:
                    raise
                self._log('failed {0}: {1}'.format(raw_task, e))
            except Exception as e:
                failed += 1
                self._mark_task_failure(cache_key, e)
                if not silent:
                    raise
                self._log('error {0}: {1}'.format(raw_task, e))
        try:
            elapsed = time.time() - started
        except Exception:
            elapsed = 0
        self._log('round done: total={0}, updated={1}, unchanged={2}, touched={3}, skipped={4}, failed={5}, force={6}, elapsed={7:.1f}s'.format(
            total, len(refreshed), unchanged, touched, skipped, failed, bool(force), elapsed))
        return refreshed


    def _request_flag_key(cls, task_key):
        try:
            digest = hashlib.md5(str(task_key).encode('utf-8')).hexdigest()[:16]
        except Exception:
            digest = str(abs(hash(str(task_key))))[:16]
        return cls.REQUEST_FLAG_PREFIX + digest

    def _can_request_task_refresh(self, task_key):
        flag_key = self._request_flag_key(task_key)
        now = self._now()
        try:
            row = self.cache.get_control_flag(flag_key)
            if row is not None:
                age = now - int(row.get('updated_ts') or 0)
                if age < self.REQUEST_THROTTLE:
                    return False
        except Exception:
            pass
        try:
            self.cache.set_control_flag(flag_key, '1')
        except Exception:
            pass
        return True

    def request_refresh(self, sections=None):
        if not self.is_cache_prewarm_enabled():
            self._cache_prewarm_disabled_log('skip request_refresh')
            return False
        if sections is None:
            sections = self.startup_sections()
        task_keys = []
        for s in sections or []:
            if not s:
                continue
            task_key = s if isinstance(s, str) else self.make_task_key(**self.parse_task(s))
            if task_key and task_key not in task_keys and self._can_request_task_refresh(task_key):
                task_keys.append(task_key)
        if not task_keys:
            return
        queued = 0
        for task_key in task_keys:
            try:
                if self.cache.enqueue_job(self.JOB_FORCE, task_key,
                                          {'task': task_key}, priority=100):
                    queued += 1
            except Exception:
                pass
        return bool(queued)

    def _consume_force_sections(self, limit=None):
        if not self.is_cache_prewarm_enabled():
            try:
                self.cache.clear_control_flag(self.FORCE_FLAG)
            except Exception:
                pass
            return None
        # Migrate the previous single-value flag without losing a producer that
        # writes while a consumer is running.
        try:
            row = self.cache.get_control_flag(self.FORCE_FLAG)
        except Exception:
            row = None
        if row:
            value = row.get('flag_value') or ''
            sections = self.startup_sections() if value in ['', '1', 'all'] else [
                s.strip() for s in value.split(',') if s.strip()]
            for task_key in sections:
                try:
                    self.cache.enqueue_job(self.JOB_FORCE, task_key, {'task': task_key}, priority=100)
                except Exception:
                    pass
            try:
                self.cache.clear_control_flag(self.FORCE_FLAG)
            except Exception:
                pass
        owner = 'force:{0}:{1}'.format(int(time.time()), id(self))
        claims = self.cache.claim_jobs(self.JOB_FORCE, limit=int(limit or self.PREWARM_BATCH_SIZE),
                                      lease_seconds=self.JOB_LEASE_SECONDS, owner=owner)
        if not claims:
            return None
        self._active_force_claims = claims
        self._active_force_owner = owner
        result = []
        for claim in claims:
            payload = self.cache.job_payload(claim, {})
            task = payload.get('task') if isinstance(payload, dict) else None
            task = task or claim.get('identity')
            if task:
                result.append(str(task))
        return result or None


    @staticmethod
    def _norm_post_id(post_id):
        if post_id in [None, '', 'None']:
            return ''
        try:
            return str(post_id).strip()
        except Exception:
            return ''


    def request_post_details(self, post_ids, reason='listing'):
        """Fetch our OWN post data for ids we have never cached.

        Source-only metadata mode switches off `request_metadata_enrich`, and
        that was read too widely: it means "do not enrich from TMDb", not "do
        not fetch our own post". The result was visible on the boxes - the
        newest films on page one of the catalogue had no description anywhere,
        because `short_story` only ever arrives with Filmix.post, and nobody
        asked for it until the user opened the film. The owner reported exactly
        that: «Игра на риск без плота, грозовой шторм тоже, и запретный город».

        Only ids missing from `posts` are queued, so a refreshed page normally
        costs a handful of requests, and the existing player-topology worker
        does the fetching - it already calls Filmix.post and stores the details.
        """
        ids = []
        seen = set()
        for raw in post_ids or []:
            if isinstance(raw, dict):
                raw = raw.get('id')
            pid = self._norm_post_id(raw)
            if pid and pid not in seen:
                seen.add(pid)
                ids.append(pid)
        if not ids:
            return 0
        listed = {}
        for raw in post_ids or []:
            if isinstance(raw, dict):
                listed[self._norm_post_id(raw.get('id'))] = raw
        missing = []
        behind = 0
        # «только трейлер» со сведениями старше шести часов (cache.TRAILER_RECHECK_SECONDS): вышел ли
        # фильм. Без этого они не обновлялись вовсе - пост в кэше есть, missing его не берёт
        # («Вински и тайна Перевёрнутого города» - 102 дня, .20, 25.11.2026); вышедший фильм
        # появляется в списках в пределах шести часов, а не трёх суток.
        try:
            stale_trailers = self.cache.trailer_only_ids(ids, stale=True)
        except Exception:
            stale_trailers = set()
        for pid in ids:
            if pid in stale_trailers:
                missing.append(pid)
                behind += 1
                continue
            try:
                details = self.cache.get_post_details(pid) or {}
                if not details:
                    missing.append(pid)
                elif self._listing_ahead_of_playlist(listed.get(pid), details):
                    missing.append(pid)
                    behind += 1
            except Exception:
                continue
        if not missing:
            return 0
        try:
            queued = set([self._norm_post_id(row.get('identity')) for row in
                          self.cache.list_jobs(self.JOB_POST_DETAILS,
                                               states=('queued', 'leased'))])
        except Exception:
            queued = set()
        added = 0
        for index, pid in enumerate(missing):
            if pid in queued:
                continue
            try:
                # Ahead of ordinary topology refreshes: a row with no
                # description is on screen right now.
                self.cache.enqueue_job(self.JOB_POST_DETAILS, pid,
                                       {'post_id': pid}, priority=max(320, 400 - index))
                added += 1
            except Exception:
                continue
        if added:
            self._log('post details queued reason={0} missing={1} behind={2} queued={3}'.format(
                reason, len(missing) - behind, behind, added))
        return added

    @staticmethod
    def _listing_ahead_of_playlist(item, details):
        """Страница каталога знает серию, которой нет в сохранённом плейлисте.

        16.10.2026 на .20 «Война» стояла в «Все» с галочкой «всё просмотрено»:
        в кеше плейлист был s1[ColdFilm:1], а на сайте уже три серии - и строка
        страницы так и говорила, last_episode s1e3. Плейлист обновлялся только
        при входе в сериал (POST_PLAYLIST_REFRESH cached=s1[ColdFilm:1]
        api=s1[ColdFilm:3,...]), а до того и хаб, и наши списки считали
        «просмотрено 1 из 1». Владелец увидел галочку, внутри - две новые серии.

        Пустой плейлист сюда не относится: такой пост перечитывался бы каждые
        пять минут без толку.
        """
        last = item.get('last_episode') if isinstance(item, dict) else None
        if not isinstance(last, dict):
            return False
        try:
            season = str(int(last.get('season') or 0))
            episode = str(int(last.get('episode') or 0))
        except (TypeError, ValueError):
            return False
        if season == '0' or episode == '0':
            return False
        playlist = ((details or {}).get('player_links') or {}).get('playlist')
        if not isinstance(playlist, dict) or not playlist:
            return False
        # Два вида плейлиста: сезон -> озвучка -> серии, или сразу озвучка ->
        # серии (у сериалов без сезонов, см. FilmixNavigation._get_season_stats).
        branch = playlist.get(season)
        if isinstance(branch, dict) and branch and all(isinstance(v, dict) for v in branch.values()):
            voices = branch.values()
        elif season == '1':
            voices = [v for v in playlist.values() if isinstance(v, dict)]
        else:
            return True
        for voice in voices:
            if isinstance(voice, dict) and episode in voice:
                return False
        return True

    MAIN_PAGE_SECTIONS = ('movies', 'serials', 'multfilms', 'multserials')

    # ---- сериалы виджетов главной: открываются без ожидания сети -----------
    #
    # Владелец 17.10.2026: «списки эпизодов сериалов, находящихся в виджетах
    # главного экрана, можно как-то закешировать, чтобы быстро открывались, не
    # теряя актуальности серий, просмотра». Замер на .30: первое открытие 2-4 с,
    # повторное 1.2 с; из 1.41 с внутри дополнения 0.36 с - плейлист с сайта,
    # 0.30 с - сверка номера TMDb, 0.47 с - описания серий сезона с TMDb.
    #
    # Сама строка по-прежнему собирается при открытии: просмотр и точки
    # продолжения берутся из Kodi живьём. Заранее делается только сетевая часть,
    # и только для сериалов, которые скин перечислил в home_series.json.
    HOME_SERIES_FILE = 'special://profile/addon_data/skin.sublime/home_series.json'
    # Меньше FilmixCatalogs.TRUSTED_PLAYER_TTL (1800), чтобы при открытии
    # плейлист всегда был в пределах доверия.
    HOME_WARM_PLAYLIST_AGE = 1500
    HOME_WARM_TMDB_AGE = 24 * 3600
    HOME_WARM_TMDB_FLAG = 'home_warm_tmdb|'
    # После ошибки сайта сериал пропускается на час. Первый запуск на .30
    # 17.10.2026: пост 187097 отвечал 404, и прогрев раз в 15 с спрашивал только
    # его - очередь дальше не шла.
    HOME_WARM_FAIL_FLAG = 'home_warm_fail|'
    HOME_WARM_FAIL_BACKOFF = 3600
    _HOME_SERIES = {'mtime': 0.0, 'ids': []}

    @classmethod
    def home_series_ids(cls):
        """Номера постов из home_series.json скина, в порядке важности."""
        try:
            import os
            import xbmcvfs
            path = xbmcvfs.translatePath(cls.HOME_SERIES_FILE)
            mtime = os.path.getmtime(path)
        except Exception:
            return []
        if mtime != cls._HOME_SERIES['mtime']:
            try:
                with open(path, 'r', encoding='utf-8') as handle:
                    payload = json.load(handle)
                ids = [str(x) for x in (payload or {}).get('ids') or [] if str(x).isdigit()]
            except Exception:
                ids = []
            cls._HOME_SERIES.update({'mtime': mtime, 'ids': ids})
        return list(cls._HOME_SERIES['ids'])

    def warm_home_series(self):
        """Один сериал за вызов: что устарело - обновить. True - была работа."""
        ids = self.home_series_ids()
        if not ids:
            return False
        try:
            ages = self.cache.get_post_player_ages_many(ids) or {}
        except Exception:
            ages = {}
        try:
            statuses = self.cache.get_serial_status_many(ids) or {}
        except Exception:
            statuses = {}
        now = time.time()
        for pid in ids:
            try:
                failed = self.cache.get_control_flag(self.HOME_WARM_FAIL_FLAG + pid)
            except Exception:
                failed = None
            if failed and now - int(failed.get('updated_ts') or 0) < self.HOME_WARM_FAIL_BACKOFF:
                continue
            age = ages.get(pid)
            # закрытый сериал («Закрыт», serial_stats.status = 2) новых серий не получит - раз в сутки,
            # как у начатых (STARTED_SERIAL_CLOSED_TTL); идущие - по-прежнему HOME_WARM_PLAYLIST_AGE.
            # Аудит .20 23.11.2026: 128 запросов сайта в час, все «обновлён» без изменений
            closed = str(statuses.get(pid)) == '2'
            playlist_due = age is None or age >= (self.STARTED_SERIAL_CLOSED_TTL if closed
                                                  else self.HOME_WARM_PLAYLIST_AGE)
            row = None
            try:
                row = self.cache.get_control_flag(self.HOME_WARM_TMDB_FLAG + pid)
            except Exception:
                row = None
            tmdb_due = (not row) or now - int((row or {}).get('updated_ts') or 0) >= self.HOME_WARM_TMDB_AGE
            if not (playlist_due or tmdb_due):
                continue
            return self._warm_one_series(pid, playlist_due, tmdb_due)
        return False

    def _warm_one_series(self, pid, playlist_due, tmdb_due):
        from .navigation import FilmixCatalogs
        started = time.time()
        playlist = 'свежий'
        details = self.cache.get_post_details(pid) or {}
        if playlist_due:
            try:
                fresh = Filmix(background=True).post(pid, force_refresh=True)
                if FilmixCatalogs._has_playlist(fresh):
                    details = self.cache.set_post_details(
                        pid, fresh, player_fresh=True, preserve_richer_player=True) or fresh
                    playlist = 'обновлён'
                else:
                    playlist = 'сайт без плейлиста'
                    try:
                        self.cache.set_control_flag(self.HOME_WARM_FAIL_FLAG + pid, 'no playlist')
                    except Exception:
                        pass
            except Exception as e:
                playlist = 'ошибка: {0}'.format(e)
                try:
                    self.cache.set_control_flag(self.HOME_WARM_FAIL_FLAG + pid, str(e)[:200])
                except Exception:
                    pass
        seasons = 0
        if tmdb_due and FilmixCatalogs._has_playlist(details):
            try:
                item = FilmixCatalogs._validate_tv_identity_for_episode_lookup(
                    FilmixCatalogs._merge_resolved_ids_for_episode_lookup(details, self.cache),
                    self.cache, route='home_warm')
                for season in sorted((details.get('player_links') or {}).get('playlist') or {}):
                    if str(season).isdigit():
                        FilmixCatalogs._tmdb_episode_metadata_map(item, season)
                        seasons += 1
                self.cache.set_control_flag(self.HOME_WARM_TMDB_FLAG + pid, '1')
            except Exception as e:
                self._log('home series tmdb warm failed post_id={0}: {1}'.format(pid, e))
        self._log('home series warm post_id={0} playlist={1} tmdb_seasons={2} elapsed={3:.2f}s'.format(
            pid, playlist, seasons, time.time() - started))
        return True

    STARTED_SERIAL_TTL = 60 * 60            # в эфире: новая серия видна в течение часа
    STARTED_SERIAL_CLOSED_TTL = 24 * 60 * 60
    STARTED_SERIAL_BATCH = 5

    def recover_after_outage(self, event):
        """Добрать пропущенное после обрыва связи или смены сервера (server_watch): отложенные
        с растущей паузой задания (до 6 часов после 8 неудач) - сразу, пометки «раздел не
        обновился» - снять, разделы главной - обновить заново. Скин видит смену по epoch в
        servers.json и сам пересобирает полосы."""
        reset = 0
        try:
            cur = self.cache.conn.execute(
                "UPDATE jobs SET due_ts=0, attempts=0, last_error='' WHERE state='queued' AND attempts>0")
            reset = cur.rowcount or 0
        except Exception as e:
            self._log('recover: jobs not reset: {0}'.format(e))
        forced = 0
        for raw_task in self.startup_sections():
            try:
                task = self.parse_task(raw_task)
                key = self.make_task_key(task['section'], task['page'], task['filters'])
                self.cache.clear_control_flag(self._stale_fail_flag_for_key(key))
                self.cache.enqueue_job(self.JOB_FORCE, raw_task, {'task': raw_task}, priority=100)
                forced += 1
            except Exception:
                continue
        self._log('recover after {0}: jobs {1}, sections {2}'.format(event, reset, forced))

    def request_started_serials_refresh(self):
        """Число серий у начатых сериалов - без открытия сериала: в эфире не старше
        часа, завершённые - суток.

        Общее обновление плейлистов выключено по умолчанию (оно держало kodi.bin под
        90 % CPU), и плейлист сериала обновлялся только при его открытии. На .20
        19.11.2026 «Осколки» стояли с 8 сериями вместо 9, «Рейс Каравелла-114» - с 2
        вместо 4: запись лежала с августа. Здесь - только сериалы из истории Kodi
        (есть досмотренная или начатая серия), по несколько за проход, той же узкой
        очередью, что и недостающие записи."""
        import re as _re
        try:
            from . import kodi_state
            rows = kodi_state._load()
        except Exception as e:
            self._log('started serials: history not read: {0}'.format(e))
            return 0
        ids = []
        for path, (playcount, position, _total) in rows.items():
            if playcount <= 0 and position <= 0:
                continue
            hit = _re.search(r'plugin\.video\.filmix/serials/(\d+)-', path)
            if hit and hit.group(1) not in ids:
                ids.append(hit.group(1))
        if not ids:
            return 0
        try:
            ages = self.cache.get_post_player_ages_many(ids)
            queued = set([self._norm_post_id(row.get('identity')) for row in
                          self.cache.list_jobs(self.JOB_POST_DETAILS, states=('queued', 'leased'))])
        except Exception as e:
            self._log('started serials: cache not read: {0}'.format(e))
            return 0
        try:
            statuses = self.cache.get_serial_status_many(ids) or {}
        except Exception:
            statuses = {}

        def _ttl(pid):
            closed = str(statuses.get(pid)) == '2'   # «Закрыт»
            return self.STARTED_SERIAL_CLOSED_TTL if closed else self.STARTED_SERIAL_TTL

        stale = [pid for pid in ids if pid not in queued
                 and (ages.get(pid) is None or ages.get(pid) >= _ttl(pid))]
        stale.sort(key=lambda pid: -(ages.get(pid) or 10 ** 9))
        added = 0
        for pid in stale[:self.STARTED_SERIAL_BATCH]:
            try:
                self.cache.enqueue_job(self.JOB_POST_DETAILS, pid, {'post_id': pid}, priority=300)
                added += 1
            except Exception:
                continue
        if added:
            self._log('started serials queued={0} stale={1}'.format(added, len(stale)))
        return added

    def request_post_details_from_pages(self, sections=None, page='1'):
        """Queue details for posts that sit on our cached pages but not in `posts`.

        Hooking this to the moment a page is written was not enough: that only
        happens when the prewarm decides the page is stale, which on these boxes
        is hours apart - measured, not a single request in three minutes after a
        restart while four films on page one still had no description. This walks
        the pages we already hold, so it does not depend on when they were
        fetched.
        """
        total = 0
        for section in (sections or self.MAIN_PAGE_SECTIONS):
            try:
                cached = self.cache.get_any_catalog_cache(section, page, '')
            except Exception:
                cached = None
            items = (cached or {}).get('items') or []
            if not items:
                continue
            try:
                total += self.request_post_details(items, reason='page:%s' % section)
            except Exception as e:
                self._log('post details sweep failed section={0}: {1}'.format(section, e))
        return total

    def request_player_topology_refresh(self, post_ids):
        if not self.is_cache_prewarm_enabled():
            return False
        ids = []
        seen = set()
        for raw in post_ids or []:
            if isinstance(raw, dict):
                raw = raw.get('id')
            pid = self._norm_post_id(raw)
            if pid and pid not in seen:
                seen.add(pid)
                ids.append(pid)
        if not ids:
            return False
        try:
            existing = set([self._norm_post_id(row.get('identity')) for row in
                            self.cache.list_jobs(self.JOB_PLAYER_TOPOLOGY, states=('queued', 'leased'))])
            added = 0
            for index, pid in enumerate(ids):
                if pid in existing:
                    continue
                priority = max(100, 300 - index)
                self.cache.enqueue_job(self.JOB_PLAYER_TOPOLOGY, pid, {'post_id': pid}, priority=priority)
                added += 1
            self.cache.prune_jobs(self.JOB_PLAYER_TOPOLOGY, self.PLAYER_TOPOLOGY_QUEUE_MAX, states=('queued',))
            return bool(added)
        except Exception as e:
            self._log('player topology queue failed: {0}'.format(e))
            return False


    def notify_player_topology_changed(self, post_id, source='interactive'):
        try:
            self.cache.set_control_flag(self.PLAYER_TOPOLOGY_RECENT_PREFIX + self._norm_post_id(post_id), str(source or 'changed'))
        except Exception:
            pass
        self._log('player topology changed post_id={0} source={1}'.format(post_id, source))
        return True

    def tick_player_topology(self, limit=None, kind=None):
        """Drain one lane of post fetches. `kind` picks the lane: the topology
        refresh, or the missing-post details queued by request_post_details."""
        kind = kind or self.JOB_PLAYER_TOPOLOGY
        if not self.is_cache_prewarm_enabled():
            return False
        if self.__class__._player_topology_thread is not None and self.__class__._player_topology_thread.is_alive():
            return False
        owner = 'player-topology:{0}:{1}'.format(int(time.time()), id(self))
        claims = self.cache.claim_jobs(kind,
                                      limit=int(limit or self.PLAYER_TOPOLOGY_BATCH_SIZE),
                                      lease_seconds=self.JOB_LEASE_SECONDS, owner=owner)
        if not claims:
            return False

        def _runner():
            worker = FilmixPrewarm(self.addon)
            api = Filmix(background=True)
            changed_ids = []
            try:
                for claim in claims:
                    identity = claim.get('identity') or ''
                    payload = worker.cache.job_payload(claim, {})
                    post_id = self._norm_post_id((payload or {}).get('post_id') or identity)
                    try:
                        before = worker.cache.get_post_details(post_id) or {}
                        before_identity = FilmixCache.player_identity(before.get('player_links') or {})
                        fresh = api.post(post_id, force_refresh=True)
                        if not isinstance(fresh, dict):
                            raise FilmixError('empty post payload')
                        playable = FilmixCache._has_playback_data(fresh)
                        if not playable and kind != self.JOB_POST_DETAILS:
                            raise FilmixError('empty player payload')
                        # задание сведений поста: описание нужно и у фильма, у которого на Filmix пока
                        # только трейлер («Чебурашка 3» и др. - без описания в «Новых фильмах»); ссылки
                        # такого поста свежими не считаются (player_fresh), их обновит своя очередь
                        merged = worker.cache.set_post_details(post_id, fresh, player_fresh=playable,
                                                               preserve_richer_player=True)
                        after_identity = FilmixCache.player_identity((merged or {}).get('player_links') or {})
                        if after_identity != before_identity:
                            changed_ids.append(post_id)
                        worker.cache.ack_job(kind, identity, owner=owner)
                        worker._log('player topology refreshed post_id={0} changed={1} playlist={2}'.format(
                            post_id, int(after_identity != before_identity), FilmixCache.playlist_summary(merged)))
                    except Exception as e:
                        attempts = int(claim.get('attempts') or 0) + 1
                        delay = (6 * 60 * 60 if attempts >= 8
                                 else min(3600, self.PLAYER_TOPOLOGY_RETRY * attempts))
                        worker.cache.retry_job(kind, identity,
                                               delay_seconds=delay, error=e, owner=owner)
                        worker._log('player topology refresh failed post_id={0} attempts={1}: {2}'.format(
                            post_id, attempts, e))
                if changed_ids:
                    for post_id in changed_ids:
                        worker.notify_player_topology_changed(post_id, source='background')
            finally:
                try:
                    worker.cache.close()
                except Exception:
                    pass
                self.__class__._player_topology_thread = None

        t = threading.Thread(target=_runner, name='FilmixPlayerTopology')
        try:
            t.daemon = True
        except Exception:
            pass
        self.__class__._player_topology_thread = t
        try:
            t.start()
            return True
        except Exception:
            self.__class__._player_topology_thread = None
            for claim in claims:
                try:
                    self.cache.release_job(kind, claim.get('identity'), owner=owner)
                except Exception:
                    pass
            raise


    @staticmethod
    def _missing_usable_plot(source, resolved_ids):
        # Single source-plot decision path: keep prewarm/navigation/widget
        # behaviour aligned with listitem rendering. Provider overview must not
        # mask a missing Filmix RU source plot.
        try:
            return not bool(_select_plot(source or {}))
        except Exception:
            return False

    @staticmethod
    def _overview_miss_recent(resolved_ids):
        try:
            miss_at = int((resolved_ids or {}).get('_tmdb_overview_miss_at') or 0)
            miss_build = str((resolved_ids or {}).get('_tmdb_overview_miss_build') or '')
            if miss_build != FilmixPrewarm.TMDB_MISS_BUILD:
                return False
            return bool(miss_at and (FilmixCache._ts() - miss_at) < int(FilmixPrewarm.TMDB_MISS_TTL))
        except Exception:
            return False


    def queue_stale_active_player_topologies(self, limit=None, force=False):
        """Поставить в очередь несколько сериалов, чья топология устарела.

        Зовётся из службы (service.py) каждые 15-45 секунд, поэтому важнее
        всего дешевизна: у текущих сериалов TTL 15 минут, у завершённых - шесть
        часов, за один проход в сеть уходит не больше горстки заданий, и обход
        идёт по кругу, чтобы длинный список не голодал.

        Раньше кандидаты брались из снимков виджетов, которые провайдер вёл сам,
        и из реестра открытых окон. И то и другое удалено - виджеты собирает
        скин. Осталось то, что провайдер знает и так: разделы, которые он
        прогревает, и их кеш каталога.
        """
        if not self.is_cache_prewarm_enabled():
            return False
        now = self._now()
        if not force:
            try:
                row = self.cache.get_control_flag(self.PLAYER_TOPOLOGY_DISCOVERY_FLAG)
                if row and (now - int(row.get('updated_ts') or 0)) < int(self.PLAYER_TOPOLOGY_DISCOVERY_INTERVAL):
                    return False
            except Exception:
                pass
        try:
            self.cache.set_control_flag(self.PLAYER_TOPOLOGY_DISCOVERY_FLAG, str(now))
        except Exception:
            pass
        sections = self.startup_sections()
        candidates = []
        seen = set()
        for cache_key in sections:
            try:
                task = self.parse_task(cache_key)
                catalog = self.cache.get_any_catalog_cache(
                    task.get('section'), task.get('page'), task.get('filters'))
                items = (catalog or {}).get('items') or []
            except Exception:
                items = []
            for item in items:
                if not isinstance(item, dict):
                    continue
                pid = self._norm_post_id(item.get('id'))
                if not pid or pid in seen:
                    continue
                try:
                    is_movie = Utilities.is_movie(item)
                except Exception:
                    media_type = str(item.get('mediatype') or item.get('dbtype') or '').lower()
                    is_movie = media_type == 'movie'
                if is_movie:
                    continue
                seen.add(pid)
                candidates.append((pid, item))
        if not candidates:
            return False
        try:
            posts = self.cache.get_post_details_many([pid for pid, _item in candidates])
            ages = self.cache.get_post_player_ages_many([pid for pid, _item in candidates])
        except Exception as e:
            self._log('active topology discovery bulk read failed: {0}'.format(e))
            return False
        stale = []
        for pid, item in candidates:
            info = posts.get(pid) or {}
            playlist = ((info.get('player_links') or {}).get('playlist')
                        if isinstance(info, dict) else None)
            age = ages.get(pid)
            ttl = self._player_topology_ttl_for_item(item, pid)
            if (not isinstance(playlist, dict) or not playlist or age is None or int(age) >= ttl):
                stale.append(pid)
        if not stale:
            return False
        batch_limit = max(1, min(int(limit or self.PLAYER_TOPOLOGY_DISCOVERY_BATCH),
                                 int(self.PLAYER_TOPOLOGY_DISCOVERY_BATCH)))
        cursor_flag = self.PLAYER_TOPOLOGY_CURSOR_PREFIX + 'all'
        try:
            cursor_row = self.cache.get_control_flag(cursor_flag)
            cursor = int((cursor_row or {}).get('flag_value') or 0)
        except Exception:
            cursor = 0
        cursor = cursor % len(stale)
        ordered = stale[cursor:] + stale[:cursor]
        selected = ordered[:batch_limit]
        try:
            self.cache.set_control_flag(cursor_flag, str((cursor + len(selected)) % len(stale)))
        except Exception:
            pass
        added = self.request_player_topology_refresh(selected) if selected else False
        self._log('active topology discovery: sections={0} serials={1} stale={2} selected={3} queued={4}'.format(
            len(sections), len(candidates), len(stale), len(selected), int(bool(added))))
        return bool(added)

    def _stale_tasks(self):
        if not self.is_cache_prewarm_enabled():
            return []
        tasks = []
        source_tasks = []
        for task in self.enabled_sections(include_genres=False, include_personal=False):
            if task and task not in source_tasks:
                source_tasks.append(task)
        for raw_task in source_tasks:
            task = self.parse_task(raw_task)
            cache_key = self.make_task_key(task['section'], task['page'], task['filters'])
            if self._task_failure_backoff_active(cache_key):
                continue
            cached = self.cache.get_any_catalog_cache(task['section'], task['page'], task['filters'])
            if cached is None:
                tasks.append(raw_task)
                continue
            if self.is_catalog_stale(cached, task['section'], task['filters']):
                tasks.append(raw_task)
        return tasks

    def tick_personal_sections(self, limit=None):
        """Refresh favorites/watch-later even while service.py's recent-Home-
        widget guard is pausing the heavier movies/serials/genre prewarm tick.

        That guard (service.py's `_background_pause_reason`) exists so a 4GB
        box never runs full catalog/genre prewarm work while AF3 is actively
        requesting Home widgets, and stays in effect for MAIN_SECTIONS/
        GENRE_SECTIONS - unchanged here. But it means `tick()`, which owns
        favorites/deferred refresh too, can go unrun for as long as Home stays
        on screen, and a favorite added outside Kodi (the Filmix website, a
        second device) has no other signal to reach Kodi with. Measured live
        on <коробка>, 2026-08-16: `/favorites/` kept serving the same
        10-item list 13+ minutes after a new title was favorited on the site,
        because every `Files.GetDirectory` poll counted as fresh Home-widget
        activity and kept re-arming the 180s pause window, so `tick()` never
        ran at all in that time. A single page-1 fetch for one or two personal
        sections is the same class of cost the 2.2.57 metadata-enrich
        exemption already lets through during that same pause.
        """
        if not self.is_cache_prewarm_enabled():
            return False
        logged = self._is_logged_in()
        stale = []
        for section in self.PERSONAL_SECTIONS:
            if section in ('favorites', 'deferred') and not logged:
                continue
            cache_key = self.make_task_key(section, '1', '')
            if self._task_failure_backoff_active(cache_key):
                continue
            cached = self.cache.get_any_catalog_cache(section, '1', '')
            if cached is None or self.is_catalog_stale(cached, section, ''):
                stale.append(cache_key)
        if not stale:
            return False
        if limit:
            stale = stale[:limit]
        self.refresh_sections(stale, force=False, silent=True)
        return True

    def tick(self, max_batch_size=None):
        if not self.is_cache_prewarm_enabled():
            self._cache_prewarm_disabled_log('skip prewarm tick')
            return False
        if self.__class__._thread is not None and self.__class__._thread.is_alive():
            return False
        force_sections = self._consume_force_sections(limit=max_batch_size)
        now = self._now()

        # Verify that previous Container.Refresh really made Kodi/skin re-request
        # refreshed Filmix paths. If not, suppress retry to avoid a Container.Refresh loop.
        # Filmix must never force a full skin reload.
        try:
            if force_sections is None:
                pass
        except Exception:
            pass

        if force_sections is None and (now - int(self.__class__._last_round or 0)) < self.REFRESH_INTERVAL:
            return False
        sections = force_sections if force_sections is not None else self._stale_tasks()
        if not sections:
            self.__class__._last_round = now
            return False
        # 2.2.35 AM8_4GB_GRADUAL_PREWARM:
        # Do not refresh all startup/widget keys at once.  Process a small batch
        # per tick. Forced keys created by stale cache-only routes are preserved
        # and continued on later ticks instead of being dropped.
        try:
            configured_batch = max(1, int(getattr(self, 'PREWARM_BATCH_SIZE', 3) or 3))
            batch_size = max(1, min(configured_batch, int(max_batch_size))) if max_batch_size else configured_batch
        except Exception:
            batch_size = 1 if max_batch_size else 3
        if len(sections) > batch_size:
            remaining = sections[batch_size:]
            self._log('gradual prewarm batch: selected={0}/{1} force={2}'.format(batch_size, len(sections), int(bool(force_sections))))
            if force_sections is not None and remaining:
                for task_key in remaining:
                    try:
                        self.cache.enqueue_job(self.JOB_FORCE, task_key, {'task': task_key}, priority=100)
                    except Exception:
                        pass
            sections = sections[:batch_size]
        self.__class__._last_round = now
        try:
            main_count = 0
            filtered_count = 0
            for raw_task in sections:
                task = self.parse_task(raw_task)
                if task.get('filters'):
                    filtered_count += 1
                else:
                    main_count += 1
            self._log('round start: total={0}, main={1}, filtered_active={2}, force={3}'.format(len(sections), main_count, filtered_count, bool(force_sections)))
        except Exception:
            pass

        force_claims = list(getattr(self, '_active_force_claims', []) or []) if force_sections is not None else []
        force_owner = str(getattr(self, '_active_force_owner', '') or '')

        def _runner():
            worker = FilmixPrewarm(self.addon)
            try:
                worker.cache.set_control_flag(self.BUSY_FLAG,
                                              json.dumps({'owner': force_owner, 'started_ts': FilmixCache._ts()}))
                worker.refresh_sections(sections, force=bool(force_sections), silent=True)
                for claim in force_claims:
                    try:
                        worker.cache.ack_job(self.JOB_FORCE, claim.get('identity'), owner=force_owner)
                    except Exception:
                        pass
            except Exception as e:
                for claim in force_claims:
                    try:
                        worker.cache.retry_job(self.JOB_FORCE, claim.get('identity'),
                                               delay_seconds=60, error=e, owner=force_owner)
                    except Exception:
                        pass
                raise
            finally:
                try:
                    worker.cache.clear_control_flag(self.BUSY_FLAG)
                except Exception:
                    pass
                try:
                    worker.cache.close()
                except Exception:
                    pass

        t = threading.Thread(target=_runner)
        t.daemon = True
        self.__class__._thread = t
        try:
            t.start()
        except Exception:
            self.__class__._thread = None
            for claim in force_claims:
                try:
                    self.cache.release_job(self.JOB_FORCE, claim.get('identity'), owner=force_owner)
                except Exception:
                    pass
            raise
        return True
