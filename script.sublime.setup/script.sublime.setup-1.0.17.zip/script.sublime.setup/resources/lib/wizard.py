# -*- coding: utf-8 -*-
"""Мастер сетапа Sublime для любого Kodi 21/22.

Сам ничего не решает о настройках: качает выпуск установщика sublime-setup (тот же архив, что
ставится с ПК), задаёт его вопросы диалогами Kodi (install.ASKER) и:
  * на CoreELEC/LibreELEC запускает установщик на этой же коробке (install.py --local, через
    systemd-run - вне группы процессов Kodi, иначе остановка Kodi убила бы установщик); твики
    системы делает он, как при установке с ПК;
  * на Windows, Android, macOS и обычном Linux ставит дополнения из репозитория (ТВ-клиент своей
    платформы), а настройки берёт из того же install.write_settings: запись перехватывается
    (_Recorder) и применяется средствами Kodi - настройки Kodi через JSON-RPC, настройки скина
    через Skin.SetString/SetBool, дополнений через xbmcaddon. Системное (службы, autostart,
    профиль железа, Wi-Fi, CEC, advancedsettings под чип) пропускается.
"""
import json
import os
import platform
import re
import shutil
import struct
import sys
import time
import zipfile
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
SETUP_REPO = 'patkino2022/sublime-setup'
REPO_ID = 'repository.sublime'
REPO_URL = 'https://raw.githubusercontent.com/patkino2022/sublime-setup/kodi-repo'
WORK = xbmcvfs.translatePath('special://temp/sublime-setup/')
HOME = xbmcvfs.translatePath('special://home/').replace('\\', '/')
if not HOME.endswith('/'):
    HOME += '/'
DIALOG = xbmcgui.Dialog()
RU = xbmc.getLanguage(xbmc.ISO_639_1) in ('ru', 'uk', 'be', 'sr')


def T(ru, en):
    return ru if RU else en


def log(msg, level=xbmc.LOGINFO):
    xbmc.log('[script.sublime.setup] %s' % msg, level)


def rpc(method, params=None):
    req = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        req['params'] = params
    return json.loads(xbmc.executeJSONRPC(json.dumps(req)))


# ---- платформа --------------------------------------------------------------------------------

def detect():
    """{'os': elec|android|windows|osx|linux, 'arch', 'kodi': 21|22, 'elec_name'}"""
    ver = xbmc.getInfoLabel('System.BuildVersion')
    m = re.match(r'(\d+)', ver)
    kodi = int(m.group(1)) if m else 21
    elec = ''
    try:
        with open('/etc/os-release', encoding='utf-8') as f:
            hit = re.search(r'^NAME="?([^"\n]+)', f.read(), re.M)
            if hit and 'ELEC' in hit.group(1):
                elec = hit.group(1)
    except OSError:
        pass
    bits64 = struct.calcsize('P') == 8
    mach = platform.machine().lower()
    if elec:
        kind = 'elec'
    elif xbmc.getCondVisibility('System.Platform.Android'):
        kind = 'android'
    elif xbmc.getCondVisibility('System.Platform.Windows'):
        kind = 'windows'
    elif xbmc.getCondVisibility('System.Platform.OSX'):
        kind = 'osx'
    else:
        kind = 'linux'
    if 'arm' in mach or 'aarch' in mach:
        arch = 'aarch64' if bits64 else 'armv7'
    else:
        arch = 'x86_64'
    return {'os': kind, 'arch': arch, 'kodi': kodi, 'elec_name': elec, 'version': ver}


def pvr_folder(p):
    """Каталог ТВ-клиента в репозитории (build_dist.kodi_repo): pvr/<платформа>[-kodi21]."""
    if p['os'] in ('elec', 'linux'):
        name = p['arch']
    elif p['os'] == 'android':
        name = 'android-' + p['arch']
    elif p['os'] == 'windows':
        name = 'windows-x86_64'
    else:
        name = 'osx'
    return 'pvr/%s%s' % (name, '-kodi21' if p['kodi'] == 21 else '')


# ---- сеть и файлы -----------------------------------------------------------------------------

UA = {'User-Agent': 'Mozilla/5.0 (Kodi; sublime-setup)'}


_CTX = []


def _ssl_context():
    """Сертификаты - из набора Kodi (тот же cacert.pem, что у его curl), не из хранилища системы:
    в хранилище Windows бывает испорченный сертификат, и Python в Kodi тогда не открывает ни одного
    https-адреса ([ASN1] nested asn1 error, Windows, 23.11.2026). На Android файл Kodi лежит внутри
    apk - тогда копия в самом мастере."""
    if not _CTX:
        import ssl
        here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        for path in (xbmcvfs.translatePath('special://xbmc/system/certs/cacert.pem'),
                     os.path.join(here, 'cacert.pem')):
            if os.path.isfile(path):
                _CTX.append(ssl.create_default_context(cafile=path))
                break
        else:
            _CTX.append(None)
    return _CTX[0]


def _urlopen(url, timeout=60):
    import urllib.request
    return urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout,
                                  context=_ssl_context())


def fetch_text(url):
    """Python напрямую; не вышло (нет сертификатов у Python на Android) - сетью самого Kodi."""
    try:
        with _urlopen(url) as r:
            return r.read().decode('utf-8')
    except Exception as exc:
        log('urllib %s: %s - через Kodi' % (url, exc), xbmc.LOGWARNING)
    f = xbmcvfs.File(url)
    try:
        chunks = []
        while True:
            b = f.readBytes(65536)
            if not b:
                break
            chunks.append(bytes(b))
        return b''.join(chunks).decode('utf-8')
    finally:
        f.close()


def download(url, dest, progress=None):
    if os.path.exists(dest):
        os.remove(dest)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    try:
        with _urlopen(url, 300) as r, open(dest, 'wb') as out:
            shutil.copyfileobj(r, out)
    except Exception as exc:
        log('urllib %s: %s - через Kodi' % (url, exc), xbmc.LOGWARNING)
        if os.path.exists(dest):
            os.remove(dest)
        xbmcvfs.copy(url, dest)
    if not os.path.exists(dest) or not os.path.getsize(dest):
        raise RuntimeError(T('не скачать %s', 'cannot download %s') % url)
    return dest


def latest_installer():
    """(версия, адрес zip) последнего выпуска: номер - из перенаправления страницы releases/latest
    (API GitHub через сеть Kodi отдавал пустой ответ - Windows, 23.11.2026), запасной путь - API."""
    try:
        with _urlopen('https://github.com/%s/releases/latest' % SETUP_REPO) as r:
            tag = r.geturl().rstrip('/').rsplit('/', 1)[-1]
        if re.fullmatch(r'v\d+\.\d+\.\d+', tag):
            ver = tag[1:]
            return ver, 'https://github.com/%s/releases/download/%s/sublime-setup-%s.zip' % (SETUP_REPO, tag, ver)
    except Exception as exc:
        log('releases/latest: %s' % exc, xbmc.LOGWARNING)
    rel = json.loads(fetch_text('https://api.github.com/repos/%s/releases/latest' % SETUP_REPO))
    asset = [x for x in rel.get('assets', []) if x['name'].endswith('.zip')][0]
    return rel['tag_name'].lstrip('v'), asset['browser_download_url']


def fetch_installer(progress):
    """Последний выпуск sublime-setup -> WORK/sublime-setup-<версия>/ (install.py, payload)."""
    ver, url = latest_installer()
    root = os.path.join(WORK, 'sublime-setup-%s' % ver)
    if not os.path.isfile(os.path.join(root, 'install.py')):
        progress.update(5, T('Скачиваю установщик %s', 'Downloading installer %s') % ver)
        zp = download(url, os.path.join(WORK, 'sublime-setup-%s.zip' % ver))
        if os.path.isdir(root):
            shutil.rmtree(root, ignore_errors=True)
        with zipfile.ZipFile(zp) as z:
            z.extractall(WORK)
        os.remove(zp)
    return root


def _et_indent(elem, space='  ', level=0):
    """xml.etree.ElementTree.indent - есть с Python 3.9, а в Kodi 21 на Windows Python 3.8."""
    pad = '\n' + level * space
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = pad + space
        for child in elem:
            _et_indent(child, space, level + 1)
        if not child.tail or not child.tail.strip():
            child.tail = pad
    if level and (not elem.tail or not elem.tail.strip()):
        elem.tail = pad


def load_installer(root):
    if not hasattr(ET, 'indent'):
        ET.indent = lambda tree, space='  ', level=0: _et_indent(
            tree.getroot() if hasattr(tree, 'getroot') else tree, space, level)
    if root not in sys.path:
        sys.path.insert(0, root)
    import install
    install.set_lang('ru' if RU else 'en')
    return install


# ---- вопросы ----------------------------------------------------------------------------------

class Asker(object):
    """install.ASKER: вопрос установщика -> диалог Kodi. Ключи API - одним вопросом «есть свои?»."""

    def __init__(self, I):
        self.I = I
        self.keys = None

    def __call__(self, item, default, answers):
        I, key, kind = self.I, item['key'], item['kind']
        text = I.qtr(item, 'text')
        why = I.qtr(item, 'why')
        if kind.startswith('choice:'):
            opts = kind.split(':', 1)[1].split(',')
            labels = I.choice_labels(key)
            pre = opts.index(default) if default in opts else 0
            i = DIALOG.select(text, [labels.get(o, o) for o in opts], preselect=pre)
            return opts[i] if i >= 0 else (default or opts[0])
        if kind == 'bool':
            skip = I.skip_text(item)
            msg = why + (('\n' + T('Если «нет»: ', 'If no: ') + skip) if skip else '')
            return 'y' if DIALOG.yesno(text, msg) else 'n'
        hide = xbmcgui.ALPHANUM_HIDE_INPUT if kind == 'secret' else 0
        raw = DIALOG.input(text, defaultt=str(default or ''), type=xbmcgui.INPUT_ALPHANUM, option=hide)
        return raw if raw != '' else default


# вне ELEC: ни коробки, ни системы - эти вопросы не задаются (ответ - «нет»/умолчание)
NOT_ELEC_SKIP = ('target.', 'system.', 'hw.', 'hardware.', 'kodi.hostname', 'kodi.timezone')
NOT_ELEC_GIVEN = {'hub.mode': 'off', 'system.advanced': 'n', 'system.cec': 'n'}


# ---- ELEC: установщик на этой же коробке ------------------------------------------------------

def run_elec(I, root, p):
    # вопросы установщика (источники, сеть, ТВ...) - диалогами Kodi; без вопросов «Загрузить
    # дополнение?» (владелец, 23.11.2026)
    I.ASKER = Asker(I)
    a = I.ask_all({}, True, include=lambda k: not k.startswith(('target.', 'hw.')))
    ini = os.path.join(root, 'answers.ini')
    I.save_answers(ini, a)
    log_file = os.path.join(root, 'install.log')
    cmd = ('systemd-run --unit=sublime-setup --collect --quiet sh -c '
           '"cd %s && python3 install.py --local --yes --lang %s --config answers.ini > %s 2>&1; '
           'rm -f answers.ini"' % (root, 'ru' if RU else 'en', log_file))
    if not DIALOG.yesno('Sublime', T('Ответы приняты. Kodi остановится на 5-10 минут на время установки и '
                                     'запустится снова. Ставить?',
                                     'Answers saved. Kodi will stop for 5-10 minutes while installing and start '
                                     'again. Install?')):
        os.remove(ini)
        return
    log('ELEC: %s' % cmd)
    os.system(cmd)


# ---- другие платформы: установка средствами Kodi ----------------------------------------------

class _Recorder(object):
    """Target установщика, который не пишет, а запоминает: install.write_settings проходит как
    на коробке, а мастер применяет записанное средствами Kodi. Пути коробки (/storage/.kodi/)
    переводятся в профиль этого Kodi - и в путях файлов, и в значениях (адрес плейлиста ТВ)."""

    local = True
    dry = False

    def __init__(self):
        self.files = {}

    @staticmethod
    def real(path):
        if path.startswith('/storage/.kodi/'):
            return HOME + path[len('/storage/.kodi/'):]
        return path

    def read(self, path):
        if path in self.files:
            return self.files[path]
        try:
            with open(self.real(path), 'rb') as f:
                return f.read()
        except OSError:
            return None

    def write(self, path, data, mode='644', backup=None, what=''):
        if isinstance(data, str):
            data = data.encode('utf-8')
        data = data.replace(b'/storage/.kodi/', HOME.encode('utf-8'))
        self.files[path] = data

    def put(self, local_path, path, mode='644', backup=None):
        with open(local_path, 'rb') as f:
            self.write(path, f.read(), mode, backup)

    def sh(self, script, mutate=True, timeout=900, what=''):
        log('пропущено (не ELEC): %s' % (what or script.strip().splitlines()[0][:80]))
        return 0, ''


def setting_types(data):
    """{id: type} из settings.xml (type="string"/"bool" у настроек скина)."""
    out = {}
    try:
        for s in ET.fromstring(data).iter('setting'):
            if s.get('id') and s.get('type'):
                out[s.get('id')] = s.get('type')
    except ET.ParseError:
        pass
    return out


def settings_values(data):
    out = {}
    try:
        for s in ET.fromstring(data).iter('setting'):
            sid = s.get('id')
            if sid:
                out[sid] = s.get('value') if s.get('value') is not None else (s.text or '')
    except ET.ParseError:
        pass
    return out


def has_addon(aid):
    """Установлено ли. Не System.HasAddon: Kodi приводит его параметр к нижнему регистру, и
    plugin.video.RuTor «не находился» - мастер ждал его 5 минут (Windows, 23.11.2026)."""
    res = rpc('Addons.GetAddonDetails', {'addonid': aid, 'properties': ['installed']})
    return bool(((res.get('result') or {}).get('addon') or {}).get('installed'))


BUNDLE = 'script.module.sublime'
BUNDLE_ADDONS = ('skin.sublime', 'service.tvlink', 'pvr.sublime', 'plugin.video.filmix', 'plugin.video.hdrezka.tv',
                 'plugin.video.elementum', 'plugin.video.RuTor', 'plugin.video.youtube',
                 'plugin.program.autocompletion')


def install_addon(aid, progress, pct, limit=600):
    if has_addon(aid):
        return True
    progress.update(pct, T('Ставлю %s', 'Installing %s') % aid)
    xbmc.executebuiltin('InstallAddon(%s)' % aid)
    for _ in range(limit):
        # InstallAddon в Kodi 21 всегда спрашивает «Требуется дополнение ... Загрузить?» (и про
        # зависимости) - второй параметр он не принимает (Windows, 23.11.2026). Ответ «да» (кнопка
        # 11 окна 10100) даёт мастер: установку пользователь уже выбрал, запустив его
        if xbmc.getCondVisibility('Window.IsActive(10100)'):
            xbmc.executebuiltin('SendClick(10100,11)')
        if has_addon(aid):
            return True
        if progress.iscanceled():
            return False
        xbmc.sleep(500)
    log('не поставлено: %s' % aid, xbmc.LOGWARNING)
    return False


def install_zip(path):
    """Пакет из архива установщика (Burst, PySocks: их нет в репозиториях) - распаковкой в addons."""
    with zipfile.ZipFile(path) as z:
        z.extractall(os.path.join(HOME, 'addons'))
        aid = z.namelist()[0].split('/')[0]
    xbmc.executebuiltin('UpdateLocalAddons')
    for _ in range(40):
        xbmc.sleep(250)
        if rpc('Addons.GetAddonDetails', {'addonid': aid}).get('result'):
            break
    rpc('Addons.SetAddonEnabled', {'addonid': aid, 'enabled': True})
    return aid


def point_repository(p):
    """repository.sublime: общий каталог + каталог ТВ-клиента этой платформы."""
    path = os.path.join(HOME, 'addons', REPO_ID, 'addon.xml')
    dirs = ''
    for sub in ('', pvr_folder(p)):
        base = REPO_URL + ('/' + sub if sub else '')
        dirs += ('    <dir>\n      <info compressed="false">%s/addons.xml</info>\n'
                 '      <checksum>%s/addons.xml.md5</checksum>\n'
                 '      <datadir zip="true">%s/</datadir>\n    </dir>\n' % (base, base, base))
    xml = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
           '<addon id="%s" name="Sublime" version="1.0.1" provider-name="patkino">\n'
           '  <extension point="xbmc.addon.repository" name="Sublime">\n%s  </extension>\n'
           '  <extension point="xbmc.addon.metadata">\n'
           '    <summary lang="en_GB">Sublime add-on updates</summary>\n'
           '    <summary lang="ru_RU">Обновления дополнений Sublime</summary>\n'
           '    <platform>all</platform>\n  </extension>\n</addon>\n' % (REPO_ID, dirs))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        f.write(xml)
    xbmc.executebuiltin('UpdateLocalAddons')
    xbmc.sleep(1500)
    rpc('Addons.SetAddonEnabled', {'addonid': REPO_ID, 'enabled': True})
    xbmc.executebuiltin('UpdateAddonRepos')
    for _ in range(240):
        if _in_repository('skin.sublime'):
            return True
        xbmc.sleep(500)
    log('репозиторий не прочитан за 2 мин', xbmc.LOGWARNING)
    return False


def _in_repository(aid):
    """Дополнение есть в прочитанных репозиториях (ещё не установлено)."""
    res = rpc('Addons.GetAddons', {'installed': False, 'properties': ['version']})
    return any(x.get('addonid') == aid for x in ((res.get('result') or {}).get('addons') or []))


def elementum_engine(I, p, progress):
    """Движок Elementum под эту платформу - с официального выпуска (как установщик на коробке)."""
    plat = {('windows', 'x86_64'): 'windows_x64', ('android', 'aarch64'): 'android_arm64',
            ('android', 'armv7'): 'android_arm', ('osx', 'x86_64'): 'darwin_x64',
            ('osx', 'aarch64'): 'darwin_arm64', ('linux', 'x86_64'): 'linux_x64',
            ('linux', 'aarch64'): 'linux_arm64', ('linux', 'armv7'): 'linux_armv7'}.get((p['os'], p['arch']))
    addon_dir = os.path.join(HOME, 'addons', 'plugin.video.elementum')
    if not plat or not os.path.isdir(addon_dir):
        return
    if os.path.isdir(os.path.join(addon_dir, 'resources', 'bin', plat)):
        return
    ver = xbmcaddon.Addon('plugin.video.elementum').getAddonInfo('version')
    ever = '.'.join(ver.split('.')[:3])
    url = ('https://github.com/elgatito/plugin.video.elementum/releases/download/v%s/'
           'plugin.video.elementum-%s.%s.zip' % (ever, ever, plat))
    progress.update(80, T('Движок Elementum (%s)', 'Elementum engine (%s)') % plat)
    zp = download(url, os.path.join(WORK, 'elementum-%s.zip' % plat))
    with zipfile.ZipFile(zp) as z:
        pre = 'plugin.video.elementum/resources/bin/%s/' % plat
        for name in z.namelist():
            if name.startswith(pre) and not name.endswith('/'):
                dest = os.path.join(addon_dir, 'resources', 'bin', plat, name[len(pre):])
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                with z.open(name) as src, open(dest, 'wb') as out:
                    shutil.copyfileobj(src, out)
                if p['os'] != 'windows':
                    os.chmod(dest, 0o755)
    os.remove(zp)


def _addon_settings(rec):
    """[(id, {настройка: значение}, путь коробки, данные)] - settings.xml дополнений из записи."""
    out = []
    for path, data in rec.files.items():
        m = re.search(r'^/storage/\.kodi/userdata/addon_data/([^/]+)/settings\.xml$', path)
        if m and m.group(1) != 'skin.sublime':
            values = settings_values(data)
            if m.group(1) == 'plugin.video.elementum' and not values.get('download_path'):
                # без папки загрузки Elementum при первом запуске спрашивает пути; торрент
                # держится в памяти (download_storage=1), папка нужна только для порядка
                values['download_path'] = xbmcvfs.translatePath('special://temp/elementum/')
                new = ('<setting id="download_path">%s</setting>' % values['download_path']).encode('utf-8')
                # заменой-функцией: путь Windows (C:\Users\...) в строке замены re.sub читает как
                # служебные последовательности - «bad escape \U» (Windows, 23.11.2026)
                data = re.sub(rb'<setting id="download_path"[^>]*?(/>|>[^<]*</setting>)', lambda _m: new, data)
                rec.files[path] = data
            out.append((m.group(1), values, path, data))
    return out


def prewrite_addon_settings(rec):
    """Файлы настроек дополнений, которые ещё не стоят: Kodi прочтёт их при установке."""
    for aid, values, path, data in _addon_settings(rec):
        if has_addon(aid):
            continue
        real = rec.real(path)
        os.makedirs(os.path.dirname(real), exist_ok=True)
        with open(real, 'wb') as f:
            f.write(data)


def apply_files(I, rec, p):
    """Записанное install.write_settings - средствами Kodi."""
    gui, skin, later = {}, {}, []
    for path, data in rec.files.items():
        if not path.startswith('/storage/.kodi/'):
            continue        # архивы для коробки (/storage/downloads) - кэш ТВ ставит tv_cache()
        if path.endswith('/userdata/guisettings.xml'):
            gui = settings_values(data)
        elif path.endswith('/addon_data/skin.sublime/settings.xml'):
            skin = settings_values(data)
            SKIN_TYPES.update(setting_types(data))
        elif re.search(r'/addon_data/([^/]+)/settings\.xml$', path):
            continue
        else:
            real = rec.real(path)
            os.makedirs(os.path.dirname(real), exist_ok=True)
            with open(real, 'wb') as f:
                f.write(data)
    for aid, values, path, data in _addon_settings(rec):
        try:
            addon = xbmcaddon.Addon(aid)
        except RuntimeError:
            # не стоит (необязательное) - файл как есть, прочтётся при установке
            real = rec.real(path)
            os.makedirs(os.path.dirname(real), exist_ok=True)
            with open(real, 'wb') as f:
                f.write(data)
            continue
        for k, v in values.items():
            addon.setSetting(k, v)
    return gui, skin


GUI_SKIP = ('services.webserver', 'services.webserverport', 'services.webserverauthentication',
            'services.esenabled', 'services.esallinterfaces', 'audiooutput.', 'input.', 'lookandfeel.skin',
            'videoscreen.', 'videoplayer.useamcodec', 'debug.', 'window.')


def apply_gui(gui):
    for k, v in gui.items():
        # мышь нужна на ПК и в Android; веб-сервер и звук - дело пользователя этой платформы
        if k.startswith(GUI_SKIP):
            continue
        val = {'true': True, 'false': False}.get(v, int(v) if re.fullmatch(r'-?\d+', v or '') else v)
        res = rpc('Settings.SetSettingValue', {'setting': k, 'value': val})
        if 'error' in res:
            log('настройка Kodi %s=%s: %s' % (k, v, res['error']), xbmc.LOGDEBUG)


def switch_skin():
    if xbmc.getSkinDir() == 'skin.sublime':
        return True
    # Вызов не возвращается, пока открыто «Оставить этот скин?»: из этого же потока нажать «да»
    # было бы уже некому, и через 10 с Kodi возвращал прежний скин (Windows, 23.11.2026).
    # Поэтому смена - в своём потоке, а здесь ждём окно и жмём «да» (кнопка 11).
    import threading
    th = threading.Thread(target=rpc, args=('Settings.SetSettingValue',
                                            {'setting': 'lookandfeel.skin', 'value': 'skin.sublime'}))
    th.daemon = True
    th.start()
    clicked = False
    for _ in range(120):
        xbmc.sleep(250)
        if xbmc.getCondVisibility('Window.IsActive(10100)'):
            xbmc.executebuiltin('SendClick(10100,11)')
            clicked = True
        elif clicked and not th.is_alive():
            break
    th.join(5)
    for _ in range(40):
        if xbmc.getSkinDir() == 'skin.sublime':
            return True
        xbmc.sleep(250)
    log('скин не переключился', xbmc.LOGWARNING)
    return False


def apply_skin(skin, p):
    # плитка 03 меню питания: на ELEC - настройки системы, здесь - выход из Kodi (владелец, 23.11.2026)
    skin['optionstiles.03.label'] = T('Выход', 'Exit')
    skin['OptionsTiles.03.Onclick'] = 'Quit'
    skin['optionstiles.03.path'] = 'Quit'
    skin['optionstiles.03.icon'] = 'special://skin/extras/icons/power.png'
    for k, v in skin.items():
        # тип - из настроек скина, не по значению: homeswitcher.*.toggle - строки со значением
        # «true»; записанные флажком, они пропадали, и с ними все хабы, кроме ТВ (Windows, 23.11.2026)
        if SKIN_TYPES.get(k) == 'bool':
            xbmc.executebuiltin('Skin.%s(%s)' % ('SetBool' if v == 'true' else 'Reset', k))
        else:
            xbmc.executebuiltin('Skin.SetString(%s,%s)' % (k, v.replace(',', '\\,')))


SKIN_TYPES = {}
NODES = os.path.join(HOME, 'userdata', 'addon_data', 'skin.sublime', 'nodes', 'skin.sublime')


def tv_tabs():
    """Вкладки хаба ТВ - по группам каналов, как установщик после запуска Kodi (install.TABS):
    группы из плейлиста service.tvlink, клиент - pvr.sublime. Без этого в хабе ТВ были только
    «Управление каналами» и «Расписание» (Windows, 23.11.2026)."""
    import urllib.request
    names, cid = [], None
    for _ in range(45):
        try:
            text = urllib.request.urlopen('http://127.0.0.1:2020/playlist', timeout=10).read().decode('utf-8', 'replace')
            names = []
            for m in re.finditer(r'group-title="([^"]+)"', text):
                if m.group(1) not in names:
                    names.append(m.group(1))
        except Exception:
            names = []
        res = rpc('PVR.GetClients')
        cl = [c for c in ((res.get('result') or {}).get('clients') or []) if c.get('addonid') == 'pvr.sublime']
        cid = cl[0].get('clientid') if cl else None
        if names and cid is not None:
            break
        xbmc.sleep(2000)
    if not (names and cid is not None):
        log('вкладки ТВ: групп нет (плейлист=%d, клиент=%s)' % (len(names), cid), xbmc.LOGWARNING)
        return 0
    names.sort(key=lambda n: n in ('Другие', 'Other'))
    tabs = [{'label': n, 'path': 'pvr://channels/tv/%s@%d' % (n, cid),
             'icon': 'special://skin/extras/icons/watched-hide.png', 'target': '', 'guid': 'guid-tv%03d' % i,
             'widget_style': 'Square', 'widget_sortby': 'lastplayed', 'widget_sortorder': 'True',
             'widget_actionbuttons': 'False'} for i, n in enumerate(names)]
    os.makedirs(NODES, exist_ok=True)
    for pre in ('skinvariables', 'vclvariables'):
        with open(os.path.join(NODES, '%s-shortcut-homewidgets.json' % pre), 'w', encoding='utf-8') as f:
            json.dump(tabs, f, ensure_ascii=False, indent=4)
    return len(tabs)


def relayout():
    """Скин пересоберёт главный экран при следующем запуске Kodi (install.RELAYOUT): отпечаток
    вкладок сброшен, отметка пересборки новая."""
    state = os.path.join(HOME, 'userdata', 'addon_data', 'skin.sublime', 'shortcuts_rebuild_state.json')
    try:
        with open(state, encoding='utf-8') as f:
            d = json.load(f)
        d.pop('input_signature', None)
        with open(state, 'w', encoding='utf-8') as f:
            json.dump(d, f)
    except Exception:
        pass
    xbmc.executebuiltin('Skin.SetString(Shortcuts.RebuildDateTime,%s)' % (time.strftime('%Y-%m-%d_%H:%M:%S') + '_tabs'))


def tv_cache(I):
    cache = I.payload('tvcache', 'tv_cache.zip')
    if not os.path.isfile(cache):
        return
    ad = os.path.join(HOME, 'userdata', 'addon_data')
    with zipfile.ZipFile(cache) as z:
        for name in z.namelist():
            dest = os.path.join(ad, name)
            if name.endswith('/') or os.path.exists(dest):
                continue
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            with z.open(name) as src, open(dest, 'wb') as out:
                shutil.copyfileobj(src, out)


def synth_box(I, p):
    """Сведения «коробки» для расчётов установщика: железа нет - средние значения."""
    box = dict(I.OFFLINE_BOX)
    mem = re.sub(r'\D', '', xbmc.getInfoLabel('System.Memory(total)'))
    box.update(os_name='', os=p['os'], kodi=p['version'].split(' ')[0], arch=p['arch'],
               mem_kb=int(mem) * 1024 if mem else 4000000, wlan_in_use=False, hub_token=False)
    return box


def run_other(I, root, p):
    given = dict(NOT_ELEC_GIVEN)
    # раскладки пульта (keyboard.xml переназначает клавиши) - для приставок Android; на ПК и Mac
    # клавиатура осталась бы с чужими клавишами
    given['system.keymaps'] = 'y' if p['os'] == 'android' else 'n'
    # вопросы установщика (источники фильмов и сериалов, скорость сети, ТВ...) - диалогами Kodi, в
    # начале, пока стоит Estuary; дальше всё само (владелец, 23.11.2026)
    I.ASKER = Asker(I)
    a = I.ask_all(given, True, include=lambda k: not k.startswith(NOT_ELEC_SKIP))
    box = synth_box(I, p)
    # не заданные вопросы: системное - «нет» (кроме раскладок пульта), железо - средние значения
    hw = I.hw_defaults(box)
    for item in I.Q:
        key, kind = item['key'], item['kind']
        if key in a:
            continue
        if key in given:
            a[key] = I.norm(kind, given[key])
        elif key.startswith(('system.', 'hardware.')) and kind == 'bool':
            a[key] = False
        else:
            a[key] = I.norm(kind, hw.get(key, item['default']))
    I.apply_net_answers(a, box)
    if a.get('tv.playlists', 'default') != 'own':
        for k, v in I.TV_DEFAULTS.items():
            a.setdefault(k, v)
            if not a[k]:
                a[k] = v
    progress = xbmcgui.DialogProgress()
    progress.create('Sublime', T('Подготовка', 'Preparing'))
    failed = []
    try:
        # настройки - ДО установки: Elementum и другие при первом запуске (сразу после
        # установки) уже настроены, а не спрашивают пути (Windows, 23.11.2026)
        progress.update(2, T('Настройки', 'Settings'))
        rec = _Recorder()
        a['_skin_version'] = ''
        I.write_settings(a, rec, box, '')
        prewrite_addon_settings(rec)
        point_repository(p)
        # Все дополнения - зависимости одного пакета script.module.sublime: Kodi ставит их за
        # один раз, вместе с зависимостями из официального репозитория (владелец, 23.11.2026).
        # Burst и PySocks в репозиториях нет - из архива установщика, до пакета.
        for name in sorted(os.listdir(I.payload('addons'))):
            if name.endswith('.zip') and ('burst' in name or 'pysocks' in name):
                install_zip(os.path.join(I.payload('addons'), name))
        lang = 'resource.language.' + (a['kodi.language'] or 'ru_ru').lower()
        install_addon(lang, progress, 8)
        ids = list(BUNDLE_ADDONS)
        if not install_addon(BUNDLE, progress, 10, limit=120):
            # пакет не встал - по одному, окна «Загрузить?» подтверждает install_addon
            log('пакет %s не поставлен - дополнения по одному' % BUNDLE, xbmc.LOGWARNING)
            for n, aid in enumerate(ids):
                install_addon(aid, progress, 10 + 60 * n // len(ids))
        for n in range(240):
            missing = [aid for aid in ids if not has_addon(aid)]
            if not missing:
                break
            if xbmc.getCondVisibility('Window.IsActive(10100)'):
                xbmc.executebuiltin('SendClick(10100,11)')
            progress.update(10 + 70 * (len(ids) - len(missing)) // len(ids),
                            T('Ставлю дополнения: осталось %d', 'Installing add-ons: %d left') % len(missing))
            xbmc.sleep(500)
        failed = [aid for aid in ids if not has_addon(aid)]
        if 'plugin.video.elementum' in ids and 'plugin.video.elementum' not in failed:
            elementum_engine(I, p, progress)
        progress.update(85, T('Настройки', 'Settings'))
        gui, skin = apply_files(I, rec, p)
        apply_gui(gui)
        if a['tv.enabled']:
            tv_cache(I)
    finally:
        progress.close()
    # вход в аккаунты - до смены скина: в Estuary у клавиатуры виден заголовок, понятно, что
    # вводить (владелец, 23.11.2026)
    logins(I, a)
    progress = xbmcgui.DialogProgress()
    progress.create('Sublime', T('Вкладки ТВ', 'TV tabs'))
    try:
        if a['tv.enabled']:
            progress.update(90, T('Вкладки ТВ по группам каналов', 'TV tabs by channel groups'))
            log('вкладки ТВ: %d' % tv_tabs())
        progress.update(95, T('Скин', 'Skin'))
    finally:
        progress.close()
    if switch_skin():
        apply_skin(skin, p)
        relayout()          # отметка пересборки - в настройки уже скина sublime
    if failed:
        log('не поставлены: %s' % ', '.join(failed), xbmc.LOGWARNING)
    xbmcgui.Dialog().notification('Sublime', T('Готово. Главный экран соберётся за минуту',
                                               'Done. The home screen builds itself within a minute') if not failed else
                                  T('Не поставлены: ', 'Not installed: ') + ', '.join(failed),
                                  xbmcgui.NOTIFICATION_INFO if not failed else xbmcgui.NOTIFICATION_WARNING, 5000)
    # Без перезапуска Kodi: главный экран скин пересобирает сам через минуту после загрузки
    # (relayout). Перезапуск сразу после смены скина вешал Kodi на Windows: службы ещё
    # стартовали, Kodi убивал их скрипты и зависал на одном из них (23.11.2026)


def _wait_login(limit=900):
    """Окно входа открылось (до 30 с) - и закрылось."""
    for _ in range(60):
        if _busy():
            break
        xbmc.sleep(500)
    _wait_dialogs(limit)


def _busy():
    return xbmc.getCondVisibility('System.HasActiveModalDialog') or \
        xbmc.getCondVisibility('Window.IsActive(progressdialog)') or \
        xbmc.getCondVisibility('Window.IsActive(okdialog)') or \
        xbmc.getCondVisibility('Window.IsActive(textviewer)')


def _wait_dialogs(limit=900):
    """Ждать, пока пользователь закончит вход: окна дополнения закрыты 3 с подряд."""
    xbmc.sleep(3000)
    quiet, waited = 0, 0
    while quiet < 6 and waited < limit * 2:
        busy = xbmc.getCondVisibility('System.HasActiveModalDialog') or \
            xbmc.getCondVisibility('Window.IsActive(progressdialog)') or \
            xbmc.getCondVisibility('Window.IsActive(okdialog)') or \
            xbmc.getCondVisibility('Window.IsActive(textviewer)')
        quiet = 0 if busy else quiet + 1
        waited += 1
        xbmc.sleep(500)


def _addon_file(aid, name):
    return os.path.join(HOME, 'userdata', 'addon_data', aid, name)


def _youtube_signed_in():
    try:
        with open(_addon_file('plugin.video.youtube', 'access_manager.json'), encoding='utf-8') as f:
            d = json.load(f)['access_manager']
        u = (d.get('users') or {}).get(str(d.get('current_user', 0))) or {}
        return bool((u.get('refresh_token') or '').split('|')[0])
    except Exception:
        return False


def _hdrezka_signed_in():
    import html
    try:
        with open(_addon_file('plugin.video.hdrezka.tv', 'settings.xml'), encoding='utf-8') as f:
            m = re.search(r'<setting id="cookies"[^>]*>([^<]*)</setting>', f.read())
        c = json.loads(html.unescape(m.group(1))) if m and m.group(1) else []
        c = [{'name': k, 'value': v} for k, v in c.items()] if isinstance(c, dict) else c
        return any(isinstance(x, dict) and x.get('name') == 'dle_user_id'
                   and str(x.get('value') or '').strip() not in ('', '0', 'deleted') for x in c)
    except Exception:
        return False


def _filmix_signed_in():
    try:
        with open(_addon_file('plugin.video.filmix', 'settings.xml'), encoding='utf-8') as f:
            # пустая настройка (<setting id="user_dev_token" default="true" />) - не вход: прежний
            # образец считал её заполненной, и вход в Filmix пропускался (Windows, 23.11.2026)
            return bool(re.search(r'<setting id="user_dev_token"[^>/]*>\s*[^<\s]', f.read()))
    except Exception:
        return False


def logins(I, a):
    """Вход в аккаунты выбранных источников - сразу, по очереди, как установщик с ПК: без входа
    у HDRezka пустой каталог (полосы сериалов пусты), у Filmix и YouTube - только кнопка «Войти»."""
    _wait_dialogs(60)
    if a.get('youtube.install') and not _youtube_signed_in():
        DIALOG.ok('YouTube', T('Войдите в аккаунт YouTube: сейчас появится код. Откройте на телефоне или ПК '
                               'google.com/device, войдите в Google и введите код.',
                               'Sign in to YouTube: a code will appear now. Open google.com/device on a phone or '
                               'PC, sign in to Google and enter the code.'))
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.youtube/sign/in/)')
        _wait_login()
    _wait_dialogs(60)
    if not _hdrezka_signed_in():
        if not a.get('hdrezka.login'):
            DIALOG.ok('HDRezka', T('Войдите в аккаунт HDRezka: сейчас появятся поля логина и пароля. Без входа '
                                   'её каталог пуст.',
                                   'Sign in to HDRezka: login and password fields appear now. Without it the '
                                   'catalogue is empty.'))
        for _ in range(3):
            login = a.get('hdrezka.login') or DIALOG.input(T('HDRezka: логин (e-mail)', 'HDRezka: login (e-mail)'))
            password = a.get('hdrezka.password') or DIALOG.input(
                T('HDRezka: пароль', 'HDRezka: password'), option=xbmcgui.ALPHANUM_HIDE_INPUT)
            a['hdrezka.login'] = a['hdrezka.password'] = ''
            if not (login and password):
                break
            tmp = xbmcvfs.translatePath('special://temp/hdrezka_login.json')
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump({'login': login, 'password': password}, f)
            xbmc.executebuiltin('RunScript(plugin.video.hdrezka.tv,0,authorize)')
            for _ in range(40):
                xbmc.sleep(1500)
                if _hdrezka_signed_in():
                    break
            if _hdrezka_signed_in():
                break
            if not DIALOG.yesno('HDRezka', T('Вход не выполнен (неверный логин или пароль, либо сайт недоступен). '
                                             'Попробовать ещё раз?',
                                             'Sign-in failed (wrong login or password, or the site is down). '
                                             'Try again?')):
                break
    # окно HDRezka после входа ещё открыто - вопрос Filmix Kodi закрывал сразу (Windows, 23.11.2026)
    _wait_dialogs(60)
    if not a.get('filmix.dev_token') and not _filmix_signed_in():
        DIALOG.ok('Filmix', T('Войдите в аккаунт Filmix: сейчас появятся код и адрес страницы. Откройте её на '
                              'телефоне или ПК, войдите в Filmix и введите код.',
                              'Sign in to Filmix: a code and a page address appear now. Open it on a phone or PC, '
                              'sign in to Filmix and enter the code.'))
        xbmc.executebuiltin('RunPlugin(plugin://plugin.video.filmix/login)')
        _wait_login()


def mark_done():
    """Мастер прошёл (установил или от установки отказались): служба больше не запускает его сама."""
    path = xbmcvfs.translatePath('special://profile/addon_data/script.sublime.setup/')
    os.makedirs(path, exist_ok=True)
    with open(os.path.join(path, 'done'), 'w') as f:
        f.write(time.strftime('%Y-%m-%d %H:%M:%S'))


def main():
    p = detect()
    log('платформа: %s' % p)
    progress = xbmcgui.DialogProgress()
    progress.create('Sublime', T('Готовлю установщик', 'Preparing the installer'))
    try:
        root = fetch_installer(progress)
    except Exception as exc:
        progress.close()
        DIALOG.ok('Sublime', T('Установщик не скачан: %s', 'Installer not downloaded: %s') % exc)
        return
    progress.close()
    I = load_installer(root)
    if p['os'] == 'elec':
        run_elec(I, root, p)
    else:
        run_other(I, root, p)
    mark_done()
