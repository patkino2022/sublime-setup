"""One naming standard for every channel of every playlist, before anything else.

Playlists name the same channel in a dozen ways: some write Latin
transliterations with resolution and notes ("Pervyy kanal (1080p) [Geo-blocked]",
"Russia-1 +4 (1080p)"), others Russian ones ("Первый канал HD (+4)"). Here every
title becomes

    <name>[ HD| 4K][ (+N)]

* <name>: the established Russian name where the channel has one ("Первый канал",
  "Россия 24", "СТС", "ТВ-3"), the Latin brand where Russian TV writes it in Latin
  (Euronews, CNN, BBC News, DW, RTVi, TLC). Explicit aliases first, then the
  channel names of the table, then the Cyrillic names of the epg.one guide - a
  Latin transliteration meets its Russian name on one phonetic key ("Dom kino",
  "Дом Кино" -> "domkino").
* quality: 4K/UHD/2160 -> " 4K"; FHD/FullHD/HD/HDR/1080/720 -> " HD"; SD, 576,
  480 and no marker -> nothing. HD and SD stay separate channels, FHD and HD are one.
* time shift as " (+N)".
* junk dropped: "(1080p)", "[Geo-blocked]", "[Not 24/7]", "orig", "Backup",
  country suffixes, emojis, double spaces.

Groups: every channel gets one of groups.STANDARD except «Другие»: owner's choice,
then the table's channel -> group, then the playlist's own group when it says
something ("General"/"Undefined" does not), then name keywords, then a
regional "<Город> 24", and «Развлекательные» as the last resort.

Data: resources/channel_names.json (aliases, names, guide names, junk, groups).
"""
import json
import os
import re

from . import groups as _groups

RESOURCES = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
DATA = os.path.join(RESOURCES, "channel_names.json")

_TR = {"а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "e", "ж": "zh", "з": "z",
       "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
       "с": "s", "т": "t", "у": "u", "ф": "f", "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sch",
       "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu", "я": "ya", "є": "e", "і": "i", "ї": "i",
       "°": ""}
# sounds written with two Latin letters become one upper-case token first, so that the
# later one-letter rules (z -> s) do not fold "Zoo TV" into "Shot TV"
_PHON = (("shch", "S"), ("sch", "S"), ("kh", "h"), ("tch", "C"), ("ts", "C"), ("tz", "C"), ("zh", "Z"),
         ("ch", "C"), ("sh", "S"), ("ck", "k"), ("x", "ks"), ("w", "v"), ("q", "k"), ("ph", "f"),
         ("yo", "e"), ("ya", "a"), ("ja", "a"), ("yu", "u"), ("ju", "u"), ("ye", "e"), ("je", "e"),
         ("y", "i"), ("j", "i"), ("z", "s"), ("c", "C"))


def skeleton(name):
    """Phonetic key: Cyrillic and its Latin transliterations meet ("Kinosemja",
    "Киносемья"; "Russkiy Detektiv", "Русский детектив"). '+' is kept: viju+ is not viju."""
    low = (name or "").casefold().replace("ё", "е")
    low = "".join(_TR.get(ch, ch) for ch in low)
    low = low.replace("&", "and")
    low = re.sub(r"[^a-z0-9+]", "", low)
    for a, b in _PHON:
        low = low.replace(a, b)
    low = re.sub(r"i(?=[aeiou])", "", low)
    return re.sub(r"(.)\1+", r"\1", low)


_EMOJI = re.compile("[\U0001F000-\U0001FFFF\u2190-\u21FF\u2300-\u27BF\u2B00-\u2BFF\uFE0F\u200B-\u200D\u2122\u00AE\u00A9]")
_SHIFT = re.compile(r"(?:\(\s*|\s|^)([+-])\s*(\d{1,2})\s*\)?\s*$")
_RES = re.compile(r"\(\s*(\d{3,4})\s*[pi]\s*\)|(?<![A-Za-z0-9])(\d{3,4})[pi](?![A-Za-z0-9])", re.I)
_UHD = re.compile(r"(?<![A-Za-zА-Яа-я0-9])(4K|UHD|2160[pi]?|8K)(?![A-Za-zА-Яа-я0-9])", re.I)
_HD = re.compile(r"(?<![A-Za-zА-Яа-я0-9])(FHD|Full\s*HD|FullHD|HDR|HD|ХД)(?![A-Za-zА-Яа-я0-9])", re.I)
_SD = re.compile(r"(?<![A-Za-zА-Яа-я0-9])(SD)(?![A-Za-zА-Яа-я0-9])")


class Table:
    def __init__(self, data):
        self.junk = [re.compile(p, re.I) for p in data.get("junk", ())]
        self.country = re.compile(r"(?:\s+|\s*-\s*)(?:%s)\s*$" % "|".join(data.get("country_suffixes") or ["$^"]), re.I)
        # two-letter country codes of guides and playlists ("Беларусь 24 BY", "Euronews TR"):
        # upper case only, so that a word of the name is never taken for one
        self.codes = re.compile(r"\s+(?:%s)\s*$" % "|".join(data.get("country_codes") or ["$^"]))
        self.prefixes = sorted((data.get("prefixes") or {}).items(), key=lambda kv: -len(kv[0]))
        self.alias = {}
        for canon, alts in (data.get("aliases") or {}).items():
            for a in [canon] + list(alts):
                self.alias.setdefault(skeleton(a), canon)
        self.names = {}
        for n in data.get("names") or ():
            self.names.setdefault(skeleton(n), n)
        self.guide = {}
        for n in data.get("guide_names") or ():
            self.guide.setdefault(skeleton(n), n)
        self.latin = {skeleton(n): n for n in data.get("latin") or ()}
        self.group_of = {}
        for g, names in (data.get("groups") or {}).items():
            for n in names:
                self.group_of.setdefault(skeleton(n), g)
        self.keywords = [(g, re.compile(p, re.I)) for g, p in (data.get("group_keywords") or {}).items()]
        self.regional = re.compile(data.get("regional") or "$^", re.I)
        self.weak = re.compile(data.get("weak_groups") or "$^", re.I)
        self.broadcast = re.compile(data.get("broadcast_groups") or "$^", re.I)

    # ---- names ----------------------------------------------------------
    def lookup(self, base):
        k = skeleton(base)
        if not k:
            return None
        for table in (self.alias, self.latin, self.names, self.guide):
            if k in table:
                return table[k]
        return None


_table = None


def table():
    global _table
    if _table is None:
        try:
            with open(DATA, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            data = {}
        _table = Table(data)
    return _table


def split(title):
    """(base name, quality '', 'HD' or '4K', shift '+4'/'-3'/'') of a raw playlist title."""
    t = _EMOJI.sub(" ", title or "")
    t = t.replace(chr(160), " ")
    tab = table()
    q = ""
    for m in _RES.finditer(t):
        res = int(m.group(1) or m.group(2))
        if res >= 2000:
            q = "4K"
        elif res >= 720 and q != "4K":
            q = "HD"
    t = _RES.sub(" ", t)
    for rx in tab.junk:
        t = rx.sub(" ", t)
    t = " ".join(t.split())
    m = _SHIFT.search(t)
    shift = ""
    if m and t[:m.start()].strip():
        n = int(m.group(2))
        if n:
            shift = m.group(1) + str(n)
        t = t[:m.start()]
    # remaining brackets are notes or countries: «(Russia)», «(Singapore)», «[Not 24/7]»
    t = re.sub(r"\([^)]*\)|\[[^\]]*\]", " ", t)
    if _UHD.search(t):
        q = "4K"
    elif _HD.search(t) and q != "4K":
        q = "HD"
    t = _UHD.sub(" ", t)
    t = _HD.sub(" ", t)
    t = _SD.sub(" ", t)
    t = " ".join(t.split()).strip(" -_|,:;/").rstrip(".")
    return t, q, shift


def canonical(base):
    """Standard name for a base title (no quality, no shift)."""
    tab = table()
    for old, new in tab.prefixes:
        if base.casefold().startswith(old.casefold()):
            base = new + base[len(old):]
            break
    hit = tab.lookup(base)
    if hit:
        return hit
    cut = tab.codes.sub("", tab.country.sub("", base)).strip(" -")
    if cut and cut != base:
        hit = tab.lookup(cut)
        return hit or cut
    return base


def title(raw):
    """Normalized title of a raw playlist title: "Russia-1 +4 (1080p)" -> "Россия 1 HD (+4)"."""
    base, q, shift = split(raw)
    if not base:
        base = " ".join((raw or "").split())
        q = shift = ""
    name = canonical(base)
    out = name + (" " + q if q else "")
    if shift:
        out += " (%s)" % shift
    return out


def key(title):
    """Matching key of any title (playlist, guide, logo pack): the phonetic key of its
    standard name without quality and time shift - "Euronews Россия", "Euronews Russian
    (720p)" and "Euronews HD" give one key."""
    base = split(title)[0]
    return skeleton(canonical(base)) if base else ""


def base_of(normalized):
    """Name without quality and shift: "Россия 1 HD (+4)" -> "Россия 1"."""
    return split(normalized)[0]


# ---- groups --------------------------------------------------------------
def group(normalized, playlist_groups=()):
    """Standard group (never «Другие») for a channel with this normalized title,
    playlist_groups: raw group names of its links, by playlist priority."""
    tab = table()
    base = base_of(normalized)
    g = tab.group_of.get(skeleton(base))
    if g:
        return g
    weak = []
    for raw in playlist_groups:
        raw = (raw or "").split(";")[0].strip()
        if not raw:
            continue
        if tab.weak.search(raw):
            weak.append(raw)
            continue
        std = _groups.normalize(raw)
        if std == "Другие":
            continue
        if std == "Эфирные" and not tab.broadcast.search(raw):
            weak.append(raw)
            continue
        # «Астрахань 24», «Дон 24» под "News" - региональные, не федеральные новости
        if std == "Новости" and tab.regional.search(base):
            return "Региональные"
        return std
    for g, rx in tab.keywords:
        if rx.search(base):
            return g
    if tab.regional.search(base):
        return "Региональные"
    if weak:
        return "Региональные"
    return "Развлекательные"
