# -*- coding: utf-8 -*-
"""Recommendations from the watched history alone - no model, no API, no cost.

The shape of the work matters as much as the result, because the add-on this
replaces was removed for loading the boxes: it asked a model for ~90 titles per
category and then paid one catalogue SEARCH per suggestion, so a refresh was
~90 sequential round trips against a 180-second budget it regularly blew.

Here the candidates come from the provider's own local cache (see catalog.py) -
no network at all - and scoring is arithmetic over the watched table.

Where the list lives: on the shared server, not per box. A box renders what the
server holds so every box shows the SAME list, and only recomputes when the
server copy is missing, stale, or was built from different settings. That last
check is what `_signature()` is for - a list built under someone else's genre
filters is not this box's list.

Scoring, all signals normalized to 0..1 before weighting so none can run away:

  genre overlap        - the strongest real signal in this catalogue
  explicitly liked     - genres/countries from "recommend such" feedback
  preferred genres     - the owner's own list from settings
  acclaim              - high rating AND many votes (see W_ACCLAIM)
  country/studio/era   - tie-breakers

Hard filters (not weights): blocked genres, excluded countries, minimum
rating, disliked titles, and anything already watched - a started show
included (it lives in "continue watching", not here).

Display order: by release, newest first - movies by year, shows by the air
date of their latest episode (TMDb, set on the row by hub/routes.py). Score
decides WHICH titles make the list, release decides the order (owner,
21.11.2026).
"""
# Ported from plugin.video.watchhub. The algorithm is unchanged; the
# sources it reads are not: settings come from config.py, the built
# lists and the feedback from store.py, and the watched history from
# history.py - which reads and writes Kodi's own database.
from __future__ import absolute_import, unicode_literals

import hashlib
import heapq
import json
import re
import math
import time


from . import catalog, identity, sync
from .lanes import _busy_signal as lanes_busy
from . import history
from .config import get_bool, get_int, get_str, log
from .provider import instance_id
from .store import db

CATEGORY_LABELS = {'movies': 'фильмов', 'shows': 'сериалов'}

W_GENRE = 5.0
W_COUNTRY = 1.5
# W_STUDIO is gone: `studio` was empty in all 2144 rows of the measured
# history, and the term compared a candidate's DIRECTORS against that empty
# studio profile - it could only ever contribute 0.0. People (directors and
# actors) deserve a real profile of their own; that is wave 2, not a weight
# quietly scoring nothing here.
W_RATING = 1.2
W_YEAR_AFFINITY = 0.8
# People: measured coverage in the catalogue is 94% for directors and 91% for
# actors, and a director is a far sharper signal than a genre - "ещё у этого
# режиссёра" is a recommendation a person can recognise. Actors are noisier
# (a cast of 20 dilutes the signal), hence the lower weight.
W_DIRECTOR = 3.5
W_ACTOR = 2.0
# The provider's own related-titles edge: it is present on every post and is
# not derived from anything this add-on guessed.
W_RELATED = 3.0
# Abandoned viewing: started, stopped early, never came back. The strongest
# honest negative a person gives without being asked - it needs no dialog.
W_ABANDONED_PENALTY = 4.0
ABANDONED_MAX_SHARE = 0.25
# Сериал, от которого посмотрены одна-две серии и к которому не возвращались три недели, -
# брошен: в профиль «нравится» он не идёт, его жанры опускают похожее.
ABANDONED_SHOW_EPISODES = 2
ABANDONED_SHOW_DAYS = 21
W_ABANDONED_GENRE = 2.0
# «Не рекомендовать» опускает и похожее по жанру и стране - зеркально «рекомендовать такое».
W_DISLIKED_GENRE = 3.0
W_DISLIKED_COUNTRY = 1.0

# The owner's explicit taste outranks what the history merely implies.
W_PREFERRED_GENRE = 4.0
W_LIKED_GENRE = 3.0
W_LIKED_COUNTRY = 1.0
# "Acclaimed": there is no awards data in any source available here (measured -
# the provider's post payload carries imdb_rating/imdb_votes/kp_rating/kp_votes
# and no awards field at all), so this is the honest local substitute: a high
# rating that a large audience actually voted on.
W_ACCLAIM = 3.0
ACCLAIM_MIN_VOTES = 50000
ACCLAIM_MIN_RATING = 7.5

# How much a list may repeat itself. 0 = pure score order, which measured out
# as 40 crime dramas in a row; 1 = maximum spread regardless of score. The
# penalty applies to what is ALREADY chosen, so the top pick is never affected.
DIVERSITY_STRENGTH = 0.45
# Slots reserved for the newest catalogue additions that still match the
# profile. A quota rather than a weight: a weight lets recency creep into every
# slot, and the point is a few fresh picks, not a fresh list.
FRESH_SHARE = 0.2
# The pool the re-ranker gets to work with.
RERANK_POOL_FACTOR = 3
# сколько первых карточек идут по счёту совпадения, а не по дате выхода
TOP_BY_SCORE = 5
# Сериалы, у которых вышли серии после вашего просмотра: в «Рекомендациях» сериалов, впереди.
# Сериал свой - просмотрено не меньше половины серий; не идёт сейчас - две недели без серий.
NEW_EPISODES_MAX = 3
NEW_EPISODES_MIN_SHARE = 0.5
NEW_EPISODES_IDLE_DAYS = 14
NEW_EPISODES_POOL = 300

PROFILE_SAMPLE = 400
CACHE_FLAG = 'recommend_cache_%s'
CACHE_TS_FLAG = 'recommend_cache_ts_%s'
CACHE_SIG_FLAG = 'recommend_cache_sig_%s'


def _split(value):
    if isinstance(value, (list, tuple, set)):
        return [str(v).strip() for v in value if str(v or '').strip()]
    text = str(value or '')
    return [part.strip() for part in text.replace('/', ',').split(',') if part.strip()]


def _lower_set(value):
    return set(v.lower() for v in _split(value))


RECENCY_HALF_LIFE_DAYS = 90.0


def _recency_weight(last_watched, now=0):
    """How much a watch still counts, by real age rather than list position.

    This used to be `1 + (n - index)/n` - the row's position in the sample -
    which made the weight depend on how many rows were fetched rather than on
    when anything was actually watched. An exponential half-life says the
    honest thing: a watch from three months ago counts half as much as
    yesterday's.
    """
    try:
        stamp = int(last_watched or 0)
    except (TypeError, ValueError):
        stamp = 0
    if not stamp:
        return 1.0
    now = int(now or time.time())
    age_days = max(0.0, (now - stamp) / 86400.0)
    return 2.0 ** (-age_days / RECENCY_HALF_LIFE_DAYS)


def _aggregate_history(rows, now=0, abandoned_out=None, episode_counts=None):
    """Collapse episodes onto their show before anything is counted.

    Measured on the shared history: 1639 of 2144 rows are episodes across 91
    shows, and the eight most-binged shows alone are 598 rows - 28% of the
    whole history. Counting each episode separately let one series outvote
    dozens of films (Родина = 96 rows against a film's 1). A show now counts
    once, with `1 + log(episodes)` so bingeing still means something: those
    eight contribute 42 instead of 598.

    Returns a list of (weight, row) where each show appears once.
    """
    now = int(now or time.time())
    shows = {}
    out = []
    for row in rows:
        mediatype = str(row.get('mediatype') or '')
        parent = str(row.get('parent_key') or '')
        recency = _recency_weight(row.get('last_watched'), now)
        # A rewatch is the strongest thing a person says without being asked.
        try:
            playcount = max(1, int(row.get('playcount') or 1))
        except (TypeError, ValueError):
            playcount = 1
        weight = recency * (1.0 + 0.5 * math.log(playcount)) if playcount > 1 else recency
        if mediatype == 'episode' and parent:
            entry = shows.get(parent)
            if entry is None:
                shows[parent] = {'row': row, 'episodes': 1, 'recency': recency,
                                 'last': row.get('last_watched') or 0}
            else:
                entry['episodes'] += 1
                # The show is as fresh as its most recent episode.
                entry['recency'] = max(entry['recency'], recency)
                try:
                    entry['last'] = max(int(entry['last'] or 0), int(row.get('last_watched') or 0))
                except (TypeError, ValueError):
                    pass
            continue
        out.append((weight, row))
    for entry in shows.values():
        age_days = 0.0
        try:
            stamp = int(entry['last'] or 0)
            age_days = (now - stamp) / 86400.0 if stamp else 0.0
        except (TypeError, ValueError):
            age_days = 0.0
        # серий за ВСЮ историю, не в выборке профиля: в последние 400 строк давно досмотренный
        # сериал может попасть одной-двумя сериями
        total_seen = (episode_counts or {}).get(str(entry['row'].get('parent_key') or ''), entry['episodes'])
        if (abandoned_out is not None and episode_counts is not None
                and total_seen <= ABANDONED_SHOW_EPISODES and age_days >= ABANDONED_SHOW_DAYS):
            abandoned_out.append(entry['row'])
            continue
        out.append((entry['recency'] * (1.0 + math.log(entry['episodes'])), entry['row']))
    return out


# A value carried by nearly every title in the history cannot distinguish
# between those titles, so it is noise in a taste vector no matter how heavy it
# looks. Measured: "Сериалы" sits on 1615 of 1639 watched episodes (99%) - it
# says "this is a series", which the category already decided.
PROFILE_STOPWORD_SHARE = 0.9
# ...but a share is meaningless on a handful of titles. With three "recommend
# such" entries every genre sits on 100% of them, and dropping on that basis
# emptied the liked profile and silenced the feedback signal entirely (caught
# by the probe: a liked detective scored the same before and after the like).
PROFILE_STOPWORD_MIN_TITLES = 20


def _weighted_counts(weighted_rows, field):
    """Sum a field across the aggregated history, normalized to 1.

    Values present in almost every title are dropped: rarity in the CATALOGUE
    is handled by idf, but a value can be common in this history and rare in
    the catalogue at once, and then only this check catches it.
    """
    counts = {}
    titles = {}
    total = 0.0
    title_count = 0
    for weight, row in weighted_rows:
        values = set(v.lower() for v in _split(row.get(field)))
        if values:
            title_count += 1
        for key in values:
            titles[key] = titles.get(key, 0) + 1
        for value in _split(row.get(field)):
            key = value.lower()
            counts[key] = counts.get(key, 0.0) + weight
            total += weight
    if not total or not title_count:
        return {}
    if title_count >= PROFILE_STOPWORD_MIN_TITLES:
        dropped = 0.0
        survivors = dict(counts)
        for key, seen in titles.items():
            if seen / float(title_count) >= PROFILE_STOPWORD_SHARE:
                dropped += survivors.pop(key, 0.0)
        # Never empty the profile: if everything looks like a stopword, the
        # rule has nothing useful to say and the raw counts are better.
        if survivors:
            counts = survivors
            total -= dropped
    if total <= 0:
        return {}
    return dict((key, value / total) for key, value in counts.items())


def build_profile(rows, liked_rows=None, now=0, disliked_rows=None, episode_counts=None):
    abandoned_rows = []
    weighted = _aggregate_history(rows, now, abandoned_out=abandoned_rows,
                                  episode_counts=episode_counts)
    profile = {
        'genres': _weighted_counts(weighted, 'genres'),
        'countries': _weighted_counts(weighted, 'countries'),
        'years': _weighted_counts(weighted, 'year'),
        'sample': len(rows),
        'titles': len(weighted),
    }
    liked_rows = liked_rows or []
    liked_weighted = [(1.0, row) for row in liked_rows]
    profile['liked_genres'] = _weighted_counts(liked_weighted, 'genres')
    profile['liked_countries'] = _weighted_counts(liked_weighted, 'countries')
    profile['liked_sample'] = len(liked_rows)
    negative = [(1.0, row) for row in abandoned_rows]
    profile['abandoned_genres'] = _weighted_counts(negative, 'genres')
    profile['abandoned_sample'] = len(abandoned_rows)
    disliked = [(1.0, row) for row in (disliked_rows or [])]
    profile['disliked_genres'] = _weighted_counts(disliked, 'genres')
    profile['disliked_countries'] = _weighted_counts(disliked, 'countries')
    profile['disliked_sample'] = len(disliked)
    return profile


def _idf_table(field, df, total):
    """log(N/df) per value, so a label everything carries counts for little."""
    counts = (df or {}).get(field) or {}
    total = int(total or 0)
    if not counts or total <= 0:
        return {}
    table = {}
    for name, freq in counts.items():
        try:
            freq = max(1, int(freq))
        except (TypeError, ValueError):
            continue
        table[str(name).lower()] = math.log(total / float(freq))
    return table


def _similarity(values, profile_part, idf):
    """Cosine similarity between the candidate's values and the profile.

    Replaces a max-of-one-value overlap that could not tell "one genre of five
    matches" from "all five match" - measured on the real profile, both scored
    0.798. Rarity (idf) is folded into both vectors, which is what stops a
    structural tag from deciding the ranking.
    """
    values = [v.lower() for v in _split(values)]
    if not values or not profile_part:
        return 0.0

    def weight(name):
        return idf.get(name, 1.0) if idf else 1.0

    candidate = {}
    for name in values:
        candidate[name] = weight(name)
    dot = 0.0
    for name, value in candidate.items():
        profile_value = profile_part.get(name)
        if profile_value:
            dot += value * (profile_value * weight(name))
    if dot <= 0:
        return 0.0
    norm_c = math.sqrt(sum(v * v for v in candidate.values()))
    norm_p = math.sqrt(sum((v * weight(k)) ** 2 for k, v in profile_part.items()))
    if not norm_c or not norm_p:
        return 0.0
    return min(1.0, dot / (norm_c * norm_p))


def _year_affinity(year, profile_years):
    try:
        year = int(str(year or '')[:4])
    except (TypeError, ValueError):
        return 0.0
    if not year or not profile_years:
        return 0.0
    best = 0.0
    for value, weight in profile_years.items():
        try:
            other = int(str(value)[:4])
        except (TypeError, ValueError):
            continue
        distance = abs(year - other)
        if distance <= 2:
            best = max(best, weight)
        elif distance <= 6:
            best = max(best, weight * 0.5)
    top = max(profile_years.values()) or 1.0
    return min(1.0, best / top)


def _num(value):
    """The provider writes '-' for a title nobody has rated yet.

    float('-') raises, and this function is called from the scorer for every
    candidate, so one such row would take the whole build down. The catalogue
    reader normalises its own rows, but nothing guarantees every caller does.
    """
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def _best_rating(row):
    """The rating to judge by, and how many votes stand behind it."""
    imdb = _num(row.get('imdb_rating'))
    imdb_votes = _num(row.get('imdb_votes'))
    kp = _num(row.get('kp_rating'))
    kp_votes = _num(row.get('kp_votes'))
    if imdb and imdb_votes >= kp_votes:
        return imdb, imdb_votes
    if kp:
        return kp, kp_votes
    return imdb, imdb_votes


# A rating source is worth listening to once enough people have voted; below
# that a handful of votes says nothing either way.
FLOOR_MIN_VOTES = 100.0


def _floor_rating(row):
    """The rating the floor is judged by: the weakest credible source.

    Measured on post 102929 («Родина», 2015): the provider carries kp 6.079
    from 46229 votes and imdb 5.4 from 441. Judging by the louder source let it
    through a floor of 6.0, while the skin displayed 5.1 and 4.2 - so the owner
    saw a title below the floor they had set. Both sources are credible here, so
    the floor now has to be cleared by the lower of them.

    Returns (rating, credible) - credible is False when no source has enough
    votes to speak, which the caller decides what to do with.
    """
    known = []
    for rating_key, votes_key in (('imdb_rating', 'imdb_votes'),
                                  ('kp_rating', 'kp_votes')):
        try:
            rating = float(row.get(rating_key) or 0)
            votes = float(row.get(votes_key) or 0)
        except (TypeError, ValueError):
            continue
        if rating > 0 and votes >= FLOOR_MIN_VOTES:
            known.append(rating)
    if known:
        return min(known), True
    rating, _votes = _best_rating(row)
    return rating, False


def _people_counts(pairs):
    """Normalize {name: weight} so no single person can dominate."""
    total = float(sum(pairs.values())) or 1.0
    return dict((k, v / total) for k, v in pairs.items())


# The seen index is one full pass over the provider's cache (2.0 s measured for
# 16820 posts) and it does not depend on the category, yet movies and shows are
# built seconds apart - so the second build was paying for the same pass twice.
# Memoised for the length of one cycle, keyed on how much history exists, so a
# new watch still invalidates it.
_SEEN_MEMO = {'key': None, 'ts': 0, 'value': None}
SEEN_MEMO_TTL = 600


def build_seen_index(store, now=0, use_memo=True):
    """One catalogue pass over the titles already watched.

    The watched table records genres and countries but no people - it is built
    from what Kodi publishes on a row, and the provider does not put a cast
    there. The cast IS in the provider's own cache, so this walks it once and
    picks up, for every title in the history: its directors, its actors, and
    the related-post ids the provider itself attaches to it.

    Returns {'directors', 'actors', 'related', 'matched'} where `related` maps
    a post id to a weight, so a candidate that the provider considers similar
    to something recently watched can be recognised by id rather than by
    guessing from titles.
    """
    now = int(now or time.time())
    watched_keys = history.watched_keys()
    watched_parents = history.watched_parent_keys()
    if not watched_keys and not watched_parents:
        return {'directors': {}, 'actors': {}, 'related': {}, 'matched': 0, 'tags': {}}
    memo_key = (len(watched_keys), len(watched_parents))
    if (use_memo and _SEEN_MEMO['value'] is not None
            and _SEEN_MEMO['key'] == memo_key
            and now - _SEEN_MEMO['ts'] < SEEN_MEMO_TTL):
        return _SEEN_MEMO['value']

    # When each key was last watched, so an old favourite counts for less.
    recency = {}
    for row in history.recent_watched(limit=4000):
        weight = _recency_weight(row.get('last_watched'), now)
        for key in (row.get('item_key'), row.get('parent_key')):
            if key:
                recency[key] = max(recency.get(key, 0.0), weight)

    directors = {}
    actors = {}
    related = {}
    tags = {}
    matched = 0
    for row in catalog.iter_post_rows():
        key = identity.show_key(identity.clean_label(row.get('label')), row.get('year'))
        if not key or (key not in watched_keys and key not in watched_parents):
            continue
        matched += 1
        if row.get('genre'):
            tags[key] = (row.get('genre'), row.get('country') or '')
        weight = recency.get(key, 0.5)
        for name in _split(row.get('directors')):
            name = name.lower()
            directors[name] = directors.get(name, 0.0) + weight
        for name in _split(row.get('actors'))[:8]:
            # Only the billed cast: a long tail of bit parts is noise.
            name = name.lower()
            actors[name] = actors.get(name, 0.0) + weight
        for post_id in (row.get('relates') or []):
            related[post_id] = max(related.get(post_id, 0.0), weight)
    value = {'directors': _people_counts(directors), 'actors': _people_counts(actors),
             'related': related, 'matched': matched, 'tags': tags}
    _SEEN_MEMO.update({'key': memo_key, 'ts': now, 'value': value})
    return value


def abandoned_keys(store, now=0):
    """Titles started, left below a quarter, and not watched since.

    Progress rows only started being collected recently (0 rows at the time of
    writing), so this is wired and dormant rather than proven - it turns real
    the moment the monitor has data, and until then it simply finds nothing.
    """
    out = {}
    watched = history.watched_keys()
    for row in history.in_progress(limit=500):
        try:
            position = float(row.get('position') or 0)
            total = float(row.get('total') or 0)
        except (TypeError, ValueError):
            continue
        if total <= 0 or position <= 0:
            continue
        share = position / total
        key = str(row.get('item_key') or '')
        if not key or share > ABANDONED_MAX_SHARE:
            continue
        if key in watched:
            # Started, stopped, but later finished - not abandoned at all.
            continue
        out[key] = 1.0 - (share / ABANDONED_MAX_SHARE)
    return out


def _people_similarity(values, profile_part, limit=8):
    """Share of this title's people that the profile already likes, 0..1.

    Not cosine: a cast list has no meaningful magnitude to normalise against,
    and one strongly-liked director should count even when the other names are
    unknown.
    """
    if not profile_part:
        return 0.0
    names = [v.lower() for v in _split(values)][:limit]
    if not names:
        return 0.0
    best = max(profile_part.values()) or 1.0
    score = 0.0
    for name in names:
        score = max(score, profile_part.get(name, 0.0) / best)
    return min(1.0, score)


def _as_float(value, default=0.0):
    try:
        return float(str(value).strip().replace(',', '.'))
    except (TypeError, ValueError):
        return default


def _as_int(value, default=0):
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return default


def settings_filters():
    return {
        'preferred_genres': _lower_set(get_str('preferred_genres')),
        'blocked_genres': _lower_set(get_str('blocked_genres')),
        'excluded_countries': _lower_set(get_str('excluded_countries')),
        # Both are stored as text now (see settings.xml): an empty value means
        # "no limit", which is why neither reads through an int default.
        # Both are declared as plain strings in settings.xml because a select
        # dialog writes them, so they must be READ as strings: asking Kodi for
        # getSettingNumber/getSettingInt on a string setting makes it log
        # "EXCEPTION: Invalid setting type" once per plugin invocation - a real
        # error line for something that is not an error.
        'min_rating': _as_float(get_str('min_rating', ''), 0.0),
        'min_year': _as_int(get_str('min_year', ''), 0),
        'prefer_acclaimed': get_bool('prefer_acclaimed', False),
        'diversity': get_bool('diversity', True),
        'fresh_share': float(get_int('fresh_percent', int(FRESH_SHARE * 100))) / 100.0,
        'exclude_watched': get_bool('exclude_watched', True),
        'widget_size': get_int('widget_size', 30),
    }


def _source_signature():
    try:
        from .lanes import source_signature
        return source_signature()
    except Exception:
        return ''


def _signature(filters):
    """Fingerprint of everything that changes what the list should contain."""
    payload = json.dumps({
        'preferred': sorted(filters['preferred_genres']),
        'blocked': sorted(filters['blocked_genres']),
        'countries': sorted(filters['excluded_countries']),
        'min_rating': filters['min_rating'],
        'min_year': filters['min_year'],
        'acclaimed': filters['prefer_acclaimed'],
        'diversity': filters['diversity'],
        'fresh': round(filters['fresh_share'], 3),
        'exclude_watched': filters['exclude_watched'],
        'size': filters['widget_size'],
        'weights': 'v15-new-episodes-favourites',
        # другой источник - другой список: при смене источника рекомендации пересчитываются
        'source': _source_signature(),
    }, sort_keys=True, ensure_ascii=False)
    return hashlib.sha1(payload.encode('utf-8')).hexdigest()[:16]


def rejected_reason(row, filters, unknown_rating_ok=False):
    """Why this candidate cannot be recommended at all, or '' if it can.

    `unknown_rating_ok` is for the catalogue lanes: a brand-new release has no
    ratings yet, and hiding it from a "new releases" lane would misrepresent
    the catalogue. Recommendations keep the strict reading.
    """
    genres = _lower_set(row.get('genre'))
    if filters['blocked_genres'] and (genres & filters['blocked_genres']):
        return 'blocked_genre'
    countries = _lower_set(row.get('country'))
    if filters['excluded_countries'] and (countries & filters['excluded_countries']):
        return 'excluded_country'
    if filters['min_year'] > 0:
        try:
            year = int(str(row.get('year') or '')[:4])
        except (TypeError, ValueError):
            year = 0
        # An unknown year cannot be shown to satisfy a floor the owner set, so
        # it is treated the same as being below it.
        if year < filters['min_year']:
            return 'older_than_min_year'
    if filters['min_rating'] > 0:
        rating, credible = _floor_rating(row)
        # An unrated title is not "below the threshold" - it is unknown. With a
        # threshold set the owner asked for a floor, so unknown cannot pass a
        # recommendation; a catalogue lane says so by passing unknown_rating_ok.
        if not credible and unknown_rating_ok:
            return ''
        if rating < filters['min_rating']:
            return 'below_min_rating'
    return ''


def score_candidate(row, profile, filters, idf=None, seen=None,
                    abandoned=None, reasons=None):
    genres = row.get('genre')
    rating, votes = _best_rating(row)
    idf = idf or {}
    seen = seen or {}
    genre_idf = idf.get('genre') or {}
    country_idf = idf.get('country') or {}

    score = 0.0
    score += W_GENRE * _similarity(genres, profile.get('genres') or {}, genre_idf)
    score += W_COUNTRY * _similarity(row.get('country'), profile.get('countries') or {}, country_idf)
    score += W_YEAR_AFFINITY * _year_affinity(row.get('year'), profile.get('years') or {})
    score += W_RATING * min(1.0, max(0.0, rating / 10.0))
    score += W_LIKED_GENRE * _similarity(genres, profile.get('liked_genres') or {}, genre_idf)
    score += W_LIKED_COUNTRY * _similarity(row.get('country'), profile.get('liked_countries') or {}, country_idf)
    score -= W_ABANDONED_GENRE * _similarity(genres, profile.get('abandoned_genres') or {}, genre_idf)
    score -= W_DISLIKED_GENRE * _similarity(genres, profile.get('disliked_genres') or {}, genre_idf)
    score -= W_DISLIKED_COUNTRY * _similarity(row.get('country'), profile.get('disliked_countries') or {}, country_idf)

    if filters['preferred_genres']:
        if _lower_set(genres) & filters['preferred_genres']:
            score += W_PREFERRED_GENRE

    if filters['prefer_acclaimed'] and rating >= ACCLAIM_MIN_RATING and votes > 0:
        # Scaled by how far past the vote floor it is, capped - so a 9.5 with
        # 2.6M votes beats a 7.6 with 60k, without either running away.
        reach = min(1.0, votes / float(ACCLAIM_MIN_VOTES * 4))
        quality = min(1.0, (rating - ACCLAIM_MIN_RATING) / 2.0)
        score += W_ACCLAIM * (0.5 * reach + 0.5 * quality)

    label = identity.clean_label(row.get('label'))

    # --- wave 2 signals ---------------------------------------------------
    director_match = _people_similarity(row.get('directors'), seen.get('directors') or {})
    if director_match > 0:
        score += W_DIRECTOR * director_match
        top = _top_match(row.get('directors'), seen.get('directors') or {})
        _note(reasons, 'режиссёр %s' % top if top else 'знакомый режиссёр')
    actor_match = _people_similarity(row.get('actors'), seen.get('actors') or {})
    if actor_match > 0:
        score += W_ACTOR * actor_match
        top = _top_match(row.get('actors'), seen.get('actors') or {})
        _note(reasons, 'в ролях %s' % top if top else 'знакомые актёры')

    related = seen.get('related') or {}
    if related:
        post_number = row.get('post_number') or 0
        if post_number and post_number in related:
            score += W_RELATED * min(1.0, related[post_number])
            _note(reasons, 'похоже на то, что вы смотрели')

    if abandoned:
        key = identity.show_key(label, row.get('year'))
        weight = abandoned.get(key)
        if weight:
            score -= W_ABANDONED_PENALTY * weight
            _note(reasons, 'вы это бросили')
    return score


def _note(reasons, text):
    """Collect why an item scored, so the list can explain itself."""
    if reasons is not None and text and text not in reasons:
        reasons.append(text)


# The reasons are stored in Russian - in the local cache and in the list shared
# between boxes - so they are translated only when shown, never rewritten.
_REASON_IDS = {
    'этот сериал вы уже смотрите': 31947,
    'знакомый режиссёр': 31949,
    'знакомые актёры': 31951,
    'похоже на то, что вы смотрели': 31952,
    'вы это бросили': 31953,
}
_REASON_PREFIX_IDS = (('режиссёр ', 31948), ('в ролях ', 31950))


def display_reason(text):
    """A stored reason in Kodi's language (Russian Kodi: unchanged)."""
    from ..l10n import is_russian, tr
    text = str(text or '')
    if not text or is_russian():
        return text
    string_id = _REASON_IDS.get(text)
    if string_id:
        return tr(string_id) or text
    for prefix, string_id in _REASON_PREFIX_IDS:
        if text.startswith(prefix):
            template = tr(string_id)
            return template % text[len(prefix):] if template else text
    return text


def _top_match(values, profile_part):
    """The single name from this title that the profile likes most."""
    best_name = ''
    best_value = 0.0
    for name in _split(values):
        value = (profile_part or {}).get(name.lower(), 0.0)
        if value > best_value:
            best_value = value
            best_name = name
    return best_name


def _build(category, filters):
    """Compute the list locally. Bounded, synchronous, no network."""
    store = db()
    if category == 'movies':
        rows = history.recent_watched(limit=PROFILE_SAMPLE, mediatype='movie')
    else:
        rows = history.recent_watched(limit=PROFILE_SAMPLE, mediatype='tvshow')
        rows += history.recent_watched(limit=PROFILE_SAMPLE, mediatype='episode')
    if not rows:
        rows = history.recent_watched(limit=PROFILE_SAMPLE)
    liked = store.feedback_rows(kind='like', limit=PROFILE_SAMPLE)
    disliked = store.feedback_rows(kind='dislike', limit=PROFILE_SAMPLE)
    seen = build_seen_index(store)
    # жанры и страны строк без своих (Elementum, RuTor, просмотры по имени) - из поста источника
    # с тем же названием и годом: иначе эти просмотры не учат профиль вовсе
    tags = seen.get('tags') or {}
    for row in rows:
        if row.get('genres'):
            continue
        tag = tags.get(row.get('item_key')) or tags.get(row.get('parent_key'))
        if tag:
            row['genres'], row['countries'] = tag
    try:
        episode_counts = history.watched_episode_counts() if category != 'movies' else None
    except Exception:
        episode_counts = None
    profile = build_profile(rows, liked_rows=liked, disliked_rows=disliked,
                            episode_counts=episode_counts)
    # One lookup, reused for every candidate: the frequencies were counted by
    # the vocabulary pass, so this costs nothing here.
    busy = lanes_busy()
    df_counts, df_total = catalog.document_frequencies()
    idf = {'genre': _idf_table('genre', df_counts, df_total),
           'country': _idf_table('country', df_counts, df_total)}
    abandoned = abandoned_keys(store)

    watched = _watched()
    disliked_keys = store.feedback_keys('dislike')

    # Streamed, and only the top `widget_size` is ever held: the catalogue is
    # ~17k rows and materialising it was memory pressure these boxes could not
    # take - both went into safe mode under it.
    want = max(1, int(filters['widget_size']))
    # Score a wider pool than the list needs: diversity and the freshness
    # quota can only choose among candidates that were kept.
    keep = want * RERANK_POOL_FACTOR
    scored = []
    dropped = {}
    considered = 0
    followed = []
    for row in catalog.iter_candidates(category):
        considered += 1
        label = identity.clean_label(row.get('label'))
        if not label:
            continue
        key = identity.show_key(label, row.get('year'))
        if key and key in disliked_keys:
            dropped['disliked'] = dropped.get('disliked', 0) + 1
            continue
        if filters['exclude_watched'] and _is_watched(key, watched):
            dropped['watched'] = dropped.get('watched', 0) + 1
            if category != 'movies' and row.get('post_id') and len(followed) < NEW_EPISODES_POOL:
                followed.append((key, row))
            continue
        if filters['exclude_watched'] and row.get('playcount'):
            dropped['watched'] = dropped.get('watched', 0) + 1
            continue
        reason = rejected_reason(row, filters)
        if reason:
            dropped[reason] = dropped.get(reason, 0) + 1
            continue
        reasons = []
        score = score_candidate(row, profile, filters, idf=idf,
                                seen=seen, abandoned=abandoned, reasons=reasons)
        row['_reasons'] = reasons[:3]
        # A bounded min-heap: the weakest kept entry sits at the root, so a new
        # row only has to beat that one to get in.
        if len(scored) < keep:
            heapq.heappush(scored, (score, considered, row))
        elif score > scored[0][0]:
            heapq.heapreplace(scored, (score, considered, row))

    busy.done()
    ranked = sorted(scored, key=lambda triple: triple[0], reverse=True)
    # Один фильм бывает у источника двумя постами (разные релизы: «Подделка» 185532 и
    # 185540 стояли в рекомендациях рядом, .20, 21.11.2026) - в список идёт лучший
    unique, taken = [], set()
    for triple in ranked:
        key = _item_key(triple[2])
        if key and key in taken:
            continue
        taken.add(key)
        unique.append(triple)
    ranked = unique
    fresh_shows = _new_episode_rows(followed, episode_counts, rows, filters)
    if fresh_shows:
        top = ranked[0][0] if ranked else 0.0
        fresh_keys = set(_item_key(r) for r in fresh_shows)
        ranked = [t for t in ranked if _item_key(t[2]) not in fresh_keys]
        ranked = [(top + 1.0 + i * 0.01, -1 - i, r) for i, r in enumerate(reversed(fresh_shows))][::-1] + ranked
    chosen = _rerank(ranked, want, filters)

    items = []
    for score, _seq, row in chosen:
        rating, votes = _best_rating(row)
        entry = {
            'label': identity.clean_label(row.get('label')),
            'file': row.get('file') or '',
            'year': row.get('year'),
            'plot': row.get('plot') or '',
            'genre': _split(row.get('genre')),
            'country': _split(row.get('country')),
            'mediatype': row.get('mediatype') or ('movie' if category == 'movies' else 'tvshow'),
            'filetype': row.get('filetype') or 'file',
            '_score': round(float(score), 3),
            '_reasons': row.get('_reasons') or [],
            # The provider's own post id: the skin resolves a row far faster
            # when it is told which post this is than when it has to search a
            # title blind.
            'post_id': str(row.get('post_id') or ''),
        }
        poster = row.get('poster') or ''
        if poster:
            entry['art'] = {'poster': poster, 'thumb': poster}
        elif row.get('art'):
            entry['art'] = dict(row['art'])
        title = identity.clean_label(row.get('title')) or entry['label']
        if title:
            entry['title'] = title
        original = (row.get('originaltitle') or '').strip()
        if original:
            entry['originaltitle'] = original
        if rating > 0:
            entry['rating'] = rating
        if votes > 0:
            entry['votes'] = int(votes)
        entry['_release'] = _release_key(row)
        if row.get('_new_episodes'):
            entry['new_episodes'] = int(row['_new_episodes'])
        items.append(entry)
    # Порядок показа: первые TOP_BY_SCORE - лучшие совпадения в порядке отбора, остальные - по
    # выходу, новое первым (счёт решает, КТО попал в список, дата - порядок хвоста)
    head = items[:TOP_BY_SCORE]
    tail = sorted(items[TOP_BY_SCORE:], key=lambda entry: entry.get('_release'), reverse=True)
    items = head + tail
    for entry in items:
        entry.pop('_release', None)

    log('build %s: профиль=%d строк -> %d тайтлов (нравится=%d, idf=%d жанров,'
        ' люди: %d реж./%d актёров из %d тайтлов, похожих=%d, брошено=%d),'
        ' кандидатов=%d, отброшено=%s, отобрано=%d'
        % (category, profile.get('sample') or 0, profile.get('titles') or 0,
           profile.get('liked_sample') or 0, len(idf.get('genre') or {}),
           len(seen.get('directors') or {}), len(seen.get('actors') or {}),
           seen.get('matched') or 0, len(seen.get('related') or {}), len(abandoned),
           considered,
           ','.join('%s:%d' % kv for kv in sorted(dropped.items())) or 'нет',
           len(items)))
    if items:
        log('%s: сверху "%s" (%s)' % (
            category, items[0].get('label') or '?',
            '; '.join(items[0].get('_reasons') or ['по совпадению вкуса'])))
    return items


def _new_episode_rows(followed, episode_counts, rows, filters, now=0):
    """Свои сериалы (просмотрено не меньше половины), у которых серий у источника больше, чем
    вы видели, и которые не смотрятся прямо сейчас. Один запрос к кэшу источника на всех."""
    if not followed or not episode_counts:
        return []
    # просматриваемый сериал - только из «Избранного» источника (владелец 25.11.2026)
    try:
        favourites = set(str(pid) for pid in catalog.provider_personal_ids().get('favorites') or ())
    except Exception:
        favourites = set()
    followed = [(key, row) for key, row in followed if str(row.get('post_id') or '') in favourites]
    if not followed:
        return []
    now = int(now or time.time())
    last = {}
    for row in rows or []:
        parent = str(row.get('parent_key') or '')
        if parent:
            try:
                last[parent] = max(last.get(parent, 0), int(row.get('last_watched') or 0))
            except (TypeError, ValueError):
                pass
    try:
        totals = catalog.episode_totals([row.get('post_id') for _key, row in followed])
    except Exception:
        totals = {}
    # Просмотренное - в том же посте, из которого берётся число серий: под одним названием и
    # годом у источника бывает несколько постов (Filmix «Реальные пацаны» 2010: 7661 - 39 серий,
    # 28082 - 13-й сезон, просмотрено 35), и не начатый пост вставал первым «вышли новые серии»
    # (.20, 25.11.2026), вытесняя «Радар» 5 из 9.
    prefixes = {}
    for _key, row in followed:
        # путь поста Filmix (.../serials/<id>-): серии этого поста начинаются так же; у других
        # источников путь сериала и пути серий устроены иначе - там прежний счёт по названию
        hit = re.match(r'^(.*?/serials/\d+-)', str(row.get('file') or ''))
        if hit:
            prefixes[str(row.get('post_id'))] = hit.group(1)
    try:
        in_post = history.watched_episode_counts_in(list(prefixes.values()))
    except Exception:
        in_post = {}
    out = []
    for key, row in followed:
        prefix = prefixes.get(str(row.get('post_id')))
        seen = int((in_post.get(prefix) if prefix else episode_counts.get(key)) or 0)
        total = int(totals.get(str(row.get('post_id'))) or 0)
        if seen <= 0 or total <= seen or seen < total * NEW_EPISODES_MIN_SHARE:
            continue
        if last.get(key) and (now - last[key]) < NEW_EPISODES_IDLE_DAYS * 86400:
            continue
        if rejected_reason(row, filters):
            continue
        row = dict(row)
        row['_new_episodes'] = total
        row['_reasons'] = ['вышли новые серии']
        out.append((total - seen, row))
    out.sort(key=lambda pair: pair[0], reverse=True)
    return [row for _n, row in out[:NEW_EPISODES_MAX]]


def _still_new(item, counts):
    """Карточка «вышли новые серии» показывается, пока вы не досмотрели вышедшее. Просмотренное -
    в том же посте, что и число серий (см. _new_episode_rows)."""
    try:
        hit = re.match(r'^(.*?/serials/\d+-)', str(item.get('file') or ''))
        if hit:
            seen = history.watched_episode_counts_in([hit.group(1)]).get(hit.group(1), 0)
        else:
            seen = counts.get(_item_key(item))
        return int(seen or 0) < int(item.get('new_episodes') or 0)
    except (TypeError, ValueError):
        return False


def _hidden_watched(item, watched, counts):
    if item.get('new_episodes'):
        return not _still_new(item, counts)
    return _is_watched(_item_key(item), watched)


def _row_genre_set(row):
    return set(v.lower() for v in _split(row.get('genre')))


def _rerank(ranked, want, filters):
    """Pick the final list: best first, but not the same thing forty times.

    Two departures from pure score order, both deliberate and both bounded:

    * diversity - each candidate is penalised for how much it repeats the
      genres of what has already been picked (maximal marginal relevance). The
      first pick is untouched, so the strongest match always leads.
    * freshness - a fifth of the slots are reserved for the newest entries in
      the catalogue that still pass every filter and still match the taste
      profile. `post_number` is the provider's own post id, which grows with
      time, so "newest" needs no date parsing (the catalogue's `date` field is
      a human string like "Сегодня, 13:29").

    Returns the chosen [(score, seq, row)] in display order.
    """
    if not ranked:
        return []
    strength = DIVERSITY_STRENGTH if filters.get('diversity', True) else 0.0
    fresh_share = float(filters.get('fresh_share') or 0.0)
    fresh_slots = int(want * fresh_share) if fresh_share > 0 else 0

    pool = list(ranked)
    chosen = []
    seen_genres = {}

    # Freshness first, so the newest picks are chosen from the full pool
    # rather than from whatever the diversity pass happened to leave.
    if fresh_slots:
        # When the provider added it, from its own date_atom (ISO 8601, present
        # on every post). post_number is only the fallback: post ids track
        # creation order, and the provider's listing leads with re-uploads.
        by_recency = sorted(
            pool,
            key=lambda t: (t[2].get('added_ts') or 0, t[2].get('post_number') or 0),
            reverse=True)
        for triple in by_recency[:fresh_slots]:
            chosen.append(triple)
            for genre in _row_genre_set(triple[2]):
                seen_genres[genre] = seen_genres.get(genre, 0) + 1
        picked = set(id(t) for t in chosen)
        pool = [t for t in pool if id(t) not in picked]

    while pool and len(chosen) < want:
        best_index = 0
        best_value = None
        for index, (score, seq, row) in enumerate(pool):
            if strength and seen_genres:
                genres = _row_genre_set(row)
                if genres:
                    repeat = sum(seen_genres.get(g, 0) for g in genres) / float(len(genres))
                    penalty = strength * min(1.0, repeat / 3.0)
                else:
                    penalty = 0.0
                value = score * (1.0 - penalty)
            else:
                value = score
            if best_value is None or value > best_value:
                best_value = value
                best_index = index
        triple = pool.pop(best_index)
        chosen.append(triple)
        for genre in _row_genre_set(triple[2]):
            seen_genres[genre] = seen_genres.get(genre, 0) + 1

    # Score order here; the display order (by release) is set by _build.
    return sorted(chosen, key=lambda triple: triple[0], reverse=True)


def _release_key(row):
    """Порядок списка - по году выхода; на экране ряд сортирует Kodi по раскладке виджетов
    (фильмы - год, сериалы - дата последней серии из сведений строки, hub/routes.py)."""
    return _as_int(row.get('year'))


def _watched():
    """(просмотренное и начатое, начатые и просмотренные сериалы). Начатое живёт в
    «Продолжить просмотр», в рекомендациях ему не место: «Гангстерленд» с одной начатой
    серией HDRezka стоял в рекомендациях сериалов (.20, 21.11.2026)."""
    return (history.watched_keys() | set(history.progress_map()),
            history.started_shows())


def _is_watched(key, watched):
    """Просмотрен фильм или сериал. У сериала в истории просмотрены СЕРИИ, и ключ сериала
    у них родительский: без второй проверки начатые и досмотренные сериалы проходили отсев
    («Тяжёлый люкс», «Полураспад» в рекомендациях, .20, 21.11.2026)."""
    keys, parents = watched
    return bool(key) and (key in keys or key in parents)


def _item_key(item):
    return identity.show_key(identity.clean_label(item.get('label')), item.get('year'))


def _usable(items, filters):
    """Готовый список годится в показ, только если в нём нет служебных пунктов и нет уже
    просмотренного. Список собирается по расписанию, а смотрят между сборками: «Престиж»,
    «Вавилон», «Терминал» отмечены просмотренными в 17:54-18:02, а список 17:52 показывался
    с ними до следующей плановой сборки (.20, 21.11.2026). Такой список не ответ - он
    собирается заново, как пустой."""
    items = _real(items)
    if not items:
        return items
    if filters['exclude_watched']:
        watched = _watched()
        counts = _episode_counts_if_needed(items)
        if any(_hidden_watched(item, watched, counts) for item in items):
            return None
    return items


def _store_local(category, items, signature):
    store = db()
    store.set_flag(CACHE_FLAG % category, json.dumps(items, ensure_ascii=False))
    store.set_flag(CACHE_TS_FLAG % category, str(int(time.time())))
    store.set_flag(CACHE_SIG_FLAG % category, signature)


def _local(category):
    store = db()
    raw = store.get_flag(CACHE_FLAG % category)
    if not raw:
        return None, 0, ''
    try:
        items = json.loads(raw)
    except Exception:
        return None, 0, ''
    if not isinstance(items, list):
        return None, 0, ''
    try:
        ts = int(store.get_flag(CACHE_TS_FLAG % category) or 0)
    except (TypeError, ValueError):
        ts = 0
    return items, ts, store.get_flag(CACHE_SIG_FLAG % category) or ''


BLOCKED_FLAG = 'recommend_blocked_at_%s'
BLOCKED_COOLDOWN = 900


def blocked_recently(category):
    """True while a failed attempt is still cooling down."""
    try:
        last = int(db().get_flag(BLOCKED_FLAG % category) or 0)
    except (TypeError, ValueError):
        return False
    return bool(last) and int(time.time()) - last < BLOCKED_COOLDOWN


def refresh_category(category, force=False):
    """Build the list and publish it to the shared server, so every box shows
    the same one. Returns the items."""
    filters = settings_filters()
    signature = _signature(filters)
    if not force and sync.enabled():
        # Someone else may have built it already since this box last looked.
        shared = sync.fetch_recommend(category)
        ready = (_usable(shared.get('items'), filters)
                 if shared and shared.get('signature') == signature else None)
        if ready:
            _store_local(category, ready, signature)
            log('%s: беру готовый список с сервера (собрал %s)'
                % (category, shared.get('built_by') or '?'))
            return ready
        if shared and shared.get('items') and shared.get('signature') != signature:
            # Say what is actually wrong. Measured on <коробка>: its blocked
            # genres held two entries fewer than <коробка>'s, so each box
            # refused the other's list and rebuilt its own every minute -
            # visible only as "another box is building it", which is not what
            # was happening at all.
            log('%s: настройки боксов расходятся, общий список не подходит '
                '(сервер=%s, здесь=%s, собрал %s)'
                % (category, shared.get('signature'), signature,
                   shared.get('built_by') or '?'))
        if not sync.claim('recommend_%s' % category):
            log('%s: список сейчас собирает другой бокс' % category)
            items, _ts, sig = _local(category)
            items = _usable(items, filters) if sig == signature else None
            if items:
                return items
            # Nothing usable and no right to build: remember the attempt so the
            # service does not come back a minute later and repeat the whole
            # round trip. A rebuild is worth an hour of patience, not a minute.
            db().set_flag(BLOCKED_FLAG % category, str(int(time.time())))
    items = _real(_build(category, filters))
    _store_local(category, items, signature)
    db().set_flag(BLOCKED_FLAG % category, '0')
    if sync.enabled():
        sync.publish_recommend(category, items, signature, instance_id())
    return items


def _real(items):
    """Без служебных пунктов дополнений («Войти в аккаунт …»): список, собранный гостем,
    мог состоять только из них - такой список не ответ, он собирается заново."""
    from .mirror import is_navigation
    return [item for item in (items or []) if not is_navigation(item)]


def get_widget_items(category, max_age_seconds):
    """Never block a directory listing on a rebuild except the very first time.

    Order of preference: the shared server copy (so all boxes match), then this
    box's own copy, then a synchronous build. A stored list is shown without
    what was watched after it was built, and is_stale() sends it to the service
    for a full rebuild. Building here instead left the row empty: Kodi drops the
    listing when the owner moves on, and the service waits while the remote is
    busy (.20, 21.11.2026, 3.2.9.498.0).
    """
    filters = settings_filters()
    signature = _signature(filters)
    stored = None
    if sync.enabled():
        shared = sync.fetch_recommend(category)
        if shared and shared.get('items'):
            if shared.get('signature') == signature:
                _store_local(category, shared['items'], signature)
                if int(time.time()) - int(shared.get('updated_ts') or 0) >= max_age_seconds:
                    log('%s: общий список устарел, отдаю до планового обновления' % category)
            stored = shared['items']
    if stored is None:
        items, ts, sig = _local(category)
        if items:
            if sig == signature and int(time.time()) - ts >= max_age_seconds:
                log('%s: локальный кэш устарел, отдаю до планового обновления' % category)
            stored = items
    shown = _visible(stored, filters)
    # Пустой сохранённый список - не ответ: он мог собраться, когда сети не было
    # (15.11.2026 на .20 сериалы HDrezka собрались при отказах Network Freedom и
    # оставались пустыми до планового обновления). Такой список собирается заново.
    if shown:
        return shown
    log('%s: готового списка нет, разовое синхронное построение' % category)
    return refresh_category(category)


def _visible(items, filters):
    """Сохранённый список в показ: без служебных пунктов и без просмотренного после сборки."""
    items = _real(items)
    if items and filters['exclude_watched']:
        watched = _watched()
        counts = _episode_counts_if_needed(items)
        items = [item for item in items if not _hidden_watched(item, watched, counts)]
    return items


def _episode_counts_if_needed(items):
    if not any(item.get('new_episodes') for item in items or []):
        return {}
    try:
        return history.watched_episode_counts()
    except Exception:
        return {}


def is_stale(category, max_age_seconds):
    filters = settings_filters()
    signature = _signature(filters)
    if sync.enabled():
        shared = sync.fetch_recommend(category)
        if shared and shared.get('items'):
            if shared.get('signature') != signature:
                return True
            if _usable(shared['items'], filters) is None:
                return True
            return int(time.time()) - int(shared.get('updated_ts') or 0) >= max_age_seconds
    items, ts, sig = _local(category)
    if items is None or sig != signature:
        return True
    if items and _usable(items, filters) is None:
        return True
    return int(time.time()) - ts >= max_age_seconds
