# -*- coding: utf-8 -*-
"""Название ролика и его канал YouTube - для строк, у которых их нет.

Kodi их не отдаёт: строки роликов приходят из `Files.GetDirectory` без типа, а в базе
просмотров Kodi у ролика только адрес. Инфо-строка скина показывает канал чипом из
`ListItem.Studio`, пункт «Перейти к каналу» и аватар в углу ведут по `channel_id`,
«Продолжить просмотр» в хабе YouTube подписывает ролик его названием.

Откуда берётся (plugin.video.youtube 8, с 26.11.2026). У дополнения 7 был data_cache.sqlite с
ответами Data API (snippet.channelTitle, channelId, title) - его читали отсюда. В 8 такого кэша
нет: дополнение хранит только описания просмотренных роликов (descriptions.json, в них есть
id канала - 'c'). Поэтому:
  1. свой кэш скина (YOUTUBE_VIDEOS) - однажды узнанное не меняется;
  2. id канала - из descriptions.json дополнения, если ролик там есть;
  3. недостающее - запрос player внутреннего интерфейса сайта (без ключа и входа: videoDetails
     title, author, channelId), не больше FETCH_LIMIT роликов за вызов, параллельно.
"""
from __future__ import absolute_import, unicode_literals

import io
import json
import os
import threading
import time

import xbmc

try:
    import xbmcvfs
except Exception:  # pragma: no cover - вне Kodi
    xbmcvfs = None

from ..sublime_helper.config import youtube_video_id

YOUTUBE_VIDEOS = 'special://profile/addon_data/skin.sublime/youtube_videos.json'
DESCRIPTIONS = 'special://profile/addon_data/plugin.video.youtube/descriptions.json'
PLAYER_URL = 'https://www.youtube.com/youtubei/v1/player?prettyPrint=false'
TIMEOUT = 8.0
FETCH_LIMIT = 40
FETCH_WORKERS = 6
KEEP = 6000
# Неудачный запрос (сеть, удалённый ролик) повторяется не раньше, чем через столько.
RETRY_AFTER = 6 * 3600

_LOCK = threading.Lock()
_STORE = {'data': None, 'descriptions': None, 'desc_mtime': 0}
_FAILED = {}


def _log(message, level=xbmc.LOGDEBUG):
    try:
        xbmc.log('[sublime youtube] %s' % message, level)
    except Exception:
        pass


def _translate(path):
    try:
        if xbmcvfs is not None:
            return xbmcvfs.translatePath(path)
    except Exception:
        pass
    return path


def video_id(path):
    """Идентификатор ролика из адреса строки (play?v= дополнения 8 и play/?video_id= 7), или ''."""
    return youtube_video_id(path)


def _load():
    if _STORE['data'] is None:
        try:
            with io.open(_translate(YOUTUBE_VIDEOS), encoding='utf-8') as fh:
                data = json.load(fh)
            _STORE['data'] = data if isinstance(data, dict) else {}
        except Exception:
            _STORE['data'] = {}
    return _STORE['data']


def _save():
    data = _STORE['data'] or {}
    if len(data) > KEEP:
        for key in sorted(data, key=lambda k: data[k].get('ts', 0))[:len(data) - KEEP]:
            data.pop(key, None)
    path = _translate(YOUTUBE_VIDEOS)
    try:
        tmp = path + '.tmp'
        with io.open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception as exc:
        _log('кэш роликов не записан: %s' % exc, xbmc.LOGWARNING)


def _descriptions():
    """{ролик: id канала} из descriptions.json дополнения (перечитывается, когда файл изменился)."""
    path = _translate(DESCRIPTIONS)
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return {}
    if _STORE['descriptions'] is None or mtime != _STORE['desc_mtime']:
        try:
            with io.open(path, encoding='utf-8') as fh:
                videos = (json.load(fh) or {}).get('videos') or {}
            _STORE['descriptions'] = dict((k, str(v.get('c') or '')) for k, v in videos.items()
                                          if isinstance(v, dict) and v.get('c'))
        except Exception:
            _STORE['descriptions'] = {}
        _STORE['desc_mtime'] = mtime
    return _STORE['descriptions']


def _fetch(vid):
    """{'t': название, 'c': канал, 'cid': id канала} из player сайта, или None."""
    import urllib.request
    from .youtube_trending import _region
    region = _region()
    body = {'context': {'client': {'clientName': 'WEB', 'clientVersion': '2.20251110.01.00',
                                   'hl': 'ru' if region == 'RU' else 'en', 'gl': region}},
            'videoId': vid}
    request = urllib.request.Request(
        PLAYER_URL, data=json.dumps(body).encode('utf-8'),
        headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0',
                 'Origin': 'https://www.youtube.com'})
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT) as answer:
            details = (json.loads(answer.read().decode('utf-8')) or {}).get('videoDetails') or {}
    except Exception:
        return None
    title = str(details.get('title') or '')
    if not title:
        return None
    return {'t': title, 'c': str(details.get('author') or ''), 'cid': str(details.get('channelId') or '')}


def known(video_ids, fetch=True):
    """{ролик: {'t', 'c', 'cid'}} - из кэша, описаний дополнения и (fetch) сети."""
    wanted = [v for v in dict.fromkeys(video_ids) if v]
    if not wanted:
        return {}
    with _LOCK:
        data = _load()
        result = dict((v, data[v]) for v in wanted if v in data)
    missing = [v for v in wanted if v not in result]
    if missing and fetch:
        now = time.time()
        todo = [v for v in missing if _FAILED.get(v, 0) < now][:FETCH_LIMIT]
        if todo:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(max_workers=min(FETCH_WORKERS, len(todo))) as pool:
                answers = list(pool.map(_fetch, todo))
            fresh = {}
            for vid, info in zip(todo, answers):
                if info:
                    info['ts'] = int(now)
                    fresh[vid] = info
                else:
                    _FAILED[vid] = now + RETRY_AFTER
            if fresh:
                with _LOCK:
                    _load().update(fresh)
                    _save()
                result.update(fresh)
    desc = _descriptions()
    for vid in wanted:
        if vid not in result and desc.get(vid):
            result[vid] = {'t': '', 'c': '', 'cid': desc[vid]}
    return result


def channel_info(video_ids, fetch=True):
    """{ролик: (название канала, id канала)}."""
    out = {}
    for vid, info in known(video_ids, fetch).items():
        if info.get('c') or info.get('cid'):
            out[vid] = (info.get('c') or '', info.get('cid') or '')
    return out


def channel_titles(video_ids):
    """{ролик: название канала}."""
    return dict((k, v[0]) for k, v in channel_info(video_ids).items() if v[0])


def channel_id(vid):
    """id канала ролика без запросов в сеть (кэш и описания дополнения) - для службы на фокусе."""
    info = known([vid], fetch=False).get(vid) or {}
    return info.get('cid') or ''


def video_titles(video_ids):
    """{ролик: название ролика} - для «Продолжить просмотр» в хабе YouTube."""
    return dict((k, v['t']) for k, v in known(video_ids).items() if v.get('t'))


def fill_channels(rows):
    """Проставить строкам YouTube название и id канала. Возвращает, скольким проставили."""
    if not rows:
        return 0
    ids = {}
    for row in rows:
        if not isinstance(row, dict) or (row.get('studio') and row.get('channel_id')):
            continue
        key = video_id(row.get('file'))
        if key:
            ids.setdefault(key, []).append(row)
    if not ids:
        return 0
    found = channel_info(list(ids))
    filled = 0
    for key, targets in ids.items():
        title, channel = found.get(key) or ('', '')
        for row in targets:
            if title and not row.get('studio'):
                row['studio'] = title
                filled += 1
            if channel and not row.get('channel_id'):
                row['channel_id'] = channel
    if filled:
        _log('название канала проставлено строкам: %d из %d' % (filled, len(ids)), xbmc.LOGINFO)
    return filled
