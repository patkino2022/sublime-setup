"""HLS -> continuous MPEG-TS, the body pvr.tvlink feeds to Kodi's demuxer.

Both owner's providers serve plain TS segments: Edem a media playlist,
Glanz (Flussonic) a redirect to a master playlist with one variant.
Encrypted or fMP4 streams are refused so the streamer moves to the next source.

Switch speed: the media-playlist URL a live link resolves to (after redirect
and master) is remembered, so the next start of that channel - or of a
neighbour warmed in advance - skips two round trips.
"""
import http.client
import re
import threading
import time
from urllib.parse import urljoin

from . import net

RESOLVED_TTL = 900
_resolved, _res_lock = {}, threading.Lock()


class StreamDead(Exception):
    pass


class Refused(StreamDead):
    """The source said no (401/403/404/410): waiting will not help."""


class ClientGone(Exception):
    pass


REFUSED = (401, 403, 404, 410)
ARCHIVE_LEAD = 60.0
LIVE_LEAD = 10.0          # seconds behind live at start, at least live_edge segments

# Null TS packets (PID 0x1FFF), dropped by every demuxer. Sent whenever nothing
# else went out for KEEPALIVE_EVERY: Kodi's player thread reads the stream and,
# with nothing to read, sits in that read when the channel is stopped (Glanz,
# 19.10.2026: CloseFile -> CloseLiveStream 1.17 s). Between playlist polls was
# not enough: 20.10.2026 Kodi waited 1.65 s in ppoll on our socket while we were
# fetching Glanz's playlist / opening a segment, switches took 1.7-7.4 s away
# from Glanz and Edem channels. So a pump thread covers every wait on upstream.
NULL_TS = (b"\x47\x1f\xff\x10" + b"\xff" * 184) * 2
KEEPALIVE_EVERY = 0.2
TS_PACKET = 188

# Segments go out at the pace of the picture, not as one burst. Official
# CoreELEC's Kodi (no AlexELEC kodi-022 async-channel-switch / kodi-063
# curl-abort-wakeup) finishes reading a whole frame of the old channel before it
# switches: with a 5 s Glanz segment sent in 0.3 s and then only null packets,
# that read waited for the next segment - 20.10.2026 switches took 0.1-10 s.
# Up to PACE_LEAD seconds of picture may go out ahead, the rest follows the
# clock. It must stay well under LIVE_LEAD: with 12 s the relay caught up with the
# live edge in seconds and every new segment went out as a burst again.
PACE_LEAD = 3.0
PACE_SLICE = TS_PACKET * 64


def _pace_lead():
    """None when Kodi with AlexELEC's patches is mounted over the official one
    (sublime-box ae-kodi): it switches at once by itself, and with only 3 s ahead
    its realtime buffering never started RTS 1 through a 7-13 s source stall
    (20.10.2026). Official Kodi gets the paced stream."""
    try:
        with open("/proc/mounts") as f:
            if " /usr/lib/kodi/kodi.bin " in f.read():
                return None
    except OSError:
        pass
    return PACE_LEAD


NET_ERRORS = (OSError, http.client.HTTPException, ValueError)


def _parse_media(text, base):
    seq, target, ended, segs, dur = 0, 6.0, False, [], None
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("#EXT-X-MEDIA-SEQUENCE:"):
            seq = int(line.split(":", 1)[1] or 0)
        elif line.startswith("#EXT-X-TARGETDURATION:"):
            target = float(line.split(":", 1)[1] or 6)
        elif line.startswith("#EXT-X-ENDLIST"):
            ended = True
        elif line.startswith("#EXT-X-KEY:") and "METHOD=NONE" not in line:
            raise StreamDead("encrypted HLS")
        elif line.startswith("#EXT-X-MAP:"):
            raise StreamDead("fMP4 HLS")
        elif line.startswith("#EXTINF:"):
            try:
                dur = float(line[8:].split(",", 1)[0])
            except ValueError:
                dur = target
        elif line and not line.startswith("#"):
            segs.append((seq + len(segs), urljoin(base, line), dur or target))
            dur = None
    return segs, target, ended


def _pick_variant(text, base):
    best, bw, want, cur = None, -1, False, 0
    for raw in text.splitlines():
        line = raw.strip()
        if line.startswith("#EXT-X-STREAM-INF:"):
            want, cur = True, 0
            for part in line[18:].split(","):
                if part.startswith("BANDWIDTH="):
                    try:
                        cur = int(part[10:])
                    except ValueError:
                        pass
        elif want and line and not line.startswith("#"):
            if cur > bw:
                best, bw = urljoin(base, line), cur
            want = False
    return best


def resolve_media(url, ua, timeout):
    """url -> (media playlist text, its final url). Remembers the answer."""
    text, base = net.get_text(url, ua, timeout)
    if "#EXT-X-STREAM-INF" in text:
        media = _pick_variant(text, base)
        if not media:
            raise StreamDead("empty master playlist")
        text, base = net.get_text(media, ua, timeout)
    if "#EXTM3U" in text[:64]:
        with _res_lock:
            _resolved[url] = (base, time.time())
    return text, base


def warm(url, ua, timeout):
    """Resolve a live link ahead of a switch; errors are irrelevant here."""
    try:
        resolve_media(url, ua, timeout)
    except Exception:
        pass


def forget(url):
    with _res_lock:
        _resolved.pop(url, None)


class Relay:
    """Writes one upstream URL into `out` until it dies, ends, or the client leaves."""

    def __init__(self, url, cfg, out, log, alive, live=True, headers=None):
        self.url, self.cfg, self.out, self.log, self.alive = url, cfg, out, log, alive
        self.live = live
        self.ua = dict({"User-Agent": cfg["user_agent"]}, **(headers or {}))
        self.timeout = cfg["timeout"]
        self.sent_seconds = 0.0   # media time delivered, for resuming archive elsewhere
        self.sent_bytes = 0
        # Writes go out in whole TS packets only (the tail waits in _pending), so
        # the pump can put a null packet between any two writes without cutting
        # a packet in half. _aligned drops when a source hands over a segment
        # that is not a multiple of 188 bytes; the pump then waits for the next one.
        self._wlock = threading.Lock()
        self._pending = b""
        self._aligned = True
        self._last_out = time.time()
        self._gone = False
        self._clock0 = None       # wall time the delivered picture is measured from
        self._media = 0.0         # seconds of picture delivered
        self._lead = _pace_lead()

    def _write(self, chunk):
        with self._wlock:
            if self._gone:
                raise ClientGone()
            data = self._pending + chunk
            cut = len(data) - len(data) % TS_PACKET
            try:
                if cut:
                    self.out.write(data[:cut])
            except OSError:
                self._gone = True
                raise ClientGone()
            self._pending = data[cut:]
            self._last_out = time.time()
        self.sent_bytes += len(chunk)

    def _flush(self):
        """End of a segment: a tail shorter than a packet is padded to 188 bytes
        (one broken packet the demuxer drops) so the wire stays aligned and the
        pump can go on. Sending it as is left the pump silent until the next
        segment: 20.10.2026 leaving RTVi HD (Edem, 10 s segments) took 6-10 s."""
        with self._wlock:
            if not self._pending:
                return
            tail = self._pending + b"\xff" * (TS_PACKET - len(self._pending))
            try:
                self.out.write(tail)
            except OSError:
                self._gone = True
                raise ClientGone()
            self._pending = b""
            self._last_out = time.time()

    def _keepalive(self):
        with self._wlock:
            if self._gone or not self.sent_bytes or not self._aligned or self._pending:
                return
            try:
                self.out.write(NULL_TS)
            except OSError:
                self._gone = True
                return
            self._last_out = time.time()

    def _pump(self, stop):
        while not stop.wait(KEEPALIVE_EVERY / 2):
            if time.time() - self._last_out >= KEEPALIVE_EVERY:
                self._keepalive()

    def run(self):
        stop = threading.Event()
        pump = threading.Thread(target=self._pump, args=(stop,), daemon=True, name="tvlink-keepalive")
        pump.start()
        try:
            return self._run()
        finally:
            stop.set()

    def _run(self):
        if self.live:
            with _res_lock:
                hit = _resolved.get(self.url)
            if hit and time.time() - hit[1] < RESOLVED_TTL:
                try:
                    text, base = net.get_text(hit[0], self.ua, self.timeout)
                    if "#EXTM3U" in text[:64]:
                        return self._hls(text, base)
                except NET_ERRORS:
                    pass
                forget(self.url)   # token rotated or server moved: take the long way
        try:
            r = net.open_url(self.url, self.ua, self.timeout)
        except net.HttpError as e:
            raise (Refused if e.code in REFUSED else StreamDead)("open: %s" % e)
        except NET_ERRORS as e:
            raise StreamDead("open: %s" % e)
        ctype = (r.headers.get("Content-Type") or "").lower()
        head = r.read(4096)
        if b"#EXTM3U" in head[:64] or "mpegurl" in ctype:
            text = (head + r.read(2 * 1024 * 1024)).decode("utf-8", "replace")
            base = r.url
            r.close()
            if "#EXT-X-STREAM-INF" in text:
                media = _pick_variant(text, base)
                if not media:
                    raise StreamDead("empty master playlist")
                text, base = self._fetch_playlist(media)
            if self.live:
                with _res_lock:
                    _resolved[self.url] = (base, time.time())
            return self._hls(text, base)
        if head[:1] != b"\x47":
            r.close(reuse=False)
            raise StreamDead("not TS/HLS (%s)" % ctype)
        return self._raw(r, head)

    def _raw(self, r, head):
        try:
            self._write(head)
            while self.alive():
                try:
                    chunk = r.read(64 * 1024)
                except NET_ERRORS as e:
                    raise StreamDead("raw stream: %s" % e)
                if not chunk:
                    raise StreamDead("raw stream ended")
                self._write(chunk)
        finally:
            r.close(reuse=False)

    def _hls(self, text, base):
        last, last_data, first = None, time.time(), True
        while True:
            if not self.alive():
                raise ClientGone()
            segs, target, ended = _parse_media(text, base)
            if first and segs and not ended:
                if self.live:
                    keep, total = [], 0.0
                    for sg in reversed(segs):
                        keep.append(sg)
                        total += sg[2]
                        if total >= LIVE_LEAD and len(keep) >= max(1, int(self.cfg["live_edge"])):
                            break
                    segs = keep[::-1]
                else:
                    # archive playlists slide like live, and the requested start sits
                    # near their end (Edem: last segment ~1 min after it, Flussonic
                    # timeshift_rel: at it) - start a minute back, never after it
                    keep, total = [], 0.0
                    for sg in reversed(segs):
                        keep.append(sg)
                        total += sg[2]
                        if total >= ARCHIVE_LEAD:
                            break
                    segs = keep[::-1]
            first = False
            fresh = [s for s in segs if last is None or s[0] > last]
            for seq, url, dur in fresh:
                if not self.alive():
                    raise ClientGone()
                if self._segment(url, dur):
                    self.sent_seconds += dur
                    last_data = time.time()
                last = seq
            if ended and not fresh:
                return  # archive finished
            if time.time() - last_data > self.cfg["switch_after"]:
                raise StreamDead("no data for %ds" % self.cfg["switch_after"])
            if not fresh:
                self._nap(min(max(target / 2.0, 1.0), 5.0))
            try:
                text, base = self._fetch_playlist(base)
            except Refused:
                raise
            except StreamDead:
                if time.time() - last_data > self.cfg["switch_after"]:
                    raise
                self._nap(1.0)

    def _nap(self, seconds):
        # the pump keeps the client fed; here we only notice that it has left
        end = time.time() + seconds
        while self.alive() and time.time() < end:
            time.sleep(KEEPALIVE_EVERY)
            if self._gone:
                raise ClientGone()
        if not self.alive():
            raise ClientGone()

    def _fetch_playlist(self, url):
        try:
            return net.get_text(url, self.ua, self.timeout)
        except net.HttpError as e:
            if e.code in REFUSED:
                raise Refused("playlist: %s" % e)
            raise StreamDead("playlist: %s" % e)
        except NET_ERRORS as e:
            raise StreamDead("playlist: %s" % e)

    def _segment(self, url, dur):
        """Fetch one segment whole, then hand it to the client at picture pace."""
        body = None
        for attempt in (1, 2):
            parts = []
            try:
                with net.open_url(url, self.ua, self.timeout) as r:
                    while True:
                        chunk = r.read(64 * 1024)
                        if not chunk:
                            break
                        parts.append(chunk)
                body = b"".join(parts)
                break
            except net.HttpError as e:
                if e.code in REFUSED:
                    # 19.10.2026: Glanz answers 403 while it still holds the session
                    # of a client that left a second ago - go to the next source now
                    raise Refused("segment: %s" % e)
                self.log("segment retry %d: %s" % (attempt, e))
            except NET_ERRORS as e:
                if parts:
                    body = b"".join(parts)   # what arrived still plays; do not fetch it twice
                    break
                self.log("segment retry %d: %s" % (attempt, e))
            if self._gone:
                raise ClientGone()
        if not body:
            return False
        self._paced(body, dur)
        self._flush()
        return True

    def _paced(self, body, dur):
        if self._lead is None:
            for off in range(0, len(body), PACE_SLICE):
                self._write(body[off:off + PACE_SLICE])
            self._media += dur
            return
        now = time.time()
        if self._clock0 is None:
            self._clock0 = now
        elif now - self._clock0 > self._media + self._lead:
            # the source stalled: catch up by at most PACE_LEAD, not by the whole stall
            self._clock0 = now - self._media
        n = len(body)
        for off in range(0, n, PACE_SLICE):
            end = min(n, off + PACE_SLICE)
            due = self._media + dur * end / n          # picture time once this slice is out
            while due - (time.time() - self._clock0) > self._lead:
                if self._gone or not self.alive():
                    raise ClientGone()
                time.sleep(0.02)
            self._write(body[off:end])
        self._media += dur


DASH_EDGE_MARGIN = 15
_URI_ATTR = re.compile(r'URI="([^"]+)"')


def absolute_playlist(text, base):
    """HLS-плейлист с абсолютными адресами: отдаётся с адреса tvlink, а читать
    варианты и сегменты inputstream.adaptive должен у источника."""
    out = []
    for line in text.splitlines():
        s = line.strip()
        if s and not s.startswith("#"):
            line = urljoin(base, s)
        elif 'URI="' in s:
            line = _URI_ATTR.sub(lambda m: 'URI="%s"' % urljoin(base, m.group(1)), line)
        out.append(line)
    return "\n".join(out) + "\n"


_UTC_TIMING = re.compile(r"<UTCTiming\b[^>]*?(?:/>|>.*?</UTCTiming>)", re.S)
_MPD_OPEN = re.compile(r"<MPD\b[^>]*>", re.S)


def fix_dash_manifest(text, base):
    """Манифест DASH для inputstream.adaptive, отданный через tvlink.

    - абсолютный <BaseURL>: относительные пути сегментов иначе считались бы от
      адреса tvlink;
    - <UTCTiming> заменяется точным временем UTC: у Первого канала часы берутся с
      1tv.ru/current_time_xml в виде "20:30:28+03:00", inputstream.adaptive 22
      пояс отбрасывает и уходит на 3 часа вперёд - просит сегменты, которых ещё
      нет (404), и через шесть повторов останавливает воспроизведение (.20,
      16.11.2026).
    """
    # Часы сдвинуты на DASH_EDGE_MARGIN назад: inputstream.adaptive догоняет край эфира и
    # просит сегмент в ту же секунду, когда тот должен появиться, а CDN выкладывает его
    # позже - 404, шесть повторов и остановка через минуту (.20, 16.11.2026). Отставание
    # на три сегмента держится всё время, а не только при старте, как live_delay.
    now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() - DASH_EDGE_MARGIN))
    text = _UTC_TIMING.sub('<UTCTiming schemeIdUri="urn:mpeg:dash:utc:direct:2014" value="%s"/>' % now, text)
    m = _MPD_OPEN.search(text)
    if m and "<BaseURL" not in text[:m.end() + 400].split("<Period", 1)[0][m.end():]:
        root = base.rsplit("/", 1)[0] + "/"
        text = text[:m.end()] + "<BaseURL>%s</BaseURL>" % root.replace("&", "&amp;") + text[m.end():]
    return text
