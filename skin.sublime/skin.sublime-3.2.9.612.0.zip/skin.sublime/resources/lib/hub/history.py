# -*- coding: utf-8 -*-
"""Watched state and resume points, read from and written to Kodi itself.

The owner's decision, and the right one: Kodi already keeps a playcount and a
resume bookmark for every plugin path it plays - that is the store the player
consults when it offers to resume, so anything else is a second opinion. Three
of them existed here at one point (Kodi, the provider add-on, and a hub of its
own), and they disagreed.

So this module is not a store. It is a view over Kodi's video database plus the
one thing Kodi cannot do: a title. Kodi's rows are paths, and recommendations
need to know that a path was «Оппенгеймер», 2023, drama, USA - which the
provider's own cache can say, because the post id is in the path. Rows we cannot
name (a YouTube clip, say) still count as history and still travel between
boxes; they simply do not shape film recommendations.

Reads go straight at Kodi's database, read-only and never copied. Writes go
through the public JSON-RPC, so Kodi's own caches stay correct.
"""
from __future__ import absolute_import, unicode_literals

import glob
import json
import os
import re
import sqlite3
import time

import xbmc
import xbmcvfs

from . import identity
from .config import get_str, log
from ..sublime_helper.config import youtube_video_id

_POST_IN_PATH = re.compile(r'/(\d+)-')
_SEASON_IN_PATH = re.compile(r'[?&]s=(\d+)')
_EPISODE_IN_PATH = re.compile(r'[?&]e=(\d+)')
# Другие источники (HDrezka и т.п.): сезон и серия в параметрах адреса.
_ANY_SEASON = re.compile(r'[?&](?:season_id|season|s)=(\d+)')
_ANY_EPISODE = re.compile(r'[?&](?:episode_id|episode|e)=(\d+)')


def _filmix_post(path):
    """Номер записи Filmix - только в адресах Filmix: у других дополнений числа в
    адресе - их собственные номера, и метаданные Filmix к ним приписывать нельзя."""
    if 'plugin.video.filmix/' not in path:
        return None
    return _POST_IN_PATH.search(path)
# Query parameters a plugin adds for its own use, which say nothing about
# which video this is. YouTube reorders them freely and the same clip arrives as
# four different paths; measured on the live store, 2818 rows held YouTube
# duplicates that no box could match against another's.
_NOISE_PARAMS = ('hide_live', 'hide_folders', 'hide_shorts', 'incognito',
                 'strm', 't', 'resume', 'refresh')
_CANON_CACHE = {}


YOUTUBE_PLAY = 'plugin://plugin.video.youtube/play?v=%s'


def canon_path(path):
    """The same video, whatever order a plugin listed its parameters in.

    Ролик YouTube - всегда родной адрес дополнения 8 (play?v=ID): у одного ролика в базе
    Kodi бывают адреса дополнения 7 (play/?video_id=ID) и 8, и это один и тот же ролик
    (переход на дополнение 8, 26.11.2026)."""
    text = str(path or '')
    if '?' not in text:
        return text
    if 'plugin.video.youtube/play' in text and '/play_playlist' not in text:
        vid = youtube_video_id(text)
        if vid:
            return YOUTUBE_PLAY % vid
    cached = _CANON_CACHE.get(text)
    if cached is not None:
        return cached
    base, _sep, query = text.partition('?')
    kept = []
    for part in query.split('&'):
        if not part:
            continue
        name = part.partition('=')[0].lower()
        if name in _NOISE_PARAMS:
            continue
        kept.append(part)
    kept.sort()
    canon = base + ('?' + '&'.join(kept) if kept else '')
    if len(_CANON_CACHE) > 8000:
        _CANON_CACHE.clear()
    _CANON_CACHE[text] = canon
    return canon


_SNAPSHOT = {'stamp': 0.0, 'rows': None}
SNAPSHOT_TTL = 45.0


def _newest_myvideos():
    paths = sorted(glob.glob(xbmcvfs.translatePath(
        'special://profile/Database/MyVideos*.db')))
    return paths[-1] if paths else ''


def _provider_cache_path():
    # Здесь - только карточки Filmix (_provider_meta зовут для адресов Filmix), поэтому база
    # всегда его, а не того, что стоит источником хаба: с источником HDRezka вся история
    # Filmix оставалась безымянной и не попадала в единую базу (.20, 17.11.2026)
    addon_id = 'plugin.video.filmix'
    for name in ('cache4.db', 'cache5.db', 'cache3.db'):
        path = xbmcvfs.translatePath(
            'special://profile/addon_data/%s/%s' % (addon_id, name))
        if os.path.isfile(path):
            return path
    return ''


def _open_ro(path):
    """Read another store in place. A copy of a 161 MB cache into tmpfs is what
    put both boxes into safe mode once, so there are no copies here."""
    if not path:
        return None
    try:
        return sqlite3.connect('file:%s?mode=ro' % path, uri=True, timeout=10)
    except Exception as exc:
        log('%s не открылась: %s' % (os.path.basename(path), exc), xbmc.LOGWARNING)
        return None


def _provider_meta(post_ids):
    """{post_id: (title, year, genres, countries, is_serial)} for these ids only.

    Asking for the handful of posts the history actually references, rather than
    reading all 16800, is the difference between milliseconds and seconds.
    """
    wanted = [str(p) for p in post_ids if str(p or '').strip()]
    if not wanted:
        return {}
    conn = _open_ro(_provider_cache_path())
    if conn is None:
        return {}
    meta = {}
    try:
        for chunk_start in range(0, len(wanted), 400):
            chunk = wanted[chunk_start:chunk_start + 400]
            marks = ','.join('?' * len(chunk))
            for post_id, details in conn.execute(
                    'SELECT post_id, details FROM posts WHERE post_id IN (%s)'
                    % marks, tuple(chunk)):
                try:
                    payload = json.loads(details or '{}')
                except Exception:
                    continue
                if not isinstance(payload, dict):
                    continue
                title = str(payload.get('title') or
                            payload.get('original_title') or '').split('/')[0].strip()
                if not title:
                    continue
                cats = payload.get('categories') or payload.get('genres') or []
                countries = payload.get('countries') or payload.get('country') or []
                if isinstance(cats, (list, tuple)):
                    cats = ', '.join(str(c) for c in cats if c)
                if isinstance(countries, (list, tuple)):
                    countries = ', '.join(str(c) for c in countries if c)
                meta[str(post_id)] = (
                    title, str(payload.get('year') or ''), str(cats or ''),
                    str(countries or ''), 'Сериалы' in (payload.get('categories') or []))
    except Exception as exc:
        log('кэш провайдера не прочитан: %s' % exc, xbmc.LOGWARNING)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return meta


_REZKA_POST = re.compile(r'/(\d+)-[^/?&]*\.html')
REZKA_CARDS = 'special://profile/addon_data/plugin.video.hdrezka.tv/cards/'


def _hdrezka_meta(path, cache):
    """(title, year, genres, countries, is_serial) для адреса HDrezka - из карточки,
    которую HDrezka кладёт при показе списков и страниц (plugin.video.hdrezka.tv,
    _card_parse). Без этого история HDrezka была безымянной, профиль вкуса
    пустым, и рекомендации у пользователя HDrezka не собирались вовсе."""
    if 'plugin.video.hdrezka.tv/' not in path:
        return None
    from urllib.parse import unquote
    hit = _REZKA_POST.search(unquote(unquote(path)))
    if not hit:
        return None
    post_id = hit.group(1)
    if post_id in cache:
        return cache[post_id]
    info = None
    try:
        with open(os.path.join(xbmcvfs.translatePath(REZKA_CARDS), post_id + '.json'),
                  encoding='utf-8') as fh:
            card = json.load(fh)
        if card.get('title'):
            # «Гангстерленд / MobLand» - ключ по русскому названию, как у Filmix и Elementum
            title = re.split(r'\s+/\s+', str(card['title']).strip())[0].strip() or card['title']
            info = (title, str(card.get('year') or ''),
                    ', '.join(g for g in (card.get('genres') or []) if g != 'Зарубежные'),
                    ', '.join(card.get('countries') or []), bool(card.get('serial')))
    except (OSError, ValueError):
        pass
    cache[post_id] = info
    return info

def _epoch(stamp):
    """Kodi writes lastPlayed as 'YYYY-MM-DD HH:MM:SS' in local time."""
    text = str(stamp or '').strip()
    if not text:
        return 0
    # Разбор вручную: strptime на 3056 строках стоил 0.17 с каждого запроса
    # полосы (профиль на .30 17.10.2026). Время то же - местное, через mktime.
    try:
        return int(time.mktime((int(text[0:4]), int(text[5:7]), int(text[8:10]),
                                int(text[11:13]), int(text[14:16]), int(text[17:19]),
                                0, 0, -1)))
    except Exception:
        try:
            return int(time.mktime(time.strptime(text[:19], '%Y-%m-%d %H:%M:%S')))
        except Exception:
            return 0


def _full_path(strpath, filename):
    """Kodi splits a file into a directory and a name, and for a plugin item it
    stores the whole URL in the NAME - so gluing the two together doubles it:
    "plugin://plugin.video.filmix/plugin://plugin.video.filmix/movies/...".
    Seen in the live database, and it matters: a doubled URL is not playable and
    is not the key Kodi itself uses.
    """
    name = str(filename or '')
    if name.startswith('plugin://'):
        return name
    return '%s%s' % (str(strpath or ''), name)


# Строки истории, общие для всех запусков маршрутов. Каждый экран Kodi
# запускает скин заново, и каждая полоса хаба читала базу просмотров Kodi
# целиком: 0.58 с из 2.55 с маршрута «Все» сериалы (профиль на .30
# 17.10.2026). Снимок лежит в special://temp и годен, пока база Kodi не
# изменилась (её размер и время записи) и не старше DISK_SNAPSHOT_TTL - имена
# постов берутся из кеша провайдера и могут дополниться.
# "2": rows of episode 0 are keyed as episodes now (identity.key_for, 21.10.2026);
# the old file carried them as marks on the whole show.
DISK_SNAPSHOT = 'special://temp/sublime_history_rows2.json'
DISK_SNAPSHOT_TTL = 600


def _db_stamp(path):
    try:
        st = os.stat(path)
        return '%s|%d|%d' % (path, int(st.st_mtime_ns), int(st.st_size))
    except Exception:
        return ''


def _disk_snapshot_load(stamp):
    if not stamp:
        return None
    try:
        with open(xbmcvfs.translatePath(DISK_SNAPSHOT), 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
    except Exception:
        return None
    if not isinstance(payload, dict) or payload.get('db') != stamp:
        return None
    if time.time() - float(payload.get('ts') or 0) > DISK_SNAPSHOT_TTL:
        return None
    rows = payload.get('rows')
    return rows if isinstance(rows, list) else None


def _disk_snapshot_store(stamp, rows):
    if not stamp:
        return
    try:
        target = xbmcvfs.translatePath(DISK_SNAPSHOT)
        tmp = '%s.%d.tmp' % (target, os.getpid())
        # dumps, а не dump: dump в файл кодирует по кусочкам чистым Python -
        # 0.91 с на 3000 строк против долей секунды у кодировщика на C.
        text = json.dumps({'db': stamp, 'ts': time.time(), 'rows': rows},
                          ensure_ascii=False, separators=(',', ':'))
        with open(tmp, 'w', encoding='utf-8') as handle:
            handle.write(text)
        os.replace(tmp, target)
    except Exception:
        pass


NAMES_FILE = 'special://profile/addon_data/skin.sublime/watch_names.json'
_NAMES = {'map': None}


def _names():
    """{адрес: [ключ, ключ сериала, тип, название, год, сезон, серия]} - имена просмотров,
    которых не назовёт кэш источника: просмотр с другой коробки или до переустановки (кэш
    карточек Filmix пуст, .20 17.11.2026: «Сердце зверя» 06.11 стало безымянным) и адреса
    Elementum, у которых в адресе только английское название."""
    if _NAMES['map'] is None:
        try:
            with open(xbmcvfs.translatePath(NAMES_FILE), encoding='utf-8') as fh:
                data = json.load(fh)
            _NAMES['map'] = data if isinstance(data, dict) else {}
        except Exception:
            _NAMES['map'] = {}
    return _NAMES['map']


def names_known():
    return os.path.isfile(xbmcvfs.translatePath(NAMES_FILE))


def remember_names(rows):
    """Запомнить имена из строк общей базы (sync.pull) или полос. Возвращает, сколько новых."""
    names, added = _names(), 0
    for row in rows or []:
        path = canon_path(row.get('path') or row.get('file') or '')
        key = str(row.get('item_key') or '')
        if not path.startswith('plugin://') or not key.startswith('v1|') or path in names:
            continue
        names[path] = [key, row.get('parent_key') or '', row.get('mediatype') or '',
                       row.get('label') or row.get('title') or '', str(row.get('year') or ''),
                       int(row.get('season') or 0), int(row.get('episode') or 0)]
        added += 1
    if added or not names_known():
        try:
            target = xbmcvfs.translatePath(NAMES_FILE)
            with open(target + '.tmp', 'w', encoding='utf-8') as fh:
                json.dump(names, fh, ensure_ascii=False)
            os.replace(target + '.tmp', target)
        except Exception as exc:
            log('имена просмотров не записаны: %s' % exc, xbmc.LOGWARNING)
        if added:
            invalidate()
    return added


_ELEMENTUM_PATH = re.compile(r'plugin://plugin\.video\.elementum/(movie|show)/(\d+)'
                             r'(?:/season/(\d+)/episode/(\d+))?/links/([^/?]*)')


def name_elementum_by_tmdb(limit=3, cancel=None):
    """Назвать просмотры Elementum по номеру TMDb из адреса - русское название и год.

    В адресе Elementum только номер TMDb и английское имя раздачи; серий в собранных полосах нет,
    и начатая серия не попадала ни в «Продолжить просмотр», ни в значок сериала (.20, 17.11.2026:
    «Американская история ужасов» S09E01, 312 с из 2890). Служба зовёт это в фоне, по несколько
    сериалов и фильмов за раз; найденное ложится в справочник имён навсегда."""
    from urllib.parse import unquote
    names = _names()
    todo = {}
    for row in _rows():
        path = canon_path(row.get('path') or '')
        if row.get('named') or path in names:
            continue
        hit = _ELEMENTUM_PATH.match(path)
        if hit:
            todo.setdefault((hit.group(1), hit.group(2)), []).append((path, hit))
    if not todo:
        return 0
    from ..sublime_helper.core import fetch_online_metadata
    found = []
    for (kind, tmdb_id), paths in list(todo.items())[:max(1, int(limit))]:
        if cancel is not None and cancel():
            break
        media = 'tvshow' if kind == 'show' else 'movie'
        english = re.sub(r'\s+S\d+E\d+$|\s*\(\d{4}\)$', '', unquote(paths[0][1].group(5) or '')).strip()
        local = {'dbid': 0, 'dbtype': media, 'media_type': media, 'tmdb_type': media,
                 'title': english, 'originaltitle': english, 'year': 0, 'tmdb_id': int(tmdb_id)}
        try:
            meta = fetch_online_metadata({'tmdb_id': tmdb_id, 'kp_search': False}, local) or {}
        except Exception as exc:
            log('имя Elementum %s/%s: %s' % (kind, tmdb_id, exc), xbmc.LOGDEBUG)
            continue
        title = str(meta.get('title') or '').strip()
        year = str(meta.get('year') or '')[:4] or str(meta.get('premiered') or '')[:4]
        if not title or title == english and not meta.get('plot'):
            continue
        for path, hit in paths:
            if kind == 'show' and hit.group(4):
                key, parent, mediatype = identity.key_for(tvshowtitle=title, year=year,
                                                         season=int(hit.group(3) or 0),
                                                         episode=int(hit.group(4)))
                season, episode = int(hit.group(3) or 0), int(hit.group(4))
            else:
                key, parent, mediatype = identity.key_for(title=title, year=year)
                season = episode = 0
                if kind == 'show':
                    mediatype = 'tvshow'
            found.append({'path': path, 'item_key': key, 'parent_key': parent, 'mediatype': mediatype,
                          'label': title, 'year': year, 'season': season, 'episode': episode})
    added = remember_names(found)
    if added:
        log('просмотры Elementum названы по TMDb: %d' % added)
    return added


def _snapshot_names(paths):
    """Имена фильмов из собранных полос (Elementum и любые источники) для этих адресов."""
    wanted, found = set(paths), []
    if not wanted:
        return found
    try:
        from . import mirror
        for _src, snap in mirror.iter_snapshots():
            for item in snap or []:
                path = canon_path(item.get('file') or '')
                kind = str(item.get('mediatype') or item.get('type') or '')
                title = item.get('title') or item.get('label') or ''
                if path in wanted and kind == 'movie' and title and item.get('year'):
                    key, parent, mediatype = identity.key_for(title=title, year=item.get('year'))
                    found.append({'path': path, 'item_key': key, 'parent_key': parent,
                                  'mediatype': mediatype, 'label': title, 'year': item.get('year')})
                    wanted.discard(path)
    except Exception as exc:
        log('имена из полос не прочитаны: %s' % exc, xbmc.LOGDEBUG)
    return found


def _rows():
    """Every plugin row Kodi knows, named where the provider can name it."""
    now = time.time()
    db_path = _newest_myvideos()
    db_stamp = _db_stamp(db_path)
    # снимок в памяти - только при той же базе Kodi: служба живёт долго, и готовая выдача хаба,
    # собранная сразу после досмотра, брала отметки из снимка до досмотра, а отпечаток - уже
    # новый, и держалась устаревшей до 13 мин (аудит 23.11.2026)
    if (_SNAPSHOT['rows'] is not None and _SNAPSHOT.get('db') == db_stamp
            and now - _SNAPSHOT['stamp'] < SNAPSHOT_TTL):
        return _SNAPSHOT['rows']
    cached = _disk_snapshot_load(db_stamp)
    if cached is not None:
        _SNAPSHOT.update({'rows': cached, 'stamp': now, 'db': db_stamp})
        return cached
    conn = _open_ro(db_path)
    if conn is None:
        return []
    raw = []
    try:
        for strpath, filename, playcount, last_played, position, total in conn.execute(
                'SELECT p.strPath, f.strFilename, f.playCount, f.lastPlayed,'
                '       b.timeInSeconds, b.totalTimeInSeconds'
                ' FROM files f JOIN path p ON p.idPath = f.idPath'
                ' LEFT JOIN bookmark b ON b.idFile = f.idFile'):
            path = _full_path(strpath, filename)
            if not path.startswith('plugin://'):
                continue
            raw.append((path, int(playcount or 0), _epoch(last_played),
                        float(position or 0), float(total or 0)))
    except Exception as exc:
        log('база Kodi не прочитана: %s' % exc, xbmc.LOGWARNING)
        return []
    finally:
        try:
            conn.close()
        except Exception:
            pass

    post_ids = []
    for path, _pc, _ts, _pos, _tot in raw:
        match = _filmix_post(path)
        if match:
            post_ids.append(match.group(1))
    meta = _provider_meta(set(post_ids))
    rezka_cache = {}
    # адреса, которых не назовут ни карточки Filmix, ни HDRezka - ищем в собранных полосах
    # один раз и запоминаем (полосы меняются, просмотр остаётся)
    names = _names()
    unnamed = [canon_path(p) for p, _pc, _ts, _pos, _tot in raw
               if not _filmix_post(p) and 'plugin.video.hdrezka' not in p
               and 'plugin.video.youtube' not in p and canon_path(p) not in names]
    if unnamed and remember_names(_snapshot_names(unnamed)):
        names = _names()

    rows = []
    for path, playcount, stamp, position, total in raw:
        match = _filmix_post(path)
        info = meta.get(match.group(1)) if match else _hdrezka_meta(path, rezka_cache)
        season_no = episode_no = 0
        known = None
        if info:
            title, year, genres, countries, is_serial = info
            # Filmix пишет сезон и серию как s=/e=, HDrezka - season_id=/episode_id=:
            # без второго варианта каждая серия HDrezka становилась «весь сериал»
            # (.20, 17.11.2026: «Гангстерленд» S1E1 -> v1|гангстерленд мобленд|2025)
            season_hit = _SEASON_IN_PATH.search(path) or _ANY_SEASON.search(path)
            episode_hit = _EPISODE_IN_PATH.search(path) or _ANY_EPISODE.search(path)
            if episode_hit:
                # An episode needs its own key, or every episode of a show
                # collapses onto one: measured, 1817 episode rows became 25
                # rows on the shared store and the rest simply disappeared.
                season_no = int(season_hit.group(1)) if season_hit else 0
                episode_no = int(episode_hit.group(1))
                item_key, parent_key, mediatype = identity.key_for(
                    tvshowtitle=title, year=year, season=season_no,
                    episode=episode_no)
            else:
                item_key, parent_key, mediatype = identity.key_for(
                    title=title, year=year)
                if is_serial:
                    mediatype = 'tvshow'
        else:
            # Unnamed but still history: key it by its own path so it can be
            # shared and resumed. Recommendations skip these - they have no
            # genres to learn from - which is honest rather than invented.
            title = year = genres = countries = ''
            item_key = 'path|%s' % canon_path(path)
            parent_key = ''
            mediatype = ''
            known = names.get(canon_path(path))
            if known:
                item_key, parent_key, mediatype, title, year = known[:5]
                season_no, episode_no = int(known[5] or 0), int(known[6] or 0)
            # сезон и серия из адреса - по ним фокус на сериале находит серию
            episode_hit = None if known else _ANY_EPISODE.search(path)
            if episode_hit:
                season_hit = _ANY_SEASON.search(path)
                season_no = int(season_hit.group(1)) if season_hit else 0
                episode_no = int(episode_hit.group(1))
                mediatype = 'episode'
        rows.append({
            'item_key': item_key,
            'parent_key': parent_key,
            'mediatype': mediatype,
            'label': title,
            'year': year,
            'season': season_no,
            'episode': episode_no,
            'genres': genres,
            'countries': countries,
            'studio': '',
            'rating': 0.0,
            'playcount': playcount,
            'last_watched': stamp,
            'path': path,
            'position': position,
            'total': total,
            'named': bool(info) or bool(known),
        })
    _SNAPSHOT.update({'rows': rows, 'stamp': now, 'db': db_stamp})
    _disk_snapshot_store(db_stamp, rows)
    _publish_by_title(rows)
    return rows


# Единая база просмотров по фильму, а не по адресу (владелец 17.11.2026: «почему база
# не единая?»). Kodi помнит просмотр по адресу файла, а у каждого источника адрес свой:
# «Одиссея», досмотренная в Filmix, для HDRezka и Elementum была непросмотренной, а
# внутри HDRezka один фильм приходит под адресами с «-latest» и без. Ключ - название и
# год (identity.key_for), тот же, по которому хаб уже ведёт историю и делится ею с
# WatchHub. Файл читают дополнения (HDRezka, Filmix) - по нему они ставят значки строкам.
BY_TITLE_FILE = 'special://profile/addon_data/skin.sublime/watch_by_title.json'


def _title_merge(rows):
    """{ключ фильма: [playcount, позиция, длительность, время]} - по всем источникам. Позиция
    берётся у самого свежего действия: «Сердце зверя» досмотрено в Filmix 06.11 и начато
    заново в HDRezka 17.11 - значит, сейчас оно недосмотрено с 40:13, а не «просмотрено».
    Отметка «просмотрено» при этом сохраняется (playcount - наибольший). Только фильмы:
    сериал по одной серии целиком отмечать нельзя."""
    state = {}
    for row in rows:
        key = row.get('item_key') or ''
        if not row.get('named') or not key or row.get('mediatype') != 'movie':
            continue
        count = int(row.get('playcount') or 0)
        pos, total = float(row.get('position') or 0), float(row.get('total') or 0)
        stamp = int(row.get('last_watched') or 0)
        if not count and pos <= 0:
            continue
        previous = state.get(key)
        if previous is None:
            state[key] = [count, pos, total, stamp]
            continue
        best = max(previous[0], count)
        if stamp >= previous[3]:
            state[key] = [best, pos, total, stamp]
        else:
            previous[0] = best
    # Значок один на все разделы - по последнему действию: начатый заново фильм везде
    # недосмотрен с этой позиции, а не «просмотрен» в одном разделе и «недосмотрен» в
    # другом (владелец 17.11.2026: «опять косяк с разными показаниями в разных категориях»)
    for value in state.values():
        if value[1] > 0:
            value[0] = 0
    return state


def state_by_title():
    return {k: tuple(v[:3]) for k, v in _title_merge(_rows()).items()}


EPISODES_FILE = 'special://profile/addon_data/skin.sublime/watch_episodes.json'


def _episode_merge(rows):
    """Серии и сериалы по всем источникам: {'episodes': {ключ серии: [playcount, позиция,
    длительность, время]}, 'shows': {ключ сериала: [просмотрено серий, начат]}}. Серия -
    по самому свежему действию, как фильм; сериал начат, если начата или просмотрена хоть
    одна серия (владелец 17.11.2026: «Гангстерленд» - значков нет ни у серии, ни у сериала)."""
    episodes, shows = {}, {}
    for row in rows:
        if not row.get('named') or row.get('mediatype') != 'episode':
            continue
        key, parent = row.get('item_key') or '', row.get('parent_key') or ''
        count = int(row.get('playcount') or 0)
        pos, total = float(row.get('position') or 0), float(row.get('total') or 0)
        stamp = int(row.get('last_watched') or 0)
        if not key or (not count and pos <= 0):
            continue
        previous = episodes.get(key)
        if previous is None or stamp >= previous[3]:
            episodes[key] = [max(count, previous[0] if previous else 0), pos, total, stamp]
        else:
            previous[0] = max(previous[0], count)
        if parent:
            shows.setdefault(parent, [0, 1])
    for key, value in episodes.items():
        if value[1] > 0:
            value[0] = 0
    for row in rows:
        parent = row.get('parent_key') or ''
        if parent in shows and row.get('mediatype') == 'episode' and int(row.get('playcount') or 0) > 0:
            shows[parent][0] += 1
    # третье число - вышедших серий (TMDb, routes._show_totals): по нему HDRezka и Elementum
    # публикуют тот же счёт, что Filmix, - непросмотренные, галочка у досмотренного
    totals = _show_totals_known()
    for parent, value in shows.items():
        if totals.get(parent):
            value.append(int(totals[parent]))
    # Elementum называет сериал по-английски (tvshowtitle = «American Horror Story»), а ключи
    # здесь русские - те же записи ещё и под номером TMDb из адреса Elementum
    # (/show/<tmdb>/season/<s>/episode/<e>): по нему Elementum находит их всегда
    for row in rows:
        hit = _ELEMENTUM_EPISODE.search(str(row.get('path') or ''))
        if not hit:
            continue
        parent = row.get('parent_key') or ''
        if parent in shows:
            shows.setdefault('tmdb:%s' % hit.group(1), shows[parent])
        key = row.get('item_key') or ''
        if key in episodes:
            episodes.setdefault('tmdb:%s|%d|%d' % (hit.group(1), int(hit.group(2)), int(hit.group(3))),
                                episodes[key])
    return {'episodes': episodes, 'shows': shows}


_ELEMENTUM_EPISODE = re.compile(r'plugin\.video\.elementum/show/(\d+)/season/(\d+)/episode/(\d+)')


SHOW_TOTALS_FILE = 'special://profile/addon_data/skin.sublime/show_totals.json'


def _show_totals_known():
    try:
        with open(xbmcvfs.translatePath(SHOW_TOTALS_FILE), encoding='utf-8') as fh:
            data = json.load(fh)
        return dict((k, int(v.get('n') or 0)) for k, v in data.items() if isinstance(v, dict))
    except Exception:
        return {}


def started_other_shows():
    """Начатые сериалы не из Filmix (HDRezka, Elementum): у Filmix счёт серий свой, этим
    число вышедших серий узнаёт скин - строками, понятными routes._show_totals."""
    out, seen = [], set()
    for row in _rows():
        parent = row.get('parent_key') or ''
        path = str(row.get('path') or '')
        if (not parent or parent in seen or row.get('mediatype') != 'episode'
                or 'plugin.video.filmix' in path or not row.get('label')):
            continue
        seen.add(parent)
        out.append({'label': row['label'], 'year': row.get('year') or '', 'file': path,
                    'mediatype': 'tvshow'})
    return out


def republish_episode_states():
    """Переписать общий файл серий (после того как узнали новые числа серий)."""
    _publish_by_title(_rows())


def episode_states():
    return _episode_merge(_rows())


def _write_if_changed(uri, data):
    """Записать файл, только если содержимое другое: раз в 5 минут те же байты переписывались
    на флеш, а дополнения перечитывали файл по смене даты (аудит 21.11.2026)."""
    path = xbmcvfs.translatePath(uri)
    text = json.dumps(data, ensure_ascii=False)
    try:
        with open(path, encoding='utf-8') as fh:
            if fh.read() == text:
                return
    except Exception:
        pass
    with open(path + '.tmp', 'w', encoding='utf-8') as fh:
        fh.write(text)
    os.replace(path + '.tmp', path)


def _publish_by_title(rows):
    try:
        _write_if_changed(EPISODES_FILE, _episode_merge(rows))
    except Exception as exc:
        log('состояние серий не записано: %s' % exc, xbmc.LOGWARNING)
    try:
        _write_if_changed(BY_TITLE_FILE, _title_merge(rows))
    except Exception as exc:
        log('состояние по фильму не записано: %s' % exc, xbmc.LOGWARNING)


def invalidate():
    _SNAPSHOT.update({'rows': None, 'stamp': 0.0})
    try:
        os.remove(xbmcvfs.translatePath(DISK_SNAPSHOT))
    except Exception:
        pass


# ---- the API the recommender and the widgets read ----------------------

def watched_keys():
    return set(r['item_key'] for r in _rows() if r['playcount'] > 0)


def watched_parent_keys():
    return set(r['parent_key'] for r in _rows()
               if r['parent_key'] and r['playcount'] > 0)


def playcounts():
    counts = {}
    for row in _rows():
        if row['playcount'] > 0:
            counts[row['item_key']] = max(counts.get(row['item_key'], 0),
                                          row['playcount'])
    return counts


def watched_episode_counts():
    """{ключ сериала: сколько РАЗНЫХ серий просмотрено}.

    Считались строки Kodi, а у одной и той же серии их бывает несколько: у
    «Всегда солнечно в Филадельфии» серия 18x2 записана двумя путями, и 179
    просмотренных серий превращались в 180 из 180 - то есть в галочку
    «просмотрен» на полосе хаба, пока избранное честно показывало оставшуюся
    серию. Ключ строки уже несёт сезон и номер, поэтому достаточно считать
    различные ключи.
    """
    seen = {}
    for row in _rows():
        if row['parent_key'] and row['playcount'] > 0:
            seen.setdefault(row['parent_key'], set()).add(row['item_key'])
    return dict((key, len(items)) for key, items in seen.items())


def watched_episode_counts_in(prefixes):
    """{начало пути поста: сколько РАЗНЫХ серий просмотрено именно в этом посте}.

    Ключ сериала - название и год, а у источника под одним ключом бывает несколько постов:
    у Filmix «Реальные пацаны» 2010 - пост 7661 (39 серий) и пост 28082 (13-й сезон, 35
    просмотренных). Серии, просмотренные в одном посте, считались против числа серий
    другого, и не начатый пост вставал в рекомендации как «вышли новые серии» (.20, 25.11.2026).
    """
    wanted = [p for p in (prefixes or ()) if p]
    seen = dict((p, set()) for p in wanted)
    if not wanted:
        return {}
    for row in _rows():
        if not row['parent_key'] or row['playcount'] <= 0:
            continue
        path = str(row.get('path') or '')
        for prefix in wanted:
            if path.startswith(prefix):
                seen[prefix].add(row['item_key'])
                break
    return dict((p, len(items)) for p, items in seen.items())


def state_by_path():
    """{приведённый путь: (playcount, позиция, длительность)} - для строк снимка.

    Снимок виджета несёт то состояние просмотра, какое было в момент сборки, а
    сборка идёт своими часами. Замер на .30 04.09.2026: из 60 строк ленты
    подписок четыре несли playcount 0, тогда как база Kodi по тем же путям
    отвечала 1, и «Сценарий следующей войны» владелец посмотрел в 22:05 - на
    экране отметки не было. Поэтому маршруты берут состояние отсюда, живьём, а
    не из снимка (routes._publish_stored_rows).

    Ключ приведённый (canon_path): одно и то же видео YouTube играется путями с
    разным порядком параметров, и без приведения половина строк не совпала бы.
    """
    state = {}
    for row in _rows():
        path = str(row.get('path') or '')
        if not path:
            continue
        current = (int(row.get('playcount') or 0),
                   float(row.get('position') or 0),
                   float(row.get('total') or 0))
        key = canon_path(path)
        previous = state.get(key)
        # Одна и та же вещь бывает записана несколькими путями. Берём то, что
        # говорит больше: отметку важнее сохранить, чем позицию.
        if previous is None or current[0] > previous[0]:
            state[key] = current
        elif current[0] == previous[0] and current[1] > previous[1]:
            state[key] = current
    return state


def started_shows():
    """Ключи сериалов, у которых хоть одна серия просмотрена или начата.

    Владелец 16.10.2026: «если сериал не начинали смотреть (хотя бы одну серию)
    - число серий не надо показывать». Начатая серия - это строка с точкой
    продолжения, отметки у неё нет.
    """
    started = set()
    for row in _rows():
        if row['parent_key'] and (row['playcount'] > 0 or row['position'] > 0):
            started.add(row['parent_key'])
    return started


def started_post_ids():
    """{номер поста Filmix: время последнего просмотра} для начатых сериалов.

    Нужен прогреву сериалов главной (hub/service._write_home_series): начатые
    владельцем сериалы открываются чаще всего, их и греть первыми.
    """
    found = {}
    for row in _rows():
        path = row['path']
        if '/serials/' not in path and '/multserials/' not in path:
            continue
        if row['playcount'] <= 0 and row['position'] <= 0:
            continue
        match = _POST_IN_PATH.search(path)
        if match:
            post_id = match.group(1)
            found[post_id] = max(found.get(post_id, 0), int(row['last_watched'] or 0))
    return found


def progress_map():
    """{item_key: (position, total)} for everything half-watched."""
    out = {}
    for row in _rows():
        if row['position'] > 0 and row['total'] > 0 and row['playcount'] <= 0:
            out[row['item_key']] = (row['position'], row['total'])
    return out


def in_progress(limit=50):
    rows = [r for r in _rows()
            if r['position'] > 0 and r['total'] > 0 and r['playcount'] <= 0]
    rows.sort(key=lambda r: r['last_watched'], reverse=True)
    return rows[:int(limit)]


def recent_watched(limit=300, mediatype=''):
    """Named, watched rows, newest first - the taste profile's input."""
    rows = [r for r in _rows() if r['playcount'] > 0 and r['named']]
    if mediatype:
        rows = [r for r in rows if r['mediatype'] == mediatype]
    rows.sort(key=lambda r: r['last_watched'], reverse=True)
    return rows[:int(limit)]


def changed_since(since_ts, limit=2000):
    """Rows Kodi touched after this moment - what the sync has to send."""
    rows = [r for r in _rows() if r['last_watched'] > int(since_ts or 0)]
    rows.sort(key=lambda r: (r['last_watched'], r['item_key']))
    return rows[:int(limit)]


# ---- writing back into Kodi -------------------------------------------

def _jsonrpc(method, params):
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})) or '{}')
        if answer.get('error'):
            log('JSON-RPC %s: %s' % (method, answer['error']), xbmc.LOGWARNING)
            return False
        return True
    except Exception as exc:
        log('JSON-RPC %s не прошёл: %s' % (method, exc), xbmc.LOGWARNING)
        return False


def mark_watched(path, playcount=1, when=0):
    """Tell Kodi this path was watched. One writer, one truth."""
    if not path:
        return False
    params = {'file': path, 'media': 'video',
              'playcount': max(1, int(playcount or 1)),
              'resume': {'position': 0.0, 'total': 0.0}}
    stamp = int(when or time.time())
    params['lastplayed'] = time.strftime('%Y-%m-%d %H:%M:%S',
                                         time.localtime(stamp))
    ok = _jsonrpc('Files.SetFileDetails', params)
    if ok:
        invalidate()
    return ok


def _stamp_text(when):
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(when)))


UNMARKED_FILE = 'special://profile/addon_data/skin.sublime/watch_unmarked.json'


def _unmarked_load():
    try:
        with open(xbmcvfs.translatePath(UNMARKED_FILE), encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _unmarked_save(data):
    target = xbmcvfs.translatePath(UNMARKED_FILE)
    tmp = target + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, target)
    except Exception as exc:
        log('снятые отметки не записаны: %s' % exc, xbmc.LOGWARNING)


def unmarked():
    """{канонический путь: время} - отметки, снятые здесь пунктом «Снять отметку просмотра» и ещё не
    отправленные на сервер обмена. Обмен шлёт только их как «снято» (playcount 0): серия, открытая на
    секунду, выглядит так же (ни отметки, ни места продолжения), но снимать чужую отметку не должна."""
    return _unmarked_load()


def forget_unmarked(paths):
    data = _unmarked_load()
    changed = False
    for path in paths:
        if data.pop(canon_path(path), None) is not None:
            changed = True
    if changed:
        _unmarked_save(data)


def clear_watched(path, when=0, record=True):
    """Снять отметку и точку продолжения.

    Вместе с ними пишется время: обмен между коробками отправляет только то, что новее прошлого
    обмена (changed_since), и принимает только то, что новее своего (apply_remote). Без нового
    времени снятая отметка оставалась на этой коробке (.20/.30, 26.11.2026). when - время,
    пришедшее с другой коробки: своё «сейчас» там сделало бы запись новее и отправило её обратно.
    playcount 0 передаётся явно - с lastplayed без него Kodi пишет playCount=1 (см. set_progress)."""
    if not path:
        return False
    stamp = int(when or time.time())
    ok = _jsonrpc('Files.SetFileDetails', {
        'file': path, 'media': 'video', 'playcount': 0,
        'resume': {'position': 0.0, 'total': 0.0},
        'lastplayed': _stamp_text(stamp)})
    if ok:
        if record:
            data = _unmarked_load()
            data[canon_path(path)] = stamp
            _unmarked_save(data)
        invalidate()
    return ok


def is_episode_path(path):
    """Адрес одной серии (s=/e= у Filmix, season_id=/episode_id= у HDRezka), а не сериала целиком."""
    path = str(path or '')
    return bool(_EPISODE_IN_PATH.search(path) or _ANY_EPISODE.search(path))


def clear_watched_show(path, label='', year=''):
    """«Снять отметку просмотра» у сериала: сбрасывает отметку и точку продолжения у КАЖДОЙ серии.

    Пункт меню сериала передаёт адрес папки сериала, а Kodi хранит просмотр по адресам серий:
    Files.SetFileDetails на папку ничего не снимал, и маркеры непросмотренных серий и «Продолжить
    просмотр» оставались (.20, 25.11.2026: «Тайный город», «Город Бога», «Гангстерленд»). Серии
    сериала - тот же пост Filmix, тот же ключ сериала (название и год) или адрес внутри папки."""
    path = str(path or '')
    if not path:
        return 0
    post = _filmix_post(path)
    post_id = post.group(1) if post else ''
    show = identity.show_key(identity.clean_label(label), year) if label else ''
    folder = path if path.endswith('/') else ''
    done = 0
    seen = set()
    for row in _rows():
        rpath = row.get('path') or ''
        if rpath in seen:
            continue
        mine = False
        if post_id:
            hit = _filmix_post(rpath)
            mine = bool(hit and hit.group(1) == post_id)
        if not mine and show:
            mine = show in (row.get('parent_key'), row.get('item_key'))
        if not mine and folder:
            mine = rpath.startswith(folder)
        if not mine or not (int(row.get('playcount') or 0) > 0 or float(row.get('position') or 0) > 0):
            continue
        seen.add(rpath)
        if clear_watched(rpath):
            done += 1
    clear_watched(path)
    if done:
        invalidate()
    return done


def set_progress(path, position, total, when=0, playcount=0):
    """Точка продолжения - и ровно тот счётчик просмотров, что был.

    Счётчик передаётся ЯВНО. Files.SetFileDetails с lastplayed и без playcount
    Kodi записывает как playCount=1 - проверено на .30 16.10.2026 пробным путём:
    {resume 600/3000, lastplayed} -> playCount 1; то же с playcount 0 -> пусто,
    с playcount 2 -> 2. Так обмен превращал «начато» в «просмотрено»: «Война»
    1x1 на .30 досмотрена до 21 %, а на .20 пришла с галочкой; на сервере обмена
    79 таких отметок, поставленных в ту же секунду, что и прогресс. Владелец:
    «у неполностью просмотренных айтемов были галки просмотрено и не было resume».
    """
    if not path or position <= 0 or total <= 0:
        return False
    params = {'file': path, 'media': 'video',
              'playcount': max(0, int(playcount or 0)),
              'resume': {'position': float(position), 'total': float(total)}}
    stamp = int(when or time.time())
    params['lastplayed'] = time.strftime('%Y-%m-%d %H:%M:%S',
                                         time.localtime(stamp))
    ok = _jsonrpc('Files.SetFileDetails', params)
    if ok:
        invalidate()
    return ok


def apply_remote(row):
    """Apply one row that came from another box.

    Kodi is per-box, so this is how a watch on one screen reaches the other.
    Nothing is invented: a row is applied only if it carries the path Kodi keys
    by, and only when it is newer than what this box already has.
    """
    path = str(row.get('path') or '')
    if not path.startswith('plugin://'):
        return False
    incoming = int(row.get('last_watched') or 0)
    incoming_playcount = int(row.get('playcount') or 0)
    local_playcount = 0
    canon = canon_path(path)
    # Одному ролику YouTube на коробке могут соответствовать две записи (адрес дополнения 7 и
    # 8) - сравнивается с самой свежей из них.
    matches = [local for local in _rows()
               if local['path'] == path or canon_path(local['path']) == canon]
    matches.sort(key=lambda local: (local['last_watched'], int(local['playcount'] or 0)), reverse=True)
    for local in matches[:1]:
        # Строже, а не только новее. Одно и то же нажатие «смотреть» даёт ДВЕ
        # записи с ОДНОЙ И ТОЙ ЖЕ секундой lastPlayed: сначала закладку
        # (прогресс), потом отметку «просмотрено». Обмен отправляет их порознь,
        # и пока здесь стояло «>=», вторая всегда отбрасывалась как «не новее».
        #
        # Замер 04.09.2026: на .30 просмотренных путей ютуба 469, на .20 - НОЛЬ,
        # при этом сами пути на .20 есть и время у них ровно то же (например
        # video_id=V21jxnsSAn4, 21:45:32) - то есть прогресс дошёл, а отметка
        # нет. Владелец: «Просмотрел видео на .30 - не отметился ни на .30, ни
        # на .20».
        #
        # Теперь при равном времени пропускается то, что говорит БОЛЬШЕ:
        # отметка сильнее закладки. Обратный порядок (закладка поверх отметки)
        # по-прежнему отбрасывается.
        stronger = incoming_playcount > int(local['playcount'] or 0)
        if local['last_watched'] > incoming:
            return False
        if local['last_watched'] == incoming and not stronger:
            return False
        # Write to the path THIS box keys by: the other box may have played the
        # same video through a differently ordered URL, and Kodi would file the
        # incoming one as a second, unrelated item.
        path = local['path']
        local_playcount = int(local['playcount'] or 0)
    if canon.startswith(YOUTUBE_PLAY % ''):
        # Ролик YouTube пишется по родному адресу дополнения 8: по нему его списки показывают
        # отметку и место продолжения, по адресу дополнения 7 - уже нет.
        path = canon
    playcount = int(row.get('playcount') or 0)
    if playcount > 0:
        return mark_watched(path, playcount, incoming)
    position = float(row.get('position') or 0)
    total = float(row.get('total') or 0)
    if position > 0 and total > 0:
        # Прогресс с другой коробки отметку этой не трогает: пересмотр уже
        # просмотренного остаётся просмотренным, начатое - начатым.
        return set_progress(path, position, total, incoming, local_playcount)
    # отмена с другой коробки - с её временем, чтобы запись не вернулась туда «новее»
    return clear_watched(path, incoming, record=False)
