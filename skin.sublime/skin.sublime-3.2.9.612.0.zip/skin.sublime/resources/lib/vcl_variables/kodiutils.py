# -*- coding: utf-8 -*-
# Module: default
# Author: jurialmunkey
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
import xbmc
import xbmcgui
import jurialmunkey.logger as jurialmunkey_logger
import jurialmunkey.plugin as jurialmunkey_plugin
import jurialmunkey.dialog as jurialmunkey_dialog
from contextlib import contextmanager


KODIPLUGIN = jurialmunkey_plugin.KodiPlugin('skin.sublime')
ADDON = KODIPLUGIN._addon
get_localized = KODIPLUGIN.get_localized


def request_skin_reload(reason='vcl'):
    """Queue only an explicit user viewtype reload; other generated XML stays manual."""
    try:
        win = xbmcgui.Window(10000)
        reason = str(reason or 'vcl')
        win.setProperty('VCL.SkinReloadRequired', 'true')
        win.setProperty('VCL.SkinReloadReason', reason)
        if reason == 'viewtypes':
            # Перезагрузку выполняет служба скина между своими тактами
            # (vcl_service._maybe_safe_skin_reload, без задержки для viewtypes_user).
            # ReloadSkin() отсюда шёл посреди такта службы: окна хаба удалялись,
            # пока служба держала их объекты, и Kodi падал в
            # CGUIWindow::SetProperty (SIGSEGV, .20, 16.11.2026, первый запуск
            # после установки).
            import time
            win.setProperty('VCL.ShortcutsReloadReason', 'viewtypes_user')
            win.setProperty('VCL.ShortcutsReloadRequestedAt', str(int(time.time())))
            win.setProperty('VCL.ShortcutsReloadPending', 'true')
        else:
            win.clearProperty('VCL.ShortcutsReloadPending')
            win.clearProperty('VCL.ShortcutsReloadReason')
            win.clearProperty('VCL.ShortcutsReloadRequestedAt')
    except Exception:
        pass



LOGGER = jurialmunkey_logger.Logger(
    log_name='skin.sublime - ',
    notification_head=f'VCLVariables {get_localized(257)}',
    notification_text=get_localized(2104),
    debug_logging=False)
kodi_log = LOGGER.kodi_log
BusyDialog = jurialmunkey_dialog.BusyDialog
busy_decorator = jurialmunkey_dialog.busy_decorator


@contextmanager
def isactive_winprop(name, value='True', windowid=10000, reverse=False):
    win = xbmcgui.Window(windowid)
    win.setProperty(name, value) if not reverse else win.clearProperty(name)
    try:
        yield
    finally:
        win.setProperty(name, value) if reverse else win.clearProperty(name)


class ProgressDialog(jurialmunkey_dialog.ProgressDialog):
    @staticmethod
    def kodi_log(msg, level=0):
        kodi_log(msg, level)
