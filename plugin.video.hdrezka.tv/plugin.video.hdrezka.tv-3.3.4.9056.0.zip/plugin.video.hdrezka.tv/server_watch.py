# -*- coding: utf-8 -*-
"""Сведения о серверах источника и переключение на работающий.

Один и тот же файл в Filmix (resources/libs/server_watch.py) и HDRezka (server_watch.py) -
правится в обоих (sublime-box/CHANGE_PROTOCOL.md).

ЗАЧЕМ (владелец 20.11.2026)
* в фоне всегда знать, какие серверы точно работают;
* выбранный не отвечает 10-20 минут - перейти на работающий (3 часа держать отказавший - много);
* отличать «нет интернета» от «не отвечает сервер»: без интернета сервер не виноват;
* после смены сервера или возврата связи - добрать пропущенное (on_event у дополнения);
* «главное бан не словить»: основной сигнал - НАСТОЯЩИЕ запросы дополнения (report),
  свои пробы редкие: текущий - только если полчаса не было запросов, запасные - раз в 6 ч
  (spares_when_ok=False - пока текущий в порядке, не щупаются вовсе), пока текущий не
  отвечает - раз в 30 мин на каждый.

Состояние - addon_data/<дополнение>/servers.json, его читают клиент (current) и скин.
Первый выбор (сведений ещё нет - новая установка или обновление) - служба проверяет все
серверы с коробки и берёт самый быстрый рабочий; установщик для этого не нужен.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import time

SWITCH_AFTER = 15 * 60          # текущий не отвечает столько при живом интернете - переключение
OK_FRESH = 6 * 3600             # «точно работает» - ответ не старше этого
PROBE_IDLE_CURRENT = 30 * 60    # текущий щупаем сами, только если столько не было запросов
PROBE_SPARE = 6 * 3600          # запасные, пока текущий в порядке
PROBE_SPARE_FAILING = 30 * 60   # запасные, пока текущий не отвечает
PROBE_FAILING_CURRENT = 5 * 60  # текущий, пока не отвечает (ждём возврата или 15 минут)
NET_URLS = ('http://connectivitycheck.gstatic.com/generate_204',
            'http://cp.cloudflare.com/generate_204',
            'http://www.msftconnecttest.com/connecttest.txt')


def internet_ok(timeout=5):
    """Есть ли интернет вообще - по нейтральным адресам, не по источнику."""
    import urllib.request
    for url in NET_URLS:
        try:
            r = urllib.request.urlopen(url, timeout=timeout)
            if 200 <= r.status < 400:
                return True
        except Exception:
            continue
    return False


class Watch(object):
    def __init__(self, profile, candidates, default='', log=None, spares_when_ok=True):
        self.path = os.path.join(profile, 'servers.json')
        self.candidates = [c for c in candidates if c]
        self.default = default or (self.candidates[0] if self.candidates else '')
        self.log = log or (lambda msg: None)
        # False - запасные щупать только при отказе текущего (21.11.2026)
        self.spares_when_ok = spares_when_ok
        self._written = None            # текст servers.json, последний прочитанный или записанный

    # ---- состояние -------------------------------------------------------
    def load(self):
        try:
            with open(self.path, encoding='utf-8') as fh:
                text = fh.read()
            st = json.loads(text)
            self._written = text
            if isinstance(st, dict):
                st.setdefault('hosts', {})
                return st
        except Exception:
            pass
        return {'current': '', 'hosts': {}, 'epoch': 0}

    def save(self, st):
        try:
            text = json.dumps(st, ensure_ascii=False, indent=1)
            if text == self._written:
                return                  # без изменений - не писать (было: раз в минуту, 21.11.2026)
            os.makedirs(os.path.dirname(self.path), exist_ok=True)
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fh:
                fh.write(text)
            os.replace(tmp, self.path)
            self._written = text
        except Exception as exc:
            self.log('servers.json не записан: %s' % exc)

    def current(self):
        st = self.load()
        cur = st.get('current') or ''
        return cur if cur in self.candidates else self.default

    # ---- сигнал от настоящих запросов ------------------------------------
    def report(self, host, ok, ms=0):
        """Итог настоящего запроса дополнения к серверу. Отказ без интернета не считается."""
        if host not in self.candidates:
            return
        st = self.load()
        h = st['hosts'].setdefault(host, {})
        now = int(time.time())
        h['used'] = now
        if ok:
            h['ok'] = now
            h['fail'] = 0
            if ms:
                h['ms'] = int(ms)
        elif not h.get('fail'):
            h['fail'] = now
        self.save(st)

    # ---- фон -------------------------------------------------------------
    def tick(self, probe):
        """Вызывается службой раз в минуту. probe(host) -> (ok, ms). Возвращает событие:
        'switched' (новый сервер), 'recovered' (вернулась связь или сервер), None."""
        st = self.load()
        now = int(time.time())
        hosts = st['hosts']
        if st.get('current') not in self.candidates and internet_ok():
            # первый запуск (новая установка или обновление дополнения): проверить все
            # серверы и взять самый быстрый рабочий - выбор всегда автоматический
            results = {}
            for host in self.candidates:
                ok, ms = self._probe(probe, host)
                results[host] = ms if ok else None
            best = self.seed(results)
            self.log('первый выбор: %s (%s)' % (best or self.default, ', '.join(
                '%s %s' % (h, '%d мс' % ms if ms is not None else 'нет') for h, ms in results.items())))
            if not best:
                st = self.load()
                st['current'] = self.default
                self.save(st)
            return None
        cur = st.get('current') if st.get('current') in self.candidates else self.default
        st['current'] = cur
        hc = hosts.setdefault(cur, {})
        event = None
        failing = bool(hc.get('fail'))

        # текущий: щупаем только если давно не было настоящих запросов или он не отвечает
        last_seen = max(hc.get('used', 0), hc.get('probe', 0))
        due = (now - last_seen >= PROBE_IDLE_CURRENT) or (failing and now - hc.get('probe', 0) >= PROBE_FAILING_CURRENT)
        if due:
            ok, ms = self._probe(probe, cur)
            hc['probe'] = now
            if ok:
                hc.update(ok=now, fail=0, ms=int(ms))
                failing = False
            elif not hc.get('fail'):
                hc['fail'] = now
                failing = True

        # отказ текущего - сначала интернет: без него сервер не виноват
        net_was_down = bool(st.get('net_down'))
        if failing:
            if internet_ok():
                if net_was_down:
                    st['net_down'] = 0
                    # отказы во время обрыва не считаются - отсчёт заново
                    hc['fail'] = now
                    self.log('интернет вернулся, %s по-прежнему не отвечает' % cur)
            else:
                if not net_was_down:
                    st['net_down'] = now
                    self.log('нет интернета - %s не считается упавшим' % cur)
                hc['fail'] = now          # пока нет сети, 15 минут не копятся
                self.save(st)
                return None
        elif net_was_down or st.get('was_failing'):
            st['net_down'] = 0
            event = 'recovered'
            self.log('%s снова отвечает - добираю пропущенное' % cur)
        st['was_failing'] = failing

        # запасные: чаще - пока текущий не отвечает; пока всё хорошо - редко или вовсе нет
        spare_every = PROBE_SPARE_FAILING if failing else (PROBE_SPARE if self.spares_when_ok else 0)
        for host in self.candidates if spare_every else ():
            if host == cur:
                continue
            h = hosts.setdefault(host, {})
            if now - h.get('probe', 0) >= spare_every:
                ok, ms = self._probe(probe, host)
                h['probe'] = now
                if ok:
                    h.update(ok=now, fail=0, ms=int(ms))
                elif not h.get('fail'):
                    h['fail'] = now
                break                      # не больше одного запасного за минуту

        # переключение: текущий молчит SWITCH_AFTER при живом интернете
        if failing and hc.get('fail') and now - hc['fail'] >= SWITCH_AFTER:
            good = [h for h in self.candidates if h != cur
                    and not hosts.get(h, {}).get('fail')
                    and now - hosts.get(h, {}).get('ok', 0) <= OK_FRESH]
            if good:
                best = min(good, key=lambda h: hosts[h].get('ms') or 99999)
                self.log('%s не отвечает %d мин - переключаюсь на %s'
                         % (cur, (now - hc['fail']) // 60, best))
                st['current'] = best
                st['switched'] = now
                st['was_failing'] = False
                event = 'switched'
        if event:
            st['epoch'] = int(st.get('epoch', 0)) + 1
        self.save(st)
        return event

    @staticmethod
    def _probe(probe, host):
        t0 = time.time()
        try:
            ok = bool(probe(host))
        except Exception:
            ok = False
        return ok, (time.time() - t0) * 1000

    def seed(self, results):
        """Первое состояние: {host: ms или None}; текущий - самый быстрый рабочий."""
        now = int(time.time())
        st = self.load()
        for host, ms in results.items():
            h = st['hosts'].setdefault(host, {})
            h['probe'] = now
            if ms is not None:
                h.update(ok=now, fail=0, ms=int(ms))
            else:
                h['fail'] = now
        good = [h for h, ms in results.items() if ms is not None]
        if good:
            st['current'] = min(good, key=lambda h: results[h])
        self.save(st)
        return st.get('current')
