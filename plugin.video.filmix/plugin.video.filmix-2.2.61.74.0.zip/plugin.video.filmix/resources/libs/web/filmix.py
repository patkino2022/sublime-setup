# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import time

__all__ = ['FilmixClient', 'FilmixError']


class FilmixError(Exception):

    def __init__(self, message, code=None):
        self.message = message
        self.code = code

        super(FilmixError, self).__init__(self.message)


# Не чаще одного запроса к API за REQUEST_GAP секунд - на всю коробку (каждый список Kodi
# открывает отдельным процессом, поэтому отметка последнего запроса - в файле под замком).
# Те же нормы, что у HDRezka, которая за запрос в секунду закрыла домашний адрес
# (владелец 17.11.2026: «для филмикса - те же нормативы»)
REQUEST_GAP = 1.5
# Фоновые запросы (служба, прогрев) уступают пользователю: пока он листает или запускает -
# последний его запрос моложе INTERACTIVE_HOLD - фон ждёт. Общая частота не растёт.
INTERACTIVE_HOLD = 4.0


def _pace(background=False, unpaced=False):
    import os
    import time
    try:
        import fcntl
        import xbmcvfs
        folder = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.filmix/')
    except Exception:
        return
    try:
        os.makedirs(folder, exist_ok=True)
        mark = os.path.join(folder, 'interactive_at')
        if background:
            # не дольше трёх выдержек подряд: фон всё равно должен пройти
            for _ in range(3):
                try:
                    left = os.path.getmtime(mark) + INTERACTIVE_HOLD - time.time()
                except OSError:
                    break
                if left <= 0:
                    break
                time.sleep(min(left, INTERACTIVE_HOLD))
        else:
            try:
                with open(mark, 'a'):
                    pass
                os.utime(mark, None)
            except OSError:
                pass
            if unpaced:
                # пользовательский поиск - без общей очереди (владелец 24.11.2026): запрос
                # поиска и описания найденного идут сразу и параллельно
                return
        with open(os.path.join(folder, 'last_request'), 'a+') as fh:
            fcntl.flock(fh, fcntl.LOCK_EX)
            fh.seek(0)
            try:
                last = float(fh.read().strip() or 0)
            except ValueError:
                last = 0.0
            wait = last + REQUEST_GAP - time.time()
            if 0 < wait <= REQUEST_GAP:
                time.sleep(wait)
            fh.seek(0)
            fh.truncate()
            fh.write('%.3f' % time.time())
            fh.flush()
    except OSError:
        pass


AUTO_APIS = ('http://filmixapp.vip/', 'http://filmixapp.cyou/')


def auto_server_on():
    """Настройка «Автовыбор сервера» (по умолчанию включена). Выключена - только сервер из
    настроек (api_url или встроенный), без проверок и переключений (коробки владельца)."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon('plugin.video.filmix').getSetting('auto_server') != 'false'
    except Exception:
        return True


def server_watch():
    """Сведения о серверах API (server_watch.py): текущий выбирает служба, а не отказ запроса."""
    if not auto_server_on():
        return None
    try:
        import xbmc
        import xbmcvfs
        from ..server_watch import Watch
        profile = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.filmix/')
        return Watch(profile, AUTO_APIS, log=lambda m: xbmc.log('[plugin.video.filmix] серверы: ' + m,
                                                                 xbmc.LOGINFO))
    except Exception:
        return None


def probe_api(base, dev_id='probe'):
    """Лёгкий запрос к API - тот же, что у установщика: token_request отвечает JSON-ом."""
    import json as _json
    import urllib.request
    url = ('%sapi/v2/token_request?user_dev_apk=2.0.9&user_dev_id=%s&user_dev_name=KODI'
           '&user_dev_os=12&user_dev_vendor=KODI' % (base, dev_id or 'probe'))
    r = urllib.request.urlopen(url, timeout=15)
    _json.loads(r.read().decode('utf-8', 'replace'))
    return True


class FilmixClient(object):
    _base_url = 'http://filmixapp.vip/' #.cyou/'
    _default_timeout = (3.05, 10)

    _user_dev_apk = '2.0.9'
    _user_dev_id = None
    _user_dev_name = None
    _user_dev_token = None
    _user_dev_vendor = None
    _user_dev_os = None

    def __init__(self, api_url=''):

        # сервер API - из сведений службы (server_watch): выбран установщиком по проверке с
        # коробки, сменяется службой, если не отвечает 15 минут при живом интернете;
        # api_url старых установок - только если сведений ещё нет
        self._watch = server_watch()
        known = self._watch.current() if self._watch and self._watch.load().get('current') else ''
        self._base_url = known or api_url or self._base_url

        headers = {#'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                   'Accept-Encoding': 'gzip',
                   'Content-Length': '0',
                   'Accept': None,
                   'User-Agent': None
                   }

        import requests  # только когда клиент действительно создают
        self._client = requests.Session()
        self._client.headers.update(headers)

    def __del__(self):
        try:
            self._client.close()
        except Exception:
            pass

    def _add_device_info(self, params):
        params = dict(params or {})
        params['user_dev_id'] = self._user_dev_id
        params['user_dev_name'] = self._user_dev_name
        params['user_dev_token'] = self._user_dev_token
        params['user_dev_vendor'] = self._user_dev_vendor
        params['user_dev_os'] = self._user_dev_os
        params['user_dev_apk'] = self._user_dev_apk

        return params

    def _get(self, url, params=None, *args, **kwargs):
        _pace(getattr(self, '_background', False), getattr(self, '_unpaced', False))
        params = self._add_device_info(params)
        if 'timeout' not in kwargs:
            kwargs['timeout'] = self._default_timeout

        return self._mirrored(self._client.get, url, *args, params=params, **kwargs)

    def _post(self, url, data=None, *args, **kwargs):
        _pace(getattr(self, '_background', False), getattr(self, '_unpaced', False))
        data = self._add_device_info(data)
        if 'timeout' not in kwargs:
            kwargs['timeout'] = self._default_timeout

        return self._mirrored(self._client.post, url, *args, data=data, **kwargs)

    @staticmethod
    def _refused(response):
        return response.status_code == 403 or response.status_code >= 500

    def _mirrored(self, send, url, *args, **kwargs):
        """Запрос к текущему серверу; один обрыв - повтор на нём же. Итог - в сведения о
        серверах (настоящие запросы - основной сигнал, без лишних проб: бан не ловим).
        Чужие серверы здесь не перебираются - переключает служба (server_watch.tick)."""
        import time as _time
        response = None
        for attempt in (1, 2):
            t0 = _time.time()
            try:
                response = send(url, *args, **kwargs)
                failed = self._refused(response)
            except Exception as exc:
                response, failed = exc, True
            if not failed:
                break
        if self._watch is not None and url.startswith(self._base_url):
            try:
                self._watch.report(self._base_url, not failed, (_time.time() - t0) * 1000)
            except Exception:
                pass
        if isinstance(response, Exception):
            raise response
        return response
    @staticmethod
    def _extract_json(r):

        if not r.text:
            raise FilmixError('Server sent an empty response')

        try:
            j = r.json()
        except ValueError as e:
            raise FilmixError(e)

        if isinstance(j, dict) and j.get('error') is not None:
            error = j.get('error')
            if isinstance(error, dict):
                message = error.get('user_message') or error.get('message') or str(error)
                raise FilmixError(message, error.get('code'))
            raise FilmixError(str(error))
        return j

    @staticmethod
    def create_dev_id():
        import random
        charsets = '0123456789abcdef'
        rng = random.SystemRandom()
        return ''.join(rng.choice(charsets) for _ in range(16))

    def token_request(self):
        url = self._base_url + 'api/v2/token_request'

        r = self._get(url)
        j = self._extract_json(r)

        return j

    def set_videoserver(self, vs_schg):
        url = self._base_url + '/api/v2/change_server'

        data = {'vs_schg': vs_schg,
                }

        r = self._post(url, data=data)
        j = self._extract_json(r)

        return j

    def user_data(self):
        url = self._base_url + 'api/v2/user_profile'

        r = self._get(url)
        j = self._extract_json(r)

        if isinstance(j, dict):
            result = j.get('user_data', {})
        else:
            result = {}

        return result


    def catalog(self, page=1, section=0, filters='', orderby='date', orderdir='desc'):
        url = self._base_url + 'api/v2/catalog'

        filter_items = filters.split('-') if filters else []
        filter_items.append('s{0}'.format(section))

        params = {'orderby': orderby,
                  'orderdir': orderdir,
                  'filter': '{0}'.format('-'.join(filter_items)),
                  'page': page,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def popular(self, page=1):
        url = self._base_url + 'api/v2/popular'

        params = {'page': page,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def top_views(self, page=1):
        url = self._base_url + 'api/v2/top_views'

        params = {'page': page,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def favourites(self, page=1, orderby='date', orderdir='desc'):
        url = self._base_url + 'api/v2/favourites'

        params = {'orderby': orderby,
                  'orderdir': orderdir,
                  'page': page,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def deferred(self, page=1):
        url = self._base_url + 'api/v2/deferred'

        params = {'page': page,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def history(self, page=1):
        url = self._base_url + 'api/v2/history'

        params = {'page': page,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def post(self, post_id='', force_refresh=False):
        url = self._base_url + 'api/v2/post/{0}'.format(post_id)

        params = None
        kwargs = {}
        if force_refresh:
            # The Filmix mobile API can be cached by intermediate proxies. A
            # unique query value plus no-cache headers ensures an interactive
            # series open checks the current playlist instead of replaying an
            # old 3/5-episode response.
            params = {'_filmix_refresh': int(time.time() * 1000)}
            kwargs['headers'] = {'Cache-Control': 'no-cache', 'Pragma': 'no-cache'}

        r = self._get(url, params=params, **kwargs)
        j = self._extract_json(r)

        return j

    def search(self, story):
        url = self._base_url + 'api/v2/search'
        params = {'story': story,
                  }

        r = self._get(url, params)
        j = self._extract_json(r)

        return j

    def get_filter(self, filter_id=None):
        url = self._base_url + 'api/v2/filter_list'

        if filter_id == 'rip':
            return self._filters_rip()

        r = self._get(url)
        j = self._extract_json(r)

        if filter_id is not None:
            return j[filter_id]
        else:
            j['rip'] = self._filters_rip()
            return j

    def set_favorite(self, post_id):
        url = self._base_url + 'api/v2/toggle_fav/{0}'.format(post_id)

        r = self._get(url)
        j = self._extract_json(r)

        return j

    def set_watch_later(self, post_id):
        url = self._base_url + 'api/v2/toggle_wl/{0}'.format(post_id)

        r = self._get(url)
        j = self._extract_json(r)

        return j

    def add_watched(self, post_id, season=None, episode=None, translation=None):
        url = self._base_url + 'api/v2/add_watched'

        data = {'add_watched': 'true',
                'id': post_id,
                }

        if season is not None:
            data['season'] = season

        if episode is not None:
            data['episode'] = episode

        if translation is not None:
            data['translation'] = translation

        self._post(url, data=data)

    def check_update(self):
        url = self._base_url + 'api/v2/check_update'

        r = self._get(url)
        return self._extract_json(r)

    def url_available(self, url):
        r = None
        try:
            r = self._client.head(url, allow_redirects=True, timeout=self._default_timeout)
            if r.status_code not in [403, 404, 405] and r.status_code < 500:
                return True
        except Exception:
            pass
        finally:
            try:
                if r is not None:
                    r.close()
            except Exception:
                pass

        # Some CDNs reject HEAD although the media URL works. Verify with a
        # one-byte ranged GET instead of treating every network exception as a
        # successful link.
        r = None
        try:
            r = self._client.get(url, headers={'Range': 'bytes=0-0'}, stream=True,
                                 allow_redirects=True, timeout=self._default_timeout)
            return r.status_code not in [403, 404] and r.status_code < 500
        except Exception:
            return False
        finally:
            try:
                if r is not None:
                    r.close()
            except Exception:
                pass

    def get_direct_link(self, url):
        r = self._client.head(url, allow_redirects=True, timeout=self._default_timeout)
        try:
            return r.url
        finally:
            r.close()

    @staticmethod
    def _filters_rip():
        result = {
            'fn': 'Хорошее (DVDRip, HDRip, SAT...)',
            'fg': 'Отличное (HD 720)',
            'fh': 'Шедевральное (FHD 1080)',
            'f2': '1080p+ (FHD Ultra+)',
            'f4': '4К (UHD 2160р)'
        }

        return result
