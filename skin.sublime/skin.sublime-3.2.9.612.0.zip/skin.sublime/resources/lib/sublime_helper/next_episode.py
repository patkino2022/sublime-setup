# -*- coding: utf-8 -*-
"""Следующая серия в конце эпизода - своя, без service.upnext.

service.upnext показывает своё окно только для серий из библиотеки Kodi или
для дополнений, которые шлют ему upnext_data. Filmix не шлёт ничего, поэтому
у владельца окно не появлялось никогда (17.10.2026: «не появляется при
окончании серии»).

Здесь всё делает служба скина. Как только началась серия Filmix, она один раз
спрашивает у самого Filmix список серий этого сезона (тот же маршрут, что
открывает сезон на экране, ~0,6 с) и находит следующую: в этом сезоне и
озвучке, иначе первую серию следующего сезона.

Окно script-sublime-nextepisode.xml открывается с началом титров. Откуда это
время (владелец 17.10.2026: «как можно точнее угадывать момент окончания серии
и показ титров»), по порядку:
  1. титры этой серии - по провалу потока в заголовке mp4 (credits.py);
  2. титры прошлых серий этого сериала, если эту измерить не удалось;
  3. где владелец сам останавливал серии этого сериала незадолго до конца;
  4. NOTICE_SECONDS до конца.
Через COUNTDOWN_SECONDS после открытия, или по «Далее», следующая серия
запускается через Player.Open (не PlayMedia - та уводит из видео на главный экран). «Отмена» и «Назад» гасят окно
до конца этой серии.

Отсчёт идёт по времени плеера, а не по часам: на паузе стоит и он, перемотка
назад закрывает окно, и оно откроется снова ближе к концу.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import re
import threading
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcaddon
import xbmcgui
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

from .core import builtin_escape, jsonrpc
from . import credits

# Когда открыть окно, если про титры ничего не известно.
NOTICE_SECONDS = 30
# Сколько идёт отсчёт после открытия окна. Окно открывается с началом титров,
# и через COUNTDOWN_SECONDS серия сменяется, даже если титры длиннее.
COUNTDOWN_SECONDS = 30
# Остановка в этих пределах до конца - «досмотрел и ушёл на титрах».
LEARN_MIN_SECONDS = 10
LEARN_MAX_SECONDS = 600
LEARN_KEEP = 5
TIMING_FILE = 'special://profile/addon_data/skin.sublime/next_episode_timing.json'
# Короче десяти минут - не серия (заставки, трейлеры, клипы).
MIN_TOTAL_SECONDS = 600
XML = 'script-sublime-nextepisode.xml'

_FILMIX_PLAY = re.compile(r'^(plugin://plugin\.video\.filmix/[^/?]+/[^/?]+/)play/\?(.+)$')
_LIST_PROPS = ['title', 'season', 'episode', 'art', 'file', 'showtitle', 'year', 'rating']

_ACTION_BACK = (9, 10, 92)
_ACTION_STOP = 13
_ACTION_PAUSE = (12, 229)

_BUTTON_PLAY = 3012
_BUTTON_CANCEL = 3013
_PROGRESS = 3014


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[skin.sublime] next episode: %s' % msg, level)


def _listing(path):
    answer = jsonrpc('Files.GetDirectory', {
        'directory': path, 'media': 'video', 'properties': _LIST_PROPS})
    return ((answer or {}).get('result') or {}).get('files') or []


def _num(value):
    try:
        return int(value)
    except Exception:
        return -1


def _first_after(rows, season, episode):
    later = [r for r in rows
             if _num(r.get('season')) == season and _num(r.get('episode')) > episode
             and r.get('file') and r.get('filetype') != 'directory']
    return min(later, key=lambda r: _num(r.get('episode'))) if later else None


def _find_next_hdrezka(playing):
    """HDrezka: play_episode с season_id/episode_id; серии - в папке сезона сериала."""
    params = parse_qs(playing.split('?', 1)[1] if '?' in playing else '')
    if (params.get('mode') or [''])[0] != 'play_episode':
        return None
    uri = (params.get('url') or [''])[0]
    season = _num((params.get('season_id') or [''])[0])
    episode = _num((params.get('episode_id') or [''])[0])
    if not uri or season < 0 or episode < 0:
        return None
    base = 'plugin://plugin.video.hdrezka.tv/?'
    found = _first_after(_listing(base + urlencode({'mode': 'show', 'uri': uri, 'season': season})), season, episode)
    if found:
        return found
    seasons = [r for r in _listing(base + urlencode({'mode': 'show', 'uri': uri}))
               if r.get('filetype') == 'directory' and _num(r.get('season')) > season]
    if not seasons:
        return None
    following = min(seasons, key=lambda r: _num(r.get('season')))
    return _first_after(_listing(following['file']), _num(following.get('season')), 0)


def find_next(playing):
    """Следующая серия после playing (путь плагина) или None."""
    if (playing or '').startswith('plugin://plugin.video.hdrezka.tv/'):
        return _find_next_hdrezka(playing)
    match = _FILMIX_PLAY.match(playing or '')
    if not match:
        return None
    base, query = match.groups()
    params = parse_qs(query)
    season = _num((params.get('s') or [''])[0])
    episode = _num((params.get('e') or [''])[0])
    if season < 0 or episode < 0:
        return None
    translation = (params.get('t') or [''])[0]
    args = {'s': season}
    if translation:
        args['t'] = translation
    found = _first_after(_listing(base + 'episodes/?' + urlencode(args)), season, episode)
    if found:
        return found
    # Серия была последней в сезоне - первая серия следующего.
    seasons = [r for r in _listing(base)
               if r.get('filetype') == 'directory' and _num(r.get('season')) > season]
    if not seasons:
        return None
    following = min(seasons, key=lambda r: _num(r.get('season')))
    return _first_after(_listing(following['file']), _num(following.get('season')), 0)


def _median(values):
    values = sorted(v for v in values if v)
    return values[len(values) // 2] if values else None


def _timing_path():
    path = TIMING_FILE
    try:
        path = xbmcvfs.translatePath(path)
    except Exception:
        pass
    return path


def _load_timing():
    try:
        with open(_timing_path(), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _remember(show, kind, seconds):
    """Запомнить для сериала: credits - найденные титры, stops - остановки."""
    if not show or not seconds:
        return
    data = _load_timing()
    entry = data.setdefault(show, {})
    values = [int(v) for v in entry.get(kind) or [] if v][-(LEARN_KEEP - 1):]
    values.append(int(seconds))
    entry[kind] = values
    path = _timing_path()
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(data, ensure_ascii=False))
        os.replace(tmp, path)
    except Exception as exc:
        _log('не записал время титров: %s' % exc, xbmc.LOGWARNING)


def notice_for(show, found=None):
    """За сколько секунд до конца открыть окно и откуда это известно."""
    if found:
        return found, 'титры этой серии'
    entry = _load_timing().get(show) or {}
    value = _median(entry.get('credits') or [])
    if value:
        return value, 'титры прошлых серий'
    value = _median(entry.get('stops') or [])
    if value:
        return value, 'ваши остановки'
    return NOTICE_SECONDS, 'по умолчанию'


class _Dialog(xbmcgui.WindowXMLDialog):

    def __init__(self, *args, **kwargs):
        super(_Dialog, self).__init__(*args, **kwargs)
        self.choice = ''
        self.reason = ''

    def fill(self, row):
        art = row.get('art') or {}
        thumb = (art.get('still') or art.get('thumb') or art.get('landscape')
                 or art.get('fanart') or '')
        self.setProperty('title', row.get('title') or row.get('label') or '')
        self.setProperty('tvshowtitle', row.get('showtitle') or '')
        self.setProperty('season', str(row.get('season') or ''))
        self.setProperty('episode', str(row.get('episode') or ''))
        self.setProperty('thumb', thumb)
        year = _num(row.get('year'))
        self.setProperty('year', str(year) if year > 0 else '')

    def tick(self, left, length):
        self.setProperty('remaining', str(max(0, int(left + 0.5))))
        try:
            self.getControl(_PROGRESS).setPercent(
                max(0.0, min(100.0, 100.0 * left / max(1.0, length))))
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == _BUTTON_PLAY:
            self.choice = 'play'
            self.close()
        elif control_id == _BUTTON_CANCEL:
            self.choice = 'cancel'
            self.reason = 'кнопка «Отмена»'
            self.close()

    def onAction(self, action):
        action_id = action.getId()
        if action_id in _ACTION_BACK:
            self.choice = 'cancel'
            self.reason = 'действие %d (назад)' % action_id
            self.close()
        elif action_id == _ACTION_STOP:
            self.choice = 'cancel'
            self.reason = 'стоп'
            self.close()
            xbmc.Player().stop()
        elif action_id in _ACTION_PAUSE:
            xbmc.Player().pause()


class Watcher(threading.Thread):
    """Следит за плеером: дёшево, пока играет не Filmix, раз в секунду в серии."""

    def __init__(self, monitor):
        super(Watcher, self).__init__(name='sublime-next-episode')
        self.daemon = True
        self._monitor = monitor
        self._player = xbmc.Player()
        self._path = ''
        self._show = ''
        self._next = None
        self._notice = NOTICE_SECONDS
        self._cancelled = False
        self._started_next = False
        self._dialog = None
        self._fire_at = 1.0
        self._countdown = COUNTDOWN_SECONDS
        self._last_remaining = None
        self._last_total = 0

    # --- поиск следующей серии и титров в стороне, чтобы не держать отсчёт ---
    def _lookup(self, path):
        try:
            row = find_next(path)
        except Exception as exc:
            _log('поиск не удался: %s' % exc, xbmc.LOGWARNING)
            row = None
        if path != self._path:
            return
        self._next = row or {}
        if row:
            _log('после %s - S%sE%s %s' % (path, row.get('season'), row.get('episode'),
                                            row.get('file')))
        else:
            _log('после %s серий нет' % path)

    def _measure(self, path):
        found = None
        stream = ''
        for _ in range(20):
            # Разрешённая ссылка появляется не сразу после старта плагина.
            if path != self._path or self._monitor.abortRequested():
                return
            try:
                stream = self._player.getPlayingFile() or ''
            except Exception:
                stream = ''
            if stream.startswith('http'):
                break
            if self._monitor.waitForAbort(1.0):
                return
        if stream.startswith('http'):
            try:
                found = credits.find_credits(stream)
            except Exception as exc:
                _log('титры не измерены: %s' % exc, xbmc.LOGWARNING)
        else:
            _log('титры не измерены: плеер отдаёт %s' % (stream[:60] or 'пустой путь'))
        if path != self._path:
            return
        if found:
            _remember(self._show, 'credits', found)
        self._notice, source = notice_for(self._show, found)
        _log('окно за %d с до конца (%s)' % (self._notice, source))

    def _reset(self, path=''):
        self._learn()
        self._close()
        self._path = path
        match = _FILMIX_PLAY.match(path or '')
        self._show = match.group(1) if match else ''
        self._next = None
        self._notice = NOTICE_SECONDS
        self._cancelled = False
        self._started_next = False
        self._last_remaining = None
        self._last_total = 0

    def _learn(self):
        # Остановил серию сам незадолго до конца - значит, там начались титры.
        remaining, total = self._last_remaining, self._last_total
        if not self._show or self._started_next or remaining is None:
            return
        if total < MIN_TOTAL_SECONDS:
            return
        if LEARN_MIN_SECONDS <= remaining <= LEARN_MAX_SECONDS and remaining < total * 0.15:
            _remember(self._show, 'stops', remaining)
            _log('остановка за %d с до конца запомнена для %s' % (remaining, self._show))

    def _close(self):
        dialog, self._dialog = self._dialog, None
        if dialog is not None:
            try:
                dialog.close()
            except Exception:
                pass
        return dialog

    def _play_next(self, why):
        row = self._next or {}
        self._close()
        self._cancelled = True
        target = row.get('file') or ''
        if not target:
            return
        self._started_next = True
        _log('запуск (%s): %s' % (why, target))
        # Не PlayMedia: эта команда из полноэкранного видео сначала делает
        # PreviousWindow() (Kodi, PlayerBuiltins.cpp PlayOrQueueMedia), и
        # владелец 18.10.2026 видел главный экран, пока Filmix отдавал серию:
        # «при нажатии на плей - выходит в главное меню». Player.Open идёт через
        # TMSG_MEDIA_PLAY без смены окна - плеер переключается на месте.
        answer = jsonrpc('Player.Open', {'item': {'file': target}})
        if not (answer or {}).get('result'):
            _log('Player.Open не прошёл (%s) - PlayMedia' % (answer or {}).get('error'),
                 xbmc.LOGWARNING)
            xbmc.executebuiltin('PlayMedia(%s)' % builtin_escape(target))

    def _playlist_continues(self):
        # Если Kodi сам играет плейлист, следующую серию он запустит без нас.
        try:
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            return playlist.size() > 1 and playlist.getposition() + 1 < playlist.size()
        except Exception:
            return False

    def _step(self):
        if not self._player.isPlayingVideo():
            if self._dialog is not None and not self._cancelled \
                    and self._last_remaining is not None \
                    and self._last_remaining <= self._fire_at + 1.5:
                # Файл кончился раньше, чем отсчёт дошёл до нуля.
                self._play_next('конец файла')
            if self._path:
                self._reset()
            return 2.0

        path = xbmc.getInfoLabel('Player.Filenameandpath') or ''
        if path != self._path:
            self._reset(path)
            if self._show:
                threading.Thread(target=self._lookup, args=(path,),
                                 name='sublime-next-lookup', daemon=True).start()
                threading.Thread(target=self._measure, args=(path,),
                                 name='sublime-next-credits', daemon=True).start()
            return 1.0
        if not self._show:
            return 2.0

        try:
            total = self._player.getTotalTime()
            remaining = total - self._player.getTime()
        except Exception:
            return 1.0
        self._last_remaining = remaining
        self._last_total = total
        if self._cancelled or not self._next:
            return 1.0
        if total < MIN_TOTAL_SECONDS or self._playlist_continues():
            return 1.0

        notice = self._notice
        if self._dialog is None:
            if 1.0 < remaining <= notice:
                # Окно открывается с началом титров, а серия сменяется через
                # COUNTDOWN_SECONDS - или в самом конце, если до него меньше.
                self._fire_at = max(1.0, remaining - COUNTDOWN_SECONDS)
                dialog = _Dialog(XML, xbmcaddon.Addon('skin.sublime').getAddonInfo('path'),
                                 'Default', '1080i')
                dialog.fill(self._next)
                dialog.show()
                # Полоса отсчёта существует только у показанного окна.
                dialog.tick(remaining - self._fire_at, remaining - self._fire_at)
                self._dialog = dialog
                self._countdown = remaining - self._fire_at
                _log('окно открыто за %d с до конца, смена через %d с'
                     % (remaining, self._countdown))
            return 0.5 if remaining <= notice + 5 else 1.0

        dialog = self._dialog
        if dialog.choice:
            self._dialog = None
            if dialog.choice == 'play':
                self._play_next('сейчас')
            else:
                self._cancelled = True
                _log('отменено: %s' % (dialog.reason or '?'))
            return 1.0
        if remaining > notice + 5:
            # Перемотали назад - окно уйдёт и вернётся ближе к концу.
            self._close()
            return 1.0
        if remaining <= self._fire_at:
            self._play_next('отсчёт')
            return 1.0
        dialog.tick(remaining - self._fire_at, self._countdown)
        return 0.5

    def run(self):
        while not self._monitor.abortRequested():
            try:
                pause = self._step()
            except Exception as exc:
                _log('сбой: %s' % exc, xbmc.LOGWARNING)
                pause = 2.0
            if self._monitor.waitForAbort(pause):
                break
        self._close()


def start(monitor):
    watcher = Watcher(monitor)
    watcher.start()
    return watcher
