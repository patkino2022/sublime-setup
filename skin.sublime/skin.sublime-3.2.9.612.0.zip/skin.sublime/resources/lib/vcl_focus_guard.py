# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals
import sys
import xbmc
import xbmcgui
import xbmcaddon
import os

_ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
if _ADDON_ROOT not in sys.path:
    sys.path.insert(0, _ADDON_ROOT)
from resources.lib.sublime_helper.hubs import HUB_AND_LOCAL_WINDOW_IDS, hub_from_window_id


try:
    BUILD = xbmcaddon.Addon('skin.sublime').getAddonInfo('version') or 'unknown'
except Exception:
    BUILD = 'unknown'
HOMEISH_WINDOW_IDS = HUB_AND_LOCAL_WINDOW_IDS


def _arg(name, default=''):
    prefix = name + '='
    for arg in sys.argv[1:]:
        if arg.startswith(prefix):
            return arg[len(prefix):]
    return default


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('[sublime focus guard %s] %s' % (BUILD, msg), level)
    except Exception:
        pass


def _int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def _current_window_id():
    try:
        return int(xbmcgui.getCurrentWindowId())
    except Exception:
        return 0


def _current_dialog_id():
    try:
        return int(xbmcgui.getCurrentWindowDialogId())
    except Exception:
        return 0


def _visible(cond):
    try:
        return bool(xbmc.getCondVisibility(cond))
    except Exception:
        return False


def _can_focus_home_control(control, expected_window=0):
    # 526: prevent delayed alarms from applying SetFocus to modal/dialog windows
    # such as 10107; Kodi otherwise logs "Control 400 ... asked to focus".
    if _visible('System.HasModalDialog'):
        return False
    dialog_id = _current_dialog_id()
    if dialog_id not in (0, 9999):
        return False
    window_id = _current_window_id()
    if expected_window:
        expected_hub = hub_from_window_id(expected_window)
        current_hub = hub_from_window_id(window_id)
        if expected_hub:
            if current_hub != expected_hub:
                return False
        elif window_id != expected_window:
            return False
    if window_id not in HOMEISH_WINDOW_IDS:
        return False

    if control == 400:
        return _visible('Control.IsVisible(400)')

    if 501 <= control <= 550:
        # 531: row containers can report visible/non-empty while still rebuilding
        # right after a peer hub is loaded. Do not focus them until Kodi says the
        # row is enabled and not updating.
        return (
            _visible('Control.IsVisible(%d)' % control)
            and _visible('Control.IsEnabled(%d)' % control)
            and not _visible('Container(%d).IsUpdating' % control)
            and not _visible('Integer.IsEqual(Container(%d).NumItems,0)' % control)
        )

    return _visible('Control.IsVisible(%d)' % control)


def _first_ready_widget():
    for candidate in range(501, 551):
        if _can_focus_home_control(candidate, 0):
            return candidate
    return 400 if _can_focus_home_control(400, 0) else 0


def main(control=None, expected_window=None, wait_ms=None, fallback=None):
    control = _int(control if control is not None else _arg('control', '400'), 400)
    expected_window = _int(
        expected_window if expected_window is not None else _arg('expected_window', '0'), 0)
    wait_ms = max(0, min(3000, _int(wait_ms if wait_ms is not None else _arg('wait_ms', '0'), 0)))
    fallback_value = fallback if fallback is not None else _arg('fallback', '')
    fallback_enabled = str(fallback_value or '').strip().lower() in ('1', 'true', 'yes', 'on')
    deadline = __import__('time').monotonic() + (wait_ms / 1000.0)
    monitor = xbmc.Monitor()
    try:
        while True:
            if _can_focus_home_control(control, expected_window):
                xbmc.executebuiltin('SetFocus(%d)' % control)
                return True
            if _visible('System.HasModalDialog'):
                return False
            if __import__('time').monotonic() >= deadline:
                if fallback_enabled:
                    fallback_control = _first_ready_widget()
                    if fallback_control:
                        xbmc.executebuiltin('SetFocus(%d)' % fallback_control)
                        return True
                return False
            if monitor.waitForAbort(0.04):
                return False
    except Exception as exc:
        log('skip SetFocus(%d) expected_window=%d: %s' % (control, expected_window, exc), xbmc.LOGWARNING)
        return False


if __name__ == '__main__':
    main()
