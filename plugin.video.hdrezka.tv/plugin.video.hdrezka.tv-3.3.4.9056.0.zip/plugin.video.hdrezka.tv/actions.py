import requests

import xbmcgui

from helpers import log, busy_dialog, dump_cookies, USER_AGENT


LOGIN_FILE = 'special://temp/hdrezka_login.json'


def _take_login_file(plugin):
    """Логин и пароль, которые положил установщик (вход в конце установки, как у
    YouTube): переносятся в настройки дополнения, файл сразу удаляется."""
    import json
    import os
    import xbmcvfs
    path = xbmcvfs.translatePath(LOGIN_FILE)
    try:
        with open(path, encoding='utf-8') as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    if data.get('login') and data.get('password'):
        plugin.addon.setSetting('username', data['login'])
        plugin.addon.setSetting('password', data['password'])


def authorize(plugin):
    log('*** authorize')
    _take_login_file(plugin)

    with busy_dialog():
        login_response = plugin.make_response('POST', '/ajax/login/', data={
            'login_name': plugin.addon.getSetting('username'),
            'login_password': plugin.addon.getSetting('password'),
            'login_not_save': '0'
        })

        try:
            data = login_response.json()
        except ValueError:
            # ответ не JSON
            log(f'code: {login_response.status_code} text: {login_response.text[:300]}')
            xbmcgui.Dialog().ok('HDRezka', 'Сайт не ответил на вход (код %s). Попробуйте позже.'
                                % login_response.status_code)
            return
        if not data.get('success'):
            log(f'code: {login_response.status_code} text: {login_response.text}')
            msg = data.get('message') or 'Fault authorize'
            if isinstance(msg, dict):
                # сайт отвечает словарём по полям: {"email": "Введен недопустимый email или пароль"}
                msg = chr(10).join(str(v) for v in msg.values() if v) or 'Fault authorize'
            xbmcgui.Dialog().ok('HDRezka', str(msg))
            return

        cookies = login_response.cookies
        cookies['hdmbbs'] = '1'

        plugin.addon.setSetting('cookies', dump_cookies(cookies))
        xbmcgui.Dialog().notification('HDRezka', 'Авторизация успешна', xbmcgui.NOTIFICATION_INFO)


def logout(plugin):
    log('*** logout')

    with busy_dialog():
        try:
            try:
                plugin.make_response('POST', '/ajax/logout/', data={})
            except Exception as ex:
                log(f'logout server request ex: {ex}')
            plugin.session.cookies.clear()
            plugin.addon.setSetting('cookies', '')
            plugin.addon.setSetting('password', '')   # иначе тихий вход (default._quiet_login) вернёт сессию
            xbmcgui.Dialog().notification('HDRezka', 'Вы вышли из аккаунта', xbmcgui.NOTIFICATION_INFO)
        except Exception as ex:
            log(f'logout fault ex: {ex}')
            xbmcgui.Dialog().notification('HDRezka', 'Ошибка при выходе из аккаунта', xbmcgui.NOTIFICATION_ERROR)


def external_config_update(plugin):
    log('*** external_config_update')

    with busy_dialog():
        url = plugin.addon.getSetting('external_config_url')

        log(f'attempt fetch config from: {url}')
        config_response = requests.get(url, timeout=30, headers={'User-Agent': USER_AGENT}, proxies=plugin.proxies)
        if not config_response.ok:
            xbmcgui.Dialog().ok('Error', f'status: {config_response.status_code}')
            return

        for key, new_value in config_response.json().items():
            old_value = plugin.addon.getSetting(key)
            if old_value == new_value:
                continue

            log(f'updating config key: "{key}" from: "{old_value}" to: "{new_value}"')
            plugin.addon.setSetting(key, new_value)

        xbmcgui.Dialog().notification('Success', 'Updated config', xbmcgui.NOTIFICATION_INFO)
