# -*- coding: utf-8 -*-
"""Сколько сериала просмотрено - один подсчёт на все списки.

21.10.2026 владелец: «Почему нельзя сделать один механизм во всех виджетах?»
«Тед Лассо» в «Избранном» стоял с одной непросмотренной серией, а в полосе
хаба «Все» - просмотренным. Считали два разных кода: этот провайдер по своей
таблице watched_state и плейлисту, скин - по базе Kodi и самому длинному
переводу сезона. Каждый раз, когда расходились, чинили одну сторону.

Теперь счёт один, здесь. Его зовут списки провайдера (navigation.py) и полосы
скина (skin.sublime, hub/routes.py): скин загружает этот файл как есть, поэтому
в нём только стандартная библиотека - ни xbmc, ни соседних модулей.

Вход у обоих одинаковый: описание поста из cache4.db (`posts.details`) и снимок
watched_state (FilmixCache.get_watched_snapshot_many или
get_watched_states_many). Ответ тоже: всего, просмотрено, осталось, playcount.
"""

import re

SUMMARY = '__filmix_summary_v1'

_POST_RE = re.compile(r'/(\d+)-')
_SEASON_RE = re.compile(r'[?&]s=(\d+)')
_EPISODE_RE = re.compile(r'[?&]e=(\d+)')


def norm(value):
    if value in (None, '', 'None'):
        return ''
    return str(value)


def _sort_key(value):
    text = str(value)
    return (0, int(text), '') if text.isdigit() else (1, 0, text)


def state_is_watched(state):
    try:
        return bool(state and int(state.get('watched') or 0) > 0)
    except Exception:
        return bool(state and state.get('watched'))


def state_of(watched_map, post_id, season=None, episode=None):
    return (watched_map or {}).get((norm(post_id), norm(season), norm(episode))) or {}


def summary_of(watched_map, post_id, season=None):
    try:
        return ((watched_map or {}).get(SUMMARY) or {}).get((norm(post_id), norm(season))) or None
    except Exception:
        return None


def episode_watched(watched_map, post_id, season, episode):
    """Просмотрена ли серия - одинаково для полного и сводного снимка.

    Сводный снимок (больше 20 постов) не несёт строк серий, только их счёт и
    список просмотренных номеров по сезону. Раньше в этом режиме выбор перевода
    не видел ни одной просмотренной серии и всегда брал самый длинный, а
    просмотренных брал общим числом - и тот же сериал в маленьком списке и в
    большом считался по-разному.
    """
    summary = summary_of(watched_map, post_id, season)
    if summary is not None and 'keys' in summary:
        return norm(episode) in summary['keys']
    return state_is_watched(state_of(watched_map, post_id, season, episode))


def playlist_of(details):
    links = (details or {}).get('player_links') or {}
    if not isinstance(links, dict):
        return {}
    return links.get('playlist') or {}


def _episode_keys(episodes):
    if isinstance(episodes, list):
        return set(str(i) for i in range(len(episodes)))
    if isinstance(episodes, dict):
        return set(str(k) for k in episodes.keys())
    return set()


def counting_keys(details, watched_map, season_filter=None):
    """Серии, которые СЧИТАЮТСЯ, по сезонам - из ОДНОГО перевода, не из объединения.

    Объединение номеров всех переводов годится для списка серий (открыть можно
    то, что есть хоть в одном переводе), но не для счёта: перевод с лишней
    записью выдумывает серию, которую никто не смотрел. Замер в «Избранном» на
    .20: «Тед Лассо» всего=39 просмотрено=38, «В Филадельфии» 180/179 - оба на
    одну меньше. Поэтому сезон считается по переводу, который смотрели (больше
    всего просмотренных), а если в сезоне не смотрели ничего - по самому
    длинному.
    """
    post_id = (details or {}).get('id')
    playlist = playlist_of(details)
    season_filter = None if season_filter in (None, '') else str(season_filter)
    result = []
    if isinstance(playlist, dict):
        for season_key in sorted(playlist, key=_sort_key):
            season_key = str(season_key)
            if season_filter is not None and season_key != season_filter:
                continue
            per_translation = {}
            for name, episodes in (playlist.get(season_key) or {}).items():
                keys = _episode_keys(episodes)
                if keys:
                    per_translation[name] = keys
            if not per_translation:
                continue
            best_keys, best_watched = None, -1
            for name in sorted(per_translation):
                keys = per_translation[name]
                watched_here = sum(1 for key in keys
                                   if episode_watched(watched_map, post_id, season_key, key))
                if watched_here > best_watched:
                    best_keys, best_watched = keys, watched_here
            if best_watched <= 0:
                best_keys = max(per_translation.values(), key=len)
            result.extend((season_key, key) for key in sorted(best_keys, key=_sort_key))
    elif isinstance(playlist, list):
        # Старая форма без сезонов: список {перевод: серии}.
        keys = set()
        for translations in playlist:
            for _name, episodes in (translations or {}).items():
                keys |= _episode_keys(episodes)
        base = season_filter if season_filter is not None else '-1'
        result.extend((base, key) for key in sorted(keys, key=_sort_key))
    return result


def stats(details, watched_map, season=None):
    """{'total', 'watched', 'unwatched'} сериала или одного его сезона."""
    post_id = (details or {}).get('id')
    total = watched = 0
    for season_key, episode_key in counting_keys(details, watched_map, season):
        total += 1
        if episode_watched(watched_map, post_id, season_key, episode_key):
            watched += 1
    return {'total': total, 'watched': watched, 'unwatched': max(0, total - watched)}


def count_properties(stats):
    """Свойства счёта серий для строки сериала или сезона - одни на все разделы.

    Владелец 21.10.2026: в полосе «Все» рамка маркера (кольцо процента
    просмотренных серий, Property(WatchedEpisodePercent)) у «Тед Лассо» была
    почти полной, а в «Избранном» её не было вовсе: полоса скина ставила
    процент, Filmix - нет. Кольцо должно быть везде, поэтому набор свойств
    собирает одна эта функция, а публикуют его и Filmix (navigation
    _apply_local_state), и полосы скина (через show_state['properties']).
    """
    total = int((stats or {}).get('total') or 0)
    watched = int((stats or {}).get('watched') or 0)
    unwatched = max(0, total - watched)
    properties = {
        'TotalEpisodes': '{0}'.format(total),
        'WatchedEpisodes': '{0}'.format(watched),
        'UnWatchedEpisodes': '{0}'.format(unwatched),
        'NumEpisodes': '{0}'.format(total),
    }
    if total:
        properties['WatchedEpisodePercent'] = '{0}'.format(
            min(100, int(round(100.0 * watched / total))))
    return properties


def recorded_tally(watched_map, post_id):
    """(просмотрено, строк) по записанным строкам серий или None, если строк нет.

    Нужно сериалу без плейлиста в кэше: отметке на его корне можно верить,
    только если ни одна записанная серия не стоит непросмотренной.
    """
    summary = summary_of(watched_map, post_id)
    if summary:
        rows = int(summary.get('rows') or 0)
        return (int(summary.get('watched') or 0), rows) if rows else None
    key = norm(post_id)
    watched = rows = 0
    for entry_key, state in (watched_map or {}).items():
        if not isinstance(entry_key, tuple) or len(entry_key) != 3:
            continue
        if entry_key[0] != key or not entry_key[2]:
            continue
        rows += 1
        if state_is_watched(state):
            watched += 1
    return (watched, rows) if rows else None


def show_state(details, watched_map):
    """Состояние сериала целиком: stats() плюс 'playcount', либо только playcount.

    playcount = 1, только когда серий больше нуля и непросмотренных нет. Корневая
    отметка («сериал просмотрен») решает лишь там, где серий не знаем: у
    сериала с пустым плейлистом - сама, у поста без плеера в кэше - если
    записанные серии ей не противоречат. Отметка на корне стоит почти у всех
    сериалов владельца (наследие старой схемы пометки), и «В Филадельфии всегда
    солнечно» с одной непросмотренной серией получал по ней галочку.

    'counted' - считали ли по сериям; без плеера в кэше 'total' нет вовсе.
    """
    post_id = (details or {}).get('id')
    root = state_of(watched_map, post_id)
    if (details or {}).get('player_links') is not None:
        result = stats(details, watched_map)
        playcount = 1 if (result['total'] and not result['unwatched']) else 0
        if not result['total'] and state_is_watched(root):
            playcount = 1
        result['playcount'] = playcount
        result['counted'] = True
        result['properties'] = count_properties(result)
        return result
    playcount = int(root.get('playcount') or 0)
    if playcount:
        tally = recorded_tally(watched_map, post_id)
        if tally and tally[0] < tally[1]:
            playcount = 0
    return {'playcount': playcount, 'counted': False}


def kodi_key(path):
    """(post_id, сезон, серия) пути Filmix в базе Kodi - ключ watched_state."""
    text = str(path or '')
    if 'plugin.video.filmix' not in text:
        return None
    post = _POST_RE.search(text)
    if not post:
        return None
    season = _SEASON_RE.search(text)
    episode = _EPISODE_RE.search(text)
    return (post.group(1),
            season.group(1) if season else '',
            episode.group(1) if episode else '')


def kodi_marks(kodi_rows):
    """Что знает Kodi: ({ключ: playcount} просмотренного, {ключи снятых отметок}).

    kodi_rows - {путь: (playcount, ...)} из базы Kodi. Снятая отметка - путь,
    который в Kodi есть с playcount 0; молчание Kodi о пути отметкой не
    считается (kodi_link.mirror: «только добавлять»). Одно определение и для
    сверки службы, и для счёта на лету (apply_kodi).
    """
    wanted, cleared = {}, set()
    for path, state in (kodi_rows or {}).items():
        key = kodi_key(path)
        if not key:
            continue
        try:
            playcount = int((state[0] if isinstance(state, (tuple, list)) else state) or 0)
        except Exception:
            playcount = 0
        if playcount > 0:
            wanted[key] = max(wanted.get(key, 0), playcount)
        else:
            cleared.add(key)
    return wanted, cleared


def apply_kodi(watched_map, kodi_rows, post_ids=None):
    """Наложить отметки Kodi на снимок watched_state - то же, что сделала бы сверка.

    29.10.2026 на .20: «Полураспад» в «Избранном» остался с одной
    непросмотренной серией сразу после того, как владелец её досмотрел. Kodi
    записал серию в свою базу в 19:07:56 и в 19:08:01 перечитал «Избранное»,
    а служба перенесла отметку в watched_state только в 19:08:06 - список
    посчитан по кэшу без последней серии, и больше его никто не перечитал.
    Здесь снимок дополняется тем, что Kodi уже знает, в момент счёта. Правило
    то же, что у kodi_link.mirror: просмотрено в Kodi - отметить, снято в
    Kodi (путь с playcount 0) и нигде не просмотрено - снять.

    Работает и с полным, и со сводным снимком. Меняет watched_map на месте.
    """
    if not isinstance(watched_map, dict) or not kodi_rows:
        return watched_map
    wanted, cleared = kodi_marks(kodi_rows)
    ids = set(norm(p) for p in post_ids or () if norm(p)) or None
    summary = watched_map.get(SUMMARY)
    for key in set(wanted) | cleared:
        post_id, season, episode = key
        if ids is not None and post_id not in ids:
            continue
        should = key in wanted
        if isinstance(summary, dict) and episode:
            entry = summary.get((post_id, season))
            keys = entry.get('keys') if isinstance(entry, dict) else None
            if should and (keys is None or episode not in keys):
                if not isinstance(entry, dict):
                    entry = summary[(post_id, season)] = {'watched': 0, 'rows': 0, 'keys': set()}
                entry.setdefault('keys', set()).add(episode)
                entry['watched'] = int(entry.get('watched') or 0) + 1
                entry['rows'] = max(int(entry.get('rows') or 0), entry['watched'])
                show = summary.setdefault((post_id, ''), {'watched': 0, 'rows': 0})
                show['watched'] = int(show.get('watched') or 0) + 1
                show['rows'] = max(int(show.get('rows') or 0), show['watched'])
            elif not should and keys is not None and episode in keys:
                keys.discard(episode)
                entry['watched'] = max(0, int(entry.get('watched') or 0) - 1)
                show = summary.get((post_id, ''))
                if isinstance(show, dict):
                    show['watched'] = max(0, int(show.get('watched') or 0) - 1)
            continue
        state = watched_map.get(key)
        watched = state_is_watched(state)
        if should and not watched:
            watched_map[key] = {'post_id': post_id, 'season': season, 'episode': episode,
                                'watched': 1, 'playcount': wanted[key]}
        elif not should and watched:
            state = dict(state)
            state.update({'watched': 0, 'playcount': 0})
            watched_map[key] = state
    return watched_map


def show_states(cache, post_ids, kodi_rows=None):
    """{post_id: show_state} для списка постов - вход скина.

    cache - FilmixCache. Два запроса на весь список: описания и снимок.
    kodi_rows - {путь: (playcount, ...)} из базы Kodi: скин читает кэш только
    на чтение и сверить его со службой не может, поэтому отметки Kodi
    накладываются на снимок здесь (apply_kodi).
    """
    ids = [norm(p) for p in post_ids if norm(p)]
    if not ids:
        return {}
    details = cache.get_post_details_many(ids)
    watched_map = cache.get_watched_snapshot_many(ids)
    if kodi_rows:
        apply_kodi(watched_map, kodi_rows, ids)
    result = {}
    for post_id in ids:
        item = details.get(post_id)
        if not isinstance(item, dict):
            continue
        item = dict(item)
        item.setdefault('id', post_id)
        result[post_id] = show_state(item, watched_map)
    return result
