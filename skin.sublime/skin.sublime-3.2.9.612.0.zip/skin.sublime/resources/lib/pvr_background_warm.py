# -*- coding: utf-8 -*-
"""Фоны каналов ТВ - заранее, а не в момент перехода на канал.

Фон канала (размытый логотип 1060x700) и цвет подложки строились, когда фокус
приходил на канал: замер на .30 15.11.2026 - 3,6-3,9 с после перехода, и только
у канала, чей фон уже лежал в кэше, 0,36 с (владелец: «фоны pvr вместе с washed
color переключаются с задержкой»). Здесь фоны и цвет всех каналов готовятся в
фоне после загрузки списка каналов и обновляются раз в 6 ч; во время просмотра и
пока владелец листает, работа ждёт.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import threading
import time

import xbmc

REFRESH_SECONDS = 6 * 3600
PAUSE_SECONDS = 0.15          # между каналами: не мешать интерфейсу на слабом железе
USER_IDLE_SECONDS = 3


def _log(message):
    xbmc.log('[sublime pvr warm] %s' % message, xbmc.LOGINFO)


def _channel_icons(group='alltv'):
    """Логотипы каналов группы: 'alltv' - ТВ, 'allradio' - радио (fill_caches)."""
    raw = xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'PVR.GetChannels',
        'params': {'channelgroupid': group, 'properties': ['thumbnail', 'channel']}}))
    try:
        channels = json.loads(raw).get('result', {}).get('channels') or []
    except ValueError:
        return []
    icons = []
    for ch in channels:
        icon = str(ch.get('thumbnail') or '').strip()
        if icon and icon not in icons:
            icons.append(icon)
            _NAMES[icon] = str(ch.get('channel') or ch.get('label') or '')
    return icons


_NAMES = {}
BY_NAME = 'special://profile/addon_data/skin.sublime/pvr_bg/'


def publish_by_name(icon):
    """Готовая подложка канала ещё и под его именем: разметка берёт её по ListItem.ChannelName
    в кадре смены фокуса, без такта службы (фон канала появлялся позже фона YouTube)."""
    import os
    import shutil
    import xbmcvfs
    from resources.lib.sublime_helper.poster_background import prepared_path
    name = _NAMES.get(icon)
    ready = prepared_path('pvr', icon)
    if not name or not ready:
        return
    target = xbmcvfs.translatePath(BY_NAME + name + '.png')
    source = xbmcvfs.translatePath(ready)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    if not (os.path.isfile(target) and os.path.getsize(target) == os.path.getsize(source)):
        # жёсткая ссылка на готовую подложку: тот же файл под именем канала, место на флеше
        # не удваивается (аудит 21.11.2026); где ссылки нельзя - копия
        try:
            if os.path.exists(target):
                os.remove(target)
            os.link(source, target)
        except OSError:
            shutil.copyfile(source, target)
    # цвет подложки канала - тоже файлом под его именем: разметка красит им фон в том же
    # кадре, что и картинку (цвет приходил от службы позже фона, 21.11.2026)
    from resources.lib.sublime_helper.image_wash import prepare_wash_color_now
    color = (prepare_wash_color_now(icon) or '').strip()
    if len(color) != 8:
        return
    wash = xbmcvfs.translatePath(BY_NAME + name + '.wash.png')
    stamp = wash + '.argb'
    try:
        if os.path.isfile(wash) and open(stamp).read() == color:
            return
    except Exception:
        pass
    from PIL import Image
    a, r, g, b = (int(color[i:i + 2], 16) for i in (0, 2, 4, 6))
    Image.new('RGBA', (4, 4), (r, g, b, a)).save(wash)
    with open(stamp, 'w') as handle:
        handle.write(color)


def _sweep_removed():
    """Файлы pvr_bg каналов, которых больше нет в списке, - убрать (их никто не чистил)."""
    import xbmcvfs
    folder = xbmcvfs.translatePath(BY_NAME)
    names = set(_NAMES.values())
    if not names or not os.path.isdir(folder):
        return
    entries = os.listdir(folder)
    pictures = sum(1 for e in entries if e.endswith('.png') and not e.endswith('.wash.png'))
    if len(names) < pictures // 2:
        return                          # список каналов неполный (ТВ ещё грузится) - не трогать
    gone = 0
    for entry in entries:
        base = entry
        for suffix in ('.wash.png.argb', '.wash.png', '.png'):
            if base.endswith(suffix):
                base = base[:-len(suffix)]
                break
        if base not in names:
            try:
                os.remove(os.path.join(folder, entry))
                gone += 1
            except OSError:
                pass
    if gone:
        _log('убраны файлы удалённых каналов: %d' % gone)


def _busy():
    return (xbmc.getCondVisibility('Player.HasMedia')
            or xbmc.getGlobalIdleTime() < USER_IDLE_SECONDS)


def _run(monitor):
    from resources.lib.sublime_helper.poster_background import prepare_background_now, prepared_path
    last = 0.0
    while not monitor.abortRequested():
        if not xbmc.getCondVisibility('Pvr.HasTVChannels'):
            if monitor.waitForAbort(20):
                return
            continue
        if time.time() - last < REFRESH_SECONDS:
            if monitor.waitForAbort(60):
                return
            continue
        try:
            from resources.lib import fill_caches
            busy_fill = fill_caches.ACTIVE[0] or os.path.exists(fill_caches.REQUEST)
        except Exception:
            busy_fill = False
        if busy_fill:
            # каналы сейчас строит заполнение кэшей (установщик): второй проход по тем же
            # каналам в то же время строил бы те же файлы дважды (аудит 21.11.2026)
            if monitor.waitForAbort(10):
                return
            continue
        icons = _channel_icons()
        quick_done = not last
        if not last:
            # первый проход после старта - без пауз: у готовых фонов только файлы под именем
            # канала и цвет подложки (из кэша цветов), это миллисекунды на канал. Иначе цвет
            # получали лишь каналы, до которых медленный проход успел дойти (113 из 897, .20)
            quick = 0
            for icon in icons:
                if monitor.abortRequested():
                    return
                try:
                    if prepared_path('pvr', icon):
                        publish_by_name(icon)
                        quick += 1
                except Exception as exc:
                    _log('%s: %s' % (icon[-60:], exc))
            _log('быстрый проход: каналов с готовым фоном %d' % quick)
            _sweep_removed()
        made = 0
        started = time.time()
        for icon in icons:
            while _busy():
                if monitor.waitForAbort(2):
                    return
            try:
                if not prepared_path('pvr', icon):
                    if prepare_background_now('pvr', icon):
                        made += 1
                    publish_by_name(icon)
                elif not quick_done:
                    publish_by_name(icon)       # готовые после старта уже опубликовал быстрый проход
            except Exception as exc:
                _log('%s: %s' % (icon[-60:], exc))
            if monitor.waitForAbort(PAUSE_SECONDS):
                return
        last = time.time()
        _log('каналов %d, новых фонов %d за %.0f с' % (len(icons), made, last - started))


def start():
    thread = threading.Thread(target=_run, args=(xbmc.Monitor(),), name='SublimePvrBackgroundWarm')
    thread.daemon = True
    thread.start()
    return thread
