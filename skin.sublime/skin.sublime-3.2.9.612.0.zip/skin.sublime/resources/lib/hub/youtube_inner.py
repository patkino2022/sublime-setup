# -*- coding: utf-8 -*-
"""Полосы YouTube и поиск без ключа Data API.

Тот же внутренний интерфейс (innertube), через который работает сайт YouTube и
воспроизведение в дополнении: ключ пользователя не нужен, общих лимитов нет.
Воспроизведение остаётся за дополнением - путь строки ведёт в него.

Полосы (15.11.2026, по выбору владельца):
  live   - «В эфире сейчас»: прямые трансляции по числу зрителей;
  news   - «Новости»: новостные видео за сутки по просмотрам;
  charts - «Музыка: чарты»: плейлист YouTube Music «100 лучших клипов» страны.
Поиск - для общего поиска скина (search).
"""
from __future__ import absolute_import, unicode_literals

import json
import time

import xbmc

from . import mirror
from .config import log
from ..sublime_helper import tls as _tls
from ..sublime_helper.config import youtube_play_url

_tls.install()   # https при испорченном хранилище сертификатов системы (Windows)
from .youtube_trending import _published, _region

WEB = {'clientName': 'WEB', 'clientVersion': '2.20251101.00.00'}
MUSIC = {'clientName': 'WEB_REMIX', 'clientVersion': '1.20251101.01.00'}
TIMEOUT = 12.0
LIMIT = 50
TTL = {'live': 15 * 60, 'news': 30 * 60, 'charts': 6 * 3600}
# поиск: запрос и фильтр YouTube (sp) - «по просмотрам» + трансляции / за сутки
LANES = {
    'live': ({'ru': 'прямой эфир', 'en': 'live'}, 'CAMSAkAB'),
    'news': ({'ru': 'новости', 'en': 'news'}, 'CAMSBAgCEAE='),
}


def _lang():
    return 'ru' if _region() == 'RU' else 'en'


def _call(endpoint, body, client=WEB):
    import urllib.request
    host = 'music.youtube.com' if client is MUSIC else 'www.youtube.com'
    ctx = dict(client, hl=_lang(), gl=_region())
    request = urllib.request.Request(
        'https://%s/youtubei/v1/%s?prettyPrint=false' % (host, endpoint),
        data=json.dumps(dict(context={'client': ctx}, **body)).encode('utf-8'),
        headers={'Content-Type': 'application/json', 'User-Agent': 'Mozilla/5.0', 'Origin': 'https://' + host})
    with urllib.request.urlopen(request, timeout=TIMEOUT) as answer:
        return json.loads(answer.read().decode('utf-8'))


def _walk(node, key, out):
    if isinstance(node, dict):
        if key in node:
            out.append(node[key])
        for value in node.values():
            _walk(value, key, out)
    elif isinstance(node, list):
        for value in node:
            _walk(value, key, out)
    return out


def _text(value):
    value = value or {}
    if value.get('simpleText'):
        return str(value['simpleText'])
    return ''.join(str(run.get('text') or '') for run in value.get('runs') or [])


def _best_art(video_id, thumbs=()):
    """Обложка как в сетапе автора (mirror._YT_BEST): maxresdefault 1280x720, если у ролика
    есть крупная обложка (в ответе - вариант шириной от 1280), иначе sddefault 640x480."""
    widest = max([int(t.get('width') or 0) for t in thumbs or ()] or [0])
    # в ответе поиска крупнейшая - hq720 (1280x720, без полос; в списке её ширина 720):
    # она есть всегда, когда YouTube её отдал, в отличие от maxresdefault
    if widest >= 1280:
        name = 'maxresdefault'
    elif any('hq720' in str(t.get('url') or '') for t in thumbs or ()):
        name = 'hq720'
    else:
        name = 'sddefault'
    url = 'https://i.ytimg.com/vi/%s/%s.jpg' % (video_id, name)
    return {'thumb': url, 'icon': 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % video_id,
            'fanart': url, 'landscape': url}


def _seconds(text):
    """«12:37» / «1:02:03» -> секунды; иначе 0."""
    try:
        total = 0
        for part in str(text or '').strip().split(':'):
            total = total * 60 + int(part)
        return total
    except ValueError:
        return 0


def _row(video_id, title, channel='', channel_id='', plot='', thumbs=(), published='', duration=0):
    when = _published(published)
    return {
        'label': title,
        'title': title,
        'duration': int(duration or 0),
        'file': youtube_play_url(video_id),
        'filetype': 'file',
        'plot': plot,
        'dateadded': when,
        'premiered': when[:10],
        'art': _best_art(video_id, thumbs),
        'studio': channel,
        'channel_id': channel_id,
        'genre': [],
        'playcount': 0,
        'episode': -1,
        '_api': True,
    }


def _search(query, params=''):
    body = {'query': query}
    if params:
        body['params'] = params
    rows = []
    for video in _walk(_call('search', body), 'videoRenderer', [])[:LIMIT]:
        video_id = str(video.get('videoId') or '')
        title = _text(video.get('title')).strip()
        if not video_id or not title:
            continue
        owner = (((video.get('ownerText') or {}).get('runs') or [{}])[0])
        channel_id = str(((owner.get('navigationEndpoint') or {}).get('browseEndpoint') or {}).get('browseId') or '')
        plot = _text((video.get('detailedMetadataSnippets') or [{}])[0].get('snippetText'))
        thumbs = (video.get('thumbnail') or {}).get('thumbnails') or []
        rows.append(_row(video_id, title, str(owner.get('text') or ''), channel_id, plot, thumbs,
                         _text(video.get('publishedTimeText')), _seconds(_text(video.get('lengthText')))))
    return rows


def _charts():
    data = _call('browse', {'browseId': 'FEmusic_charts', 'formData': {'selectedValues': [_region()]}}, MUSIC)
    lists = []
    for item in _walk(data, 'musicTwoRowItemRenderer', []):
        browse = ((item.get('navigationEndpoint') or {}).get('browseEndpoint') or {}).get('browseId') or ''
        if browse.startswith('VL'):
            lists.append((_text(item.get('title')), browse))
    if not lists:
        return []
    # «100 лучших клипов» страны; нет - первый плейлист чартов
    browse = next((b for t, b in lists if '100' in t), lists[0][1])
    rows = []
    for item in _walk(_call('browse', {'browseId': browse}, MUSIC), 'musicResponsiveListItemRenderer', [])[:LIMIT]:
        ids = _walk(item, 'videoId', [])
        cols = [_text((c.get('musicResponsiveListItemFlexColumnRenderer') or {}).get('text'))
                for c in item.get('flexColumns') or []]
        if not ids or not cols or not cols[0]:
            continue
        rows.append(_row(str(ids[0]), cols[0], cols[1] if len(cols) > 1 else ''))
    return rows


def fetch(kind):
    """Строки полосы прямым запросом. Пустой список - значит не вышло."""
    try:
        if kind == 'charts':
            return _charts()
        words, params = LANES[kind]
        return _search(words[_lang()], params)
    except Exception as exc:
        log('YouTube без ключа (%s): запрос не удался: %s' % (kind, exc), xbmc.LOGWARNING)
        return []


def _src(kind):
    return 'sublime://youtube_%s' % kind


def rows(kind):
    """Строки полосы: снимок, если свежий; иначе запрос (пустой ответ снимок не затирает)."""
    if kind not in TTL:
        return []
    kept, stamp = mirror.load(_src(kind))
    if kept and stamp and time.time() - stamp < TTL[kind]:
        return kept
    fresh = fetch(kind)
    if fresh:
        from .youtube_tvfeed import finish_rows
        fresh = finish_rows(fresh)
        mirror.store(_src(kind), fresh)
        log('YouTube без ключа (%s): %d строк' % (kind, len(fresh)))
        return fresh
    return kept or []


def search(query):
    """Поиск YouTube для общего поиска скина (по релевантности)."""
    query = (query or '').strip()
    if not query:
        return []
    try:
        return _search(query)
    except Exception as exc:
        log('YouTube без ключа: поиск не удался: %s' % exc, xbmc.LOGWARNING)
        return []
