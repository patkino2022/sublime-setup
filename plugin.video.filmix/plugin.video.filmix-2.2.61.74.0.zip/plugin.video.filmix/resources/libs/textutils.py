# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html
#
# Shared, dependency-free text/query helpers.
# These were previously copy-pasted byte-for-byte across utilities.py,
# navigation.py and prewarm.py. Centralised here so all call sites use one
# implementation. No xbmc/Addon imports on purpose: importing this module has zero
# side effects and cannot create import cycles.
from __future__ import unicode_literals


def filmix_resume_norm(value):
    if value in [None, '']:
        return ''
    try:
        text = str(value)
    except Exception:
        return ''
    try:
        from urllib.parse import unquote
    except Exception:
        try:
            from urllib import unquote
        except Exception:
            unquote = None
    if unquote:
        try:
            text = unquote(text)
        except Exception:
            pass
    return text


def filmix_query_dict(query):
    result = {}
    if not query:
        return result
    try:
        from urllib.parse import parse_qsl
    except Exception:
        try:
            from urlparse import parse_qsl
        except Exception:
            parse_qsl = None
    if parse_qsl:
        try:
            for k, v in parse_qsl(query, keep_blank_values=True):
                result[str(k)] = str(v)
            return result
        except Exception:
            pass
    try:
        for part in query.split('&'):
            if not part:
                continue
            if '=' in part:
                k, v = part.split('=', 1)
            else:
                k, v = part, ''
            result[str(k)] = str(v)
    except Exception:
        pass
    return result


# --- Catalog filter label helpers (were identical in navigation.py and prewarm.py) ---

_FILTER_LABEL_REPLACEMENTS = {
    'ё': 'е',
    '-': ' ',
    '_': ' ',
    '/': ' ',
    '\\': ' ',
    ',': ' ',
    '.': ' ',
    ':': ' ',
    ';': ' ',
    '(': ' ',
    ')': ' ',
    '[': ' ',
    ']': ' ',
    '  ': ' ',
}

_BLOCKED_FILTER_LABELS = ('на украинском', 'украинский', 'украинские', 'українською', 'ukrainian')


def normalize_filter_label(label):
    if label is None:
        return ''
    text = str(label).strip().lower()
    for src, dst in _FILTER_LABEL_REPLACEMENTS.items():
        text = text.replace(src, dst)
    return ' '.join(text.split())


def is_blocked_custom_filter_label(label):
    text = normalize_filter_label(label)
    return any(b in text for b in _BLOCKED_FILTER_LABELS)


def find_filter_ids(values, aliases):
    ids = []
    norm_aliases = [normalize_filter_label(alias) for alias in aliases or [] if alias]
    for item in values or []:
        item_id = item.get('id')
        label = normalize_filter_label(item.get('val', ''))
        if not item_id or not label or is_blocked_custom_filter_label(label):
            continue
        for alias in norm_aliases:
            if alias == label or alias in label or label in alias:
                if item_id not in ids:
                    ids.append(item_id)
                break
    return ids
