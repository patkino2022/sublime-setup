# -*- coding: utf-8 -*-
"""Где в серии начинаются титры - по размеру кадров, без декодирования.

В заголовке mp4 (moov) записан размер каждого кадра. Титры - текст на чёрном
- сжимаются в десятки раз сильнее любой сцены: в «Король Талсы» 3x2 поток
падает с 3,5 до 0,07 Мбит/с ровно за 75 с до конца. Заголовок весит 1-3 МБ и
читается двумя запросами Range, так что серия разбирается за 1-3 с в
стороне от воспроизведения.

Прогон 17.10.2026 по 22 сериям 11 сериалов из истории .20: титры найдены у
шести сериалов, и у соседних серий одного сериала одинаково («Похищение» 89 и
90 с, «Холод» 163 и 206 с, «Тед Лассо» 37 и 38 с). Где титры идут поверх
картинки («Вавилон-Берлин», «Перевал Дятлова»), провала нет - тогда ответ
None, и время берётся из других источников.
"""
from __future__ import absolute_import, unicode_literals

import struct
from urllib.request import Request, urlopen
from urllib.parse import unquote

# Порог - доля медианы потока этой серии. 0,15-0,30 на прогоне дают те же
# ответы; 0,25 ловит и «Похищение», где провал не такой глубокий.
RATIO = 0.25
# Титры короче 20 с от затемнения в конце сцены не отличить.
MIN_RUN = 20
# Дальше 15 минут от конца титров не бывает - там начинается сама серия.
HORIZON = 900
# После титров бывает заставка студии (логотип на 5-15 с) - её пропускаем.
TAIL_ALLOW = 12
_MAX_MOOV = 16 * 1024 * 1024


def _split_kodi_url(url):
    """Ссылка Kodi вида url|User-Agent=...&Referer=... - адрес и заголовки."""
    headers = {'User-Agent': 'Mozilla/5.0'}
    if '|' in url:
        url, extra = url.split('|', 1)
        for part in extra.split('&'):
            if '=' in part:
                name, value = part.split('=', 1)
                headers[unquote(name)] = unquote(value)
    return url, headers


def _get(url, headers, first, last, timeout=15):
    request = Request(url, headers=dict(headers, Range='bytes=%d-%d' % (first, last)))
    with urlopen(request, timeout=timeout) as answer:
        return answer.read(), answer.headers.get('Content-Range') or ''


def _boxes(buf, off, end):
    while off + 8 <= end:
        size, kind = struct.unpack('>I4s', buf[off:off + 8])
        if size == 1:
            size = struct.unpack('>Q', buf[off + 8:off + 16])[0]
        if size < 8:
            return
        yield kind, off, size
        off += size


def _find(buf, off, end, path):
    for kind, at, size in _boxes(buf, off, end):
        if kind == path[0]:
            if len(path) == 1:
                return at, size
            found = _find(buf, at + 8, at + size, path[1:])
            if found:
                return found
    return None


def _read_moov(url, headers):
    pos = 0
    total = None
    while total is None or pos < total:
        head, content_range = _get(url, headers, pos, pos + 15)
        if total is None:
            try:
                total = int(content_range.rsplit('/', 1)[1])
            except Exception:
                return None
        if len(head) < 8:
            return None
        size, kind = struct.unpack('>I4s', head[:8])
        if size == 1:
            size = struct.unpack('>Q', head[8:16])[0]
        if size < 8:
            return None
        if kind == b'moov':
            if size > _MAX_MOOV:
                return None
            return _get(url, headers, pos, pos + size - 1, timeout=30)[0]
        pos += size
    return None


def bytes_per_second(url):
    """Сколько байт видео приходится на каждую секунду серии."""
    url, headers = _split_kodi_url(url)
    moov = _read_moov(url, headers)
    if not moov:
        return None
    for kind, at, size in _boxes(moov, 8, len(moov)):
        if kind != b'trak':
            continue
        hdlr = _find(moov, at + 8, at + size, [b'mdia', b'hdlr'])
        if not hdlr or moov[hdlr[0] + 16:hdlr[0] + 20] != b'vide':
            continue
        mdhd = _find(moov, at + 8, at + size, [b'mdia', b'mdhd'])
        stts = _find(moov, at + 8, at + size, [b'mdia', b'minf', b'stbl', b'stts'])
        stsz = _find(moov, at + 8, at + size, [b'mdia', b'minf', b'stbl', b'stsz'])
        if not (mdhd and stts and stsz):
            return None
        mo = mdhd[0]
        if moov[mo + 8] == 0:
            timescale = struct.unpack('>I', moov[mo + 20:mo + 24])[0]
        else:
            timescale = struct.unpack('>I', moov[mo + 28:mo + 32])[0]
        so = stts[0]
        entries = struct.unpack('>I', moov[so + 12:so + 16])[0]
        zo = stsz[0]
        fixed, count = struct.unpack('>II', moov[zo + 12:zo + 20])
        if fixed:
            sizes = [fixed] * count
        else:
            sizes = struct.unpack('>%dI' % count, moov[zo + 20:zo + 20 + 4 * count])
        if not timescale:
            return None
        per = []
        clock = 0
        index = 0
        for entry in range(entries):
            run, delta = struct.unpack('>II', moov[so + 16 + 8 * entry:so + 24 + 8 * entry])
            for _ in range(run):
                if index >= count:
                    break
                second = clock // timescale
                while len(per) <= second:
                    per.append(0)
                per[second] += sizes[index]
                index += 1
                clock += delta
        return per
    return None


def credits_remaining(per):
    """За сколько секунд до конца начинаются титры, или None."""
    if not per:
        return None
    n = len(per)
    if n < 600:
        return None
    median = sorted(per)[n // 2]
    if median <= 0:
        return None
    limit = median * RATIO
    smooth = []
    for i in range(n):
        window = per[max(0, i - 2):i + 3]
        smooth.append(float(sum(window)) / len(window))
    # Ищем низкий отрезок, который кончается в последних TAIL_ALLOW секундах:
    # после титров бывает заставка студии, а последняя секунда бывает пустой -
    # в «Король Талсы» 3x2 обе вещи сразу. Берём самое раннее начало.
    best = None
    for end in range(n - 1, max(0, n - 1 - TAIL_ALLOW), -1):
        if smooth[end] >= limit:
            continue
        start = end
        gap = 0
        t = end
        while t > n - HORIZON and t > 0:
            if smooth[t] < limit:
                start = t
                gap = 0
            else:
                gap += 1
                if gap > 3:
                    break
            t -= 1
        if end - start + 1 >= MIN_RUN and (best is None or start < best):
            best = start
    if best is None:
        return None
    start = best
    return n - start


def find_credits(url):
    if not url or not url.lower().split('|', 1)[0].split('?', 1)[0].endswith('.mp4'):
        return None
    return credits_remaining(bytes_per_second(url))
