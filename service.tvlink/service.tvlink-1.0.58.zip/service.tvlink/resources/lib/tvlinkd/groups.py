"""One set of channel groups whatever the playlist calls them.

Playlists name groups differently: some use English categories ("News",
"Entertainment"), some Russian ones ("Информационные", "Кино и сериалы"), some
with Latin look-alike letters ("Россия региoнальные"). Everything is mapped onto the
standard list below; unknown names go to "Другие".
"""
import re

OTHER = "Другие"   # only without the naming standard (normalize.py never gives it)

STANDARD = ["Эфирные", "Новости", "Международные новости", "Кино и сериалы", "Спорт", "Детские",
            "Музыка", "Познавательные", "Развлекательные", "Региональные", "Религиозные", "Другие"]

# названия групп при английском языке установки (флажок standard_groups содержит "en")
ENGLISH = {"Эфирные": "Broadcast", "Новости": "News", "Международные новости": "World news",
           "Кино и сериалы": "Movies & Series", "Спорт": "Sports", "Детские": "Kids", "Музыка": "Music",
           "Познавательные": "Documentary", "Развлекательные": "Entertainment", "Региональные": "Regional",
           "Религиозные": "Religious", "Другие": "Other"}


# логотип группы (resources/group_logos/<имя>.png, tools/make_group_logos.py) - для канала,
# у которого своего логотипа нет нигде (владелец 15.11.2026: вместо пустого места)
LOGOS = {"Эфирные": "broadcast", "Новости": "news", "Международные новости": "world_news",
         "Кино и сериалы": "movies", "Спорт": "sports", "Детские": "kids", "Музыка": "music",
         "Познавательные": "documentary", "Развлекательные": "entertainment", "Региональные": "regional",
         "Религиозные": "religious", "Другие": "other"}
LOGO_PREFIX = "GRP_"


def logo_id(name):
    """Id логотипа группы для плейлиста ("GRP_NEWS"); группа по-английски (установка на
    английском) и своя группа плейлиста не из списка - тоже: у второй логотип «Другие»."""
    name = {v: k for k, v in ENGLISH.items()}.get(name, name)
    return LOGO_PREFIX + LOGOS.get(name, LOGOS["Другие"]).upper()


def label(name, lang):
    return ENGLISH.get(name, name) if lang == "en" else name


_LATIN = str.maketrans("aceopxyAСEHKMOPTXB", "асеорхуАСЕНКМОРТХВ")

_MAP = [
    ("Международные новости", r"междунар|international|world news|foreign"),
    ("Новости", r"новост|информац|news|business|бизнес|weather|погод"),
    ("Кино и сериалы", r"кино|фильм|сериал|movie|series|classic|cinema"),
    ("Спорт", r"спорт|sport|outdoor"),
    ("Детские", r"дет|мульт|kids|animation|family|семейн"),
    ("Музыка", r"муз|music"),
    ("Познавательные", r"познават|документ|науч|образоват|путешеств|documentary|education|science|"
                       r"culture|культур|travel|auto|авто|cooking|кулинар|history|истор|nature|природ"),
    ("Развлекательные", r"развлек|юмор|entertainment|comedy|lifestyle|relax|shop|магазин|стиль"),
    ("Региональные", r"регион|local|city|город"),
    ("Религиозные", r"религ|religious|faith|правосл"),
    ("Эфирные", r"эфирн|федерал|общероссийск|общественн|general|legislative|main|основн"),
]


def normalize(name):
    """Standard group for a playlist's group name ('' -> 'Другие')."""
    text = (name or "").split(";")[0].strip()
    if not text:
        return "Другие"
    # и как написано (английские категории), и с латинскими двойниками, заменёнными на кириллицу
    variants = (text.lower(), text.translate(_LATIN).lower())
    for target, pattern in _MAP:
        if any(re.search(pattern, v) for v in variants):
            return target
    return "Другие"
