"""Guide: download the XMLTV sources and keep only our channels and window.

The sources weigh 40-66 MB gzipped each (4300 channels, 8+ days); pvr.tvlink
re-reads the whole file on every load, so the output holds only the playlist's
channels, the days Kodi shows, and ids equal to tvg-id.

Matching: a source channel belongs to ours when one of its display-names gives
the same id (ids.chid) as the channel or one of its aliases. "Src@epgid" in
channels.json forces it. Sources are tried by priority; the first that has the
channel wins.
"""
import calendar
import gzip
import os
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from email.utils import formatdate, parsedate_to_datetime
from xml.sax.saxutils import escape, quoteattr

import re

from . import ids, normalize
from .store import mtime, read_json, write_json

_SHIFT = re.compile(r"\(?\s*([+-])\s*(\d{1,2})\s*\)?\s*$")


def _shift_of(title):
    """(name without the time shift, shift in seconds): "Россия 1 (+4)" -> ("Россия 1", 14400)."""
    m = _SHIFT.search(title or "")
    if not m:
        return title or "", 0
    hours = int(m.group(2)) * (1 if m.group(1) == "+" else -1)
    return title[:m.start()].strip(), hours * 3600


_QUAL = re.compile(r"\(([^)]*)\)|\[[^\]]*\]|(?<![a-z0-9а-я])(hd|fhd|uhd|4k|hdr|sd|orig|old|\d{3,4}[pi])(?![a-z0-9а-я])", re.I)


def _loose(title):
    """Loose name for the guide: no time shift, quality, brackets or punctuation, Latin
    letters - "Россия 1 HD", "Россия-1" and "Россия 1 (+4)" meet on one key."""
    from .logos import _TRANSLIT
    low = _QUAL.sub(" ", _shift_of(title)[0].casefold())
    low = "".join(_TRANSLIT.get(ch, ch) for ch in low)
    return re.sub(r"[^a-z0-9]", "", low)


def _keys(title):
    """Second-pass keys of a title: the loose name and the naming standard's key."""
    out = []
    k = _loose(title)
    if len(k) >= 3:
        out.append(k)
    k = normalize.key(title)
    if len(k) >= 3:
        out.append("n:" + k)
    return out


# Пометка чужой страны или пакета в названии канала источника: «N-TV HD DE», «NTV HD TR»,
# «[magenta] n-tv». Такой канал не берётся нестрогим сопоставлением целиком: 15.11.2026
# немецкий n-tv отдавал программу НТВ, потому что «[magenta] n-tv» и «НТВ» сводятся к «ntv».
_COUNTRY = re.compile(r"(?:^|[\s(\[])(DE|AT|CH|TR|UA|PL|BY|KZ|AM|GE|AZ|UZ|IL|US|UK|GB|FR|IT|ES|RS|HR|BA|SI|"
                      r"ME|MK|BG|RO|HU|CZ|SK|LT|LV|EE|FI|SE|NO|DK|NL|BE|PT|GR|IN|AR|BR|MX)(?:$|[\s)\]])")
_PACKAGE = re.compile(r"^\s*\[[^\]]+\]")


_CYRILLIC = re.compile(r"[а-яё]", re.I)


def _foreign(names):
    """Помечен чужой страной или пакетом и ни одного названия кириллицей: «Охота и рыбалка»
    с «OKHOTA I RYBALKA LV» остаётся своим, «TNT»/«TNT HD US» и «[magenta] n-tv» - чужие."""
    tagged = any(_COUNTRY.search(n or "") or _PACKAGE.search(n or "") for n in names)
    return tagged and not any(_CYRILLIC.search(n or "") for n in names)


def _fmt(ts):
    return time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(ts))


def download(src, path, cfg, log):
    req = urllib.request.Request(src["url"], headers={"User-Agent": cfg["user_agent"]})
    if os.path.exists(path):
        req.add_header("If-Modified-Since", formatdate(mtime(path), usegmt=True))
    tmp = path + ".part"
    try:
        with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
            head = r.read(2)
            gz = None if head == b"\x1f\x8b" else gzip.GzipFile(fileobj=f, mode="wb")
            sink = gz or f
            sink.write(head)
            while True:
                chunk = r.read(256 * 1024)
                if not chunk:
                    break
                sink.write(chunk)
            if gz:
                gz.close()
            lm = r.headers.get("Last-Modified")
        os.replace(tmp, path)
        if lm:
            try:
                t = parsedate_to_datetime(lm).timestamp()
                os.utime(path, (t, t))
            except (TypeError, ValueError):
                pass
        log("epg %s: downloaded %d KB" % (src["name"], os.path.getsize(path) // 1024))
        return True
    except urllib.error.HTTPError as e:
        if e.code == 304:
            log("epg %s: not modified" % src["name"])
            return False
        log("epg %s: HTTP %s" % (src["name"], e.code))
    except (OSError, ValueError) as e:
        log("epg %s: %s" % (src["name"], e))
    try:
        os.unlink(tmp)
    except OSError:
        pass
    return False


def _ts(s):
    s = s.strip()
    try:
        t = calendar.timegm(time.strptime(s[:14], "%Y%m%d%H%M%S"))
    except ValueError:
        return None
    off = s[14:].strip()
    if len(off) == 5 and off[0] in "+-" and off[1:].isdigit():
        sec = int(off[1:3]) * 3600 + int(off[3:5]) * 60
        t -= sec if off[0] == "+" else -sec
    return t


def _coverage(path):
    """{id канала источника: [конец самой поздней годной передачи, число передач]} - у чего
    источник ещё даёт программу. Передача длиннее 18 часов или с концом не позже начала -
    ошибка источника."""
    out = {}
    now = time.time()
    try:
        with gzip.open(path, "rb") as f:
            it = ET.iterparse(f, events=("start", "end"))
            _, root = next(it)
            for ev, el in it:
                if ev != "end" or el.tag != "programme":
                    continue
                st, sp = _ts(el.get("start", "")), _ts(el.get("stop", ""))
                if st is not None and sp is not None and st < sp <= st + 18 * 3600:
                    cid = el.get("channel")
                    item = out.setdefault(cid, [0, 0])
                    item[0] = max(item[0], sp)
                    if sp > now:
                        item[1] += 1          # считаем только то, что ещё впереди
                root.clear()
    except (OSError, ET.ParseError, EOFError):
        pass
    return out


def _source_channels(path):
    """{source channel id: [display names]} - reads only the head of the file."""
    out = {}
    with gzip.open(path, "rb") as f:
        for ev, el in ET.iterparse(f, events=("end",)):
            if el.tag == "channel":
                icon = el.find("icon")
                out[el.get("id")] = ([d.text or "" for d in el.findall("display-name")],
                                     icon.get("src", "") if icon is not None else "")
                el.clear()
            elif el.tag == "programme":
                break
    return out


def build(cfg, catalog, paths, sources, log, nice=True):
    """Each channel takes its guide from the first source that has it and the
    later sources fill what the earlier ones lack: on 19.10.2026 Glanz (priority
    1) ended that same evening while Edem ran six days on, and a one-source
    choice left the Glanz channels empty until the next night."""
    if nice:
        try:
            os.nice(10)          # сборка читает сотни мегабайт: не мешать просмотру
        except (OSError, AttributeError):
            pass
    past = time.time() - cfg["epg_past_days"] * 86400
    future = time.time() + cfg["epg_future_days"] * 86400
    sfx = cfg["strip_suffixes"]

    key = {}      # channel id and aliases -> our channel ids
    tvg = {}      # playlist tvg-id -> our channel ids (the guide's channel id itself)
    for c in catalog["channels"]:
        # match_ids (catalog): also the ids of the normalized and the raw titles
        for k in c.get("match_ids") or [c["id"]] + c["aliases"]:
            key.setdefault(k, []).append(c["id"])
        for t in c.get("tvg_ids") or ():
            tvg.setdefault(t.casefold(), []).append(c["id"])
    usable = [s for s in sources if os.path.exists(paths.epg_source(s["name"]))]
    # Что источник ещё даёт: канал, привязанный к ленте, у которой программа кончилась (Edem
    # «RTVi» - 15.11, «AMC» - одна передача), и канал, нашедшийся по имени только в такой ленте,
    # оставались вовсе без программы, хотя у другого источника она есть (18.11.2026, .20/.30:
    # 9 каналов - RTVi, AMC, CNN, MyZen, Univer, BOX Music, VF Сериал)
    horizon = time.time() + 6 * 3600
    cur = {s["name"]: _coverage(paths.epg_source(s["name"])) for s in usable}

    def alive(src, eid):
        stop, count = cur.get(src, {}).get(eid, (0, 0))
        return stop > horizon and count >= 8          # одна передача - не программа

    forced = {}   # (src, epgid) -> [our ids]; a forced channel reads only that source
    pinned = set()
    for c in catalog["channels"]:
        if c.get("epg") and "@" in c["epg"]:
            s, e = c["epg"].split("@", 1)
            if not alive(s, e):
                continue          # лента закрепления кончилась - канал ищет программу по имени
            forced.setdefault((s, e), []).append(c["id"])
            pinned.add(c["id"])

    plan, icons = {}, {}
    for s in usable:
        try:
            chans = _source_channels(paths.epg_source(s["name"]))
        except (OSError, ET.ParseError, EOFError) as e:
            log("epg %s: unreadable (%s)" % (s["name"], e))
            continue
        m = {}
        for eid, (names, icon) in chans.items():
            mine = set(forced.get((s["name"], eid), []))
            mine.update(cid for cid in tvg.get((eid or "").casefold(), ()) if cid not in pinned)
            for n in names:
                mine.update(cid for cid in key.get(ids.chid(n, sfx), ()) if cid not in pinned)
            if mine:
                m[eid] = sorted(mine)
                if icon.startswith("http"):
                    for cid in mine:
                        icons.setdefault(cid, icon)
        plan[s["name"]] = m

    # Второй проход: каналы без программы - по очищенному названию («Россия 1» берёт
    # программу «Россия 1 HD»), со сдвигом времени у «(+4)», «(-3)»; и по ключу стандарта
    # названий (normalize.key: «Euronews» берёт «Euronews Россия», «Belgorod 24» - «Белгород 24»)
    matched = {cid for sname, m in plan.items() for eid, cids in m.items() if alive(sname, eid) for cid in cids}
    # каналы только из встроенных плейлистов (catalog "norm": все ссылки по стандарту);
    # канал владельца, слившийся с бесплатной строкой, берёт ленту как раньше
    builtin = {c["id"] for c in catalog["channels"] if c.get("norm")}
    loose = {}
    for c in catalog["channels"]:
        if c["id"] in matched or c["id"] in pinned:
            continue
        # the standard's key only for channels of the built-in playlists (catalog "norm")
        keys = _keys(c["title"]) if c.get("norm") else [k for k in [_loose(c["title"])] if len(k) >= 3]
        for k in keys:
            loose.setdefault(k, []).append((c["id"], _shift_of(c["title"])[1]))
    shifts, taken = {}, set()
    if loose:
        for s in usable:
            try:
                chans = _source_channels(paths.epg_source(s["name"]))
            except (OSError, ET.ParseError, EOFError):
                continue
            m = plan.setdefault(s["name"], {})
            for eid, (names, _icon) in chans.items():
                if not alive(s["name"], eid):
                    continue                        # у этой ленты программы уже нет
                foreign = _foreign(names)           # чужая страна или пакет: «[magenta] n-tv» не НТВ
                for n in names:
                    if _shift_of(n)[1]:
                        continue                    # сдвинутые программы источника не берём
                    for k in _keys(n):
                        if foreign:
                            # встроенным бесплатным плейлистам чужая лента не годится;
                            # свои плейлисты владельца (немецкие каналы с OpenEPG-DE) - как раньше
                            keep = [x for x in loose.get(k, ()) if x[0] in builtin]
                            rest = [x for x in loose.get(k, ()) if x[0] not in builtin]
                            if not rest:
                                continue
                            if keep:
                                loose[k] = keep
                            else:
                                loose.pop(k, None)
                            hits = rest
                        else:
                            hits = loose.pop(k, ())
                        for cid, off in hits:
                            if cid in taken:
                                continue            # уже нашёлся по другому ключу
                            taken.add(cid)
                            m.setdefault(eid, []).append(cid)
                            shifts[cid] = off
                if not loose:
                    break

    until = {}    # our id -> end of the guide the earlier sources gave it
    first = {}    # our id -> source that gave it the most programmes, for status
    tmp_parts, count = [], 0
    for s in usable:
        want = plan.get(s["name"])
        if not want:
            continue
        part = paths.xmltv + ".%s.part" % len(tmp_parts)
        reach, n_src = {}, 0
        try:
            with gzip.open(paths.epg_source(s["name"]), "rb") as f, open(part, "w", encoding="utf-8") as out:
                it = ET.iterparse(f, events=("start", "end"))
                _, root = next(it)
                for ev, el in it:
                    if ev != "end" or el.tag != "programme":
                        if ev == "end" and el.tag == "channel":
                            root.clear()
                        continue
                    cids = want.get(el.get("channel"))
                    if cids:
                        st0, sp0 = _ts(el.get("start", "")), _ts(el.get("stop", ""))
                        # epgshare (Serbia-*) в части каналов подписывает «+0100» время, посчитанное
                        # по летнему поясу (+0200): «Dnevnik 2» на RTS 1 стоял на 20:30 вместо 19:30
                        # (.20, 18.11.2026). Тот же канал в варианте «+0000» верен. Час вычитаем
                        bias = -3600 if (s["name"].startswith("Serbia-") and st0 is not None
                                         and el.get("start", "")[14:].strip() == "+0100") else 0
                        if bias:
                            st0, sp0 = st0 + bias, sp0 + bias
                        # передача с концом не позже начала (в источниках бывает «начало 19.11 06:55, конец
                        # 18.11 07:40» и нулевая длина) обрывала импорт EPG канала в Kodi: у «Дождя»
                        # после 02:55 не было ни одной передачи (.20, 18.11.2026) - такие пропускаем
                        # и передача на сутки («Настроение на Дожде» 18.11 05:55 - 19.11 06:00, ошибка Glanz)
                        # накрывала весь день: Kodi оставлял её и выбрасывал всё, что внутри - у «Дождя»
                        # на 18.11 было 7 передач из 50. Длиннее 18 часов - ошибка источника
                        if st0 is not None and sp0 is not None and st0 < sp0 <= st0 + 18 * 3600                                 and sp0 >= past - 86400 and st0 <= future + 86400:
                            take = [c for c in cids
                                    if past <= sp0 + shifts.get(c, 0) and st0 + shifts.get(c, 0) <= future
                                    and st0 + shifts.get(c, 0) >= until.get(c, 0) - 120]
                            if take:
                                # programme pictures dropped: Kodi shows the current
                                # programme's icon instead of the channel logo (switch
                                # OSD, tiles) - 21.10.2026 the Serbian channels from
                                # epgshare had a show still or a Kinopoisk poster in
                                # place of their logo; Glanz/Edem carry none
                                body = "".join(ET.tostring(ch, encoding="unicode") for ch in el if ch.tag != "icon")
                                for cid in take:
                                    off = shifts.get(cid, 0)
                                    attrib = dict(el.attrib)
                                    if off or bias:
                                        attrib["start"], attrib["stop"] = _fmt(st0 + off), _fmt(sp0 + off)
                                    attrs = " ".join("%s=%s" % (k, quoteattr(v)) for k, v in attrib.items()
                                                     if k != "channel")
                                    out.write('<programme %s channel="%s">%s</programme>\n' % (attrs, cid, body))
                                    sp = sp0 + off
                                    reach[cid] = max(reach.get(cid, 0), sp)
                                    first.setdefault(cid, s["name"])
                                    n_src += 1
                    root.clear()
        except (OSError, ET.ParseError, EOFError) as e:
            log("epg %s: parse stopped (%s)" % (s["name"], e))
        for cid, sp in reach.items():
            until[cid] = max(until.get(cid, 0), sp)
        tmp_parts.append(part)
        count += n_src
        log("epg %s: %d programmes for %d channels" % (s["name"], n_src, len(reach)))

    tmp = paths.xmltv + ".part"
    with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=5) as out:
        out.write('<?xml version="1.0" encoding="utf-8"?>\n<tv generator-info-name="service.tvlink">\n')
        for c in catalog["channels"]:
            if c["id"] in first:
                out.write('<channel id="%s"><display-name>%s</display-name></channel>\n'
                          % (c["id"], escape(c["title"])))
        for part in tmp_parts:
            with open(part, "r", encoding="utf-8") as f:
                while True:
                    chunk = f.read(1024 * 1024)
                    if not chunk:
                        break
                    out.write(chunk)
            os.unlink(part)
        out.write("</tv>\n")

    # a source that failed or shrank must not wipe the guide on screen: keep the
    # previous file unless the new one covers at least 80% of its channels
    prev = (read_json(paths.status, {}) or {}).get("epg_channels") or 0
    if os.path.exists(paths.xmltv) and len(first) < 0.8 * prev:
        os.unlink(tmp)
        log("epg kept previous: new covers %d channels, previous %d" % (len(first), prev))
        return prev, None
    os.replace(tmp, paths.xmltv)
    write_json(os.path.join(paths.cache, "epg_icons.json"), icons)
    short = sum(1 for c in first if until.get(c, 0) < time.time() + 86400)
    log("epg built: %d channels, %d programmes, %d end within a day" % (len(first), count, short))
    return len(first), count


def sources(cfg, catalog):
    srcs = list(cfg["epg"])
    if cfg.get("epg_from_playlist", True):
        have = {s["url"] for s in srcs}
        for name, h in catalog["headers"].items():
            for u in (h.get("url-tvg") or h.get("x-tvg-url") or "").split(","):
                u = u.strip()
                if u and u not in have:
                    srcs.append({"name": "%s-tvg" % name, "url": u})
                    have.add(u)
    return srcs


def job(root, force):
    """Child process entry: download what changed, rebuild, print one JSON line."""
    import json
    print(json.dumps(run_job(root, force)))


def run_job(root, force, nice=True):
    """Скачать изменившиеся гиды и пересобрать; итог - словарь. В процессе Kodi (не ELEC) без
    os.nice: он понизил бы приоритет самого Kodi."""
    from . import catalog as cat
    from .store import Paths, load_config
    paths = Paths(root)
    cfg = load_config(paths)
    logf = open(paths.log, "a", encoding="utf-8")
    log = lambda m: logf.write("%s [epg] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), m))
    c = cat.build(cfg, paths, persist=False)
    srcs = sources(cfg, c)
    changed = False
    for s in srcs:
        changed |= download(s, paths.epg_source(s["name"]), cfg, log)
    res = {}
    if changed or force or not os.path.exists(paths.xmltv):
        n, p = build(cfg, c, paths, srcs, log, nice=nice)
        res = {"epg_channels": n}
        if p is not None:
            res["epg_programmes"] = p
            # epg_built - знак для pvr «гид новый» (service.py перезагружает клиент).
            # Пересобранный, но тот же самый гид (принудительная сборка после смены
            # настроек) знаком не считается: иначе pvr перезагружался дважды подряд
            # (.20, 16.11.2026: 17:46:52 и 17:47:37)
            sig = content_sig(paths.xmltv)
            prev = read_json(paths.status, {}) or {}
            res["epg_sig"] = sig
            if sig != prev.get("epg_sig") or not prev.get("epg_built"):
                res["epg_built"] = int(time.time())
    logf.close()
    return res


def content_sig(path):
    """crc32 распакованного гида: у gzip в заголовке время сжатия, сам файл каждый раз другой."""
    import zlib
    crc = 0
    try:
        with gzip.open(path, "rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                crc = zlib.crc32(chunk, crc)
    except OSError:
        return None
    return "%08x" % (crc & 0xFFFFFFFF)


if __name__ == "__main__":
    import sys
    job(sys.argv[1], "force" in sys.argv[2:])
