# SPDX-License-Identifier: GPL-3.0-only
"""Sublime fork: carry the playback choices of the previous add-on (v7) over to v8, once.

v7 kept them under its own ids (kodion.mpd.quality.selection 3..6, kodion.mpd.stream.features
'avc1,vp9,av01,hdr,...', youtube.region, youtube.view.hide_videos 'shorts,...'); v8 has max_quality
(height), codec (preferred family), allow_hdr, region and hide_shorts. Without this an updated box falls back to v8's defaults (no height limit, any
codec), and a box whose installer limited it to H.264 would start decoding VP9/AV1 in software.

The old values are read from the settings file on disk; nothing is written unless an old value is
found, and only once (state in sublime_migrate.json)."""
import os
import re

from . import kodi

STATE = 'sublime_migrate.json'
HEIGHTS = {'3': '720', '4': '1080', '5': '1440', '6': '2160'}


def _old_settings():
    path = os.path.join(kodi.PROFILE, 'settings.xml')
    try:
        with open(path, encoding='utf-8') as handle:
            text = handle.read()
    except OSError:
        return {}
    return dict(re.findall(r'<setting id="([^"]+)"[^>]*>([^<]*)</setting>', text))


def run_once():
    state = kodi.load_json(STATE, {})
    if state.get('settings_v7'):
        return
    old = _old_settings()
    changes = {}
    quality = old.get('kodion.mpd.quality.selection')
    if quality in HEIGHTS:
        changes['max_quality'] = HEIGHTS[quality]
    features = [f.strip() for f in (old.get('kodion.mpd.stream.features') or '').split(',') if f.strip()]
    if features:
        changes['codec'] = 'any' if 'av01' in features else 'vp9' if 'vp9' in features else 'avc1'
        changes['allow_hdr'] = 'true' if 'hdr' in features else 'false'
    if old.get('youtube.region'):
        changes['region'] = old['youtube.region']
    hidden = [h.strip() for h in (old.get('youtube.view.hide_videos') or '').split(',')]
    if 'shorts' in hidden or 'hide_shorts' in hidden:
        changes['hide_shorts'] = 'true'
    for key, value in changes.items():
        kodi.ADDON.setSetting(key, value)
    if changes:
        kodi.log('settings carried over from v7: %s' % ', '.join('%s=%s' % kv for kv in sorted(changes.items())))
        kodi.refresh()
    state['settings_v7'] = 1
    kodi.save_json(STATE, state)
