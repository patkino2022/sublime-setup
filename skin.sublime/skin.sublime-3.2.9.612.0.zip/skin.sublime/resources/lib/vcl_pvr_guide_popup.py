# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Native Kodi PVR channels window presented with Sublime's fake-popup layout.

The obsolete runtime XML renderer/cache was removed in 3.2.9.10.672. Kodi owns
channel and EPG data; this module only resolves a native group path, seeds the
properties used by the skin layout, without changing the Home/hub window behind fullscreen playback.
"""

import json
import re
import sys

import xbmc

from resources.lib.sublime_helper.core import read_label
import xbmcaddon
import xbmcgui

import os
_ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
if _ADDON_ROOT not in sys.path:
    sys.path.insert(0, _ADDON_ROOT)
from resources.lib.sublime_helper.hubs import DEFAULT_HUB_ID, hub_from_window_id, local_window_id, valid_hub_id

try:
    from urllib.parse import quote, unquote
except Exception:  # pragma: no cover - Python 2 compatibility kept for old Kodi forks
    from urllib import quote, unquote

SKIN_ID = 'skin.sublime'
try:
    BUILD = xbmcaddon.Addon(SKIN_ID).getAddonInfo('version') or 'unknown'
except Exception:
    BUILD = 'unknown'


def log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('[sublime PVR popup %s] %s' % (BUILD, message), level)
    except Exception:
        pass


def _argv():
    params = {}
    for arg in sys.argv[1:]:
        if '=' in arg:
            key, value = arg.split('=', 1)
            params[key] = value
    return params


def _home():
    try:
        return xbmcgui.Window(10000)
    except Exception:
        return xbmcgui.Window(xbmcgui.getCurrentWindowId())


def _get_home(key, default=''):
    try:
        value = _home().getProperty(key)
        return value if value != '' else default
    except Exception:
        return default


def _set_home(key, value):
    try:
        _home().setProperty(key, '' if value is None else str(value))
    except Exception:
        pass


def _last_hub_key(default=DEFAULT_HUB_ID):
    return valid_hub_id(
        _get_home('Sublime.LastHub') or read_label('Skin.String(Sublime.LastHub)'),
        default)


def _hub_config_key(source_key):
    return str(source_key or '')


def rpc(method, params=None):
    payload = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params is not None:
        payload['params'] = params
    try:
        data = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    except Exception as exc:
        log('JSON-RPC parse failed for %s: %s' % (method, exc), xbmc.LOGWARNING)
        return None
    if data.get('error'):
        log('JSON-RPC error %s: %s' % (method, data.get('error')), xbmc.LOGWARNING)
        return None
    return data.get('result')


def _norm_label(value):
    try:
        value = unquote(str(value or '')).replace('+', ' ')
    except Exception:
        value = str(value or '')
    return re.sub(r'\s+', ' ', value.strip().lower())


def _group_hint_from_path(path):
    raw = str(path or '').strip()
    marker = 'pvr://channels/tv/'
    if not raw.lower().startswith(marker):
        return ''
    part = raw[len(marker):].split('?', 1)[0].split('#', 1)[0].rstrip('/')
    if '@' in part:
        part = part.split('@', 1)[0]
    try:
        part = unquote(part).replace('+', ' ')
    except Exception:
        pass
    return part.strip()


def load_groups():
    result = rpc('PVR.GetChannelGroups', {'channeltype': 'tv'})
    return (result or {}).get('channelgroups') or []


def choose_group(groups, path=''):
    if not groups:
        return None
    hint = _norm_label(_group_hint_from_path(path))
    if hint and hint not in ('*', 'all', 'all channels'):
        for group in groups:
            if _norm_label(group.get('label')) == hint:
                return group
        for group in groups:
            label = _norm_label(group.get('label'))
            if hint and (hint in label or label in hint):
                return group
        log('group not matched: path=%s hint=%s' % (path, hint), xbmc.LOGWARNING)
    for group in groups:
        label = (group.get('label') or '').lower()
        if any(token in label for token in ('избран', 'favour', 'favor')):
            return group
    return groups[0]


def _char_px(ch):
    if ch in 'il.,:;|! ':
        return 5
    if ch.isdigit():
        return 8
    if ord(ch) > 127:
        return 15
    return 9


def fit_text(value, width, pad=24, min_keep=1):
    text = re.sub(r'\s+', ' ', str(value or '').replace('\n', ' ').strip())
    available = max(0, int(width) - int(pad))
    if not text:
        return ''
    if sum(_char_px(ch) for ch in text) <= available:
        return text
    ellipsis = '…'
    if available <= _char_px(ellipsis) + 2:
        return ellipsis
    output = ''
    used = 0
    limit = available - _char_px(ellipsis)
    for ch in text:
        increment = _char_px(ch)
        if used + increment > limit:
            break
        output += ch
        used += increment
    return output.rstrip() + ellipsis if len(output) >= min_keep else ellipsis


def pvr_group_path(label):
    label = str(label or '').strip()
    try:
        encoded = quote(label, safe='')
    except Exception:
        encoded = label.replace(' ', '%20')
    return 'pvr://channels/tv/%s/' % encoded


def _percent_lower(value):
    return re.sub(r'%[0-9A-Fa-f]{2}', lambda match: match.group(0).lower(), str(value or ''))


def _pvr_client_suffix_from_path(path):
    raw = str(path or '').strip()
    try:
        raw = unquote(raw)
    except Exception:
        pass
    marker = 'pvr://channels/tv/'
    if not raw.lower().startswith(marker):
        return ''
    segment = raw[len(marker):].strip('/')
    if '@' not in segment:
        return ''
    suffix = segment[segment.find('@'):].split('/', 1)[0].strip()
    return suffix if suffix.startswith('@') else ''


def _native_pvr_group_path(label, source_path=''):
    label = str(label or '').strip()
    try:
        encoded = quote(label, safe='')
    except Exception:
        encoded = label.replace(' ', '%20')
    suffix = _pvr_client_suffix_from_path(source_path)
    if suffix:
        return 'pvr://channels/tv/%s%s/' % (_percent_lower(encoded), suffix)
    return 'pvr://channels/tv/%s/' % _percent_lower(encoded)


def play_channel(channel_id):
    try:
        channel_id = int(channel_id)
    except Exception:
        return
    try:
        # The PVR window is already active here, so preserve the hub captured
        # before opening it. The service uses this when Player.HasVideo changes
        # after the source hub is no longer visible.
        source_key = _get_home('VCL.PVRPopup.SourceHubKey') or _last_hub_key()
        source_runtime = _get_home('VCL.PVRPopup.SourceHubRuntime') or str(local_window_id(_last_hub_key()))
        _set_home('VCL.Playback.SourceHubKey', source_key)
        _set_home('VCL.Playback.SourceHubRuntime', source_runtime)
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.sleep(80)
        rpc('Player.Open', {'item': {'channelid': channel_id}})
    except Exception as exc:
        log('Player.Open failed channel=%s: %s' % (channel_id, exc), xbmc.LOGWARNING)


def _native_pvr_window_path(path):
    raw = str(path or '').strip()
    try:
        raw = unquote(raw)
    except Exception:
        pass
    if not raw.lower().startswith('pvr://channels/tv/'):
        return 'pvr://channels/tv/*'
    hint = _group_hint_from_path(raw)
    if not hint or hint in ('*', '/*'):
        return 'pvr://channels/tv/*'
    try:
        group = choose_group(load_groups(), raw)
        if group and group.get('label'):
            return _native_pvr_group_path(group.get('label'), raw)
    except Exception as exc:
        log('native path resolve failed for %s: %s' % (raw, exc), xbmc.LOGWARNING)
    return 'pvr://channels/tv/*'


def _source_hub_key():
    try:
        source = hub_from_window_id(xbmcgui.getCurrentWindowId())
    except Exception:
        source = ''
    return source or _last_hub_key()


def _source_hub_runtime_id():
    return local_window_id(_source_hub_key(), local_window_id(_last_hub_key()))


def _seed_pvrpopup_wheel_snapshot(source_key):
    try:
        source_key = source_key or _source_hub_key()
        values = {
            'Top': read_label('Container(399).ListItem(-1).Icon') or _get_home('VCL.PVRPopup.Wheel.Top'),
            'Center': read_label('Container(399).ListItem.Icon') or read_label('Skin.String(HomeSwitcher.%s.Icon)' % _hub_config_key(source_key)) or _get_home('VCL.PVRPopup.Wheel.Center'),
            'Near': read_label('Container(399).ListItem(1).Icon') or _get_home('VCL.PVRPopup.Wheel.Near'),
            'Far': read_label('Container(399).ListItem(2).Icon') or _get_home('VCL.PVRPopup.Wheel.Far'),
        }
        for key, value in values.items():
            _set_home('VCL.PVRPopup.Wheel.%s' % key, value or '')
    except Exception as exc:
        log('wheel snapshot failed: %s' % exc, xbmc.LOGWARNING)


def _seed_native_fake_group_buttons(native_path):
    max_slots = 9
    try:
        groups = [group for group in load_groups() if group.get('label')]
        selected = choose_group(groups, native_path)
        selected_id = selected.get('channelgroupid') if selected else None
        selected_index = next((i for i, group in enumerate(groups) if group.get('channelgroupid') == selected_id), 0)
    except Exception as exc:
        log('seed groups failed: %s' % exc, xbmc.LOGWARNING)
        groups, selected_index = [], 0
    if not groups:
        for slot in range(max_slots):
            for suffix in ('Visible', 'Label', 'Path'):
                _set_home('VCL.PVRPopup.Group.%d.%s' % (slot, suffix), '')
        _set_home('VCL.PVRPopup.ActiveGroupIndex', '0')
        _set_home('VCL.PVRPopup.NextGroupPath', 'pvr://channels/tv/*')
        return
    start = max(0, min(selected_index - 4, max(0, len(groups) - max_slots)))
    visible = groups[start:start + max_slots]
    active_slot = max(0, min(max_slots - 1, selected_index - start))
    next_group = groups[(selected_index + 1) % len(groups)]
    for slot in range(max_slots):
        if slot < len(visible):
            label = visible[slot].get('label') or ''
            _set_home('VCL.PVRPopup.Group.%d.Visible' % slot, 'true')
            _set_home('VCL.PVRPopup.Group.%d.Label' % slot, fit_text(label, 153, pad=28))
            _set_home('VCL.PVRPopup.Group.%d.Path' % slot, pvr_group_path(label))
        else:
            for suffix in ('Visible', 'Label', 'Path'):
                _set_home('VCL.PVRPopup.Group.%d.%s' % (slot, suffix), '')
    _set_home('VCL.PVRPopup.ActiveGroupIndex', str(active_slot))
    _set_home('VCL.PVRPopup.NextGroupPath', pvr_group_path(next_group.get('label') or ''))


def open_popup(path='', time_offset=0, channel_offset=0):
    del time_offset, channel_offset
    path = path or _get_home('VCL.PVRPopup.Path') or 'pvr://channels/tv/*'
    native_path = _native_pvr_window_path(path)
    _set_home('VCL.PVRPopup.NativeFake', 'true')
    _set_home('VCL.PVRPopup.Path', native_path)
    _set_home('VCL.PVRPopup.ChannelOffset', '0')
    _set_home('VCL.PVRPopup.PrewarmReady', 'native')
    source_key = _source_hub_key()
    source_runtime = _source_hub_runtime_id()
    _set_home('VCL.PVRPopup.SourceHubKey', source_key)
    _set_home('VCL.PVRPopup.SourceHubRuntime', source_runtime)
    _set_home('VCL.Playback.SourceHubKey', source_key)
    _set_home('VCL.Playback.SourceHubRuntime', source_runtime)
    _seed_pvrpopup_wheel_snapshot(source_key)
    _seed_native_fake_group_buttons(native_path)
    log('open raw=%s native=%s' % (path, native_path))
    try:
        xbmc.executebuiltin('ActivateWindow(tvchannels,%s,return)' % native_path)
    except Exception as exc:
        log('ActivateWindow(tvchannels) failed: %s' % exc, xbmc.LOGWARNING)
        xbmc.executebuiltin('ActivateWindow(TVChannels,%s,return)' % native_path)


def main(args=None):
    args = args or _argv()
    action = args.get('action', 'open')
    path = args.get('path') or args.get('pvr') or _get_home('VCL.PVRPopup.Path')
    try:
        path = unquote(path)
    except Exception:
        pass
    if action == 'play':
        play_channel(args.get('channelid') or args.get('channel') or '')
    elif action == 'prewarm':
        return  # Compatibility no-op for stale alarms from older builds.
    elif action == 'page':
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.sleep(80)
        open_popup(path, args.get('time_offset', 0), args.get('channel_offset', 0))
    else:
        open_popup(path, args.get('time_offset', 0), args.get('channel_offset', 0))


if __name__ == '__main__':
    main()
