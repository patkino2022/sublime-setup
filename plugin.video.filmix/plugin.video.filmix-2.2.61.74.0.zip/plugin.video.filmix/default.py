# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import sys
import time

import xbmc
from resources.libs import plugin

def _manifest_version(fallback=''):
    """The version Kodi actually installed, for ROUTE_START/ROUTE_DONE."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon(id='plugin.video.filmix').getAddonInfo('version') or fallback
    except Exception:
        return fallback


BUILD_VERSION = _manifest_version()
BUILD_MARKER = ''


# Без входа в аккаунт Filmix доступны только вход и настройки
_OPEN = ('/login', '/check_device', '/select_videoserver')


def _needs_signin():
    path = '/' + (sys.argv[0].split('://', 1)[-1].split('/', 1)[1] if '/' in sys.argv[0].split('://', 1)[-1] else '')
    if path.split('?')[0].rstrip('/') in _OPEN:
        return False
    try:
        import xbmcaddon
        return not xbmcaddon.Addon('plugin.video.filmix').getSetting('user_login')
    except Exception:
        return False


def _signin_screen():
    import xbmcgui
    import xbmcplugin
    handle = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].lstrip('-').isdigit() else -1
    if handle < 0:
        return
    if sys.argv[0].rstrip('/').rsplit('/', 1)[-1] in ('play', 'trailer'):
        xbmcgui.Dialog().notification('Filmix', 'Войдите в свой аккаунт Filmix', xbmcgui.NOTIFICATION_INFO, 5000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    item = xbmcgui.ListItem('[COLOR=FF00FF00]Войти в аккаунт Filmix[/COLOR]')
    xbmcplugin.addDirectoryItem(handle, 'plugin://plugin.video.filmix/login', item, False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


if __name__ == '__main__':
    _route_t0 = time.time()
    # Интерпретатор переиспользуется между вызовами (reuselanguageinvoker в addon.xml): модули
    # уже загружены, и вход в сериал не ждёт ~0,6-1 с запуска Python (.20, 20.11.2026). То,
    # что рассчитано на один вызов, сбрасывается здесь.
    try:
        from resources.libs import utilities as _u
        from resources.libs.navigation import FilmixCatalogs as _fc
        _u.reset_call_state()
        _fc._user_lists.clear()
        _fc._user_search[0] = False
        del _fc._deferred_posts[:]
    except Exception:
        pass
    try:
        xbmc.log('[plugin.video.filmix] ROUTE_START v{0}: {1} argv={2}'.format(BUILD_VERSION, BUILD_MARKER, sys.argv), xbmc.LOGINFO)
    except Exception:
        pass
    try:
        if _needs_signin():
            _signin_screen()
        else:
            plugin.run()
    finally:
        try:
            xbmc.log('[plugin.video.filmix] ROUTE_DONE v{0}: {1} elapsed={2:.3f}s requests={4} argv={3}'.format(BUILD_VERSION, BUILD_MARKER, time.time() - _route_t0, sys.argv, int('requests' in sys.modules)), xbmc.LOGINFO)
        except Exception:
            pass
        try:
            from resources.libs.navigation import FilmixCatalogs as _fc2
            _w0 = time.time()
            _n = _fc2.flush_deferred_posts()
            if _n:
                xbmc.log('[plugin.video.filmix] deferred posts written={0} elapsed={1:.3f}s'.format(_n, time.time() - _w0), xbmc.LOGINFO)
        except Exception:
            pass
