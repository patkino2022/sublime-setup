# -*- coding: utf-8 -*-
"""Скрыть штатные пункты контекстного меню - и только потом показать меню.

Владелец 06.11.2026: «При открытии контекстного меню на мгновение оно
появляется в старом виде без скрытых пунктов». Замер на .30: меню видно через
0,02-0,05 с, пункты скрыты через 0,29-0,35 с - это запуск интерпретатора и
импорт модулей скина, которые тянула прежняя RunScript(skin.sublime,
action=hide_context_information).

Теперь DialogContextMenu.xml держит меню невидимым, пока здесь не поставлено
Window(Home).Property(Sublime.ContextReady), а этот скрипт нарочно лёгкий:
только xbmc/xbmcgui, ничего из скина. Через секунду меню показывается в любом
случае (AlarmClock в DialogContextMenu.xml) - на загруженной коробке скрипт
однажды стартовал через 13 с.

Что скрывается - см. ниже. Если не остаётся ни одного пункта, меню
закрывается.
"""
from __future__ import absolute_import, unicode_literals

import time

import xbmc
import xbmcgui

# Штатные пункты Kodi, которые скин убирает из контекстного меню. Номера -
# строки языкового файла Kodi; подпись берётся на языке коробки.
#   190    «Информация» - у скина своя панель сведений;
#   14076  «Добавить в избранное»  } избранным Kodi владелец не пользуется
#   14077  «Удалить из избранного» } (06.11.2026: «вообще удали везде»);
#   13349  «Сканировать содержимое» - для папок дополнений ничего не делает;
#   208, 15218  «Воспроизвести» - владелец 06.11.2026: «из всех контекстных
#          меню убрать» (воспроизводит и так нажатие на плитку);
#   10008 «Воспроизвести следующий», 13347, 526 «Добавить в плейлист» -
#          сначала только у фильмов, потом владелец прислал снимок меню ролика
#          YouTube с ними же: «неубранные пункты» - значит везде.
#   «Продолжить с ...» остаётся, и «Воспроизвести с начала» (12021) тоже:
#          14.11.2026 владелец велел вернуть его для неоконченных. Kodi сам
#          показывает его только рядом с «Продолжить с ...».
# Пункты Filmix подписаны иначе («Filmix: В избранное») и сюда не попадают.
HIDDEN_CONTEXT_STRINGS = (190, 14076, 14077, 13349, 208, 15218,
                          10008, 13347, 526)
# Штатное «Отметить как просмотренное» (16103) - только у фильмов: у них есть
# своё «Отметить просмотренным» скина. У роликов YouTube владелец велел его
# оставить (06.11.2026). Тип плитки публикует служба скина.
HIDDEN_MOVIE_CONTEXT_STRINGS = (16103,)
KIND_PROPERTY = 'Sublime.ContextKind'
HIDDEN_CONTEXT_FALLBACK = ('information', 'info', 'информация',
                           'add to favourites', 'remove from favourites',
                           'добавить в избранное', 'удалить из избранного',
                           'scan for new content', 'сканировать содержимое',
                           'play', 'воспроизвести',
                           # «Сбросить позицию возобновления» - владелец 14.11.2026:
                           # «нигде не нужен». Пункт Kodi у фильмов и
                           # дополнения YouTube у роликов, подпись одна.
                           'сбросить позицию возобновления',
                           'reset resume point')
READY_PROPERTY = 'Sublime.ContextReady'
# Позже этого прятать нельзя: пункт мог уже оказаться под курсором владельца,
# а скрытие пункта в открытом меню на глазах - это схлопывание меню.
CONTEXT_HIDE_GRACE = 1.0


def _labels_to_hide():
    string_ids = HIDDEN_CONTEXT_STRINGS
    try:
        if xbmcgui.Window(10000).getProperty(KIND_PROPERTY) == 'movie':
            string_ids = string_ids + HIDDEN_MOVIE_CONTEXT_STRINGS
    except Exception:
        pass
    labels = set(HIDDEN_CONTEXT_FALLBACK)
    for string_id in string_ids:
        labels.add(str(xbmc.getLocalizedString(string_id) or '').strip().casefold())
    labels.discard('')
    return labels


def hide():
    """Скрыть пункты в открытом меню. Возвращает номера скрытых кнопок.

    xbmcgui.Window.getControl() пишет в журнал исключение на каждый
    отсутствующий номер, даже пойманное, поэтому подписи читаются тихим
    Control.GetLabel, а трогается только существующая кнопка.
    """
    labels = _labels_to_hide()
    monitor = xbmc.Monitor()
    started = time.monotonic()
    deadline = started + 1.5
    while time.monotonic() < deadline:
        if not (xbmc.getCondVisibility('Window.IsVisible(DialogContextMenu.xml)') or
                xbmc.getCondVisibility('Window.IsActive(DialogContextMenu.xml)')):
            if monitor.waitForAbort(0.02):
                return []
            continue
        matched, kept = [], []
        # Кнопки меню - 1000 и дальше.
        for control_id in range(1000, 1100):
            label = str(xbmc.getInfoLabel('Control.GetLabel(%d)' % control_id) or '').strip()
            normalized = label.casefold()
            if not normalized:
                continue
            if normalized in labels or normalized.endswith(' information'):
                matched.append(control_id)
            else:
                kept.append(control_id)
        if not matched:
            return []
        if not kept:
            # Пунктов не осталось вовсе - меню не нужно. 06.11.2026 у канала
            # YouTube в меню был один «Добавить в избранное», и он стоял под
            # курсором, а пункт под курсором прятать нельзя - так он и оставался.
            xbmc.executebuiltin('Dialog.Close(contextmenu,true)')
            xbmc.log('[sublime context] all entries hidden - menu closed', xbmc.LOGINFO)
            return matched
        if time.monotonic() - started > CONTEXT_HIDE_GRACE:
            xbmc.log('[sublime context] hiding skipped: menu already open %.1fs'
                     % (time.monotonic() - started), xbmc.LOGINFO)
            return []
        try:
            win = xbmcgui.Window(10106)
        except Exception:
            return []
        # Без фокуса Kodi закрывает меню, поэтому курсор с прячемого пункта
        # сначала уходит на первый оставшийся.
        for control_id in matched:
            if xbmc.getCondVisibility('Control.HasFocus(%d)' % control_id):
                xbmc.executebuiltin('SetFocus(%d)' % kept[0])
                for _ in range(10):
                    if xbmc.getCondVisibility('Control.HasFocus(%d)' % kept[0]):
                        break
                    monitor.waitForAbort(0.01)
                break
        hidden = []
        for control_id in matched:
            try:
                if xbmc.getCondVisibility('Control.HasFocus(%d)' % control_id):
                    continue
                control = win.getControl(control_id)
                control.setEnabled(False)
                control.setVisible(False)
                hidden.append(control_id)
            except Exception as exc:
                xbmc.log('[sublime context] hide failed id=%s error=%s'
                         % (control_id, exc), xbmc.LOGWARNING)
        xbmc.log('[sublime context] native entries hidden controls=%s in %.0f ms'
                 % (','.join(map(str, hidden)) or 'none',
                    (time.monotonic() - started) * 1000), xbmc.LOGINFO)
        return hidden
    return []


if __name__ == '__main__':
    try:
        hide()
    finally:
        # Меню показывается в любом случае - и когда скрывать было нечего.
        xbmcgui.Window(10000).setProperty(READY_PROPERTY, 'true')
