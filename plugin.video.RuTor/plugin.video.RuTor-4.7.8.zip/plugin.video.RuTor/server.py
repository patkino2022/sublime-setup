# coding: utf-8
# Module: server
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
import xbmc, xbmcgui, xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.RuTor')

print('----- Rutor serv started: AM8 4GB idle guard -----')
monitor = xbmc.Monitor()
player = xbmc.Player()

# AM8 4GB: do not compete with Kodi/skin/widget startup.
# Native RuTor prewarm/cache is preserved, just delayed and made idle-safe.
if not monitor.abortRequested():
	monitor.waitForAbort(120)

while not monitor.abortRequested():
	try:
		if not player.isPlaying():
			xbmc.executebuiltin('RunPlugin("plugin://plugin.video.RuTor/?mode=Check")')
		else:
			print('----- Rutor serv skip Check: playback active -----')
	except Exception:
		pass
	monitor.waitForAbort(8*60*60)

print('----- Rutor serv stopped: AM8 4GB idle guard -----')
