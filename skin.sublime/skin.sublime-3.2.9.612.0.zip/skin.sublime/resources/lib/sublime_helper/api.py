# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import hashlib
import json
import threading
import ssl
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from urllib.request import Request, urlopen

import xbmc
import xbmcgui

from . import cache, config

LOG_PREFIX = '[sublime metadata]'
USER_AGENT = 'Kodi/skin.sublime'
_NETWORK_MONITOR = xbmc.Monitor()
_CACHE_ONLY = False


from . import tls as _tls

_SSL_CTX = _tls.context()
_tls.install()


def set_cache_only(value):
    """Disallow network access for cacheonly plugin invocations.

    The flag is process-wide on purpose: provider helper threads created by the
    same plugin invoker must obey the same policy. Each Kodi plugin invocation
    runs in its own Python interpreter context.
    """
    global _CACHE_ONLY
    _CACHE_ONLY = bool(value)


# A per-thread override of the flag above, used for exactly one thing: asking a
# provider «what do you already have» without allowing a network call. The
# metadata worker shares this process with everything else, so the policy has to
# be per-thread or it would change the rules for everybody.
_THREAD_POLICY = threading.local()


class cache_only_scope(object):
    """Caches may be read, the network may not - for this thread, in this block."""

    def __init__(self, value=True):
        self.value = bool(value)
        self.previous = None

    def __enter__(self):
        self.previous = getattr(_THREAD_POLICY, 'cache_only', None)
        _THREAD_POLICY.cache_only = self.value
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        _THREAD_POLICY.cache_only = self.previous
        return False


def cache_only():
    thread_value = getattr(_THREAD_POLICY, 'cache_only', None)
    if thread_value is not None:
        return bool(thread_value)
    return bool(_CACHE_ONLY)


# Удачные исходы опознания - в отладочный журнал. Аудит .20 17.10.2026: за
# 14.5 часа ~49 тысяч строк «provider=... status=ok/identity_cache_hit/
# trusted_cross_id» и ~3.5 тысячи «search reject», больше половины журнала
# (23 МБ в сутки на встроенную память). Ошибки, квоты, отказы опознания и
# итоговые строки item=... остаются в обычном журнале.
_QUIET_STATUSES = ('status=ok ', 'status=identity_cache_hit ', 'status=trusted_cross_id ',
                   'status=supported_cross_id ', 'status=trusted_explicit_localized ')


def _quiet(message):
    text = str(message)
    if text.startswith('search reject:'):
        return True
    if not text.startswith('provider='):
        return False
    head = text.split(' ', 2)
    status = (head[1] + ' ') if len(head) > 1 else ''
    return status in _QUIET_STATUSES


def log(message, level=xbmc.LOGINFO):
    try:
        if level == xbmc.LOGINFO and _quiet(message):
            level = xbmc.LOGDEBUG
        xbmc.log('%s %s' % (LOG_PREFIX, message), level)
    except Exception:
        pass


def _redact_url(url):
    try:
        parts = urlsplit(url)
        sensitive = {'api_key', 'apikey', 'client_key', 'client_id', 'client_secret', 'access_token'}
        query = [(key, '***' if key.lower() in sensitive else value) for key, value in parse_qsl(parts.query, keep_blank_values=True)]
        return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query, doseq=True), parts.fragment))
    except Exception:
        return url


def _cache_ttl(hours=None):
    return int((hours if hours is not None else config.cache_hours()) * 3600)


def _auth_failure_key(url, headers):
    try:
        parts = urlsplit(url)
        sensitive = {'api_key', 'apikey', 'client_key', 'client_id', 'client_secret', 'access_token'}
        material = [value for key, value in parse_qsl(parts.query, keep_blank_values=True) if key.lower() in sensitive]
        for key, value in (headers or {}).items():
            if key.lower() in ('authorization', 'x-api-key') and value:
                material.append(str(value))
        if not material:
            return ''
        digest = hashlib.sha1('|'.join(material).encode('utf-8', 'ignore')).hexdigest()[:16]
        return 'authfail:%s:%s' % (parts.netloc.lower(), digest)
    except Exception:
        return ''


_PROVIDER_LOGGED = set()
_PROVIDER_RETRY_UNTIL = {}

# Слова, которыми службы сообщают, что норма запросов исчерпана. Номер ответа
# для этого решения не годится: kinopoiskapiunofficial отвечает 402, а
# kinopoisk.dev на том же самом - 403 («Вы израсходовали ваш суточный
# лимит по запросам», замер на .30 08.09.2026). Пока решение принималось по
# номеру, 403 считался ошибкой ключа: пауза пять минут вместо паузы до
# полуночи, и служба не отключалась целиком, то есть остаток суток мы
# ломились в закрытую дверь. Решение принимается ОДИН раз и здесь - по тексту
# ответа, для любой службы.
_QUOTA_WORDS = ('quota', 'лимит', 'норм', 'rate limit', 'too many request',
                'исчерпал', 'израсходовал')
_QUOTA_DAILY_WORDS = ('per day', 'в сутки', 'за сутки', 'суточн', 'daily')


def _quota_verdict(answer):
    """(норма исчерпана, исчерпана до полуночи) по тексту ответа службы."""
    lowered = str(answer or '').lower()
    if not any(word in lowered for word in _QUOTA_WORDS):
        return False, False
    return True, any(word in lowered for word in _QUOTA_DAILY_WORDS)

# After a transport-level failure (TLS/ASN1, connection reset, timeout) the empty
# result must NOT be cached as a genuine "no match". Recording a short retry here
# makes the assembled bundle non-cacheable (see core._attach_provider_retry /
# _cache_result) and self-clears, so the item is re-resolved instead of poisoned.
_TRANSPORT_RETRY_SECONDS = 45


def _set_provider_retry(provider, retry_at):
    provider = str(provider or '').strip().lower()
    try:
        retry_at = float(retry_at or 0)
    except Exception:
        retry_at = 0.0
    if provider and retry_at > time.time():
        _PROVIDER_RETRY_UNTIL[provider] = retry_at


def provider_retry_at(provider):
    provider = str(provider or '').strip().lower()
    try:
        retry_at = float(_PROVIDER_RETRY_UNTIL.get(provider) or 0)
    except Exception:
        retry_at = 0.0
    if retry_at <= time.time():
        _PROVIDER_RETRY_UNTIL.pop(provider, None)
        return 0.0
    return retry_at


def _clear_provider_retry(provider):
    _PROVIDER_RETRY_UNTIL.pop(str(provider or '').strip().lower(), None)


def _provider_name(url, provider=''):
    if provider:
        return str(provider).strip().lower()
    try:
        host = (urlsplit(url).netloc or '').lower()
    except Exception:
        host = ''
    if 'themoviedb' in host:
        return 'tmdb'
    if 'kinopoisk' in host:
        return 'kinopoisk'
    if 'omdbapi' in host:
        return 'imdb'
    if 'fanart.tv' in host:
        return 'fanart'
    if 'mdblist' in host:
        return 'mdblist'
    return host.split(':', 1)[0] or 'unknown'


def _provider_endpoint(url):
    try:
        parts = urlsplit(url)
        return parts.path or '/'
    except Exception:
        return '/'


def _provider_status(provider, status, detail=''):
    provider = str(provider or 'unknown').strip().lower()
    try:
        win = xbmcgui.Window(10000)
        base = 'SublimeHelper.Provider.%s' % provider.capitalize()
        win.setProperty('%s.Status' % base, str(status or ''))
        if detail:
            win.setProperty('%s.Error' % base, str(detail)[:240])
        else:
            win.clearProperty('%s.Error' % base)
    except Exception:
        pass


def _log_provider_success(provider, endpoint, cached=False):
    marker = '%s:%s' % (provider, 'cache' if cached else 'network')
    if marker in _PROVIDER_LOGGED:
        return
    _PROVIDER_LOGGED.add(marker)
    log('provider=%s status=ok source=%s endpoint=%s' % (
        provider, 'cache' if cached else 'network', endpoint), xbmc.LOGINFO)


def _stale(key, ttl, provider):
    """Последний сохранённый ответ без срока - когда поставщик отказал (норма кончилась, ошибка,
    сеть). Карточка Кинопоиска с логотипом «Вествуда» лежала в кэше, но срок истёк, а второй API
    отвечал 402 - опознание выходило без логотипа, и он пропадал с экрана (.20, 22.11.2026)."""
    if ttl == 0:
        return {}
    try:
        old = cache.get(key, None)
    except Exception:
        old = None
    if old:
        log('provider=%s status=stale_cache (поставщик отказал - прежний ответ)' % provider, xbmc.LOGINFO)
        return old
    return {}


def get_json(url, params=None, headers=None, ttl=None, cache_key=None, method='GET', data=None, provider=''):
    params = dict(params or {})
    headers = dict(headers or {})
    if params:
        separator = '&' if '?' in url else '?'
        url = '%s%s%s' % (url, separator, urlencode(params, doseq=True))
    provider = _provider_name(url, provider)
    endpoint = _provider_endpoint(url)
    key = cache_key or '%s:%s:%s' % (method, url, data or '')
    if ttl != 0:
        hit = cache.get(key, _cache_ttl() if ttl is None else ttl)
        if hit is not None:
            _provider_status(provider, 'ok')
            _log_provider_success(provider, endpoint, cached=True)
            return hit
    if cache_only():
        _provider_status(provider, 'cache_miss', 'network disabled by cacheonly=true')
        return {}
    body = None
    if data is not None:
        body = json.dumps(data).encode('utf-8')
        headers.setdefault('Content-Type', 'application/json')
    headers.setdefault('User-Agent', USER_AGENT)
    auth_failure_key = _auth_failure_key(url, headers)
    if auth_failure_key:
        # Читается без срока: сколько ждать, сказано в самой записи. Прежде
        # запись жила пять минут, и пауза «до полуночи» на деле означала
        # запрос каждые пять минут - срок чтения кэша отменял решение.
        cached_failure = cache.get(auth_failure_key, None)
        if isinstance(cached_failure, dict):
            retry_at = float(cached_failure.get('retry_at') or 0)
            if retry_at > time.time():
                failure_code = int(cached_failure.get('code') or 401)
                is_quota = bool(cached_failure.get('quota'))
                if is_quota:
                    _set_provider_retry(provider, retry_at)
                _provider_status(provider,
                                 'quota_error' if is_quota else 'auth_error',
                                 'cached HTTP %s failure' % failure_code)
                return _stale(key, ttl, provider)
    request = Request(url, data=body, headers=headers, method=method)
    last_error = None
    for attempt in range(2):
        try:
            with urlopen(request, timeout=config.request_timeout(), context=_SSL_CTX) as response:
                raw_bytes = response.read()
                raw = raw_bytes.decode('utf-8-sig', 'replace').strip()
                if not raw:
                    result = {}
                else:
                    try:
                        result = json.loads(raw)
                    except ValueError:
                        # Some provider responses contain unescaped control characters.
                        result = json.loads(raw, strict=False)
                if ttl != 0:
                    cache.set(key, result)
                _provider_status(provider, 'ok')
                _clear_provider_retry(provider)
                _log_provider_success(provider, endpoint, cached=False)
                return result
        except HTTPError as exc:
            last_error = exc
            if exc.code == 404:
                # «У этой записи ничего нет» - ответ, а не сбой: запоминаем пустым на срок кэша
                # запроса. Без этого fanart.tv/kinopoisk.dev спрашивались заново при каждом
                # опознании той же записи (аудит 22.11.2026). Раньше так было только у mdblist.
                if ttl != 0:
                    try:
                        cache.set(key, {})
                    except Exception:
                        pass
                _provider_status(provider, 'no_data', 'HTTP 404 endpoint=%s' % endpoint)
                return {}
            if exc.code == 429 and attempt == 0:
                retry_after = 1.0
                try:
                    retry_after = float(exc.headers.get('Retry-After') or 1.0)
                except Exception:
                    retry_after = 1.0
                retry_after = max(0.5, min(30.0, retry_after))
                if _NETWORK_MONITOR.waitForAbort(retry_after):
                    return {}
                continue
            quota_seen = exc.code == 402
            if exc.code in (401, 402, 403) and auth_failure_key:
                # Отказ бывает двух разных смыслов, и ждать после них надо
                # по-разному: исчерпанная суточная норма - до полуночи, плохой
                # ключ - пять минут. Смысл читается из текста ответа
                # (_quota_verdict), потому что номер у служб разный: 402 у
                # kinopoiskapiunofficial, 403 у kinopoisk.dev. Сам 402 считается
                # нормой запросов и без слов - это «требуется оплата тарифа».
                answer = ''
                try:
                    answer = (exc.read() or b'').decode('utf-8', 'replace')
                except Exception:
                    answer = ''
                quota, daily = _quota_verdict(answer)
                quota_seen = quota or exc.code == 402
                retry_at = time.time() + (5 * 60)
                if daily:
                    # До завтрашней полуночи по местному времени.
                    now = time.time()
                    midnight = time.mktime(
                        time.localtime(now + 24 * 3600)[:3] + (0, 0, 0, 0, 0, -1))
                    retry_at = max(now + 600, midnight)
                    log('provider=%s status=quota_exhausted до %s (суточная '
                        'норма исчерпана, HTTP %s)'
                        % (provider, time.strftime('%d.%m %H:%M',
                                                   time.localtime(retry_at)),
                           exc.code),
                        xbmc.LOGWARNING)
                cache.set(auth_failure_key, {'code': int(exc.code),
                                             'retry_at': int(retry_at),
                                             'quota': bool(quota_seen)})
                if quota_seen:
                    _set_provider_retry(provider, retry_at)
            detail = 'HTTP %s endpoint=%s' % (exc.code, endpoint)
            status_name = 'quota_error' if quota_seen else 'auth_error' if exc.code in (401, 403) else 'error'
            _provider_status(provider, status_name, detail)
            log('provider=%s status=error HTTP=%s endpoint=%s url=%s' % (
                provider, exc.code, endpoint, _redact_url(url)), xbmc.LOGWARNING)
            break
        except ValueError as exc:
            last_error = exc
            preview = ''
            try:
                preview = ' '.join(raw[:180].split())
            except Exception:
                pass
            detail = 'invalid JSON endpoint=%s' % endpoint
            _provider_status(provider, 'error', detail)
            log('provider=%s status=error invalid_json endpoint=%s preview=%s error=%s' % (
                provider, endpoint, preview, exc), xbmc.LOGWARNING)
            # A malformed response is deterministic; retry once only in case a proxy
            # returned a transient partial body.
            if attempt == 0:
                time.sleep(0.25)
                continue
            break
        except (URLError, OSError) as exc:
            last_error = exc
            if attempt == 0:
                time.sleep(0.25)
                continue
            detail = '%s endpoint=%s' % (exc, endpoint)
            _set_provider_retry(provider, time.time() + _TRANSPORT_RETRY_SECONDS)
            _provider_status(provider, 'error', detail)
            break
        except Exception as exc:
            last_error = exc
            detail = '%s endpoint=%s' % (exc, endpoint)
            _set_provider_retry(provider, time.time() + _TRANSPORT_RETRY_SECONDS)
            _provider_status(provider, 'error', detail)
            break
    if last_error:
        log('provider=%s status=error endpoint=%s request_failed=%s' % (
            provider, endpoint, last_error), xbmc.LOGWARNING)
    return _stale(key, ttl, provider)


def _tmdb_language_code():
    locale = str(config.language() or '').strip().replace('_', '-')
    return locale.split('-', 1)[0].lower() if locale else ''


def _tmdb_image_languages():
    """Match TMDb's ISO-639-1 artwork language list."""
    short = _tmdb_language_code()
    values = []
    for value in (short, 'null', 'en'):
        if value and value not in values:
            values.append(value)
    return ','.join(values)


def _tmdb_video_languages():
    short = _tmdb_language_code()
    values = []
    for value in (short, 'null', 'en'):
        if value and value not in values:
            values.append(value)
    return ','.join(values)


class TMDb(object):
    root = 'https://api.themoviedb.org/3'

    def available(self):
        return bool(config.tmdb_key() or config.tmdb_token())

    def request(self, path, params=None, ttl=None, language=True, region=False, cache_key=None):
        if not self.available():
            return {}
        params = dict(params or {})
        headers = {}
        token = config.tmdb_token()
        if token:
            headers['Authorization'] = 'Bearer %s' % token
        else:
            params['api_key'] = config.tmdb_key()
        if language and 'language' not in params:
            params['language'] = config.language()
        if region and 'region' not in params:
            params['region'] = config.region()
        return get_json(self.root + path, params=params, headers=headers, ttl=ttl, cache_key=cache_key, provider='tmdb')

    def configuration(self):
        return self.request('/configuration', language=False, ttl=7 * 86400)

    def search(self, media_type, query, year=None, page=1):
        media_type = 'tv' if media_type in ('tv', 'tvshow', 'episode', 'season') else media_type
        if media_type not in ('movie', 'tv', 'person', 'multi', 'collection', 'keyword'):
            media_type = 'multi'
        params = {'query': query or '', 'page': page, 'include_adult': 'false'}
        if year:
            if media_type == 'movie':
                params['year'] = year
            elif media_type == 'tv':
                params['first_air_date_year'] = year
        return self.request('/search/%s' % media_type, params=params, ttl=6 * 3600)

    def find(self, external_id, source='imdb_id'):
        if not external_id:
            return {}
        return self.request('/find/%s' % external_id, params={'external_source': source}, ttl=7 * 86400)

    def details(self, media_type, tmdb_id, season=None, episode=None):
        media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
        if media_type == 'person':
            path = '/person/%s' % tmdb_id
            append = 'images,combined_credits,external_ids,translations'
        elif media_type == 'movie':
            path = '/movie/%s' % tmdb_id
            append = 'credits,images,videos,recommendations,similar,external_ids,alternative_titles,translations,release_dates,watch/providers,keywords,reviews'
        elif media_type == 'tv' and season not in (None, '') and episode not in (None, '', 0, '0'):
            path = '/tv/%s/season/%s/episode/%s' % (tmdb_id, season, episode)
            append = 'credits,images,videos,external_ids,translations'
        elif media_type == 'tv' and season not in (None, ''):
            path = '/tv/%s/season/%s' % (tmdb_id, season)
            append = 'credits,aggregate_credits,images,videos,external_ids,translations'
        else:
            path = '/tv/%s' % tmdb_id
            append = 'aggregate_credits,credits,images,videos,recommendations,similar,external_ids,alternative_titles,translations,content_ratings,watch/providers,keywords,reviews'
        return self.request(path, params={
            'append_to_response': append,
            'include_image_language': _tmdb_image_languages(),
            'include_video_language': _tmdb_video_languages(),
        })

    def credits(self, media_type, tmdb_id, season=None, episode=None):
        media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
        if media_type == 'movie':
            path = '/movie/%s/credits' % tmdb_id
            aggregate = False
        elif media_type == 'tv' and season not in (None, '') and episode not in (None, '', 0, '0'):
            path = '/tv/%s/season/%s/episode/%s/credits' % (tmdb_id, season, episode)
            aggregate = False
        elif media_type == 'tv' and season not in (None, ''):
            path = '/tv/%s/season/%s/aggregate_credits' % (tmdb_id, season)
            aggregate = True
        else:
            path = '/tv/%s/aggregate_credits' % tmdb_id
            aggregate = True
        return self.request(path, ttl=24 * 3600), aggregate

    def images(self, media_type, tmdb_id, season=None, episode=None,
               language_filter=None, include_fallbacks=True, complete=False,
               cache_version=''):
        media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
        if media_type == 'person':
            path = '/person/%s/images' % tmdb_id
        elif media_type == 'movie':
            path = '/movie/%s/images' % tmdb_id
        elif season not in (None, '') and episode not in (None, '', 0, '0'):
            path = '/tv/%s/season/%s/episode/%s/images' % (tmdb_id, season, episode)
        elif season not in (None, ''):
            path = '/tv/%s/season/%s/images' % (tmdb_id, season)
        else:
            path = '/tv/%s/images' % tmdb_id

        if complete:
            cache_key = 'tmdb-images-complete:%s:%s:%s' % (
                str(cache_version or 'v1'), media_type, tmdb_id)
            return self.request(
                path, params={}, ttl=6 * 3600, language=False,
                cache_key=cache_key)

        short = str(language_filter or _tmdb_language_code() or '').strip().lower()
        languages = []
        if short:
            languages.append(short)
        if include_fallbacks:
            for value in ('null', 'en'):
                if value not in languages:
                    languages.append(value)
        params = {'include_image_language': ','.join(languages)} if languages else {}
        # Keep the normal locale (for example ru-RU) while the image filter uses
        # ISO-639-1 values (ru,null,en). This mirrors TMDb's intended split.
        return self.request(path, params=params, ttl=6 * 3600, language=True)

    def videos(self, media_type, tmdb_id, season=None, episode=None):
        data = self.details(media_type, tmdb_id, season, episode)
        return data.get('videos') or {}

    def recommendations(self, media_type, tmdb_id, page=1):
        media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
        return self.request('/%s/%s/recommendations' % (media_type, tmdb_id), params={'page': page}, ttl=12 * 3600)

    def similar(self, media_type, tmdb_id, page=1):
        media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
        return self.request('/%s/%s/similar' % (media_type, tmdb_id), params={'page': page}, ttl=12 * 3600)

    def seasons(self, tmdb_id):
        return self.details('tv', tmdb_id).get('seasons') or []

    def season(self, tmdb_id, season):
        return self.details('tv', tmdb_id, season=season)

    def collection(self, collection_id):
        return self.request('/collection/%s' % collection_id)


    def trending(self, media_type='all', window='week', page=1):
        return self.request('/trending/%s/%s' % (media_type, window), params={'page': page}, ttl=2 * 3600)

    def popular(self, media_type='movie', page=1):
        media_type = 'tv' if media_type in ('tvshow', 'tv') else 'movie'
        return self.request('/%s/popular' % media_type, params={'page': page}, ttl=4 * 3600, region=True)

    def genres(self, media_type='movie'):
        media_type = 'tv' if media_type in ('tvshow', 'tv') else 'movie'
        return self.request('/genre/%s/list' % media_type, ttl=7 * 86400)

    def discover(self, media_type='movie', params=None):
        media_type = 'tv' if media_type in ('tvshow', 'tv') else 'movie'
        return self.request('/discover/%s' % media_type, params=params or {}, ttl=4 * 3600, region=True)


class OMDb(object):
    root = 'https://www.omdbapi.com/'

    def details(self, imdb_id='', title='', year=''):
        if not config.use_omdb():
            return {}
        imdb_id = str(imdb_id or '').strip()
        if imdb_id and not imdb_id.startswith('tt'):
            imdb_id = ''
        params = {'apikey': config.omdb_key(), 'plot': 'full', 'r': 'json'}
        if imdb_id:
            params['i'] = imdb_id
        elif title:
            params['t'] = title
            if year:
                params['y'] = year
        else:
            return {}
        data = get_json(self.root, params=params, ttl=7 * 86400, provider='imdb')
        return data if str(data.get('Response', 'True')).lower() != 'false' else {}


class KinopoiskDev(object):
    """Второй API Кинопоиска - kinopoisk.dev.

    Зачем: у kinopoiskapiunofficial норма 500 запросов в сутки, и на .30
    07.09.2026 она исчерпалась («provider=kinopoisk status=quota_exhausted»),
    то есть оценок КП в этот день больше не будет. У kinopoisk.dev норма выше,
    а поля те же по смыслу - id, названия, описание, год, рейтинг, постер,
    логотип. Ключ вводится в настройках скина; пока его нет, класс молчит и
    работает прежний путь.

    Документация: https://api.kinopoisk.dev/documentation (v1.4).
    """
    root = 'https://api.kinopoisk.dev/v1.4'

    def available(self):
        return bool(config.kinopoisk_dev_key())

    def request(self, path, params=None, ttl=None):
        if not self.available():
            return {}
        headers = {
            'X-API-KEY': config.kinopoisk_dev_key(),
            'Accept': 'application/json',
        }
        return get_json('%s/%s' % (self.root.rstrip('/'), str(path or '').lstrip('/')),
                        params=params or {}, headers=headers, ttl=ttl,
                        provider='kinopoisk_dev')

    def details(self, kinopoisk_id):
        if not kinopoisk_id:
            return {}
        return self.request('movie/%s' % kinopoisk_id, ttl=7 * 86400)

    def search(self, title, year='', media_type=''):
        if not title:
            return []
        params = {'query': str(title), 'limit': 10}
        data = self.request('movie/search', params, ttl=12 * 3600)
        rows = (data.get('docs') or []) if isinstance(data, dict) else []
        target_year = str(year or '').strip()
        if target_year.isdigit():
            same = [row for row in rows
                    if str(row.get('year') or '') == target_year]
            if same:
                rows = same
        if media_type in ('tv', 'tvshow', 'season', 'episode'):
            wanted = {'tv-series', 'mini-series', 'animated-series'}
        elif media_type == 'movie':
            wanted = {'movie', 'cartoon', 'anime'}
        else:
            wanted = None
        if wanted:
            filtered = [row for row in rows
                        if str(row.get('type') or '').lower() in wanted]
            if filtered:
                rows = filtered
        return rows


class Kinopoisk(object):
    """Small client for the API used by the attached UMS scrapers.

    It intentionally exposes raw responses; normalization and source priority
    are handled by Sublime's own metadata model.
    """
    root = 'https://kinopoiskapiunofficial.tech/api'

    def available(self):
        return config.use_kinopoisk()

    def request(self, path, params=None, ttl=None):
        if not self.available():
            return {}
        headers = {
            'X-API-KEY': config.kinopoisk_key(),
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }
        return get_json('%s/%s' % (self.root.rstrip('/'), str(path or '').lstrip('/')),
                        params=params or {}, headers=headers, ttl=ttl, provider='kinopoisk')

    def search(self, title, year='', media_type=''):
        if not title:
            return []
        params = {'keyword': title, 'page': 1}
        target_year = str(year or '').strip()
        if target_year.isdigit():
            params['yearFrom'] = target_year
            params['yearTo'] = target_year
        data = self.request('v2.2/films', params, ttl=12 * 3600)
        rows = (data.get('items') or []) if isinstance(data, dict) else []
        if not rows:
            legacy = self.request('v2.1/films/search-by-keyword', {'keyword': title, 'page': 1}, ttl=12 * 3600)
            rows = (legacy.get('films') or []) if isinstance(legacy, dict) else []
        allowed = None
        if media_type in ('tv', 'tvshow', 'season', 'episode'):
            allowed = {'TV_SERIES', 'MINI_SERIES', 'TV_SHOW'}
        elif media_type == 'movie':
            allowed = {'FILM', 'VIDEO'}
        if allowed:
            filtered = [row for row in rows if str(row.get('type') or '').upper() in allowed]
            if filtered:
                rows = filtered
        return rows

    def details(self, kinopoisk_id):
        return self.request('v2.2/films/%s' % kinopoisk_id, ttl=7 * 86400) if kinopoisk_id else {}

    def staff(self, kinopoisk_id):
        data = self.request('v1/staff', {'filmId': kinopoisk_id}, ttl=7 * 86400) if kinopoisk_id else {}
        return data if isinstance(data, list) else []

    def images(self, kinopoisk_id, image_types=None, first_nonempty=False):
        if not kinopoisk_id:
            return []
        output = []
        image_types = tuple(image_types or ('FAN_ART', 'WALLPAPER', 'COVER', 'STILL', 'SCREENSHOT', 'POSTER'))

        def fetch(image_type):
            data = self.request('v2.2/films/%s/images' % kinopoisk_id,
                                {'type': image_type, 'page': 1}, ttl=7 * 86400)
            rows = (data.get('items') or []) if isinstance(data, dict) else []
            result = []
            for row in rows:
                item = dict(row)
                item['_type'] = image_type
                result.append(item)
            return result

        # Missing-fanart fallback is deliberately sequential and stops at the
        # first useful category. A full gallery may still request all categories.
        if first_nonempty:
            for image_type in image_types:
                rows = fetch(image_type)
                if rows:
                    return rows
            return []

        with ThreadPoolExecutor(max_workers=min(4, max(1, len(image_types)))) as executor:
            futures = [executor.submit(fetch, image_type) for image_type in image_types]
            for future in as_completed(futures):
                try:
                    output.extend(future.result() or [])
                except Exception:
                    pass
        return output

    def videos(self, kinopoisk_id):
        return self.request('v2.2/films/%s/videos' % kinopoisk_id, ttl=24 * 3600) if kinopoisk_id else {}


class MDBList(object):
    root = 'https://api.mdblist.com'

    def details(self, media_type, tmdb_id='', imdb_id=''):
        if not config.use_mdblist():
            return {}
        media_type = 'show' if media_type in ('tv', 'tvshow', 'episode', 'season') else 'movie'
        if tmdb_id:
            path = '/tmdb/%s/%s' % (media_type, tmdb_id)
        elif imdb_id:
            path = '/imdb/%s/%s' % (media_type, imdb_id)
        else:
            return {}
        return get_json(self.root + path, params={'apikey': config.mdblist_key()}, ttl=24 * 3600, provider='mdblist')


    def list_items(self, list_id, limit=20, offset=0):
        if not config.use_mdblist() or not list_id:
            return {}
        params = {
            'apikey': config.mdblist_key(), 'limit': max(1, min(50, int(limit or 20))),
            'offset': max(0, int(offset or 0)), 'append_to_response': 'ratings',
        }
        data = get_json(self.root + '/lists/%s/items' % list_id, params=params, ttl=4 * 3600, provider='mdblist')
        return data if isinstance(data, dict) else {}


class Fanart(object):
    root = 'https://webservice.fanart.tv/v3'

    def details(self, media_type, tmdb_id='', tvdb_id=''):
        if not config.use_fanart():
            return {}
        params = {'api_key': config.fanart_key()}
        if config.fanart_client_key():
            params['client_key'] = config.fanart_client_key()
        if media_type in ('tv', 'tvshow', 'episode', 'season'):
            if not tvdb_id:
                return {}
            path = '/tv/%s' % tvdb_id
        else:
            if not tmdb_id:
                return {}
            path = '/movies/%s' % tmdb_id
        return get_json(self.root + path, params=params, ttl=7 * 86400, provider='fanart')


tmdb = TMDb()
omdb = OMDb()
kinopoisk = Kinopoisk()
kinopoisk_dev = KinopoiskDev()
mdblist = MDBList()
fanart = Fanart()
