import sys
from urllib import parse


def build_uri(mode, **params):
    uri = {'mode': mode}
    for key, value in params.items():
        if not value:
            continue
        uri[key] = value
    # sys.argv, а не копия при импорте: при reuselanguageinvoker Kodi даёт новый список (21.11.2026)
    return sys.argv[0] + '?' + parse.urlencode(uri)


def parse_uri(src):
    return dict(parse.parse_qsl(parse.urlsplit(src).query))


def normalize_uri(item):
    return parse.urlsplit(item).path
