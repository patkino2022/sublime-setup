# -*- coding: utf-8 -*-
"""HTTPS-контекст скина, переживающий испорченное хранилище сертификатов системы.

Один на все модули скина (sublime_helper.api, лента и полосы YouTube): на Windows один
испорченный сертификат в хранилище системы роняет ssl.create_default_context(), и без этого
Python в Kodi не открывал ни одного https-адреса - полосы YouTube были пусты (23.11.2026).
install() делает этот контекст контекстом urllib по умолчанию - только когда обычный не строится.
"""
from __future__ import absolute_import, unicode_literals

import os
import ssl
import sys

import xbmc

LOG_PREFIX = '[sublime metadata]'
_STATE = {}


def _candidate_ca_files():
    """Known-good CA bundles, if any are importable in this Kodi Python env."""
    paths = []
    # набор сертификатов самого Kodi (рядом с kodi.exe; на Android - внутри apk, тогда его нет)
    paths.append(os.path.join(os.path.dirname(sys.executable or ''), 'system', 'certs', 'cacert.pem'))
    try:
        import certifi
        paths.append(certifi.where())
    except Exception:
        pass
    try:
        from requests.utils import DEFAULT_CA_BUNDLE_PATH
        paths.append(DEFAULT_CA_BUNDLE_PATH)
    except Exception:
        pass
    return [p for p in paths if p]


def _build_ssl_context():
    """Build an HTTPS verification context that survives a broken OS trust store.

    The normal platform default is tried first, so on healthy systems
    (e.g. CoreELEC) behaviour is byte-for-byte unchanged. The fallback only
    engages when create_default_context() itself raises -- which happens on
    Windows when a single malformed certificate in the system trust store makes
    load_default_certs() throw "[X509] nested asn1 error" and would otherwise
    poison every HTTPS request. In that case we (1) use an explicit good CA
    bundle if one is importable, else (2) load the Windows store cert-by-cert,
    skipping only the malformed entries. The function never raises.
    """
    try:
        return ssl.create_default_context()
    except Exception:
        _STATE['fallback'] = True
    try:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.check_hostname = True
        context.verify_mode = ssl.CERT_REQUIRED
    except Exception:
        return None
    for ca_file in _candidate_ca_files():
        if not os.path.isfile(ca_file):
            continue
        try:
            context.load_verify_locations(cafile=ca_file)
            return context
        except Exception:
            continue
    enum_certificates = getattr(ssl, 'enum_certificates', None)
    if enum_certificates is not None:
        loaded = 0
        for store_name in ('ROOT', 'CA'):
            try:
                for cert_bytes, encoding, _trust in enum_certificates(store_name):
                    if encoding != 'x509_asn':
                        continue
                    try:
                        context.load_verify_locations(
                            cadata=ssl.DER_cert_to_PEM_cert(cert_bytes))
                        loaded += 1
                    except Exception:
                        # Skip the malformed cert that breaks load_default_certs().
                        continue
            except Exception:
                continue
        try:
            xbmc.log('%s ssl context: hardened build, trusted_roots=%d' % (LOG_PREFIX, loaded), xbmc.LOGINFO)
        except Exception:
            pass
    return context



def context():
    if 'ctx' not in _STATE:
        _STATE['ctx'] = _build_ssl_context()
    return _STATE['ctx']


def install():
    """urllib без явного контекста - этот, но только если обычный не строится (испорченное
    хранилище): на исправных системах (CoreELEC) ничего не меняется."""
    ctx = context()
    if _STATE.get('fallback') and ctx is not None:
        ssl._create_default_https_context = lambda *a, **k: ctx
