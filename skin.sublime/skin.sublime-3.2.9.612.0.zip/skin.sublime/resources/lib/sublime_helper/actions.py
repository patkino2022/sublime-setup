# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import os
import time
import json
from urllib.parse import urlencode

import xbmc
import xbmcgui
import xbmcaddon
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

from . import cache, config
from .hubs import (
    DEFAULT_HUB_ID, HUB_CONFIGURATION_MARKER, REAL_HUB_IDS, adjacent_enabled_hub,
    enabled_hub_ids, hub_from_window_id, select_enabled_hub, valid_hub_id,
)
from .core import (
    builtin_escape, clear_runtime_metadata_cache, get_details, get_first_youtube_video,
    home_window, jsonrpc, read_label, resolve_identity, safe_int, set_prop,
)

MYLIST_TAG = 'mylist'

# Single shared Monitor for short-lived action waits. Reusing one instance avoids
# repeatedly constructing/destroying native xbmc.Monitor objects per action call
# (each script-entrypoint run otherwise leaves a Monitor for Kodi to clean up).
_MONITOR = xbmc.Monitor()


_TRAILER_SEARCH_TERMS = {
    'ru': ('официальный трейлер', 'трейлер'),
    'uk': ('офіційний трейлер', 'трейлер'),
    'en': ('official trailer', 'trailer'),
    'de': ('offizieller Trailer', 'Trailer'),
    'fr': ('bande-annonce officielle', 'bande-annonce'),
    'es': ('tráiler oficial', 'tráiler'),
    'it': ('trailer ufficiale', 'trailer'),
    'pt': ('trailer oficial', 'trailer'),
    'pl': ('oficjalny zwiastun', 'zwiastun'),
    'tr': ('resmi fragman', 'fragman'),
    'zh': ('官方预告片', '预告片'),
    'ja': ('公式予告編', '予告編'),
    'ko': ('공식 예고편', '예고편'),
}


def _trailer_search_queries(title):
    language = str(config.language() or '').replace('_', '-').split('-', 1)[0].lower()
    official, generic = _TRAILER_SEARCH_TERMS.get(language, _TRAILER_SEARCH_TERMS['en'])
    queries = ['%s %s' % (title, official)]
    if generic != official:
        queries.append('%s %s' % (title, generic))
    if language != 'en':
        queries.append('%s official trailer' % title)
    return queries


_API_KEY_SETTINGS = {
    'api.tmdb_key': ('SublimeHelper.Api.TMDbKey', 31822),
    'api.tmdb_token': ('SublimeHelper.Api.TMDbToken', 31823),
    'api.fanart_key': ('SublimeHelper.Api.FanartKey', 31825),
    'api.fanart_client_key': ('SublimeHelper.Api.FanartClientKey', 31826),
    'api.omdb_key': ('SublimeHelper.Api.OMDbKey', 31828),
    'api.kinopoisk_key': ('SublimeHelper.Api.KinopoiskKey', 31859),
    'api.kinopoisk_dev_key': ('SublimeHelper.Api.KinopoiskDevKey', 31889),
    'api.mdblist_key': ('SublimeHelper.Api.MDBListKey', 31830),
}


def _set_skin_string(key, value):
    value = str(value or '')
    if value:
        xbmc.executebuiltin('Skin.SetString(%s,%s)' % (key, builtin_escape(value)))
    else:
        xbmc.executebuiltin('Skin.Reset(%s)' % key)


def set_api_key(params):
    setting_id = str(params.get('set_api_key') or '').strip()
    setting_def = _API_KEY_SETTINGS.get(setting_id)
    if not setting_def:
        return
    skin_key, label_id = setting_def
    addon = xbmcaddon.Addon('skin.sublime')
    heading = addon.getLocalizedString(label_id) or setting_id
    current = read_label('Skin.String(%s)' % skin_key) or ''
    input_type = getattr(xbmcgui, 'INPUT_ALPHANUM', 0)
    hide_opt = getattr(xbmcgui, 'ALPHANUM_HIDE_INPUT', 1)
    value = xbmcgui.Dialog().input(heading, defaultt=current, type=input_type, option=hide_opt)
    _set_skin_string(skin_key, value)
    cache.clear()
    marker = 'SublimeHelper.ApiConfigured.%s' % setting_id.replace('.', '_')
    if value:
        xbmc.executebuiltin('Skin.SetBool(%s)' % marker)
    else:
        xbmc.executebuiltin('Skin.Reset(%s)' % marker)
    set_prop('SublimeHelper.SettingsChanged', setting_id)


def select_setting(params):
    setting_id = str(params.get('select_setting') or '').strip()
    definitions = {
        'metadata.language': (
            'SublimeHelper.MetadataLanguage', 31802,
            ['', 'ru-RU', 'en-US', 'en-GB', 'uk-UA', 'de-DE', 'fr-FR', 'es-ES', 'it-IT', 'pt-BR', 'pt-PT', 'pl-PL', 'tr-TR', 'zh-CN', 'ja-JP', 'ko-KR'],
        ),
        'metadata.region': (
            'SublimeHelper.MetadataRegion', 31803,
            ['', 'RU', 'US', 'GB', 'UA', 'DE', 'FR', 'ES', 'IT', 'BR', 'PT', 'PL', 'TR', 'CA', 'AU', 'JP', 'KR', 'CN'],
        ),
        'metadata.primary_source': (
            'SublimeHelper.MetadataPrimarySource', 31870,
            ['', 'tmdb', 'kinopoisk', 'imdb'], [31863, 31864, 31865, 31866],
        ),
        'metadata.priority.tmdb': (
            'SublimeHelper.MetadataPriorityTMDb', 31873,
            ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
            ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
        ),
        'metadata.priority.kinopoisk': (
            'SublimeHelper.MetadataPriorityKinopoisk', 31874,
            ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
            ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
        ),
        'metadata.priority.imdb': (
            'SublimeHelper.MetadataPriorityIMDb', 31875,
            ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
            ['1', '2', '3', '4', '5', '6', '7', '8', '9'],
        ),
        'metadata.artwork_source': (
            'SublimeHelper.ArtworkPrimarySource', 31871,
            ['', 'fanart', 'tmdb', 'kinopoisk', 'imdb'], [31863, 31867, 31864, 31865, 31866],
        ),
        'metadata.rating_source': (
            'SublimeHelper.RatingPrimarySource', 31872,
            ['', 'kinopoisk', 'imdb', 'tmdb'], [31863, 31865, 31866, 31864],
        ),
    }
    row = definitions.get(setting_id)
    if not row:
        return
    skin_key, label_id, values = row[:3]
    addon = xbmcaddon.Addon('skin.sublime')
    heading = addon.getLocalizedString(label_id) or setting_id
    if len(row) > 3:
        labels = [(addon.getLocalizedString(label) or str(value)) if isinstance(label, int) else str(label) for label, value in zip(row[3], values)]
    else:
        automatic = addon.getLocalizedString(31847) or 'Kodi'
        labels = [automatic] + values[1:]
    current = read_label('Skin.String(%s)' % skin_key) or ''
    if not current and setting_id.startswith('metadata.priority.'):
        current = str(config.metadata_priority(setting_id.rsplit('.', 1)[-1]))
    try:
        preselect = values.index(current)
    except ValueError:
        preselect = 0
    selected = xbmcgui.Dialog().select(heading, labels, preselect=preselect)
    if selected < 0:
        return
    _set_skin_string(skin_key, values[selected])
    cache.clear()
    set_prop('SublimeHelper.SettingsChanged', setting_id)


def _identity(params):
    dbid, dbtype = resolve_identity(params)
    return dbid, dbtype if dbtype in ('movie','tvshow','episode') else ''


def ismylist(params):
    dbid, dbtype = _identity(params)
    if not dbid or not dbtype:
        return
    details = get_details(dbid, dbtype)
    set_prop('SublimeHelper.IsInMyList', dbid if MYLIST_TAG in (details.get('tag') or []) else '')


def togglemylist(params):
    dbid, dbtype = _identity(params)
    if not dbid or not dbtype:
        return
    details = get_details(dbid, dbtype)
    tags = list(details.get('tag') or [])
    if MYLIST_TAG in tags:
        tags.remove(MYLIST_TAG)
        set_prop('SublimeHelper.IsInMyList', '')
    else:
        tags.append(MYLIST_TAG)
        set_prop('SublimeHelper.IsInMyList', dbid)
    method = {'movie':'VideoLibrary.SetMovieDetails','tvshow':'VideoLibrary.SetTVShowDetails','episode':'VideoLibrary.SetEpisodeDetails'}[dbtype]
    jsonrpc(method, {'%sid' % dbtype: dbid, 'tag': tags})


def ratetitle(params):
    dbid, dbtype = _identity(params)
    if not dbid or not dbtype:
        return
    action = str(params.get('rateaction') or '').lower()
    values = {'like': 10, 'dislike': 1, 'reset': 0}
    if action not in values:
        return
    method = {'movie':'VideoLibrary.SetMovieDetails','tvshow':'VideoLibrary.SetTVShowDetails','episode':'VideoLibrary.SetEpisodeDetails'}[dbtype]
    jsonrpc(method, {'%sid' % dbtype: dbid, 'userrating': values[action]})
    set_prop('SublimeHelper.RateTitle', dbid)
    set_prop('SublimeHelper.RateTitle.Action', action)


def gettvshowid(params):
    dbid = safe_int(params.get('dbid'))
    if not dbid:
        dbid, dbtype = resolve_identity(params)
        if dbtype != 'episode':
            return
    details = get_details(dbid, 'episode')
    set_prop(params.get('output') or 'ListItem.TVShowID', details.get('tvshowid') or '')


def _local_tvshow_trailer(item_path, folder_name):
    if not item_path or not xbmcvfs:
        return ''
    try:
        _, files = xbmcvfs.listdir(item_path)
    except Exception:
        return ''
    wanted = ((folder_name or '').lower() + '-trailer').strip('-')
    for filename in files:
        stem = os.path.splitext(filename)[0].lower()
        if stem.endswith('-trailer') and stem in ('tvshow-trailer', wanted):
            return os.path.join(item_path, filename)
    return ''


def _home_value(win, *names):
    for name in names:
        try:
            value = win.getProperty(name) or ''
        except Exception:
            value = ''
        if value and str(value).strip() not in ('0', 'None', 'null', '-'):
            return str(value).strip()
    return ''


def _trailer_context(params, win):
    data = dict(params or {})
    fallbacks = {
        'tmdb_id': ('VCL.ActionPopup.TMDB_ID', 'SublimeHelper.ListItem.Monitor.TMDb_ID', 'VCL.Widget.TMDB_ID', 'SublimeHelper.ListItem.TMDB_ID'),
        'tmdb_type': ('VCL.ActionPopup.TMDB_Type', 'SublimeHelper.ListItem.Monitor.TMDb_Type', 'VCL.Widget.TMDB_Type', 'SublimeHelper.ListItem.TMDB_Type'),
        'kinopoisk_id': ('VCL.ActionPopup.Kinopoisk_ID', 'VCL.Widget.Kinopoisk_ID', 'SublimeHelper.ListItem.Kinopoisk_ID'),
        'imdb_id': ('VCL.ActionPopup.IMDb_ID', 'VCL.Widget.IMDb_ID', 'SublimeHelper.ListItem.IMDb_ID'),
        'dbid': ('VCL.ActionPopup.DBID', 'SublimeHelper.ListItem.Monitor.DBID', 'VCL.Widget.DBID', 'SublimeHelper.ListItem.DBID'),
        'dbtype': ('VCL.ActionPopup.DBType', 'VCL.Widget.DBType', 'SublimeHelper.ListItem.DBType', 'SublimeHelper.ListItem.base_dbtype'),
        'season': ('SublimeHelper.ListItem.Monitor.Season', 'SublimeHelper.ListItem.Season'),
        'episode': ('SublimeHelper.ListItem.Monitor.Episode', 'SublimeHelper.ListItem.Episode'),
        'title': ('VCL.ActionPopup.Title', 'SublimeHelper.PendingTrailerTitle', 'VCL.Widget.Title', 'SublimeHelper.ListItem.Title', 'SublimeHelper.ListItem.base_title'),
        'trailer': ('VCL.ActionPopup.Trailer', 'SublimeHelper.PendingTrailer', 'SublimeHelper.ListItem.Trailer'),
        'fallback_trailer': ('VCL.ActionPopup.TrailerFallback', 'SublimeHelper.PendingTrailerFallback', 'SublimeHelper.ListItem.TrailerFallback', 'VCL.Widget.Trailer'),
        'trailer_candidates': ('VCL.ActionPopup.TrailerCandidates', 'SublimeHelper.PendingTrailerCandidates', 'SublimeHelper.ListItem.TrailerCandidates'),
    }
    for key, names in fallbacks.items():
        if data.get(key) in (None, '', '0'):
            value = _home_value(win, *names)
            if value:
                data[key] = value
    return data


def _decode_trailer_candidates(value):
    value = str(value or '').strip()
    if not value:
        return []
    try:
        rows = json.loads(value)
    except Exception:
        return []
    output = []
    for row in rows if isinstance(rows, list) else []:
        if isinstance(row, str):
            row = {'url': row}
        if not isinstance(row, dict):
            continue
        url = str(row.get('url') or '').strip()
        if not url or url in ('0', 'None', 'null', '-'):
            continue
        output.append({
            'url': url,
            'language': str(row.get('language') or ''),
            'source': str(row.get('source') or ''),
            'official': bool(row.get('official')),
        })
    return output


class _TrailerPlaybackProbe(xbmc.Player):
    """Capture Kodi Player lifecycle outcomes without inventing resolver reasons."""
    def __init__(self):
        super().__init__()
        self.started = False
        self.failed = False


def _trailer_failure_reason(probe):
    return 'playback_error' if getattr(probe, 'failed', False) else 'playback_timeout'

def _wait_for_video(timeout=18.0):
    deadline = time.monotonic() + max(0.5, float(timeout))
    monitor = _MONITOR
    while time.monotonic() < deadline:
        if xbmc.getCondVisibility('Player.HasVideo'):
            return True
        if not home_window().getProperty('TrailerPlaying'):
            return False
        if monitor.waitForAbort(0.10):
            return False
    return xbmc.getCondVisibility('Player.HasVideo')


def _clear_failed_trailer_properties(win, failed_url):
    failed_url = str(failed_url or '')
    if not failed_url:
        return
    for name in (
        'PlayTrailer',
        'VCL.ActionPopup.Trailer', 'VCL.ActionPopup.TrailerFallback',
        'SublimeHelper.PendingTrailer', 'SublimeHelper.PendingTrailerFallback',
        'SublimeHelper.ListItem.Trailer', 'SublimeHelper.ListItem.TrailerFallback',
        'VCL.Widget.Trailer',
    ):
        try:
            if str(win.getProperty(name) or '') == failed_url:
                win.clearProperty(name)
        except Exception:
            pass
    for name in (
            'VCL.ActionPopup.TrailerCandidates', 'SublimeHelper.PendingTrailerCandidates',
            'SublimeHelper.ListItem.TrailerCandidates'):
        try:
            rows = [row for row in _decode_trailer_candidates(win.getProperty(name))
                    if str(row.get('url') or '') != failed_url]
            if rows:
                win.setProperty(name, json.dumps(rows, ensure_ascii=False, separators=(',', ':')))
            else:
                win.clearProperty(name)
        except Exception:
            pass


def _next_action_focus(win):
    if (_home_value(win, 'VCL.ActionPopup.Trailer', 'SublimeHelper.ListItem.Trailer') or
            _home_value(win, 'VCL.ActionPopup.TrailerFallback', 'SublimeHelper.ListItem.TrailerFallback') or
            _home_value(win, 'VCL.ActionPopup.TrailerCandidates', 'SublimeHelper.ListItem.TrailerCandidates')):
        return 692
    for control_id, setting in (
        (693, 'VCL.ActionButtons.DisableDetails'),
        (694, 'VCL.ActionButtons.DisablePlot'),
        (695, 'VCL.ActionButtons.DisableCast'),
        (696, 'VCL.ActionButtons.DisableGallery'),
    ):
        if not xbmc.getCondVisibility('Skin.HasSetting(%s)' % setting):
            return control_id
    return 692


def _stop_late_trailer_start(timeout=5.0):
    """Stop an asynchronous YouTube start that arrives after a failed timeout."""
    deadline = time.monotonic() + max(0.0, float(timeout))
    monitor = _MONITOR
    while time.monotonic() < deadline:
        if xbmc.getCondVisibility('Player.HasVideo'):
            xbmc.executebuiltin('PlayerControl(Stop)')
            return True
        if monitor.waitForAbort(0.10):
            return False
    return False


def _clear_widget_keepalive(win):
    for name in ('VCL.Widget.KeepAliveActive', 'VCL.Widget.KeepAliveHub', 'VCL.Widget.KeepAliveRow'):
        win.clearProperty(name)


def _arm_widget_keepalive(win):
    """Keep only the currently focused source row mounted during trailer playback."""
    hub_id = hub_from_window_id(xbmcgui.getCurrentWindowId())
    if not hub_id:
        hub_id = valid_hub_id(
            win.getProperty('Sublime.LastHub') or read_label('Skin.String(Sublime.LastHub)'),
            DEFAULT_HUB_ID)
    row_id = safe_int(win.getProperty('VCL.ActionButtonsFocusedWidget'))
    if hub_id in REAL_HUB_IDS and 501 <= row_id <= 550:
        win.setProperty('VCL.Widget.KeepAliveHub', hub_id)
        win.setProperty('VCL.Widget.KeepAliveRow', str(row_id))
        win.setProperty('VCL.Widget.KeepAliveActive', 'true')
        return True
    _clear_widget_keepalive(win)
    return False


def playtrailer(params):
    win = home_window()
    if win.getProperty('traileractionbusy'):
        return
    win.setProperty('traileractionbusy', 'true')
    win.setProperty('VCL.ActionButtonsPreserve', 'true')
    win.setProperty('VCL.ActionButtonsVisible', 'true')
    win.setProperty('VCL.ActionButtonsStableLoaded', 'true')
    if not win.getProperty('VCL.ActionButtonsRestoreFocus'):
        win.setProperty('VCL.ActionButtonsRestoreFocus', '692')
    dialog_opened = False
    playback_started = False
    try:
        context = _trailer_context(params, win)
        title = context.get('title') or read_label('ListItem.Title') or ''
        mode = str(context.get('playtrailer') or context.get('mode') or 'windowed').replace('auto_', '')
        allow_local = str(context.get('local') or '').lower() == 'true'
        allow_local_tv = str(context.get('tvshow') or '').lower() == 'true'
        trailer = str(context.get('trailer') or '').strip()
        fallback_trailer = str(context.get('fallback_trailer') or '').strip()
        serialized_candidates = context.get('trailer_candidates') or ''
        if trailer in ('0', 'None', 'null', '-'):
            trailer = ''
        if fallback_trailer in ('0', 'None', 'null', '-'):
            fallback_trailer = ''
        if not trailer and allow_local and allow_local_tv:
            trailer = _local_tvshow_trailer(
                read_label('ListItem.Path') or win.getProperty('VCL.Widget.FolderPath'),
                read_label('ListItem.FolderName') or title,
            )

        candidates = []
        seen = set()

        def add_candidate(kind, url):
            url = str(url or '').strip()
            if not url or url in ('0', 'None', 'null', '-') or url in seen:
                return
            if cache.is_trailer_failed(url):
                _clear_failed_trailer_properties(win, url)
                return
            seen.add(url)
            candidates.append((str(kind or 'resolved'), url))

        add_candidate('preferred', trailer)
        add_candidate('fallback', fallback_trailer)
        for row in _decode_trailer_candidates(serialized_candidates):
            add_candidate('%s:%s' % (row.get('source') or 'resolved', row.get('language') or 'neutral'), row.get('url'))

        tmdb_id = safe_int(context.get('tmdb_id'))
        tmdb_type = context.get('tmdb_type') or ''
        query = {'info': 'videos', 'tmdb_type': tmdb_type, 'tmdb_id': tmdb_id}
        season = context.get('season')
        episode = context.get('episode')
        if season not in (None, '', 0, '0'):
            query['season'] = season
        if episode not in (None, '', 0, '0'):
            query['episode'] = episode
        pending_items = _home_value(win, 'SublimeHelper.PendingTrailerItems')
        if pending_items:
            win.setProperty('PlayTrailerItems', pending_items)
        elif tmdb_id and tmdb_type:
            win.setProperty('PlayTrailerItems', 'plugin://skin.sublime/?%s' % urlencode(query))
        else:
            win.setProperty('PlayTrailerItems', '-')
        win.setProperty('PlayTrailerTitle', str(title or ''))

        # If metadata has no resolved URL, perform the localized search before
        # opening the dialog. Custom_1123 closes itself when PlayTrailer is empty.
        if not candidates and title:
            for search_query in _trailer_search_queries(title):
                search_url = get_first_youtube_video(search_query, limit=5)
                add_candidate('youtube_search', search_url)
                if candidates:
                    break
        if not candidates:
            xbmc.log('[sublime trailer] no usable resolved url: type=%s id=%s title=%s' % (
                tmdb_type, tmdb_id, title), xbmc.LOGWARNING)
            xbmcgui.Dialog().notification(
                'Sublime', xbmcaddon.Addon('skin.sublime').getLocalizedString(31857),
                xbmcgui.NOTIFICATION_INFO, 2500)
            win.setProperty('VCL.ActionButtonsRestoreFocus', str(_next_action_focus(win)))
            restore_action_focus({'restore_action_focus': win.getProperty('VCL.ActionButtonsRestoreFocus') or '692'})
            return

        # The first URL must exist before ActivateWindow(1123), otherwise the
        # dialog's own onload guard immediately closes it (the 704 regression).
        win.setProperty('PlayTrailer', candidates[0][1])
        win.setProperty('TrailerPlaying', 'loading')
        _arm_widget_keepalive(win)
        xbmc.executebuiltin('ActivateWindow(1123)')
        for _ in range(25):
            if xbmc.getCondVisibility('Window.IsVisible(1123) | Window.IsVisible(11123)'):
                dialog_opened = True
                break
            if not win.getProperty('TrailerPlaying'):
                break
            xbmc.sleep(100)
        if not dialog_opened:
            win.clearProperty('TrailerPlaying')
            win.clearProperty('PlayTrailer')
            xbmc.log('[sublime trailer] dialog failed to open: type=%s id=%s first_url=%s' % (
                tmdb_type, tmdb_id, 'yes' if candidates else 'no'), xbmc.LOGWARNING)
            restore_action_focus({'restore_action_focus': win.getProperty('VCL.ActionButtonsRestoreFocus') or '692'})
            return

        attempted = 0
        search_expanded = False
        user_cancelled = False
        while attempted < 4:
            if not candidates and not search_expanded and title:
                search_expanded = True
                for search_query in _trailer_search_queries(title):
                    search_url = get_first_youtube_video(search_query, limit=5)
                    add_candidate('youtube_search', search_url)
            if not candidates:
                break
            if not win.getProperty('TrailerPlaying'):
                user_cancelled = True
                break

            selected_kind, selected_url = candidates.pop(0)
            attempted += 1
            win.setProperty('PlayTrailer', selected_url)
            win.setProperty('TrailerPlaying', 'loading')
            xbmc.log('[sublime trailer] start: type=%s id=%s kind=%s attempt=%s' % (
                tmdb_type, tmdb_id, selected_kind, attempted), xbmc.LOGINFO)
            playback_probe = _TrailerPlaybackProbe()
            xbmc.executebuiltin('PlayMedia(%s,False,1)' % builtin_escape(selected_url))
            if _wait_for_video(18.0 if attempted == 1 else 14.0):
                cache.clear_trailer_failure(selected_url)
                win.setProperty('TrailerPlaying', mode)
                playback_started = True
                xbmc.log('[sublime trailer] playback started kind=%s attempt=%s' % (
                    selected_kind, attempted), xbmc.LOGINFO)
                return

            user_cancelled = not bool(win.getProperty('TrailerPlaying'))
            if user_cancelled:
                break
            cache.mark_trailer_failed(selected_url, _trailer_failure_reason(playback_probe))
            _clear_failed_trailer_properties(win, selected_url)
            xbmc.log('[sublime trailer] candidate unavailable: type=%s id=%s kind=%s attempt=%s title=%s' % (
                tmdb_type, tmdb_id, selected_kind, attempted, title), xbmc.LOGWARNING)
            if xbmc.getCondVisibility('Player.HasVideo'):
                xbmc.executebuiltin('PlayerControl(Stop)')
            _stop_late_trailer_start(3.0)
            if win.getProperty('TrailerPlaying'):
                win.setProperty('TrailerPlaying', 'loading')

        if xbmc.getCondVisibility('Player.HasVideo'):
            xbmc.executebuiltin('PlayerControl(Stop)')
        if xbmc.getCondVisibility('Window.IsVisible(1123) | Window.IsVisible(11123)'):
            xbmc.executebuiltin('Dialog.Close(1123,true)')
        win.clearProperty('TrailerPlaying')
        win.clearProperty('PlayTrailer')
        win.setProperty('VCL.ActionButtonsRestoreFocus', str(_next_action_focus(win)))
        xbmc.log('[sublime trailer] playback unavailable: type=%s id=%s attempts=%s title=%s' % (
            tmdb_type, tmdb_id, attempted, title), xbmc.LOGWARNING)
        if not user_cancelled:
            xbmcgui.Dialog().notification(
                'Sublime', xbmcaddon.Addon('skin.sublime').getLocalizedString(31857),
                xbmcgui.NOTIFICATION_INFO, 2500)
        restore_action_focus({'restore_action_focus': win.getProperty('VCL.ActionButtonsRestoreFocus') or '692'})
    finally:
        for prop in (
                'SublimeHelper.PendingTrailer', 'SublimeHelper.PendingTrailerFallback',
                'SublimeHelper.PendingTrailerCandidates', 'SublimeHelper.PendingTrailerTitle',
                'SublimeHelper.PendingTrailerItems'):
            win.clearProperty(prop)
        if not playback_started:
            win.clearProperty('VCL.ActionButtonsPreserve')
            _clear_widget_keepalive(win)
        win.clearProperty('traileractionbusy')

def blur_image(params):
    source = params.get('blur_image') or params.get('source') or ''
    prefix = params.get('prefix') or 'SimpleBackground'
    if source:
        set_prop('SublimeHelper.%s.BlurImage' % prefix, source)
        set_prop('SublimeHelper.%s.BlurImage.Original' % prefix, source)
        set_prop('SublimeHelper.Blur.SourceImage', source)


def clear_metadata_cache(params):
    count = cache.clear()
    clear_runtime_metadata_cache()
    xbmcgui.Dialog().notification('Sublime', xbmc.getLocalizedString(31879) % count, xbmcgui.NOTIFICATION_INFO, 2500)


def restart_service(params):
    clear_metadata_cache(params)
    set_prop('SublimeHelper.RestartRequested', 'true')


def close_dialog(params):
    dialog_id = params.get('close_dialog')
    if dialog_id:
        xbmc.executebuiltin('Dialog.Close(%s)' % dialog_id)


def playmedia(params):
    path = params.get('playmedia') or params.get('call_path')
    if path:
        xbmc.executebuiltin('PlayMedia(%s)' % builtin_escape(path))


def call_update(params):
    path = params.get('call_update')
    if path:
        xbmc.executebuiltin('Container.Update(%s)' % builtin_escape(path))


def restore_action_focus(params):
    control_id = safe_int(params.get('restore_action_focus')) or 692
    win = home_window()
    win.setProperty('VCL.ActionButtonsVisible', 'true')
    win.setProperty('VCL.ActionButtonsStableLoaded', 'true')
    # Wait until the hub is the active window again. Setting focus while the
    # trailer dialog is still unloading is ignored by Kodi and leaves no focus.
    for _ in range(40):
        if xbmc.getCondVisibility(
                'Window.IsVisible(1100) | Window.IsVisible(1101) | Window.IsVisible(1102) | '
                'Window.IsVisible(1103) | Window.IsVisible(1104) | Window.IsVisible(1105) | '
                'Window.IsVisible(1106) | Window.IsVisible(1107) | Window.IsVisible(1108) | '
                'Window.IsVisible(1109) | Window.IsVisible(11100) | Window.IsVisible(11101) | '
                'Window.IsVisible(11102) | Window.IsVisible(11103) | Window.IsVisible(11104) | '
                'Window.IsVisible(11105) | Window.IsVisible(11106) | Window.IsVisible(11107) | '
                'Window.IsVisible(11108) | Window.IsVisible(11109)'):
            win.setProperty('VCL.ActionButtonsVisible', 'true')
            win.setProperty('VCL.ActionButtonsStableLoaded', 'true')
            xbmc.executebuiltin('SetFocus(%s)' % control_id)
            xbmc.sleep(100)
            if xbmc.getCondVisibility('Control.HasFocus(%s)' % control_id):
                break
        else:
            xbmc.sleep(100)
    win.clearProperty('TrailerPlaying')
    win.clearProperty('VCL.ActionButtonsPreserve')


def hide_context_information(params):
    """Скрыть штатные пункты контекстного меню - реализация в vcl_context_hide.

    DialogContextMenu.xml запускает тот лёгкий скрипт напрямую; здесь вход для
    старого действия action=hide_context_information.
    """
    from resources.lib import vcl_context_hide
    try:
        vcl_context_hide.hide()
    finally:
        xbmcgui.Window(10000).setProperty(vcl_context_hide.READY_PROPERTY, 'true')


def _hub_configuration_exists():
    try:
        return bool(xbmc.getCondVisibility('Skin.HasSetting(%s)' % HUB_CONFIGURATION_MARKER))
    except Exception:
        return False


def _saved_hub_id():
    win = home_window()
    return valid_hub_id(
        win.getProperty('Sublime.LastHub') or read_label('Skin.String(Sublime.LastHub)'))


def _store_last_hub(hub_id):
    hub_id = valid_hub_id(hub_id)
    if not hub_id:
        return
    win = home_window()
    if str(win.getProperty('Sublime.LastHub') or '') != hub_id:
        win.setProperty('Sublime.LastHub', hub_id)
    if str(read_label('Skin.String(Sublime.LastHub)') or '') != hub_id:
        xbmc.executebuiltin('Skin.SetString(Sublime.LastHub,%s)' % hub_id)


def _activate_peer_hub(hub_id, replace=False, focus=0):
    hub_id = valid_hub_id(hub_id)
    if not hub_id:
        xbmc.log('[sublime hubs] no enabled peer hub to activate', xbmc.LOGWARNING)
        return False
    win = home_window()
    current = valid_hub_id(hub_from_window_id(xbmcgui.getCurrentWindowId()))
    now_ms = int(time.monotonic() * 1000)
    try:
        last_target = valid_hub_id(win.getProperty('Sublime.HubNav.Target'))
        last_source = valid_hub_id(win.getProperty('Sublime.HubNav.Source'))
        last_at = int(win.getProperty('Sublime.HubNav.At') or 0)
    except Exception:
        last_target, last_source, last_at = '', '', 0
    try:
        target_visible = bool(xbmc.getCondVisibility(
            'Window.IsVisible(%s) | Window.IsVisible(%s)' %
            (hub_id, int(hub_id) + 10000)))
    except Exception:
        target_visible = False
    # XML animations/key repeat can submit the same transition more than once.
    # A peer hub can also remain visible underneath a modal router dialog. In
    # either case, never activate/replace that same hub again: doing so rebuilds
    # its plugin containers and looks like an unsolicited widget refresh.
    if current == hub_id or target_visible or (
            last_target == hub_id and last_source == current and 0 <= now_ms - last_at < 450):
        _store_last_hub(hub_id)
        if focus and (current == hub_id or target_visible):
            xbmc.executebuiltin(
                'RunScript(skin.sublime,focus_control=%s,expected_window=%s,wait_ms=250)'
                % (int(focus), hub_id))
        return True
    win.setProperty('Sublime.HubNav.Target', hub_id)
    win.setProperty('Sublime.HubNav.Source', current or '')
    win.setProperty('Sublime.HubNav.At', str(now_ms))
    _store_last_hub(hub_id)
    builtin = 'ReplaceWindow' if replace else 'ActivateWindow'
    xbmc.executebuiltin('%s(%s)' % (builtin, hub_id))
    if focus:
        alarm_name = 'SublimeHubFocus%s_%s_%s' % (
            hub_id, int(focus), now_ms)
        xbmc.executebuiltin(
            'AlarmClock(%s,RunScript(skin.sublime,focus_control=%s,expected_window=%s,wait_ms=250),00:01,silent)'
            % (alarm_name, int(focus), hub_id))
    return True


def activate_last_hub(params):
    enabled = enabled_hub_ids()
    configured = _hub_configuration_exists() or bool(enabled)
    hub_id = select_enabled_hub(_saved_hub_id(), enabled, configured)
    return _activate_peer_hub(
        hub_id,
        replace=str(params.get('replace') or '').lower() in ('1', 'true', 'yes'),
        focus=safe_int(params.get('focus')),
    )


def activate_hub_action(params):
    hub_id = valid_hub_id(params.get('activate_hub') or params.get('hub'))
    enabled = enabled_hub_ids()
    if hub_id not in enabled:
        hub_id = select_enabled_hub(hub_id, enabled, _hub_configuration_exists() or bool(enabled))
    return _activate_peer_hub(hub_id, replace=True, focus=safe_int(params.get('focus')))


def activate_adjacent_hub_action(params):
    current = valid_hub_id(
        params.get('current') or hub_from_window_id(xbmcgui.getCurrentWindowId()) or _saved_hub_id())
    direction = params.get('activate_adjacent_hub') or params.get('direction') or 'previous'
    hub_id = adjacent_enabled_hub(current, direction, enabled_hub_ids())
    return _activate_peer_hub(hub_id, replace=True, focus=safe_int(params.get('focus')))


def noop(params):
    return


ACTIONS = {
    'ismylist': ismylist, 'togglemylist': togglemylist, 'ratetitle': ratetitle,
    'gettvshowid': gettvshowid, 'playtrailer': playtrailer, 'blur_image': blur_image,
    'restart_service': restart_service, 'clear_metadata_cache': clear_metadata_cache,
    'close_dialog': close_dialog,
    'call_path': playmedia,
    'playmedia': playmedia, 'call_update': call_update, 'add_path': noop, 'call_auto': noop,
    'set_api_key': set_api_key, 'select_setting': select_setting,
    'restore_action_focus': restore_action_focus,
    'hide_context_information': hide_context_information,
    'activate_last_hub': activate_last_hub,
    'activate_hub': activate_hub_action,
    'activate_adjacent_hub': activate_adjacent_hub_action,
}

# Дополнения, которые есть не в каждой сборке скина (home_extras.py).
try:
    from . import home_extras as _extras
    ACTIONS.update(_extras.ACTIONS)
except ImportError:
    pass


def run(params):
    action = params.get('action') or ''
    if action in ACTIONS:
        return ACTIONS[action](params)
    for name, callback in ACTIONS.items():
        if name in params:
            return callback(params)
    return False
