# -*- coding: utf-8 -*-


#siteUrl = 'open-tor.org'
#httpSiteUrl = 'http://' + siteUrl
import os, sys, time
import uscode

import xbmc, xbmcgui, xbmcplugin, xbmcaddon
__settings__ = xbmcaddon.Addon(id='plugin.video.RuTor')
siteUrl = __settings__.getSetting('Url')
if siteUrl == "": siteUrl = 'rutor.info'
httpSiteUrl = 'http://' + siteUrl
if __settings__.getSetting('Protokol')=='1': httpSiteUrl = 'https://' + siteUrl

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

def b2s(s):
	if sys.version_info.major > 2:
		try:s=s.decode('utf-8')
		except: pass
		try:s=s.decode('windows-1251')
		except: pass
		return s
	else:
		return s

def win(t):
	return t.decode('utf-8').encode('windows-1251')

def lower(s):
	if sys.version_info.major > 2: return s.lower()
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def CRC32(buf):
		import binascii
		if sys.version_info.major > 2: buf = (binascii.crc32(buf.encode('utf-8')) & 0xFFFFFFFF)
		else: buf = (binascii.crc32(buf) & 0xFFFFFFFF)
		r=str("%08X" % buf)
		return r

def GET(target, referer='', post=None):
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 1.1.4322; .NET CLR 2.0.50727; .NET CLR 3.0.4506.2152; .NET CLR 3.5.30729; .NET4.0C)')
		# сайт изредка не отвечает вовремя: один повтор, затем - пусто, а не падение
		# всего поиска с окном ошибки (.20, 17.11.2026: TimeoutError в поиске скина)
		for attempt in (1, 2):
			try:
				resp = urllib2.urlopen(req, timeout=12)
				http = resp.read()
				resp.close()
				break
			except Exception as e:
				print('GET %s: %s' % (target, e))
				if attempt == 2: return ''
		http = b2s(http)
		
		return http

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es, s)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def rt(x):
	x = uscode.decode(x)
	L=[('&quot;','”'),('&#39;','’'), ('&#145;','‘'), ('&#146;','’'), ('&#147;','“'), ('&#148;','”'), ('&#149;','•'), ('&#150;','–'), ('&#151;','—'), ('&#152;','?'), ('&#153;','™'), ('&#154;','s'), ('&#155;','›'), ('&#156;','?'), ('&#157;',''), ('&#158;','z'), ('&#159;','Y'), ('&#160;',''), ('&#161;','?'), ('&#162;','?'), ('&#163;','?'), ('&#164;','¤'), ('&#165;','?'), ('&#166;','¦'), ('&#167;','§'), ('&#168;','?'), ('&#169;','©'), ('&#170;','?'), ('&#171;','«'), ('&#172;','¬'), ('&#173;',''), ('&#174;','®'), ('&#175;','?'), ('&#176;','°'), ('&#177;','±'), ('&#178;','?'), ('&#179;','?'), ('&#180;','?'), ('&#181;','µ'), ('&#182;','¶'), ('&#183;','·'), ('&#184;','?'), ('&#185;','?'), ('&#186;','?'), ('&#187;','»'), ('&#188;','?'), ('&#189;','?'), ('&#190;','?'), ('&#191;','?'), ('&#192;','A'), ('&#193;','A'), ('&#194;','A'), ('&#195;','A'), ('&#196;','A'), ('&#197;','A'), ('&#198;','?'), ('&#199;','C'), ('&#200;','E'), ('&#201;','E'), ('&#202;','E'), ('&#203;','E'), ('&#204;','I'), ('&#205;','I'), ('&#206;','I'), ('&#207;','I'), ('&#208;','?'), ('&#209;','N'), ('&#210;','O'), ('&#211;','O'), ('&#212;','O'), ('&#213;','O'), ('&#214;','O'), ('&#215;','?'), ('&#216;','O'), ('&#217;','U'), ('&#218;','U'), ('&#219;','U'), ('&#220;','U'), ('&#221;','Y'), ('&#222;','?'), ('&#223;','?'), ('&#224;','a'), ('&#225;','a'), ('&#226;','a'), ('&#227;','a'), ('&#228;','a'), ('&#229;','a'), ('&#230;','?'), ('&#231;','c'), ('&#232;','e'), ('&#233;','e'), ('&#234;','e'), ('&#235;','e'), ('&#236;','i'), ('&#237;','i'), ('&#238;','i'), ('&#239;','i'), ('&#240;','?'), ('&#241;','n'), ('&#242;','o'), ('&#243;','o'), ('&#244;','o'), ('&#245;','o'), ('&#246;','o'), ('&#247;','?'), ('&#248;','o'), ('&#249;','u'), ('&#250;','u'), ('&#251;','u'), ('&#252;','u'), ('&#253;','y'), ('&#254;','?'), ('&#255;','y')]
	for i in L:
		x=x.replace(i[0], i[1])
	return x

def untag(html):
	import re
	p = re.compile(r'<.*?>')
	return p.sub('', html)

# Кэш разобранных страниц списка на 10 минут в addon_data: возврат назад и
# повторный заход в раздел не ходят на сайт заново (21.11.2026).
PAGE_TTL = 600

def _page_cache(url):
	try:
		import xbmcvfs
		folder = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.RuTor/pages/')
		if not os.path.isdir(folder): os.makedirs(folder)
		return folder, os.path.join(folder, CRC32(url)+'.json')
	except Exception:
		return '', ''

def _page_get(url):
	folder, path = _page_cache(url)
	try:
		if path and time.time() - os.path.getmtime(path) < PAGE_TTL:
			import json, io
			with io.open(path, encoding='utf-8') as f:
				data = json.load(f)
			if data.get('url') == url: return data.get('list')
	except Exception:
		pass
	return None

def _page_put(url, L):
	folder, path = _page_cache(url)
	if not path or not L: return  # пустой ответ (сайт не ответил) не кэшируем
	try:
		import json, io
		now = time.time()
		for name in os.listdir(folder):  # просроченные страницы - вон
			old = os.path.join(folder, name)
			try:
				if now - os.path.getmtime(old) >= PAGE_TTL: os.remove(old)
			except Exception: pass
		with io.open(path, 'w', encoding='utf-8') as f:
			f.write(json.dumps({'url': url, 'list': L}, ensure_ascii=False))
	except Exception:
		pass

def get_list(url):
	print ('get_list: '+url)
	cached = _page_get(url)
	if cached is not None: return cached
	L2 = _get_list(url)
	_page_put(url, L2)
	return L2

def _get_list(url):
	hp=GET(url)
	hp=hp.replace('class="gai"', 'class="tum"')
	L=mfindal(hp, 'class="tum"', '</span></td></tr>')
	L2=[]
	for i in L:
		if '/torrent/' in i:
			##print i
			id = mfind(i,'/torrent/','/')
			magnet = 'magnet:'+mfind(i,'magnet:','"><')
			ft = rt(mfind(mfind(i,'/torrent/','/a>'),'>','<').strip())
			size = mfind(i,'<td align="right">','</td><td align="center">').replace('&nbsp;', '').strip()
			if '"right">' in size: size=size[size.find('"right">')+8:]
			if 'MB' in size: size=size[:size.find('.')]+'MB'
			seeds = mfind(i,'alt="S" />','<').replace('&nbsp;', '').strip()
			if ' / ' in ft:
				ru = mfind(ft,'',' / ').strip()
				if ' [' in ft: en = mfind(ft,' / ',' [').strip()
				else:          en = mfind(ft,' / ',' (').strip()
				if ' / ' in en: en = mfind(ft,' / ',' / ').strip()
			else:
				if ' [' in ft: en = mfind(ft,'',' [').strip()
				else:          en = mfind(ft,'',' (').strip()
				ru = en
			
			
			year = mfind(i,' (',') ')
			
			##print '----'
			##print id
			##print ft
			##print ru
			##print en
			##print year
			##print size
			##print seeds
			
			L2.append ({'id':id, 'magnet': magnet, 'title': ru, 'originaltitle':en, 'year':year, 'size':size, 'seeds':seeds, 'fulltitle':ft})
	return L2

def get_kpid(t):
	# только цифры номера: ссылка без «/» на конце (kinopoisk.ru/film/5613466" target=...)
	# прежним поиском до '/"' захватывала хвост разметки в номер и в адрес обложки
	for pat in (r'kinopoisk\.ru/rating/(\d+)', r'kinopoisk\.ru/film/(\d+)', r'rating\.kinopoisk\.ru/(\d+)'):
		m = _re.search(pat, t)
		if m: return m.group(1)
	return ''

def search_kpid(t):
	if '>Связанные раздачи<' in t:
		t=t[t.find('>Связанные раздачи<'):]
		L=mfindal(t,'/download/','"><img src="/s/i/d')
		for i in L:
			id = i.replace('/download/')
			url=httpSiteUrl+'/torrent/'+id
			##print url
			hp=GET(url)
			kpid = get_kpid(hp)
			##print kpid
			if kpid!='': return kpid
	return ''

def get_info(info = {}):
	# Справочник td-soft.narod.ru (kpdb) убран 17.10.2026 - см. get_info_page.
	return get_info_page(info)

import re as _re
_LATIN = _re.compile(r'[A-Za-z()]')
_HMS = _re.compile(r'(\d{1,2}):(\d{2})(?::\d{2})?')
_MIN = _re.compile(r'(\d{2,3})\s*мин')

def get_imdbid(t):
	import re
	m = re.search(r'imdb\.com/title/(tt\d{5,10})', t or '')
	return m.group(1) if m else ''

def get_info_page(info = {}):
	"""Сведения о фильме - только со страницы раздачи rutor.

	Справочник td-soft.narod.ru (kpdb) убран 17.10.2026: он перестал
	обновляться в начале 2025 года (71 фильм за 2025-й, ни одного за 2026-й),
	для новинок ничего не находил и всё равно заканчивался этой страницей, а
	сам при этом качал 4.5 МБ и выполнял их eval-ом. Номер Кинопоиска и IMDb,
	описание, жанр, страна, год и длительность есть на странице раздачи;
	оценки, фоны и логотипы строке добавляет скин по этим номерам.
	"""
	id = info['id']
	hp = GET(httpSiteUrl+'/torrent/'+id)
	kp_id = get_kpid(hp)
	if kp_id:
		info['kp_id'] = kp_id
		info['cover'] = 'https://st.kp.yandex.net/images/film_iphone/iphone360_'+kp_id+".jpg"
	else:
		info['cover'] = get_cover(hp)
	imdb = get_imdbid(hp)
	if imdb: info['imdb'] = imdb
	utt=untag(hp)
	utt=utt.replace(chr(13),'')
	utt=utt.replace('О фильме:','Описание:')
	utt=utt.replace('Описание:'+chr(10),'Описание: ')
	lines = [l.strip() for l in utt.splitlines()]
	for n, i in enumerate(lines):
		if ':' not in i: continue
		label, _, value = i.partition(':')
		value = value.strip()
		if not value and ('Описание' in label or 'О фильме' in label or 'Сюжет' in label):
			# «Описание:» и текст строкой ниже («Оппенгеймер», замер 17.10.2026).
			value = next((x for x in lines[n+1:n+4] if x), '')
		if not value: continue
		if 'Год' in label and 'year' not in info: info['year'] = value
		if ('Описание' in label or 'Сюжет' in label) and not info.get('plot'): info['plot'] = rt(value)
		if 'Жанр' in label and not info.get('genre'): info['genre'] = value
		if 'Страна' in label and not info.get('studio'): info['studio'] = value
		if 'Производство' in label and not info.get('studio'):
			# «Великобритания, США, Home Box Office (HBO)» - только страны.
			countries = [x.strip() for x in value.split(',') if x.strip() and not _LATIN.search(x)]
			if countries: info['studio'] = ', '.join(countries)
		if 'Продолжительность' in label and not info.get('duration'):
			m = _HMS.search(value)
			if m: info['duration'] = str(int(m.group(1))*60 + int(m.group(2)))
			else:
				m = _MIN.search(value)
				if m: info['duration'] = m.group(1)
	return info

def get_cover(hp):
	hp=hp.replace(chr(13),'')
	hp=hp.replace(chr(10),'')
	hp=hp.replace('<img src="',chr(10)+'<img src="')
	hp=hp.replace('">','">'+chr(10))
	L=hp.splitlines()
	BL = ['banner', 'blacklist', 'logo', '.th.', '93eceee739dbbacca1e7d54ca254f6d8','2ff75c0c358795c5946784cc1680714d', 'rutor', 'cdnbunny', 'getapic.me']
	for i in L:
		#print (i)
		if '.jpg' in i and 'http' in i: 
			n=0
			for b in BL:
				if b in i: n+=1
			if n==0: return 'http'+mfind(i, 'http', '.jpg')+'.jpg'
		
		if '.jpeg' in i and 'http' in i: 
			n=0
			for b in BL:
				if b in i: n+=1
			if n==0: return 'http'+mfind(i, 'http', '.jpeg')+'.jpeg'
	
	#for i in L:
		#print (i)
		if '.png' in i and 'http' in i: 
			n=0
			for b in BL:
				if b in i: n+=1
			if n==0: return 'http'+mfind(i, 'http', '.png')+'.png'


def get_db_id(info):
	sid = lower(info['originaltitle']).replace('.','').replace(',','').replace(':','').replace('-','')+str(info['year'])
	return CRC32(sid)

def torrents(info):
	#print ('torrents: '+repr(info))
	try:
		id = info['id']
		url=httpSiteUrl+'/torrent/'+id
		hp=GET(url)
		#print hp
		if 'margin-bottom: -5px;"><a href="' in hp:
			url2=quote(mfind(hp,'margin-bottom: -5px;"><a href="', '"'))#.replace(' ', '%20')
			if 'http' not in url2: url2=httpSiteUrl+url2
			print (url2)
			return get_list(url2)
		else:
			return [info,]
	except:
		url=httpSiteUrl+'/search/'+quote(info['title'])#.replace(' ', '%20')
		print (url)
		return get_list(url)

def serch(t):
	url=httpSiteUrl+'/search/0/0/100/2/'+quote(t).replace(' ', '%20')
	return get_list(url)



#get_list('http://open-tor.org/browse/0/0/0/0')

#get_info('612444')
#get_info('608076')
#get_info('612451')

#torrents('612444')

#serch('terminator 2')
















