# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import contextlib
import copy
import hashlib
import json
import queue
import re
import sys
import threading
import time
import unicodedata
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from difflib import SequenceMatcher
from urllib.parse import quote, quote_plus

import xbmc
import xbmcgui
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

from . import cache, config
from .api import (cache_only_scope as api_cache_only, fanart, kinopoisk,
                  kinopoisk_dev, log, mdblist, omdb, provider_retry_at, tmdb)
from .title_logo import request_title_logo
from .model import (
    language_code, language_rank, trailer_rank,
    kinopoisk_dev_to_legacy,
    merge_fanart, merge_mdblist, merge_omdb,
    normalize_kinopoisk, normalize_omdb, normalize_tmdb, release_short, safe_float, safe_int, window_properties,
)

ADDON_ID = 'skin.sublime'
HOME_ID = 10000
# Kodi exposes custom XML windows through runtime ids 10000 higher than the
# logical XML/ActivateWindow id (for example 1102 -> 11102, 1127 -> 11127).
# xbmcgui.Window() must receive the runtime id; using the logical id writes a
# noisy "Window id does not exist" exception before Python can catch it.
_LOCAL_RUNTIME_WINDOW_IDS = tuple([HOME_ID] + list(range(11100, 11110)))
# Окна Kodi, где наши списки тоже показывают фон: «Видео» (10025) - это списки
# сериалов, сезонов и серий. Разметка там читает Window.Property(...), то есть
# свойства ТЕКУЩЕГО окна, а служба писала только в Home и хабовые окна.
# Проверено на .20 2026-08-29 в списке серий «Тед Лассо»: в Home лежал кадр
# серии «Бирд вне работы», а Window(10025) был пуст - и на экране стоял арт
# сериала, потому что переменная фона проваливалась в следующую ветку.
_MEDIA_RUNTIME_WINDOW_IDS = (10025,)


def _runtime_window_id(window_id):
    window_id = safe_int(window_id)
    if 1100 <= window_id <= 1199:
        return window_id + 10000
    return window_id


def _window_visible(window_id):
    logical = safe_int(window_id)
    runtime = _runtime_window_id(logical)
    ids = [runtime]
    if logical and logical != runtime:
        ids.append(logical)
    try:
        return any(xbmc.getCondVisibility('Window.IsVisible(%d)' % wid) for wid in ids if wid)
    except Exception:
        return False


def _visible_local_windows():
    """Return only live Home/custom-hub Window objects without probing invalid ids."""
    output = []
    seen = set()
    try:
        current_id = safe_int(xbmcgui.getCurrentWindowId())
    except Exception:
        current_id = 0
    for window_id in _LOCAL_RUNTIME_WINDOW_IDS:
        if window_id in seen:
            continue
        if window_id != current_id and not _window_visible(window_id):
            continue
        try:
            output.append(xbmcgui.Window(window_id))
            seen.add(window_id)
        except Exception:
            pass
    if current_id in _MEDIA_RUNTIME_WINDOW_IDS and current_id not in seen:
        try:
            output.append(xbmcgui.Window(current_id))
            seen.add(current_id)
        except Exception:
            pass
    return output


def _visible_custom_window(logical_id):
    runtime_id = _runtime_window_id(logical_id)
    if not runtime_id or not _window_visible(logical_id):
        return None
    try:
        return xbmcgui.Window(runtime_id)
    except Exception:
        return None
VIDEO_TYPES = ('movie', 'tvshow', 'season', 'episode', 'set')
TYPE_TO_RPC = {
    'movie': ('VideoLibrary.GetMovieDetails', 'movieid', 'moviedetails'),
    'tvshow': ('VideoLibrary.GetTVShowDetails', 'tvshowid', 'tvshowdetails'),
    'season': ('VideoLibrary.GetSeasonDetails', 'seasonid', 'seasondetails'),
    'episode': ('VideoLibrary.GetEpisodeDetails', 'episodeid', 'episodedetails'),
    'set': ('VideoLibrary.GetMovieSetDetails', 'setid', 'setdetails'),
}
_OPTIONAL_EXECUTOR = ThreadPoolExecutor(max_workers=3)
_IDENTITY_TRUST_CACHE = {}
_IDENTITY_TRUST_LOCK = threading.RLock()
_IDENTITY_TRUST_MAX = 512
_KP_IDENTITY_TTL = 30 * 86400
_FINAL_METADATA_TTL = 14 * 86400
_NO_LOGO_METADATA_TTL = 86400       # итог без логотипа - сутки
# Namespace bumped: entries written while a partial answer could
# become the answer for a whole film are not read any more.
_FINAL_METADATA_CACHE_NS = 'finalmeta-v92'


def _kp_identity_keys(tmdb_id=0, imdb_id='', media_type='movie'):
    keys = []
    tmdb_id = safe_int(tmdb_id)
    imdb_id = str(imdb_id or '').strip().lower()
    media_type = 'tv' if media_type in ('tv', 'tvshow', 'season', 'episode') else 'movie'
    if tmdb_id:
        keys.append('identity:kinopoisk:v1:tmdb:%s:%s' % (media_type, tmdb_id))
    if imdb_id.startswith('tt'):
        keys.append('identity:kinopoisk:v1:imdb:%s' % imdb_id)
    return keys


def _kp_identity_lookup(tmdb_id=0, imdb_id='', media_type='movie'):
    for key in _kp_identity_keys(tmdb_id, imdb_id, media_type):
        row = cache.get(key, _KP_IDENTITY_TTL)
        kp_id = safe_int((row or {}).get('kinopoisk_id') if isinstance(row, dict) else row)
        if kp_id:
            log('provider=kinopoisk status=identity_cache_hit id=%s key=%s' % (kp_id, key.rsplit(':', 2)[-2:]), xbmc.LOGINFO)
            return kp_id
    return 0


def _kp_identity_store(kp_id, tmdb_id=0, imdb_id='', media_type='movie'):
    kp_id = safe_int(kp_id)
    if not kp_id:
        return
    row = {'kinopoisk_id': kp_id}
    for key in _kp_identity_keys(tmdb_id, imdb_id, media_type):
        cache.set(key, row)


def _kp_identity_forget(kp_id, tmdb_id=0, imdb_id='', media_type='movie'):
    kp_id = safe_int(kp_id)
    for key in _kp_identity_keys(tmdb_id, imdb_id, media_type):
        row = cache.get(key, _KP_IDENTITY_TTL)
        cached_id = safe_int((row or {}).get('kinopoisk_id') if isinstance(row, dict) else row)
        if not kp_id or cached_id == kp_id:
            cache.delete(key)

DETAIL_PROPERTIES = {
    'movie': ['title','originaltitle','sorttitle','plot','plotoutline','tagline','year','premiered','runtime','mpaa','rating','userrating','votes','top250','playcount','lastplayed','dateadded','file','trailer','genre','country','studio','director','writer','cast','tag','set','setid','art','fanart','thumbnail','ratings','uniqueid','streamdetails'],
    'tvshow': ['title','originaltitle','sorttitle','plot','year','premiered','mpaa','rating','userrating','votes','playcount','lastplayed','dateadded','file','genre','studio','cast','tag','status','season','episode','watchedepisodes','art','fanart','thumbnail','ratings','uniqueid'],
    'season': ['title','showtitle','season','episode','playcount','watchedepisodes','tvshowid','art','fanart','thumbnail'],
    'episode': ['title','originaltitle','showtitle','plot','firstaired','runtime','season','episode','playcount','lastplayed','dateadded','file','productioncode','rating','userrating','votes','tvshowid','seasonid','director','writer','cast','art','fanart','thumbnail','ratings','uniqueid','streamdetails'],
    'set': ['title','plot','playcount','art','fanart','thumbnail'],
}


def jsonrpc(method, params=None):
    request = {'jsonrpc': '2.0', 'id': 1, 'method': method}
    if params:
        request['params'] = params
    try:
        result = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        if result.get('error'):
            log('JSON-RPC %s: %s' % (method, result.get('error')), xbmc.LOGWARNING)
        return result
    except Exception as exc:
        log('JSON-RPC failed %s: %s' % (method, exc), xbmc.LOGWARNING)
        return {}


def home_window():
    return xbmcgui.Window(HOME_ID)


def get_prop(name, window=None):
    try:
        return (window or home_window()).getProperty(name) or ''
    except Exception:
        return ''


def set_prop(name, value, window=None):
    try:
        win = window or home_window()
        value = '' if value in (None, '') else str(value)
        if not value:
            if win.getProperty(name):
                win.clearProperty(name)
        elif win.getProperty(name) != value:
            win.setProperty(name, value)
    except Exception:
        pass


def normalize_dbtype(value):
    value = str(value or '').strip().lower()
    aliases = {'tv': 'tvshow', 'show': 'tvshow', 'shows': 'tvshow', 'tvshows': 'tvshow', 'movies': 'movie'}
    value = aliases.get(value, value)
    return value if value in VIDEO_TYPES else ''


def tmdb_type_from_dbtype(dbtype):
    dbtype = normalize_dbtype(dbtype)
    if dbtype == 'movie':
        return 'movie'
    if dbtype in ('tvshow', 'season', 'episode'):
        return 'tv'
    return ''


def _path_media_type(path):
    """Infer only strong media-type hints from a plugin/library path.

    A plugin can expose stale or incorrect TMDb properties on a list item.  The
    directory branch that produced the item is a stronger signal when it uses
    an explicit movies/serials route.  Keep the matcher deliberately narrow so
    generic plugin paths are not guessed.
    """
    value = str(path or '').replace('\\', '/').lower()
    if re.search(r'/(?:movies?|films?)(?:/|\?|$)', value):
        return 'movie'
    if re.search(r'/(?:serials?|tvshows?|shows?|series)(?:/|\?|$)', value):
        return 'tv'
    return ''


def _path_year(path):
    """Return a release year encoded as a standalone path/slug component."""
    value = str(path or '').replace('\\', '/')
    # Exclude long numeric ids.  This accepts ``title-2025/`` and ``/2025/``
    # while ignoring a year-looking four-digit slice inside an opaque id.
    matches = re.findall(r'(?<!\d)((?:19|20)\d{2})(?!\d)', value)
    for year in reversed(matches):
        number = safe_int(year)
        if 1900 <= number <= 2099:
            return number
    return 0


def _preferred_media_type(params, local):
    """Choose canonical media type from the focused item, not provider ids."""
    params = params or {}
    local = local or {}
    dbtype_type = tmdb_type_from_dbtype(local.get('dbtype'))
    path_type = str(local.get('source_media_type') or '').strip().lower()
    if path_type not in ('movie', 'tv'):
        path_type = _path_media_type(local.get('file'))
    # A concrete Kodi DBType is authoritative.  For plugin rows the explicit
    # directory branch is authoritative over stale tmdb_type properties.
    if dbtype_type in ('movie', 'tv'):
        return dbtype_type
    if path_type in ('movie', 'tv'):
        return path_type
    if _is_episode_like(local, params):
        # Kodi's JSON-RPC Player.FilenameAndPath/VideoPlayer.FilenameAndPath are
        # both empty once plugin playback has resolved to a stream URL - the
        # path is simply not available here to feed _path_media_type, and
        # local_model_from_player() never gets one to put in 'file'. A series
        # title plus a real episode number is not ambiguous regardless: only a
        # season/episode of a TV show has both. Measured on <коробка> while
        # «Хождение по мукам» s1e1 was playing: with no forced type the search
        # fell through to /search/multi and matched a 1977 film by title alone.
        return 'tv'
    value = (params.get('tmdb_type') or params.get('type') or
             local.get('tmdb_type') or local.get('media_type') or '')
    value = str(value or '').strip().lower()
    if value in ('tvshow', 'season', 'episode', 'series', 'show'):
        return 'tv'
    return value if value in ('movie', 'tv', 'person') else ''


def _identity_target_year(params, local, trusted_models=None):
    """Return the focused item's explicit year before any path-derived hint.

    Plugin item paths frequently end in numeric post ids.  A four-digit post id
    must never override ListItem.Year or the year passed by the caller.
    """
    params = params or {}
    local = local or {}
    if _is_episode_like(local, params):
        # The identity being resolved for a season or an episode is the SERIES,
        # and none of the years attached to such a row is the series' first-air
        # year: the item year is the episode's own air year, and the path year
        # is the year of the Filmix post - the release or the dub. «Безумцы»
        # sits at .../8294-20ll22-bezumcy-2010/ while Mad Men first aired in
        # 2007, and that gap alone rejected the correct series
        # (`year_mismatch:2010!=2007`, filmix/docs/ARCHITECTURE_PLUGIN.md).
        # With no year the series is matched on title and country, and the
        # ambiguous-title guard still refuses a one-word title outright rather
        # than guessing.
        return 0
    year = _identity_rank_year(params, local)
    if year:
        return year
    for trusted in (trusted_models or {}).values():
        year = safe_int((trusted or {}).get('year'))
        if year:
            return year
    return 0


def _identity_rank_year(params, local):
    """The item's year as a ranking hint, with no gate attached.

    _identity_target_year() answers 0 for a season/episode because none of the
    years on such a row is the series' first-air year, and a hard gate built on
    it rejects the correct show. Ranking is the opposite case: it still needs to
    know roughly when this release is from, or a namesake wins. Measured on
    <коробка> while «Хождение по мукам» s1e1 was playing: with the year gone
    entirely, the identity chain picked the 1952 Soviet adaptation over the 2017
    series. This value is what breaks that tie - it can promote a candidate, it
    can never reject one.
    """
    params = params or {}
    local = local or {}
    year = safe_int(params.get('year')) or safe_int(local.get('year'))
    if year:
        return year
    # Path parsing is fallback-only and is intentionally never stronger than an
    # explicit item year.
    return safe_int(local.get('source_path_year')) or _path_year(local.get('file'))


def _model_media_type(model, fallback=''):
    value = str((model or {}).get('provider_media_type') or
                (model or {}).get('tmdb_type') or
                (model or {}).get('media_type') or fallback or '').strip().lower()
    if value in ('tvshow', 'season', 'episode', 'series', 'show'):
        return 'tv'
    return value if value in ('movie', 'tv', 'person') else ''


_PLOT_STOPWORDS = {
    'this', 'that', 'with', 'from', 'into', 'when', 'after', 'before', 'about',
    'their', 'there', 'where', 'which', 'while', 'through', 'must', 'will',
    'когда', 'после', 'перед', 'который', 'которая', 'которые', 'своего',
    'своей', 'свои', 'чтобы', 'между', 'вместе', 'теперь', 'однако', 'только',
    'вновь', 'снова', 'этого', 'этот', 'этой', 'один', 'одна', 'жизнь',
}


def _plot_conflict(left, right):
    """Return True only for a decisive same-language plot contradiction.

    The former 0.20 similarity threshold rejected correct cards whose provider
    descriptions were legitimate paraphrases.  Here plot text is a veto only
    when both descriptions are substantial and share no meaningful lexical
    root at all.  Missing/short/different-language plots remain neutral.
    """
    left = str(left or '').strip().lower().replace('ё', 'е')
    right = str(right or '').strip().lower().replace('ё', 'е')
    if len(left) < 80 or len(right) < 80:
        return False
    left_cyr = bool(re.search(r'[а-я]', left))
    right_cyr = bool(re.search(r'[а-я]', right))
    if left_cyr != right_cyr:
        return False

    def roots(value):
        output = set()
        for word in re.findall(r'[a-zа-я0-9]+', value):
            if len(word) < 5 or word in _PLOT_STOPWORDS:
                continue
            # Six-character roots tolerate the common Russian inflectional
            # endings while remaining specific enough for a conflict veto.
            output.add(word[:6])
        return output

    left_roots = roots(left)
    right_roots = roots(right)
    if len(left_roots) < 8 or len(right_roots) < 8:
        return False
    return not bool(left_roots & right_roots)


def _unique_id(uniqueid, key):
    if isinstance(uniqueid, dict):
        return str(uniqueid.get(key) or uniqueid.get(key.upper()) or uniqueid.get(key.lower()) or '')
    return ''


def get_details(dbid, dbtype):
    dbtype = normalize_dbtype(dbtype)
    route = TYPE_TO_RPC.get(dbtype)
    if not route or not dbid:
        return {}
    method, id_key, result_key = route
    params = {id_key: safe_int(dbid), 'properties': DETAIL_PROPERTIES.get(dbtype, [])}
    return jsonrpc(method, params).get('result', {}).get(result_key, {}) or {}






_label_offset = [0]


# Reading info labels through xbmc.getInfoLabel is what takes Kodi 22-BETA1
# down: five crash logs across both boxes on 23.08.2026, every one of them a
# SIGSEGV inside CGUIInfoManager::GetMultiInfoLabel one frame under that call,
# and several of them in the first seconds after the skin loaded. The same
# labels asked over JSON-RPC (XBMC.GetInfoLabels) have been read thousands of
# times tonight from outside without a single crash - a different entry point
# into the same data, and one that answers many labels per call.
#
# So all label reading funnels through here. `read_labels` asks for a whole
# list at once, which is what the callers actually need.
# Measured on .20: a JSON-RPC label request costs about 20 ms, against
# microseconds for the Python API. Even asked in batches - seventy-five labels
# for a row model in one request, forty for its fingerprint - the service loop
# makes many such requests per turn, and the owner's verdict on the result was
# «всё грузится очень медленно, пользоваться очень некомфортно». That is the
# honest outcome: this path is too expensive for this hardware.
#
# So the fast API is used again, and the crash is fought with the measures that
# cost nothing: worker threads never read GUI state (refresh_ui_snapshot), the
# service waits for a real window plus twelve seconds at startup, and the
# fallback publisher is asked at most every 1.5 s instead of four times a
# second. The batching and the short-lived cache below stay, because fewer reads
# is both faster AND fewer chances to hit the Kodi bug. Flip this back to True
# to test the safe-but-slow path again.
LABELS_VIA_JSONRPC = False


# One request is not one call: measured on .20, a JSON-RPC label request costs
# about 20 ms over the local socket, against microseconds for the Python API it
# replaced. A model of one row reads about forty labels, so read one at a time
# that is the better part of a second per focused row - which is exactly what
# the owner saw as "фоны и метаданные грузятся очень долго" right after this
# path was introduced. Two things make it cheap again: everything asks for its
# labels as a LIST, and a very short-lived cache absorbs the repeats within one
# turn of the service loop (which runs every 250 ms).
# One look at the GUI per turn of the service loop, and everything reads from
# it. Before this each part asked for its own batch - the row model, the
# fingerprint (twice), the fallback publisher, the wash source - and a time
# based cache tried to paper over the repeats. Now the loop clears the snapshot
# at the top of every iteration and nothing else expires: within one iteration
# every reader sees the same state (which is also the correctness the two-tick
# guards used to chase), and across iterations it is always fresh.
_LABEL_CACHE = {}
_LABEL_CACHE_AT = [0.0]
_LABEL_CACHE_TTL = 1.5


def invalidate_labels():
    """Start a new snapshot. Called once per turn of the service loop."""
    _LABEL_CACHE.clear()
    _LABEL_CACHE_AT[0] = time.time()


def _label_cache_sweep(now):
    # A safety net only: if nobody calls invalidate_labels (a plugin route, a
    # dialog script), the snapshot still cannot go stale for long.
    if now - _LABEL_CACHE_AT[0] < _LABEL_CACHE_TTL:
        return
    _LABEL_CACHE.clear()
    _LABEL_CACHE_AT[0] = now


def read_labels(addresses, fresh=False):
    """{address: value} for these info labels, in one request."""
    names = []
    for address in (addresses or []):
        address = str(address or '')
        if address and address not in names:
            names.append(address)
    if not names:
        return {}
    now = time.time()
    if fresh:
        for name in names:
            _LABEL_CACHE.pop(name, None)
    else:
        _label_cache_sweep(now)
    answer = {}
    missing = []
    for name in names:
        if name in _LABEL_CACHE:
            answer[name] = _LABEL_CACHE[name]
        else:
            missing.append(name)
    if not missing:
        return answer
    if not (LABELS_VIA_JSONRPC or labels_batch_enabled()):
        for name in missing:
            try:
                answer[name] = xbmc.getInfoLabel(name) or ''
            except Exception:
                answer[name] = ''
    else:
        try:
            raw = xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'XBMC.GetInfoLabels',
                'params': {'labels': missing},
            })) or '{}'
            result = (json.loads(raw).get('result') or {})
            for name in missing:
                answer[name] = str(result.get(name) or '')
        except Exception:
            for name in missing:
                answer[name] = ''
    if not _LABEL_CACHE:
        _LABEL_CACHE_AT[0] = now
    _LABEL_CACHE.update((name, answer.get(name, '')) for name in missing)
    return answer


def prefetch_labels(names, container_id=0):
    """Ask for a whole set of ListItem labels the way current_label addresses
    them, so the reads that follow are answered from memory."""
    off = safe_int(_label_offset[0])
    addresses = []
    for name in (names or []):
        if container_id:
            cid = safe_int(container_id)
            addresses.append('Container.ListItem(%d).%s' % (off, name) if off
                             else 'Container(%d).ListItem.%s' % (cid, name))
        elif not off:
            addresses.append('ListItem.%s' % name)
    if addresses:
        read_labels(addresses)


def read_label(address):
    """One info label, without the Python API that crashes this Kodi."""
    if not address:
        return ''
    return read_labels([address]).get(str(address), '')


def current_label(name, container_id=0):
    off = safe_int(_label_offset[0])
    try:
        if container_id:
            cid = safe_int(container_id)
            if off:
                # An INDEXED read against an explicit container id is ambiguous
                # on Home: every hub owns its own control with the same id, and
                # measured on <коробка> `Container(501).ListItem(2)` returned
                # the PVR hub's channel rows while the user was on a film lane
                # (log: "widget warm-up ... pvr_row(pvr://channels/tv/...)").
                # Every neighbour the warm-up ever prepared was therefore the
                # wrong row. The id-less form is bound to the FOCUSED container,
                # which is the only container offsets are ever read for, so ask
                # that - and only while the intended container really is focused.
                if not xbmc.getCondVisibility('Control.HasFocus(%d)' % cid):
                    return ''
                addr = 'Container.ListItem(%d).%s' % (off, name)
            else:
                addr = 'Container(%d).ListItem.%s' % (cid, name)
            value = read_label(addr)
            if value:
                return value
        if not off:
            return read_label('ListItem.%s' % name)
        return ''
    except Exception:
        return ''


def _at_offset(container_id, offset, func, *args):
    """Run func(container_id, *args) as if a different row in container_id
    had focus, using Container(id).ListItem(offset).* addressing instead of
    the focused item. offset is relative to whatever is actually focused
    right now (Kodi's own ListItem(offset) semantics), and is restored to 0
    afterwards regardless of outcome so unrelated current_label() callers on
    the same thread are never affected by a stale offset.
    """
    prev = _label_offset[0]
    _label_offset[0] = safe_int(offset)
    try:
        return func(container_id, *args)
    finally:
        _label_offset[0] = prev


def split_people(value):
    value = str(value or '').replace('[CR]', ' / ').replace(', ', ' / ')
    return [x.strip() for x in value.split(' / ') if x.strip()]


def _pvr_context(container_id=0):
    """Return strict PVR context without trusting stale global channel labels.

    Kodi can keep ListItem.ChannelName / EPG labels populated for several focus
    changes after leaving a PVR row.  Those labels must never classify a normal
    plugin movie as PVR.  Only the actual item path or DB type establishes PVR.
    """
    try:
        path = current_label('FileNameAndPath', container_id) or current_label('FolderPath', container_id) or current_label('Path', container_id)
        path_lower = str(path or '').strip().lower()
        raw_dbtype = str(current_label('DBType', container_id) or '').strip().lower()
        is_pvr = path_lower.startswith('pvr://') or raw_dbtype in ('channel', 'epg', 'epgevent', 'pvr')
        if not is_pvr:
            return {}
        epg_title = current_label('EpgEventTitle', container_id) or current_label('EPGEventTitle', container_id)
        title = epg_title or current_label('Title', container_id) or current_label('Label', container_id)
        channel = current_label('ChannelName', container_id)
        start_time = current_label('StartTime', container_id)
        end_time = current_label('EndTime', container_id)
        plot = current_label('Plot', container_id)
        # A channel-group folder normally has only a label/path.  A real channel
        # or EPG event has at least one of these event/channel signals.
        lookup_candidate = bool(title and (epg_title or channel or start_time or end_time or plot))
        return {
            'is_pvr': True,
            'lookup_candidate': lookup_candidate,
            'path': path,
            'title': title,
            'channel': channel,
            'start_time': start_time,
            'end_time': end_time,
            'plot': plot,
        }
    except Exception:
        return {}


def _has_media_evidence(local):
    """Reject navigation/category rows while retaining actual media folders."""
    if not local or not str(local.get('title') or '').strip():
        return False
    if local.get('_is_pvr'):
        return bool(local.get('_pvr_lookup_candidate'))
    if local.get('dbid') or local.get('tmdb_id') or local.get('imdb_id') or local.get('kinopoisk_id'):
        return True
    if local.get('dbtype') in VIDEO_TYPES:
        return True
    if local.get('year') or local.get('premiered') or local.get('plot') or local.get('trailer'):
        return True
    art = local.get('art') or {}
    if art.get('poster') or art.get('fanart') or art.get('landscape'):
        return True
    path = str(local.get('file') or '').lower()
    if path.startswith(('videodb://', 'library://')):
        return True
    # Film/episode plugin rows are commonly playable/open routes even when the
    # addon has not yet supplied IDs.  Generic category routes are not.
    media_route_markers = ('/play/', '/open/', '/movie/', '/movies/', '/film/', '/films/', '/serial/', '/serials/', '/tvshow/', '/episode/', '/show/', 'mode=show', 'mode=play')
    return path.startswith('plugin://') and any(marker in path for marker in media_route_markers)



def _background_resolve_candidate_from_current(container_id):
    """Lightweight one-frame gate for media rows that will use online metadata.

    This must not publish any row data and must not call library/details APIs; it
    only decides whether the fallback layer should wait for the enriched/no-
    enriched background decision.
    """
    try:
        if not config.online_enabled() or not _metadata_available():
            return False
        pvr = _pvr_context(container_id)
        if pvr:
            return bool(config.pvr_lookups_enabled() and pvr.get('lookup_candidate'))
        title = current_label('Title', container_id) or current_label('Label', container_id)
        if not str(title or '').strip():
            return False
        dbtype = normalize_dbtype(current_label('DBType', container_id))
        dbid = safe_int(current_label('DBID', container_id))
        path = str(current_label('FileNameAndPath', container_id) or current_label('FolderPath', container_id) or '').lower()
        tmdb_id = _valid_tmdb_id(current_label('UniqueID(tmdb)', container_id) or current_label('Property(tmdb_id)', container_id) or current_label('Property(TMDB_ID)', container_id) or current_label('Property(TMDb_ID)', container_id))
        imdb_id = current_label('UniqueID(imdb)', container_id) or current_label('IMDBNumber', container_id) or current_label('Property(imdb_id)', container_id) or current_label('Property(IMDb_ID)', container_id)
        kp_id = safe_int(current_label('UniqueID(kinopoisk)', container_id) or current_label('UniqueID(kp)', container_id) or current_label('Property(kinopoisk_id)', container_id) or current_label('Property(Kinopoisk_ID)', container_id) or current_label('Property(kp_id)', container_id))
        probe = {
            'file': path, 'dbtype': dbtype, 'dbid': dbid,
            'tmdb_id': tmdb_id, 'imdb_id': imdb_id, 'kinopoisk_id': kp_id,
        }
        if _is_generic_youtube_item(probe):
            return False
        if dbid or tmdb_id or imdb_id or kp_id or dbtype in VIDEO_TYPES:
            return True
        if current_label('Year', container_id) or current_label('Premiered', container_id) or current_label('Date', container_id) or current_label('Plot', container_id) or current_label('Trailer', container_id):
            return True
        if current_label('Art(poster)', container_id) or current_label('Art(fanart)', container_id) or current_label('Art(landscape)', container_id):
            return True
        media_route_markers = ('/play/', '/open/', '/movie/', '/movies/', '/film/', '/films/', '/serial/', '/serials/', '/tvshow/', '/episode/', '/show/', 'mode=show', 'mode=play')
        return path.startswith('plugin://') and any(marker in path for marker in media_route_markers)
    except Exception:
        return False


def _is_generic_youtube_item(local):
    local = local or {}
    path = str(local.get('file') or '').lower()
    if 'plugin.video.youtube' not in path:
        return False
    # Explicit movie/show identity is allowed; generic subscriptions, news and
    # ordinary YouTube videos must never consume movie metadata providers.
    if local.get('tmdb_id') or local.get('imdb_id') or local.get('kinopoisk_id') or local.get('dbid'):
        return False
    return str(local.get('dbtype') or '').lower() not in ('movie', 'tvshow', 'season', 'episode')


def _identity_cache_get(key):
    with _IDENTITY_TRUST_LOCK:
        return _IDENTITY_TRUST_CACHE.get(str(key or ''))


def _identity_cache_set(key, trusted):
    key = str(key or '')
    if not key:
        return
    with _IDENTITY_TRUST_LOCK:
        _IDENTITY_TRUST_CACHE[key] = bool(trusted)
        while len(_IDENTITY_TRUST_CACHE) > _IDENTITY_TRUST_MAX:
            try:
                _IDENTITY_TRUST_CACHE.pop(next(iter(_IDENTITY_TRUST_CACHE)))
            except Exception:
                break


def _pending_local_model(local, rejected=False, background_resolving=False):
    safe = copy.deepcopy(local or {})
    # Keep local-first text/poster publication, but background promotion is
    # decided later in _publish(). Local/plugin fanart is metadata, not a proven
    # large background. This keeps the model universal for every plugin.
    safe['trailer'] = ''
    safe['trailer_fallback'] = ''
    safe.pop('trailer_candidates', None)
    if rejected:
        safe['_identity_rejected'] = True
    if background_resolving:
        # A media row with an active online/enriched lookup must not show fallback
        # first and then replace it with enriched fanart. The fallback layer is
        # released only after the worker has decided that no enriched background
        # exists for this same keyed item.
        safe['_background_resolving'] = True
    return safe


def _has_enriched_background_art(art_models, sources):
    # A large primary background may only come from a validated provider/enriched
    # source. The focused plugin row's own art remains available as fallback art.
    for source in sources or []:
        if source == 'local':
            continue
        source_art = (art_models.get(source, {}) or {}).get('art') or {}
        if source_art.get('fanart') or source_art.get('landscape'):
            return True
    return False


def extract_year(value):
    match = re.search(r'(19|20)\d{2}', str(value or ''))
    return safe_int(match.group(0)) if match else 0


def _valid_tmdb_id(value):
    value = safe_int(value)
    # Plugin-internal identifiers seen in logs are around 1.7 billion and were
    # previously sent to TMDb as real media ids. Keep a deliberately generous
    # upper bound while rejecting those foreign ids.
    return value if 0 < value < 50000000 else 0


def _metadata_available():
    return bool(tmdb.available() or kinopoisk.available() or config.use_omdb())


_HAS_CYRILLIC = re.compile(r'[Ѐ-ӿ]')


def _prefer_russian(first, second):
    """Из двух текстов: сначала русский, при равенстве - первый.

    Порядок для серии: её собственное описание, затем описание сериала.
    Русский при этом важнее очерёдности.
    """
    first = str(first or '').strip()
    second = str(second or '').strip()
    if first and _HAS_CYRILLIC.search(first):
        return first
    if second and _HAS_CYRILLIC.search(second):
        return second
    return first or second


def prefer_local_title(answer_title, local_title):
    """Название для экрана: своё русское важнее чужого оригинального.

    TMDb на ru-RU отдаёт локализованное название не для всех фильмов - если
    его нет, приходит оригинал. Провайдер при этом знает русское. Так на .20
    в полосе новинок «Невидимый гость» показывался как «The Invisible Guest»,
    а «Солнечная танцовщица» - как «Sunny Dancer».

    Правило узкое: подменяем только тогда, когда в ответе кириллицы нет, а в
    строке она есть. Английский фильм с английским названием и русский ответ
    остаются как были.
    """
    answer = str(answer_title or '').strip()
    local = str(local_title or '').strip()
    if not local:
        return answer
    if not answer:
        return local
    if _HAS_CYRILLIC.search(local) and not _HAS_CYRILLIC.search(answer):
        return local
    return answer



def prefer_local_plot(answer_plot, local_plot):
    """Описание для экрана: русское описание источника важнее нерусского ответа.

    TMDb без перевода отдаёт описание на языке оригинала: у новинки Filmix
    «Всегда говори Да на Рождество» (.20, 19.11.2026) английский текст TMDb
    перебивал русский short_story источника. Правило то же, что у названия.
    """
    answer = str(answer_plot or '').strip()
    local = str(local_plot or '').strip()
    if local and (not answer or (_HAS_CYRILLIC.search(local)
                                 and not _HAS_CYRILLIC.search(answer))):
        return local
    return answer


_CYRILLIC_TRANSLIT = {
    'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo',
    'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
    'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
    'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'shch',
    'ъ': '', 'ы': 'y', 'ь': '', 'э': 'e', 'ю': 'yu', 'я': 'ya',
    'і': 'i', 'ї': 'yi', 'є': 'ye', 'ґ': 'g',
}


def _transliterate_title(value):
    value = str(value or '')
    return ''.join(_CYRILLIC_TRANSLIT.get(ch.casefold(), ch) for ch in value)


def _normal_title(value):
    value = unicodedata.normalize('NFKD', str(value or '')).casefold()
    return ''.join(ch for ch in value if ch.isalnum())


def _title_keys(value):
    keys = set()
    direct = _normal_title(value)
    if direct:
        keys.add(direct)
    transliterated = _normal_title(_transliterate_title(value))
    if transliterated:
        keys.add(transliterated)
    return keys


def _title_word_set(value):
    """Whole words of a title, in both the original and transliterated spelling."""
    words = set()
    for variant in (str(value or ''), _transliterate_title(value)):
        for token in re.split(r'\W+', unicodedata.normalize('NFKD', variant).casefold(), flags=re.U):
            token = ''.join(ch for ch in token if ch.isalnum())
            # «F1», «R2», «3D»: короткое слово из букв и цифр - тоже слово названия. Без него
            # «F1» не находилось внутри «F1: The Movie», и «Формула-1» оставалась без опознания,
            # пока Кинопоиск на паузе (.20, 22.11.2026)
            mixed = len(token) >= 2 and any(ch.isdigit() for ch in token) and any(ch.isalpha() for ch in token)
            if (len(token) >= 3 or mixed) and not token.isdigit():
                words.add(token)
    return words


def _title_similarity(left, right):
    left_keys = _title_keys(left)
    right_keys = _title_keys(right)
    if not left_keys or not right_keys:
        return 0.0, False
    exact = bool(left_keys.intersection(right_keys))
    score = max(SequenceMatcher(None, a, b).ratio() for a in left_keys for b in right_keys)
    # Character-ratio scoring underrates a title that is wholly contained in the
    # other one. Measured live on <коробка>: the catalogue calls the series
    # "Джек Ричер", TMDb calls it "Ричер"/"Reacher", and the TMDb search returned
    # that one series and nothing else - yet 0.67 fell under the 0.72 acceptance
    # threshold, so the row resolved to TMDB_ID=0 and lost every rating and its
    # trailer while a correct card for it already sat in metadata_cache.
    # Only whole words count, digits and 1-2 letter fragments are ignored, and
    # the lift stops just past the threshold - the caller's year-mismatch and
    # ambiguous-query guards still decide, so a sequel cannot ride in on this.
    if not exact and score < 0.75:
        left_words = _title_word_set(left)
        right_words = _title_word_set(right)
        if left_words and right_words and (
                left_words <= right_words or right_words <= left_words):
            score = max(score, 0.75)
    return score, exact


_COUNTRY_CODE_MAP = {
    'россия': 'RU', 'russia': 'RU', 'ссср': 'RU', 'рф': 'RU',
    'сша': 'US', 'usa': 'US', 'united states': 'US', 'америка': 'US',
    'великобритания': 'GB', 'англия': 'GB', 'uk': 'GB', 'united kingdom': 'GB', 'британия': 'GB',
    'франция': 'FR', 'france': 'FR', 'германия': 'DE', 'germany': 'DE',
    'испания': 'ES', 'spain': 'ES', 'италия': 'IT', 'italy': 'IT',
    'украина': 'UA', 'ukraine': 'UA', 'япония': 'JP', 'japan': 'JP',
    'корея': 'KR', 'южная корея': 'KR', 'korea': 'KR', 'south korea': 'KR',
    'китай': 'CN', 'china': 'CN', 'турция': 'TR', 'turkey': 'TR',
    'индия': 'IN', 'india': 'IN', 'канада': 'CA', 'canada': 'CA',
    'сербия': 'RS', 'serbia': 'RS', 'югославия': 'RS', 'yugoslavia': 'RS',
    'польша': 'PL', 'poland': 'PL', 'швеция': 'SE', 'sweden': 'SE',
    'норвегия': 'NO', 'norway': 'NO', 'дания': 'DK', 'denmark': 'DK',
    'нидерланды': 'NL', 'netherlands': 'NL', 'голландия': 'NL', 'holland': 'NL',
    'бельгия': 'BE', 'belgium': 'BE', 'мексика': 'MX', 'mexico': 'MX',
    'бразилия': 'BR', 'brazil': 'BR', 'аргентина': 'AR', 'argentina': 'AR',
    'австралия': 'AU', 'australia': 'AU', 'ирландия': 'IE', 'ireland': 'IE',
    'швейцария': 'CH', 'switzerland': 'CH', 'австрия': 'AT', 'austria': 'AT',
}
_COUNTRY_LANG_MAP = {
    'RU': 'ru', 'US': 'en', 'GB': 'en', 'FR': 'fr', 'DE': 'de', 'ES': 'es',
    'IT': 'it', 'UA': 'uk', 'JP': 'ja', 'KR': 'ko', 'CN': 'zh', 'TR': 'tr',
    'IN': 'hi', 'CA': 'en', 'RS': 'sr', 'PL': 'pl', 'SE': 'sv',
    'NO': 'no', 'DK': 'da', 'NL': 'nl', 'BE': 'nl', 'MX': 'es',
    'BR': 'pt', 'AR': 'es', 'AU': 'en', 'IE': 'en', 'CH': 'de', 'AT': 'de',
}


def _country_code_from_value(value):
    text = str(value or '').strip()
    if not text:
        return ''
    raw = text.upper()
    if re.match(r'^[A-Z]{2}$', raw):
        return raw
    norm = text.lower().replace('ё', 'е')
    norm = re.sub(r'[^a-zа-я0-9 ]+', ' ', norm, flags=re.U)
    norm = re.sub(r'\s+', ' ', norm, flags=re.U).strip()
    if not norm:
        return ''
    code = _COUNTRY_CODE_MAP.get(norm)
    if code:
        return code
    for name, mapped in _COUNTRY_CODE_MAP.items():
        if len(name) >= 4 and re.search(r'(^|\s)%s($|\s)' % re.escape(name), norm, flags=re.U):
            return mapped
    return ''


def _country_codes_from_values(values):
    if values in (None, ''):
        return set()
    if isinstance(values, dict):
        values = values.values()
    elif not isinstance(values, (list, tuple, set)):
        values = [values]
    output = set()
    for value in values:
        if isinstance(value, dict):
            value = value.get('iso_3166_1') or value.get('name') or value.get('country') or value.get('english_name') or ''
        code = _country_code_from_value(value)
        if code:
            output.add(code)
    return output


def _local_country_codes(local):
    local = local or {}
    values = []
    for field in ('source_country', 'source_countries', 'filmix_source_country', 'filmix_source_countries', 'country', 'countries', 'origin_country', 'genre', 'genres', 'studio', 'tag', 'tagline'):
        val = local.get(field)
        if isinstance(val, (list, tuple, set)):
            values.extend(val)
        elif val:
            values.append(val)
    return _country_codes_from_values(values)


def _model_country_codes(model):
    model = model or {}
    values = []
    for field in ('country', 'countries', 'origin_country', 'production_countries', 'country_text'):
        val = model.get(field)
        if isinstance(val, (list, tuple, set)):
            values.extend(val)
        elif val:
            values.extend([x.strip() for x in str(val).split(',') if x.strip()])
    return _country_codes_from_values(values)


def _identity_country_codes(params=None, local=None):
    codes = set()
    for source in (params or {}, local or {}):
        codes.update(_local_country_codes(source))
    return codes


def _country_identity_confirmed(params=None, local=None, model=None):
    source_codes = _identity_country_codes(params, local)
    if not source_codes:
        return True, source_codes, set()
    provider_codes = _model_country_codes(model or {})
    if not provider_codes:
        # No country data on the candidate is not evidence of a wrong film - it
        # is no evidence at all, and plenty of correct records carry none. This
        # branch used to reject, and the row then lost its background, logo and
        # rating while the log said the identification had succeeded (measured
        # on .20 with «Шанхайский сюрприз»). Title and year still have to agree
        # for the match to be accepted; see the caller.
        return True, source_codes, provider_codes
    return bool(source_codes.intersection(provider_codes)), source_codes, provider_codes


def _source_locale(local):
    """Best-effort (country_code, language_code) from the source item.

    Used as a search scoring tiebreaker. Actual acceptance is validated later by
    _country_identity_confirmed().
    """
    codes = _local_country_codes(local or {})
    if codes:
        code = sorted(codes)[0]
        return code, _COUNTRY_LANG_MAP.get(code, '')
    return '', ''


def _score_row(query, year, row, source='tmdb', prefer_country='', prefer_lang=''):
    if source == 'kinopoisk':
        names = (row.get('nameRu'), row.get('nameEn'), row.get('nameOriginal'))
        row_year = safe_int(row.get('year'))
    else:
        names = (row.get('title'), row.get('name'), row.get('original_title'), row.get('original_name'))
        row_year = extract_year(row.get('release_date') or row.get('first_air_date'))
    scored = [_title_similarity(query, name) for name in names if name]
    score = max((item[0] for item in scored), default=0.0)
    if any(item[1] for item in scored):
        score += 1.0
    target_year = safe_int(year)
    if target_year and row_year:
        if target_year == row_year:
            score += 0.5
        elif abs(target_year - row_year) > 1:
            score -= 0.25
    # Country/language affinity (tmdb only). Breaks same-title collisions toward
    # the record whose origin matches the source item; moderate weights so it
    # cannot override a clearly better title/year match.
    if source == 'tmdb' and (prefer_country or prefer_lang):
        row_countries = row.get('origin_country') or []
        if isinstance(row_countries, str):
            row_countries = [row_countries]
        row_lang = str(row.get('original_language') or '').lower()
        if prefer_country and row_countries:
            if prefer_country in row_countries:
                score += 0.6
            else:
                score -= 0.4
        elif prefer_lang and row_lang:
            if row_lang == prefer_lang:
                score += 0.4
            else:
                score -= 0.3
    return score


def _row_titles(row, source='tmdb'):
    row = row or {}
    if source == 'kinopoisk':
        return tuple(filter(None, (row.get('nameRu'), row.get('nameEn'), row.get('nameOriginal'))))
    return tuple(filter(None, (row.get('title'), row.get('name'), row.get('original_title'), row.get('original_name'))))


def _row_year(row, source='tmdb'):
    row = row or {}
    if source == 'kinopoisk':
        return safe_int(row.get('year'))
    return extract_year(row.get('release_date') or row.get('first_air_date'))


def _search_query_is_ambiguous(query):
    words = re.findall(r'[\w]+', str(query or '').casefold(), flags=re.UNICODE)
    normalized = _normal_title(query)
    # A short single word such as "Вместо" can legitimately be the translated
    # title of many unrelated records. Without a provider id/cross-id there is no
    # safe way to choose one, so prefer no metadata over a false match.
    return len(words) <= 1 and len(normalized) < 12


def _row_country_codes(row, source='tmdb'):
    """ISO country codes for a provider search row (e.g. tmdb origin_country)."""
    row = row or {}
    values = []
    for field in ('origin_country', 'country', 'countries', 'production_countries'):
        val = row.get(field)
        if isinstance(val, (list, tuple, set)):
            values.extend(val)
        elif val:
            values.append(val)
    return _country_codes_from_values(values)


def _log_search_reject(reason, query, names, exact, best_similarity, target_year,
                       candidate_year, prefer, row, source, extra=''):
    """One line per rejected search row, naming the gate that dropped it.

    The August 2026 "Джек Ричер" session burned a whole context because the gates
    only ever returned False silently, so a fix could be deployed against the
    wrong gate and look exactly like no fix at all.
    """
    try:
        log('search reject: gate=_search_row_is_safe reason=%s source=%s q=%r names=%s '
            'exact=%s sim=%.2f year=%s/%s prefer=%s row_country=%s %s' % (
                reason, source, str(query)[:32], '|'.join(str(n)[:24] for n in names),
                exact, best_similarity, target_year or '-', candidate_year or '-',
                ','.join(sorted(prefer or [])) or '-',
                ','.join(sorted(_row_country_codes(row, source))) or '-', extra),
            xbmc.LOGINFO)
    except Exception:
        pass


def _search_row_is_safe(query, year, row, source='tmdb', prefer_country=None):
    if not row:
        return False
    names = _row_titles(row, source)
    scored = [_title_similarity(query, name) for name in names]
    best_similarity = max((value[0] for value in scored), default=0.0)
    exact = any(value[1] for value in scored)
    target_year = safe_int(year)
    candidate_year = _row_year(row, source)
    if target_year and candidate_year and abs(target_year - candidate_year) > 1:
        _log_search_reject('year_mismatch', query, names, exact, best_similarity,
                           target_year, candidate_year, set(prefer_country or []), row, source)
        return False
    # Short one-word titles are too ambiguous for fuzzy matching. Require an
    # exact localized/original title and a known provider year within one year.
    # Providers commonly disagree by one year between festival/premiere/release,
    # while an unrelated title such as the rejected adult card for "Вместо"
    # still cannot pass because its title is not exact.
    if _search_query_is_ambiguous(query):
        year_ok = bool(target_year and candidate_year and abs(target_year - candidate_year) <= 1)
        if exact and year_ok:
            return True
        # Country + year both agree: accept a reasonable (not necessarily exact)
        # title. Origin country plus year is a strong structural disambiguator for
        # generic one-word titles like "Сезон" (HK, 2026) - it lets the correct
        # entry through while still rejecting a same-titled entry from another
        # country (e.g. the US "Брачный сезон").
        prefer = set(prefer_country or [])
        if prefer and year_ok and (prefer & _row_country_codes(row, source)) and best_similarity >= 0.60:
            return True
        _log_search_reject('ambiguous_query', query, names, exact, best_similarity,
                           target_year, candidate_year, prefer, row, source,
                           'year_ok=%s' % year_ok)
        return False
    # One title wholly contained in the other, with the year agreeing and the
    # origin country agreeing, is structural evidence rather than a fuzzy guess.
    # Measured on <коробка>: the catalogue calls the series "Джек Ричер" and
    # searches TMDb as "Jack Reacher"; TMDb returned exactly one record, "Ричер"
    # / "Reacher" (US, 2022), which _score_row ranked 1.88 - and this gate still
    # dropped it, because 0.75 is under the 0.82 fuzzy bar and the titles are not
    # equal. The row therefore resolved to TMDB_ID=0 and lost its ratings,
    # trailer and fanart. Whole words only, so "Jack Reacher 2" cannot slip in on
    # a digit, and the year/country agreement still has to hold.
    # Containment is a property of ONE title, so it has to be tested against each
    # candidate name separately. Merging every name into a single word set is what
    # made the first attempt (v938) fail: the union for this record is
    # {reacher, richer, ричер}, so neither direction is a subset of
    # {jack, reacher} and the branch never fired, even though "Reacher" on its own
    # is wholly contained in the query.
    if not exact and best_similarity < 0.82:
        query_words = _title_word_set(query)
        contained = ''
        for name in names:
            row_words = _title_word_set(name)
            if query_words and row_words and (
                    query_words <= row_words or row_words <= query_words):
                contained = name
                break
        if contained:
            year_ok = bool(target_year and candidate_year and abs(target_year - candidate_year) <= 1)
            prefer = set(prefer_country or [])
            # страна неизвестна - не несогласие: у строк поиска фильмов TMDb стран нет вовсе, а
            # карточка проверяется ещё раз целиком (_accept_provider_model, с альтернативными названиями)
            row_countries = _row_country_codes(row, source)
            country_ok = (not prefer) or (not row_countries) or bool(prefer & row_countries)
            if year_ok and country_ok:
                return True
            _log_search_reject(
                'containment_guard', query, names, exact, best_similarity,
                target_year, candidate_year, prefer, row, source,
                'contained=%s year_ok=%s country_ok=%s' % (contained, year_ok, country_ok))
            return False
    # Exact localized/original title is accepted. Fuzzy-only search must be very
    # close; the detailed object is validated again before publication.
    accepted = bool(exact or best_similarity >= 0.82)
    if not accepted:
        _log_search_reject(
            'similarity', query, names, exact, best_similarity,
            target_year, candidate_year, set(prefer_country or []), row, source, 'no containment')
    return accepted


def _best_row(rows, query, year='', source='tmdb', prefer_country='', prefer_lang='', source_countries=None,
              rank_year=''):
    # Ranking may use a year the gate is not allowed to enforce - see
    # _identity_rank_year(). Everything below still decides acceptance on `year`.
    order_year = safe_int(rank_year) or year
    rows = sorted(list(rows or []), key=lambda row: _score_row(query, order_year, row, source, prefer_country, prefer_lang), reverse=True)
    # Sublime 870 diagnostic: for tmdb, log the top candidates with their country and
    # score so a mismatch (e.g. Великолепная пятёрка -> CBBC) can be pinned - shows
    # whether a same-country candidate even exists in the provider result set.
    if source == 'tmdb' and rows:
        try:
            top = []
            for row in rows[:4]:
                oc = row.get('origin_country') or row.get('country') or ''
                if isinstance(oc, (list, tuple)):
                    oc = ','.join(str(c) for c in oc)
                top.append('%s[%s]=%.2f' % (
                    (row.get('name') or row.get('title') or '?')[:24], oc,
                    _score_row(query, order_year, row, source, prefer_country, prefer_lang)))
            # Диагностика опознания - в отладочный уровень. Замер на .30
            # 07.09.2026: из 677 строк журнала 193 наши, и почти все - вот эти
            # четыре сообщения (match diag, metadata_chain, полный поиск
            # логотипов). На простое журнал писал 61 КБ/мин, то есть 86 МБ в
            # сутки на eMMC. Ошибки, отказы и исчерпание нормы остаются в
            # обычном журнале.
            log('match diag: q=%r prefer=%s rank_year=%s top=%s' % (
                str(query)[:24], prefer_country or '-', order_year or '-', ' | '.join(top)), xbmc.LOGDEBUG)
        except Exception:
            pass
    for row in rows:
        if _search_row_is_safe(query, year, row, source, source_countries):
            return row
    return {}


def _identity_validation_required(local, media_type=''):
    """Return whether provider identity must be checked against the focused item."""
    local = local or {}
    if local.get('_is_pvr') or media_type == 'person':
        return False
    dbtype = str(local.get('dbtype') or '').lower()
    # Season/episode requests use a parent-show id plus numeric coordinates; the
    # provider title can legitimately be an episode/season title in another
    # locale - or, fetched here, a straight episode name in a completely
    # different language from the show's own title. _is_episode_like() covers
    # this the same way dbtype in ('season','episode') did: Kodi's own DBType
    # is empty for plugin playback (VideoPlayer.DBType reports nothing), so a
    # played episode used to fail this check and go through full title
    # validation against an EPISODE title it could never match. Measured on
    # <коробка>: playing «Хождение по мукам» s1e1 correctly found tmdb=82195
    # by search, then rejected it here because "Хождение по мукам" (the show)
    # does not match "Добро пожаловать в Маргрейв"-style episode-name data -
    # and fell back to an unrelated OMDb title match instead.
    if dbtype in ('season', 'episode') or _is_episode_like(local):
        return False
    title = str(local.get('title') or local.get('tvshowtitle') or '').strip()
    if not title:
        return False
    return media_type in ('movie', 'tv') or dbtype in ('movie', 'tvshow') or str(local.get('file') or '').startswith('plugin://')


def _log_identity_reject(reason, title, model, match_score, target_year, data_year, extra=''):
    """One line per rejected provider object, naming the branch that dropped it."""
    try:
        log('identity reject: gate=_provider_identity_match reason=%s title=%s '
            'provider_title=%s score=%.2f year=%s/%s %s' % (
                reason, str(title)[:32],
                str((model or {}).get('title') or (model or {}).get('originaltitle') or '')[:32],
                match_score, target_year or '-', data_year or '-', extra), xbmc.LOGINFO)
    except Exception:
        pass


def _provider_identity_match(params, local, media_type, model, trusted_models=None):
    """Strict title/year match shared by TMDb, KinoPoisk and OMDb."""
    model = model or {}
    if not _identity_validation_required(local, media_type):
        return True, 1.0, False
    expected_type = _preferred_media_type(params or {}, local or {})
    provider_type = _model_media_type(model, media_type)
    if (expected_type in ('movie', 'tv') and provider_type in ('movie', 'tv') and
            expected_type != provider_type):
        # TMDb ids are not globally unique between movie and television.  A
        # stale ``tmdb_type=tv`` on an item from a /movies/ directory can point
        # to a perfectly valid but completely unrelated series with the same
        # numeric id.  Reject before title/year relaxation can accept it.
        return False, 0.0, False
    queries = list(_identity_queries(params or {}, local or {}, media_type))
    for trusted in (trusted_models or {}).values():
        for value in (
                (trusted or {}).get('title'),
                (trusted or {}).get('originaltitle'),
                (trusted or {}).get('tvshowtitle')):
            value = str(value or '').strip()
            key = _normal_title(value)
            if value and key and all(_normal_title(existing) != key for existing in queries):
                queries.append(value)
    names = [
        model.get('title'), model.get('originaltitle'), model.get('tvshowtitle'),
        model.get('nameRu'), model.get('nameEn'), model.get('nameOriginal'),
        model.get('Title'), model.get('original_title'), model.get('original_name'),
    ]
    names.extend(model.get('alternative_titles') or [])
    names = [str(value).strip() for value in names if str(value or '').strip()]
    scores = []
    exact_match = False
    for query in queries:
        for name in names:
            score, exact = _title_similarity(query, name)
            if exact:
                exact_match = True
                score += 1.0
            scores.append(score)
    match_score = max(scores or [0.0])
    target_year = _identity_target_year(params or {}, local or {}, trusted_models)
    data_year = safe_int(model.get('year')) or extract_year(
        model.get('premiered') or model.get('release_date') or model.get('first_air_date') or model.get('Year'))
    year_mismatch = bool(target_year and data_year and abs(target_year - data_year) > 1)
    primary_title = str((local or {}).get('title') or (params or {}).get('title') or '').strip()
    plot_conflict = _plot_conflict(
        (local or {}).get('plot') or (params or {}).get('plot'),
        model.get('plot') or model.get('Plot'))
    country_ok, source_countries, provider_countries = _country_identity_confirmed(params, local, model)
    if not country_ok and exact_match and not year_mismatch:
        # Countries disagree, but the title matches exactly and the year agrees.
        # That is two independent facts against one: co-productions are listed
        # differently by every database - the provider says Великобритания where
        # TMDb says US for the same film - and vetoing on that alone left rows
        # with no metadata at all. The veto stays for fuzzy matches below.
        try:
            log('provider identity: country_mismatch overridden by exact title+year '
                'title=%s source_country=%s provider_country=%s' % (
                    primary_title, ','.join(sorted(source_countries)) or '-',
                    ','.join(sorted(provider_countries)) or '-'), xbmc.LOGINFO)
        except Exception:
            pass
        country_ok = True
    if not country_ok:
        try:
            log('provider identity reject: country_mismatch title=%s source_country=%s provider_country=%s provider_title=%s' % (
                primary_title, ','.join(sorted(source_countries)) or '-',
                ','.join(sorted(provider_countries)) or '-',
                model.get('title') or model.get('originaltitle') or ''), xbmc.LOGWARNING)
        except Exception:
            pass
        return False, match_score, year_mismatch
    # A TV provider reports the show's original first-air year, while a plugin
    # can legitimately expose the current season/year and a paraphrased plot.
    # Exact title + exact type is therefore authoritative for series. This branch
    # intentionally precedes the one-word-title rule: "Босх", "Щит" and
    # "Грань" are exact one-word matches but often carry the current season
    # year rather than the provider's original first-air year.
    if (exact_match and expected_type == 'tv' and provider_type == 'tv'):
        # Exact title/type is not enough when the focused item carries a concrete
        # source year and the provider object has a different first-air year. This
        # is the proven false-positive path for same-title series collisions.
        if year_mismatch:
            _log_identity_reject('exact_tv_year_mismatch', primary_title, model,
                                 match_score, target_year, data_year)
        return (not year_mismatch), match_score, year_mismatch
    if _search_query_is_ambiguous(primary_title):
        # Any exact match from the complete trusted query set is sufficient. The
        # primary ListItem title may be original-language while params/translation
        # contains the exact localized name. Missing year data is neutral; a
        # decisive plot contradiction still rejects a same-title collision.
        compatible_year = bool(not target_year or not data_year or abs(target_year - data_year) <= 1)
        accepted = bool(exact_match and compatible_year and not plot_conflict)
        if not accepted:
            _log_identity_reject(
                'ambiguous_title', primary_title, model, match_score, target_year, data_year,
                'exact=%s compatible_year=%s plot_conflict=%s' % (
                    exact_match, compatible_year, plot_conflict))
        return accepted, match_score, year_mismatch
    # Year may reject a candidate, but must never rescue a weak title match.
    accepted = bool(match_score >= 0.72 and not year_mismatch)
    if not accepted:
        _log_identity_reject('score_or_year', primary_title, model, match_score,
                             target_year, data_year, 'year_mismatch=%s' % year_mismatch)
    return accepted, match_score, year_mismatch


def _explicit_adult(value):
    value = value or {}
    raw = value.get('adult')
    if isinstance(raw, str):
        raw = raw.strip().lower() in ('1', 'true', 'yes')
    if raw:
        return True
    raw = value.get('isAdult')
    if isinstance(raw, str):
        raw = raw.strip().lower() in ('1', 'true', 'yes')
    return bool(raw)


def _merge_missing(base, extra):
    if not extra:
        return base
    for key, value in extra.items():
        if key in ('art', 'ratings', 'crew', 'fanart_art'):
            continue
        if key == 'cast':
            if not base.get('cast') and value:
                base['cast'] = value
            continue
        if base.get(key) in (None, '', 0, [], {}):
            if value not in (None, '', 0, [], {}):
                base[key] = value
    for key, value in (extra.get('art') or {}).items():
        if value:
            base.setdefault('art', {}).setdefault(key, value)
    for key, value in (extra.get('ratings') or {}).items():
        if value:
            base.setdefault('ratings', {}).setdefault(key, value)
    for key, rows in (extra.get('crew') or {}).items():
        if rows and not (base.setdefault('crew', {}).get(key)):
            base['crew'][key] = rows
    for key, urls in (extra.get('fanart_art') or {}).items():
        if urls:
            base.setdefault('fanart_art', {}).setdefault(key, urls)
    return base


def _ordered_sources(selected, default_order):
    if selected and selected != 'auto' and selected in default_order:
        return [selected] + [item for item in default_order if item != selected]
    return list(default_order)


def _clearlogo_candidates(source, model):
    model = model or {}
    rows = list(((model.get('art_candidates') or {}).get('clearlogo') or []))
    output = []
    seen = set()
    for row in rows:
        row = dict(row or {})
        url = str(row.get('url') or '')
        if not url or url in seen:
            continue
        seen.add(url)
        row['url'] = url
        row['source'] = source
        output.append(row)
    fallback = str((model.get('art') or {}).get('clearlogo') or '')
    if fallback and fallback not in seen:
        output.append({
            # Язык неизвестен - и допущение «раз от Кинопоиска, значит
            # русский» здесь стояло ровно до 09.09.2026. Замер на .30: у 1-й и
            # 4-й серии «В Филадельфии всегда солнечно» кандидатов не было
            # вовсе, источником стоял kinopoisk, и его картинка
            # (cSgCL9wwFUzY1WVuUHS1e3axetO.png - английский логотип, он же
            # лежит среди английских кандидатов TMDb) уходила в показ как
            # «русская». Владелец увидел это как «на первом и четвёртом
            # эпизодах английское clear logo, на остальных русское».
            #
            # Без языка кандидат не может выиграть отбор по языку интерфейса, а
            # значит логотип берётся у сериала или собирается из текста - и
            # одинаков у всех серий.
            'url': fallback,
            'language': '',
            'source': source,
        })
    return output


def _best_clearlogo_candidate(art_models, art_order, max_language_rank=None):
    candidates = []
    for source_index, source in enumerate(art_order):
        for row_index, row in enumerate(_clearlogo_candidates(source, art_models.get(source) or {})):
            rank = language_rank(row.get('language'))
            if max_language_rank is not None and rank > max_language_rank:
                continue
            candidates.append((
                rank,
                source_index,
                -safe_float(row.get('vote_average')),
                -safe_int(row.get('vote_count')),
                -safe_int(row.get('likes')),
                row_index,
                row,
            ))
    return min(candidates, default=(None, None, None, None, None, None, {}))[-1]




def _pick_clearlogo(rows, source_order=()):
    """Выбор логотипа среди кандидатов: язык интерфейса, затем оценки.

    Правило живёт здесь и только здесь, потому что путей показа два: сборка
    модели у провайдеров и показ УЖЕ КЭШИРОВАННОЙ строки. Пока правило было
    только в сборке, любая правка логотипов требовала сброса кэша метаданных
    отпечатком - а это, замер 08.09.2026, пять минут ожидания на каждой
    перезагрузке: владелец увидел «Clear logo раньше грузились мгновенно,
    сейчас - последними из всех данных и арта». Кандидаты в кэше лежат, значит
    выбор можно сделать заново, ничего не сбрасывая.
    """
    preferred = language_code()
    if not preferred:
        return {}
    order = list(source_order or [])
    candidates = []
    for row_index, row in enumerate(rows or []):
        if language_code((row or {}).get('language')) != preferred:
            continue
        # SVG Kodi не рисует: такой логотип - пустое место вместо названия («Искусственный
        # интеллект», TMDb .svg, .20, 24.11.2026); без него показывается название текстом
        if str((row or {}).get('url') or '').lower().split('?')[0].endswith('.svg'):
            continue
        source = str((row or {}).get('source') or '')
        source_index = order.index(source) if source in order else len(order)
        candidates.append((
            source_index,
            -safe_float(row.get('vote_average')),
            -safe_int(row.get('vote_count')),
            -safe_int(row.get('likes')),
            row_index,
            row,
        ))
    return min(candidates, default=(None, None, None, None, None, {}))[-1]


def _best_preferred_clearlogo_candidate(art_models, art_order):
    """Return only a clearlogo that is safe to show in the configured UI language.

    TMDb filtered image responses may temporarily expose an English/fallback logo
    as neutral before the complete image list relabels it. For non-English UI this
    caused a visible English clearlogo flash before the final title fallback. The
    Home title/logo layer must not show uncertain or foreign logos for media items.
    """
    preferred = language_code()
    if not preferred:
        return _best_clearlogo_candidate(art_models, art_order)
    rows = []
    for source in art_order:
        rows.extend(_clearlogo_candidates(source, art_models.get(source) or {}))
    return _pick_clearlogo(rows, art_order)


def _clearlogo_from_cached(model):
    """Пересобрать выбор логотипа у кэшированной строки - по тем же правилам.

    Кандидаты лежат в самой записи кэша (art_candidates.clearlogo), поэтому
    выбор делается без единого запроса в сеть. Кандидатов нет - запись не
    трогаем: значит выбирать не из чего, и прежний логотип остаётся как был.
    """
    if not isinstance(model, dict):
        return model
    # Логотип, СОБРАННЫЙ ИЗ ТЕКСТА, лежит в записи кэша готовым, и до
    # 09.09.2026 он оставался таким, каким его собрали: у серии - «Эпизод 1».
    # Пересобираем его по тому же правилу, что и везде (_header_title): это
    # местная отрисовка, без сети, и запись кэша от неё не портится.
    if str(model.get('clearlogo_source') or '') == 'generated':
        header = _header_title(model)
        if header:
            regenerated = request_title_logo(header, language_code())
            if regenerated and regenerated != str((model.get('art') or {}).get('clearlogo') or ''):
                art = dict(model.get('art') or {})
                art['clearlogo'] = regenerated
                model['art'] = art
                model['_clearlogo_safe'] = True
    rows = ((model.get('art_candidates') or {}).get('clearlogo') or [])
    if not rows:
        return model
    order = ['tmdb', 'kinopoisk', 'local', 'imdb']
    selected = config.artwork_source()
    if selected and selected != 'auto':
        order = _ordered_sources(selected, ['fanart', 'tmdb', 'kinopoisk', 'imdb']) + ['local']
    chosen = _pick_clearlogo(rows, order)
    if not str((chosen or {}).get('url') or ''):
        # У серии своих кандидатов может не быть вовсе - тогда логотип берётся
        # у СЕРИАЛА, тем же отбором. Замер на .30 09.09.2026: у части серий
        # «Филадельфии» кандидатов ноль, а у сериала их 34, среди них русский.
        # Подробности сериала берутся из кэша метаданных, без сети.
        show_id = safe_int(model.get('tvshow_tmdb_id') or model.get('tmdb_id'))
        if show_id and str(model.get('dbtype') or '') in ('episode', 'season'):
            try:
                show_meta = normalize_tmdb(tmdb.details('tv', show_id), 'tv') or {}
            except Exception:
                show_meta = {}
            show_rows = ((show_meta.get('art_candidates') or {}).get('clearlogo') or [])
            if show_rows:
                chosen = _pick_clearlogo(list(rows) + list(show_rows), order)
    url = str((chosen or {}).get('url') or '')
    if not url:
        # выбрать не из чего; прежний логотип SVG (Kodi его не рисует) снимается - название текстом
        art = dict(model.get('art') or {})
        if str(art.get('clearlogo') or '').lower().split('?')[0].endswith('.svg'):
            art.pop('clearlogo', None)
            model['art'] = art
        return model
    art = dict(model.get('art') or {})
    if str(art.get('clearlogo') or '') == url:
        return model
    art['clearlogo'] = url
    model['art'] = art
    model['clearlogo_language'] = language_code(chosen.get('language'))
    model['clearlogo_source'] = chosen.get('source') or ''
    model['_clearlogo_safe'] = True
    return model

def _trailer_candidates(source, model):
    model = model or {}
    rows = list(model.get('trailer_candidates') or [])
    output = []
    seen = set()
    for row in rows:
        row = dict(row or {})
        url = str(row.get('url') or '')
        if not url or url in seen or cache.is_trailer_failed(url):
            continue
        seen.add(url)
        row['url'] = url
        row['source'] = source
        output.append(row)
    fallback = str(model.get('trailer') or '')
    if fallback and fallback not in seen and not cache.is_trailer_failed(fallback):
        output.append({
            'url': fallback,
            'language': model.get('trailer_language') or ('ru' if source == 'kinopoisk' else 'zz'),
            'official': bool(model.get('trailer_official')),
            'type': 'Trailer',
            'source': source,
        })
    return output


def _best_trailer_candidate(models, source_order, max_language_rank=None, min_language_rank=None):
    candidates = []
    for source_index, source in enumerate(source_order):
        for row_index, row in enumerate(_trailer_candidates(source, models.get(source) or {})):
            rank = trailer_rank(row)
            if max_language_rank is not None and rank[0] > max_language_rank:
                continue
            if min_language_rank is not None and rank[0] < min_language_rank:
                continue
            candidates.append((
                rank[0], rank[1], rank[2], source_index,
                -safe_int(row.get('size')), row_index, row,
            ))
    return min(candidates, default=(None, None, None, None, None, None, {}))[-1]


def _has_preferred_clearlogo(models):
    preferred = language_code()
    if not preferred:
        return False
    for source, model in (models or {}).items():
        for row in _clearlogo_candidates(source, model):
            if language_code(row.get('language')) == preferred:
                return True
    return False


def _has_foreign_clearlogo(models):
    for source, model in (models or {}).items():
        for row in _clearlogo_candidates(source, model):
            if language_rank(row.get('language')) >= 2:
                return True
    return False


def _has_preferred_official_trailer(models):
    preferred = language_code()
    if not preferred:
        return False
    for source, model in (models or {}).items():
        for row in _trailer_candidates(source, model):
            if (language_code(row.get('language')) == preferred and
                    bool(row.get('official')) and
                    str(row.get('type') or '').lower() == 'trailer'):
                return True
    return False

def _summarize_clearlogo_candidates(models, source_order):
    preferred = language_code()
    parts = []
    for source in source_order:
        rows = _clearlogo_candidates(source, models.get(source) or {})
        if not rows:
            continue
        preferred_count = 0
        neutral_count = 0
        foreign_count = 0
        for row in rows:
            lang = language_code(row.get('language'))
            if preferred and lang == preferred:
                preferred_count += 1
            elif not lang:
                neutral_count += 1
            else:
                foreign_count += 1
        parts.append('%s:%d/%d/%d' % (source, preferred_count, neutral_count, foreign_count))
    return ','.join(parts) or 'none'


def _tmdb_logo_rows_debug(images, limit=20):
    rows = list((images or {}).get('logos') or [])
    output = []
    for row in rows[:max(1, safe_int(limit, 20))]:
        lang = language_code(row.get('iso_639_1') or row.get('language')) or 'null'
        path = str(row.get('file_path') or '').strip()
        output.append('%s:%s' % (lang, path or '-'))
    if len(rows) > limit:
        output.append('+%d' % (len(rows) - limit))
    return '|'.join(output) or 'none'


def _summarize_trailer_candidates(models, source_order):
    preferred = language_code()
    parts = []
    for source in source_order:
        rows = _trailer_candidates(source, models.get(source) or {})
        if not rows:
            continue
        preferred_count = 0
        neutral_count = 0
        foreign_count = 0
        preferred_official = 0
        for row in rows:
            lang = language_code(row.get('language'))
            kind = str(row.get('type') or '').lower()
            official = bool(row.get('official'))
            if preferred and lang == preferred:
                preferred_count += 1
                if official and kind == 'trailer':
                    preferred_official += 1
            elif not lang:
                neutral_count += 1
            else:
                foreign_count += 1
        parts.append('%s:%d/%d/%d(o%d)' % (source, preferred_count, neutral_count, foreign_count, preferred_official))
    return ','.join(parts) or 'none'


def _local_art(meta):
    art = dict(meta.get('art') or {})
    if meta.get('fanart') and not art.get('fanart'):
        art['fanart'] = meta.get('fanart')
    if meta.get('thumbnail') and not art.get('thumb'):
        art['thumb'] = meta.get('thumbnail')
    return {k: v for k, v in art.items() if v}


def _local_to_model(meta, dbtype='', dbid=0):
    dbtype = normalize_dbtype(dbtype)
    uniqueid = meta.get('uniqueid') or {}
    cast = []
    for row in meta.get('cast') or []:
        if isinstance(row, dict):
            cast.append({'name': row.get('name') or '', 'role': row.get('role') or '', 'thumb': row.get('thumbnail') or '', 'id': ''})
    directors = [{'name': x, 'role': 'Director', 'job': 'Director', 'thumb': '', 'id': ''} for x in meta.get('director') or []]
    writers = [{'name': x, 'role': 'Writer', 'job': 'Writer', 'thumb': '', 'id': ''} for x in meta.get('writer') or []]
    premiered = meta.get('premiered') or meta.get('firstaired') or ''
    model = {
        'dbid': safe_int(dbid), 'dbtype': dbtype, 'media_type': tmdb_type_from_dbtype(dbtype) or dbtype,
        'tmdb_type': tmdb_type_from_dbtype(dbtype), 'tmdb_id': _valid_tmdb_id(_unique_id(uniqueid, 'tmdb')),
        'imdb_id': _unique_id(uniqueid, 'imdb'), 'tvdb_id': _unique_id(uniqueid, 'tvdb'),
        'kinopoisk_id': safe_int(_unique_id(uniqueid, 'kinopoisk') or _unique_id(uniqueid, 'kp')),
        'title': meta.get('title') or meta.get('label') or meta.get('showtitle') or '',
        'originaltitle': meta.get('originaltitle') or '', 'tvshowtitle': meta.get('showtitle') or '',
        'plot': meta.get('plot') or '', 'tagline': meta.get('tagline') or '', 'premiered': premiered,
        'year': safe_int(meta.get('year')) or extract_year(premiered), 'runtime': safe_int(meta.get('runtime')),
        'mpaa': meta.get('mpaa') or '', 'rating': safe_float(meta.get('rating')), 'votes': safe_int(meta.get('votes')),
        'userrating': safe_int(meta.get('userrating')), 'top250': safe_int(meta.get('top250')),
        'playcount': safe_int(meta.get('playcount')), 'lastplayed': meta.get('lastplayed') or '', 'dateadded': meta.get('dateadded') or '',
        'genre': meta.get('genre') or [], 'country': meta.get('country') or [], 'studio': meta.get('studio') or [],
        'status': meta.get('status') or '', 'trailer': meta.get('trailer') or '', 'file': meta.get('file') or '',
        'art': _local_art(meta), 'cast': cast, 'crew': {'director': directors, 'writer': writers},
        'season': safe_int(meta.get('season')), 'episode': safe_int(meta.get('episode')),
        'ratings': {'tmdb': {'rating': safe_float(meta.get('rating')), 'votes': safe_int(meta.get('votes'))}},
    }
    if dbtype == 'episode' and meta.get('tvshowid'):
        show = get_details(meta.get('tvshowid'), 'tvshow')
        show_ids = show.get('uniqueid') or {}
        model['tvshow_tmdb_id'] = safe_int(_unique_id(show_ids, 'tmdb'))
        model['tvshowtitle'] = model.get('tvshowtitle') or show.get('title') or ''
    return model


# Every label this model reads, so it can be asked for in ONE request.
# Seventy-five labels at twenty milliseconds each is a second and a half
# per focused row; asked together it is one round trip.
_MODEL_LABELS = (
    'Art(clearart)', 'Art(clearlogo)', 'Art(fanart)', 'Art(landscape)',
    'Art(poster)', 'Art(thumb)', 'Country', 'DBID', 'DBType', 'Date',
    'Director', 'Episode', 'FileNameAndPath', 'FolderPath', 'Genre',
    'IMDBNumber', 'Icon', 'Label', 'OriginalTitle', 'Plot', 'Premiered',
    'Property(Countries)', 'Property(Country)',
    'Property(FilmixIdentityRejected)', 'Property(FilmixSourceCountries)',
    'Property(FilmixSourceCountry)', 'Property(FilmixSourceYear)',
    'Property(Genre)', 'Property(IMDb_ID)', 'Property(Kinopoisk_ID)',
    'Property(Premiered)', 'Property(ReleaseDate)',
    'Property(SourceCountries)', 'Property(SourceCountry)',
    'Property(SourceYear)', 'Property(TMDB_ID)', 'Property(TMDb_ID)',
    'Property(Year)', 'Property(countries)', 'Property(country)',
    'Property(genre)', 'Property(imdb)', 'Property(imdb_id)',
    'Property(kinopoisk)', 'Property(kinopoisk_id)', 'Property(kp)',
    'Property(kp_id)', 'Property(original_title)', 'Property(premiered)',
    'Property(release_date)', 'Property(resolved_year)',
    'Property(source_countries)', 'Property(source_country)',
    'Property(source_year)', 'Property(tmdb)', 'Property(tmdb_id)',
    'Property(tmdb_type)', 'Property(tvshow.tmdb_id)',
    'Property(tvshow_tmdb_id)', 'Property(year)', 'Season', 'Status',
    'Studio', 'TVShowTitle', 'Tagline', 'Title', 'Trailer',
    'UniqueID(imdb)', 'UniqueID(kinopoisk)', 'UniqueID(kp)',
    'UniqueID(tmdb)', 'UniqueID(tvdb)', 'UniqueID(tvshow.tmdb)', 'Writer',
    'Year',
)


def _release_details_of_row(container_id=0):
    """Сведения о релизе одной строкой: «BDRip · 745MB · 7 сид. · AlexFilm».

    Их составляет сам плагин-источник (plugin.video.RuTor, skin_meta.py): что
    за раздача, сколько весит, сколько сидов, чья озвучка. Скин это только
    показывает - разбирать название раздачи второй раз незачем.

    Владелец 11.09.2026, глядя на снимки списка релизов: «не вижу нигде на
    скриншотах этих данных». И правда: в метку строки они попадали, а вид «ряд
    постеров» метки не рисует вовсе. Поэтому строка со сведениями показывается
    в инфопанели, под инфострокой, и видна в любом виде.
    """
    try:
        return str(current_label('Property(sublime_release_details)', container_id) or '').strip()
    except Exception:
        return ''


def _strip_formatting(text):
    try:
        from resources.lib.hub import identity as _identity
        return _identity.strip_formatting(text)
    except Exception:
        return text


def _release_of_row(container_id=0):
    """Качество релиза строки: («WEB-DLRip», «1080»).

    09.09.2026 владелец: «у филмикса, rutor и наверняка других похожих плагинов
    в строках названий есть информация о качестве и виде релиза, которую мы
    сейчас вырезаем, чтобы не портить названия. Надо предусмотреть механизм,
    чтобы из этой информации собирались графические иконки … и добавлялись в
    инфостроку».

    Разбор один на весь скин и живёт там же, где срезание скобки с названия
    (hub/identity.release_info). Здесь только чтение ярлыка строки: у filmix и
    RuTor скобка стоит в самом ярлыке, а к моменту публикации название уже
    очищено, и взять её оттуда было бы неоткуда.
    """
    try:
        from resources.lib.hub import identity as _identity
    except Exception:
        return '', ''
    try:
        # Наши полосы отдают готовое: в их ярлыке скобки уже нет - её срезала
        # выборка каталога, она же и запомнила разбор (hub/catalog.py).
        ready_quality = current_label('Property(sublime_release_quality)', container_id)
        ready_resolution = current_label('Property(sublime_release_resolution)', container_id)
        if ready_quality or ready_resolution:
            return str(ready_quality or ''), str(ready_resolution or '')
        raw = (current_label('Label', container_id)
               or current_label('Title', container_id) or '')
        return _identity.release_info(raw)
    except Exception:
        return '', ''


def local_model_from_current(container_id=0):
    prefetch_labels(_MODEL_LABELS, container_id)
    pvr = _pvr_context(container_id)
    if pvr:
        art = {
            'poster': current_label('Art(poster)', container_id) or current_label('Icon', container_id),
            'fanart': current_label('Art(fanart)', container_id),
            'landscape': current_label('Art(landscape)', container_id),
            'clearlogo': current_label('Art(clearlogo)', container_id),
            'thumb': current_label('Art(thumb)', container_id),
        }
        premiered = current_label('Premiered', container_id) or current_label('Date', container_id)
        return {
            '_is_pvr': True,
            '_pvr_lookup_candidate': bool(pvr.get('lookup_candidate')),
            'dbid': 0,
            'dbtype': '',
            'media_type': '',
            'tmdb_type': '',
            'title': pvr.get('title') or '',
            'plot': pvr.get('plot') or '',
            'premiered': premiered,
            'year': safe_int(current_label('Year', container_id)) or extract_year(premiered),
            'genre': split_people(current_label('Genre', container_id)),
            'country': split_people(current_label('Country', container_id)),
            'studio': split_people(current_label('Studio', container_id)),
            'file': pvr.get('path') or '',
            'art': {k: v for k, v in art.items() if v},
            'cast': [],
            'crew': {'director': [], 'writer': []},
        }
    dbtype = normalize_dbtype(current_label('DBType', container_id))
    dbid = safe_int(current_label('DBID', container_id))
    if dbid and dbtype:
        meta = get_details(dbid, dbtype)
        if meta:
            return _local_to_model(meta, dbtype, dbid)
    art = {
        'poster': current_label('Art(poster)', container_id) or current_label('Icon', container_id),
        'fanart': current_label('Art(fanart)', container_id), 'landscape': current_label('Art(landscape)', container_id),
        'clearlogo': current_label('Art(clearlogo)', container_id), 'clearart': current_label('Art(clearart)', container_id),
        'thumb': current_label('Art(thumb)', container_id),
    }
    premiered = (current_label('Premiered', container_id) or current_label('Property(Premiered)', container_id) or
                 current_label('Property(premiered)', container_id) or current_label('Property(ReleaseDate)', container_id) or
                 current_label('Property(release_date)', container_id) or current_label('Date', container_id))
    file_path = current_label('FileNameAndPath', container_id) or current_label('FolderPath', container_id)
    source_media_type = _path_media_type(file_path)
    source_path_year = _path_year(file_path)
    return {
        'dbid': dbid, 'dbtype': dbtype, 'media_type': tmdb_type_from_dbtype(dbtype),
        'tmdb_type': current_label('Property(tmdb_type)', container_id) or tmdb_type_from_dbtype(dbtype),
        'source_media_type': source_media_type, 'source_path_year': source_path_year,
        'tmdb_id': _valid_tmdb_id(
            current_label('UniqueID(tmdb)', container_id) or current_label('Property(tmdb_id)', container_id) or
            current_label('Property(TMDB_ID)', container_id) or current_label('Property(TMDb_ID)', container_id) or
            current_label('Property(tmdb)', container_id)),
        'imdb_id': (current_label('UniqueID(imdb)', container_id) or current_label('IMDBNumber', container_id) or
                    current_label('Property(imdb_id)', container_id) or current_label('Property(IMDb_ID)', container_id) or
                    current_label('Property(imdb)', container_id)),
        'kinopoisk_id': safe_int(
            current_label('UniqueID(kinopoisk)', container_id) or current_label('UniqueID(kp)', container_id) or
            current_label('Property(kinopoisk_id)', container_id) or current_label('Property(Kinopoisk_ID)', container_id) or
            current_label('Property(kp_id)', container_id) or current_label('Property(kinopoisk)', container_id) or
            current_label('Property(kp)', container_id)),
        # A season/episode row carries its SERIES' identity, and Filmix already
        # publishes it - as uniqueid tvshow.tmdb plus Property(tvshow.tmdb_id)
        # (plugin.video.filmix, listitems.py: _fast_cache_unique_ids /
        # _fast_cache_widget_properties). Nothing here ever read it, so the
        # skin re-derived identity from the episode row itself and could land
        # anywhere: measured on <коробка> with Filmix 2.2.59.56.8, a
        # «Безумцы» episode was published as "Harry Potter and the Deathly
        # Hallows: Part 1" and the season inherited its clearlogo.
        'tvshow_tmdb_id': _valid_tmdb_id(
            current_label('UniqueID(tvshow.tmdb)', container_id) or
            current_label('Property(tvshow.tmdb_id)', container_id) or
            current_label('Property(tvshow_tmdb_id)', container_id)),
        # Filmix says so itself when its own resolver refused a candidate;
        # inventing an identity after that is how a rejected show turns into an
        # unrelated film rather than into no metadata at all.
        'identity_rejected': bool(str(current_label('Property(FilmixIdentityRejected)', container_id) or '').strip().lower()
                                  in ('1', 'true', 'yes')),
        # Заголовок - без разметки Kodi: «[B]Плейлисты[/B]» у папок YouTube
        # стоял на экране знаками (hub/identity.strip_formatting).
        'tvdb_id': current_label('UniqueID(tvdb)', container_id),
        'title': _strip_formatting(current_label('Title', container_id) or current_label('Label', container_id)),
        'originaltitle': current_label('OriginalTitle', container_id) or current_label('Property(original_title)', container_id),
        'tvshowtitle': current_label('TVShowTitle', container_id), 'plot': current_label('Plot', container_id), 'tagline': current_label('Tagline', container_id),
        'premiered': premiered, 'year': (safe_int(current_label('Property(FilmixSourceYear)', container_id)) or
                                           safe_int(current_label('Property(SourceYear)', container_id)) or
                                           safe_int(current_label('Property(source_year)', container_id)) or
                                           safe_int(current_label('Year', container_id)) or
                                           safe_int(current_label('Property(Year)', container_id)) or
                                           safe_int(current_label('Property(year)', container_id)) or
                                           safe_int(current_label('Property(resolved_year)', container_id)) or
                                           extract_year(premiered)),
        'source_year': (safe_int(current_label('Property(FilmixSourceYear)', container_id)) or
                        safe_int(current_label('Property(SourceYear)', container_id)) or
                        safe_int(current_label('Property(source_year)', container_id))),
        'genre': split_people(current_label('Genre', container_id) or current_label('Property(Genre)', container_id) or current_label('Property(genre)', container_id)),
        'country': split_people(current_label('Property(FilmixSourceCountry)', container_id) or
                                current_label('Property(FilmixSourceCountries)', container_id) or
                                current_label('Property(SourceCountry)', container_id) or
                                current_label('Property(SourceCountries)', container_id) or
                                current_label('Property(source_country)', container_id) or
                                current_label('Property(source_countries)', container_id) or
                                current_label('Country', container_id) or current_label('Property(Country)', container_id) or
                                current_label('Property(country)', container_id) or current_label('Property(Countries)', container_id) or
                                current_label('Property(countries)', container_id)),
        'source_country': split_people(current_label('Property(FilmixSourceCountry)', container_id) or
                                       current_label('Property(FilmixSourceCountries)', container_id) or
                                       current_label('Property(SourceCountry)', container_id) or
                                       current_label('Property(SourceCountries)', container_id) or
                                       current_label('Property(source_country)', container_id) or
                                       current_label('Property(source_countries)', container_id)),
        'studio': split_people(current_label('Studio', container_id)), 'status': current_label('Status', container_id),
        'trailer': current_label('Trailer', container_id), 'file': file_path,
        'art': {k: v for k, v in art.items() if v}, 'cast': [], 'crew': {
            'director': [{'name': x, 'role': 'Director', 'job': 'Director', 'thumb': '', 'id': ''} for x in split_people(current_label('Director', container_id))],
            'writer': [{'name': x, 'role': 'Writer', 'job': 'Writer', 'thumb': '', 'id': ''} for x in split_people(current_label('Writer', container_id))],
        }, 'release_quality': _release_of_row(container_id)[0],
        'release_resolution': _release_of_row(container_id)[1],
        'release_details': _release_details_of_row(container_id),
        'season': safe_int(current_label('Season', container_id)), 'episode': safe_int(current_label('Episode', container_id)),
    }


# Метки о том, что играет. Один пакет вместо девятнадцати отдельных вопросов.
#
# ЗАЧЕМ. read_label спрашивает интерфейс по одной метке за раз, и каждый вопрос
# - это отдельный вызов через JSON-RPC. Отпечаток плеера собирался из девяти
# таких вопросов и считался ЗАНОВО каждые 0.75 с, пока идёт воспроизведение, а
# у PVR каждая метка VideoPlayer.* идёт через клиент телегида. Замер на .20
# 06.09.2026: стадия «плеер-свойства» встретилась в журнале 43 раза со средним
# 340 мс - почти половина ядра, потраченная на повторные вопросы об одном и том
# же. Владелец видел это как «долго включается канал, лагает».
#
# Пакет складывается в общий кеш меток на такт (read_labels), поэтому и модель
# плеера ниже собирается уже из памяти, не спрашивая ничего заново.
_PLAYER_LABELS = (
    'VideoPlayer.DBType', 'VideoPlayer.DBID', 'VideoPlayer.UniqueID(tmdb)',
    'VideoPlayer.UniqueID(kinopoisk)', 'VideoPlayer.UniqueID(kp)',
    'VideoPlayer.IMDBNumber', 'Player.FilenameAndPath',
    'VideoPlayer.FilenameAndPath', 'VideoPlayer.Title', 'Player.Title',
    'VideoPlayer.TVShowTitle', 'VideoPlayer.Season', 'VideoPlayer.Episode',
    'VideoPlayer.Premiered', 'VideoPlayer.Year', 'VideoPlayer.Plot',
    'VideoPlayer.Genre', 'VideoPlayer.Studio', 'VideoPlayer.Director',
    'VideoPlayer.Writer',
)


def local_model_from_player():
    # Тот же пакет, что у отпечатка: внутри одного такта это попадание в кеш, а
    # если модель зовут первой - один запрос вместо двадцати.
    read_labels(_PLAYER_LABELS)
    dbtype = normalize_dbtype(read_label('VideoPlayer.DBType'))
    dbid = safe_int(read_label('VideoPlayer.DBID'))
    if dbid and dbtype:
        meta = get_details(dbid, dbtype)
        if meta:
            model = _local_to_model(meta, dbtype, dbid)
            model['player'] = True
            return model
    premiered = read_label('VideoPlayer.Premiered')
    # The playing file, and what it says about the item. The container model has
    # carried this for a long time; the player model did not, and without it
    # _preferred_media_type() had nothing to work from once Kodi reported no
    # DBType - which it never does for plugin playback. Measured on
    # <коробка> with «Хождение по мукам» s1e1 playing: the identity search
    # ran as `multi` instead of `tv` and answered with the 1957 Soviet film
    # trilogy («Сёстры», «Восемнадцатый год», «Хмурое утро») rather than the
    # 2017 series, so no series clearlogo was ever published and the OSD drew
    # its text title instead.
    player_path = read_label('Player.FilenameAndPath') or read_label('VideoPlayer.FilenameAndPath') or ''
    return {
        'player': True, 'dbid': dbid, 'dbtype': dbtype, 'media_type': tmdb_type_from_dbtype(dbtype), 'tmdb_type': tmdb_type_from_dbtype(dbtype),
        'file': player_path, 'source_media_type': _path_media_type(player_path),
        'source_path_year': _path_year(player_path),
        'tmdb_id': _valid_tmdb_id(read_label('VideoPlayer.UniqueID(tmdb)')), 'imdb_id': read_label('VideoPlayer.IMDBNumber'),
        'kinopoisk_id': safe_int(read_label('VideoPlayer.UniqueID(kinopoisk)') or read_label('VideoPlayer.UniqueID(kp)')),
        'title': read_label('VideoPlayer.Title') or read_label('Player.Title'), 'tvshowtitle': read_label('VideoPlayer.TVShowTitle'),
        'plot': read_label('VideoPlayer.Plot'), 'premiered': premiered, 'year': safe_int(read_label('VideoPlayer.Year')) or extract_year(premiered),
        'genre': split_people(read_label('VideoPlayer.Genre')), 'studio': split_people(read_label('VideoPlayer.Studio')),
        'season': safe_int(read_label('VideoPlayer.Season')), 'episode': safe_int(read_label('VideoPlayer.Episode')),
        'art': {}, 'cast': [], 'crew': {
            'director': [{'name': x, 'role': 'Director', 'job': 'Director', 'thumb': '', 'id': ''} for x in split_people(read_label('VideoPlayer.Director'))],
            'writer': [{'name': x, 'role': 'Writer', 'job': 'Writer', 'thumb': '', 'id': ''} for x in split_people(read_label('VideoPlayer.Writer'))],
        }
    }


def _is_episode_like(local, params=None):
    """Whether this item is one episode/season of a series rather than a title.

    DBType alone is not enough: Kodi only fills VideoPlayer.DBType for library
    items, so plugin playback reports no type at all. Measured on <коробка>
    while «Хождение по мукам» s1e1 was playing - DBType empty, TVShowTitle
    «Хождение по мукам», Season 1, Episode 1 - and the identity chain therefore
    searched for the episode's own title, "Серия 1", found nothing, and the OSD
    fell back to text because no clearlogo was ever published. A series title
    plus an episode coordinate is an episode whatever DBType says.
    """
    local = local or {}
    params = params or {}
    dbtype = str(local.get('dbtype') or '').lower()
    if dbtype in ('season', 'episode'):
        return True
    show_title = str(local.get('tvshowtitle') or params.get('tvshowtitle') or '').strip()
    episode = safe_int(local.get('episode')) or safe_int(params.get('episode'))
    return bool(show_title and episode > 0)


def _identity_queries(params, local, media_type='', allow_original=True):
    show_title = str(local.get('tvshowtitle') or params.get('tvshowtitle') or '').strip()
    if _is_episode_like(local, params) and show_title:
        # An episode row's own title is a position, not an identity: Filmix
        # publishes "Серия 1" and the real name of the series next to it, in
        # TVShowTitle. Searching for the episode label is how a «Безумцы»
        # episode was identified as "Harry Potter and the Deathly Hallows:
        # Part 1" (measured on <коробка>, 2026-08-16: q='Серия 1', OMDb
        # answered, and the whole season inherited Harry Potter's clearlogo
        # while losing its own episode names and stills). Only the series
        # title can identify a season or an episode.
        values = [params.get('tvshowtitle'), local.get('tvshowtitle')]
        if allow_original:
            values.extend([params.get('originaltvshowtitle'), local.get('originaltvshowtitle')])
        values = [value for value in values if str(value or '').strip()]
    else:
        values = [params.get('query'), params.get('title'), local.get('title')]
        if allow_original:
            values.extend([params.get('originaltitle'), local.get('originaltitle')])
        if media_type == 'tv':
            values.extend([local.get('tvshowtitle'), params.get('tvshowtitle')])
    output = []
    seen = set()
    split = []
    for value in values:
        value = str(value or '').strip()
        # «Вернуться в 1988 / Отвечай, 1988»: HDRezka пишет в названии два перевода
        # через косую черту, и целиком такое название не находилось нигде
        # (.20, 15.11.2026: status=no_match). Каждая часть - отдельный запрос,
        # после названия целиком.
        split.append(value)
        if ' / ' in value:
            split.extend(part.strip() for part in value.split(' / ') if part.strip())
    for value in split:
        variants = [value]
        transliterated = _transliterate_title(value).strip()
        if transliterated and transliterated.casefold() != value.casefold():
            variants.append(transliterated)
        for variant in variants:
            key = _normal_title(variant)
            if variant and key and key not in seen:
                seen.add(key)
                output.append(variant)
    return output




def _kinopoisk_search(query, year='', media_type=''):
    """Поиск по Кинопоиску: сначала kinopoisk.dev, если у него есть ключ.

    07.09.2026 обнаружено при проверке на .30: подробности через kinopoisk.dev
    были проведены (201.0), а поиск - нет, и оба места искали только прежним
    API. А он в этот день отдавал HTTP 402 - суточные 500 запросов кончились.
    Значит номер фильма не находился вовсе, и введённый ключ kinopoisk.dev
    оставался без дела: подробности запрашивать было не по чему.

    Номера у обеих служб одни и те же - это один и тот же Кинопоиск, поэтому
    найденный здесь номер годится для подробностей через любой из них.
    """
    if kinopoisk_dev.available():
        rows = [kinopoisk_dev_to_legacy(row)
                for row in (kinopoisk_dev.search(query, year, media_type) or [])]
        rows = [row for row in rows if row]
        if rows:
            return rows
    if kinopoisk.available():
        return kinopoisk.search(query, year, media_type) or []
    return []


# Поля карточки Кинопоиска, которые второй API дополняет, если первый их не дал.
_KP_FILL_KEYS = ('logoUrl', 'imdbId')


def _resolve_kinopoisk(local, params, media_type, tmdb_id=0, imdb_id=''):
    kp_id = safe_int(params.get('kinopoisk_id') or params.get('kp_id') or local.get('kinopoisk_id'))
    if kp_id or not kinopoisk.available():
        return kp_id
    kp_id = _kp_identity_lookup(
        tmdb_id or params.get('tmdb_id') or local.get('tmdb_id'),
        imdb_id or params.get('imdb_id') or local.get('imdb_id'),
        media_type)
    if kp_id:
        return kp_id
    if local.get('identity_rejected'):
        return 0
    if params.get('kp_search') is False:
        # ФОНОВОМУ проходу поиск в Кинопоиске запрещён.
        #
        # Один неопознанный фильм стоит здесь не один запрос, а по одному на
        # каждый вариант названия из _identity_queries. Фоновый дописыватель
        # берёт десять строк в минуту (hub/builder.top_up_meta) и способен
        # сжечь суточную норму бесплатного ключа в 500 запросов за двадцать
        # минут - и жёг: 07.09.2026 к 07:36 утра на ключе стояло 504 запроса
        # из 500, при том что в живых журналах обеих коробок набиралось меньше
        # десятка (остальное унесло вращение журналов при перезапусках).
        #
        # Уже опознанные строки Кинопоиск отдаёт по кешу личности выше, и это
        # бесплатно; новые опознаются в тот момент, когда владелец на них
        # наведётся. Правило владельца от 06.09.2026: «Кинопоиск запрашивать
        # только ради рейтинга и того, чего не дал TMDb».
        return 0
    year = _identity_target_year(params, local) or ''
    rank_year = _identity_rank_year(params, local)
    for query in _identity_queries(params, local, media_type):
        rows = _kinopoisk_search(query, year, media_type)
        row = _best_row(rows, query, year, 'kinopoisk', source_countries=_local_country_codes(local),
                        rank_year=rank_year)
        kp_id = safe_int(row.get('filmId') or row.get('kinopoiskId')) if row else 0
        if kp_id:
            return kp_id
    return 0


def _prefetch_known_id_provider_cache(source, root_tmdb_id, imdb_id, kp_id_hint, media_type):
    """Warm api.get_json's response cache for a provider's known-id details
    call, using only plain values already resolved by the time this fires.

    This must never touch fetch_online_metadata's own local state (local,
    params, the nonlocal identity variables) - it exists specifically so the
    sequential provider chain in that function can stay completely
    unmodified. get_json's cache is a plain file keyed by URL, independent of
    any of that function's closures, so populating it early from a thread is
    safe: the later, unchanged sequential call either finds a warm cache (and
    returns exactly the data it would have fetched itself) or a cold one (and
    fetches exactly as it does today) - it can never change WHICH id gets
    accepted, rejected, merged or reported as adult, only whether that one
    call blocks on the network. Measured cold chain: 1.9-2.3s across three
    sequential requests (docs/PLAN_INSTANT_ART_2026-08-13.md section 7.1);
    this only ever targets sources after the first, since the first
    (typically tmdb) still resolves the ids this reads.

    Deliberately does not attempt the search-fallback path (no known id at
    all yet) - replicating that loop's ranking/retry/rejection logic in a
    second, thread-safe copy was assessed and rejected as more risk than this
    plan's "twice as fast" target is worth; see the same plan section.
    """
    try:
        if source == 'kinopoisk':
            if not kinopoisk.available():
                return
            kp_id = safe_int(kp_id_hint)
            if not kp_id:
                kp_id = _kp_identity_lookup(safe_int(root_tmdb_id), str(imdb_id or ''), media_type)
            if kp_id:
                kinopoisk.details(kp_id)
        elif source == 'imdb':
            if not config.use_omdb():
                return
            if str(imdb_id or '').strip().startswith('tt'):
                omdb.details(imdb_id=str(imdb_id).strip())
    except Exception as exc:
        log('provider prefetch warm failed source=%s: %s' % (source, exc), xbmc.LOGDEBUG)


def _fire_provider_cache_prefetch(metadata_order, first_source, root_tmdb_id, imdb_id, kp_id_hint, media_type):
    for later_source in metadata_order:
        if later_source == first_source:
            continue
        try:
            threading.Thread(
                target=_prefetch_known_id_provider_cache,
                args=(later_source, root_tmdb_id, imdb_id, kp_id_hint, media_type),
                daemon=True,
            ).start()
        except Exception as exc:
            log('provider prefetch spawn failed source=%s: %s' % (later_source, exc), xbmc.LOGDEBUG)


def _metadata_missing_fields(meta, media_type=''):
    """Return the minimal information fields still missing from a metadata model.

    This list intentionally controls only the *information-source* fallback chain.
    Artwork, ratings, cast and trailers have independent enrichment paths and do
    not force another information provider to be queried.
    """
    meta = meta or {}
    if media_type == 'person':
        return [] if (meta.get('title') and meta.get('plot')) else ['plot']
    missing = []
    if not str(meta.get('plot') or '').strip():
        missing.append('plot')
    if not (str(meta.get('premiered') or '').strip() or safe_int(meta.get('year'))):
        missing.append('date')
    if not (meta.get('genre') or meta.get('genres')):
        missing.append('genre')
    if not meta.get('country'):
        missing.append('country')
    return missing


# Whether the cursor has come to rest. Set by the service loop, read here - a
# plain boolean, never a GUI read, so any thread may look at it.
#
# It gates exactly ONE thing: the extra TMDb /images call that finds a localised
# clearlogo when the already-loaded data has none. Everything else - plot,
# ratings, cast, backgrounds - is fetched as before, because the owner's rule is
# that nothing else may wait. And even the logo waits only when it is NOT
# cached: the call below is first made cache-only, so a logo somebody has
# already fetched appears at once.
_FOCUS_SETTLED = [False]
# Per-thread permission to fetch a logo that is not cached.
#
# The rule the owner set is about the SCREEN: nothing waits except a logo, and
# only when it is missing from the cache. The rule was being applied to the
# warm-up thread as well, which is nonsense - that thread has no screen and no
# deadline, and it only ever runs while the cursor is moving, which is exactly
# when the gate says "not now". So the warm-up cached everything about a row
# except its logo, and every row still paid the fetch on focus. The gate stays
# for the focused path; the warm-up is allowed to do the one piece of work that
# makes a logo instant later.
_LOGO_FETCH = threading.local()
# Whether label reads on THIS thread should go out as one JSON-RPC batch.
#
# The direct API (xbmc.getInfoLabel) is the faster way to read a handful of
# labels and stays the default for the focused row. Warming is the opposite
# case: it reads a whole 75-label model per row, one blocking call at a time,
# and traced on .20 that came to roughly a second per row - which is what held
# the service loop for 2-4 s at a stretch. One batched request carries all of
# them in a single round trip.
_LABELS_BATCH = threading.local()


@contextlib.contextmanager
def labels_batch_scope(enabled=True):
    previous = getattr(_LABELS_BATCH, 'enabled', False)
    _LABELS_BATCH.enabled = bool(enabled)
    try:
        yield
    finally:
        _LABELS_BATCH.enabled = previous


def labels_batch_enabled():
    return bool(getattr(_LABELS_BATCH, 'enabled', False))


@contextlib.contextmanager
def logo_fetch_scope(allowed=True):
    previous = getattr(_LOGO_FETCH, 'allowed', False)
    _LOGO_FETCH.allowed = bool(allowed)
    try:
        yield
    finally:
        _LOGO_FETCH.allowed = previous


def logo_fetch_allowed():
    return bool(getattr(_LOGO_FETCH, 'allowed', False))


def set_focus_settled(value):
    _FOCUS_SETTLED[0] = bool(value)


def focus_settled():
    return bool(_FOCUS_SETTLED[0])


def fetch_online_metadata(params=None, local=None, cancel_check=None, base_callback=None):
    params = params or {}
    local = dict(local or {})

    def cancelled():
        try:
            return bool(cancel_check and cancel_check())
        except Exception:
            return False

    if not config.online_enabled() or not _metadata_available() or cancelled():
        return local

    media_type = _preferred_media_type(params, local)
    if media_type not in ('movie', 'tv', 'person'):
        media_type = 'tv' if local.get('dbtype') in ('tvshow', 'season', 'episode') else 'movie'
    feature_purpose = str(params.get('feature_purpose') or '').strip().lower()

    season = params.get('season') if params.get('season') not in (None, '') else local.get('season')
    episode = params.get('episode') if params.get('episode') not in (None, '') else local.get('episode')
    local_dbtype = str(local.get('dbtype') or '').lower()
    if local_dbtype == 'tvshow':
        season = None
        episode = None
    elif local_dbtype == 'season':
        episode = None
    elif local_dbtype == 'episode':
        if safe_int(episode) <= 0:
            episode = None
    elif safe_int(season) == 0 and safe_int(episode) == 0:
        season = None
        episode = None

    root_tmdb_id = _valid_tmdb_id(params.get('tmdb_id') or params.get('tmdbid') or local.get('tmdb_id'))
    if local.get('dbtype') == 'episode' and _valid_tmdb_id(local.get('tvshow_tmdb_id')):
        root_tmdb_id = _valid_tmdb_id(local.get('tvshow_tmdb_id'))
        media_type = 'tv'
    kp_id = safe_int(params.get('kinopoisk_id') or params.get('kp_id') or local.get('kinopoisk_id'))
    imdb_id = str(params.get('imdb_id') or local.get('imdb_id') or '').strip()
    explicit_tmdb_id = root_tmdb_id
    explicit_kp_id = kp_id
    explicit_imdb_id = imdb_id if imdb_id.startswith('tt') else ''

    source_models = {}
    source_raw = {}
    loaded_sources = set()
    source_purposes = {}
    # IMDb ids returned by an already strictly validated TMDb/KinoPoisk object
    # are a stronger identity link than comparing localized and English titles.
    trusted_imdb_ids = {}
    provider_retry_times = {}
    # One metadata pass must never request the same TMDb details twice. The
    # adult/identity safety gate runs before the normal source chain, so without
    # this local cache every valid explicit id caused two identical HTTP calls.
    tmdb_details_cache = {}

    def _tmdb_details_once(candidate_id):
        cache_key = (str(media_type), safe_int(candidate_id), str(season), str(episode))
        if cache_key not in tmdb_details_cache:
            tmdb_details_cache[cache_key] = tmdb.details(media_type, candidate_id, season, episode) or {}
        return tmdb_details_cache.get(cache_key) or {}

    def _note_provider_retry(provider):
        retry_at = provider_retry_at(provider)
        if retry_at > time.time():
            provider_retry_times[str(provider or '').lower()] = retry_at
        return retry_at

    def _attach_provider_retry(target):
        if target is not None:
            # Include any provider currently in transport-retry (not only the
            # manually noted ones), so a TLS/ASN1/connection failure on tmdb,
            # imdb, fanart, mdblist or omdb also marks this bundle non-cacheable
            # and the item is re-resolved instead of caching an empty result.
            times = dict(provider_retry_times)
            # Только поставщики личности и основных сведений. fanart, mdblist, OMDb - дополнения:
            # их сбой срывал запись полного ответа в кэш, и строка переспрашивалась по кругу
            # (аудит 22.11.2026); пустой логотип теперь сам перепроверяется через сутки.
            for _prov in ('tmdb', 'kinopoisk', 'imdb'):
                _ra = provider_retry_at(_prov)
                if _ra > time.time():
                    times[_prov] = _ra
            if times:
                target['_provider_retry_at'] = min(times.values())
                target['_provider_retry'] = ','.join(sorted(times))
        return target

    adult_blocked = False
    adult_blocked_provider = ''
    adult_blocked_model = {}
    # Filmix publishes FilmixIdentityRejected on a row whose identity its own
    # resolver refused (for «Безумцы» it names the rejected candidate, TMDb
    # 1104 / Mad Men). Starting the chain already rejected means the same thing
    # here as a rejection discovered mid-chain: trust no plugin-supplied id
    # bundle, and - see _blind_search_allowed below - do not go looking for a
    # replacement identity by title.
    identity_rejected = bool(local.get('identity_rejected'))

    def _blind_search_allowed():
        """Whether a title search may invent an identity for this row.

        It may not once the row is marked rejected. Measured on <коробка>:
        a «Безумцы» episode with no accepted id searched by title and came back
        as "Harry Potter and the Deathly Hallows: Part 1" (via OMDb) and then
        as the 2010 film «Безумцы» (via KinoPoisk), publishing a foreign
        clearlogo over the whole season. No metadata is the correct answer
        here; the series' own identity is Filmix's to resolve.
        """
        return not bool(local.get('identity_rejected'))

    def _mark_identity_rejected(provider='', identifier=''):
        """Distrust the complete plugin-supplied id bundle after one explicit mismatch."""
        nonlocal identity_rejected, root_tmdb_id, kp_id, imdb_id
        first_rejection = not identity_rejected
        identity_rejected = True
        root_tmdb_id = 0
        kp_id = 0
        imdb_id = ''
        local['_identity_rejected'] = True
        local['tmdb_id'] = 0
        local['kinopoisk_id'] = 0
        local['imdb_id'] = ''
        # Remote decoration remains blocked. The synchronous VCL.Widget.Poster
        # snapshot is handled separately by the fallback generator and is never
        # published as validated helper artwork.
        local['art'] = {}
        for key in (
                'fanart', 'landscape', 'poster', 'thumb', 'icon', 'clearlogo',
                'clearart', 'banner', 'keyart', 'discart'):
            local.pop(key, None)
        local['trailer'] = ''
        local['trailer_fallback'] = ''
        if first_rejection:
            log('provider=%s status=explicit_identity_bundle_rejected id=%s title=%s' % (
                provider or 'provider', identifier or '-',
                local.get('title') or params.get('title') or ''), xbmc.LOGWARNING)

    def _adult_blocked_result(provider='', model=None):
        safe = copy.deepcopy(local)
        safe['art'] = {}
        safe['trailer'] = ''
        safe['cast'] = []
        safe['crew'] = {'director': [], 'writer': []}
        safe['tmdb_id'] = 0
        safe['kinopoisk_id'] = 0
        safe['imdb_id'] = ''
        safe['_adult_blocked'] = True
        blocked_model = model or adult_blocked_model or {}
        blocked_provider = provider or adult_blocked_provider or 'provider'
        log('provider=%s status=adult_blocked title=%s year=%s' % (
            blocked_provider, blocked_model.get('title') or local.get('title') or '',
            blocked_model.get('year') or local.get('year') or ''), xbmc.LOGWARNING)
        return safe

    def _provider_match(model):
        return _provider_identity_match(params, local, media_type, model, source_models)

    def _accept_provider_model(provider, model, explicit=False):
        nonlocal adult_blocked, adult_blocked_provider, adult_blocked_model
        # Read the explicit adult flag before accepting identity. A mismatched
        # adult id is rejected and its attached art is distrusted, but it must
        # not classify the correctly named local item itself as adult content.
        is_adult = bool(config.hide_adult() and _explicit_adult(model))
        matched, match_score, year_mismatch = _provider_match(model)

        local_imdb = str(explicit_imdb_id or '').strip().lower()
        model_imdb = str((model or {}).get('imdb_id') or (model or {}).get('imdbID') or '').strip().lower()
        cross_id_match = bool(local_imdb.startswith('tt') and model_imdb == local_imdb)
        # Both explicit IDs can originate from the same incorrect plugin row. A
        # matching pair therefore supports identity but cannot override a weak title.
        if (cross_id_match and not matched and not year_mismatch and
                match_score >= 0.60 and not _search_query_is_ambiguous(
                    str(local.get('title') or params.get('title') or ''))):
            matched = True
            log('provider=%s status=supported_cross_id id=%s score=%.2f' % (
                provider, local_imdb, match_score), xbmc.LOGINFO)

        # A correct explicit TMDb id can land just below the normal 0.72 title
        # threshold after localization. Permit only the narrow 0.68-0.72 band,
        # and never let a matching year rescue an unrelated title. If both sides
        # expose a year it must match exactly for this relaxed explicit-id path.
        local_title = str(local.get('title') or params.get('title') or '')
        target_year = _identity_target_year(params, local)
        model_year = safe_int((model or {}).get('year')) or extract_year(
            (model or {}).get('premiered') or (model or {}).get('release_date') or
            (model or {}).get('first_air_date') or (model or {}).get('Year'))
        exact_year = bool(target_year and model_year and target_year == model_year)
        relaxed_year_ok = bool(not target_year or not model_year or exact_year)
        # Односложное название («Крепость»): номер TMDb дал сам плагин, год совпал точно и название
        # почти то же (0,9+) - принять. Правило односложных требует точного совпадения, и сербский
        # «Tvrđava» (2025) с номером от Filmix оставался без сведений при сходстве 0,93 (.30, 23.11.2026).
        if (explicit and provider == 'tmdb' and not matched and not is_adult and not year_mismatch
                and _search_query_is_ambiguous(local_title) and exact_year and match_score >= 0.9):
            matched = True
            log('provider=tmdb status=trusted_explicit_short_title score=%.2f title=%s' % (
                match_score, local_title), xbmc.LOGINFO)
        if (explicit and provider == 'tmdb' and not matched and not is_adult and
                not year_mismatch and not _search_query_is_ambiguous(local_title) and
                match_score >= 0.68 and relaxed_year_ok):
            matched = True
            log('provider=tmdb status=trusted_explicit_localized score=%.2f exact_year=%s title=%s' % (
                match_score, 'yes' if exact_year else 'no', local_title), xbmc.LOGINFO)

        if is_adult and matched:
            adult_blocked = True
            adult_blocked_provider = provider
            adult_blocked_model = dict(model or {})
            return False, match_score, year_mismatch
        if not matched or is_adult:
            return False, match_score, year_mismatch
        return True, match_score, year_mismatch

    def fetch_tmdb_details(candidate_id):
        if not (tmdb.available() and candidate_id):
            return {}
        data = _tmdb_details_once(candidate_id)
        if data:
            model = normalize_tmdb(data, media_type)
            matched, match_score, year_mismatch = _accept_provider_model(
                'tmdb', model, explicit=bool(explicit_tmdb_id and safe_int(candidate_id) == safe_int(explicit_tmdb_id)))
            if matched:
                return data
            if adult_blocked:
                return {'_sublime_adult_blocked': True}
            if explicit_tmdb_id and safe_int(candidate_id) == safe_int(explicit_tmdb_id):
                _mark_identity_rejected('tmdb', candidate_id)
            log('provider=tmdb status=id_mismatch id=%s title=%s expected=%s score=%.2f year_mismatch=%s adult=%s' % (
                candidate_id, model.get('title') or '',
                local.get('title') or params.get('title') or '', match_score,
                'yes' if year_mismatch else 'no',
                'yes' if _explicit_adult(model) else 'no'), xbmc.LOGWARNING)
        year = _identity_target_year(params, local) or ''
        rejected = set([safe_int(candidate_id)])
        for query in _identity_queries(params, local, media_type, allow_original=not identity_rejected):
            rows = (tmdb.search(media_type, query, year).get('results') or [])
            ranked = sorted(rows, key=lambda row: _score_row(query, year, row, 'tmdb'), reverse=True)
            for row in ranked[:5]:
                retry_id = _valid_tmdb_id(row.get('id')) if row else 0
                if not retry_id or retry_id in rejected:
                    continue
                rejected.add(retry_id)
                if not _search_row_is_safe(query, year, row, 'tmdb', _local_country_codes(local)):
                    continue
                retry_data = _tmdb_details_once(retry_id)
                if not retry_data:
                    continue
                retry_model = normalize_tmdb(retry_data, media_type)
                matched, retry_score, year_mismatch = _accept_provider_model('tmdb', retry_model)
                if matched:
                    return {'_sublime_resolved_id': retry_id, '_sublime_data': retry_data}
                if adult_blocked:
                    return {'_sublime_adult_blocked': True}
                log('provider=tmdb status=retry_mismatch id=%s title=%s expected=%s score=%.2f year_mismatch=%s' % (
                    retry_id, retry_model.get('title') or '',
                    local.get('title') or params.get('title') or '', retry_score,
                    'yes' if year_mismatch else 'no'), xbmc.LOGWARNING)
        return {'_sublime_rejected': True}

    def resolve_tmdb_id():
        nonlocal root_tmdb_id, media_type
        if root_tmdb_id or not tmdb.available():
            return root_tmdb_id
        if imdb_id.startswith('tt'):
            found = tmdb.find(imdb_id, 'imdb_id')
            if media_type == 'movie':
                rows = found.get('movie_results') or []
            elif media_type == 'tv':
                rows = found.get('tv_results') or found.get('tv_episode_results') or []
            else:
                rows = found.get('movie_results') or found.get('tv_results') or found.get('tv_episode_results') or []
            if rows:
                row = rows[0]
                root_tmdb_id = _valid_tmdb_id(row.get('id') or row.get('show_id'))
                resolved_type = row.get('media_type') or ('movie' if media_type == 'movie' else 'tv')
                if media_type not in ('movie', 'tv') and resolved_type in ('movie', 'tv'):
                    media_type = resolved_type
        if not root_tmdb_id and _blind_search_allowed():
            year = _identity_target_year(params, local) or ''
            search_type = media_type if media_type in ('movie', 'tv', 'person') else 'multi'
            prefer_country, prefer_lang = _source_locale(local)
            for query in _identity_queries(params, local, media_type, allow_original=not identity_rejected):
                rows = (tmdb.search(search_type, query, year).get('results') or [])
                row = _best_row(rows, query, year, 'tmdb', prefer_country, prefer_lang,
                                source_countries=_local_country_codes(local),
                                rank_year=_identity_rank_year(params, local))
                if row:
                    root_tmdb_id = _valid_tmdb_id(row.get('id'))
                    resolved_type = row.get('media_type') or search_type
                    if resolved_type in ('movie', 'tv', 'person'):
                        media_type = resolved_type
                    if root_tmdb_id:
                        break
        return root_tmdb_id

    def fetch_kinopoisk_details(candidate_id):
        if not candidate_id or not (kinopoisk.available() or kinopoisk_dev.available()):
            return {}
        # Сначала kinopoisk.dev, если у него есть ключ: у прежнего API норма
        # 500 запросов в сутки, и на .30 07.09.2026 она исчерпалась
        # («status=quota_exhausted»). Ответ приводится к тем же полям, что у
        # прежнего API (model.kinopoisk_dev_to_legacy), поэтому дальше всё
        # работает одним разбором.
        raw = {}
        if kinopoisk_dev.available():
            raw = kinopoisk_dev_to_legacy(kinopoisk_dev.details(candidate_id))
            if raw:
                log('provider=kinopoisk_dev status=ok id=%s' % candidate_id)
        if not raw and kinopoisk.available():
            raw = kinopoisk.details(candidate_id)
        elif raw and kinopoisk.available() and not all(raw.get(k) for k in _KP_FILL_KEYS):
            # У части карточек kinopoisk.dev отдаёт пустой логотип или кадр, а у
            # kinopoiskapiunofficial они есть («Вествуд: Панк, икона, активист»,
            # .30, 22.11.2026: logo.url = null, логотипа на экране нет; на .20
            # тот же фильм из второго API - с логотипом). Пустые поля дополняет
            # второй API той же карточки; заполненные не трогаются. Только логотип: пустой кадр
            # и постер у kinopoisk.dev часты, а у второго API норма 500 запросов в сутки; и не
            # спрашиваем сеть, пока он на паузе (норма кончилась): get_json тогда отдаёт прежний ответ
            # из кэша без запроса (api._stale) - раньше пауза пропускала и его, и «Вествуд» на .20
            # оставался без логотипа, хотя карточка с логотипом лежала в кэше (22.11.2026).
            extra = kinopoisk.details(candidate_id) or {}
            for key in _KP_FILL_KEYS:
                if not raw.get(key) and extra.get(key):
                    raw[key] = extra[key]
        if not raw:
            _note_provider_retry('kinopoisk')
        if raw:
            model = normalize_kinopoisk(raw, media_type)
            matched, match_score, year_mismatch = _accept_provider_model(
                'kinopoisk', model, explicit=bool(explicit_kp_id and safe_int(candidate_id) == safe_int(explicit_kp_id)))
            if matched:
                _kp_identity_store(candidate_id, root_tmdb_id if source_models.get('tmdb') else 0, model.get('imdb_id') or '', media_type)
                return raw
            # Invalidate every key that could have produced this candidate. The
            # requested identity and the mismatched card identity can differ; deleting
            # only the latter leaves the original bad mapping alive indefinitely.
            _kp_identity_forget(candidate_id, root_tmdb_id, imdb_id, media_type)
            _kp_identity_forget(candidate_id, 0, model.get('imdb_id') or '', media_type)
            if adult_blocked:
                return {'_sublime_adult_blocked': True}
            if explicit_kp_id and safe_int(candidate_id) == safe_int(explicit_kp_id):
                _mark_identity_rejected('kinopoisk', candidate_id)
            log('provider=kinopoisk status=id_mismatch id=%s title=%s expected=%s score=%.2f year_mismatch=%s adult=%s' % (
                candidate_id, model.get('title') or '',
                local.get('title') or params.get('title') or '', match_score,
                'yes' if year_mismatch else 'no',
                'yes' if _explicit_adult(model) else 'no'), xbmc.LOGWARNING)
        year = _identity_target_year(params, local) or ''
        rejected = set([safe_int(candidate_id)])
        for query in (_identity_queries(params, local, media_type, allow_original=not identity_rejected)
                      if _blind_search_allowed() else []):
            rows = _kinopoisk_search(query, year, media_type)
            if not rows:
                _note_provider_retry('kinopoisk')
            ranked = sorted(rows, key=lambda row: _score_row(query, year, row, 'kinopoisk'), reverse=True)
            for row in ranked[:5]:
                retry_id = safe_int(row.get('filmId') or row.get('kinopoiskId')) if row else 0
                if not retry_id or retry_id in rejected:
                    continue
                rejected.add(retry_id)
                if not _search_row_is_safe(query, year, row, 'kinopoisk', _local_country_codes(local)):
                    continue
                retry_raw = kinopoisk.details(retry_id)
                if not retry_raw:
                    _note_provider_retry('kinopoisk')
                    continue
                retry_model = normalize_kinopoisk(retry_raw, media_type)
                matched, retry_score, year_mismatch = _accept_provider_model('kinopoisk', retry_model)
                if matched:
                    _kp_identity_store(retry_id, root_tmdb_id if source_models.get('tmdb') else 0, retry_model.get('imdb_id') or '', media_type)
                    return {'_sublime_resolved_id': retry_id, '_sublime_data': retry_raw}
                if adult_blocked:
                    return {'_sublime_adult_blocked': True}
                log('provider=kinopoisk status=retry_mismatch id=%s title=%s expected=%s score=%.2f year_mismatch=%s' % (
                    retry_id, retry_model.get('title') or '',
                    local.get('title') or params.get('title') or '', retry_score,
                    'yes' if year_mismatch else 'no'), xbmc.LOGWARNING)
        return {'_sublime_rejected': True}

    def enrich_kinopoisk_source(purpose):
        """Lazily add only the KinoPoisk section needed by one UI feature."""
        raw = dict(source_raw.get('kinopoisk') or {})
        if not raw or not kp_id:
            return source_models.get('kinopoisk') or {}
        changed = False
        if purpose == 'cast' and '_staff' not in raw:
            raw['_staff'] = kinopoisk.staff(kp_id)
            changed = True
            if not raw['_staff']:
                _note_provider_retry('kinopoisk')
        elif purpose == 'language_trailer' and '_videos' not in raw:
            raw['_videos'] = kinopoisk.videos(kp_id)
            changed = True
            if not raw['_videos']:
                _note_provider_retry('kinopoisk')
        elif purpose == 'gallery' and '_images' not in raw:
            raw['_images'] = kinopoisk.images(kp_id)
            changed = True
            if not raw['_images']:
                _note_provider_retry('kinopoisk')
        elif purpose == 'artwork' and '_images' not in raw:
            # Details normally contains poster/cover/logo, but coverUrl does not
            # imply that fanart exists. Query the smallest useful image subset
            # only when the normalized details still have no fanart, and stop at
            # the first category that returns rows.
            current_art = (source_models.get('kinopoisk') or {}).get('art') or {}
            if current_art.get('fanart'):
                return source_models.get('kinopoisk') or {}
            raw['_images'] = kinopoisk.images(
                kp_id, image_types=('FAN_ART', 'WALLPAPER', 'COVER'), first_nonempty=True)
            changed = True
            if not raw['_images']:
                _note_provider_retry('kinopoisk')
        if changed:
            source_raw['kinopoisk'] = raw
            source_models['kinopoisk'] = normalize_kinopoisk(raw, media_type)
            log('provider=kinopoisk status=enriched id=%s purpose=%s staff=%s videos=%s images=%s' % (
                kp_id, purpose, 'yes' if '_staff' in raw else 'no',
                'yes' if '_videos' in raw else 'no', 'yes' if '_images' in raw else 'no'), xbmc.LOGINFO)
        return source_models.get('kinopoisk') or {}

    def fetch_omdb_details(candidate_imdb_id):
        year = _identity_target_year(params, local) or ''
        tried = set()
        if identity_rejected and str(candidate_imdb_id or '') not in trusted_imdb_ids:
            candidate_imdb_id = ''
        if str(candidate_imdb_id or '').startswith('tt'):
            raw = omdb.details(imdb_id=candidate_imdb_id)
            tried.add(str(candidate_imdb_id))
            if raw:
                model = normalize_omdb(raw, media_type)
                trusted_source = trusted_imdb_ids.get(str(candidate_imdb_id))
                if trusted_source and not (config.hide_adult() and _explicit_adult(model)):
                    # A trusted cross-id must still not resurrect a country-mismatched
                    # identity. Without this, an imdb cross-id carried over from a
                    # rejected tmdb bundle (e.g. HK "Сезон" -> US tmdb 290295) bypassed
                    # the country gate and poisoned the show's season/episode fanart.
                    cross_country_ok, _cross_sc, _cross_pc = _country_identity_confirmed(params, local, model)
                    if cross_country_ok:
                        log('provider=imdb status=trusted_cross_id id=%s source=%s' % (
                            candidate_imdb_id, trusted_source), xbmc.LOGINFO)
                        return raw
                    log('provider=imdb status=trusted_cross_id_country_reject id=%s source=%s source_country=%s provider_country=%s' % (
                        candidate_imdb_id, trusted_source,
                        ','.join(sorted(_cross_sc)) or '-', ','.join(sorted(_cross_pc)) or '-'), xbmc.LOGWARNING)
                matched, match_score, year_mismatch = _accept_provider_model('imdb', model)
                if matched:
                    return raw
                if adult_blocked:
                    return {'_sublime_adult_blocked': True}
                if explicit_imdb_id and str(candidate_imdb_id) == str(explicit_imdb_id):
                    _mark_identity_rejected('imdb', candidate_imdb_id)
                log('provider=imdb status=id_mismatch id=%s title=%s expected=%s score=%.2f year_mismatch=%s adult=%s' % (
                    candidate_imdb_id, model.get('title') or '',
                    local.get('title') or params.get('title') or '', match_score,
                    'yes' if year_mismatch else 'no',
                    'yes' if _explicit_adult(model) else 'no'), xbmc.LOGWARNING)
        for query in (_identity_queries(params, local, media_type, allow_original=not identity_rejected)
                      if _blind_search_allowed() else []):
            query_key = _normal_title(query)
            if not query_key or query_key in tried:
                continue
            tried.add(query_key)
            retry_raw = omdb.details(title=query, year=year)
            if not retry_raw:
                continue
            retry_model = normalize_omdb(retry_raw, media_type)
            matched, retry_score, year_mismatch = _accept_provider_model('imdb', retry_model)
            if matched:
                return {'_sublime_resolved_id': retry_model.get('imdb_id') or '', '_sublime_data': retry_raw}
            if adult_blocked:
                return {'_sublime_adult_blocked': True}
            log('provider=imdb status=retry_mismatch id=%s title=%s expected=%s score=%.2f year_mismatch=%s' % (
                retry_model.get('imdb_id') or '-', retry_model.get('title') or '',
                local.get('title') or params.get('title') or '', retry_score,
                'yes' if year_mismatch else 'no'), xbmc.LOGWARNING)
        return {'_sublime_rejected': True}

    def load_source(source, purpose='metadata'):
        nonlocal root_tmdb_id, kp_id, imdb_id, adult_blocked
        source = str(source or '').lower()
        source_purposes.setdefault(source, set()).add(purpose)
        if source in loaded_sources:
            if source == 'kinopoisk':
                return enrich_kinopoisk_source(purpose)
            return source_models.get(source) or {}
        loaded_sources.add(source)
        if cancelled() or adult_blocked:
            return {}
        try:
            if source == 'tmdb':
                candidate_id = resolve_tmdb_id()
                if not candidate_id:
                    return {}
                raw = fetch_tmdb_details(candidate_id)
                if isinstance(raw, dict) and raw.get('_sublime_adult_blocked'):
                    adult_blocked = True
                    root_tmdb_id = 0
                    return {}
                if isinstance(raw, dict) and raw.get('_sublime_rejected'):
                    root_tmdb_id = 0
                    return {}
                if isinstance(raw, dict) and raw.get('_sublime_data') is not None:
                    root_tmdb_id = _valid_tmdb_id(raw.get('_sublime_resolved_id'))
                    raw = raw.get('_sublime_data') or {}
                if not raw:
                    root_tmdb_id = 0
                    return {}
                source_raw['tmdb'] = raw or {}
                model = normalize_tmdb(raw, media_type) if raw else {}
                if model:
                    if media_type == 'tv':
                        nested_id = safe_int(model.get('tmdb_id'))
                        model['tvshow_tmdb_id'] = root_tmdb_id
                        model['item_tmdb_id'] = nested_id if (season not in (None, '') or episode not in (None, '')) else 0
                        model['tmdb_id'] = root_tmdb_id
                        model['dbtype'] = local.get('dbtype') or ('episode' if episode not in (None, '') else 'season' if season not in (None, '') else 'tvshow')
                        if season not in (None, '') or episode not in (None, ''):
                            show_data = tmdb.details('tv', root_tmdb_id)
                            show_meta = normalize_tmdb(show_data, 'tv') if show_data else {}
                            if show_meta:
                                model['tvshowtitle'] = show_meta.get('title') or local.get('tvshowtitle') or ''
                                model['tvshow_art'] = show_meta.get('art') or {}
                                # Логотипы СЕРИАЛА идут в тот же список
                                # кандидатов, что и все остальные: выбор
                                # логотипа один на весь скин
                                # (_best_preferred_clearlogo_candidate,
                                # язык - первый признак).
                                #
                                # 08.09.2026 владелец: «логотипы меняются на
                                # текст или на логотипы на английском языке», и
                                # следом: «ПОЧЕМУ У ЛОГОТИПОВ РАЗНЫЙ МЕХАНИЗМ?!
                                # У НАС СТАНДАРТИЗАЦИЯ - ГЛАВНЫЙ ПРИОРИТЕТ!»
                                # Замер на .30: у записи «В Филадельфии всегда
                                # солнечно» art.clearlogo = английский, а
                                # tvshow_art.clearlogo = русский. У сериала на
                                # TMDb один русский логотип (0 голосов) и 33
                                # английских, и в список кандидатов серии
                                # русский не попадал вовсе - выбирать было не
                                # из чего. Теперь попадает, и решает та же
                                # сортировка, что и везде.
                                show_logos = ((show_meta.get('art_candidates') or {}).get('clearlogo') or [])
                                show_plain = str((show_meta.get('art') or {}).get('clearlogo') or '')
                                if show_logos or show_plain:
                                    candidates = model.setdefault('art_candidates', {})
                                    merged = list(candidates.get('clearlogo') or [])
                                    known = set(str(row.get('url') or '') for row in merged)
                                    for row in show_logos:
                                        url = str((row or {}).get('url') or '')
                                        if url and url not in known:
                                            known.add(url)
                                            merged.append(dict(row))
                                    if show_plain and show_plain not in known:
                                        merged.append({'url': show_plain, 'language': '',
                                                       'source': 'tmdb'})
                                    candidates['clearlogo'] = merged
                                for key in ('tvdb_id', 'imdb_id', 'networks', 'providers', 'recommendations', 'similar', 'next_aired', 'last_aired', 'status'):
                                    if show_meta.get(key):
                                        model[key if key != 'status' else 'show_status'] = show_meta.get(key)
                                for key in ('genre', 'genres', 'country', 'language', 'studio'):
                                    if not model.get(key) and show_meta.get(key):
                                        model[key] = show_meta.get(key)
                                if safe_int(model.get('runtime')) <= 0 and safe_int(show_meta.get('runtime')) > 0:
                                    model['runtime'] = show_meta.get('runtime')
                                model['show_ratings'] = show_meta.get('ratings') or {}
                                if not model.get('studio'):
                                    model['studio'] = show_meta.get('studio') or []
                    else:
                        model['dbtype'] = local.get('dbtype') or media_type
                    old_imdb_id = imdb_id
                    imdb_id = str(model.get('imdb_id') or imdb_id or '').strip()
                    source_models['tmdb'] = model
                    if imdb_id.startswith('tt'):
                        trusted_imdb_ids[imdb_id] = 'tmdb'
                    if imdb_id and imdb_id != old_imdb_id and not source_models.get('imdb'):
                        loaded_sources.discard('imdb')
                return source_models.get('tmdb') or {}

            if source == 'kinopoisk':
                # достаточно любого из двух API: с одним ключом kinopoisk.dev Кинопоиск не
                # грузился вовсе (оценка КП, русский логотип, описание - пусто)
                if not (kinopoisk.available() or kinopoisk_dev.available()):
                    return {}
                if not kp_id:
                    kp_id = _resolve_kinopoisk(local, params, media_type, root_tmdb_id, imdb_id)
                if not kp_id:
                    _note_provider_retry('kinopoisk')
                    return {}
                raw = fetch_kinopoisk_details(kp_id)
                if isinstance(raw, dict) and raw.get('_sublime_adult_blocked'):
                    adult_blocked = True
                    kp_id = 0
                    return {}
                if isinstance(raw, dict) and raw.get('_sublime_rejected'):
                    kp_id = 0
                    return {}
                if isinstance(raw, dict) and raw.get('_sublime_data') is not None:
                    kp_id = safe_int(raw.get('_sublime_resolved_id'))
                    raw = raw.get('_sublime_data') or {}
                if not raw:
                    kp_id = 0
                    return {}
                source_raw['kinopoisk'] = raw or {}
                model = normalize_kinopoisk(raw, media_type) if raw else {}
                if model:
                    old_imdb_id = imdb_id
                    imdb_id = str(model.get('imdb_id') or imdb_id or '').strip()
                    source_models['kinopoisk'] = model
                    if imdb_id.startswith('tt'):
                        trusted_imdb_ids[imdb_id] = 'kinopoisk'
                    if imdb_id and imdb_id != old_imdb_id:
                        if not source_models.get('tmdb'):
                            loaded_sources.discard('tmdb')
                        if not source_models.get('imdb'):
                            loaded_sources.discard('imdb')
                    _kp_identity_store(kp_id, root_tmdb_id if source_models.get('tmdb') else 0, model.get('imdb_id') or '', media_type)
                return enrich_kinopoisk_source(purpose)

            if source == 'imdb':
                if not config.use_omdb() or media_type == 'person':
                    return {}
                raw = fetch_omdb_details(imdb_id)
                if isinstance(raw, dict) and raw.get('_sublime_adult_blocked'):
                    adult_blocked = True
                    imdb_id = ''
                    return {}
                if isinstance(raw, dict) and raw.get('_sublime_rejected'):
                    imdb_id = ''
                    return {}
                if isinstance(raw, dict) and raw.get('_sublime_data') is not None:
                    imdb_id = str(raw.get('_sublime_resolved_id') or '').strip()
                    raw = raw.get('_sublime_data') or {}
                if not raw:
                    imdb_id = ''
                    return {}
                source_raw['imdb'] = raw or {}
                model = normalize_omdb(raw, media_type) if raw else {}
                if model:
                    imdb_id = str(model.get('imdb_id') or imdb_id or '').strip()
                    source_models['imdb'] = model
                return source_models.get('imdb') or {}
        except Exception as exc:
            log('provider=%s status=error %s_stage=%s' % (source, purpose, exc), xbmc.LOGWARNING)
        return {}

    # Safety gate for explicit TMDb ids supplied by plugins. Search requests
    # already use include_adult=false, but a direct id bypasses that filter. Validate
    # it before any provider can reuse the id for artwork, trailers or Fanart.tv.
    if config.hide_adult() and root_tmdb_id and tmdb.available():
        gate = fetch_tmdb_details(root_tmdb_id)
        if isinstance(gate, dict) and gate.get('_sublime_adult_blocked'):
            return _adult_blocked_result()
        if not gate or (isinstance(gate, dict) and gate.get('_sublime_rejected')):
            root_tmdb_id = 0
        elif isinstance(gate, dict) and gate.get('_sublime_data') is not None:
            root_tmdb_id = _valid_tmdb_id(gate.get('_sublime_resolved_id'))

    metadata_order = config.metadata_source_priorities()
    remote = {}
    metadata_sources = []
    for _order_idx, source in enumerate(metadata_order):
        model = load_source(source, 'metadata')
        if cancelled():
            return local
        if adult_blocked:
            return _adult_blocked_result()
        if not model:
            log('metadata_chain source=%s priority=%s status=no_data' % (
                source, config.metadata_priority(source)), xbmc.LOGDEBUG)
            if _order_idx == 0:
                # Plan step (docs/PLAN_INSTANT_ART_2026-08-13.md section 7.1):
                # the first source came back with nothing, so every later
                # source in the chain will run anyway. Warm their known-id
                # response cache concurrently instead of leaving each one to
                # block the next on its own network round trip - the chain
                # itself, and every identity decision in it, runs exactly as
                # it does today; see _prefetch_known_id_provider_cache.
                _fire_provider_cache_prefetch(
                    metadata_order, source, root_tmdb_id, imdb_id,
                    safe_int(params.get('kinopoisk_id') or params.get('kp_id') or local.get('kinopoisk_id')),
                    media_type)
            continue
        if not remote:
            remote = copy.deepcopy(model)
        else:
            _merge_missing(remote, model)
        metadata_sources.append(source)
        missing = _metadata_missing_fields(remote, media_type)
        if _order_idx == 0 and missing:
            _fire_provider_cache_prefetch(
                metadata_order, source, root_tmdb_id, imdb_id,
                safe_int(params.get('kinopoisk_id') or params.get('kp_id') or local.get('kinopoisk_id')),
                media_type)
        log('metadata_chain source=%s priority=%s missing=%s stop=%s' % (
            source, config.metadata_priority(source), ','.join(missing) if missing else 'none',
            'yes' if not missing else 'no'), xbmc.LOGDEBUG)
        if not missing:
            break

    if adult_blocked:
        return _adult_blocked_result()

    if not remote:
        log('item=%s year=%s status=no_match providers=%s' % (
            local.get('title') or params.get('title') or '', local.get('year') or '',
            ','.join(metadata_sources) or 'none'), xbmc.LOGINFO)
        return _attach_provider_retry(local)

    # Playback/library values always come from Kodi.
    for key in ('dbid', 'playcount', 'lastplayed', 'dateadded', 'file', 'userrating', 'top250'):
        if local.get(key) not in (None, ''):
            remote[key] = local.get(key)
    remote['dbtype'] = local.get('dbtype') or remote.get('dbtype') or ('tvshow' if media_type == 'tv' else media_type)
    remote['tmdb_type'] = media_type
    if root_tmdb_id:
        remote['tmdb_id'] = root_tmdb_id
    if kp_id:
        remote['kinopoisk_id'] = kp_id
    if imdb_id:
        remote['imdb_id'] = imdb_id
    if identity_rejected:
        remote['_identity_rejected'] = True

    selected_art = config.artwork_source()
    selected_rating = config.rating_source()
    def apply_fast_art_and_rating(target):
        # 856 stage-1 publication: use artwork/rating already present in the
        # validated primary provider models.  Do not wait for complete-logo,
        # trailer-language, cast, Fanart.tv, mdblist or Trakt enrichment.
        art_models = {'local': {'art': local.get('art') or {}}}
        art_models.update(source_models)
        if selected_art and selected_art != 'auto':
            art_order = _ordered_sources(
                selected_art, ['fanart', 'tmdb', 'kinopoisk', 'imdb']) + ['local']
        else:
            art_order = ['tmdb', 'kinopoisk', 'local', 'imdb']
        combined_art = {}
        for source in art_order:
            for key, value in (art_models.get(source, {}).get('art') or {}).items():
                if value and key not in combined_art:
                    combined_art[key] = value
        chosen_logo = _best_preferred_clearlogo_candidate(art_models, art_order)
        if chosen_logo:
            combined_art['clearlogo'] = chosen_logo.get('url') or ''
            target['clearlogo_language'] = language_code(chosen_logo.get('language'))
            target['clearlogo_source'] = chosen_logo.get('source') or ''
            target['_clearlogo_safe'] = True
        else:
            combined_art.pop('clearlogo', None)
            target.pop('clearlogo_language', None)
            target.pop('clearlogo_source', None)
            target.pop('_clearlogo_safe', None)
        selected_poster = combined_art.get('poster') or ''
        if selected_poster:
            for source in art_order:
                source_art = (art_models.get(source, {}).get('art') or {})
                if source_art.get('poster') == selected_poster:
                    combined_art['poster_original'] = source_art.get('poster_original') or selected_poster
                    break
            combined_art.setdefault('poster_original', selected_poster)
        target['_background_has_enriched_art'] = _has_enriched_background_art(art_models, art_order)
        target['art'] = combined_art
        rating_order = _ordered_sources(selected_rating, ['kinopoisk', 'imdb', 'tmdb', 'mdblist'])
        target.pop('rating', None)
        target.pop('votes', None)
        for source in rating_order:
            row = (target.get('ratings') or {}).get(source) or {}
            if safe_float(row.get('rating')) > 0:
                target['rating'] = safe_float(row.get('rating'))
                target['votes'] = safe_int(row.get('votes'))
                break

    if base_callback and not cancelled():
        try:
            fast_remote = copy.deepcopy(remote)
            apply_fast_art_and_rating(fast_remote)
            base_callback(fast_remote)
        except Exception as exc:
            log('fast metadata callback failed: %s' % exc, xbmc.LOGWARNING)

    # Cast remains a normal fallback. Trailer selection is different: provider
    # priority only breaks ties after the language selected in Sublime settings.
    need_cast = (config.feature_requested('cast') or feature_purpose in ('cast', 'crew')) and not remote.get('cast')
    trailer_requested = config.feature_requested('trailer') or feature_purpose == 'videos'
    if media_type != 'person' and need_cast:
        for source in ('tmdb', 'kinopoisk'):
            source_model = load_source(source, 'cast')
            if not source_model:
                continue
            if not remote.get('cast') and source_model.get('cast'):
                remote['cast'] = source_model.get('cast')
            for key, rows in (source_model.get('crew') or {}).items():
                if rows and not (remote.setdefault('crew', {}).get(key)):
                    remote['crew'][key] = rows
            if remote.get('cast'):
                break

    if media_type != 'person' and trailer_requested:
        trailer_models = dict(source_models)
        trailer_models['local'] = local
        # TMDb can return the configured metadata language for every supported
        # locale. Do not call the next provider once an official preferred-language
        # trailer has already been found.
        if not _has_preferred_official_trailer(trailer_models):
            load_source('tmdb', 'language_trailer')
            trailer_models = dict(source_models)
            trailer_models['local'] = local
        # Kinopoisk's video feed is Russian and is only a language candidate when
        # Russian is actually selected. This avoids fixed Russian behaviour for all
        # other UI languages.
        # За русским трейлером к Кинопоиску не ходим ВОВСЕ.
        #
        # Замер на .20 06.09.2026: 666 обращений purpose=language_trailer
        # против 3 purpose=cast за один сеанс, при суточной норме ключа в 500
        # запросов - «You exceeded the quota. You have sent 530 request, but
        # available 500 per day». То есть трейлер, которого на инфостроке нет
        # вообще, съедал всю норму, а вместе с ней и оценку Кинопоиска, ради
        # которой этот поставщик и нужен.
        #
        # Взамен ничего изобретать не пришлось: в скине давно есть поиск
        # трейлера на YouTube по локализованному запросу
        # (actions.py, _trailer_search_queries + get_first_youtube_video), и он
        # включается ровно тогда, когда у метаданных ссылки нет. Он бесплатный
        # и по-русски ищет не хуже. Предложение владельца, и оно верное.
        # The UI should not lock onto a foreign trailer when the configured
        # language has no direct match. In that case we leave the helper trailer
        # empty so the play action can try a localized YouTube search first and
        # only then fall back to a foreign ListItem.Trailer.
        chosen_trailer = _best_trailer_candidate(
            trailer_models, ('tmdb', 'kinopoisk', 'local', 'imdb'), max_language_rank=1)
        if chosen_trailer:
            remote['trailer'] = chosen_trailer.get('url') or ''
            remote['trailer_language'] = language_code(chosen_trailer.get('language'))
            remote['trailer_official'] = bool(chosen_trailer.get('official'))
            remote['trailer_source'] = chosen_trailer.get('source') or ''
        else:
            remote.pop('trailer', None)
            remote.pop('trailer_language', None)
            remote.pop('trailer_official', None)
            remote.pop('trailer_source', None)

    # A specifically selected artwork/rating provider is allowed to run even if
    # it was not needed by the information-source fallback chain.
    if selected_art in ('tmdb', 'kinopoisk', 'imdb'):
        load_source(selected_art, 'artwork')
    if feature_purpose == 'gallery' and kinopoisk.available():
        load_source('kinopoisk', 'gallery')

    # Clearlogo is resolved entirely inside Sublime. The unfiltered /images
    # response is the source of truth for language tags. Filtered TMDb endpoints
    # can return fallback rows that look like a requested-language result, so
    # they are never allowed to relabel or short-circuit the complete list.
    language_art_models = dict(source_models)
    language_art_models['local'] = local
    if not source_models.get('tmdb'):
        load_source('tmdb', 'language_artwork')
        language_art_models = dict(source_models)
        language_art_models['local'] = local

    if (not _has_preferred_clearlogo(language_art_models) and
            source_models.get('tmdb') and root_tmdb_id):
        try:
            # Cached first, always: if this response is already on disk the logo
            # is on screen immediately. Only an actual network fetch waits for
            # the cursor to stop, and the row is resolved once more when it does.
            with api_cache_only(True):
                complete_images = tmdb.images(
                    media_type, root_tmdb_id, complete=True, cache_version='v700')
            if not complete_images:
                if not (focus_settled() or logo_fetch_allowed()):
                    remote['_logo_pending'] = True
                    raise _LogoDeferred()
                complete_images = tmdb.images(
                    media_type, root_tmdb_id, complete=True, cache_version='v700')
            complete_images = dict(complete_images or {})
            log('tmdb complete logo lookup id=%s requested=%s rows=%s' % (
                root_tmdb_id, language_code() or 'neutral',
                _tmdb_logo_rows_debug(complete_images)), xbmc.LOGDEBUG)
            refreshed_raw = dict(source_raw.get('tmdb') or {})
            refreshed_raw['images'] = complete_images
            refreshed_model = normalize_tmdb(refreshed_raw, media_type)
            refreshed_candidates = ((refreshed_model.get('art_candidates') or {}).get('clearlogo') or [])
            tmdb_model = source_models.setdefault('tmdb', {})
            # Replace, do not append: this discards language classifications that
            # came only from a server-filtered response.
            tmdb_model.setdefault('art_candidates', {})['clearlogo'] = refreshed_candidates
            if refreshed_candidates:
                best_art = refreshed_model.get('art') or {}
                if best_art.get('clearlogo'):
                    tmdb_model.setdefault('art', {})['clearlogo'] = best_art.get('clearlogo')
            else:
                tmdb_model.setdefault('art', {}).pop('clearlogo', None)
            source_raw.setdefault('tmdb', {})['images'] = complete_images
            language_art_models = dict(source_models)
            language_art_models['local'] = local
        except _LogoDeferred:
            # Not cached and the cursor is still moving: left for the moment it
            # stops. Everything else in this answer is already complete.
            log('tmdb logo deferred id=%s: не в кэше, фокус в движении' % root_tmdb_id,
                xbmc.LOGDEBUG)
        except Exception as exc:
            log('tmdb complete logo lookup failed id=%s error=%s' % (
                root_tmdb_id, exc), xbmc.LOGWARNING)

    if language_code() == 'ru' and not _has_preferred_clearlogo(language_art_models):
        load_source('kinopoisk', 'language_artwork')

    if selected_rating in ('tmdb', 'kinopoisk', 'imdb'):
        load_source(selected_rating, 'rating')
    # Custom rating slots are independent from the primary rating selector.
    for rating_provider in ('tmdb', 'kinopoisk', 'imdb'):
        if config.rating_requested(rating_provider):
            load_source(rating_provider, 'displayed_rating')

    if media_type != 'person' and trailer_requested:
        trailer_models = dict(source_models)
        trailer_models['local'] = local
        chosen_trailer = None
        if not remote.get('trailer'):
            chosen_trailer = _best_trailer_candidate(
                trailer_models, ('tmdb', 'kinopoisk', 'local', 'imdb'), max_language_rank=1)
            if chosen_trailer:
                remote['trailer'] = chosen_trailer.get('url') or ''
                remote['trailer_language'] = language_code(chosen_trailer.get('language'))
                remote['trailer_official'] = bool(chosen_trailer.get('official'))
                remote['trailer_source'] = chosen_trailer.get('source') or ''
        # Keep the best foreign candidate separately. It is never published as
        # the primary trailer; the play action uses it only if the preferred or
        # neutral URL is absent or cannot start playback.
        fallback_trailer = _best_trailer_candidate(
            trailer_models, ('tmdb', 'kinopoisk', 'local', 'imdb'), min_language_rank=2)
        if fallback_trailer:
            remote['trailer_fallback'] = fallback_trailer.get('url') or ''
            remote['trailer_fallback_language'] = language_code(fallback_trailer.get('language'))
            remote['trailer_fallback_source'] = fallback_trailer.get('source') or ''
        else:
            remote.pop('trailer_fallback', None)
            remote.pop('trailer_fallback_language', None)
            remote.pop('trailer_fallback_source', None)

        ordered_trailer_candidates = []
        seen_trailer_urls = set()
        primary_row = chosen_trailer or ({
            'url': remote.get('trailer') or '',
            'language': remote.get('trailer_language') or '',
            'official': bool(remote.get('trailer_official')),
            'source': remote.get('trailer_source') or 'metadata',
        } if remote.get('trailer') else None)
        for row in ([primary_row] if primary_row else []):
            url = str((row or {}).get('url') or '')
            if url and url not in seen_trailer_urls and not cache.is_trailer_failed(url):
                seen_trailer_urls.add(url)
                ordered_trailer_candidates.append(dict(row))
        for source in ('tmdb', 'kinopoisk', 'local', 'imdb'):
            for row in sorted(_trailer_candidates(source, trailer_models.get(source) or {}), key=trailer_rank):
                url = str(row.get('url') or '')
                if not url or url in seen_trailer_urls or cache.is_trailer_failed(url):
                    continue
                seen_trailer_urls.add(url)
                ordered_trailer_candidates.append(dict(row))
        remote['trailer_candidates'] = ordered_trailer_candidates[:8]

    # Feature enrichment never overwrites the chosen information source. It only
    # fills feature collections, IDs and ratings used by their own UI controls.
    for model in source_models.values():
        if not remote.get('cast') and model.get('cast'):
            remote['cast'] = model.get('cast')
        for key, rows in (model.get('crew') or {}).items():
            if rows and not (remote.setdefault('crew', {}).get(key)):
                remote['crew'][key] = rows
        if (not remote.get('trailer') and model.get('trailer') and
                not cache.is_trailer_failed(model.get('trailer')) and
                language_rank(model.get('trailer_language')) <= 1):
            remote['trailer'] = model.get('trailer')
            remote['trailer_language'] = language_code(model.get('trailer_language'))
            remote['trailer_official'] = bool(model.get('trailer_official'))
            remote['trailer_source'] = model.get('trailer_source') or model.get('source') or ''
        for key in ('videos', 'recommendations', 'similar', 'reviews', 'seasons', 'providers', 'networks', 'tvdb_id'):
            if not remote.get(key) and model.get(key):
                remote[key] = model.get(key)
        for key, row in (model.get('ratings') or {}).items():
            if row:
                remote.setdefault('ratings', {}).setdefault(key, row)
        for key, urls in (model.get('fanart_art') or {}).items():
            if urls:
                remote.setdefault('fanart_art', {}).setdefault(key, urls)

    # Persist only cross-provider links that have passed both providers'
    # identity validation. KinoPoisk's own IMDb id is safe to cache directly.
    if kp_id and source_models.get('kinopoisk'):
        kp_model = source_models.get('kinopoisk') or {}
        _kp_identity_store(
            kp_id, root_tmdb_id if source_models.get('tmdb') else 0,
            kp_model.get('imdb_id') or '', media_type)

    # Optional integrations run only when their output is actually requested.
    # Their requests start before the base publication, but the UI no longer waits
    # for them: the selected information provider and local art are published first.
    fanart_model = {'art': {}, 'fanart_art': {}, 'art_candidates': {}}
    optional_jobs = {}
    current_art = {}
    for model in source_models.values():
        for key, value in (model.get('art') or {}).items():
            if value and key not in current_art:
                current_art[key] = value
    for key, value in (local.get('art') or {}).items():
        if value and key not in current_art:
            current_art[key] = value
    # Fanart.tv is also a language-aware clearlogo fallback. An English or
    # untagged logo must not block a lookup for the language selected in settings.
    fanart_language_models = dict(source_models)
    fanart_language_models['local'] = local
    need_fanart_lookup = (
        selected_art == 'fanart'
        or not _has_preferred_clearlogo(fanart_language_models)
        or (selected_art == 'auto' and not current_art.get('fanart'))
    )
    if config.use_fanart() and not root_tmdb_id and need_fanart_lookup:
        load_source('tmdb', 'fanart_identity')
    if config.use_fanart() and need_fanart_lookup and (root_tmdb_id or remote.get('tvdb_id')):
        optional_jobs['fanart'] = _OPTIONAL_EXECUTOR.submit(
            fanart.details, media_type, root_tmdb_id, remote.get('tvdb_id'))
    if config.use_mdblist() and config.rating_requested('mdblist') and (root_tmdb_id or imdb_id):
        optional_jobs['mdblist'] = _OPTIONAL_EXECUTOR.submit(
            mdblist.details, media_type, root_tmdb_id, imdb_id)

    def apply_art_and_rating(target, extra_fanart=None):
        art_models = {'local': {'art': local.get('art') or {}}}
        art_models.update(source_models)
        if extra_fanart:
            art_models['fanart'] = extra_fanart
        if selected_art and selected_art != 'auto':
            art_order = _ordered_sources(
                selected_art, ['fanart', 'tmdb', 'kinopoisk', 'imdb']) + ['local']
        else:
            art_order = ['fanart', 'tmdb', 'kinopoisk', 'local', 'imdb']
        combined_art = {}
        for source in art_order:
            for key, value in (art_models.get(source, {}).get('art') or {}).items():
                if value and key not in combined_art:
                    combined_art[key] = value

        chosen_logo = _best_preferred_clearlogo_candidate(art_models, art_order)
        if chosen_logo:
            combined_art['clearlogo'] = chosen_logo.get('url') or ''
            target['clearlogo_language'] = language_code(chosen_logo.get('language'))
            target['clearlogo_source'] = chosen_logo.get('source') or ''
            target['_clearlogo_safe'] = True
        else:
            # Provider APIs occasionally expose only foreign or incorrectly tagged
            # logos. Preserve the selected UI language with a native transparent
            # title-logo rather than showing a foreign logo or an empty slot.
            generated_logo = ''
            if language_code() and _has_foreign_clearlogo(art_models):
                generated_logo = request_title_logo(
                    _header_title(target, local), language_code())
            if generated_logo:
                combined_art['clearlogo'] = generated_logo
                target['clearlogo_language'] = language_code()
                target['clearlogo_source'] = 'generated'
                target['_clearlogo_safe'] = True
            else:
                combined_art.pop('clearlogo', None)
                target.pop('clearlogo_language', None)
                target.pop('clearlogo_source', None)
                target.pop('_clearlogo_safe', None)

        selected_poster = combined_art.get('poster') or ''
        if selected_poster:
            for source in art_order:
                source_art = (art_models.get(source, {}).get('art') or {})
                if source_art.get('poster') == selected_poster:
                    combined_art['poster_original'] = source_art.get('poster_original') or selected_poster
                    break
            combined_art.setdefault('poster_original', selected_poster)
        target['_background_has_enriched_art'] = _has_enriched_background_art(art_models, art_order)
        target['art'] = combined_art
        target['fanart_art'] = {}
        fanart_sources = list(source_models.values())
        if extra_fanart:
            fanart_sources.append(extra_fanart)
        for model in fanart_sources:
            for key, urls in (model.get('fanart_art') or {}).items():
                if urls:
                    target.setdefault('fanart_art', {}).setdefault(key, urls)
        rating_order = _ordered_sources(selected_rating, ['kinopoisk', 'imdb', 'tmdb', 'mdblist'])
        target.pop('rating', None)
        target.pop('votes', None)
        for source in rating_order:
            row = (target.get('ratings') or {}).get(source) or {}
            if safe_float(row.get('rating')) > 0:
                target['rating'] = safe_float(row.get('rating'))
                target['votes'] = safe_int(row.get('votes'))
                break

    omdb_data = source_raw.get('imdb') or {}
    if omdb_data:
        merge_omdb(remote, omdb_data)
    _attach_provider_retry(remote)
    apply_art_and_rating(remote)

    if base_callback and optional_jobs and not cancelled():
        try:
            base_callback(copy.deepcopy(remote))
        except Exception as exc:
            log('base metadata callback failed: %s' % exc, xbmc.LOGWARNING)

    optional_results = {}
    for source, future in optional_jobs.items():
        if cancelled():
            break
        try:
            optional_results[source] = future.result() or {}
        except Exception as exc:
            log('provider=%s status=error optional_stage=%s' % (source, exc), xbmc.LOGWARNING)
            optional_results[source] = {}
    if optional_results.get('fanart'):
        merge_fanart(fanart_model, optional_results.get('fanart'))
    if optional_results.get('mdblist'):
        merge_mdblist(remote, optional_results.get('mdblist'))
    apply_art_and_rating(remote, fanart_model)

    clearlogo_summary = _summarize_clearlogo_candidates(
        {'local': {'art': local.get('art') or {}}, 'tmdb': source_models.get('tmdb') or {}, 'kinopoisk': source_models.get('kinopoisk') or {}, 'imdb': source_models.get('imdb') or {}, 'fanart': fanart_model or {}},
        ['fanart', 'tmdb', 'kinopoisk', 'local', 'imdb'])
    trailer_summary = _summarize_trailer_candidates(
        dict(source_models, local=local),
        ['tmdb', 'kinopoisk', 'local', 'imdb'])

    log('item=%s year=%s source_year=%s source_country=%s provider_country=%s status=ok metadata_sources=%s loaded_sources=%s tmdb=%s kinopoisk=%s imdb=%s fanart=%s bg_enriched=%s clearlogo=%s clearlogo_lang=%s clearlogo_source=%s clearlogo_candidates=%s trailer=%s trailer_lang=%s trailer_source=%s trailer_official=%s trailer_fallback=%s trailer_fallback_lang=%s trailer_fallback_source=%s trailer_candidates=%s cast=%s' % (
        remote.get('title') or local.get('title') or '', remote.get('year') or local.get('year') or '',
        local.get('source_year') or local.get('year') or '', ','.join(local.get('source_country') or local.get('country') or []) or '-', ','.join(remote.get('country') or []) or '-',
        ','.join(metadata_sources) or 'none', ','.join(sorted(loaded_sources)) or 'none',
        root_tmdb_id or 0, kp_id or 0, imdb_id or '-',
        'yes' if (remote.get('art') or {}).get('fanart') else 'no',
        'yes' if remote.get('_background_has_enriched_art') else 'no',
        'yes' if (remote.get('art') or {}).get('clearlogo') else 'no',
        remote.get('clearlogo_language') or 'neutral', remote.get('clearlogo_source') or '-', clearlogo_summary,
        'yes' if remote.get('trailer') else 'no', remote.get('trailer_language') or 'neutral',
        remote.get('trailer_source') or '-', 'yes' if remote.get('trailer_official') else 'no',
        'yes' if remote.get('trailer_fallback') else 'no', remote.get('trailer_fallback_language') or 'neutral',
        remote.get('trailer_fallback_source') or '-', trailer_summary,
        len(remote.get('cast') or [])), xbmc.LOGINFO)
    _attach_provider_retry(remote)
    return remote

# Kodi paints a remote picture only after it has downloaded and converted it,
# and it records every texture it has converted. That record is the difference
# between a background that appears with the row and one that appears seconds
# later - or, while scrolling, never appears at all, which is what the owner
# filmed: the text of the new film with the previous film's backdrop behind it,
# then nothing.
_TEXTURE_READY = OrderedDict()
_TEXTURE_READY_MAX = 4096
_TEXTURE_MISS_TTL = 2.5
_TEXTURE_FETCHING = set()
_TEXTURE_LOCK = threading.Lock()
# A picture Kodi cannot fetch (dead link, refused host) must not keep its row
# without a background for ever: after this many attempts it is published
# anyway, which is exactly the old behaviour for that row.
_TEXTURE_TRIES = OrderedDict()
_TEXTURE_TRIES_MAX = 2
# Holding the enriched background back until Kodi holds the picture removes one
# kind of blank screen. It is free now: the check is a dictionary lookup filled
# in by background work, never a query from the publishing path.
HOLD_BACKGROUND_UNTIL_CACHED = True


def probe_texture(url):
    """Ask Kodi whether it holds this picture, and remember the answer.

    Deliberately NOT called while publishing properties for the focused row:
    that path runs on the service loop, and a JSON-RPC round trip there is a
    stall the owner would feel. This is for background work - the lane warm-up -
    which has time to wait for an answer.
    """
    url = str(url or '').strip()
    if not url.startswith(('http://', 'https://')):
        return True
    ready = True
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Textures.GetTextures',
            'params': {'filter': {'field': 'url', 'operator': 'is', 'value': url}},
        })) or '{}')
        ready = bool(((answer.get('result') or {}).get('textures') or []))
    except Exception:
        ready = True
    _TEXTURE_READY[url] = (ready, time.time())
    while len(_TEXTURE_READY) > _TEXTURE_READY_MAX:
        _TEXTURE_READY.popitem(last=False)
    return ready


def texture_ready(url):
    """Public name for _texture_ready: the fallback layer needs it too.

    The fallback background used to be taken down as soon as the enriched
    background PROPERTY existed, whether or not Kodi could paint it yet. On a
    film whose metadata was already loaded that produced exactly one blink about
    a second after focus - the placeholder went out, the enriched picture was
    not on screen yet, and the eye caught the gap. Reported by the owner as
    «при уже загруженных метаданных и фоне через примерно секунду фокуса фон
    мигает один раз».
    """
    return _texture_ready(url)


def _texture_ready(url):
    """True when this picture can be painted right now.

    A dictionary lookup and nothing else - the answers come from background work
    (warm-up probes) and from the fetches this module starts itself.

    An UNKNOWN picture counts as not ready, and that is deliberate: the owner
    asked for the cheap placeholder first and the enriched background after
    («фолбек загружался первым для всех виджетов на главной, а полное обогащение
    уже после»). Publishing an unknown remote URL is what used to hide the
    placeholder and leave the screen empty until the download finished. The
    attempt cap below makes sure a picture Kodi cannot fetch stops blocking
    after two tries, so nothing is lost permanently.
    """
    url = str(url or '').strip()
    if not url or not url.startswith(('http://', 'https://')):
        return True
    if _TEXTURE_TRIES.get(url, 0) >= _TEXTURE_TRIES_MAX:
        return True  # asked enough; a picture Kodi will not fetch must not block
    known = _TEXTURE_READY.get(url)
    if known is None:
        # Never seen this picture before. Ask Kodi once - it is a local database
        # query, a few milliseconds, and the answer is remembered for the rest
        # of the session. Guessing "not ready" instead was wrong in the visible
        # direction: rows whose enriched background Kodi had held all along
        # started showing the placeholder («сейчас ещё и фолбек вылезает в тех
        # айтемах, в которых раньше было обогащение»).
        return probe_texture(url)
    ready, stamp = known
    if ready:
        return True
    # A miss is only trusted briefly: the fetch it triggers is usually quick.
    return (time.time() - stamp) >= _TEXTURE_MISS_TTL


def _fetch_texture_async(url):
    """Ask Kodi to convert this picture, off whatever thread noticed it was cold.

    One reader is all it takes; the bytes are of no interest. Deliberately not
    on the caller's thread: publishing metadata happens on the service loop,
    which has the focused row's own work to do meanwhile.
    """
    url = str(url or '').strip()
    if not url.startswith(('http://', 'https://')) or xbmcvfs is None:
        return
    with _TEXTURE_LOCK:
        if url in _TEXTURE_FETCHING:
            return
        _TEXTURE_FETCHING.add(url)
        _TEXTURE_TRIES[url] = _TEXTURE_TRIES.get(url, 0) + 1
        while len(_TEXTURE_TRIES) > _TEXTURE_READY_MAX:
            _TEXTURE_TRIES.popitem(last=False)

    def _work():
        handle = None
        try:
            handle = xbmcvfs.File('image://%s/' % quote(url, safe=''))
            handle.readBytes(1)
        except Exception:
            pass
        finally:
            try:
                if handle is not None:
                    handle.close()
            except Exception:
                pass
            with _TEXTURE_LOCK:
                _TEXTURE_FETCHING.discard(url)
            # Kodi converts the texture as part of that read, so the picture is
            # paintable now. Recording it is what lets the very next publish
            # hand the screen over from the placeholder to the real background.
            _TEXTURE_READY[url] = (True, time.time())
            while len(_TEXTURE_READY) > _TEXTURE_READY_MAX:
                _TEXTURE_READY.popitem(last=False)

    thread = threading.Thread(target=_work, name='SublimeTextureFetch')
    thread.daemon = True
    try:
        thread.start()
    except Exception:
        with _TEXTURE_LOCK:
            _TEXTURE_FETCHING.discard(url)


# How long the previous picture may stay while this row's own is being made.
# Long enough to cover the placeholder's arrival (measured 0.2-0.6 s), short
# enough that a row which never gets one does not sit under another film's
# backdrop - the owner watched «Как спят дикие животные» do exactly that when
# the hold had no limit at all.
# Номер серии в адресе строки провайдера: `.../play/?s=1&e=3`.
_EPISODE_IN_PATH = re.compile(r'[?&]e=(\d+)')


# Постер вместо кадра. У серии фоном идёт её собственный кадр, и он лежит в
# art['thumb'] - но не всегда: онлайн-ответ Кинопоиска кладёт туда МАЛЕНЬКИЙ
# ПОСТЕР (.../images/posters/kp_small/...), и он уходил в подложку. Замер на .20
# 05.09.2026, «Эпизод 5» сериала «Осколки»: у строки был кадр TMDb
# (t/p/w1920/e7ASKOJACLkoG6FqKD1OKKBdEWB.jpg), опубликован фанарт
# (t/p/w1920/AhzF2bk...), а размытая подложка построена из kp_small/6531565.jpg.
# Владелец увидел это как «маленький лендскейп вместо фанарта».
_POSTER_MARKS = ('kp_small', '/posters/', '/poster/', 'poster_small')


def _picture_host_down(url):
    """Хост этой картинки числится недоступным.

    Решение принимает одна служба - hub/host_health (проба по трём настоящим
    адресам раз в пять минут). Здесь оно только читается, потому что фон стоит
    дороже плитки: код ниже честно ждёт картинку и сам её дозагружает, а для
    мёртвого адреса это попытка за попыткой по десять секунд - и загрузчик
    текстур у Kodi ОДИН. По кадрам записи владельца 08.09.2026 видно, чем это
    кончается: на строке с мёртвым адресом гаснут все плитки полосы и фон
    замирает на прошлой строке.
    """
    if not url:
        return False
    try:
        from resources.lib.hub import host_health
    except Exception:
        return False
    try:
        return bool(host_health.is_down(url))
    except Exception:
        return False


def _header_title(model, local=None):
    """Название для заголовка: у серии и сезона это название СЕРИАЛА.

    09.09.2026 владелец, по двум снимкам: «Тени над Балканами - вместо
    названия сериала "Эпизод 1"», «Терапия - вместо названия сериала название
    серии», и сразу: «сейчас везде - сериал, только в этих скриншотах
    наоборот, надо привести к единому». Заголовок на этих экранах - не текст, а
    логотип, СОБРАННЫЙ ИЗ ТЕКСТА (title_logo.py), и собирался он из названия
    строки: у серии - «Эпизод 1». Название самой серии никуда не девается: оно
    стоит подписью под плиткой и в строке описания.
    """
    for source in (model or {}, local or {}):
        dbtype = str((source or {}).get('dbtype') or '')
        if dbtype in ('episode', 'season'):
            for owner in (model or {}, local or {}):
                show = str((owner or {}).get('tvshowtitle') or '').strip()
                if show:
                    return show
            break
    for owner in (local or {}, model or {}):
        title = str((owner or {}).get('title') or '').strip()
        if title:
            return title
    return ''


def _still_not_poster(value):
    """Кадр, если это кадр. Постер - не кадр, лучше взять лендскейп или фанарт."""
    text = str(value or '')
    if not text:
        return ''
    low = text.lower()
    for mark in _POSTER_MARKS:
        if mark in low:
            return ''
    return text


def _is_tmdb_still(url):
    """Кадр ли это с TMDb - хоть бы опознание у нас и не закончилось.

    Ворота ниже требовали НАШЕГО опознания (tmdb_id), иначе кадру строки не
    доверяли: у неопознанной серии в thumb мог лежать постер сериала. Но кадр
    может прийти и от плагина - он сам ходит в TMDb. Замер на .30 09.09.2026:
    10-я серия «Заветов» («Ножницы») записи в нашем кэше не имеет вовсе, а в
    строке у неё настоящий кадр TMDb - и фоном вместо кадра вставала картинка
    сериала. Владелец: «только у 10й серии - не кадр, а картинка».

    Постером такой адрес быть не может: у TMDb кадры серий лежат отдельно от
    постеров, а адрес с постером здесь и так отсекает _still_not_poster.
    """
    text = str(url or '')
    if not text or not _still_not_poster(text):
        return False
    return 'image.tmdb.org' in text or 'themoviedb.org' in text


def _cached_fits_row(cached, local):
    """Годится ли запись кэша этой строке - по виду записи.

    09.09.2026, «Заветы», 10-я серия «Ножницы»: под ключом ЭТОЙ строки в кэше
    лежала модель СЕЗОНА - заголовок «Сезон 1», картинка сезона, - и служба
    честно её показывала, а к TMDb не обращалась вовсе (замер: ни одного
    запроса, «отпечаток совпал»). Владелец видел это как «только у 10-й серии
    не кадр, а картинка».

    Строка знает свой вид: у серии `dbtype=episode` и номер серии в адресе.
    Если запись говорит «сезон» или «сериал», она не про эту строку - публиковать
    её нельзя, надо опознавать заново.
    """
    if not isinstance(cached, dict) or not isinstance(local, dict):
        return True
    row_is_episode = (str(local.get('dbtype') or '') == 'episode'
                      or _is_episode_row(local))
    if not row_is_episode:
        return True
    cached_dbtype = str(cached.get('dbtype') or cached.get('tmdb_type') or '')
    if cached_dbtype in ('season', 'tvshow', 'tv'):
        log('кэш не про эту строку: строка=%s (серия), в записи %s - опознаю заново'
            % (str(local.get('title') or local.get('label') or '')[:40], cached_dbtype),
            xbmc.LOGINFO)
        return False
    return True


def _keep_row_still(model, local):
    """У строки-СЕРИИ фоном остаётся её собственный кадр.

    09.09.2026, «Заветы», 10-я серия «Ножницы»: TMDb этой серии ещё не знает
    (сериал выходит сейчас), опознание падает на СЕЗОН, и публикуется модель
    сезона - вместе с картинкой сезона. Кадр у строки при этом есть, его дал
    плагин (image.tmdb.org/.../zM8G8o5O...jpg), но в модели сезона его нет.
    Владелец: «только у 10й серии - не кадр, а картинка», и правило он назвал
    прямо: «должен быть кадр из серии, только если кадра нет - картинка из
    tmdb».

    Поэтому кадр строки переносится в модель, если модель его не несёт. Постер
    кадром не считается (_still_not_poster), сезоны и сериалы не затрагиваются:
    признак - строка сама себя называет серией.
    """
    if not isinstance(model, dict) or not isinstance(local, dict):
        return model
    if str(local.get('dbtype') or '') != 'episode' and not _is_episode_row(local):
        return model
    row_still = (_still_not_poster((local.get('art') or {}).get('still'))
                 or _still_not_poster((local.get('art') or {}).get('thumb')))
    if not row_still:
        return model
    art = dict(model.get('art') or {})
    if _still_not_poster(art.get('still')) or _still_not_poster(art.get('thumb')):
        return model
    art['still'] = row_still
    art['thumb'] = row_still
    model = dict(model)
    model['art'] = art
    return model


def _keep_row_logo(model, row_model):
    """Логотип и студия собранной строки - если в результате опознания их нет. Закэшированное
    опознание без логотипа перебивало логотип строки: «Вествуд» на .20 стоял с названием текстом,
    хотя в хранилище строк логотип Кинопоиска был (22.11.2026)."""
    if not isinstance(model, dict) or not isinstance(row_model, dict):
        return model
    row_logo = str(((row_model.get('art') or {}).get('clearlogo')) or '')
    if row_logo and not str(((model.get('art') or {}).get('clearlogo')) or ''):
        model = dict(model)
        model['art'] = dict(model.get('art') or {}, clearlogo=row_logo)
        model['_clearlogo_safe'] = True
    if row_model.get('studio') and not model.get('studio'):
        model = dict(model)
        model['studio'] = list(row_model.get('studio'))
    return model


def _keep_row_release(model, local):
    """Качество релиза - свойство САМОЙ строки, а не результата опознания.

    Провайдеры метаданных о нём не знают вовсе, поэтому после обогащения оно
    пропадало бы: модель приходит от TMDb/Кинопоиска. Переносим из строки.
    """
    if not isinstance(model, dict) or not isinstance(local, dict):
        return model
    quality = str(local.get('release_quality') or '')
    resolution = str(local.get('release_resolution') or '')
    details = str(local.get('release_details') or '')
    if not quality and not resolution and not details:
        return model
    if (str(model.get('release_quality') or '') == quality
            and str(model.get('release_resolution') or '') == resolution
            and str(model.get('release_details') or '') == details):
        return model
    model = dict(model)
    model['release_quality'] = quality
    model['release_resolution'] = resolution
    model['release_details'] = details
    return model


def _is_episode_row(meta):
    """Серия ли это - независимо от того, назвал ли её так плагин.

    DBType у строк плагина сплошь и рядом пуст: Kodi заполняет его только для
    библиотеки. Номер серии из ListItem.Episode для этого не годится: у строки
    СЕЗОНА Kodi кладёт туда количество серий, и правило по номеру принимало
    сезон за серию - тогда фоном шёл постер сезона вместо кадра сериала.
    Надёжный признак - адрес самой строки: у серии в нём стоит её номер
    (`?s=1&e=3`), у сезона и сериала его нет.
    """
    meta = meta or {}
    dbtype = str(meta.get('dbtype') or meta.get('tmdb_type') or '').strip().lower()
    if dbtype == 'episode':
        return True
    if dbtype in ('season', 'movie', 'tvshow', 'tv'):
        return False
    hit = _EPISODE_IN_PATH.search(str(meta.get('file') or ''))
    try:
        return bool(hit) and int(hit.group(1)) > 0
    except Exception:
        return False


# Порядок, в котором заполняются пустые слоты оценок. Владелец 10.09.2026:
# «у Эхо Пойнт нет рейтингов, как и у многих других». Замер на .30 по этой самой
# строке: TMDB_ID опознан, но у TMDb оценки нет (свежий фильм без голосов),
# номера Кинопоиска нет вовсе - а IMDb 2.4 опубликован. Слотов в инфостроке два,
# и каждый жёстко ждал ту службу, которую владелец выбрал в настройках; если у
# неё оценки нет, слот молчал, хотя оценка была у другой. Теперь выбор владельца
# - первый, а пустой слот добирается тем, что есть.
# Ровно те три службы, которые разметка умеет показать в любом слоте
# (см. Info_Meta_Ratings): добирать слот тем, что нарисовать нельзя,
# значило бы снова оставить его пустым.
_RATING_FALLBACK = ('Kinopoisk', 'TMDb', 'IMDb')


def _rating_slots(published, prefix, media_dbtype):
    """Какая служба показывается в каждом из двух слотов инфостроки.

    Наличие оценки спрашивается у ТОГО, ЧТО УЖЕ СТОИТ В ОКНЕ, а не у модели
    нынешнего прохода: на одну строку публикация приходит несколько раз, и
    более бедный проход не снимает опубликованное (см. same_row в _publish).
    Считай слоты по модели - и такой проход погасил бы чипы при живых оценках.
    """
    content = ('TVShows' if str(media_dbtype or '') in ('tvshow', 'season', 'episode', 'tv')
               else 'Movies')
    addresses = ['Skin.String(CustomRating.%s.%s)' % (content, slot)
                 for slot in ('Item01', 'Item02')]
    try:
        got = read_labels(addresses)
    except Exception:
        got = {}
    wanted = [str(got.get(address) or '').strip() for address in addresses]

    def has(source):
        return bool(published('%s.%s_Rating' % (prefix, source)))

    picks = ['', '']
    taken = set()
    for index, source in enumerate(wanted):
        if source and has(source) and source not in taken:
            picks[index] = source
            taken.add(source)
    for index in range(2):
        if picks[index]:
            continue
        # Слот владельца пуст - ставим первую службу, у которой оценка есть.
        # Если владелец выбрал службу, которой у нас нет вовсе (Trakt и прочие),
        # добор тоже сработает: пустой слот лучше занять тем, что известно.
        for source in _RATING_FALLBACK:
            if source not in taken and has(source):
                picks[index] = source
                taken.add(source)
                break
    return picks


# Свойства слоя фона строки (их пишет только _publish).
_ROW_BACKGROUND_SUFFIXES = (
    'Fanart', 'Landscape', 'Still', 'TVShow.Fanart', 'TVShow.Landscape',
    'BlurImage', 'BlurImage.Original', 'Current.BlurImage',
    'Current.BlurImage.Original')


def _publish(window, prefix, meta, key=''):
    # Set when this row has its own background: the placeholder's properties are
    # taken down only after that picture has actually been written (see below).
    clear_fallback_after = False
    # логотип-надпись старого образца (title_logos_v1, рисовался со скобками): хранилище строк его не
    # показывает (row_store.row_properties), а кэш метаданных ещё держит путь; каталог убран как кэш
    # прошлой версии - пусть будет текст названия, а не пустое место (23.11.2026)
    if '/title_logos_v1/' in str(((meta or {}).get('art') or {}).get('clearlogo') or ''):
        meta = dict(meta)
        meta['art'] = dict(meta.get('art') or {}, clearlogo='')
    props = window_properties(meta, prefix)
    retry_at = safe_float((meta or {}).get('_provider_retry_at'))
    retry_active = retry_at > time.time()
    set_prop('%s.ProviderRetryAt' % prefix, retry_at if retry_active else '', window)
    set_prop('%s.ProviderRetryKey' % prefix, key if retry_active else '', window)
    art = meta.get('art') or {}
    listitem_prefix = prefix.endswith('ListItem')
    # ОДНА СТРОКА - ПУБЛИКАЦИЯ ТОЛЬКО БОГАТЕЕТ.
    #
    # На одну строку публикация приходит несколько раз: сначала местная модель
    # (то, что знает сам плагин), потом кэш, потом обогащённый ответ. Порядок по
    # богатству не выдержан, и более бедный проход снимал то, что уже стояло на
    # экране. Замер на .30 10.09.2026, опрос каждые 0.05-0.08 с, строка стоит на
    # месте:
    #   «Моана»: TMDb 6.2 -> ПУСТО -> КП 5.9 + TMDb 6.2 (0.09 с в пустоте);
    #   «Включи удовольствие!»: качество HDTV -> ПУСТО;
    #   «Мой папа — медведь 2»: Landscape -> ПУСТО -> Landscape (0.07 с) и на
    #   шестой секунде AF3SL.FallbackPrimaryReal: true -> ПУСТО, то есть фон
    #   отдали слою-заглушке при живой картинке.
    # По кадрам записей владельца 10.09.2026 это выглядит так: «какой-то рейтинг
    # появляется, исчезает и тд, выглядит как неоднократная пересборка при
    # скролле» и «непонятное мигание фона» - фон гаснет до чёрного и через
    # 0.2 с возвращается тот же самый, строка при этом не менялась.
    #
    # Правило то же, что уже действует для картинки («не убираем, её только
    # ЗАМЕНЯЮТ») и для логотипа сериала, только шире: пока ключ строки тот же,
    # ни одно поле не стирается - его можно лишь заменить непустым значением.
    # Смена строки этим не затронута: там уборка обязательна, иначе на экране
    # окажется чужое.
    # «Та же строка» - это про СТРОКУ, а не про ключ публикации. Ключ содержит
    # отпечаток, номер TMDb, название и подпись поставщиков, и любое из этих
    # полей меняется, пока строка стоит на месте: обогащение уточняет название
    # («Пойдем со мной» -> «Пойдём со мной»), опознание добавляет номер. С
    # ключом в основе правило переставало действовать ровно там, где оно нужнее
    # всего, и владелец 10.09.2026 увидел это снова: «строки с рейтингом КП всё
    # ещё пересобираются». Поэтому строку называют её собственные приметы -
    # полоса и путь, - как это уже делает служба (vcl_service._current_item_key
    # держит по той же причине только ярлык и путь).
    row_identity = ''
    if key:
        container_part = str(key).split('|', 1)[0]
        own = str((meta or {}).get('file') or '') or str((meta or {}).get('title') or '')
        if container_part and own:
            row_identity = '%s|%s' % (container_part, own)
    published_row = get_prop('%s.RowId' % prefix, window)
    # Отклонённое опознание - исключение: его значения и надо смести.
    same_row = bool(row_identity) and published_row == row_identity and not meta.get('_identity_rejected')
    # Эти поля живут не на экране, а в деле: мёртвый трейлер надо снимать, а
    # признаки состояния и так переставляются ниже своими set_prop.
    same_row_sweep = set(
        '%s.%s' % (prefix, suffix) for suffix in (
            'Trailer', 'TrailerFallback', 'TrailerCandidates',
            'IdentityPending', 'IdentityRejected'))
    # Фон - исключение из «та же строка». demote_publication фон не снимает и
    # тут же ставит RowId НОВОЙ строки, поэтому первая же публикация новой
    # строки считала себя «той же» и не снимала фон ПРОШЛОЙ: он держался, пока
    # не придёт свой, а у строки без обогащения (no_match, сайт недоступен) не
    # приходил вовсе и переезжал на следующие строки. Владелец на .20,
    # 15.11.2026: «завис фон от Друзей». Поэтому помним, ЧЬЙ фон стоит
    # (BackgroundRowId), и чужой снимаем при любой публикации.
    if listitem_prefix and same_row and get_prop(
            '%s.BackgroundRowId' % prefix, window) != row_identity:
        same_row_sweep |= set('%s.%s' % (prefix, suffix) for suffix in _ROW_BACKGROUND_SUFFIXES)
    media_dbtype = str((meta or {}).get('dbtype') or (meta or {}).get('tmdb_type') or '').strip().lower()
    suppress_raw_clearlogo = listitem_prefix and media_dbtype in ('movie', 'tvshow', 'season', 'episode', 'tv')
    clearlogo = art.get('clearlogo') or art.get('clearart') or ''
    if suppress_raw_clearlogo and not (meta or {}).get('_clearlogo_safe'):
        clearlogo = ''
    if listitem_prefix:
        # Universal background state: primary Home background is only a validated
        # enriched fanart/landscape. Local/plugin row art stays in the fallback
        # layer and must not hide fallback or blank it later.
        background = (art.get('fanart') or art.get('landscape') or '') if meta.get('_background_has_enriched_art') else ''
        if _is_episode_row(meta) and _still_not_poster(art.get('thumb')):
            # У серии фоном идёт её собственный кадр, и это правило одно на оба
            # ответа. Раньше местный ответ ставил кадр серии, а онлайн-ответ -
            # лендскейп сериала, и они сменяли друг друга на одной строке:
            # владелец описал это на сезоне 4 «Джек Ричер» как «фоны мигают, то
            # стилл, то лендскейп». Ниже есть та же мысль для случая, когда
            # обогащения нет вовсе; здесь она распространена на случай, когда
            # обогащение пришло - у серии всё равно свой кадр.
            background = art.get('thumb')
        if not background and media_dbtype == 'episode' and (
                meta.get('tmdb_id') or _is_tmdb_still(art.get('thumb'))
                or _is_tmdb_still(art.get('still'))):
            # Only trust art.get('thumb') as a stand-in for the episode's own
            # still when TMDb identity actually resolved for this show. When
            # it did not, meta is the local/pending pass-through model and
            # art['thumb'] is whatever the plugin published as its generic
            # thumb - on Filmix that is the show POSTER, not a still. Using a
            # portrait poster as the primary background here (previous bug:
            # no tmdb_id gate at all) marked AF3SL.FallbackPrimaryReal true and
            # wiped every regular fallback property below, leaving the screen
            # blank instead of the graceful poster/wash fallback that existed
            # before this whole episode-background branch was added.
            #
            # An episode still is row-level by nature: no provider publishes a
            # per-episode background, so _has_enriched_background_art - which
            # skips the 'local' source on purpose - is always false here and the
            # block below then strips Fanart/Landscape and hands the screen to
            # the poster fallback. Measured on <коробка>, focus on «Прекрасные
            # цветы» s1e1 in container 531: the row's own art was already the
            # TMDb still (image.tmdb.org/t/p/w1920/...) while every published
            # property was empty. The enriched-only rule exists to keep a plugin
            # poster out of the background; a still is not a poster, and it is
            # the art this row is about. Seasons and shows are untouched.
            #
            # Priority within the row's own art must put the still first: if the
            # episode has no still, both the row card (Image_Episode_Card in
            # vclvariables-images-includes.xml) and this background should show
            # landscape next, and only fall further (fanart, then empty -> the
            # generic fallback layer) once landscape is also missing. The
            # previous order (fanart, landscape, thumb/still last) put a
            # show-level fanart ahead of the episode's own still.
            background = (_still_not_poster(art.get('thumb'))
                          or art.get('landscape') or art.get('fanart') or '')
    else:
        background = art.get('fanart') or art.get('landscape') or art.get('poster') or ''
        if _is_episode_row(meta):
            # У СЕРИИ ПОСТЕР ФОНОМ НЕ ИДЁТ - ни постер сериала, ни постер
            # Кинопоиска. Замер на .30 06.09.2026, «Осколки», «Эпизод 1»: в
            # списке фоном стоял кадр серии
            # (image.tmdb.org/t/p/w1920/fhsYQZ0DRCQFd8m9AxmF6wwdXXW.jpg), а в
            # момент включения плеер публиковал
            # kinopoiskapiunofficial.tech/images/posters/kp/6531565.jpg. Это и
            # есть «скачок фона при включении эпизода», на который владелец
            # жаловался 05.09: правка того дня держала кадр из модели плеера, а
            # у плеера своего кадра не оказалось вовсе - и сработал запасной
            # постер прямо здесь, ниже всех правил.
            #
            # Порядок тот же, что у строки списка, и постер отсекается по
            # адресу. Если у плеера кадра нет совсем - берём тот, что уже
            # показан для этой же серии: смены фона тогда не происходит вовсе.
            clean = (_still_not_poster(art.get('fanart'))
                     or _still_not_poster(art.get('landscape'))
                     or _still_not_poster(art.get('thumb'))
                     or _still_not_poster(art.get('still')))
            if not clean:
                clean = (get_prop('SublimeHelper.ListItem.BlurImage.Original', window)
                         or get_prop('SublimeHelper.ListItem.BlurImage', window))
            background = clean or ''
    # Keep the image interface formerly consumed by the skin. The source image is
    # immediately usable even when an optional platform image processor is absent.
    # Строка из зеркала приносит готовую подложку - файл, который сборщик уже
    # написал (hub/builder.py). Она идёт в BlurImage вместо ссылки на картинку
    # провайдера: именно BlurImage смотрит Exp_BackgroundPrimaryArt_IsEmpty, то
    # есть слой-заглушка для такой строки не включится ни на кадр.
    prepared = str((meta or {}).get('_prepared_background') or '')
    if background and _picture_host_down(background):
        # Склад поставщика молчит: этой картинки не будет, ждать и дозагружать
        # её нечего. Берём готовый файл, если он есть, иначе слой-заглушка.
        background = ''
    if clearlogo:
        props['%s.CropImage' % prefix] = clearlogo
    # ОДНА схема на все виджеты. Раньше их было две, и владелец увидел это
    # прямо на экране: «В Филадельфии всегда солнечно» в «Избранном» показывал
    # резкий кадр TMDb, а в «Все» - наш локальный файл, то есть ту же картинку,
    # но размытую. Строку избранного опознаёт служба на лету и ставит фоном сам
    # кадр; строка из зеркала приносила готовый файл, и он вытеснял кадр.
    # Теперь фон везде один и тот же - кадр, который дал поставщик. Готовый
    # файл остаётся тем, чем он и был задуман: картинкой на те доли секунды,
    # пока Kodi ещё не скачал кадр (ниже), - и никогда не подменяет его собой.
    already_published = ''
    if listitem_prefix:
        already_published = (get_prop('%s.Fanart' % prefix, window)
                             or get_prop('%s.Landscape' % prefix, window))
    if (listitem_prefix and background and HOLD_BACKGROUND_UNTIL_CACHED
            and background != already_published
            and not _texture_ready(background)):
        # ... unless it is the picture ALREADY on screen. A republish of the
        # same row (the settled pass, the slow safety poll) recomputes this, and
        # the readiness answer can go stale - the probe memo is bounded and its
        # attempt counter expires. Withholding it then CLEARED a background that
        # was drawn and visible, the fallback layer took over for a turn, and the
        # picture came back: one blink about a second after focus, exactly what
        # the owner reported. A picture once shown is never taken back.
        #
        # The picture is real but Kodi has not got it yet. Publishing it now
        # would hide the fallback layer (Exp_BackgroundFallbackArt_Active is
        # gated on the primary being empty) and put nothing in its place - the
        # blank background the owner filmed while scrolling. So it is held back
        # for exactly as long as it takes to fetch, and the next publish tick -
        # which runs from the cached metadata, so costs nothing - lets it
        # through.
        _fetch_texture_async(background)
        # Пустота здесь и была «фон пропал»: слой-заглушка включается не
        # мгновенно, и между ними экран оставался чёрным. Если готовый файл
        # есть - показываем его: он лежит на диске и рисуется сразу, а как
        # только Kodi скачает кадр, следующая публикация поставит кадр.
        background = prepared or ''
    # Картинка выбирается ПОСЛЕ решения об ожидании, иначе в свойство попадал
    # ещё не скачанный кадр, который Kodi нечем нарисовать.
    if background or prepared:
        props['%s.BlurImage' % prefix] = background or prepared
        props['%s.BlurImage.Original' % prefix] = background or prepared
    if listitem_prefix and not background:
        # Do not let local/plugin fanart/landscape keep Exp_BackgroundPrimaryArt
        # active. If no enriched background exists, fallback must remain visible.
        #
        # But only if the fallback layer actually HAS something to show. Recorded
        # on .20 while the owner scrolled at his own pace: a row with no enriched
        # art of its own published here, this clear emptied the primary layer,
        # the placeholder arrived 0.2-0.6 s later, and in between the screen was
        # black - «обогащённый -> ПУСТО -> фолбек». Nothing is ever taken down
        # with nothing to put in its place: the previous picture holds for those
        # few tenths and is then replaced, which the eye reads as one change
        # instead of a flash.
        # "Is there a placeholder" is not the question - the two layers are
        # mutually exclusive, the placeholder only shows once this one is empty,
        # and the placeholder that was up belonged to the PREVIOUS row. The
        # question is whether the placeholder is THIS row's: only then does
        # clearing here swap one picture for another instead of showing black.
        # The row's own path is what both sides can name, so the placeholder
        # publisher writes it (AF3SL.FallbackRowPath) and this compares it with
        # the row being published. Traced on .20 at the owner's own pace: «Рая не
        # существует» went enriched -> ПУСТО -> placeholder, a 0.3 s black gap,
        # because any placeholder counted as ready - and the one that was up
        # belonged to the row before it.
        fallback_ready = False
        try:
            fb_art = (window.getProperty('AF3SL.FallbackPreparedArt')
                      or window.getProperty('AF3SL.FallbackArt') or '')
            fb_row = window.getProperty('AF3SL.FallbackRowPath') or ''
            row_path = str((meta or {}).get('file') or '')
            fallback_ready = bool(fb_art and fb_row and row_path
                                  and fb_row == row_path)
        except Exception:
            fallback_ready = False
        if fallback_ready:
            for suffix in ('Fanart', 'Landscape', 'TVShow.Fanart', 'TVShow.Landscape',
                           'BlurImage', 'BlurImage.Original', 'Current.BlurImage',
                           'Current.BlurImage.Original'):
                props.pop('%s.%s' % (prefix, suffix), None)
        else:
            # Фон прошлой строки не остаётся НИКОГДА. Здесь держалась картинка,
            # которая уже на экране, - чтобы не мигнуть чёрным, пока у новой
            # строки своя не готова. Владелец 08.09.2026, по кадрам своей
            # записи: описание и оценки одного фильма при фоне другого - «фоны
            # зависают и наследуются», «это полный пиздец». Чужой фон хуже
            # паузы, поэтому паузу и оставляем: слой-заглушка этой же строки
            # включается сам (ветка fallback_ready выше), а чужого арта на
            # экране больше не бывает.
            for suffix in ('Fanart', 'Landscape', 'TVShow.Fanart', 'TVShow.Landscape',
                           'BlurImage', 'BlurImage.Original', 'Current.BlurImage',
                           'Current.BlurImage.Original'):
                props.pop('%s.%s' % (prefix, suffix), None)
        props.pop('SublimeHelper.ListItem.Current.BlurImage', None)
        props.pop('SublimeHelper.ListItem.Current.BlurImage.Original', None)
    if listitem_prefix:
        # The metadata publisher is the authoritative source for validated primary
        # background. Keep the fallback XML gate synchronized here instead of
        # relying on the fallback polling service to rediscover the same state.
        if background:
            # The placeholder's properties are taken down AFTER this row's own
            # picture has been written, not before. They used to be cleared
            # right here, while the picture itself is only written further down
            # this function - and the two layers are mutually exclusive, so for
            # a frame or two nothing was on screen. Recorded on .20 at 50 Hz
            # while the owner scrolled: «фолбек -> ПУСТО -> обогащённый» inside
            # 20 ms, «обогащённый -> ПУСТО -> фолбек» inside 100 ms. Short, and
            # exactly what the eye catches as the old background flickering.
            clear_fallback_after = True
        elif not (meta or {}).get('_background_resolving') and not same_row:
            # ...и только если строка сменилась. Замер выше: на шестой секунде
            # стояния на одной строке приходил проход без обогащённого фона и
            # снимал этот признак - слой-заглушка забирал экран у живой
            # картинки. Это и есть «непонятное мигание фона».
            try:
                window.clearProperty('AF3SL.FallbackPrimaryReal')
            except Exception:
                pass
        trailer_candidates = []
        for row in (meta.get('trailer_candidates') or []):
            url = str((row or {}).get('url') or '').strip()
            if url and not cache.is_trailer_failed(url):
                trailer_candidates.append({
                    'url': url,
                    'language': str((row or {}).get('language') or ''),
                    'official': bool((row or {}).get('official')),
                    'source': str((row or {}).get('source') or ''),
                })
        if trailer_candidates:
            props['%s.TrailerCandidates' % prefix] = json.dumps(
                trailer_candidates[:8], ensure_ascii=False, separators=(',', ':'))
        if clearlogo:
            props['SublimeHelper.ListItem.Current.CropImage'] = clearlogo
            props['SublimeHelper.ListItem.CropImage'] = clearlogo
            props['SublimeHelper.ListItem.Current.CropImage'] = clearlogo
        if background:
            props['SublimeHelper.ListItem.Current.BlurImage'] = prepared or background
            props['SublimeHelper.ListItem.Current.BlurImage.Original'] = prepared or background
    marker_name = 'SublimeHelper.Published.%s' % ('Player' if prefix.endswith('Player') else 'ListItem')
    previous = set(filter(None, get_prop(marker_name, window).split('|')))
    current = set(props)
    # Логотип сериала внутри одного сериала не роняем. Замер на .20 07.09.2026
    # в списке серий «Во все тяжкие»: служба публикует логотип, но на каждом
    # переходе он пропадал на 0.15-0.4 с и возвращался - у новой строки
    # логотипа ещё нет, и уборка «что публиковали раньше, а теперь нет» его
    # стирала. В эту щель и лезла текстовая подмена: владелец видел
    # «название эпизода - название сериала - название эпизода».
    #
    # Правило то же, что у фона (см. demote_publication): картинку не убираем,
    # её только ЗАМЕНЯЮТ. Здесь - пока сериал тот же.
    keep_logo_props = set()
    if prefix.endswith('ListItem') and str(meta.get('dbtype') or '') in (
            'episode', 'season') and not (meta.get('art') or {}).get('clearlogo'):
        show_now = str(meta.get('tvshowtitle') or '').strip().casefold()
        show_logo_of = str(get_prop('SublimeHelper.ListItem.LogoShow', window) or '').strip().casefold()
        # Сравнение по ПУТИ - главное, по имени - запасное. Замер на .30
        # 08.09.2026: в списке серий «Джека Ричера» у четырёх серий из десяти
        # логотипа не было НИКОГДА, и вместе с ним пропадали «сеть» (Prime
        # Video) и логотип студии. Причина - здесь: условие держалось на
        # meta['tvshowtitle'], а у этих серий опознание имени не дало вовсе
        # (пустое имя не совпадёт ни с чем), и уборка «что публиковали раньше,
        # а теперь нет» стирала логотип. Путь же есть всегда и у всех серий
        # сериала он один - см. _show_key.
        key_now = _show_key(meta.get('file'))
        key_of = str(get_prop('SublimeHelper.ListItem.LogoShowKey', window) or '').strip()
        same_show = bool(key_now) and key_now == key_of
        if not same_show:
            same_show = bool(show_now) and show_now == show_logo_of
        if same_show:
            keep_logo_props = {'SublimeHelper.ListItem.ClearLogo',
                               'SublimeHelper.ListItem.CropImage',
                               'SublimeHelper.ListItem.Current.CropImage',
                               'SublimeHelper.ListItem.SuppressRawClearLogo'}
            # Сеть и студия принадлежат СЕРИАЛУ, а не серии: их владелец
            # увидел пропавшими на тех же строках («studio logo не показывается
            # у части фильмов сериалов»). Держим ровно то, что уже было
            # опубликовано для этого сериала.
            keep_logo_props |= {name for name in previous
                                if name.startswith('SublimeHelper.ListItem.Network.')
                                or name.startswith('SublimeHelper.ListItem.Studio.')
                                or name == 'SublimeHelper.ListItem.StudioLogo'}
    if (props.get('SublimeHelper.ListItem.CropImage')
            and str(meta.get('tvshowtitle') or '').strip()):
        # Запоминаем, ЧЬЁМУ сериалу принадлежит опубликованный логотип: по этой
        # метке следующая строка того же сериала его сохранит.
        set_prop('SublimeHelper.ListItem.LogoShow',
                 str(meta.get('tvshowtitle') or '').strip(), window)
    if props.get('SublimeHelper.ListItem.CropImage'):
        # Тот же признак, но по пути: он работает и когда имени сериала нет.
        logo_key = _show_key(meta.get('file'))
        if logo_key:
            set_prop('SublimeHelper.ListItem.LogoShowKey', logo_key, window)
    sweep = (previous - current) - keep_logo_props
    if same_row:
        # Пока строка та же, «раньше публиковали, теперь нет» не значит «убрать»:
        # это значит, что нынешний проход про это поле просто не знает.
        sweep &= same_row_sweep
    for name in sweep:
        if get_prop(name, window):
            window.clearProperty(name)
    for name, value in props.items():
        value = '' if value in (None, '') else str(value)
        if not value:
            if same_row and name not in same_row_sweep:
                continue
            if get_prop(name, window):
                window.clearProperty(name)
        elif get_prop(name, window) != value:
            window.setProperty(name, value)
    if clear_fallback_after:
        # Now the picture is up, so the layer underneath it can go.
        try:
            window.setProperty('AF3SL.FallbackPrimaryReal', 'true')
            for _name in (
                    'AF3SL.FallbackArt', 'AF3SL.FallbackArtKind', 'AF3SL.FallbackKey',
                    'AF3SL.FallbackSourceKey', 'AF3SL.FallbackPrepareNextPoll',
                    'AF3SL.FallbackPrepared', 'AF3SL.FallbackPreparedArt',
                    'AF3SL.FallbackColorNextPoll', 'AF3SL.FallbackSourceArt',
                    'AF3SL.FallbackWashColorSource', 'AF3SL.FallbackArtWashed',
                    'AF3SL.FallbackArtWashedSource'):
                window.clearProperty(_name)
        except Exception:
            pass
    slot1, slot2 = _rating_slots(
        lambda name: get_prop(name, window), prefix, media_dbtype)
    set_prop('%s.RatingSlot.Item01' % prefix, slot1, window)
    set_prop('%s.RatingSlot.Item02' % prefix, slot2, window)
    if prefix.endswith('ListItem'):
        set_prop('%s.IdentityPending' % prefix, 'true' if meta.get('_identity_pending') else '', window)
        # A rejected plugin id bundle is not by itself a reason to blank the
        # background. After the rejection the providers re-resolve by title and
        # the surviving model is validated, so it can carry correct enriched art
        # (this is the normal case when the plugin and TMDb use different
        # localised titles for the same original title). Signal the rejection to
        # XML only when the resolve produced no enriched background to show.
        set_prop('%s.IdentityRejected' % prefix,
                 'true' if (meta.get('_identity_rejected')
                            and not meta.get('_background_has_enriched_art')) else '', window)
        set_prop('%s.BackgroundResolving' % prefix, 'true' if meta.get('_background_resolving') else '', window)
        # Hub XML reads these image properties from the active runtime window,
        # not only from Window(Home). Publish to every currently visible local
        # Home/hub window. This restores clearlogo/blur art while avoiding writes
        # to windows that have already closed.
        for current_window in _visible_local_windows():
            for name in (
                'SublimeHelper.ListItem.CropImage', 'SublimeHelper.ListItem.BlurImage',
                'SublimeHelper.ListItem.BlurImage.Original',
            ):
                value = props.get(name)
                value = '' if value in (None, '') else str(value)
                if value:
                    if get_prop(name, current_window) != value:
                        current_window.setProperty(name, value)
                elif get_prop(name, current_window):
                    current_window.clearProperty(name)
    # Список опубликованного - это то, что РЕАЛЬНО стоит в окне, а не то, что
    # принёс нынешний проход. Раньше писался только нынешний набор, и с
    # правилом «пока строка та же, ничего не стираем» получалась дыра: бедный
    # проход по той же строке оставлял оценки и постер на экране, но забывал их
    # в списке - и на смене строки уборка их уже не находила. Проверено
    # сценарием 5 в tools/simulate_flows.py: без этой строки оценки прошлого
    # фильма переезжали на следующий.
    set_prop(marker_name, '|'.join(sorted(
        name for name in (previous | current) if get_prop(name, window))), window)
    if key:
        set_prop('%s.Key' % prefix, key, window)
    if row_identity:
        set_prop('%s.RowId' % prefix, row_identity, window)
    if listitem_prefix:
        # Всё, что после этой публикации осталось в слое фона, принадлежит этой
        # строке: чужое снято выше.
        has_background = any(get_prop('%s.%s' % (prefix, suffix), window)
                             for suffix in _ROW_BACKGROUND_SUFFIXES)
        set_prop('%s.BackgroundRowId' % prefix,
                 row_identity if (row_identity and has_background) else '', window)
    if prefix.endswith('ListItem'):
        if meta.get('_identity_rejected'):
            for stale_name in (
                    'VCL.Widget.Fanart', 'VCL.Widget.Trailer',
                    'VCL.ActionPopup.Fanart', 'VCL.ActionPopup.Trailer',
                    'VCL.ActionPopup.TrailerFallback', 'VCL.ActionPopup.TrailerCandidates'):
                window.clearProperty(stale_name)
            popup = _visible_custom_window(1127)
            if popup is not None:
                popup.clearProperty('VCL.ActionPopup.FanartSnapshot')
        set_prop('SublimeHelper.ListItem.Monitor.DBID', meta.get('dbid'), window)
        set_prop('SublimeHelper.ListItem.Monitor.TMDb_ID', meta.get('tmdb_id'), window)
        set_prop('SublimeHelper.ListItem.Monitor.TMDb_Type', meta.get('tmdb_type'), window)
        set_prop('SublimeHelper.ListItem.Monitor.Season', meta.get('season'), window)
        set_prop('SublimeHelper.ListItem.Monitor.Episode', meta.get('episode'), window)
        # Action-popup snapshots must use the validated/resolved ids rather than
        # plugin-specific UniqueID values from the focused list item.
        set_prop('VCL.Widget.TMDB_ID', meta.get('tmdb_id'), window)
        set_prop('VCL.Widget.TMDB_Type', meta.get('tmdb_type'), window)
        set_prop('VCL.Widget.Trailer', meta.get('trailer'), window)
        set_prop('VCL.Widget.Fanart', background if background else '', window)
        set_prop('VCL.Widget.Kinopoisk_ID', meta.get('kinopoisk_id'), window)
        set_prop('VCL.Widget.IMDb_ID', meta.get('imdb_id'), window)
        # When an action popup/dialog is open, keep its source item frozen but
        # allow a late online result for that same item to enrich the snapshot.
        if key and get_prop('VCL.ActionPopup.SourceKey', window) == key:
            for prop_name, value in (
                ('VCL.ActionPopup.TMDB_ID', meta.get('tmdb_id')),
                ('VCL.ActionPopup.TMDB_Type', meta.get('tmdb_type')),
                ('VCL.ActionPopup.Kinopoisk_ID', meta.get('kinopoisk_id')),
                ('VCL.ActionPopup.IMDb_ID', meta.get('imdb_id')),
                ('VCL.ActionPopup.Title', meta.get('title')),
                ('VCL.ActionPopup.Fanart', (meta.get('art') or {}).get('fanart')),
                ('VCL.ActionPopup.Trailer', meta.get('trailer')),
                ('VCL.ActionPopup.TrailerFallback', meta.get('trailer_fallback')),
                ('VCL.ActionPopup.TrailerCandidates', props.get('SublimeHelper.ListItem.TrailerCandidates')),
            ):
                if value not in (None, ''):
                    set_prop(prop_name, value, window)
                elif meta.get('_identity_rejected') and prop_name in (
                        'VCL.ActionPopup.Fanart', 'VCL.ActionPopup.Trailer',
                        'VCL.ActionPopup.TrailerFallback', 'VCL.ActionPopup.TrailerCandidates'):
                    window.clearProperty(prop_name)
            popup_fanart = (meta.get('art') or {}).get('fanart') or ''
            popup = _visible_custom_window(1127)
            if popup_fanart and popup is not None:
                popup.setProperty('VCL.ActionPopup.FanartSnapshot', str(popup_fanart))
        for source, target in (('title','base_title'),('title','base_label'),('tvshowtitle','base_tvshowtitle'),('plot','base_plot'),('dbtype','base_dbtype'),('file','base_folderpath')):
            set_prop('SublimeHelper.ListItem.%s' % target, meta.get(source), window)
        art = meta.get('art') or {}
        set_prop('SublimeHelper.ListItem.base_poster', art.get('poster'), window)
        set_prop('SublimeHelper.ListItem.base_clearlogo', art.get('clearlogo'), window)
        set_prop('SublimeHelper.ListItem.base_icon', art.get('icon') or art.get('thumb') or art.get('poster'), window)




_POST_ID_IN_PATH = re.compile(r'/(\d+)-')


class _LogoDeferred(Exception):
    """Raised to leave the clearlogo stage without touching the network."""


def _metadata_entry_complete(value):
    if isinstance(value, dict) and value.get('_logo_pending'):
        return False
    """Whether a cached answer is worth reusing for another row.

    Measured on .20 with «Шанхайский сюрприз»: the resolve log said fanart=yes,
    clearlogo=yes, rating present - and the row published title and plot only,
    because the shared entry for that film had been stored earlier in a thinner
    state and every later visit hit it. A partial answer may be published for the
    row that produced it, but it must never become the answer for the film.
    """
    if not isinstance(value, dict):
        return False
    art = value.get('art') or {}
    if not (art.get('fanart') or art.get('landscape') or art.get('poster')):
        return False
    return bool(value.get('plot') or value.get('rating') or value.get('votes'))


def _identity_cache_id(local):
    """A key for the FILM, not for the row that happens to show it.

    The final-metadata cache was keyed by container id + row fingerprint. Two
    consequences, both measured on these boxes: the same film in another widget
    was resolved from scratch, and everything the lane warm-up resolved was
    stored under a key the focused row never reads - the work was done and
    thrown away. One identity, one cache entry: warmed rows are then instant on
    first focus, and a film already seen anywhere is instant everywhere.

    Ids first, because they are exact. A provider post id is next best - it is
    the same film by definition. Title and year are the last resort, and they
    still pass the country guard before anything cached is published.
    """
    local = local or {}
    kind = str(local.get('dbtype') or local.get('media_type') or '').lower()
    kind = 'tv' if kind in ('tvshow', 'season', 'episode', 'tv') else 'movie'
    season = str(local.get('season') or '')
    episode = str(local.get('episode') or '')
    suffix = ('|%s|%s' % (season, episode)) if (season or episode) else ''
    tmdb = str(local.get('tmdb_id') or '').strip()
    if tmdb.isdigit():
        return 'tmdb:%s:%s%s' % (kind, tmdb, suffix)
    imdb = str(local.get('imdb_id') or '').strip()
    if imdb.startswith('tt'):
        return 'imdb:%s:%s%s' % (kind, imdb, suffix)
    kp = str(local.get('kinopoisk_id') or '').strip()
    if kp.isdigit() and kp != '0':
        return 'kp:%s:%s%s' % (kind, kp, suffix)
    path = str(local.get('file') or '')
    if 'plugin.video.' in path:
        hit = _POST_ID_IN_PATH.search(path)
        if hit:
            return 'post:%s:%s%s' % (kind, hit.group(1), suffix)
    # Nothing exact to key on. Title and year were tried here and they were a
    # mistake: the cache started answering with a different film, and the
    # country guard - the only thing that caught it - then left the row with no
    # metadata at all. Measured on .20: «Запретный город» was answered with
    # «Заклятие монахини», and «Заклятие монахини» with «Risqué». A row without
    # ids keeps its own row-specific key, exactly as before.
    return ''


def _final_metadata_cache_key(key):
    return '%s:%s' % (_FINAL_METADATA_CACHE_NS, key)


def _cached_final_metadata_country_ok(local, cached):
    """Validate disk/memory final metadata against the current focused source country.

    Provider-country confirmation was added after the final metadata cache had
    already stored some wrong title-only matches. Cached results bypass the
    provider pipeline, so the same country gate must run here before publishing
    cached artwork.
    """
    try:
        source_codes = _identity_country_codes({}, local or {})
        if not source_codes:
            return True
        provider_codes = _model_country_codes(cached or {})
        if not provider_codes:
            log('cached final metadata reject: country_missing title=%s source_country=%s' % (
                (local or {}).get('title') or '', ','.join(sorted(source_codes)) or '-'), xbmc.LOGWARNING)
            return False
        if source_codes.intersection(provider_codes):
            return True
        log('cached final metadata reject: country_mismatch title=%s source_country=%s cached_country=%s cached_title=%s' % (
            (local or {}).get('title') or '', ','.join(sorted(source_codes)) or '-',
            ','.join(sorted(provider_codes)) or '-', (cached or {}).get('title') or ''), xbmc.LOGWARNING)
        return False
    except Exception as exc:
        log('cached final metadata country check skipped: %s' % exc, xbmc.LOGWARNING)
        return True

class MetadataWorker(object):
    def __init__(self):
        self.queue = queue.Queue(maxsize=4)
        self.pending = set()
        self.latest = {}
        self.results = OrderedDict()
        self.results_max = 128
        self.lock = threading.RLock()
        # Prewarm work (Home widget neighbours) is a distinct concern from the
        # one focused-item fast path above: it has no "current target" to be
        # cancelled in favour of, must never publish to the screen, and must
        # never be able to make the real focused item's own job look stale.
        # A fully separate queue/thread/pending-set/dedupe keeps it from ever
        # touching self.latest or self.pending, so it can only ever help
        # (populate self.results ahead of time) and never compete for or
        # invalidate the one job that is actually on screen right now.
        self.prewarm_queue = queue.Queue(maxsize=8)
        self.prewarm_pending = set()
        log('providers configured: tmdb=%s kinopoisk=%s imdb=%s fanart=%s mdblist=%s pvr=%s language=%s region=%s' % (
            'yes' if tmdb.available() else 'no', 'yes' if kinopoisk.available() else 'no',
            'yes' if config.use_omdb() else 'no', 'yes' if config.use_fanart() else 'no',
            'yes' if config.use_mdblist() else 'no',
            'yes' if config.pvr_lookups_enabled() else 'no', config.language(), config.region()), xbmc.LOGINFO)
        self.thread = threading.Thread(target=self._run, name='SublimeMetadataWorker')
        self.thread.daemon = True
        self.thread.start()
        self.prewarm_thread = threading.Thread(target=self._run_prewarm, name='SublimeMetadataPrewarm')
        self.prewarm_thread.daemon = True
        self.prewarm_thread.start()

    def invalidate(self, key, prefix):
        with self.lock:
            self.latest[prefix] = key

    def get_cached(self, key, local=None):
        identity = _identity_cache_id(local) if local else ''
        if identity:
            found = self._get_cached_under(identity, local)
            if found is not None and _metadata_entry_complete(found):
                return found
        return self._get_cached_under(key, local)

    def _get_cached_under(self, key, local=None):
        with self.lock:
            if key in self.results:
                value = self.results.pop(key)
                if not _cached_final_metadata_country_ok(local or {}, value or {}):
                    return None
                self.results[key] = value
                return copy.deepcopy(value)
        disk_value = cache.get(_final_metadata_cache_key(key), _FINAL_METADATA_TTL)
        if (isinstance(disk_value, dict) and not ((disk_value.get('art') or {}).get('clearlogo'))
                and cache.get(_final_metadata_cache_key(key), _NO_LOGO_METADATA_TTL) is None):
            # Ответ без логотипа живёт сутки, а не две недели: логотип мог появиться у
            # поставщика или у нас (второй API Кинопоиска - «Вествуд», 22.11.2026).
            disk_value = None
        if isinstance(disk_value, dict):
            if not _cached_final_metadata_country_ok(local or {}, disk_value):
                try:
                    cache.delete(_final_metadata_cache_key(key))
                except Exception:
                    pass
                return None
            with self.lock:
                self.results.pop(key, None)
                self.results[key] = copy.deepcopy(disk_value)
                while len(self.results) > self.results_max:
                    self.results.popitem(last=False)
            return copy.deepcopy(disk_value)
        return None

    def _cache_result(self, key, value, local=None):
        identity = _identity_cache_id(local) if local else ''
        if identity and _metadata_entry_complete(value):
            # One entry per film - but only a complete answer earns that place.
            # A thin one stays under the row's own key, where it can help that
            # row and cannot speak for the film.
            key = identity
        if not key or not isinstance(value, dict) or value.get('_provider_retry_at'):
            return
        snapshot = copy.deepcopy(value)
        with self.lock:
            self.results.pop(key, None)
            self.results[key] = snapshot
            while len(self.results) > self.results_max:
                self.results.popitem(last=False)
        cache.set(_final_metadata_cache_key(key), snapshot)

    def clear_results(self):
        with self.lock:
            self.results.clear()

    def submit(self, key, prefix, local, params=None):
        if not key or not config.online_enabled() or not _metadata_available():
            return
        job_key = '%s|%s' % (prefix, key)
        with self.lock:
            self.latest[prefix] = key
            if job_key in self.pending:
                return
            self.pending.add(job_key)
        job = (job_key, key, prefix, dict(local or {}), dict(params or {}))
        try:
            self.queue.put_nowait(job)
            set_prop('SublimeHelper.IsUpdating', 'true', home_window())
            set_prop('SublimeHelper.IsUpdatingDetails', 'true', home_window())
            set_prop('SublimeHelper.IsUpdatingRatings', 'true', home_window())
        except queue.Full:
            # Remove the oldest waiting item; an already running stale request exits
            # at the next provider stage through cancel_check below.
            try:
                old_job = self.queue.get_nowait()
                with self.lock:
                    self.pending.discard(old_job[0])
                self.queue.task_done()
                self.queue.put_nowait(job)
            except Exception:
                with self.lock:
                    self.pending.discard(job_key)

    def submit_prewarm(self, key, local, params=None):
        """Resolve and cache one item on the dedicated prewarm thread.

        Never touches self.latest/self.pending (the focused item's own
        staleness tracking) and never publishes anything - a neighbour that
        is still resolving when the user actually reaches it looks exactly
        like a cache miss always did, just usually is not one anymore.
        """
        if not key or not config.online_enabled() or not _metadata_available():
            return False
        with self.lock:
            if key in self.prewarm_pending:
                return False
            self.prewarm_pending.add(key)
        job = (key, dict(local or {}), dict(params or {}))
        try:
            self.prewarm_queue.put_nowait(job)
            return True
        except queue.Full:
            # The queue holds eight jobs and one job takes seconds, so a
            # warm-up that submits faster than that will meet a full queue.
            # Saying so matters: the caller must not record a dropped job as
            # an attempt, or the row stays cold until the memo expires.
            with self.lock:
                self.prewarm_pending.discard(key)
            return False

    def focused_busy(self):
        """True while a focused-row job is queued or running."""
        with self.lock:
            return bool(self.pending)

    def prewarm_backlog(self):
        """How many rows are queued or in flight on the prewarm thread."""
        try:
            return self.prewarm_queue.qsize()
        except Exception:
            return 0

    def _warm_derived(self, meta, local):
        """Textures, blurred background and wash colour - but never in front of
        the row on screen.

        Measured the hard way on <коробка>: doing all three unconditionally
        turned a 0.3-0.6 s scroll into 7-10.8 s, because blurring a 1920x1080
        background and extracting a colour are real CPU work on these boxes and
        the focused row's own resolution was left fighting for the same cores.
        Warming is only ever worth it while nothing is waiting.
        """
        if self.focused_busy() or _user_busy():
            return False
        _precache_art(meta)
        if self.focused_busy() or _user_busy():
            return False
        _prewarm_fallback_background(local)
        return True

    def _run_prewarm(self):
        # `while not _stopping()` и get с таймаутом вместо `while True` и
        # блокирующего get: иначе поток не выходит никогда, и Kodi ждёт его
        # пять секунд при каждой остановке, а потом убивает.
        while not _stopping():
            try:
                key, local, params = self.prewarm_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            try:
                # Never resolve ahead of the row on screen, and never while the
                # user is moving. The threads are separate but they share the
                # providers and the cores, and Kodi needs those cores to draw
                # the art of the row just focused. Waiting here is free - a
                # warm-up has no deadline.
                # Оба ожидания прерываются остановкой. Второе особенно: его
                # предел - PREWARM_USER_WAIT_LIMIT, то есть до минуты сна по
                # четверти секунды, и всё это время поток был жив.
                waited = 0.0
                while (waited < FOCUS_YIELD_LIMIT and self.focused_busy()
                       and not _stopping()):
                    time.sleep(0.1)
                    waited += 0.1
                waited = 0.0
                while (waited < PREWARM_USER_WAIT_LIMIT and _user_busy()
                       and not _stopping()):
                    time.sleep(0.25)
                    waited += 0.25
                if _stopping():
                    continue
                cached = self.get_cached(key, local)
                if cached is not None:
                    # Resolved already, but its images may still be missing from
                    # Kodi's texture cache - which is the part the eye sees.
                    self._warm_derived(cached, local)
                    continue
                # cancel_check is why this pipeline has one: a warm-up job in
                # flight was the last thing still able to take the cores at the
                # exact moment the user moved, because the check before starting
                # cannot help a job that already started. Now the resolution
                # itself gives up the moment the remote is touched, and the row
                # is left for a later pass.
                # Yields to the user again. Letting it run through keypresses
                # was measured worse where it matters: on .30 the row itself
                # stopped changing for up to 4.5 s while these jobs competed,
                # and a stalled interface is worse than a background picture
                # that arrives late.
                # Logos included: see logo_fetch_scope. Without this the warm-up
                # cached a row's whole answer except the one piece the eye waits
                # for, and the row paid for it again the moment it was focused.
                with logo_fetch_scope(True):
                    remote = fetch_online_metadata(params, local,
                                                   cancel_check=_cancel_warmup,
                                                   base_callback=None)
                # Keep what was learned, always. The network call is already
                # paid for, and a result thrown away because the user touched
                # the remote a second ago has to be paid for again the next
                # time that row is focused. Measured on .30: 217 rows warmed,
                # 203 of them stuck "in flight" and only 6 ids ever learned,
                # because this is where their answers were being discarded.
                self._cache_result(key, remote, local)
                if _user_busy():
                    # Only the derived work - textures, blur, wash - waits for
                    # a quiet moment; that is the part that costs cores.
                    continue
                self._warm_derived(remote, local)
            except Exception as exc:
                # At debug level this was invisible, and a prewarm job that
                # throws every time looks exactly like one that quietly does
                # nothing: measured on .30, twelve jobs accepted per pass and
                # not one result ever cached. A warm-up failing is worth a line.
                log('metadata prewarm failed: %s: %s' % (type(exc).__name__, exc),
                    xbmc.LOGWARNING)
            finally:
                with self.lock:
                    self.prewarm_pending.discard(key)
                self.prewarm_queue.task_done()
                # One breath per job: without it this thread simply runs flat
                # out through the whole queue.
                time.sleep(PREWARM_JOB_GAP)

    def _run(self):
        # То же, что и в _run_prewarm: без выхода по остановке этот поток
        # держал Kodi ровно пять секунд на каждой остановке.
        while not _stopping():
            try:
                job_key, key, prefix, local, params = self.queue.get(timeout=0.5)
            except queue.Empty:
                continue
            try:
                with self.lock:
                    stale = self.latest.get(prefix) != key
                if stale:
                    continue
                def cancelled():
                    with self.lock:
                        return self.latest.get(prefix) != key
                # Готовая подложка строки - локальный файл, который сборщик уже
                # написал. Онлайн-ответ её не знает, и публикация ответа
                # заменяла картинку на экране удалённым адресом, которого у
                # Kodi ещё нет: фон пропадал, а при переходе на соседнюю строку
                # появлялся на мгновение и снова исчезал. Владелец описал это
                # как «фолбек вместо обогащённого, обогащённый мигает при
                # переходе вверх» 2026-08-29. Файл лежит рядом и рисуется
                # мгновенно, поэтому он переживает любой онлайн-ответ.
                prepared_row_background = str((local or {}).get('_prepared_background') or '')

                # Кадр самой серии: онлайн-ответ его не знает и отдаёт
                # лендскейп сериала. Ответ дополняется кадром строки, иначе
                # фон на строке меняется от публикации к публикации.
                local_art = (local or {}).get('art') or {}
                row_is_episode = _is_episode_row(local)
                row_still = str(local_art.get('thumb') or '') if row_is_episode else ''
                # Название и описание самой серии. Ответ приходит по сериалу, и
                # у него название сериала: на видео владельца в списке серий
                # «Тёмной материи» подпись перескакивала с «Контейнер» на
                # «Тёмная материя» и обратно. Своё название строки возвращается,
                # когда ответ принёс название сериала.
                row_title = str((local or {}).get('title') or '') if row_is_episode else ''
                show_title = str((local or {}).get('tvshowtitle') or '')

                def keep_prepared(meta):
                    if not prepared_row_background or not isinstance(meta, dict):
                        return meta
                    if meta.get('_prepared_background'):
                        return meta
                    meta = dict(meta)
                    meta['_prepared_background'] = prepared_row_background
                    return meta

                # Картинки самой строки. Строка из зеркала уже несёт кадр,
                # логотип и постер - их нашёл сборщик, когда опознавал её у
                # поставщиков. Онлайн-ответ на живом пути может ничего не найти
                # (одно и то же название бывает не узнать по-русски), и тогда
                # он публиковался пустым: картинка снималась, а служба ставила
                # метку «опознание отклонено», по которой разметка прячет
                # основной слой фона. На экране это «фолбек вместо
                # обогащённого, а при уходе фокуса кадр вспыхивает» - владелец
                # описал так «Шёпот за окном» 2026-08-29. Ответ дополняется
                # тем, что у строки уже есть: добавлять он может, отнимать нет.
                row_art = {}
                if (local or {}).get('_background_has_enriched_art'):
                    local_row_art = (local or {}).get('art') or {}
                    for name in ('fanart', 'landscape', 'clearlogo', 'poster'):
                        if local_row_art.get(name):
                            row_art[name] = local_row_art[name]

                def keep_row_release(meta):
                    """Качество релиза - свойство самой строки.

                    Провайдеры метаданных о нём не знают, поэтому после
                    обогащения оно бы пропадало: 09.09.2026 замер на .30 -
                    строка «Тед Лассо [WEB-DLRip 1080]», а в свойствах пусто,
                    потому что публиковал этот путь, а не тот, который я
                    поправил первым. Одно правило на все пути публикации.
                    """
                    quality = str((local or {}).get('release_quality') or '')
                    resolution = str((local or {}).get('release_resolution') or '')
                    details = str((local or {}).get('release_details') or '')
                    if not isinstance(meta, dict) or not (quality or resolution or details):
                        return meta
                    meta = dict(meta)
                    meta['release_quality'] = quality
                    meta['release_resolution'] = resolution
                    meta['release_details'] = details
                    return meta

                def keep_row_art(meta):
                    if not row_art or not isinstance(meta, dict):
                        return meta
                    art = dict(meta.get('art') or {})
                    for name, value in row_art.items():
                        # пустое значение опознания - тоже «нет»: setdefault оставлял clearlogo='' и
                        # логотип строки пропадал после опознания без логотипа (22.11.2026)
                        if not art.get(name):
                            art[name] = value
                    meta = dict(meta)
                    meta['art'] = art
                    meta['_background_has_enriched_art'] = True
                    if 'clearlogo' in row_art:
                        meta.setdefault('_clearlogo_safe', True)
                    return meta

                # Кадр эпизода важнее картинки сериала. Для эпизода служба
                # сперва публикует его собственный кадр (локальная модель из
                # плеера), а потом приходит онлайн-ответ - и он про СЕРИАЛ,
                # поэтому его fanart перебивал кадр, и фон на экране прыгал с
                # эпизодного на сериальный. Владелец: «при включении эпизода фон
                # меняется с эпизодного на сериальный, можно убрать эти ненужные
                # скачки». Здесь именно перебивание (update), а не дополнение:
                # ответ про сериал не должен подменять кадр серии.
                #
                # 05.09.2026 то же правило понадобилось и СПИСКУ серий. Замер на
                # .20, «Осколки», «Эпизод 5» в контейнере 531: у строки её
                # собственный кадр лежит и в thumb, и в landscape, и в fanart
                # (t/p/w1920/e7ASKOJACLkoG6FqKD1OKKBdEWB.jpg), а опубликован был
                # задник СЕРИАЛА (t/p/w1920/AhzF2bkYYybcCT4PnqpoagRGBWJ.jpg):
                # ответ приходит про сериал и перебивал кадр серии тем же
                # способом, каким перебивал его у плеера. Владелец назвал это
                # «неисправленный фолбек» в списке эпизодов.
                #
                # Порядок для списка - тот же, что в _publish: сперва thumb (у
                # серии там кадр - соглашение самого Kodi), потом лендскейп,
                # потом фанарт. Постер фоном не идёт никогда: его отсекает
                # _still_not_poster по адресу, а на случай постера с безымянного
                # адреса - сравнение с art['poster'] той же строки. Без этих
                # двух проверок сюда попал бы generic-thumb провайдера, то есть
                # постер сериала в портретной ориентации, - ровно то, о чём
                # предупреждает длинный разбор в _publish.
                episode_art = {}
                listitem_answer = prefix.endswith('ListItem')
                if prefix.endswith('Player') and str(
                        (local or {}).get('dbtype') or '') == 'episode':
                    local_art = (local or {}).get('art') or {}
                    # Кадр серии лежит не обязательно в fanart. Замер на .30
                    # 05.09.2026: у эпизода fanart пуст, а кадр - в thumb/still,
                    # поэтому первая версия правки не срабатывала и фон всё
                    # равно скакал на сериальный. Берём первое, что есть.
                    still = (local_art.get('fanart') or local_art.get('landscape')
                             or local_art.get('still') or local_art.get('thumb'))
                    if still:
                        episode_art['fanart'] = still
                        episode_art['landscape'] = still
                    for name in ('thumb', 'still'):
                        value = local_art.get(name)
                        if value:
                            episode_art[name] = value
                elif listitem_answer and row_is_episode:
                    local_art = (local or {}).get('art') or {}
                    row_poster = str(local_art.get('poster') or '')

                    def _row_still(name):
                        value = _still_not_poster(local_art.get(name))
                        if value and row_poster and value == row_poster:
                            return ''
                        return value

                    still = (_row_still('thumb') or _row_still('landscape')
                             or _row_still('fanart'))
                    if still:
                        episode_art['fanart'] = still
                        episode_art['landscape'] = still
                        episode_art['thumb'] = still

                def keep_episode_art(meta):
                    if not episode_art or not isinstance(meta, dict):
                        return meta
                    art = dict(meta.get('art') or {})
                    art.update(episode_art)
                    meta = dict(meta)
                    meta['art'] = art
                    meta['_background_has_enriched_art'] = True
                    return meta

                def keep_row_still(meta):
                    if not isinstance(meta, dict):
                        return meta
                    changed = False
                    if row_still:
                        art = dict(meta.get('art') or {})
                        if not art.get('thumb'):
                            art['thumb'] = row_still
                            meta = dict(meta)
                            meta['art'] = art
                            changed = True
                    if row_title:
                        answer_title = str(meta.get('title') or '')
                        if not answer_title or (show_title and answer_title == show_title):
                            if not changed:
                                meta = dict(meta)
                                changed = True
                            meta['title'] = row_title
                    # Своё русское название важнее оригинального из ответа - то
                    # же правило, что и у сборщика полос.
                    answer_title = str(meta.get('title') or '')
                    better = prefer_local_title(answer_title, str((local or {}).get('title') or ''))
                    if better and better != answer_title:
                        if not changed:
                            meta = dict(meta)
                        meta['title'] = better
                    # То же самое с описанием. Снято на .20 на серии «Ложь -
                    # это правда»: у строки лежало русское описание, а
                    # публиковалось английское описание сериала из ответа.
                    # Пустой ответ описание строки тоже не стирает - у серий
                    # без своего сюжета на экране оставалась пустота, хотя
                    # сюжет сериала провайдер даёт.
                    answer_plot = str(meta.get('plot') or '')
                    row_plot = str((local or {}).get('plot') or '')
                    if row_is_episode:
                        # У серии своё описание важнее описания сериала, но
                        # русское важнее обоих. Снято на .20 на серии «2831»
                        # сериала «Спецназ: Львица»: у строки лежало описание
                        # самой серии, а публиковалось описание сериала - и то,
                        # и другое по-английски. Русских описаний серий у этого
                        # сериала нет ни у провайдера, ни у TMDb (названия серий
                        # русские, описания пустые), русское описание сериала
                        # есть - и оно побеждает английское описание серии.
                        better_plot = _prefer_russian(row_plot, answer_plot)
                    else:
                        better_plot = prefer_local_title(answer_plot, row_plot)
                    if better_plot and better_plot != answer_plot:
                        if not changed:
                            meta = dict(meta)
                            changed = True
                        meta['plot'] = better_plot
                    return meta

                def publish_base(base_meta):
                    if cancelled():
                        return
                    win = home_window()
                    if get_prop('%s.Key' % prefix, win) != key:
                        return
                    if prefix.endswith('ListItem') and not _key_still_focused(key):
                        return
                    if prefix.endswith('ListItem'):
                        _identity_cache_set(key, not bool((base_meta or {}).get('_identity_rejected') or (base_meta or {}).get('_adult_blocked')))
                        if not (base_meta or {}).get('_background_has_enriched_art'):
                            base_meta = copy.deepcopy(base_meta or {})
                            # Ждать нечего, когда картинка уже лежит файлом.
                            if not prepared_row_background:
                                base_meta['_background_resolving'] = True
                    _publish(win, prefix, keep_row_release(keep_episode_art(keep_row_art(
                        keep_row_still(keep_prepared(base_meta))))), key)
                    set_prop('SublimeHelper.LastError', '', win)
                    set_prop('SublimeHelper.IsUpdatingDetails', '', win)

                remote = fetch_online_metadata(
                    params, local, cancel_check=cancelled, base_callback=publish_base)
                if cancelled():
                    continue
                self._cache_result(key, remote, local)
                if isinstance(remote, dict) and remote.get('_logo_pending'):
                    # The whole answer is ready except a logo that was not in
                    # the cache. It used to be left for the moment the cursor
                    # stopped - 0.7 s, and then fetched on the focused path. The
                    # owner's rule is that nothing waits, so the fetch starts
                    # now, on the thread that has no screen to hold up: the logo
                    # appears as soon as the network answers, and the next
                    # publish reads it from the cache for nothing.
                    self.submit_prewarm(key, local, params)
                win = home_window()
                current_key = get_prop('%s.Key' % prefix, win)
                if current_key == key and (not prefix.endswith('ListItem') or _key_still_focused(key)):
                    if prefix.endswith('ListItem'):
                        _identity_cache_set(key, not bool((remote or {}).get('_identity_rejected') or (remote or {}).get('_adult_blocked')))
                    _publish(win, prefix, keep_row_release(keep_episode_art(keep_row_art(
                        keep_row_still(keep_prepared(remote))))), key)
                    set_prop('SublimeHelper.LastError', '', win)
            except Exception as exc:
                log('metadata worker: %s' % exc, xbmc.LOGWARNING)
                set_prop('SublimeHelper.LastError', str(exc), home_window())
            finally:
                with self.lock:
                    self.pending.discard(job_key)
                    idle = not self.pending
                if idle:
                    win = home_window()
                    set_prop('SublimeHelper.IsUpdating', '', win)
                    set_prop('SublimeHelper.IsUpdatingDetails', '', win)
                    set_prop('SublimeHelper.IsUpdatingRatings', '', win)
                self.queue.task_done()


_WORKER = None


def worker():
    global _WORKER
    if _WORKER is None:
        _WORKER = MetadataWorker()
    return _WORKER


def clear_runtime_metadata_cache():
    if _WORKER is not None:
        _WORKER.clear_results()


def _key_still_focused(key):
    """Ответ рабочего потока относится к карточке, которая сейчас в фокусе: путь в ключе
    публикации ('контейнер|отпечаток|тип|id|tmdb|путь|...') совпадает с путём фокуса этого
    контейнера, прочитанным заново. Иначе поздний ответ ставил фон ушедшей карточки к новой
    (.20, 20.11.2026: фон «Я не робот» на двух следующих). Сверять по ключу публикации нельзя:
    в окне сериала строка «меняется», пока заполняется список, и законный ответ для этой же
    серии выбрасывался - фон серии то был, то нет."""
    parts = str(key or '').split('|')
    if len(parts) < 6 or not parts[0].isdigit() or not parts[5]:
        return True
    prefix = 'Container(%s).' % parts[0] if parts[0] != '0' else ''
    addresses = [prefix + 'ListItem.FileNameAndPath', prefix + 'ListItem.FolderPath']
    try:
        got = read_labels(addresses, fresh=True)
    except Exception:
        return True
    current = [str(got.get(a) or '').split('|')[0] for a in addresses]
    # Контейнера в фокусе нет вовсе (другое окно: ответ для карточки хаба пришёл, когда
    # открыт сериал) - карточки на экране нет, ответ чужой (.20 20.11.2026: логотип и фон
    # «Теда Лассо» в окне «Закона и порядка»).
    return parts[5] in current


def _current_item_fingerprint(container_id=0):
    # Same reason as the model above: one request for the whole set.
    prefetch_labels(('ChannelName', 'Country', 'DBID', 'DBType', 'Episode', 'FileNameAndPath', 'FolderPath', 'IMDBNumber', 'Label', 'OriginalTitle', 'Path', 'Premiered', 'Property(Countries)', 'Property(Country)', 'Property(FilmixSourceCountries)', 'Property(FilmixSourceCountry)', 'Property(FilmixSourceYear)', 'Property(IMDb_ID)', 'Property(Premiered)', 'Property(SourceCountries)', 'Property(SourceCountry)', 'Property(SourceYear)', 'Property(TMDB_ID)', 'Property(TMDb_ID)', 'Property(Year)', 'Property(countries)', 'Property(country)', 'Property(imdb_id)', 'Property(kinopoisk_id)', 'Property(premiered)', 'Property(tmdb_id)', 'Property(year)', 'Season', 'StartTime', 'TVShowTitle', 'Title', 'UniqueID(imdb)', 'UniqueID(kinopoisk)', 'UniqueID(tmdb)', 'Year'), container_id)
    values = (
        container_id,
        current_label('DBType', container_id), current_label('DBID', container_id),
        current_label('UniqueID(tmdb)', container_id), current_label('Property(tmdb_id)', container_id),
        current_label('Property(TMDB_ID)', container_id), current_label('Property(TMDb_ID)', container_id),
        current_label('UniqueID(imdb)', container_id), current_label('IMDBNumber', container_id),
        current_label('Property(imdb_id)', container_id), current_label('Property(IMDb_ID)', container_id),
        current_label('UniqueID(kinopoisk)', container_id), current_label('Property(kinopoisk_id)', container_id),
        current_label('FileNameAndPath', container_id) or current_label('FolderPath', container_id) or current_label('Path', container_id),
        current_label('Title', container_id) or current_label('Label', container_id),
        current_label('OriginalTitle', container_id), current_label('TVShowTitle', container_id),
        current_label('Property(FilmixSourceYear)', container_id), current_label('Property(SourceYear)', container_id),
        current_label('Year', container_id), current_label('Property(Year)', container_id), current_label('Property(year)', container_id),
        current_label('Premiered', container_id), current_label('Property(Premiered)', container_id), current_label('Property(premiered)', container_id),
        current_label('Property(FilmixSourceCountry)', container_id), current_label('Property(FilmixSourceCountries)', container_id),
        current_label('Property(SourceCountry)', container_id), current_label('Property(SourceCountries)', container_id),
        current_label('Country', container_id), current_label('Property(Country)', container_id), current_label('Property(country)', container_id),
        current_label('Property(Countries)', container_id), current_label('Property(countries)', container_id),
        current_label('Season', container_id), current_label('Episode', container_id),
        current_label('ChannelName', container_id), current_label('StartTime', container_id),
        config.provider_signature(),
    )
    return hashlib.sha1(repr(values).encode('utf-8', 'ignore')).hexdigest()[:20]


def prewarm_widget_neighbors(container_id, radius=3):
    """Warm the metadata cache for rows around the focused one, so scrolling
    a Home widget does not wait on a fresh TMDb/KinoPoisk/IMDb round-trip for
    every single item the user lands on.

    Runs entirely on MetadataWorker's dedicated prewarm queue/thread
    (submit_prewarm) - never the same queue/thread/prefix-tracking the
    focused item's own resolution uses, so it can only ever populate
    worker().get_cached() ahead of time and can never delay or invalidate
    the item actually on screen (see 7c1c4d0 for why the first attempt at
    this, sharing that path, made things worse instead of better).

    Для виджета, собранного заранее, это лишняя работа: у соседних строк
    ответы уже лежат в самих строках (hub/builder.py), а чтобы это выяснить,
    здесь пришлось бы прочитать их метки с интерфейса - то есть заплатить
    ровно ту цену, от которой зеркало и избавляет. Достаточно спросить
    сфокусированную строку: если она готова, готов и весь виджет.
    """
    try:
        address = ('Container(%s).ListItem.Property(Sublime.Background)' % container_id
                   if str(container_id).isdigit()
                   else 'ListItem.Property(Sublime.Background)')
        if xbmc.getInfoLabel(address):
            return 0
    except Exception:
        pass
    if not container_id or radius <= 0:
        return
    try:
        num_items = safe_int(read_label('Container(%d).NumItems' % safe_int(container_id)))
    except Exception:
        return
    if num_items <= 1:
        return
    signature = config.provider_signature()
    # Same budget as the span sweep, and for the same reason: this runs on the
    # service loop on every focus change, and each row it looks at costs ~80
    # info-label reads. Six neighbours were enough to hold the turn - and the
    # background with it - for longer than the eye tolerates.
    deadline = time.monotonic() + WARM_SLICE_BUDGET
    for offset in range(1, radius + 1):
        for rel_offset in (offset, -offset):
            # Before EVERY row, not every pair: one row costs ~80 info-label
            # reads, and measured on .20 that is up to a second on its own. A
            # check per pair let a single pair hold the turn for 2 s and the
            # budget did nothing at all.
            if time.monotonic() >= deadline:
                return
            _prewarm_one_row(container_id, rel_offset, signature)


def prewarm_widget_span(container_id, start, count):
    """Warm rows beyond the focus neighbourhood, a slice per call.

    Why this exists: measured on <коробка>, the recommendation widget had
    82% of its rows already in the skin's metadata cache and felt instant,
    while a freshly built "new releases" lane had 30% and every uncached row
    cost a live TMDb/KinoPoisk/IMDb resolution on focus. The difference was
    never the add-on serving the rows - it was whether anyone had resolved them
    before. So instead of waiting for the user to walk the list, the whole
    container gets warmed while the remote is idle, a few rows at a time.

    Returns the offset to continue from, or 0 once the container is covered.

    Для виджета, который собрал сборщик, обход не нужен вовсе: причина, ради
    которой этот механизм появился - «никто не опознал строки заранее» - как
    раз и снята зеркалом. Ноль здесь значит «этот контейнер закрыт», то есть
    служба к нему больше не возвращается.
    """
    if not container_id or count <= 0:
        return 0
    try:
        if xbmc.getInfoLabel('Container(%d).ListItem.Property(Sublime.Background)'
                             % safe_int(container_id)):
            return 0
    except Exception:
        pass
    # Категория виджета известна по его пути - до чтения строк. Для ТВ, видео и
    # «другого» прогрев не нужен вовсе: у канала PVR и ролика YouTube у
    # поставщиков нечего искать, а чтение строки стоит ~80 параметрических
    # метк. Замер .30 07.09.2026: именно эти чтения давали такт службы на
    # 1050-1209 мс при пустом результате («accepted=0 skipped=no_evidence»).
    try:
        from ..hub import widget_kinds
        # У виджетов хаба Container(N).FolderPath ПУСТ - проверено на .30
        # 07.09.2026, - поэтому природу виджета берём по пути его строки. Это
        # одно чтение метки против двух чтений по ~80 метк, которые прогрев
        # делал, чтобы прийти к тому же выводу.
        probe = safe_int(container_id)
        folder = (xbmc.getInfoLabel('Container(%d).FolderPath' % probe)
                  or xbmc.getInfoLabel('Container(%d).ListItem.FolderPath' % probe)
                  or xbmc.getInfoLabel('Container(%d).ListItem.FileNameAndPath' % probe))
        if folder and not widget_kinds.warmable(folder):
            log('widget warm-up: виджет %s категории «%s» прогрев не требует'
                % (probe, widget_kinds.kind_of(folder)))
            return 0
    except Exception:
        pass
    try:
        num_items = safe_int(read_label('Container(%d).NumItems' % safe_int(container_id)))
    except Exception:
        return 0
    # Reading one row's identity costs ~80 parameterised info labels, and that
    # is the exact call Kodi 22-BETA1 segfaults inside (four crashlogs, two of
    # them while a sweep was running: ...20260820203221, ...20260821072120).
    # Warming the whole 50-row lane meant thousands of those reads for rows the
    # user may never reach; the first screens are where the win actually is.
    num_items = min(num_items, WARM_SPAN_LIMIT)
    if num_items <= 1 or start >= num_items:
        return 0
    signature = config.provider_signature()
    last = min(num_items, start + count)
    accepted = 0
    tally = {}
    # A time budget, because a row is not a fixed price. Reading one row's
    # identity is ~80 parameterised info labels, and a label read costs whatever
    # Kodi's GUI thread is busy with at that moment. Traced on .20 during a
    # sweep of Home: single turns of this service loop ran 3.0-8.0 s, of which
    # the metadata stage accounted for 0.5-1.5 s and the rest was this warm-up -
    # and nothing else in the turn, the background publisher included, can run
    # while it does. That is exactly the pause the owner reported. Warming is
    # worth doing, but never at the cost of the picture in front of him: the
    # slice stops at the deadline and resumes from the same offset next tick.
    deadline = time.monotonic() + WARM_SLICE_BUDGET
    for offset in range(start, last):
        for rel_offset in (offset, -offset):
            now = time.monotonic()
            if now >= deadline:
                _log_warm_slice(container_id, start, offset, accepted, 'budget', tally)
                return offset
            # Бюджет проверялся ТОЛЬКО перед строкой, а сама строка стоит
            # дороже бюджета: замер .30 07.09.2026 дал такт 1050-1209 мс при
            # бюджете 0.30 с. Поэтому строку не начинаем, если на неё заведомо
            # не хватает времени: цена строки известна по прошлым проходам.
            if _WARM_ROW_COST[0] and now + _WARM_ROW_COST[0] * 0.8 > deadline:
                _log_warm_slice(container_id, start, offset, accepted, 'budget', tally)
                return offset
            started = time.monotonic()
            resolved = _prewarm_one_row(container_id, rel_offset, signature, tally)
            spent = time.monotonic() - started
            # Скользящее среднее: цену строки узнаём у самой коробки, а не
            # угадываем. Быстрые попадания в память тоже учитываются, поэтому
            # среднее держится около настоящей цены чтения.
            _WARM_ROW_COST[0] = (spent if not _WARM_ROW_COST[0]
                                 else _WARM_ROW_COST[0] * 0.7 + spent * 0.3)
            if resolved:
                accepted += 1
                continue
            if worker().prewarm_backlog() >= PREWARM_QUEUE_HEADROOM:
                # The worker is already as far behind as it is worth letting it
                # get. Resume from this offset next tick instead of firing rows
                # into a full queue, where they would simply be dropped.
                _log_warm_slice(container_id, start, offset, accepted, 'queue_full', tally)
                return offset
    _log_warm_slice(container_id, start, last, accepted,
                    'done' if last >= num_items else 'more', tally)
    return last if last < num_items else 0


# Rows whose resolution has already been attempted, so a warm-up pass does not
# keep resubmitting the ones that cannot resolve. Measured on <коробка>: a
# row whose provider lookup ends in a mismatch is never cached, so the idle
# warm-up handed it back every second and the log filled with the same line
# ("provider=imdb status=retry_mismatch id=tt41839304 ... expected=Лев",
# once every 1-3 s) while the box paid for the request each time.
# Leave room in the queue so a real focus change is never behind a wall of
# warm-up jobs; the queue itself holds eight.
PREWARM_QUEUE_HEADROOM = 5
# Longest this loop may spend warming before it hands the turn back. One slice
# used to run for seconds (see prewarm_widget_span), and everything the screen
# waits for sits behind it.
# Строки, которые опознавать нечем (нет ни идентификаторов, ни признаков
# медиа): ролик YouTube, канал PVR, служебная папка. Проход прогрева больше не
# читает их повторно - именно эти чтения давали такт службы на 1050-1209 мс
# (замер .30 07.09.2026). Срок памяти короткий: содержимое строки может
# смениться вместе с содержимым виджета.
# Цена одного чтения строки, замеренная на этой самой коробке (скользящее
# среднее). Список из одного элемента - чтобы менять её изнутри функции.
_WARM_ROW_COST = [0.0]
_WARM_HOPELESS = {}
_WARM_HOPELESS_TTL = 900.0

WARM_SLICE_BUDGET = 0.30
# How far past the focused row warming goes at all.
WARM_SPAN_LIMIT = 18
# How long a warm-up job waits for the focused row to be done before going
# ahead anyway - a cap, so a stuck focused job cannot stall warming forever.
FOCUS_YIELD_LIMIT = 8.0
# The warm-up also waits out the user. Measured on <коробка> while the owner
# reported ~5 s for a row's art: the row's metadata was already cached (no
# item= line for it at all), but the warm-up was resolving four OTHER rows in
# those same five seconds with kodi.bin at 91% CPU - and Kodi needs those cores
# to fetch and scale the textures the eye is waiting for. Resolving ahead is
# only worth anything while nobody is pressing anything.
PREWARM_USER_IDLE = 3.0
PREWARM_USER_WAIT_LIMIT = 60.0
# A breath between jobs, so the thread cannot hold a core continuously.
PREWARM_JOB_GAP = 0.4
_PREWARM_ATTEMPTED = OrderedDict()
_PREWARM_ATTEMPT_TTL = 900
_PREWARM_ATTEMPT_MAX = 512


# Whether the user is busy, taken on the service's own thread and read from
# here by the worker threads.
#
# This is the crash the owner has been feeling. Kodi 22-BETA1 segfaults inside
# CGUIInfoManager::GetMultiInfoLabel when GUI state is read from a thread that
# is not the script's own - four crash logs on .20 tonight, and the crashing
# thread in the last one is the metadata worker (T:191244, the same thread that
# had just logged "[sublime metadata] item=Вечерние новости"). It reached
# xbmc.getGlobalIdleTime/getCondVisibility through this very function, on every
# prewarm job and as the cancel check of every provider call.
#
# So the reads happen once per service tick, on the right thread, and everyone
# else looks at the answer. A snapshot older than its TTL counts as busy: that
# is the safe direction, because it only ever postpones warming.
_UI_SNAPSHOT = {'busy': True, 'at': 0.0}
_UI_SNAPSHOT_TTL = 6.0


def refresh_ui_snapshot():
    """Take the snapshot. MUST be called from the script's own thread."""
    busy = True
    try:
        busy = (xbmc.getGlobalIdleTime() < PREWARM_USER_IDLE
                or xbmc.getCondVisibility('System.HasActiveModalDialog | '
                                          'System.HasVisibleModalDialog'))
    except Exception:
        busy = False
    _UI_SNAPSHOT['busy'] = bool(busy)
    _UI_SNAPSHOT['at'] = time.time()
    return _UI_SNAPSHOT['busy']




# Остановка Kodi. Ни одного abortRequested/waitForAbort/Monitor в этом файле не
# было, и это стоило владельцу тёмной коробки 05.08.2026.
#
# Как это выглядит в журнале - точная причина, найденная 03.09.2026 на
# <коробка>:
#
#     08:31:51.179  CPythonInvoker(7, vcl_service.py): waiting on thread ...
#     08:31:56.178  script didn't stop in 5 seconds - let's kill it
#
# Ровно пять секунд ожидания ПОТОКА. То есть Kodi ждёт потоки скрипта
# независимо от флага daemon - рассуждение «daemon выходу интерпретатора не
# мешает, значит остановку не задерживает» неверно, и я на нём уже ошибся.
# А _run и _run_prewarm - это `while True` с блокирующим queue.get(): они не
# выходят никогда, поэтому пять секунд истекали при КАЖДОЙ остановке.
#
# Монитор один на модуль: xbmc.Monitor() в горячем цикле - лишний объект на
# каждую строку.
_MONITOR = None


def _stopping():
    """Kodi просят остановиться - бросаем начатое немедленно."""
    global _MONITOR
    try:
        if _MONITOR is None:
            _MONITOR = xbmc.Monitor()
        return _MONITOR.abortRequested()
    except Exception:
        return False


def _cancel_warmup():
    """Отмена фоновой работы: пульт тронули ИЛИ Kodi останавливают."""
    return _user_busy() or _stopping()


def _user_busy():
    """True while the user is doing something warming must not disturb.

    That is either a recent keypress, or an open dialog. A dialog matters for
    its own reason: the context menu runs a script from its <onload>, and on a
    box whose cores are busy resolving rows that script started thirteen
    seconds late - by which time hiding an entry closed the menu instead of
    tidying it. Nothing needs warming while a menu is on screen.
    """
    try:
        if time.time() - (_UI_SNAPSHOT.get('at') or 0.0) > _UI_SNAPSHOT_TTL:
            return True
        return bool(_UI_SNAPSHOT.get('busy'))
    except Exception:
        return False


def _prewarm_attempt_allowed(key, reserve=True):
    """Whether this row may be handed to the worker again.

    `reserve=False` only asks; the caller marks the attempt afterwards, once
    the queue has actually accepted the job. Marking too early was a real bug:
    a job dropped by a full queue counted as attempted and the row then stayed
    cold for the whole memo window.
    """
    now = time.time()
    stamp = _PREWARM_ATTEMPTED.get(key)
    if stamp is not None and now - stamp < _PREWARM_ATTEMPT_TTL:
        return False
    if not reserve:
        return True
    _PREWARM_ATTEMPTED[key] = now
    _PREWARM_ATTEMPTED.move_to_end(key)
    while len(_PREWARM_ATTEMPTED) > _PREWARM_ATTEMPT_MAX:
        _PREWARM_ATTEMPTED.popitem(last=False)
    return True


# Kodi downloads and converts a remote image the first time something on screen
# asks for it, and that download - not the metadata lookup - is what the eye
# actually waits for: an owner watching a warmed scroll still saw a row arrive
# without its poster. Reading the image through Kodi's own image:// handler
# makes the texture pipeline fetch and store it, so by the time the row is
# focused the picture is local. Cheap to skip: an already-cached texture
# resolves from disk.
_ART_KEYS = ('poster', 'fanart', 'clearlogo', 'thumb', 'landscape')
_ART_PRECACHED = OrderedDict()
_WASH_PREWARMED = OrderedDict()
_ART_PRECACHE_MAX = 2048


def _precache_art(meta, busy_check=None):
    """Pull this item's key images into Kodi's texture cache.

    `busy_check` exists because this is also called from the hub's warm thread,
    and the default check reads GUI state - which Kodi 22-BETA1 segfaults on when
    it is not the script's own thread (crash log on .20, 17:41). That caller
    passes its own snapshot-based check instead.
    """
    if not isinstance(meta, dict) or xbmcvfs is None:
        return 0
    busy_check = busy_check or _user_busy
    art = meta.get('art') or {}
    done = 0
    for name in _ART_KEYS:
        if busy_check():
            # Between pictures is a fine place to stop: whatever is already
            # cached stays cached, and the rest waits for a quiet moment.
            break
        url = str(art.get(name) or '').strip()
        if not url or not url.startswith(('http://', 'https://')):
            continue
        if url in _ART_PRECACHED:
            continue
        _ART_PRECACHED[url] = 1
        while len(_ART_PRECACHED) > _ART_PRECACHE_MAX:
            _ART_PRECACHED.popitem(last=False)
        handle = None
        try:
            handle = xbmcvfs.File('image://%s/' % quote(url, safe=''))
            # One read is enough to make Kodi fetch and convert the texture;
            # the bytes themselves are of no interest here.
            handle.readBytes(1)
            done += 1
        except Exception:
            pass
        finally:
            try:
                if handle is not None:
                    handle.close()
            except Exception:
                pass
    # The wash colour of the enriched background belongs to the same tick as
    # the background itself: _update_background_wash() applies it immediately
    # when it is cached and otherwise leaves it for a later poll, which the
    # owner saw as the colour catching up after the picture. Only the image the
    # wash is actually taken from is worth the extraction.
    wash_source = str(art.get('fanart') or art.get('landscape')
                      or art.get('poster') or '').strip()
    if wash_source.startswith(('http://', 'https://')) and wash_source not in _WASH_PREWARMED:
        _WASH_PREWARMED[wash_source] = 1
        while len(_WASH_PREWARMED) > _ART_PRECACHE_MAX:
            _WASH_PREWARMED.popitem(last=False)
        try:
            from .image_wash import prepare_wash_color_now
            prepare_wash_color_now(wash_source)
        except Exception as exc:
            log('wash colour prewarm: %s' % exc, xbmc.LOGDEBUG)
    return done


# The blurred 4K fallback background is built from the row's OWN poster, and
# only for the focused row - which is why art could look slow even when the
# metadata was already published: the picture behind it was still being made.
_BG_PREWARMED = OrderedDict()
_BG_PREWARM_MAX = 512


def _prewarm_fallback_background(local):
    """Build this row's blurred fallback background before it is focused."""
    art = (local or {}).get('art') or {}
    source = str(art.get('poster') or art.get('thumb') or '').strip()
    if not source or not source.startswith(('http://', 'https://')):
        return False
    if source in _BG_PREWARMED:
        return False
    done = False
    try:
        from .poster_background import prepare_background_now
        done = bool(prepare_background_now('poster', source))
    except Exception as exc:
        log('fallback background prewarm: %s' % exc, xbmc.LOGDEBUG)
    try:
        # The wash colour is taken from the same poster and is the other thing
        # the skin computes at focus time.
        from .image_wash import prepare_wash_color_now
        prepare_wash_color_now(source)
    except Exception as exc:
        log('wash colour prewarm: %s' % exc, xbmc.LOGDEBUG)
    # Recorded only after the work was really attempted, so a source skipped
    # because the screen was busy is tried again later.
    _BG_PREWARMED[source] = 1
    while len(_BG_PREWARMED) > _BG_PREWARM_MAX:
        _BG_PREWARMED.popitem(last=False)
    return done


def _log_warm_slice(container_id, start, stop, accepted, outcome, tally=None):
    """One line per warm-up slice: without it, a warm-up that quietly does
    nothing is indistinguishable from one that works (which is exactly the
    hole this line was added to close)."""
    # Only worth a line when work was actually queued, or when the sweep is
    # finished. A line per idle second saying "nothing to do" is noise, but a
    # warm-up that silently does nothing was exactly the bug this line caught.
    if not accepted and outcome != 'done':
        return
    detail = ','.join('%s:%s' % kv for kv in sorted((tally or {}).items())) or '-'
    log('widget warm-up: row=%s offsets=%s..%s accepted=%s %s skipped=%s' % (
        container_id, start, stop, accepted, outcome, detail), xbmc.LOGINFO)


def _prewarm_one_row(container_id, rel_offset, signature, tally=None):
    """Submit one row for background resolution, if it needs it."""
    def note(reason):
        if tally is not None:
            tally[reason] = tally.get(reason, 0) + 1
        return False
    try:
        with labels_batch_scope(True):
            fingerprint = _at_offset(container_id, rel_offset, _current_item_fingerprint)
            if not fingerprint:
                return note('no_fingerprint')
            # Строку, которую опознать нечем, второй раз не читаем.
            #
            # Замер на .30 07.09.2026 при обходе разделов: такт службы упирался
            # в прогрев виджета на 1050-1209 мс, а в журнале стояло
            # «widget warm-up: row=501 offsets=17..18 accepted=0 skipped=
            # no_evidence:2» - то есть время уходило на ЧТЕНИЕ двух строк (по
            # ~80 параметрических метк каждая), после которого выяснялось, что
            # опознавать нечего. И так на каждом проходе по кругу.
            hopeless_at = _WARM_HOPELESS.get(fingerprint)
            if hopeless_at and time.time() - hopeless_at < _WARM_HOPELESS_TTL:
                return note('hopeless_known')
            local = _at_offset(container_id, rel_offset, local_model_from_current)
    except Exception:
        return note('read_error')

    def hopeless(reason):
        if len(_WARM_HOPELESS) > 512:
            _WARM_HOPELESS.clear()
        _WARM_HOPELESS[fingerprint] = time.time()
        return note(reason)
    if not local:
        return note('empty_model')
    if local.get('_is_pvr'):
        return hopeless('pvr_row')
    if _is_generic_youtube_item(local):
        # sync_metadata_properties skips exactly this check for the focused item
        # (its "skip_youtube_nonmedia" branch) because a generic YouTube
        # video/news row can never match a movie database entry. Without it
        # here, warming burned a full sequential tmdb/imdb/kinopoisk round trip
        # (measured cold: ~1.9-2.3 s) per YouTube row that was never going to
        # resolve - wasted work that can only compete with a real film's own
        # resolution for the same provider clients.
        return hopeless('youtube_row')
    if not _has_media_evidence(local):
        return hopeless('no_evidence')
    key = '%s|%s|%s|%s|%s|%s|%s|%s' % (
        container_id, fingerprint, local.get('dbtype'), local.get('dbid'),
        local.get('tmdb_id'), local.get('file'), local.get('title'), signature)
    try:
        if worker().get_cached(key, local) is not None:
            return note('already_cached')
    except Exception:
        pass
    if not _prewarm_attempt_allowed(key, reserve=False):
        return note('attempted_recently')
    if not worker().submit_prewarm(key, local):
        return note('refused')
    _prewarm_attempt_allowed(key, reserve=True)
    return True



def row_model_from_snapshot(row):
    """Та же модель, что _model_from_row строит на фокусе, но из строки снимка.

    Свойства Sublime.* строки - ровно то, что routes отдаёт в список
    (mirror.row_properties), поэтому и ключ кэша метаданных (_identity_cache_id)
    выходит тот же, что у строки под курсором. None - строка не собрана
    сборщиком (у неё нет Sublime.Background).
    """
    from ..hub import mirror
    props = mirror.row_properties(row or {})
    background = props.get('Sublime.Background') or ''
    if not background:
        return None
    return _row_model(lambda name: props.get('Sublime.%s' % name, ''), background,
                      props.get('Sublime.Prepared') or '', str((row or {}).get('file') or ''))


def prewarm_model(local):
    """Отдать модель строки фоновому потоку прогрева (submit_prewarm) заранее.

    Для заполнения кэшей установщиком (resources/lib/fill_caches.py): тот же
    поток, что прогревает соседей на главной, - уступает фокусу и пульту,
    дописывает итоговый пакет в metadata_cache под ключ фильма и кладёт его
    картинки в кэш текстур. Ответ: 'off' (метаданные выключены), 'skip' (строку
    не опознать по номерам/посту), 'cached' (пакет уже есть), 'queued',
    'full' (очередь полна - повторить позже).
    """
    if not config.online_enabled() or not _metadata_available():
        return 'off'
    if not local or local.get('_is_pvr') or _is_generic_youtube_item(local):
        return 'skip'
    identity = _identity_cache_id(local)
    if not identity:
        return 'skip'
    try:
        found = worker().get_cached(identity, local)
        if found is not None and _metadata_entry_complete(found):
            return 'cached'
    except Exception:
        pass
    # Свой ключ, а не ключ фильма: неполный ответ ляжет под ним и не станет
    # ответом за фильм (_cache_result кладёт под ключ фильма только полный).
    return 'queued' if worker().submit_prewarm('fill|' + identity, local) else 'full'

def _player_fingerprint():
    read_labels(_PLAYER_LABELS)
    values = (
        read_label('VideoPlayer.DBType'), read_label('VideoPlayer.DBID'),
        read_label('VideoPlayer.UniqueID(tmdb)'), read_label('VideoPlayer.IMDBNumber'),
        read_label('Player.FilenameAndPath'), read_label('VideoPlayer.Title') or read_label('Player.Title'),
        read_label('VideoPlayer.Season'), read_label('VideoPlayer.Episode'),
        config.provider_signature(),
    )
    return hashlib.sha1(repr(values).encode('utf-8', 'ignore')).hexdigest()[:20]


def _set_prop_changed(win, name, value):
    value = '' if value in (None, '') else str(value)
    if get_prop(name, win) == value:
        return
    set_prop(name, value, win)


# Свойства фона. При переходе между окнами их можно НЕ снимать: картинка,
# оставшаяся на экране лишний миг, не врёт - в отличие от названия и описания.
# Замер на .30 05.09.2026: нажатие на сериал открывает пустое окно «Видео» и
# держит его 3.3 с, пока провайдер строит список эпизодов, и всё это время фон
# был снят - владелец назвал это «странный экран загрузки».
_BACKGROUND_PROPS = (
    'SublimeHelper.ListItem.BlurImage',
    'SublimeHelper.ListItem.BlurImage.Original',
    'SublimeHelper.ListItem.Current.BlurImage',
    'SublimeHelper.ListItem.Current.BlurImage.Original',
    'VCL.Widget.Fanart',
)


def _clear_listitem_publication(win, key='', keep_background=False):
    marker = 'SublimeHelper.Published.ListItem'
    for name in filter(None, get_prop(marker, win).split('|')):
        if keep_background and name in _BACKGROUND_PROPS:
            continue
        win.clearProperty(name)
    set_prop(marker, '', win)
    for name in (
        'SublimeHelper.ListItem.CropImage', 'SublimeHelper.ListItem.BlurImage',
        'SublimeHelper.ListItem.BlurImage.Original', 'SublimeHelper.ListItem.Current.CropImage',
        'SublimeHelper.ListItem.Current.BlurImage', 'SublimeHelper.ListItem.Current.BlurImage.Original',
        'SublimeHelper.ListItem.Monitor.DBID', 'SublimeHelper.ListItem.Monitor.TMDb_ID',
        'SublimeHelper.ListItem.Monitor.TMDb_Type', 'SublimeHelper.ListItem.Monitor.Season',
        'SublimeHelper.ListItem.Monitor.Episode', 'VCL.Widget.TMDB_ID', 'VCL.Widget.TMDB_Type',
        'VCL.Widget.Kinopoisk_ID', 'VCL.Widget.IMDb_ID', 'VCL.Widget.Trailer', 'VCL.Widget.Fanart',
        'SublimeHelper.ListItem.Fingerprint', 'SublimeHelper.ListItem.ProviderRetryAt',
        'SublimeHelper.ListItem.ProviderRetryKey', 'SublimeHelper.ListItem.BackgroundResolving',
    ):
        if keep_background and name in _BACKGROUND_PROPS:
            continue
        win.clearProperty(name)
    for current_window in _visible_local_windows():
        for name in (
                'SublimeHelper.ListItem.CropImage',
                'SublimeHelper.ListItem.BlurImage',
                'SublimeHelper.ListItem.BlurImage.Original'):
            if keep_background and name in _BACKGROUND_PROPS:
                continue
            current_window.clearProperty(name)
    set_prop('SublimeHelper.ListItem.Key', key, win)
    # Примета строки уходит вместе с публикацией: следующая публикация не должна
    # считать себя продолжением снятой.
    win.clearProperty('SublimeHelper.ListItem.RowId')


def demote_publication(win, container_id=0, row_key=''):
    """The moment focus moves, stop showing the previous row's identity.

    Measured on .20 at 40 ms resolution: the row and its own plot change in
    0.02 s, while the enriched title arrives at 0.12-0.54 s, the clearlogo and
    the enriched background anywhere from 0.38 s to 6.8 s - and sometimes not at
    all. Everything in between was the previous film's name, logo and backdrop
    over the new film's description, which is exactly what the owner called
    unpleasant.

    So the identity of the row that just lost focus is dropped at once, and the
    row's OWN name and description - which Kodi already has - take its place.
    Nothing here reads the network or the disk: it is a handful of window
    properties and one batched label read. The enriched version replaces it a
    fraction of a second later through the normal path.
    """
    win = win or home_window()
    got = read_labels(_demote_addresses(container_id))
    label = ''
    plot = ''
    year = ''
    for name, target in (('Title', 'label'), ('Label', 'label'),
                         ('Plot', 'plot'), ('Year', 'year')):
        address = _demote_address(container_id, name)
        value = str(got.get(address) or '').strip()
        if not value:
            continue
        if target == 'label' and not label:
            label = value
        elif target == 'plot' and not plot:
            plot = value
        elif target == 'year' and not year:
            year = value
    # The BACKGROUND is not in this list, and that is the point.
    #
    # Recorded passively on .20 while the owner scrolled at his own pace: the
    # picture went to nothing and came back 0.2-0.6 s later - «обогащённый ->
    # ПУСТО -> обогащённый» on the same row, and «обогащённый -> ПУСТО ->
    # фолбек -> обогащённый» across a row change. The dark gap is what the eye
    # reads as flashing, and it was this clear: everything went down here and
    # the new picture arrived a moment afterwards.
    #
    # A background is never taken down now - it is only ever replaced, by the
    # placeholder or by this row's own enriched art, both of which write these
    # same properties. A row that genuinely has no picture is cleared by the
    # publisher instead, which knows that only after reading the row twice.
    #
    # The name, the plot and the logo still go at once: a title from the
    # previous film is a wrong statement about this one, while its blurred
    # backdrop for another fraction of a second is not.
    # Внутри одного сериала логотип и студия не меняются, поэтому и ронять их
    # не за что. 07.09.2026 владелец сообщил: «в эпизодах при перемещении
    # зачем-то вылезает название сериала». Так и было: логотип стирался на
    # каждой смене серии, слот названия оставался без картинки и показывал
    # текстовую подмену - а первая подмена в этом слоте (Includes_Info.xml,
    # Info_Title) как раз ListItem.TVShowTitle. Через доли секунды логотип
    # возвращался. Теперь при переходе на серию ТОГО ЖЕ сериала логотип и
    # студия остаются на месте, и мигать нечему.
    # Сравнивать надо ОДИНАКОВЫЕ имена. Замер на .30 07.09.2026 в списке серий
    # «Джека Ричера»: у строки ListItem.TVShowTitle = «Джек Ричер» (как отдаёт
    # Filmix), а опубликованное обогащением base_tvshowtitle = «Ричер» (как
    # называет сериал TMDb). Сравнение этих двух не совпадало никогда, логотип
    # ронялся на каждом шаге и возвращался через доли секунды - то самое
    # мигание. Поэтому запоминаем имя сериала ТОЙ ЖЕ природы: метку Kodi с
    # прошлого перехода. Обогащённое имя оставлено вторым шансом - иногда они
    # совпадают, и тогда логотип держится с первого же перехода.
    show_now = str(got.get(_demote_address(container_id, 'TVShowTitle')) or '').strip()
    show_previous = str(get_prop('SublimeHelper.ListItem.DemoteShow', win) or '').strip()
    show_published = str(get_prop('SublimeHelper.ListItem.base_tvshowtitle', win) or '').strip()
    # Главный признак - ПУТЬ, а не имя (см. _show_key): 08.09.2026 замером на
    # .30 показано, что имена подводят оба - память затирается пустой меткой, а
    # опубликованное имя из другого мира («Ричер» против «Джек Ричер»).
    path_now = _show_key(got.get(_demote_address(container_id, 'FolderPath'))
                         or got.get(_demote_address(container_id, 'FileNameAndPath')))
    path_previous = str(get_prop('SublimeHelper.ListItem.DemotePath', win) or '').strip()
    same_show = bool(path_now) and path_now == path_previous
    if not same_show:
        same_show = bool(show_now) and show_now.casefold() in (
            show_previous.casefold(), show_published.casefold())
    # Правила «нет свидетельств - держим логотип» здесь НЕТ, и это осознанно:
    # офлайн-проверка «строка без сериала логотип тоже снимает» поймала, что с
    # таким правилом фильм унаследовал бы логотип предыдущего сериала - ровно
    # то наследование, которое владелец велел исключить (08.09.2026). Логотип
    # держится только по положительному признаку: тот же путь или то же имя.
    # Память обновляется только настоящими значениями: затирание пустым и
    # ломало всю цепочку.
    if show_now:
        set_prop('SublimeHelper.ListItem.DemoteShow', show_now, win)
    if path_now:
        set_prop('SublimeHelper.ListItem.DemotePath', path_now, win)
    # Строка не должна носить сведения ЧУЖОЙ строки. 07.09.2026 владелец:
    # «в каких-то ситуациях (видимо когда подгружено не всё) айтемы наследуют
    # чужие фоны, рейтинги, клир лого и тп».
    #
    # Так и было устроено: список снимаемого писался руками и знал 12 имён, а
    # публикация выставляет под сотню - все оценки по источникам, награды,
    # сборы, страны, жанры, дату премьеры, состояние сериала, слоган, постер,
    # опознание в базах. Всё, чего в списке не было, оставалось от прошлой
    # строки до её замены, а у необогащённой строки замены не приходило вовсе.
    #
    # Теперь снимается РОВНО то, что публикация записала (она сама ведёт
    # список в SublimeHelper.Published.ListItem), кроме трёх исключений:
    #   - слой фона: картинку не убираем, её только заменяют (иначе на каждом
    #     переходе тёмный провал - за это владелец ругал отдельно);
    #   - логотип и студия того же сериала (см. выше);
    #   - то, что эта же функция сейчас перезапишет своими значениями.
    background_suffixes = {
        'BlurImage', 'BlurImage.Original', 'Current.BlurImage',
        'Current.BlurImage.Original', 'Fanart', 'Landscape', 'Still',
        'TVShow.Fanart', 'TVShow.Landscape', 'BackgroundResolving',
    }
    keep_suffixes = {
        # служебные метки самой публикации
        'IdentityPending', 'IdentityRejected', 'Key', 'Fingerprint',
        'DemoteShow', 'DemotePath', 'LogoShow', 'ProviderRetryAt', 'ProviderRetryKey',
        # значения, которые ставим ниже из метк самой строки
        'Title', 'Plot', 'Year', 'Release_Quality', 'Release_Resolution',
        'Release_Details',
    }
    if same_show:
        keep_suffixes |= {'ClearLogo', 'CropImage', 'Current.CropImage',
                          'SuppressRawClearLogo', 'Studio', 'StudioLogo'}
        # фон держится только внутри одного сериала (серии): это та же картинка
        keep_suffixes |= background_suffixes
    else:
        # Фон прошлой строки при новой - чужой арт, а он хуже паузы (владелец; .20 20.11.2026
        # держался постер «Время Счастливых»). Раньше фон здесь сохранялся ради отсутствия
        # тёмного провала; строки хаба теперь несут свой фон (Sublime.Background) и рисуют
        # его сразу, так что пауза остаётся только у строк без своих данных.
        win.clearProperty('AF3SL.WashColor')
    published = set(filter(None, get_prop(
        'SublimeHelper.Published.ListItem', win).split('|')))
    prefix_len = len('SublimeHelper.ListItem.')
    def _show_wide(suffix):
        # Сеть и студия принадлежат СЕРИАЛУ, а не серии: 08.09.2026 замер на
        # .30 показал, что вместе с логотипом на этих же строках пропадала и
        # «сеть» (Prime Video), а с ней и логотип студии внизу справа. Внутри
        # одного сериала снимать их не за что.
        return suffix.startswith('Network.') or suffix.startswith('Studio.')

    dropped = [name for name in published
               if name.startswith('SublimeHelper.ListItem.')
               and name[prefix_len:] not in keep_suffixes
               and not (same_show and _show_wide(name[prefix_len:]))]
    # Имена, которые публикация могла записать до появления списка (старый
    # снимок свойств), добавляем вручную - вреда от повторного снятия нет.
    for name in ('Rating', 'Votes', 'Runtime', 'Genre', 'Director', 'Writer',
                 'Cast', 'Trailer'):
        dropped.append('SublimeHelper.ListItem.%s' % name)
    if not same_show:
        for name in ('ClearLogo', 'CropImage', 'Current.CropImage', 'Studio',
                     'SuppressRawClearLogo'):
            dropped.append('SublimeHelper.ListItem.%s' % name)
    for name in dropped:
        win.clearProperty(name)
    win.clearProperty('AF3SL.FallbackPrimaryReal')
    set_prop('SublimeHelper.ListItem.Title', label, win)
    set_prop('SublimeHelper.ListItem.Plot', plot, win)
    set_prop('SublimeHelper.ListItem.Year', year, win)
    # Чип качества - из самой строки, как название и описание. По кадрам
    # записи владельца 10.09.2026 видно, как на переходе он гас и возвращался
    # («выглядит как неоднократная пересборка при скролле»), а гаснуть ему не
    # за что: «WEB-DL 1080» строка знает про себя сразу - это её свойство,
    # выставленное выборкой каталога, или скобка в её же ярлыке.
    # Скобка в ярлыке - самое свежее, что есть: Kodi обновляет ярлык строки
    # раньше её свойств (это записано и в vcl_service._container_has_real_fanart).
    # Поэтому сначала разбираем ярлык, а свойству строки верим только если
    # пакет прочитан ДЛЯ ТОЙ ЖЕ строки, которую служба назвала сменившейся:
    # иначе на 0.1 с в чипе оказывалось качество прошлого фильма, и владелец
    # видел, как строка «пересобирается» («WEB» -> «WEB-DL» на замере .30).
    quality, resolution = '', ''
    try:
        from resources.lib.hub import identity as _identity
        quality, resolution = _identity.release_info(label)
    except Exception:
        quality, resolution = '', ''
    if not quality and not resolution and _demote_batch_is_fresh(got, container_id, row_key):
        quality = str(got.get(_demote_address(
            container_id, 'Property(sublime_release_quality)')) or '').strip()
        resolution = str(got.get(_demote_address(
            container_id, 'Property(sublime_release_resolution)')) or '').strip()
    quality = release_short(quality)
    set_prop('SublimeHelper.ListItem.Release_Quality', quality, win)
    set_prop('SublimeHelper.ListItem.Release_Resolution', resolution, win)
    set_prop('SublimeHelper.ListItem.Release_Details', str(got.get(_demote_address(
        container_id, 'Property(sublime_release_details)')) or '').strip(), win)
    # Примета строки, к которой относится всё, что тут только что записано.
    # По ней публикация узнаёт «это та же строка» и больше ничего с экрана не
    # снимает - только заменяет (см. _publish).
    own = str(got.get(_demote_address(container_id, 'FileNameAndPath'))
              or got.get(_demote_address(container_id, 'FolderPath')) or '') or label
    if own:
        set_prop('SublimeHelper.ListItem.RowId', '%s|%s' % (
            safe_int(container_id) or '', own), win)
    # Номер сезона и серии - для строки «Сезон 2 Эпизод 5 Похороны» под
    # логотипом. Владелец 07.09.2026, глядя на список серий «Джека Ричера»:
    # «В целом я не против, чтобы был clearlogo здесь. Но где-то ниже надо
    # написать "Сезон 2 Эпизод 5 «Похороны»"». Названия серии на экране не
    # было нигде: заголовок занимает clear logo сериала, а номера Kodi отдаёт
    # только той полосе, что в фокусе (у полосы сезонов Episode - это число
    # серий в сезоне, а не номер серии). Здесь номера берутся у той самой
    # полосы, откуда взяты название и описание, поэтому они всегда об одной
    # и той же строке.
    season_now = safe_int(got.get(_demote_address(container_id, 'Season')))
    episode_now = safe_int(got.get(_demote_address(container_id, 'Episode')))
    set_prop('SublimeHelper.ListItem.Season', str(season_now) if season_now > 0 else '', win)
    set_prop('SublimeHelper.ListItem.Episode', str(episode_now) if episode_now > 0 else '', win)
    set_prop('SublimeHelper.ListItem.IdentityPending', 'true', win)


def _demote_batch_is_fresh(got, container_id, row_key=''):
    """Прочитан ли пакет метк для той же строки, которую назвала служба.

    Служба узнаёт о смене строки по ключу из ярлыка, пути и dbid
    (vcl_service._current_item_key) и передаёт его сюда. Если наш пакет даёт
    тот же ключ - значит Kodi успел обновить строку целиком, и её свойствам
    можно верить. Без ключа (старый вызов) остаёмся осторожными.
    """
    if not row_key:
        return False
    pick = lambda name: str(got.get(_demote_address(container_id, name)) or '')
    mine = '%s|%s|%s|%s' % (
        container_id,
        pick('Label') or pick('Title'),
        pick('FileNameAndPath') or pick('FolderPath'),
        pick('DBID'))
    return mine == row_key


def _demote_address(container_id, name):
    if container_id:
        return 'Container(%d).ListItem.%s' % (safe_int(container_id), name)
    return 'ListItem.%s' % name


def _demote_addresses(container_id):
    # TVShowTitle появился здесь 07.09.2026: по нему видно, остался ли фокус
    # внутри того же сериала. Читается тем же пакетом, отдельного запроса к
    # интерфейсу не добавляет.
    # Season и Episode добавлены 07.09.2026 вместе со строкой «Сезон 2
    # Эпизод 5 Похороны»: они нужны из той же полосы, что название и описание.
    # FolderPath и FileNameAndPath добавлены 08.09.2026: по пути видно, что
    # строка из того же сериала, и это надёжнее имени - см. _show_key.
    # Качество релиза - тем же пакетом: у строки оно есть сразу (его ставит
    # выборка каталога), поэтому чипу незачем гаснуть на переходе.
    return [_demote_address(container_id, name)
            for name in ('Title', 'Label', 'Plot', 'Year', 'TVShowTitle',
                         'Season', 'Episode', 'FolderPath',
                         'FileNameAndPath', 'DBID',
                         'Property(sublime_release_quality)',
                         'Property(sublime_release_resolution)',
                         'Property(sublime_release_details)')]


def _show_key(path):
    """Признак «это тот же сериал» по пути строки.

    08.09.2026, замер на .30 в списке серий «Джека Ричера»: логотип сериала
    пропадал на четырёх строках из шести и возвращался на остальных, вместе с
    ним пропадала и «сеть» (Prime Video). Удержание логотипа держалось на
    сравнении ИМЁН, и оба имени подводили:

      - DemoteShow (метка Kodi с прошлого шага) оказывалась пустой: в момент
        обновления полосы Kodi отдаёт метку пустой, и память затиралась;
      - LogoShow = «Ричер» (как зовёт TMDb), а у строки TVShowTitle = «Джек
        Ричер» (как зовёт Filmix) - эти два имени не совпадут никогда.

    Путь свободен от обеих бед: у всех серий всех сезонов одного сериала он
    одинаков до знака вопроса (номер сезона и перевод лежат в запросе), а у
    другого сериала он другой.

        plugin://plugin.video.filmix/serials/157139-dzhek-richer-pixel-2022/episodes/?t=LostFilm&s=1
        ^-------------------- одно и то же для всего сериала --------------^
    """
    value = str(path or '').strip()
    if not value:
        return ''
    value = value.split('?')[0].rstrip('/')
    # Обрезаем до сегмента с номером сериала. 08.09.2026 замером на .30
    # выяснилось, что у части строк FolderPath приходит пустым, и ключ
    # считался из пути самой серии: у полосы это «.../157139-.../episodes», а
    # у серии «.../157139-.../play» - два разных ключа вперемешку, и логотип
    # снова падал через шаг. После обрезки оба дают одно и то же.
    parts = value.split('/')
    for index, part in enumerate(parts):
        head = part.split('-')[0]
        if head.isdigit() and len(head) >= 3:
            return '/'.join(parts[:index + 1])
    return value.rsplit('/', 1)[0] or value


# Строка, которую собрали заранее. Двенадцать свойств вместо семидесяти пяти
# инфометок - и ни одного обращения в сеть.
#
# Зачем: до этого на каждую смену фокуса служба читала _MODEL_LABELS (75 метк) с
# интерфейса, опознавала фильм у поставщиков, готовила подложку и вытягивала
# цвет - на том же такте, который рисует кадр. Для строки из зеркала всё это уже
# сделано в фоне (hub/builder.py), результат лежит в самой строке, и разметка его
# уже читает первым значением. Спрашивать интерфейс заново незачем.
#
# Studio и Premiered в этом списке появились 05.09.2026. Их читал
# _model_from_row, но в пакет они не входили, поэтому каждое наведение стоило
# двух ОТДЕЛЬНЫХ запросов к интерфейсу вместо того, чтобы приехать вместе с
# остальными четырнадцатью. Список и чтение обязаны совпадать: что не в
# пакете, то читается поодиночке.
_ROW_PROPERTY_LABELS = tuple('Property(Sublime.%s)' % name for name in (
    'Background', 'Prepared', 'Fanart', 'Wash', 'Logo', 'Poster', 'Title', 'Plot', 'Year',
    'Genre', 'Country', 'Rating', 'Rating_tmdb', 'Rating_imdb', 'Rating_kp',
    'Rating_trakt', 'Rating_letterboxd', 'Rating_meta', 'Rating_rt',
    'Rating_rtuser', 'Rating_mdblist',
    'Tmdb_id', 'Tmdb_type', 'Studio', 'Premiered'))


def _row_ratings(read, fallback):
    """{источник: {'rating': значение}} из свойств готовой строки."""
    out = {}
    for source, name in (('tmdb', 'Rating_tmdb'), ('imdb', 'Rating_imdb'),
                         ('kinopoisk', 'Rating_kp'), ('trakt', 'Rating_trakt'),
                         ('letterboxd', 'Rating_letterboxd'),
                         ('metacritic', 'Rating_meta'),
                         ('rottentomatoes', 'Rating_rt'),
                         ('rottentomatoes_user', 'Rating_rtuser'),
                         ('mdblist', 'Rating_mdblist')):
        value = read(name)
        if value:
            out[source] = {'rating': value}
    if not out and fallback:
        # Старый снимок без разбивки по источникам: показываем как было.
        out['tmdb'] = {'rating': fallback}
    return out


def _model_from_row(container_id):
    """Модель из свойств строки. None - значит строка не из зеркала.

    Ключ - Sublime.Background: его пишет только сборщик, и только когда картинка
    уже готова. Всё остальное необязательно, поэтому старый снимок без
    Sublime.Fanart тоже годится: подложка тогда работает и за него.
    """
    if not container_id:
        return None
    prefetch_labels(_ROW_PROPERTY_LABELS, container_id)
    file_path = current_label('FileNameAndPath', container_id) or current_label('FolderPath', container_id)
    # Общее хранилище строк (hub/row_store.py) главнее свойств полосы: в нём слитый и самый свежий
    # блок, а полоса держит то, что было при её выдаче, и на открытом хабе нарочно не перечитывается.
    # «Формула-1» в «Рекомендациях»: очередь собрала логотип и кадр TMDb, а на экране оставались
    # постер вместо фона и пустой логотип (.20, 22.11.2026)
    block = {}
    if file_path:
        try:
            try:
                from ..hub import row_store as _row_store
            except (ImportError, ValueError):
                from hub import row_store as _row_store
            block = _row_store.get_many([file_path]).get(file_path) or {}
        except Exception as exc:
            log('хранилище строк на фокусе: %s' % exc, xbmc.LOGDEBUG)
            block = {}
    read = lambda name: str(block.get(name.lower()) or '') or current_label('Property(Sublime.%s)' % name, container_id)
    background = read('Background')
    if not background:
        return None
    release = _release_of_row(container_id)
    model = _row_model(read, background, read('Prepared'), file_path,
                       release[0], release[1], _release_details_of_row(container_id))
    # оригинальное название строки - для опознания: без него «Формула-1» искалась только по-русски
    # и не находилась (TMDb знает её как «F1»; оригинал у Filmix - «F1: The Movie»)
    model['originaltitle'] = current_label('OriginalTitle', container_id) or ''
    return model


def _row_model(read, background, prepared, file_path, release_quality='',
               release_resolution='', release_details=''):
    """Модель готовой строки по её свойствам Sublime.* (read(name) -> значение).

    Общая для фокуса (_model_from_row, свойства с интерфейса) и для заполнения
    кэшей заранее (row_model_from_snapshot, те же свойства из снимка): ключ кэша
    метаданных у обоих выходит один и тот же.
    """
    genre = read('Genre')
    rating = read('Rating')
    tmdb_type = read('Tmdb_type')
    return {
        # Снимки прошлых версий держали готовый файл в Background - оттуда и
        # берём, если своего свойства ещё нет.
        '_prepared_background': prepared or (background if background.startswith('special://') else ''),
        '_background_has_enriched_art': True,
        '_from_row': True,
        # Логотип в строке - результат обогащения (TMDb/fanart), а не сырой арт
        # дополнения. Без этой отметки _publish подавляет его для фильмов и
        # сериалов, и логотипа не было нигде.
        '_clearlogo_safe': True,
        'dbid': 0,
        # Качество релиза читается тем же способом, что и везде
        # (_release_of_row). Замер на .30 09.09.2026: у строк полос свойство
        # стояло («WEB-DLRip», «1080»), а в инфостроке было пусто - потому что
        # строки из снимков публикуются ЭТОЙ моделью, а её я сначала не тронул.
        'release_quality': release_quality,
        'release_resolution': release_resolution,
        'release_details': release_details,
        'dbtype': tmdb_type if tmdb_type in ('movie', 'tvshow', 'season', 'episode') else '',
        'media_type': tmdb_type,
        'tmdb_type': tmdb_type,
        'tmdb_id': read('Tmdb_id'),
        'title': read('Title'),
        'originaltitle': '',
        'plot': read('Plot'),
        'premiered': read('Premiered'),
        'year': safe_int(read('Year')),
        'genre': [part.strip() for part in genre.split(',') if part.strip()],
        'country_text': read('Country'),
        'country': [part.strip() for part in read('Country').split(',')
                    if part.strip()],
        # Студия и дата приезжают в самой строке (сборщик кладёт их вместе с
        # фоном и цветом), поэтому инфострока показывает рейтинг, дату, жанры и
        # страну сразу, не дожидаясь опознания в TMDB.
        'studio': [read('Studio')] if read('Studio') else [],
        'file': file_path,
        'art': {k: v for k, v in (
            ('fanart', read('Fanart') or (background if not background.startswith('special://') else '')),
            ('poster', read('Poster')),
            ('clearlogo', read('Logo'))) if v},
        # Оценки ПО ИСТОЧНИКАМ, а не одна под видом TMDb.
        #
        # До 07.09.2026 здесь стояло `{'tmdb': {'rating': rating}}`: в строке
        # лежала одна оценка, и она публиковалась как TMDb независимо от того,
        # откуда взялась. Из-за этого TMDb появлялся мгновенно из готовой
        # строки, а Кинопоиск - только после опознания в сети, уже на
        # наведении. Владелец: «появляется позже tmdb, другой механизм? не
        # включён в предзагрузку строки?» - именно так и было.
        'ratings': _row_ratings(read, rating),
        'cast': [],
        'crew': {'director': [], 'writer': []},
    }


# Сколько выдерживать пустой ответ «строки нет», прежде чем стирать публикацию.
# Такт службы - четверть секунды, окно троттла перебора строк короче секунды.
NO_FOCUS_GRACE = 1.5
_NO_FOCUS_SINCE = [0.0]


_RETRY_DONE = {}


def sync_metadata_properties(win=None, container_id=0, force=False):
    win = win or home_window()
    retry_due = False
    retry_at = safe_float(get_prop('SublimeHelper.ListItem.ProviderRetryAt', win))
    retry_key = get_prop('SublimeHelper.ListItem.ProviderRetryKey', win)
    if not container_id and not force:
        no_focus_key = 'no_focus'
        # «Строки нет» бывает мгновением, а не событием: перебор
        # сфокусированной строки троттлится и в это окно возвращает 0
        # (_focused_widget_row_cached). Стирать по такому мигу всю публикацию
        # нельзя - по кадрам записи владельца 10.09.2026 видно, как инфострока
        # пересобирается несколько раз на одно перемещение: чипы гаснут и
        # возвращаются, а год с жанрами остаются, потому что их даёт сама
        # строка. Он сказал прямо: «такого быть не должно».
        #
        # Пустой ответ выдерживается: публикация стирается только когда строки
        # нет по-настоящему (NO_FOCUS_GRACE). Это не наследование чужого арта -
        # строка та же, просто служба на миг не смогла её назвать.
        now = time.time()
        if not _NO_FOCUS_SINCE[0]:
            _NO_FOCUS_SINCE[0] = now
        if now - _NO_FOCUS_SINCE[0] < NO_FOCUS_GRACE:
            return get_prop('SublimeHelper.ListItem.Key', win) or no_focus_key
        # Идёт запуск того, что нажали (окно ожидания, видео ещё не было на весь экран):
        # строки в фокусе нет, но фон нажатой строки должен держаться до видео - у RT News
        # запуск шёл 3 с, и после NO_FOCUS_GRACE фон стирался (.20, 17.11.2026)
        try:
            if xbmc.getCondVisibility(
                    'Window.IsVisible(DialogBusy.xml) | [Player.HasMedia + '
                    'String.IsEmpty(Window(Home).Property(Sublime.VideoShown))]'):
                return get_prop('SublimeHelper.ListItem.Key', win) or no_focus_key
        except Exception:
            pass
        worker().invalidate(no_focus_key, 'SublimeHelper.ListItem')
        if get_prop('SublimeHelper.ListItem.Key', win) != no_focus_key:
            _clear_listitem_publication(win, no_focus_key)
        return no_focus_key
    _NO_FOCUS_SINCE[0] = 0.0
    fingerprint = _current_item_fingerprint(container_id)
    current_publication_key = get_prop('SublimeHelper.ListItem.Key', win)
    published_fingerprint = get_prop('SublimeHelper.ListItem.Fingerprint', win)
    if (container_id and not force and retry_at and time.time() >= retry_at and
            retry_key and retry_key == current_publication_key and published_fingerprint == fingerprint):
        set_prop('SublimeHelper.ListItem.ProviderRetryAt', '', win)
        set_prop('SublimeHelper.ListItem.ProviderRetryKey', '', win)
        # повтор после паузы поставщика - не чаще раза в час на карточку: при долгом сбое
        # TMDb/Кинопоиска карточка в фокусе иначе переспрашивалась после каждой паузы (аудит 22.11)
        now = time.time()
        if now - _RETRY_DONE.get(retry_key, 0) >= 3600:
            _RETRY_DONE[retry_key] = now
            while len(_RETRY_DONE) > 256:
                _RETRY_DONE.pop(next(iter(_RETRY_DONE)))
            force = True
            retry_due = True
            log('provider retry due container=%s' % container_id, xbmc.LOGINFO)
    if (not force and published_fingerprint == fingerprint and
            not get_prop('SublimeHelper.ListItem.IdentityPending', win) and
            not str(current_publication_key or '').startswith('transition|')):
        return current_publication_key

    # Plan step 1 (docs/PLAN_INSTANT_ART_2026-08-13.md): this used to wait for the
    # same container identity on two consecutive service ticks before daring to
    # build the model at all - "one GUI frame to let Kodi finish updating every
    # ListItem field together". Profiling showed every publication cost exactly
    # two ticks (390-560 ms of iteration time each, not the loop's 250 ms sleep),
    # and this wasted first tick was the whole reason: it never touched local,
    # never called _publish, and existed purely to wait.
    #
    # The correctness check below (verified_fingerprint != fingerprint) already
    # re-reads the identity fingerprint after building local and discards the
    # snapshot on any mismatch, on every tick, whether this is the first sight of
    # a row or not. That is the actual guard against pairing one item's title
    # with another's art - a two-tick wait made it more likely Kodi had settled
    # before the first read, it did not make the read itself any more verified
    # than this same check already makes it. Build on first sight; let this gate
    # keep discarding a snapshot exactly as it always did if focus moves again
    # mid-build.
    # Готовая строка: публикуем то, что она принесла, и на этом всё.
    row_model = _model_from_row(container_id)
    if row_model:
        # Ключ той же формы, что и на обычном пути: первое поле - номер
        # контейнера (по нему служба сверяет, к той ли строке относится
        # опубликованное), а остальные поля делают ключ пригодным для кеша
        # метаданных. Первая версия писала сюда слово «row» и свой набор полей -
        # кеш промахивался всегда, и строка оставалась без оценок и трейлера.
        key = '%s|%s|%s|%s|%s|%s|%s|%s' % (
            container_id, fingerprint, row_model.get('dbtype'), 0,
            row_model.get('tmdb_id'), row_model.get('file'),
            row_model.get('title'), config.provider_signature())
        previous_key = get_prop('SublimeHelper.ListItem.Key', win)
        _set_prop_changed(win, 'SublimeHelper.ListItem.Fingerprint', fingerprint)
        cached = None if force else worker().get_cached(key, row_model)
        if cached is not None and not _cached_fits_row(cached, row_model):
            cached = None
        if cached is not None:
            # Всё уже опознано: логотип, оценки, трейлер, актёры. Публикуем
            # полную модель, но подложку берём из строки - она уже готова.
            cached = dict(cached)
            # Логотип выбираем заново из кандидатов, лежащих в самой записи:
            # тогда правка правила действует сразу, а кэш метаданных остаётся
            # целым (иначе каждая перезагрузка - пять минут ожидания).
            cached = _clearlogo_from_cached(cached)
            cached = _keep_row_logo(cached, row_model)
            cached = _keep_row_still(cached, row_model)
            cached = _keep_row_release(cached, row_model)
            cached['_prepared_background'] = row_model['_prepared_background']
            worker().invalidate(key, 'SublimeHelper.ListItem')
            if (force or previous_key != key
                    or get_prop('SublimeHelper.ListItem.IdentityPending', win)):
                _publish(win, 'SublimeHelper.ListItem', cached, key)
                log('item=%s status=row_ready_cached' % (row_model.get('title') or ''),
                    xbmc.LOGINFO)
        else:
            # Картинка и название - сразу, из строки. Всё остальное досылает
            # рабочий поток: без него у строки не было ни оценок, ни трейлера,
            # ни логотипа.
            if (force or previous_key != key
                    or get_prop('SublimeHelper.ListItem.IdentityPending', win)):
                _publish(win, 'SublimeHelper.ListItem', row_model, key)
                log('item=%s status=row_ready' % (row_model.get('title') or ''), xbmc.LOGINFO)
            if config.online_enabled() and _metadata_available():
                worker().submit(key, 'SublimeHelper.ListItem', row_model)
        _set_prop_changed(win, 'SublimeHelper.EnableData',
                          'true' if config.online_enabled() and _metadata_available() else '')
        return key

    local = local_model_from_current(container_id)
    verified_fingerprint = _current_item_fingerprint(container_id)
    if verified_fingerprint != fingerprint:
        # Kodi updates container labels over several GUI frames. Never combine the
        # title/id from one item with art or ratings from the next one. Invalidate
        # the previous worker immediately and retry on the next service tick.
        transition_key = 'transition|%s|%s' % (container_id, verified_fingerprint)
        worker().invalidate(transition_key, 'SublimeHelper.ListItem')
        # Фон здесь снимается вместе с остальным, и это осознанно. Я пробовал
        # его сохранять (), чтобы экран не пустел на время открытия
        # окна, - и получил худшее: в окне «Видео» служба публикует только для
        # строк хаба, поэтому сохранённый фон оставался от ПРОШЛОЙ строки хаба
        # вместе со всей её публикацией, и владелец увидел чужой кадр и фолбек
        # в списке эпизодов. Пустой миг честнее чужой картинки.
        _clear_listitem_publication(win, transition_key)
        set_prop('SublimeHelper.ListItem.IdentityPending', 'true', win)
        set_prop('SublimeHelper.ListItem.BackgroundResolving', 'true' if _background_resolve_candidate_from_current(container_id) else '', win)
        _set_prop_changed(win, 'SublimeHelper.ListItem.Fingerprint', verified_fingerprint)
        log('container=%s status=focus_transition snapshot=discarded' % container_id, xbmc.LOGDEBUG)
        return transition_key
    fingerprint = verified_fingerprint
    signature = config.provider_signature()
    key = '%s|%s|%s|%s|%s|%s|%s|%s' % (
        container_id, fingerprint, local.get('dbtype'), local.get('dbid'),
        local.get('tmdb_id'), local.get('file'), local.get('title'), signature)
    previous_key = get_prop('SublimeHelper.ListItem.Key', win)
    _set_prop_changed(win, 'SublimeHelper.ListItem.Fingerprint', fingerprint)

    # A provider-quota retry must keep the currently visible metadata/artwork in
    # place. Re-submit the same item without publishing the raw local snapshot.
    if retry_due and previous_key == key:
        worker().submit(key, 'SublimeHelper.ListItem', local)
        return key

    if local.get('_is_pvr'):
        reason = ''
        if not config.pvr_lookups_enabled():
            reason = 'disabled'
        elif not local.get('_pvr_lookup_candidate'):
            reason = 'group_or_folder'
        if reason:
            worker().invalidate(key, 'SublimeHelper.ListItem')
            if force or previous_key != key or get_prop('SublimeHelper.ListItem.IdentityPending', win):
                _publish(win, 'SublimeHelper.ListItem', local, key)
                log('item=%s status=skip_pvr reason=%s' % (local.get('title') or '', reason), xbmc.LOGINFO)
            _set_prop_changed(win, 'SublimeHelper.EnableData', 'true' if config.online_enabled() and _metadata_available() else '')
            return key
        if previous_key != key:
            log('item=%s status=pvr_lookup' % (local.get('title') or ''), xbmc.LOGINFO)

    if _is_generic_youtube_item(local):
        worker().invalidate(key, 'SublimeHelper.ListItem')
        if force or previous_key != key or get_prop('SublimeHelper.ListItem.IdentityPending', win):
            # Sublime 866: YouTube items are not enriched, so they carry no clearlogo and
            # the skin falls back to a fixed-size text title that clips long video names.
            # Render the same scalable title-logo image that movies use, so the video
            # title scales to fit exactly like a clearlogo.
            try:
                if not ((local.get('art') or {}).get('clearlogo')):
                    logo = request_title_logo(
                        local.get('title') or local.get('label') or '', language_code())
                    if logo:
                        art = dict(local.get('art') or {})
                        art['clearlogo'] = logo
                        local['art'] = art
                        local['_clearlogo_safe'] = True
            except Exception:
                pass
            _publish(win, 'SublimeHelper.ListItem', local, key)
            log('item=%s status=skip_youtube_nonmedia' % (local.get('title') or ''), xbmc.LOGINFO)
        _set_prop_changed(win, 'SublimeHelper.EnableData', 'true' if config.online_enabled() and _metadata_available() else '')
        return key

    if not _has_media_evidence(local):
        worker().invalidate(key, 'SublimeHelper.ListItem')
        if force or previous_key != key or get_prop('SublimeHelper.ListItem.IdentityPending', win):
            _publish(win, 'SublimeHelper.ListItem', local, key)
            log('item=%s status=skip_nonmedia' % (local.get('title') or ''), xbmc.LOGINFO)
        _set_prop_changed(win, 'SublimeHelper.EnableData', 'true' if config.online_enabled() and _metadata_available() else '')
        return key

    if not config.online_enabled() or not _metadata_available():
        worker().invalidate(key, 'SublimeHelper.ListItem')
        _publish(win, 'SublimeHelper.ListItem', local, key)
        _set_prop_changed(win, 'SublimeHelper.EnableData', '')
        return key

    cached_result = None if force else worker().get_cached(key, local)
    if cached_result is not None and not _cached_fits_row(cached_result, local):
        cached_result = None
    if cached_result is not None:
        # Тот же пересчёт логотипа, что и во второй ветке показа кэшированной
        # строки: путей публикации два, и правило должно действовать в обоих.
        cached_result = _clearlogo_from_cached(cached_result)
        cached_result = _keep_row_still(cached_result, local)
        cached_result = _keep_row_release(cached_result, local)
        worker().invalidate(key, 'SublimeHelper.ListItem')
        _identity_cache_set(key, not bool(
            cached_result.get('_identity_rejected') or cached_result.get('_adult_blocked')))
        _publish(win, 'SublimeHelper.ListItem', cached_result, key)
        _set_prop_changed(win, 'SublimeHelper.EnableData',
                          'true' if config.online_enabled() and _metadata_available() else '')
        return key

    cached_trust = _identity_cache_get(key)
    if not force and previous_key == key:
        if get_prop('SublimeHelper.ListItem.IdentityPending', win) and cached_trust is not None:
            _publish(win, 'SublimeHelper.ListItem', _pending_local_model(local, rejected=False), key)
        return key
    # Local-first text/poster publication for online media rows, but keep the
    # background unresolved. Fallback must not appear before the enriched/no-
    # enriched decision for this same keyed media item.
    _publish(win, 'SublimeHelper.ListItem', _pending_local_model(local, rejected=False, background_resolving=_background_resolve_candidate_from_current(container_id)), key)
    worker().submit(key, 'SublimeHelper.ListItem', local)
    _set_prop_changed(win, 'SublimeHelper.EnableData', 'true' if config.online_enabled() and _metadata_available() else '')
    return key


def sync_player_properties(win=None):
    win = win or home_window()
    _set_prop_changed(win, 'SublimeHelper.EnableData', 'true' if config.online_enabled() and _metadata_available() else '')
    # Trailer playback is already tied to the selected media item. Never treat
    # the YouTube trailer title as a new movie/show and query all providers for it.
    if get_prop('TrailerPlaying', win) or _window_visible(1123):
        if get_prop('SublimeHelper.Player.Key', win) or get_prop('SublimeHelper.Player.Fingerprint', win):
            marker = 'SublimeHelper.Published.Player'
            for name in filter(None, get_prop(marker, win).split('|')):
                win.clearProperty(name)
            set_prop(marker, '', win)
            set_prop('SublimeHelper.Player.Key', '', win)
            set_prop('SublimeHelper.Player.Fingerprint', '', win)
        return ''
    # Respect the PVR lookup setting for the player path too. List-item lookup was
    # already disabled, but 702 still queried movie providers for live EPG titles.
    if xbmc.getCondVisibility('Pvr.IsPlayingTV | Pvr.IsPlayingRadio') and not config.pvr_lookups_enabled():
        marker = 'SublimeHelper.Published.Player'
        for name in filter(None, get_prop(marker, win).split('|')):
            win.clearProperty(name)
        set_prop(marker, '', win)
        set_prop('SublimeHelper.Player.Key', '', win)
        set_prop('SublimeHelper.Player.Fingerprint', _player_fingerprint(), win)
        return ''
    if not xbmc.getCondVisibility('Player.HasVideo'):
        if get_prop('SublimeHelper.Player.Key', win) or get_prop('SublimeHelper.Player.Fingerprint', win):
            marker = 'SublimeHelper.Published.Player'
            for name in filter(None, get_prop(marker, win).split('|')):
                win.clearProperty(name)
            set_prop(marker, '', win)
            set_prop('SublimeHelper.Player.Key', '', win)
            set_prop('SublimeHelper.Player.Fingerprint', '', win)
            win.clearProperty('SublimeHelper.Player.CropImage')
        return ''
    fingerprint = _player_fingerprint()
    if get_prop('SublimeHelper.Player.Fingerprint', win) == fingerprint:
        return get_prop('SublimeHelper.Player.Key', win)
    local = local_model_from_player()
    player_path = read_label('Player.FilenameAndPath') or ''
    # reset the YouTube title-logo on every player-item change so it can
    # never linger into the PVR/other-playback OSD (Info_Title draws
    # SublimeHelper.Player.CropImage). The YouTube branch below re-sets it when needed;
    # for PVR and everything else it stays cleared.
    win.clearProperty('SublimeHelper.Player.CropImage')
    if 'plugin.video.youtube' in player_path.lower() and not (
            local.get('tmdb_id') or local.get('imdb_id') or local.get('kinopoisk_id') or local.get('dbid')):
        marker = 'SublimeHelper.Published.Player'
        for name in filter(None, get_prop(marker, win).split('|')):
            win.clearProperty(name)
        set_prop(marker, '', win)
        set_prop('SublimeHelper.Player.Key', '', win)
        set_prop('SublimeHelper.Player.Fingerprint', fingerprint, win)
        # Sublime 868: give YouTube playback the same scalable title-logo as movies, so
        # the OSD title scales (Info_Title draws SublimeHelper.Player.CropImage) instead
        # of showing tiny/clipped text.
        try:
            logo = request_title_logo(
                local.get('title') or read_label('VideoPlayer.Title') or '',
                language_code())
            set_prop('SublimeHelper.Player.CropImage', logo or '', win)
        except Exception:
            pass
        return ''
    key = '%s|%s|%s|%s|%s|%s|%s' % (local.get('dbtype'), local.get('dbid'), local.get('tmdb_id'), local.get('title'), local.get('season'), local.get('episode'), config.provider_signature())
    _set_prop_changed(win, 'SublimeHelper.Player.Fingerprint', fingerprint)
    if get_prop('SublimeHelper.Player.Key', win) != key:
        _publish(win, 'SublimeHelper.Player', local, key)
        worker().submit(key, 'SublimeHelper.Player', local)
    return key


def resolve_identity(params=None):
    params = params or {}
    dbid = safe_int(params.get('dbid') or params.get('movieid') or params.get('tvshowid') or params.get('episodeid') or params.get('seasonid') or params.get('setid'))
    dbtype = normalize_dbtype(params.get('dbtype') or params.get('type'))
    if not dbtype:
        for key, value in (('movieid','movie'),('tvshowid','tvshow'),('episodeid','episode'),('seasonid','season'),('setid','set')):
            if params.get(key):
                dbtype = value
                break
    if not dbid:
        dbid = safe_int(get_prop('VCL.ActionPopup.DBID') or get_prop('VCL.Widget.DBID') or get_prop('SublimeHelper.ListItem.Monitor.DBID') or get_prop('SublimeHelper.ListItem.DBID'))
    if not dbtype:
        dbtype = normalize_dbtype(get_prop('VCL.ActionPopup.DBType') or get_prop('VCL.Widget.DBType') or get_prop('SublimeHelper.ListItem.DBType') or get_prop('SublimeHelper.ListItem.base_dbtype'))
    return dbid, dbtype


def identity_local_model(params=None):
    params = params or {}
    dbid, dbtype = resolve_identity(params)
    if dbid and dbtype:
        data = get_details(dbid, dbtype)
        if data:
            return _local_to_model(data, dbtype, dbid)
    local = local_model_from_current(0)
    for key in ('tmdb_id','tmdb_type','imdb_id','query','title','year','season','episode'):
        if params.get(key) not in (None, ''):
            if key == 'query':
                local['title'] = params[key]
            else:
                local[key] = params[key]
    return local


def video_info(meta):
    info = {
        'title': meta.get('title') or '', 'originaltitle': meta.get('originaltitle') or '', 'tvshowtitle': meta.get('tvshowtitle') or '',
        'plot': meta.get('plot') or '', 'tagline': meta.get('tagline') or '',
        'premiered': meta.get('premiered') or '', 'aired': meta.get('premiered') or '', 'duration': safe_int(meta.get('runtime')),
        'mpaa': meta.get('mpaa') or '', 'rating': safe_float(meta.get('rating')), 'userrating': safe_int(meta.get('userrating')),
        'votes': safe_int(meta.get('votes')), 'top250': safe_int(meta.get('top250')), 'playcount': safe_int(meta.get('playcount')),
        'lastplayed': meta.get('lastplayed') or '', 'dateadded': meta.get('dateadded') or '', 'genre': meta.get('genre') or [],
        'country': meta.get('country') or [], 'studio': meta.get('studio') or [], 'director': [x.get('name') for x in (meta.get('crew') or {}).get('director', [])],
        'writer': [x.get('name') for x in (meta.get('crew') or {}).get('writer', [])], 'season': safe_int(meta.get('season')), 'episode': safe_int(meta.get('episode')),
        'status': meta.get('status') or '', 'trailer': meta.get('trailer') or '', 'mediatype': meta.get('dbtype') or ('tvshow' if meta.get('media_type') == 'tv' else meta.get('media_type') or 'video'),
    }
    year = safe_int(meta.get('year'))
    if year:
        info['year'] = year
    return info


def make_video_listitem(meta, path=''):
    li = xbmcgui.ListItem(label=str(meta.get('title') or ''), path=path or str(meta.get('file') or ''), offscreen=True)
    try:
        li.setInfo('video', video_info(meta))
    except Exception:
        pass
    art = meta.get('art') or {}
    try:
        li.setArt({str(k): str(v) for k, v in art.items() if v})
    except Exception:
        pass
    try:
        unique = {'tmdb': str(meta.get('item_tmdb_id') or meta.get('tmdb_id') or '')}
        if meta.get('imdb_id'):
            unique['imdb'] = str(meta.get('imdb_id'))
        if meta.get('tvdb_id'):
            unique['tvdb'] = str(meta.get('tvdb_id'))
        if meta.get('kinopoisk_id'):
            unique['kinopoisk'] = str(meta.get('kinopoisk_id'))
        li.setUniqueIDs({k: v for k, v in unique.items() if v})
    except Exception:
        pass
    props = {k.split('SublimeHelper.ListItem.', 1)[-1]: v for k, v in window_properties(meta).items()}
    props.update({'tmdb_id': meta.get('tmdb_id') or '', 'tmdb_type': meta.get('tmdb_type') or '', 'TMDb_ID': meta.get('tmdb_id') or '', 'TMDb_Type': meta.get('tmdb_type') or '', 'DBID': meta.get('dbid') or '', 'DBType': meta.get('dbtype') or ''})
    try:
        li.setProperties({str(k): str(v) for k, v in props.items() if v not in (None, '')})
    except Exception:
        pass
    return li


def builtin_escape(value):
    value = '' if value is None else str(value)
    return '"%s"' % value.replace('\\', '\\\\').replace('"', '\\"')




def _youtube_directory_first_video(directory, limit=5, depth=0, visited=None):
    # audit/refactor:
    # Do not call directory-expansion from the skin helper.  Directory probing can
    # re-enter plugin routes, touch widgets while Home is returning, and produce
    # the same class of phantom reloads that this branch is avoiding.  Trailer
    # search may still use direct provider URLs when already present in metadata,
    # but the skin never expands plugin directories by itself.
    return ''


def get_first_youtube_video(query, limit=5):
    addon = config.youtube_addon()
    # YouTube 7.x uses singular search_type=video for actual result items.
    # The old plural value returned a category directory, which was then passed
    # to PlayMedia and opened an empty trailer window without playback.
    directory = 'plugin://%s/kodion/search/query/?q=%s&search_type=video' % (
        addon, quote_plus(query))
    path = _youtube_directory_first_video(directory, limit)
    if path:
        log('youtube search hit query=%s playable=yes' % query, xbmc.LOGINFO)
        return path
    log('youtube search empty query=%s playable=no' % query, xbmc.LOGINFO)
    return ''
