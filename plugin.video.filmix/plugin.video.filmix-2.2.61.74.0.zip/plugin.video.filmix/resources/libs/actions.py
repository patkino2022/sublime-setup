# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import json

import xbmc
import xbmcgui
from future.utils import iteritems

from .utilities import plugin, WebClientError, _
from .web import (Filmix, FilmixError)
from .prewarm import FilmixPrewarm
from .cache import FilmixCache


class FilmixActions(object):
    @staticmethod
    def login():
        try:
            api = Filmix()
            token_result = api.token_request()
            if not (isinstance(token_result, dict) and token_result.get('code')):
                # сервер ответил без кода (Windows, 23.11.2026: KeyError 'code' сразу после установки,
                # минутой позже тот же запрос давал код) - ещё раз, потом - причина вместо падения
                xbmc.sleep(3000)
                token_result = api.token_request()
            if not (isinstance(token_result, dict) and token_result.get('code')):
                raise FilmixError('token_request: %s' % json.dumps(token_result, ensure_ascii=False)[:200])
            update_info = api.check_update()
        except (FilmixError, WebClientError) as e:
            plugin.notify_error(e, True)
        else:
            api.update_dev_token(token_result['code'])
            plugin.set_setting('user_dev_token', token_result['code'])

            code = token_result['user_code']
            domain = update_info['domain']

            progress = plugin.dialog_progress_create(_('Authorization'),
                                                     _('Connection code: [B]{0}[/B]').format(code),
                                                     _('Enter code on the page [B]{0}/consoles[/B]').format(domain),
                                                     _('or in the site menu [B]\'Profile\' -> \'Consoles\'[/B]'))
            wait_sec = 300
            step_sec = 2
            pass_sec = 0
            check_sec = 20

            user_fields = api.get_user_fields()
            while pass_sec < wait_sec:
                if progress.iscanceled():
                    return

                xbmc.sleep(step_sec * 1000)
                pass_sec += step_sec

                plugin.dialog_progress_update(progress, int(100 * pass_sec / wait_sec))

                if (pass_sec % check_sec) == 0:
                    try:
                        user_data = api.user_data()
                    except (FilmixError, WebClientError) as e:
                        plugin.notify_error(e)
                    else:
                        user_fields = api.get_user_fields(user_data)
                        if user_fields['user_login']:
                            break

            progress.close()

            plugin.set_settings(user_fields)

            if user_fields['user_login']:
                # (kept on top of 59.17 manual overrides):
                # After device-code login the old cache-only account widgets may still
                # contain stale empty Favorites/Watch Later rows created while logged out.
                # Invalidate only these account sections and force a background refresh.
                try:
                    cache = FilmixCache(plugin.profile_dir)
                    for _section in ('favorites', 'deferred'):
                        try:
                            cache.clear_catalog_cache(_section)
                        except Exception:
                            pass
                    try:
                        FilmixPrewarm(plugin).refresh_sections(['favorites', 'deferred'], force=True, silent=True)
                    except Exception:
                        try:
                            FilmixPrewarm(plugin).request_refresh(['favorites|1|', 'deferred|1|'])
                        except Exception:
                            pass
                    try:
                        xbmc.log('[plugin.video.filmix] AccountCacheFix: login_success cleared favorites/deferred catalog+snapshots and requested refresh', xbmc.LOGINFO)
                    except Exception:
                        pass
                except Exception as e:
                    try:
                        xbmc.log('[plugin.video.filmix] AccountCacheFix: login_success refresh failed: {0}'.format(e), xbmc.LOGWARNING)
                    except Exception:
                        pass
                plugin.dialog_ok(_('You have successfully logged in'))
                xbmc.executebuiltin('Container.Refresh')
            else:
                plugin.dialog_ok(_('Login failure! Please, try later'))

    @staticmethod
    def select_videoserver():
        api = Filmix()
        try:
            user_data = api.user_data()
        except (FilmixError, WebClientError) as e:
            plugin.notify_error(e)
        else:
            keys = []
            titles = []
            for key, val in iteritems(user_data.get('available_servers')):
                titles.append(val)
                keys.append(key)

            videoserver = user_data.get('videoserver') or 'AUTO'

            if titles:
                if plugin.kodi_major_version() >= '17':
                    preselect = keys.index(videoserver)
                    selected = xbmcgui.Dialog().select(_('Select video server'), titles, preselect=preselect)
                else:
                    selected = xbmcgui.Dialog().select(_('Select video server'), titles)

                if selected is not None \
                        and keys[selected] != videoserver:
                    try:
                        result = api.set_videoserver(keys[selected])
                    except (FilmixError, WebClientError) as e:
                        plugin.notify_error(e)
                    else:
                        if result['status'] == 'ok' \
                                and videoserver != result['server']:
                            plugin.set_setting('videoserver', user_data['available_servers'].get(result['server']))
                            xbmcgui.Dialog().notification(plugin.name, _('Video server successfully changed'),
                                                          xbmcgui.NOTIFICATION_INFO)

    @staticmethod
    def check_device():
        Filmix().check_device()

    @staticmethod
    def toogle_favorites():
        content_id = plugin.params.get('id')

        try:
            api = Filmix()
            result = api.set_favorite(content_id)
        except (FilmixError, WebClientError) as e:
            plugin.notify_error(e, True)
        else:
            if result.get('id') is not None:
                xbmcgui.Dialog().notification(plugin.name, _('Successfully added to Favorites'),
                                              xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification(plugin.name, _('Successfully removed from Favorites'),
                                              xbmcgui.NOTIFICATION_INFO)

            try:
                prewarm = FilmixPrewarm(plugin)
                # Обновляем кеш раздела и тут же перечитываем список: заказ
                # перерисовки виджета главной провайдер больше не оформляет -
                # это делает скин, а на открытом экране довольно
                # Container.Refresh() ниже.
                prewarm.refresh_sections(['favorites'], force=True, silent=True)
            except Exception as e:
                plugin.log_debug('Filmix prewarm favorites refresh failed: {0}'.format(e))

            FilmixActions._user_lists_changed()

    @staticmethod
    def _user_lists_changed():
        """Списки «Избранное»/«Смотреть позже» изменились - перечитать экран.

        Container.Refresh перечитывает список в окне самого дополнения, но не
        виджет на главной: 06.11.2026 на .20 «Книготорговцы» были убраны из
        избранного в 20:02:51, а полоса показывала их и в 20:04 - маршрут
        favorites после этого не запускался. Виджет Kodi перечитывает по
        событию медиатеки (CDirectoryProvider: VideoLibrary OnScanFinished /
        OnUpdate) или при смене адреса. Событие даёт пустое сканирование
        несуществующей папки: на .30 оно заняло 12 мс, и полоса «Смотреть
        позже» перечиталась через 0,6 с. Медиатеку оно не трогает.
        """
        try:
            xbmc.executeJSONRPC(json.dumps({
                'jsonrpc': '2.0', 'id': 1, 'method': 'VideoLibrary.Scan',
                'params': {'directory': 'special://temp/filmix-lists-changed/',
                           'showdialogs': False}}))
        except Exception as e:
            plugin.log_debug('Filmix widget reload failed: {0}'.format(e))
        xbmc.executebuiltin('Container.Refresh()')

    @staticmethod
    def toogle_watch_later():
        content_id = plugin.params.get('id')

        try:
            api = Filmix()
            result = api.set_watch_later(content_id)
        except (FilmixError, WebClientError) as e:
            plugin.notify_error(e, True)
        else:
            if result.get('id') is not None:
                xbmcgui.Dialog().notification(plugin.name, _('Successfully added to Watch Later'),
                                              xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().notification(plugin.name, _('Successfully removed from Watch Later'),
                                              xbmcgui.NOTIFICATION_INFO)

            try:
                prewarm = FilmixPrewarm(plugin)
                # То же, что в toogle_favorites() выше.
                prewarm.refresh_sections(['deferred'], force=True, silent=True)
            except Exception as e:
                plugin.log_debug('Filmix prewarm deferred refresh failed: {0}'.format(e))

            FilmixActions._user_lists_changed()


