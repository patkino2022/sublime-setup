# -*- coding: utf-8 -*-
"""
RuTor -> TMDbHelper tmdb_id bridge.

Fast design:
- no Files.GetDirectory calls;
- no poster/fanart/plot enrichment from TMDbHelper;
- no separate cache;
- native RuTor info.db and server.py prewarm are preserved;
- list drawing does not block on TMDbHelper lookups unless tmdb_id already exists in info.db;
- default AM8 4GB mode resolves tmdb_id only when a single item is opened;
- native Check() prewarms only RuTor/KPDB cache unless slow background TMDb is explicitly enabled;
- RuTor titles stay raw; candidate count is limited to reduce TMDbHelper load.
"""
import os
import re
import sys
import time

import xbmc
import xbmcaddon

BUILD = 'tmdbid'
_MEMO = {}
_IMPORT_FAILED = False

_ALLOWED_INFO = set([
    'count', 'size', 'date', 'genre', 'country', 'year', 'episode', 'season',
    'sortepisode', 'sortseason', 'episodeguide', 'showlink', 'top250', 'setid',
    'tracknumber', 'rating', 'userrating', 'watched', 'playcount', 'overlay',
    'cast', 'castandrole', 'director', 'mpaa', 'plot', 'plotoutline', 'title',
    'originaltitle', 'sorttitle', 'duration', 'studio', 'tagline', 'writer',
    'tvshowtitle', 'premiered', 'status', 'set', 'setoverview', 'tag',
    'imdbnumber', 'code', 'aired', 'credits', 'lastplayed', 'album', 'artist',
    'votes', 'trailer', 'mediatype', 'dbid', 'dateadded'
])

# v4.3.4: do not clean RuTor names; duplicate the full RuTor row into Kodi UI fields.


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('[plugin.video.RuTor][tmdbid] %s: %s' % (BUILD, msg), level)
    except Exception:
        pass


_ADDON = []


def _get_setting(setting_id, default=''):
    # Addon() - один на вызов плагина, а не на каждое чтение (21.11.2026).
    try:
        if not _ADDON:
            _ADDON.append(xbmcaddon.Addon(id='plugin.video.RuTor'))
        value = _ADDON[0].getSetting(setting_id)
        if value == '' or value is None:
            return default
        return value
    except Exception:
        return default


def tmdb_mode():
    """0=off, 1=open-only/default for AM8 4GB, 2=slow background."""
    return _get_setting('tmdb_id_mode', '1')


def tmdb_resolve_enabled():
    return tmdb_mode() != '0'


def tmdb_background_enabled():
    return tmdb_mode() == '2'


def _enum_int(setting_id, values, default):
    try:
        idx = int(_get_setting(setting_id, str(default)))
        if idx < 0 or idx >= len(values):
            idx = default
        return values[idx]
    except Exception:
        return values[default]


def background_max_items():
    # Conservative defaults for Ugoos AM8 4GB. This is used only when the user
    # explicitly enables slow background TMDb mode in settings.
    return _enum_int('tmdb_bg_max', [2, 4, 8], 0)


def background_sleep_ms():
    return _enum_int('tmdb_bg_sleep', [500, 1500, 3000], 1)


def background_time_budget_sec():
    return _enum_int('tmdb_bg_budget', [8, 15, 30], 0)


def background_can_resolve(done_count, start_time):
    if not tmdb_background_enabled():
        return False
    try:
        if int(done_count) >= int(background_max_items()):
            return False
    except Exception:
        return False
    try:
        if time.time() - float(start_time) > float(background_time_budget_sec()):
            return False
    except Exception:
        pass
    return True


def background_pause():
    try:
        xbmc.sleep(int(background_sleep_ms()))
    except Exception:
        pass


def _addon_path(addon_id):
    try:
        return xbmcaddon.Addon(id=addon_id).getAddonInfo('path')
    except Exception:
        return ''


def _tmdb_api():
    """TMDb Helper больше не используется (нет ни на коробках, ни в установщике, 23.11.2026):
    номер TMDb строке даёт опознание скина. Поиск через его API отключён."""
    return None


def clean_info_labels(info):
    out = {}
    try:
        for k, v in info.items():
            if k in _ALLOWED_INFO:
                out[k] = v
    except Exception:
        return info or {}
    return out


def has_tmdb_id(info):
    try:
        return bool(info.get('tmdb_id') or info.get('uniqueid', {}).get('tmdb'))
    except Exception:
        return False


def get_existing_tmdb_id(info):
    try:
        v = info.get('tmdb_id') or info.get('uniqueid', {}).get('tmdb')
        if v:
            return str(v)
    except Exception:
        pass
    return ''


def _media_type(info, fallback=None):
    t = ''
    try:
        t = info.get('type') or info.get('mediatype') or ''
    except Exception:
        pass
    if not t and fallback:
        try:
            t = fallback.get('type') or fallback.get('mediatype') or ''
        except Exception:
            pass
    t = str(t).lower()
    if t in ('show', 'tv', 'tvshow', 'series'):
        return 'tv'
    return 'movie'


def _first_year(year):
    try:
        m = re.search(r'(19\d{2}|20\d{2})', str(year or ''))
        return m.group(1) if m else ''
    except Exception:
        return ''


def _raw_title(title):
    if title is None:
        return ''
    try:
        title = str(title)
    except Exception:
        return ''
    return title.replace('\xa0', ' ').strip()


def _candidate_titles(info, fallback=None):
    raw = []
    # Prefer original RuTor fields from fallback over KPDB/setInfo names.
    for src in (fallback or {}, info or {}):
        for key in ('originaltitle', 'title', 'tvshowtitle', 'fulltitle'):
            try:
                val = src.get(key)
            except Exception:
                val = None
            if val:
                raw.append(val)
    out = []
    for val in raw:
        # Keep the original plugin title. Only split bilingual "RU / EN" variants
        # into candidates; do not remove WEBRip/year/voiceover/noise tokens.
        parts = [val]
        if ' / ' in str(val):
            p = str(val).split(' / ')
            if len(p) >= 2:
                parts = [p[1], p[0], val]
        for p in parts:
            c = _raw_title(p)
            if c and c not in out and len(c) >= 2:
                out.append(c)
    return out[:3]


def preserve_plugin_titles(info, source=None, label=None):
    """Keep displayed/TAM title fields from RuTor, not from TMDb/KPDB.

    TMDbHelper resolution can still use all raw candidates, including fulltitle,
    but Kodi/TAM see the original plugin title/originaltitle.
    """
    if info is None:
        info = {}
    source = source or {}
    try:
        if source.get('title'):
            info['title'] = source.get('title')
        elif label:
            info['title'] = label
    except Exception:
        pass
    try:
        if source.get('originaltitle'):
            info['originaltitle'] = source.get('originaltitle')
    except Exception:
        pass
    try:
        if source.get('fulltitle'):
            info['rutor_fulltitle'] = source.get('fulltitle')
    except Exception:
        pass
    return info


def restore_list_label(listitem, label):
    if not label:
        return
    try:
        listitem.setLabel(label)
    except Exception:
        pass



def _text(value):
    if value is None:
        return ''
    try:
        value = str(value)
    except Exception:
        return ''
    return value.replace('\xa0', ' ').strip()


def _source_fulltitle(source):
    source = source or {}
    for key in ('fulltitle', 'rutor_fulltitle', 'rutor_torrent_title', 'title', 'originaltitle'):
        try:
            val = _text(source.get(key))
        except Exception:
            val = ''
        if val:
            return val
    return ''


def make_ui_info(info, display_title='', source=None):
    """Return a UI-only info copy with the exact RuTor visible row as title.

    The original info dict is intentionally not changed, because it is passed to TAM
    and to native RuTor routes. This only affects Kodi ListItem.Info labels used by
    skins such as Arctic Fuse.
    """
    try:
        out = dict(info or {})
    except Exception:
        out = info or {}
    shown = _text(display_title) or _source_fulltitle(source) or _text(out.get('title'))
    full = _source_fulltitle(source) or shown
    if shown:
        try:
            out['title'] = shown
            out['sorttitle'] = shown
        except Exception:
            pass
    if full:
        try:
            out['plotoutline'] = full
            out['tagline'] = full
            old_plot = _text(out.get('plot'))
            if old_plot and full not in old_plot:
                out['plot'] = full + '\n\n' + old_plot
            elif not old_plot:
                out['plot'] = full
        except Exception:
            pass
    try:
        if 'originaltitle' not in out and shown:
            out['originaltitle'] = shown
    except Exception:
        pass
    return out


def apply_display_properties(listitem, display_title='', source=None):
    shown = _text(display_title)
    full = _source_fulltitle(source) or shown
    for key, value in (
        ('rutor.displaytitle', shown),
        ('rutor.fulltitle', full),
        ('rutor.label', shown),
        ('RUTOR_DISPLAY_TITLE', shown),
        ('RUTOR_FULL_TITLE', full),
    ):
        if not value:
            continue
        try:
            listitem.setProperty(key, value)
        except Exception:
            pass
    try:
        if full:
            listitem.setLabel2(full)
    except Exception:
        pass


def _call_get_tmdb_id(api, tmdb_type, query, year):
    attempts = []
    base = {'tmdb_type': tmdb_type, 'query': query}
    if year:
        base['year'] = year
    attempts.append(base)
    base2 = {'type': tmdb_type, 'query': query}
    if year:
        base2['year'] = year
    attempts.append(base2)
    base3 = {'tmdb_type': tmdb_type, 'title': query}
    if year:
        base3['year'] = year
    attempts.append(base3)
    for params in attempts:
        try:
            result = api.get_tmdb_id(**params)
            if result:
                return str(result)
        except TypeError:
            continue
        except Exception as exc:
            log('get_tmdb_id failed query=%s type=%s year=%s err=%s' % (query, tmdb_type, year, exc), xbmc.LOGDEBUG)
            continue
    return ''


def resolve_tmdb_id(info, fallback=None):
    if not tmdb_resolve_enabled():
        return ''
    existing = get_existing_tmdb_id(info)
    if existing:
        return existing
    tmdb_type = _media_type(info, fallback)
    year = _first_year((info or {}).get('year') or (fallback or {}).get('year'))
    titles = _candidate_titles(info or {}, fallback or {})
    if not titles:
        return ''
    key = (tmdb_type, year, tuple(titles))
    if key in _MEMO:
        return _MEMO[key]
    api = _tmdb_api()
    if not api:
        _MEMO[key] = ''
        return ''
    for title in titles:
        tmdb_id = _call_get_tmdb_id(api, tmdb_type, title, year)
        if tmdb_id:
            _MEMO[key] = tmdb_id
            log('resolved tmdb_id=%s type=%s year=%s title=%s' % (tmdb_id, tmdb_type, year, title), xbmc.LOGINFO)
            return tmdb_id
    _MEMO[key] = ''
    return ''


def enrich_info(info, fallback=None):
    if info is None:
        info = {}
    tmdb_id = resolve_tmdb_id(info, fallback)
    if not tmdb_id:
        return info
    try:
        info['tmdb_id'] = tmdb_id
        info['uniqueid'] = dict(info.get('uniqueid') or {})
        info['uniqueid']['tmdb'] = tmdb_id
        mt = _media_type(info, fallback)
        info['tmdbhelper_type'] = mt
        if mt == 'tv':
            info.setdefault('mediatype', 'tvshow')
        else:
            info.setdefault('mediatype', 'movie')
    except Exception:
        pass
    return info


def apply_to_listitem(listitem, info):
    tmdb_id = get_existing_tmdb_id(info or {})
    if not tmdb_id:
        return
    try:
        listitem.setUniqueIDs({'tmdb': str(tmdb_id)}, 'tmdb')
    except Exception:
        pass
    for prop in ('tmdb_id', 'TMDb_ID', 'TMDbHelper.TMDB_ID'):
        try:
            listitem.setProperty(prop, str(tmdb_id))
        except Exception:
            pass
