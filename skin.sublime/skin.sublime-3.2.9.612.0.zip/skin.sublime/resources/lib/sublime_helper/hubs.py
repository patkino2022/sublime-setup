# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Canonical peer-hub identifiers shared by Sublime runtime helpers.

The Kodi system Home window (10000) is not a Sublime hub. 1100 is only the
first-run fallback and otherwise has exactly the same status as every peer hub.
"""

REAL_HUB_IDS = ('1100', '1101', '1102', '1103', '1104', '1106', '1107', '1108')
REAL_HUB_ID_SET = frozenset(REAL_HUB_IDS)
REAL_HUB_WINDOW_IDS = tuple(int(value) for value in REAL_HUB_IDS)
LOCAL_HUB_WINDOW_IDS = tuple(value + 10000 for value in REAL_HUB_WINDOW_IDS)
HUB_AND_LOCAL_WINDOW_IDS = frozenset(REAL_HUB_WINDOW_IDS + LOCAL_HUB_WINDOW_IDS)
DEFAULT_HUB_ID = '1100'


def _visible_condition(window_ids):
    return ' | '.join('Window.IsVisible(%d)' % value for value in window_ids)


REAL_HUB_VISIBILITY_CONDITION = _visible_condition(REAL_HUB_WINDOW_IDS)
LOCAL_HUB_VISIBILITY_CONDITION = _visible_condition(LOCAL_HUB_WINDOW_IDS)
HUB_AND_LOCAL_VISIBILITY_CONDITION = ' | '.join(
    value for value in (REAL_HUB_VISIBILITY_CONDITION, LOCAL_HUB_VISIBILITY_CONDITION) if value)
SERVICE_UI_WINDOW_IDS = (1105, 1109, 11105, 11109)
HUB_SERVICE_UI_VISIBILITY_CONDITION = ' | '.join(
    value for value in (HUB_AND_LOCAL_VISIBILITY_CONDITION, _visible_condition(SERVICE_UI_WINDOW_IDS)) if value)


def valid_hub_id(value, default=''):
    candidate = str(value or '').strip()
    if candidate in REAL_HUB_ID_SET:
        return candidate
    return str(default or '') if str(default or '') in REAL_HUB_ID_SET else ''


def hub_from_window_id(value, default=''):
    try:
        window_id = int(value)
    except (TypeError, ValueError):
        return valid_hub_id(default)
    if window_id in REAL_HUB_WINDOW_IDS:
        return str(window_id)
    if window_id in LOCAL_HUB_WINDOW_IDS:
        return str(window_id - 10000)
    return valid_hub_id(default)


def local_window_id(hub_id, default=0):
    hub_id = valid_hub_id(hub_id)
    return int(hub_id) + 10000 if hub_id else int(default or 0)


HUB_CONFIGURATION_MARKER = 'Sublime.HubConfigurationInitialized709'


def enabled_hub_ids(info_label=None):
    """Return enabled peer hubs in canonical carousel order."""
    if info_label is None:
        try:
            # Through core.read_label, not xbmc.getInfoLabel: that API is what
            # segfaults Kodi 22-BETA1 (docs/CRASH_GETINFOLABEL_2026-08-23.md).
            from .core import read_label
            info_label = read_label
        except Exception:
            info_label = lambda _label: ''
    enabled = []
    for hub_id in REAL_HUB_IDS:
        try:
            value = info_label('Skin.String(HomeSwitcher.%s.Toggle)' % hub_id)
        except Exception:
            value = ''
        if str(value or '').strip():
            enabled.append(hub_id)
    return tuple(enabled)


def select_enabled_hub(saved_hub='', enabled_ids=None, configuration_exists=True):
    """Choose an enabled peer hub without assigning special status to 1100.

    Preference order: saved hub, nearest enabled hub in canonical order, first
    enabled hub. 1100 is used only for an unconfigured first run.
    """
    enabled = tuple(h for h in (enabled_ids if enabled_ids is not None else enabled_hub_ids())
                    if h in REAL_HUB_ID_SET)
    saved = valid_hub_id(saved_hub)
    if saved and saved in enabled:
        return saved
    if enabled and saved:
        index = REAL_HUB_IDS.index(saved)
        for distance in range(1, len(REAL_HUB_IDS)):
            left = index - distance
            right = index + distance
            if left >= 0 and REAL_HUB_IDS[left] in enabled:
                return REAL_HUB_IDS[left]
            if right < len(REAL_HUB_IDS) and REAL_HUB_IDS[right] in enabled:
                return REAL_HUB_IDS[right]
    if enabled:
        return enabled[0]
    return DEFAULT_HUB_ID if not configuration_exists else ''


def adjacent_enabled_hub(current_hub, direction='previous', enabled_ids=None):
    """Return the next enabled carousel peer, wrapping at either end."""
    enabled = tuple(h for h in (enabled_ids if enabled_ids is not None else enabled_hub_ids())
                    if h in REAL_HUB_ID_SET)
    current = valid_hub_id(current_hub)
    if not enabled or not current:
        return ''
    step = -1 if str(direction or '').lower() in ('previous', 'prev', 'up', '-1') else 1
    start = REAL_HUB_IDS.index(current)
    for offset in range(1, len(REAL_HUB_IDS) + 1):
        candidate = REAL_HUB_IDS[(start + step * offset) % len(REAL_HUB_IDS)]
        if candidate in enabled:
            return candidate
    return ''
