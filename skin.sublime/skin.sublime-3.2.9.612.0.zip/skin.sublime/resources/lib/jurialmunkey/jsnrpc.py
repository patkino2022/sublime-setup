from xbmc import executeJSONRPC
from jurialmunkey.parser import try_int


def get_jsonrpc(method=None, params=None, query_id=1):
    if not method:
        return {}
    query = {
        "jsonrpc": "2.0",
        "method": method,
        "id": query_id}
    if params:
        query["params"] = params
    try:
        from json import dumps, loads
        jrpc = executeJSONRPC(dumps(query))
        response = loads(jrpc)
    except Exception as exc:
        from jurialmunkey.logger import Logger
        Logger(log_name='[sublime.local.jurialmunkey]').kodi_log(f'JSONRPC Error:\n{exc}', 1)
        response = {}
    if 'error' in response:
        from jurialmunkey.logger import Logger
        Logger(log_name='[sublime.local.jurialmunkey]').kodi_log(f'JSONRPC Error:\n{query}\n{response}', 1)
    return response


def get_details(dbid, dbtype, key):
    json_info = get_jsonrpc(
        method=f'VideoLibrary.Get{dbtype.capitalize()}Details',
        params={f'{dbtype}id': dbid, "properties": [key]})
    try:
        return json_info['result'][f'{dbtype}details'][key]
    except (AttributeError, KeyError):
        return


def set_tags(dbid=None, dbtype=None, tags=None):
    if not dbid or not dbtype or not tags:
        return

    old_db_tags = set(get_details(dbid, dbtype, key='tag') or [])
    new_db_tags = old_db_tags | set(tags)

    if new_db_tags == old_db_tags:
        return

    return get_jsonrpc(
        method=f'VideoLibrary.Set{dbtype.capitalize()}Details',
        params={f'{dbtype}id': dbid, "tag": list(new_db_tags)})


def get_directory(url, properties=None):
    method = "Files.GetDirectory"
    properties = properties or [
        "title", "year", "originaltitle", "imdbnumber", "premiered", "streamdetails", "size",
        "firstaired", "season", "episode", "showtitle", "file", "tvshowid", "thumbnail"]
    params = {
        "directory": url,
        "media": "files",
        "properties": properties}
    response = get_jsonrpc(method, params)
    try:
        return response['result']['files'] or [{}]
    except KeyError:
        return [{}]
