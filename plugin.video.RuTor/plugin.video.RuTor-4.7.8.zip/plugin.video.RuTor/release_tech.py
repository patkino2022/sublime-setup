# -*- coding: utf-8 -*-
"""Технические данные раздачи: размер кадра со страницы релиза.

Владелец 11.09.2026: «как понять какое разрешение у BDRip? Нигде нет сведений
об этом в чипах скина». И правда - в названии раздачи высоты часто нет вовсе:
«Один дома / Home Alone (1990) BDRip-AVC от ExKinoRay | P». Зато на странице
самой раздачи размер кадра написан точно:

    Видео: 656x352 (1.85:1), 23,976 fps, x264 (AVC), 927 kbps

Отсюда и берём. Замер на .30 11.09.2026: страница раздачи отдаётся быстро -
четыре страницы подряд за 0.4 с, двенадцать в шести потоках за 0.3 с, - поэтому
на список релизов это не влияет заметно. Разобранное складывается в info.db
навсегда: у готовой раздачи размер кадра не меняется.

Класс для чипа считается по ШИРИНЕ кадра, а не по высоте: широкоформатные рипы
обрезаны сверху и снизу (1920x1040, 1280x688, 1000x544), и по высоте они
попадали бы классом ниже. Точный размер при этом всё равно виден - он идёт во
вторую строку под инфострокой.
"""
from __future__ import absolute_import, unicode_literals

import os
import re
import sqlite3
import sys
import time

try:
    from concurrent.futures import ThreadPoolExecutor
except Exception:  # очень старый python - обойдёмся без параллели
    ThreadPoolExecutor = None

if sys.version_info.major > 2:
    import urllib.request as urllib2
else:
    import urllib2

import xbmc
import xbmcaddon

ADDON = 'plugin.video.RuTor'
# Сколько всего ждать страницы релизов на один список. Кэш делает второй заход
# мгновенным, а первый не должен превращаться в ожидание.
BUDGET = 6.0
WORKERS = 6
_FRAME = re.compile(r'(\d{3,4})\s*[xх×]\s*(\d{3,4})')
_TAGS = re.compile(r'<[^>]+>')
_MEMO = {}


def _db_path():
    # Та же info.db, что у default.py, - в addon_data: папку дополнения стирает
    # каждое обновление (21.11.2026).
    try:
        import xbmcvfs
        folder = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON)
        if not os.path.isdir(folder):
            os.makedirs(folder)
        return os.path.join(folder, 'info.db')
    except Exception:
        return ''


def _connect():
    path = _db_path()
    if not path:
        return None
    try:
        conn = sqlite3.connect(path, timeout=5)
        conn.execute('CREATE TABLE IF NOT EXISTS release_tech '
                     '(id TEXT PRIMARY KEY, w INTEGER, h INTEGER, at INTEGER)')
        conn.commit()
        return conn
    except Exception as exc:
        xbmc.log('[%s] release_tech: база не открылась: %s' % (ADDON, exc), xbmc.LOGDEBUG)
        return None


def _stored(conn, ids):
    found = {}
    if conn is None:
        return found
    for number in ids:
        try:
            row = conn.execute('SELECT w, h FROM release_tech WHERE id = ?',
                               (str(number),)).fetchone()
        except Exception:
            row = None
        if row and row[0] and row[1]:
            found[str(number)] = (int(row[0]), int(row[1]))
    return found


def _store(conn, found):
    if conn is None or not found:
        return
    try:
        now = int(time.time())
        for number, (w, h) in found.items():
            conn.execute('INSERT OR REPLACE INTO release_tech (id, w, h, at) '
                         'VALUES (?, ?, ?, ?)', (str(number), int(w), int(h), now))
        conn.commit()
    except Exception as exc:
        xbmc.log('[%s] release_tech: не записал: %s' % (ADDON, exc), xbmc.LOGDEBUG)


def _get(url, timeout=10):
    try:
        request = urllib2.Request(url)
        request.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; '
                                         'U; ru) Presto/2.6.30 Version/10.60')
        request.add_header('Accept', '*/*')
        request.add_header('Accept-Language', 'ru,en;q=0.9')
        answer = urllib2.urlopen(request, timeout=max(1.0, timeout))
        raw = answer.read()
        answer.close()
    except Exception:
        return ''
    for encoding in ('utf-8', 'windows-1251'):
        try:
            return raw.decode(encoding)
        except Exception:
            continue
    try:
        return raw.decode('utf-8', 'ignore')
    except Exception:
        return ''


def _frame_of(page):
    """Размер кадра со страницы раздачи: (ширина, высота)."""
    if not page:
        return None
    text = _TAGS.sub('\n', page)
    best = None
    for line in text.splitlines():
        low = line.lower()
        if 'видео' not in low and 'video' not in low and 'разрешение' not in low:
            continue
        hit = _FRAME.search(line)
        if hit:
            best = (int(hit.group(1)), int(hit.group(2)))
            break
    if best is None:
        hit = _FRAME.search(text)
        if hit:
            best = (int(hit.group(1)), int(hit.group(2)))
    if not best:
        return None
    width, height = best
    # Отсеиваем явную чушь: обложки, баннеры и «1920x1080» из подписи к фото.
    if width < 320 or height < 180 or width > 8192 or height > 4320:
        return None
    return best


def frame_class(width, height=0):
    """Класс для чипа по ширине кадра: «2160», «1080», «720», «576», «480»."""
    try:
        width = int(width or 0)
        height = int(height or 0)
    except Exception:
        return ''
    if width <= 0:
        return ''
    if width >= 3200:
        return '2160'
    if width >= 1800:
        return '1080'
    if width >= 1200:
        return '720'
    if width >= 900:
        return '576'
    if width >= 600:
        return '480'
    return ''


def for_ids(ids, site_url=''):
    """{номер раздачи: (ширина, высота)} - из кэша, чего нет - со страниц."""
    wanted = [str(x) for x in (ids or []) if str(x).strip()]
    if not wanted:
        return {}
    answer = {}
    missing = []
    for number in wanted:
        if number in _MEMO:
            if _MEMO[number]:
                answer[number] = _MEMO[number]
        else:
            missing.append(number)
    conn = _connect()
    if missing:
        stored = _stored(conn, missing)
        answer.update(stored)
        _MEMO.update(stored)
        missing = [x for x in missing if x not in stored]
    if missing and site_url:
        started = time.time()
        fetched = {}

        def one(number):
            left = BUDGET - (time.time() - started)
            if left <= 0:
                return number, None
            # таймаут запроса не больше остатка бюджета: начатые запросы раньше ждали по
            # 10 с каждый, и список открывался до 20 с (живая проверка 15.11.2026)
            return number, _frame_of(_get('%s/torrent/%s' % (site_url.rstrip('/'), number), left))

        try:
            if ThreadPoolExecutor is not None:
                with ThreadPoolExecutor(max_workers=WORKERS) as pool:
                    for number, frame in pool.map(one, missing):
                        if frame:
                            fetched[number] = frame
                        _MEMO[number] = frame or None
            else:
                for number in missing:
                    number, frame = one(number)
                    if frame:
                        fetched[number] = frame
                    _MEMO[number] = frame or None
        except Exception as exc:
            xbmc.log('[%s] release_tech: обход страниц прерван: %s' % (ADDON, exc),
                     xbmc.LOGDEBUG)
        answer.update(fetched)
        _store(conn, fetched)
        xbmc.log('[%s] release_tech: страниц запрошено %d, размер кадра нашёлся у %d, '
                 '%.1f с' % (ADDON, len(missing), len(fetched), time.time() - started),
                 xbmc.LOGINFO)
    if conn is not None:
        try:
            conn.close()
        except Exception:
            pass
    return answer
