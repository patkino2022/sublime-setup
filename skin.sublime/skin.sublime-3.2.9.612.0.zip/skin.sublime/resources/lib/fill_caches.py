# -*- coding: utf-8 -*-
"""Заполнить все кэши разом - по просьбе установщика, без «по фокусу».

Владелец 15.11.2026: «надо, чтобы все кеши строились сами в конце установщика без
"по фокусу"» и «сделай прогресс заполнения кешей в установщике». Свежая коробка
иначе строит фон канала, размытый постер, цвет подложки и картинки строки в момент,
когда на строку впервые приходит фокус (фон канала - 3,6-3,9 с вместо 0,36 с).

Установщик кладёт файл REQUEST; служба скина (vcl_service.main -> start) замечает его
и проходит этапы по очереди, записывая ход в STATUS (JSON), который установщик
показывает как прогресс:
  channels - ждёт, пока service.tvlink скачает плейлисты и проверит потоки;
  pvr      - фон и цвет подложки каждого канала;
  radio    - то же для радиоканалов (группа allradio); нет радио - пропуск;
  youtube  - снимки полос YouTube без ключа: тренды, «В эфире», «Новости»,
             «Чарты» и лента подписок (youtube_subs.refresh, без ключа - по входу,
             youtube_tvfeed). Стоит ДО lanes: сборщик обогащает ленту подписок,
             а rows кладёт картинки всех этих снимков в кэш;
  lanes    - ждёт, пока хабы соберут свои полосы (снимки widget_mirror перестали
             меняться);
  rows     - для каждой строки каждой полосы: размытый фон из постера, цвет
             подложки и картинки строки в кэше текстур Kodi (через /image/ его
             веб-сервера - так же, как Kodi кэширует показанную картинку);
  meta     - итоговый пакет метаданных строк сборщика (metadata_cache, ключ
             фильма): через поток прогрева службы (core.prewarm_model);
  state    - полосы «состояние» с главной (избранное, в процессе и т.п.): список
             у источника (mirror.fetch, снимок не пишется - он для них вреден),
             картинки строк в кэш текстур, пакет метаданных как в meta;
  folders  - папки сериалов главной (порядок home_series.json): сезоны, серии и
             кадры серий - в кэше дополнения и в кэше текстур.

Этапы meta..folders и radio/youtube добавлены 15.11.2026 (HANDOFF_2026-11-15,
п. 6: что ещё строилось по фокусу). У каждого свой предел времени: что не
успело, строится по фокусу, как раньше. Работа идёт по одной за раз (коробки
4 ГБ ARM), с выходом по остановке Kodi и с паузой, пока что-то играет.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcvfs

DATA = xbmcvfs.translatePath('special://profile/addon_data/skin.sublime/')
REQUEST = os.path.join(DATA, 'fill_caches.request')
# идёт заполнение кэшей: проход скина по каналам (pvr_background_warm) ждёт, чтобы не строить те
# же фоны вторым потоком одновременно (аудит 21.11.2026)
ACTIVE = [False]
STATUS = os.path.join(DATA, 'fill_caches.status.json')
MIRROR = os.path.join(DATA, 'widget_mirror')
TVLINK = xbmcvfs.translatePath('special://profile/addon_data/service.tvlink/status.json')
STAGES = ('channels', 'pvr', 'lanes', 'first', 'youtube', 'rows', 'meta', 'state', 'folders', 'radio')
LANES_QUIET = 60          # полосы собраны: снимки не менялись столько секунд
LANES_MAX = 15 * 60
LANES_ENRICH = 20          # столько секунд сборщик обогащает строки, дальше пишет как есть; остальное доделывает служба
                          # (было 90: на .20 17.11.2026 «Рекомендации» обогащались все 90 с до отметки ready)
CHANNELS_MAX = 3 * 60
CHANNEL_WORKERS = 3       # подложки каналов строятся в столько потоков (_channel_stage)
# Пределы новых этапов.
RADIO_MAX = 10 * 60
YOUTUBE_MAX = 5 * 60
SUBS_BUDGET = 180         # youtube_subs.refresh(budget=...)
META_MAX = 20 * 60
META_BACKLOG = 2          # заданий в очереди прогрева одновременно - не больше
STATE_MAX = 10 * 60
FOLDERS_MAX = 15 * 60
FOLDER_SHOWS = 20         # сериалов главной
FOLDER_SEASONS = 2        # последних сезонов у сериала
DRAIN_MAX = 3 * 60        # дождаться очереди прогрева в конце этапа
# Всё заполнение - не дольше 10 минут (владелец, 15.11.2026): этапы идут по важности для
# первого экрана, у каждого свой предел, но не дальше общего; не успевшее строится по фокусу.
# Установщик ждёт только то, что видно сразу: каналы, фоны ТВ, полосы и строки ПЕРВЫХ
# вкладок каждого хаба главного экрана (владелец 16.11.2026). Остальное - в фоне, после
# отметки ready, со своим пределом.
FIRST_MAX = 8 * 60
BACKGROUND_MAX = 30 * 60
NODES = 'special://profile/addon_data/skin.sublime/nodes/skin.sublime/'
_END = [0.0]
_STARTED = [0.0]   # начало текущего заполнения (полосы, собранные службой после него, не пересобираются)


def _until(seconds):
    return min(time.time() + seconds, _END[0] or time.time() + seconds)


FILMIX_SHOW = re.compile(r'plugin://plugin\.video\.filmix/(?:serials|multserials)/(\d+)-')


def _log(message):
    xbmc.log('[sublime fill caches] %s' % message, xbmc.LOGINFO)


class _Status(object):
    def __init__(self):
        self.data = {'started': int(time.time()), 'finished': False,
                     'stages': {s: {'state': 'wait', 'done': 0, 'total': 0} for s in STAGES}}

    def set(self, stage, state=None, done=None, total=None, note=None):
        item = self.data['stages'][stage]
        if state is not None:
            item['state'] = state
        if done is not None:
            item['done'] = done
        if total is not None:
            item['total'] = total
        if note is not None:
            item['note'] = note
        self.save()

    def save(self):
        self.data['updated'] = int(time.time())
        tmp = STATUS + '.tmp'
        try:
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(self.data, fh, ensure_ascii=False)
            os.replace(tmp, STATUS)
        except OSError:
            pass


def _image_cache(url):
    """Положить картинку в кэш текстур Kodi: веб-сервер Kodi отдаёт /image/<image://...>
    и при этом кэширует её так же, как показанную на экране."""
    if not url:
        return
    if not url.startswith('image://'):
        url = 'image://%s/' % urllib.parse.quote(url, safe='')
    try:
        req = urllib.request.Request('http://127.0.0.1:8080/image/' + urllib.parse.quote(url, safe=''))
        with urllib.request.urlopen(req, timeout=20) as answer:
            answer.read(1)
    except Exception:
        pass


def _quiet(monitor):
    """Ждать, пока что-то играет. False - Kodi останавливается или вышел срок окна
    (иначе включённое после установки ТВ держало бы этап, и отметка ready не ставилась)."""
    while xbmc.getCondVisibility('Player.HasMedia'):
        if time.time() >= (_END[0] or float('inf')):
            return False
        if monitor.waitForAbort(5):
            return False
    return not monitor.abortRequested()


def _art(row):
    art = row.get('art') or {}
    if isinstance(art, str):
        try:
            import ast
            art = ast.literal_eval(art)
        except Exception:
            art = {}
    return art if isinstance(art, dict) else {}


def _warm_row_art(row, seen):
    """Картинки строки - в кэш текстур Kodi, по одной и без повторов."""
    art = _art(row)
    for url in (art.get('thumb'), art.get('poster'), art.get('fanart'), art.get('landscape'),
                art.get('clearlogo')):
        if url and url not in seen:
            seen.add(url)
            _image_cache(url)
    return art


def _prewarm(monitor, local, deadline):
    """Модель строки - в поток прогрева метаданных, когда в его очереди есть место.
    Ответ core.prewarm_model ('queued', 'cached', 'skip', 'off') или '' - время вышло."""
    from resources.lib.sublime_helper import core
    while time.time() < deadline:
        if core.worker().prewarm_backlog() < META_BACKLOG:
            answer = core.prewarm_model(local)
            if answer != 'full':
                return answer
        if monitor.waitForAbort(0.5) or not _quiet(monitor):
            return ''
    return ''


def _drain(monitor, deadline):
    """Дождаться, пока поток прогрева доделает отданное (не дольше DRAIN_MAX)."""
    from resources.lib.sublime_helper import core
    until = min(deadline, time.time() + DRAIN_MAX)
    while time.time() < until and core.worker().prewarm_backlog():
        if monitor.waitForAbort(1):
            return


def _channels(monitor, st):
    if not os.path.isdir(os.path.dirname(TVLINK)):
        st.set('channels', 'skip')
        return
    st.set('channels', 'run', note='список каналов')
    deadline = _until(CHANNELS_MAX)
    while time.time() < deadline:
        try:
            with open(TVLINK, encoding='utf-8') as fh:
                tv = json.load(fh)
        except (OSError, ValueError):
            tv = {}
        st.set('channels', done=tv.get('channels', 0))
        # список собран service.tvlink после этого запуска и уже принят Kodi
        if tv.get('channels') and (tv.get('built') or 0) >= (tv.get('started') or 1)                 and xbmc.getCondVisibility('Pvr.HasTVChannels'):
            st.set('channels', 'done', total=tv.get('channels', 0))
            return
        if monitor.waitForAbort(1):          # было 5 с: лишние секунды после готового списка
            return
    st.set('channels', 'done', note='не дождались списка каналов')


def _channel_stage(monitor, st, stage, group, deadline=None):
    """Фон и цвет подложки каждого канала группы (как pvr_background_warm)."""
    from resources.lib import pvr_background_warm as warm
    from resources.lib.sublime_helper.poster_background import prepare_background_now, prepared_path
    icons = warm._channel_icons(group)
    if not icons and stage != 'pvr':
        st.set(stage, 'skip')
        return
    st.set(stage, 'run', 0, len(icons))

    def one(icon):
        try:
            if not prepared_path('pvr', icon):
                prepare_background_now('pvr', icon)
            warm.publish_by_name(icon)          # цвет считает он же (prepare_wash_color_now)
            # логотип канала Kodi 22 отдаёт как image://pvrchannel_tv@...: веб-сервер
            # Kodi такую схему не грузит (CreateLoader - unsupported protocol, 190 раз
            # за заполнение на .20), а на экране Kodi кэширует его сам
            if 'pvrchannel_' not in icon:
                _image_cache(icon)
        except Exception as exc:
            _log('канал %s: %s' % (icon[-50:], exc))

    # Подложка - размытие 2120x1400 и уменьшение, около секунды на канал на коробке; по
    # одному это минуты (владелец 17.11.2026: «кеши надо строить быстрее»). Pillow отпускает
    # GIL в фильтрах, поэтому несколько потоков на четырёх ядрах идут почти в разы быстрее;
    # одно ядро остаётся интерфейсу.
    from concurrent.futures import ThreadPoolExecutor
    done = 0
    with ThreadPoolExecutor(max_workers=CHANNEL_WORKERS) as pool:
        for start in range(0, len(icons), CHANNEL_WORKERS):
            if not _quiet(monitor):
                return
            if deadline and time.time() > deadline:
                st.set(stage, 'done', note='предел времени')
                return
            batch = icons[start:start + CHANNEL_WORKERS]
            list(pool.map(one, batch))
            done += len(batch)
            if done % 10 < CHANNEL_WORKERS or done == len(icons):
                st.set(stage, done=done)
    st.set(stage, 'done')


def _pvr(monitor, st):
    _channel_stage(monitor, st, 'pvr', 'alltv', _END[0])


def _radio(monitor, st):
    _channel_stage(monitor, st, 'radio', 'allradio', _until(RADIO_MAX))


def _youtube(monitor, st):
    """Снимки полос YouTube без ключа и ленты подписок - их же функциями обновления.
    Пустой ответ снимок не затирает (так устроены сами refresh/rows)."""
    from resources.lib.hub import youtube_inner, youtube_subs, youtube_trending
    deadline = _until(YOUTUBE_MAX)
    jobs = [('тренды', lambda: youtube_trending.refresh(force=True))]
    jobs += [(kind, (lambda k=kind: len(youtube_inner.rows(k) or [])))
             for kind in ('news', 'charts')]   # «В эфире» убрана (владелец 17.11.2026)
    jobs.append(('подписки', lambda: youtube_subs.refresh(
        cancel=lambda: monitor.abortRequested() or time.time() > deadline,
        budget=SUBS_BUDGET)[1]))
    st.set('youtube', 'run', 0, len(jobs))
    for i, (name, job) in enumerate(jobs, 1):
        if not _quiet(monitor):
            return
        if time.time() > deadline:
            st.set('youtube', 'done', note='предел времени')
            return
        try:
            _log('YouTube %s: строк %s' % (name, job()))
        except Exception as exc:
            _log('YouTube %s: %s' % (name, exc))
        st.set('youtube', done=i)
    # аватары каналов этих полос - заранее (значок в правом нижнем углу; без
    # ключа Data API дополнение YouTube их не знает - sublime_helper/youtube_channels)
    try:
        from resources.lib.sublime_helper import youtube_channels
        ids = [r.get('channel_id') for r in _rows() if 'youtube' in str(r.get('file') or '')]
        _log('YouTube каналы: аватаров найдено %d' % youtube_channels.prefetch(
            ids, cancel=lambda: monitor.abortRequested() or time.time() > deadline))
    except Exception as exc:
        _log('YouTube каналы: %s' % exc)
    # крупные обложки (фон 1920x1080 не из 480x360) - не дожидаясь сборщика
    try:
        from resources.lib.hub import mirror as _mirror
        _log('YouTube обложки: поднято до крупных %d' % _mirror.upgrade_youtube_art(
            cancel=lambda: monitor.abortRequested() or time.time() > deadline))
    except Exception as exc:
        _log('YouTube обложки: %s' % exc)
    st.set('youtube', 'done')


def _snapshots():
    out = {}
    try:
        for name in os.listdir(MIRROR):
            if name.endswith('.json'):
                out[name] = os.path.getmtime(os.path.join(MIRROR, name))
    except OSError:
        pass
    return out


def _lanes(monitor, st):
    st.set('lanes', 'run', note='сборка полос')
    # Сборщик хабов сам ждёт до 15 мин с прошлого прохода и уступает пульту; здесь он
    # запускается сразу, с поиском логотипов (иначе логотип добирается по фокусу).
    try:
        from resources.lib.hub import builder, mirror_wire
        from resources.lib.sublime_helper.core import logo_fetch_scope
        with builder._BUILD_LOCK:           # дождаться прохода службы, затем свой
            # снимки всех полос - быстро; обогащение после срока доделает служба
            builder.enrich_until(time.time() + LANES_ENRICH)
            # Пока заполнение ждало замка, служба хаба могла собрать те же полосы: на .20
            # 17.11.2026 её проход занял 90 с, и следом заполнение собирало их ещё раз.
            # Собранное после начала заполнения не трогаем
            from resources.lib.hub import mirror
            todo = [src for src in mirror_wire.sources()
                    if (mirror.stamp_of(src) or 0) < _STARTED[0]]
            try:
                with logo_fetch_scope(True):
                    builder.build_all(todo)
                    builder.build_ours()
            finally:
                builder.enrich_until(0)
            builder.top_up_meta()
        # Полосы собраны здесь же, под замком сборщика: ждать «тишины» снимков незачем.
        # Ожидание 60 с без изменений стоило 331 с простоя после сборки за 9 с, и первые
        # вкладки не успевали в свой срок (.20, 17.11.2026: этап lanes 430 с, first пропущен)
        st.set('lanes', 'done', done=len(_snapshots()), total=len(_snapshots()))
        return
    except Exception as exc:
        _log('сборка полос: %s' % exc)
    # сборка не прошла - ждём, пока полосы соберёт служба хаба
    deadline = _until(LANES_MAX)
    last, quiet_since = None, time.time()
    while time.time() < deadline:
        now = _snapshots()
        if now != last:
            last, quiet_since = now, time.time()
        st.set('lanes', done=len(now))
        if time.time() - quiet_since >= LANES_QUIET and now:
            break
        if monitor.waitForAbort(5):
            return
    st.set('lanes', 'done', total=len(last or {}))


def _first_tab_paths():
    """Пути первой вкладки каждого хаба (раскладка skinvariables-shortcut-*widgets.json)."""
    import glob
    try:
        import xbmcvfs
        folder = xbmcvfs.translatePath(NODES)
    except Exception:
        folder = xbmc.translatePath(NODES)
    paths = []
    files = {}
    # редактор вкладок скина пишет vclvariables-*, skinvariables-* - старые копии
    for prefix in ('skinvariables', 'vclvariables'):
        for name in glob.glob(os.path.join(folder, '%s-shortcut-*widgets.json' % prefix)):
            files[os.path.basename(name)[len(prefix):]] = name
    for key in sorted(files):
        if 'search' in key:
            continue
        try:
            with open(files[key], encoding='utf-8') as fh:
                data = json.load(fh) or []
            tabs = [t for t in data if isinstance(t, dict)
                    and str(t.get('disabled', '')).lower() != 'true']
        except Exception:
            continue
        path = tabs and (tabs[0].get('widget_path') or tabs[0].get('path'))
        if path:
            paths.append(str(path).replace('&amp;', '&'))
    return paths


def _first_rows():
    from resources.lib.hub import mirror
    rows = []
    for path in _first_tab_paths():
        try:
            if 'info=hub_trending' in path:
                from resources.lib.hub import youtube_trending
                youtube_trending.refresh()
                kept, _stamp = mirror.load(youtube_trending.SRC)
            elif 'info=hub_ytlane' in path:
                from resources.lib.hub import youtube_inner
                kind = re.search(r'kind=(\w+)', path)
                kept = youtube_inner.rows(kind.group(1)) if kind else []
            elif 'info=hub_subs' in path:
                from resources.lib.hub import youtube_subs
                kept = youtube_subs.stored_rows()
                if not kept:
                    youtube_subs.refresh(budget=60)
                    kept = youtube_subs.stored_rows()
            else:
                kept, _stamp = mirror.load(path)
        except Exception as exc:
            _log('первая вкладка %s: %s' % (path[:80], exc))
            kept = None
        rows.extend(kept or [])
    return rows


def _rows():
    rows = []
    for name in sorted(_snapshots()):
        try:
            with open(os.path.join(MIRROR, name), encoding='utf-8') as fh:
                rows.extend((json.load(fh) or {}).get('rows') or [])
        except (OSError, ValueError):
            continue
    return rows


def _first_stage(monitor, st):
    _rows_stage(monitor, st, 'first', _first_rows())


def _rows_stage(monitor, st, stage='rows', rows=None):
    from resources.lib.sublime_helper.poster_background import prepare_background_now, prepared_path
    from resources.lib.sublime_helper.image_wash import prepare_wash_color_now
    rows = _rows() if rows is None else rows
    st.set(stage, 'run', 0, len(rows))
    # два набора: картинки для кэша текстур и постеры для подложек. Был один, и
    # _warm_row_art клал в него постер раньше проверки - подложки строк не строились вовсе
    seen, seen_bg = set(), set()
    lock = threading.Lock()

    def one(row):
        art = _warm_row_art(row, seen)
        poster = art.get('poster') or art.get('thumb') or ''
        # логотип-название для роликов YouTube без своего clear logo (строится только по фокусу)
        if 'plugin.video.youtube' in str(row.get('file') or '') and not art.get('clearlogo'):
            try:
                from resources.lib.sublime_helper.title_logo import request_title_logo
                request_title_logo(str(row.get('label') or ''))
            except Exception as exc:
                _log('логотип %s: %s' % (str(row.get('label'))[:40], exc))
        if row.get('sublime'):
            # строку собрал сборщик (hub/builder): её подложка и цвет уже готовы и лежат в
            # строке - второй раз из постера не делаем (аудит 21.11.2026, ~1 с ЦП на строку)
            return
        with lock:
            fresh = bool(poster) and poster.startswith(('http://', 'https://')) and poster not in seen_bg
            if fresh:
                seen_bg.add(poster)
        if fresh:
            try:
                if not prepared_path('poster', poster):
                    prepare_background_now('poster', poster)
                prepare_wash_color_now(poster)
            except Exception as exc:
                _log('строка %s: %s' % (str(row.get('label'))[:40], exc))

    # подложка строки - загрузка постера и размытие, около секунды; по одной это минуты
    # (как у каналов, _channel_stage): несколько потоков, одно ядро остаётся интерфейсу
    from concurrent.futures import ThreadPoolExecutor
    done = 0
    with ThreadPoolExecutor(max_workers=CHANNEL_WORKERS) as pool:
        for start in range(0, len(rows), CHANNEL_WORKERS):
            if not _quiet(monitor):
                if not monitor.abortRequested():
                    st.set(stage, 'done', done, len(rows), note='предел времени - воспроизведение')
                return
            if time.time() > _END[0]:
                st.set(stage, 'done', done, len(rows), note='предел времени')
                return
            batch = rows[start:start + CHANNEL_WORKERS]
            list(pool.map(one, batch))
            done += len(batch)
            if done % 10 < CHANNEL_WORKERS or done == len(rows):
                st.set(stage, done=done)
    st.set(stage, 'done')


def _meta(monitor, st):
    """Итоговый пакет метаданных строк сборщика - заранее, под ключ фильма.
    Модель и ключ - те же, что у строки под курсором (core.row_model_from_snapshot)."""
    from resources.lib.sublime_helper.core import _identity_cache_id, row_model_from_snapshot
    deadline = _until(META_MAX)
    models, seen = [], set()
    for row in _rows():
        if row.get('sublime'):
            continue                    # собрана сборщиком - всё нужное экрану уже в строке
        model = row_model_from_snapshot(row)
        identity = _identity_cache_id(model) if model else ''
        if identity and identity not in seen:
            seen.add(identity)
            models.append(model)
    st.set('meta', 'run', 0, len(models))
    tally = {}
    for i, model in enumerate(models, 1):
        if not _quiet(monitor):
            return
        answer = _prewarm(monitor, model, deadline)
        if answer == 'off':
            st.set('meta', 'skip', note='метаданные выключены')
            return
        if not answer:
            if monitor.abortRequested():
                return
            st.set('meta', 'done', done=i - 1, note='предел времени')
            _log('пакеты метаданных: %s' % tally)
            return
        tally[answer] = tally.get(answer, 0) + 1
        if i % 5 == 0 or i == len(models):
            st.set('meta', done=i)
    _drain(monitor, deadline)
    _log('пакеты метаданных: %s' % tally)
    st.set('meta', 'done')


def _local(row):
    """Модель строки чужого списка - как у сборщика (builder._local_from_row), плюс
    сезон и серия: у серии свой ключ фильма (core._identity_cache_id)."""
    from resources.lib.hub.builder import _local_from_row
    local = _local_from_row(row)
    for key in ('season', 'episode'):
        try:
            value = int(row.get(key))
        except (TypeError, ValueError):
            value = -1
        if value >= 0:
            local[key] = value
    return local


def _state(monitor, st):
    """Полосы «состояние» с главной: свежий список у источника (mirror.fetch, без
    снимка), картинки строк и пакет метаданных - заранее."""
    from resources.lib.hub import mirror, service
    from resources.lib.hub.builder import _enrichable
    deadline = _until(STATE_MAX)
    sources = sorted(src for src in service._live_sources()
                     if mirror.category(src) == 'состояние')
    rows = []
    for src in sources:
        if not _quiet(monitor) or time.time() > deadline:
            break
        got = mirror.content_rows(mirror.fetch(src))
        _log('состояние %s: строк %d' % (src[:80], len(got)))
        rows.extend(got)
    if not rows:
        st.set('state', 'skip' if not sources else 'done')
        return
    st.set('state', 'run', 0, len(rows))
    seen, queued, films = set(), 0, set()
    for i, row in enumerate(rows, 1):
        if not _quiet(monitor):
            if not monitor.abortRequested():
                st.set('state', 'done', note='предел времени - воспроизведение')
            return
        if time.time() > deadline:
            st.set('state', 'done', note='предел времени')
            return
        _warm_row_art(row, seen)
        if _enrichable(row):
            local = _local(row)
            try:
                from resources.lib.sublime_helper.core import _identity_cache_id
                ident = _identity_cache_id(local) or ''
            except Exception:
                ident = ''
            if ident and ident in films:
                continue                    # тот же фильм в «Избранном» и «В процессе»
            films.add(ident)
            if _prewarm(monitor, local, deadline) == 'queued':
                queued += 1
        if i % 5 == 0 or i == len(rows):
            st.set('state', done=i)
    _drain(monitor, deadline)
    _log('состояние: строк %d, пакетов в прогрев %d' % (len(rows), queued))
    st.set('state', 'done')


def _shows():
    """Пути сериалов главной: порядок - home_series.json службы хаба (тот же список
    прогревает и Filmix), затем сериалы HDrezka из снимков."""
    from resources.lib.hub import service
    by_post, extra = {}, []
    for row in _rows():
        path = str(row.get('file') or '')
        hit = FILMIX_SHOW.search(path)
        if hit:
            by_post.setdefault(hit.group(1), path)
        elif (path.startswith('plugin://plugin.video.hdrezka.tv/') and 'mode=show' in path
              and str(row.get('filetype') or '') == 'directory' and path not in extra):
            extra.append(path)
    try:
        order = service._write_home_series()
    except Exception as exc:
        _log('home_series: %s' % exc)
        order = list(by_post)
    shows = [by_post[pid] for pid in order if pid in by_post]
    return (shows + extra)[:FOLDER_SHOWS]


def _season_no(row):
    try:
        return int(row.get('season'))
    except (TypeError, ValueError):
        return -1


def _folders(monitor, st):
    """Сезоны, серии и кадры серий сериалов главной: папки спрашиваются у дополнения
    (оно кладёт их в свой кэш), картинки - в кэш текстур. Последние FOLDER_SEASONS
    сезонов каждого сериала."""
    from resources.lib.hub import mirror
    deadline = _until(FOLDERS_MAX)
    shows = _shows()
    if not shows:
        st.set('folders', 'skip')
        return
    st.set('folders', 'run', 0, len(shows))
    seen = set()
    for i, show in enumerate(shows, 1):
        if not _quiet(monitor):
            return
        if time.time() > deadline:
            st.set('folders', 'done', note='предел времени')
            return
        try:
            top = mirror.content_rows(mirror.fetch(show))
            seasons = [r for r in top if str(r.get('filetype') or '') == 'directory']
            episodes = [r for r in top if str(r.get('filetype') or '') != 'directory']
            seasons.sort(key=_season_no, reverse=True)
            for row in seasons:
                _warm_row_art(row, seen)
            for season in seasons[:FOLDER_SEASONS]:
                if not _quiet(monitor) or time.time() > deadline:
                    break
                path = str(season.get('file') or '')
                if path:
                    episodes.extend(r for r in mirror.content_rows(mirror.fetch(path))
                                    if str(r.get('filetype') or '') != 'directory')
            for row in episodes:
                if not _quiet(monitor) or time.time() > deadline:
                    break
                _warm_row_art(row, seen)
        except Exception as exc:
            _log('папка %s: %s' % (show[:80], exc))
        st.set('folders', done=i)
    st.set('folders', 'done')


def _signed_in():
    """{дополнение: выполнен ли вход} - Filmix, HDrezka, YouTube."""
    out = {}
    for aid, setting in (('plugin.video.filmix', 'user_login'), ('plugin.video.hdrezka.tv', 'username')):
        try:
            if xbmc.getCondVisibility('System.HasAddon(%s)' % aid):
                import xbmcaddon
                out[aid] = bool(xbmcaddon.Addon(aid).getSetting(setting))
        except Exception:
            pass
    try:
        from resources.lib.hub import youtube_tvfeed
        out['plugin.video.youtube'] = youtube_tvfeed.signed_in()
    except Exception:
        pass
    return out


def _login_watch(state):
    """Выполнен вход в аккаунт - кэши источника пересобираются тем же заполнением, что в
    конце установки."""
    now = _signed_in()
    before = state.get('logins')
    state['logins'] = now
    if before is None:
        return
    joined = [aid for aid, yes in now.items() if yes and not before.get(aid)]
    if joined and not os.path.exists(REQUEST):
        _log('вход в аккаунт (%s) - пересобираю кэши' % ', '.join(joined))
        try:
            open(REQUEST, 'w').close()
        except OSError:
            pass


def _run(monitor):
    watch = {'next': 0.0}
    while not monitor.abortRequested():
        if time.time() >= watch['next']:
            watch['next'] = time.time() + 60
            try:
                _login_watch(watch)
            except Exception as exc:
                _log('проверка входа: %s' % exc)
        if not os.path.exists(REQUEST):
            if monitor.waitForAbort(1):      # было 5 с: просьба установщика ждала до 5 с
                return
            continue
        try:
            os.remove(REQUEST)
        except OSError:
            pass
        st = _Status()
        st.save()
        ACTIVE[0] = True
        started = time.time()
        _END[0] = started + FIRST_MAX
        _STARTED[0] = started
        _log('начато')
        for stage, fn in (('channels', _channels), ('pvr', _pvr), ('lanes', _lanes),
                          ('first', _first_stage), ('youtube', _youtube), ('rows', _rows_stage),
                          ('meta', _meta), ('state', _state), ('folders', _folders), ('radio', _radio)):
            if stage not in ('channels', 'pvr', 'lanes', 'first') and not st.data.get('ready'):
                # первые вкладки готовы - установщик дальше не ждёт, остальное идёт в фоне
                st.data['ready'] = True
                st.data['ready_seconds'] = int(time.time() - started)
                st.save()
                _log('первые вкладки готовы за %d с' % st.data['ready_seconds'])
                _END[0] = time.time() + BACKGROUND_MAX
            if time.time() >= _END[0]:
                st.set(stage, 'skip', note='предел времени - по фокусу')
                continue
            stage_started = time.time()
            try:
                fn(monitor, st)
            except Exception as exc:
                st.set(stage, 'error', note=str(exc)[:200])
                _log('%s: %s' % (stage, exc))
            if stage == 'pvr':
                ACTIVE[0] = False               # каналы пройдены - проходу скина снова можно
            if monitor.abortRequested():
                return
            _log('этап %s: %d с' % (stage, time.time() - stage_started))
        ACTIVE[0] = False
        st.data['finished'] = True
        st.data['seconds'] = int(time.time() - started)
        st.save()
        _log('готово за %d с' % st.data['seconds'])


def start():
    thread = threading.Thread(target=_run, args=(xbmc.Monitor(),), name='SublimeFillCaches')
    thread.daemon = True
    thread.start()
    return thread
