# -*- coding: utf-8 -*-
"""Автозапуск мастера: сразу после «Установить из файла zip» (Kodi запускает службу нового
дополнения) и при следующих запусках Kodi - пока установка не завершена. Потом молчит;
запустить снова можно из «Программ»."""
import os
import sys

import xbmc
import xbmcvfs

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'lib'))

DONE = xbmcvfs.translatePath('special://profile/addon_data/script.sublime.setup/done')

if not os.path.exists(DONE):
    mon = xbmc.Monitor()
    # дождаться, пока Kodi покажет главный экран (при запуске Kodi) - диалоги поверх загрузки не видны
    while not mon.abortRequested() and xbmc.getCondVisibility('Window.IsActive(startup)'):
        mon.waitForAbort(1)
    if not mon.waitForAbort(3):
        from wizard import main
        main()
