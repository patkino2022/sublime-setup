# -*- coding: utf-8 -*-
"""Settings for the hub, kept in one JSON file in the skin's own data.

The lanes and the recommendations used to live in plugin.video.watchhub, which
had a settings dialog of its own. Inside the skin there is no add-on settings
UI to inherit, and building one in skin XML is a separate job - so the values
live in a plain file that the skin reads and that a settings screen can write
later. The defaults below are the ones the boxes were actually running with, so
nothing changes on the first read.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import time

import xbmc
import xbmcvfs

CONFIG_URI = 'special://profile/addon_data/skin.sublime/hub_config.json'

DEFAULTS = {
    'auto_refresh': True,
    # A full rebuild reads the provider's whole catalogue - 12-17 thousand posts,
    # measured at 30-80 s and ~120% CPU. It used to run every hour because it was
    # the only thing that kept the lanes fresh. It is not any more: the top-up
    # merges the provider's own first page every 90 s and the widget tops up on
    # request. The rebuild now only has to re-sort the tail of the catalogue, and
    # six hours is plenty - on the 4 GB box the hourly pass was pushing it into
    # swap (383 MB in swap, kswapd at 58% CPU, measured on .30).
    'refresh_hours': 6,
    'widget_size': 50,
    # Off. The store answers fast (YouTube's subscriptions 5.99 s -> 0.64 s
    # measured on .20), but what it hands back is not yet the widget the owner
    # configured: the add-on's own ordering is lost and its navigation rows
    # («Следующая страница») are served as if they were videos. Until the stored
    # rows are a faithful copy of that widget, this stays off and the widgets go
    # straight to their add-on as before. See hub/mirror.py.
    # Serve other add-ons' widgets from our own store instead of asking them on
    # every load. Verified row for row against the add-on's own answer on .20 -
    # same rows, same order, no navigation rows - and warm: YouTube's
    # subscriptions 9.50 s -> 0.41 s, its recommendations 1.11 s -> 0.47 s. Our
    # own lanes are built the same way and need no switch: their route is ours.
    'mirror_widgets': True,
    # К каким дополнениям это применяется: список через запятую или «*» - все
    # каталоги. Сначала здесь стоял один YouTube, потому что первый заход
    # зеркалил всё разом и сломал строку рекомендаций. Сломал он её не широтой
    # охвата, а тем, что считал служебной любую папку; это исправлено и закрыто
    # проверками в tools/test_mirror.py. Теперь решает природа списка
    # (hub/mirror.py, category): каталог зеркалим, «избранное» и телегид - нет.
    # Пустая строка по-прежнему значит «ничего», а не «всё».
    'mirror_addons': '*',
    'exclude_watched': True,
    'preferred_genres': '',
    'blocked_genres': '',
    'excluded_countries': '',
    'min_rating': '',
    'min_year': '',
    'prefer_acclaimed': True,
    'diversity': True,
    'fresh_percent': 20,
    'filter_lanes': False,
    # Where the hub's materials live: 'local' keeps them on this box only,
    # 'server' uses the HTTP sync server, 'folder' uses any path Kodi's VFS can
    # reach - a share, FTP, or a plain directory. See shared_store.py for what
    # each transport can and cannot do.
    'state_location': 'local',
    'state_path': '',
    'sync_enabled': False,
    'sync_url': 'http://127.0.0.1:8090/watch/',
    'sync_token': '',
    'sync_interval_minutes': 10,
    'sync_timeout': 30,
    'video_addon_id': 'plugin.video.filmix',
    'movies_catalog_path': '/movies/',
    'shows_catalog_path': '/serials/',
    'candidate_pages': 5,
    'progress_interval': 30,
}

_CACHE = {'values': None, 'stamp': 0.0, 'mtime': 0.0}
_TTL = 5.0


def log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('[sublime hub] %s' % message, level)
    except Exception:
        pass


# Остановка Kodi. До 30.08.2026 весь пакет hub о ней не знал: ни
# abortRequested, ни waitForAbort, ни Monitor не встречались в нём ни разу.
#
# Kodi даёт скрипту 5 секунд и пишет «script didn't stop in 5 seconds - let's
# kill it», а kodi.service ждёт 30 (TimeoutStopSec) и бьёт SIGKILL. Работа же
# здесь длинная: сборка строки ходит в сеть, ждёт цвет до двух секунд, а
# shared_store.acquire_lock по умолчанию ждёт шесть - и всё это через
# xbmc.sleep, который досыпает до конца, что бы ни происходило. В журнале это
# видно прямо: строки [sublime metadata] шли ПОСЛЕ «Unloaded skin». 05.08.2026
# на <коробка> остановка так и не завершилась, и коробка осталась без
# интерфейса.
#
# Монитор один на весь пакет: xbmc.Monitor() в горячем цикле - лишний объект на
# каждую строку.
_MONITOR = None


def monitor():
    global _MONITOR
    if _MONITOR is None:
        _MONITOR = xbmc.Monitor()
    return _MONITOR


def stopping():
    """Kodi просят остановиться - бросаем начатое немедленно."""
    try:
        return monitor().abortRequested()
    except Exception:
        return False


def pause(seconds):
    """Пауза, которая кончается досрочно при остановке. Замена xbmc.sleep.

    Возвращает True, если Kodi останавливают: вызывающий должен выйти, а не
    продолжать со следующей итерации.
    """
    try:
        return monitor().waitForAbort(seconds)
    except Exception:
        xbmc.sleep(int(seconds * 1000))
        return False


def _path():
    return xbmcvfs.translatePath(CONFIG_URI)


def _load():
    """Read the file at most every few seconds, and again after it changes."""
    path = _path()
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        mtime = 0.0
    now = time.time()
    cached = _CACHE['values']
    if (cached is not None and now - _CACHE['stamp'] < _TTL
            and mtime == _CACHE['mtime']):
        return cached
    values = dict(DEFAULTS)
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            stored = json.load(handle)
        if isinstance(stored, dict):
            values.update(stored)
    except FileNotFoundError:
        pass
    except Exception as exc:
        log('настройки не прочитаны (%s), беру значения по умолчанию' % exc,
            xbmc.LOGWARNING)
    _CACHE.update({'values': values, 'stamp': now, 'mtime': mtime})
    return values


def values():
    """Every setting with its current value - what a settings screen lists."""
    return dict(_load())


def get_str(key, default=''):
    value = _load().get(key, DEFAULTS.get(key, default))
    return '' if value is None else str(value)


def get_int(key, default=0):
    try:
        return int(float(str(_load().get(key, DEFAULTS.get(key, default))).strip()))
    except (TypeError, ValueError):
        return default




def get_bool(key, default=False):
    value = _load().get(key, DEFAULTS.get(key, default))
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ('true', '1', 'yes')


def set_value(key, value):
    """Write one setting back, preserving everything else in the file."""
    path = _path()
    values = dict(_load())
    values[key] = value
    folder = os.path.dirname(path)
    try:
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        temp = path + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump(values, handle, ensure_ascii=False, indent=2,
                      sort_keys=True)
        os.replace(temp, path)
    except Exception as exc:
        log('настройка %s не записана: %s' % (key, exc), xbmc.LOGWARNING)
        return False
    _CACHE.update({'values': None, 'stamp': 0.0, 'mtime': 0.0})
    return True


