# -*- coding: utf-8 -*-
"""Категория виджета: Фильмы / Сериалы / ТВ / Видео / Другое.

ЗАЧЕМ

Скин до сих пор угадывал природу каждой СТРОКИ: смотрел путь, содержимое
контейнера, наличие номера поста, признаки PVR и YouTube. Угадывание стоит
дорого и иногда ошибается. Замер на .30 07.09.2026: такт службы упирался в
прогрев виджета на 1050-1209 мс, а в журнале стояло «accepted=0
skipped=no_evidence:2» - служба прочитала две строки по ~80 параметрических
метк каждая, чтобы выяснить, что опознавать в них нечего. Для виджета
подписок YouTube или групп каналов PVR это известно заранее - по самому
виджету, без чтения строк.

Владелец предложил (07.09.2026): «присваивать вручную всем виджетам в
настройках скина категории - Фильмы/Сериалы/ТВ/Видео/Другие. Чтобы скин не
ошибался в автоопределении. Возможно, это что-то убыстрит».

ЧТО ЭТО ДАЁТ

  * `warmable()` - прогрев не читает строки виджетов ТВ, Видео и Другое вовсе.
  * `enrichable()` - строки таких виджетов не отправляются к поставщикам
    (TMDb, Кинопоиск): у канала PVR и ролика YouTube там нечего искать.
  * категория виджета известна ДО первой строки, а не после её разбора.

КАК ЗАДАЁТСЯ

В настройках самого виджета - пункт «Категория» рядом с «Порядком сортировки»
и «Пределом строк» (Dialog_DialogShortcuts.xml, свойство widget_kind). Так
распорядился владелец 08.09.2026: «В настройках главного экрана в пункте
виджеты у каждого должна быть выбрана категория. И всё. Всё остальное -
согласно выбранной категории.»

Источник ровно один - раскладка виджета. Отдельного файла категорий и
отдельного экрана назначения больше нет: два источника расходились бы, а
выбор владельца должен быть один. Пока выбора нет, работают правила по
умолчанию ниже - они описывают именно этот дом: PVR - телевидение, всё из
дополнения YouTube - видео, наши полосы фильмов и сериалов - по имени полосы,
списки жанров и стран Filmix - «Другое» (там нечего опознавать).
"""
from __future__ import absolute_import, unicode_literals

import glob
import io
import json
import os
import time

import xbmcvfs

from .config import log

KINDS = ('movies', 'shows', 'tv', 'video', 'other')
KIND_LABELS = {
    'movies': 'Фильмы',
    'shows': 'Сериалы',
    'tv': 'ТВ',
    'video': 'Видео',
    'other': 'Другое',
}


# Порядок важен: первое подходящее правило и решает. Ключ - начало пути или
# любой его кусок (проверяется и то, и другое).
DEFAULT_RULES = (
    ('pvr://', 'tv'),
    ('plugin://plugin.video.youtube/', 'video'),
    ('plugin://skin.sublime/?info=hub_subs', 'video'),
    ('plugin://skin.sublime/?info=hub_trending', 'video'),
    ('info=hub_lane&name=new_movies', 'movies'),
    ('info=hub_lane&name=top_movies', 'movies'),
    ('info=hub_lane&name=ru_movies', 'movies'),
    ('info=hub_widget&category=movies', 'movies'),
    ('info=hub_lane&name=new_shows', 'shows'),
    ('info=hub_lane&name=top_shows', 'shows'),
    ('info=hub_lane&name=ru_shows', 'shows'),
    ('info=hub_widget&category=shows', 'shows'),
    # Поисковый виджет «Youtube» (searchwidgets: DefaultSearch-Youtube).
    # Проверено на .30 08.09.2026 по самой раскладке. У двух других
    # поисковых виджетов - «Фильмы и сериалы» (filmix/search) и
    # «Торренты» (RuTor) - правила НЕТ намеренно: там смесь фильмов и
    # сериалов, им нужна «Авто», иначе мы запретили бы им обогащение.
    ('defaultsearch-youtube', 'video'),
    ('plugin://plugin.video.filmix/genres_movies', 'other'),
    ('plugin://plugin.video.filmix/genres_serials', 'other'),
    ('plugin://plugin.video.filmix/countries_movies', 'other'),
    ('plugin://plugin.video.filmix/countries_serials', 'other'),
    ('plugin://plugin.video.filmix/deferred', 'movies'),
    ('plugin://plugin.video.filmix/favorites', 'shows'),
    ('plugin://plugin.video.filmix/serials', 'shows'),
    ('plugin://plugin.video.filmix/movies', 'movies'),
)

_CACHE = {'stamp': 0.0, 'rules': None}


LAYOUT = 'special://profile/addon_data/skin.sublime/nodes/skin.sublime/'


def _layout_files():
    """Файлы раскладки виджетов - там, где владелец их и настраивает."""
    try:
        base = xbmcvfs.translatePath(LAYOUT)
    except Exception:
        return []
    try:
        # Именно все json, а не «*widgets.json». Файлы раскладки называются
        # vclvariables-shortcut-<меню>.json (shortcuts/futils.py, FILE_PREFIX),
        # то есть под старый образец попадал ОДИН файл - поисковых виджетов, а
        # главное меню не читалось вовсе. Найдено 08.09.2026 при разборе
        # вопроса владельца про поиск; на боксе не проверено (сеть лежит) -
        # правило взято из кода, который эти файлы и создаёт.
        # Только файлы виджетов, и только текущего вида имени: рядом лежат
        # старые копии `skinvariables-shortcut-*` того же содержимого (проверено
        # на .30 08.09.2026), и читать обе пары незачем.
        return sorted(glob.glob(os.path.join(base, 'vclvariables-shortcut-*widgets.json')))
    except Exception:
        return []


def load(force=False):
    """Категории, выбранные владельцем В НАСТРОЙКАХ ВИДЖЕТА.

    08.09.2026 владелец: «В настройках главного экрана в пункте виджеты у
    каждого должна быть выбрана категория. И всё. Всё остальное - согласно
    выбранной категории.» Поэтому источник один - свойство widget_kind в
    раскладке виджета (Dialog_DialogShortcuts.xml, пункт «Категория»,
    do_edit&&widget_kind). Отдельного файла категорий больше нет: два
    источника расходились бы, а выбор владельца должен быть один.

    Читается один раз и перечитывается, когда раскладка изменилась.
    """
    # Раскладку проверяем не чаще раза в 2 с: выдача полосы спрашивала вид у каждой из 50 строк, и
    # каждый раз шёл поиск файлов и stat (40 мс на полосу, профиль .30, 22.11.2026)
    now = time.time()
    if not force and _CACHE['rules'] is not None and now - _CACHE.get('checked_at', 0.0) < 2.0:
        return _CACHE['rules']
    _CACHE['checked_at'] = now
    files = _layout_files()
    # В отпечаток входит и размер: по одному времени правка в ту же секунду
    # осталась бы незамеченной, и выбор владельца применился бы не сразу
    # (офлайн-проверка это и поймала 08.09.2026).
    marks = []
    for path in files:
        try:
            info = os.stat(path)
            marks.append((path, info.st_mtime, info.st_size))
        except OSError:
            marks.append((path, 0.0, 0))
    stamp = tuple(marks)
    if not force and _CACHE['rules'] is not None and stamp == _CACHE['stamp']:
        return _CACHE['rules']
    rules = {}
    for path in files:
        try:
            with io.open(path, encoding='utf-8') as handle:
                data = json.load(handle)
        except Exception as exc:
            log('раскладка виджетов не прочитана (%s): %s' % (os.path.basename(path), exc))
            continue
        items = data if isinstance(data, list) else (data.get('items') or [])
        for item in items:
            if not isinstance(item, dict):
                continue
            target = str(item.get('widget_path') or item.get('path') or '').strip()
            kind = str(item.get('widget_kind') or '').strip().lower()
            if target and kind in KINDS:
                rules[target] = kind
    _CACHE['rules'] = rules
    _CACHE['stamp'] = stamp
    return rules


def kind_of(path):
    """Категория виджета или строки. Пусто - неизвестно, решает угадывание."""
    text = str(path or '').strip()
    if not text:
        return ''
    lowered = text.lower()
    rules = load()
    if text in rules:
        return rules[text]
    for key, value in rules.items():
        if key and key.lower() in lowered:
            return value
    for key, value in DEFAULT_RULES:
        # Ключи сравниваются со строчным путём, поэтому и сами приводятся к
        # нижнему регистру: у RuTor в идентификаторе заглавные буквы, и правило
        # «plugin://plugin.video.RuTor» не совпадало ни с чем.
        if key.lower() in lowered:
            return value
    return ''


def enrichable(path):
    """Стоит ли искать эту строку у поставщиков (TMDb, Кинопоиск и прочие)."""
    return kind_of(path) not in ('tv', 'video', 'other')


def warmable(path):
    """Стоит ли прогревать этот виджет заранее."""
    return kind_of(path) in ('movies', 'shows', '')
