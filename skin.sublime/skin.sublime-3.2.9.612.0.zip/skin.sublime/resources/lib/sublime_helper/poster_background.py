# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Build high-quality blurred fallback textures from poster and PVR artwork.

Poster fallbacks are rendered on a 4K intermediate canvas, blurred slightly and
then downsampled to 1080p. PVR picons use the same supersampling strategy on a
transparent 2x canvas. Only the large background fallback is processed; widget
card artwork is untouched.
"""

import hashlib
import io
import os
import re
import threading
import time
from collections import OrderedDict
from urllib.parse import unquote

import xbmc
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

_CACHE_URI = 'special://profile/addon_data/skin.sublime/fallback_backgrounds_v2/'
# Промежуточного холста 4K больше нет. Он существовал ради гладкого размытия,
# но после размытия и уменьшения разницы не остаётся: измерено на настоящих
# картинках с коробки - средняя разница яркости 0.5-0.7 из 255, то есть её не
# видно, а стоил он 0.63 с против 0.13 с на файл. На коробке это минуты работы
# процессора на каждую пересборку и лишние доли секунды на каждой строке,
# которую владелец открывает первым.
_POSTER_WORK_W = 1920
_POSTER_WORK_H = 1080
_POSTER_FINAL_W = 1920
_POSTER_FINAL_H = 1080
_PICON_WORK_W = 2120
_PICON_WORK_H = 1400
_PICON_FINAL_W = 1060
_PICON_FINAL_H = 700
# Must match the visible 1105 x 730 poster fallback geometry.
_VISIBLE_RATIO = 1105.0 / 730.0
# Радиус пересчитан под холст 1080p: 2.2 на 4K - это те же 1.1 здесь.
_POSTER_BLUR_RADIUS = 1.1
_PICON_BLUR_RADIUS = 2.0
_RETRY_SECONDS = 90.0
_MAX_MEMORY_RESULTS = 128
_MAX_MEMORY_FAILURES = 64
# Measured 2026-08-07: the live cache on .20 held 162 MB against this limit, so
# every newly prepared background evicted one the next scroll needed again and
# had to be regenerated. While a file is missing the publisher reports
# cached_only=yes and shows nothing, which reads as backgrounds flickering in and
# out while scrolling. Entries average 430 KB, /storage has 37 GB free, and the
# 45-day age prune below still applies.
_MAX_DISK_BYTES = 512 * 1024 * 1024
_MAX_DISK_AGE = 45 * 86400
_PRUNE_INTERVAL = 6 * 3600
_ALGO_VERSION = 'v5-cover-1080'
# Файлы прошлой версии алгоритма НЕ удаляются при смене версии, и это не
# небрежность. 2026-08-29 такая уборка снесла на .20 разом 517 МБ готовых
# фонов, пока владелец смотрел телевизор: сборщик при активном пользователе
# стоит в стороне, новые файлы появлялись по одному, и на экране это было
# «у фильма нет фона», «фон мигает», «опять запасной фон». Старые файлы
# больше никто не запросит - их имена содержат версию, - поэтому они просто
# доживают до возрастной чистки, а экран всё это время не пустеет.

_LOCK = threading.RLock()
_EVENT = threading.Event()
_LATEST_JOB = None
_WORKER = None
_RESULTS = OrderedDict()
_FAILURES = OrderedDict()
_LAST_PRUNE = 0.0


def _log(message, level=xbmc.LOGDEBUG):
    try:
        xbmc.log('[sublime fallback texture] %s' % message, level)
    except Exception:
        pass


def _translate(path):
    if not path:
        return ''
    try:
        return xbmcvfs.translatePath(path) if xbmcvfs else path
    except Exception:
        try:
            return xbmc.translatePath(path)
        except Exception:
            return path


def _exists(path):
    try:
        if xbmcvfs:
            return bool(path and xbmcvfs.exists(path))
        return bool(path and os.path.exists(_translate(path)))
    except Exception:
        return False


def _ensure_cache():
    try:
        if xbmcvfs:
            if not xbmcvfs.exists(_CACHE_URI):
                xbmcvfs.mkdirs(_CACHE_URI)
        else:
            os.makedirs(_translate(_CACHE_URI), exist_ok=True)
    except Exception:
        pass
    return _CACHE_URI


def _md5(value):
    return hashlib.md5(str(value or '').encode('utf-8', errors='surrogatepass')).hexdigest()


def _normalize_fallback_art_url(value):
    value = str(value or '').strip()
    if not value:
        return ''
    path, sep, suffix = value.partition('|')
    path = path.strip()
    low = path.lower()
    if not path:
        return ''
    if low.startswith(('http://', 'https://', 'special://', 'resource://', 'plugin://',
                       'pvr://', 'smb://', 'nfs://', 'file://', 'image://')):
        fixed = path
    elif low.startswith('//'):
        fixed = 'https:' + path
    elif low.startswith('/image.tmdb.org/'):
        fixed = 'https:/' + path
    elif low.startswith('image.tmdb.org/'):
        fixed = 'https://' + path
    elif re.match(r'^/?s/\d+/', low, re.IGNORECASE) or low.startswith(('s/', '/s/')):
        fixed = 'http://filmixapp.vip/' + path.lstrip('/')
    elif low.startswith(('/posters/', '/thumbs/', '/uploads/')):
        fixed = 'http://filmixapp.vip' + path
    elif low.startswith(('posters/', 'thumbs/', 'uploads/')):
        fixed = 'http://filmixapp.vip/' + path.lstrip('/')
    elif re.match(r'^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}(?::\d+)?/', low, re.IGNORECASE):
        fixed = 'https://' + path
    else:
        fixed = path
    return fixed + (sep + suffix if sep else '')


def _unwrap_image_url(source):
    value = str(source or '').strip()
    if not value:
        return ''
    for _ in range(2):
        low = value.lower()
        if low.startswith('image://'):
            value = unquote(value[8:])
            if value.endswith('/'):
                value = value[:-1]
            continue
        changed = False
        for scheme in ('http://', 'https://', 'special://', 'smb://', 'nfs://'):
            marker = '@' + scheme
            index = low.find(marker)
            if index >= 0:
                value = value[index + 1:]
                changed = True
                break
        if not changed:
            break
    return _normalize_fallback_art_url(value)


# Source-agnostic "original size" URL upgrade rules.
# Each rule: (match_substrings, [(compiled_regex, replacement), ...]).
# A rule fires when ANY of its match_substrings is present in the lowercased URL.
# Rules for unknown hosts simply never match, so adding a new source plugin only
# means appending an entry here (or registering one) -- no buried per-source literal.
# The first two entries reproduce the previous TMDb + Filmix behaviour exactly.
_ORIGINAL_URL_RULES = (
    (('image.tmdb.org/t/p/',), (
        (re.compile(r'/(?:w92|w154|w185|w342|w500|w780|h632|w1280|original)/', re.IGNORECASE), '/original/'),
    )),
    (('filmix', '/thumbs/'), (
        (re.compile(r'/thumbs/(?:w\d+|h\d+)/', re.IGNORECASE), '/orig/'),
        (re.compile(r'/thumbs/w220(?=/|$)', re.IGNORECASE), '/orig'),
    )),
)


def _upgrade_original_url(source):
    """Prefer known original-size URL forms without touching unknown hosts."""
    value = _unwrap_image_url(source)
    if not value:
        return ''
    path, separator, headers = value.partition('|')
    low = path.lower()
    for match_substrings, substitutions in _ORIGINAL_URL_RULES:
        if any(token in low for token in match_substrings):
            for pattern, replacement in substitutions:
                path = pattern.sub(replacement, path)
    return path + (separator + headers if separator else '')


_TVLINK_LOGO = re.compile(r'127\.0\.0\.1:2020/logo/([0-9A-Za-z_]+)\.png', re.I)
_TVLINK_LOGOS = 'special://profile/addon_data/service.tvlink/logos/'
_TVLINK_GROUP_LOGOS = 'special://home/addons/service.tvlink/resources/group_logos/'
_FILE_MD5 = {}


def tvlink_logo_file(source):
    """Файл логотипа канала tvlink на коробке для адреса его логотипа (в любом виде:
    http://127.0.0.1:2020/logo/ID.png?v=..., pvrchannel_tv@..., image://...), иначе ''."""
    text = str(source or '')
    for _ in range(2):
        text = unquote(text)
    m = _TVLINK_LOGO.search(text)
    if not m:
        return ''
    cid = m.group(1).upper()
    if cid.startswith('GRP_'):
        path = _translate(_TVLINK_GROUP_LOGOS + cid[4:].lower() + '.png')
    else:
        path = _translate(_TVLINK_LOGOS + cid + '.png')
    return path if path and os.path.isfile(path) else ''


def file_md5(path):
    stat = os.stat(path)
    key = (path, getattr(stat, 'st_mtime_ns', int(stat.st_mtime * 1000000000)), stat.st_size)
    value = _FILE_MD5.get(key)
    if value is None:
        with open(path, 'rb') as fh:
            value = hashlib.md5(fh.read()).hexdigest()
        if len(_FILE_MD5) > 4096:
            _FILE_MD5.clear()
        _FILE_MD5[key] = value
    return value


def tvlink_identity(path, size_tag=None):
    """Ключ подложки логотипа канала - по содержимому файла, а не по адресу: метка ?v= в
    адресе своя на каждой коробке, и готовые подложки из установщика (собраны на ПК тем же
    кодом) иначе не подошли бы ни к одной (владелец, 17.11.2026: «кеши бесплатных каналов
    и групп - поместить в установщик»)."""
    return '%s|pvr|tvlogo|%s|%s' % (_ALGO_VERSION, file_md5(path),
                                    size_tag or '%sx%s' % (_PICON_FINAL_W, _PICON_FINAL_H))


def _identity(kind, source):
    translated = _translate(source.partition('|')[0])
    size_tag = '%sx%s' % (
        (_POSTER_FINAL_W, _POSTER_FINAL_H) if kind == 'poster'
        else (_PICON_FINAL_W, _PICON_FINAL_H))
    if kind == 'pvr':
        try:
            logo = tvlink_logo_file(source)
            if logo:
                return tvlink_identity(logo, size_tag)
        except Exception:
            pass
    try:
        if translated and os.path.isfile(translated):
            stat = os.stat(translated)
            stamp = getattr(stat, 'st_mtime_ns', int(stat.st_mtime * 1000000000))
            return '%s|%s|%s|%s|%s|%s' % (
                _ALGO_VERSION, kind, source, stamp, stat.st_size, size_tag)
    except Exception:
        pass
    return '%s|%s|%s|%s' % (_ALGO_VERSION, kind, source, size_tag)


def _destination(kind, identity):
    extension = 'png' if kind == 'pvr' else 'jpg'
    return _CACHE_URI + '%s.%s' % (_md5(identity), extension)


def _open_image(path):
    from PIL import Image
    if xbmcvfs and path.startswith('special://'):
        with xbmcvfs.File(path, 'rb') as handle:
            return Image.open(io.BytesIO(handle.readBytes()))
    return Image.open(_translate(path))


_TEXTURE_DB = [None]


def _kodi_cached_file(source):
    """Path to Kodi's own already-downloaded copy of this image, or ''.

    The rule here used to be "never reuse Kodi's low-res cache", and it cost a
    full network fetch of the poster for every prepared background. The premise
    no longer holds: advancedsettings caps cached textures at
    imageres/fanartres 1080, and what this module produces is a *blurred*
    1920x1080 background, where a 720x1080 source and a 1000x1500 one are
    indistinguishable once blurred. Kodi has almost always fetched the image
    already, because the row that needs the background is the row showing the
    poster.

    Verified 2026-08-07 against the live cache: a TMDb /original/ URL resolves
    through the w1920 variant to a local 101 KB file, and a Filmix poster to a
    local 125 KB file, where a network request used to happen.
    """
    try:
        if not source.startswith(('http://', 'https://')):
            return ''
        if _TEXTURE_DB[0] is None:
            found = ''
            try:
                base = _translate('special://database/')
                names = [n for n in os.listdir(base)
                         if n.startswith('Textures') and n.endswith('.db')]
                if names:
                    found = os.path.join(base, sorted(names)[-1])
            except Exception:
                found = ''
            _TEXTURE_DB[0] = found
        if not _TEXTURE_DB[0]:
            return ''
        base_url = source.partition('|')[0]
        # _upgrade_original_url() has already rewritten TMDb URLs to /original/,
        # but Kodi cached whichever size the skin actually requested, so an
        # exact-match lookup would miss every TMDb image and fetch anyway.
        candidates = [base_url]
        if 'image.tmdb.org/t/p/' in base_url.lower():
            for size in ('w1920', 'w780', 'w1280', 'w500'):
                variant = re.sub(r'(/t/p/)[^/]+/', r'' + size + '/', base_url, count=1)
                if variant != base_url:
                    candidates.append(variant)
        import sqlite3
        con = sqlite3.connect(_TEXTURE_DB[0], timeout=0.5)
        try:
            for candidate_url in candidates:
                row = con.execute(
                    'SELECT cachedurl FROM texture WHERE url = ? LIMIT 1',
                    (candidate_url,)).fetchone()
                if row and row[0]:
                    on_disk = _translate('special://profile/Thumbnails/') + row[0]
                    if os.path.isfile(on_disk):
                        return on_disk
        finally:
            con.close()
        return ''
    except Exception:
        return ''


def _download_or_open(source, identity):
    """Open the source image, preferring a copy already on this box."""
    path = source.partition('|')[0]
    try:
        local = _kodi_cached_file(source)
        if local:
            return _open_image(local), ''
    except Exception:
        pass
    translated = _translate(path)
    try:
        if translated and os.path.isfile(translated):
            return _open_image(path), ''
    except Exception:
        pass
    try:
        if source.startswith('special://') and _exists(source):
            return _open_image(source), ''
    except Exception:
        pass
    try:
        if xbmc.skinHasImage(source):
            skin_path = source if source.startswith('special://skin') else os.path.join('special://skin/media/', source)
            return _open_image(skin_path), ''
    except Exception:
        pass
    if not xbmcvfs:
        return None, ''
    temp_uri = _CACHE_URI + 'download_%s.img' % _md5(identity)
    try:
        if xbmcvfs.exists(temp_uri):
            xbmcvfs.delete(temp_uri)
        if not xbmcvfs.copy(source, temp_uri):
            return None, ''
        return _open_image(temp_uri), temp_uri
    except Exception:
        return None, ''


def _resample_lanczos(Image):
    try:
        return Image.Resampling.LANCZOS
    except AttributeError:
        return getattr(Image, 'LANCZOS', Image.ANTIALIAS)


def _poster_canvas(image):
    """Кадр 1920x1080 из любой картинки: заполняем целиком, без полей.

    История этого места - история двух неправильных ответов на один вопрос
    «чем занять края, если картинка уже кадра». Сначала края занимал растянутый
    крайний пиксель - владелец сфотографировал эти вертикальные полосы у
    правого края 2026-08-29. Потом - мягкая размытая заливка из самой картинки,
    и он увидел ровно то же самое место, только размытым: «вместо полос справа
    размытия».

    Правильный ответ - не занимать края ничем: картинка увеличивается до тех
    пор, пока не закроет кадр целиком, лишнее обрезается. Никаких полей,
    никаких стыков, никакой выдумки по краям. Обложка при этом показывается
    своей средней частью - для размытой подложки это ровно то, что нужно.
    """
    from PIL import Image, ImageFilter, ImageOps
    try:
        image = ImageOps.exif_transpose(image)
    except Exception:
        pass
    rgb = image.convert('RGB')
    resample = _resample_lanczos(Image)
    work = ImageOps.fit(rgb, (_POSTER_WORK_W, _POSTER_WORK_H),
                        method=resample, centering=(0.5, 0.5))
    final = work.filter(ImageFilter.GaussianBlur(radius=_POSTER_BLUR_RADIUS))
    if final.size != (_POSTER_FINAL_W, _POSTER_FINAL_H):
        smaller = final.resize((_POSTER_FINAL_W, _POSTER_FINAL_H), resample)
        final.close()
        final = smaller
    work.close()
    rgb.close()
    return final


def _contain(image, size, method):
    """ImageOps.contain - с Pillow 8.3; в Kodi 21 на Windows Pillow 5.1, и фоны каналов не строились
    («module 'PIL.ImageOps' has no attribute 'contain'», 23.11.2026). Вписать с сохранением пропорций."""
    w, h = image.size
    scale = min(float(size[0]) / max(1, w), float(size[1]) / max(1, h))
    return image.resize((max(1, int(round(w * scale))), max(1, int(round(h * scale)))), method)


def _picon_canvas(image):
    from PIL import Image, ImageFilter, ImageOps
    try:
        image = ImageOps.exif_transpose(image)
    except Exception:
        pass
    rgba = image.convert('RGBA')
    # Leave a small transparent margin so blur does not clip the logo edges.
    contained = _contain(rgba, (int(_PICON_WORK_W * 0.92), int(_PICON_WORK_H * 0.92)),
                         _resample_lanczos(Image))
    work = Image.new('RGBA', (_PICON_WORK_W, _PICON_WORK_H), (0, 0, 0, 0))
    left = (_PICON_WORK_W - contained.width) // 2
    top = (_PICON_WORK_H - contained.height) // 2
    work.alpha_composite(contained, (left, top))
    blurred = work.filter(ImageFilter.GaussianBlur(radius=_PICON_BLUR_RADIUS))
    final = blurred.resize((_PICON_FINAL_W, _PICON_FINAL_H), _resample_lanczos(Image))
    blurred.close()
    work.close()
    contained.close()
    rgba.close()
    return final


def _prune_cache(force=False):
    global _LAST_PRUNE
    now = time.time()
    if not force and now - _LAST_PRUNE < _PRUNE_INTERVAL:
        return
    _LAST_PRUNE = now
    root = _translate(_CACHE_URI)
    try:
        if not root or not os.path.isdir(root):
            return
        entries = []
        total = 0
        for filename in os.listdir(root):
            path = os.path.join(root, filename)
            try:
                stat = os.stat(path)
            except OSError:
                continue
            age = now - stat.st_mtime
            if filename.startswith('download_') or '.tmp.' in filename or age > _MAX_DISK_AGE:
                try:
                    os.remove(path)
                except OSError:
                    pass
                continue
            if filename.lower().endswith(('.jpg', '.png')):
                entries.append((stat.st_mtime, stat.st_size, path))
                total += stat.st_size
        if total > _MAX_DISK_BYTES:
            for _, size, path in sorted(entries):
                try:
                    os.remove(path)
                    total -= size
                except OSError:
                    pass
                if total <= _MAX_DISK_BYTES:
                    break
    except Exception as exc:
        _log('cache prune skipped: %s' % exc, xbmc.LOGDEBUG)


def _bounded_store(store, key, value, limit):
    store.pop(key, None)
    store[key] = value
    while len(store) > limit:
        store.popitem(last=False)


def _generate(kind, source, identity, destination):
    _ensure_cache()
    if _exists(destination):
        return destination
    image = None
    canvas = None
    temp_download = ''
    try:
        if kind == 'pvr' and '|tvlogo|' in identity:
            # тот же файл, по которому посчитан ключ: картинка не зависит от того,
            # закэшировал ли Kodi логотип и в каком виде
            logo = tvlink_logo_file(source) or (source if os.path.isfile(source) else '')
            if logo:
                source = logo
        image, temp_download = _download_or_open(source, identity)
        if image is None:
            return ''
        original_size = getattr(image, 'size', (0, 0))
        canvas = _picon_canvas(image) if kind == 'pvr' else _poster_canvas(image)
        final_path = _translate(destination)
        os.makedirs(os.path.dirname(final_path), exist_ok=True)
        if kind == 'pvr':
            temp_path = final_path + '.tmp.png'
            canvas.save(temp_path, 'PNG', optimize=True)
        else:
            temp_path = final_path + '.tmp.jpg'
            # Качество 95 без прореживания цветности давало 420 КБ на файл:
            # измерено на .20 (1262 файла, 517 МБ) и .30 (1054, 437 МБ) при
            # пределе кеша в 512 МБ. Картинка размытая, поэтому 85 и обычное
            # прореживание визуально не отличаются, а весит вдвое меньше:
            # замерено на тех же снимках 489 -> 217 КБ (обложка) и 523 -> 232 КБ
            # (фанарт), на коробке после пересборки - 213 КБ в среднем. В тот же
            # предел влезает вдвое с лишним больше фонов, то есть настолько же
            # реже их приходится готовить заново.
            canvas.save(temp_path, 'JPEG', quality=85, subsampling=2, optimize=True)
        os.replace(temp_path, final_path)
        _prune_cache()
        _log('ready kind=%s id=%s source=%sx%s output=%sx%s' % (
            kind, _md5(identity)[:10], original_size[0], original_size[1],
            canvas.size[0], canvas.size[1]), xbmc.LOGINFO)
        return destination
    except Exception as exc:
        _log('generation failed kind=%s id=%s: %s' % (
            kind, _md5(identity)[:10], exc), xbmc.LOGWARNING)
        return ''
    finally:
        try:
            if canvas is not None:
                canvas.close()
        except Exception:
            pass
        try:
            if image is not None:
                image.close()
        except Exception:
            pass
        try:
            if temp_download and xbmcvfs and xbmcvfs.exists(temp_download):
                xbmcvfs.delete(temp_download)
        except Exception:
            pass


def _worker_loop():
    global _LATEST_JOB
    while True:
        _EVENT.wait()
        while True:
            with _LOCK:
                job = _LATEST_JOB
                _LATEST_JOB = None
                if job is None:
                    _EVENT.clear()
                    break
            kind, source, identity, destination = job
            result = _generate(kind, source, identity, destination)
            with _LOCK:
                if result:
                    _bounded_store(_RESULTS, identity, result, _MAX_MEMORY_RESULTS)
                    _FAILURES.pop(identity, None)
                else:
                    _bounded_store(_FAILURES, identity, time.time(), _MAX_MEMORY_FAILURES)


def _ensure_worker():
    global _WORKER
    with _LOCK:
        if _WORKER is not None and _WORKER.is_alive():
            return
        _WORKER = threading.Thread(target=_worker_loop, name='SublimeFallbackTextureWorker')
        _WORKER.daemon = True
        _WORKER.start()


def _request(kind, source):
    global _LATEST_JOB
    source = _upgrade_original_url(source)
    if not source:
        return ''
    identity = _identity(kind, source)
    destination = _destination(kind, identity)
    if _exists(destination):
        return destination
    now = time.time()
    with _LOCK:
        cached = _RESULTS.get(identity)
        if cached and _exists(cached):
            _RESULTS.move_to_end(identity)
            return cached
        failed_at = _FAILURES.get(identity, 0.0)
        if failed_at and now - failed_at < _RETRY_SECONDS:
            return ''
        # Latest focused item wins; do not process every item crossed quickly.
        _LATEST_JOB = (kind, source, identity, destination)
        _EVENT.set()
    _ensure_worker()
    return ''


def prepared_path(kind, source):
    """Путь к уже готовой подложке для этого источника, или пусто.

    Нужен тем, кто хочет взять у подложки не саму картинку, а её цвет: файл
    лежит локально, и вытащить из него цвет - это чтение с диска, а не загрузка
    из сети. Именно из-за сети washed color приезжал позже фона.
    """
    source = _upgrade_original_url(source)
    if not source:
        return ''
    destination = _destination(kind, _identity(kind, source))
    return destination if _exists(destination) else ''


def prepare_background_now(kind, source):
    """Generate and cache one blurred background on the CALLER's thread.

    Deliberately separate from _request(): that one keeps a single
    latest-wins slot so a fast scroll does not process every row it crosses,
    and a warm-up calling it would evict the job for the row the user is
    actually looking at. This entry point touches no shared slot - it does the
    work where it is called, which for warming is a background thread whose
    whole purpose is to be early. The owner's report is what prompted it: the
    metadata arrived quickly and the blurred fallback still did not.
    """
    source = _upgrade_original_url(source)
    if not source:
        return ''
    identity = _identity(kind, source)
    destination = _destination(kind, identity)
    if _exists(destination):
        return destination
    now = time.time()
    with _LOCK:
        cached = _RESULTS.get(identity)
        if cached and _exists(cached):
            _RESULTS.move_to_end(identity)
            return cached
        failed_at = _FAILURES.get(identity, 0.0)
        if failed_at and now - failed_at < _RETRY_SECONDS:
            return ''
    result = _generate(kind, source, identity, destination)
    with _LOCK:
        if result:
            _bounded_store(_RESULTS, identity, result, _MAX_MEMORY_RESULTS)
            _FAILURES.pop(identity, None)
        else:
            _bounded_store(_FAILURES, identity, time.time(), _MAX_MEMORY_FAILURES)
    return result


def request_poster_background(source):
    return _request('poster', source)


def request_pvr_background(source):
    return _request('pvr', source)
