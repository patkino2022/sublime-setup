# -*- coding: utf-8 -*-
"""Жив ли хост картинок поставщика.

ЗАЧЕМ

08.09.2026 у Filmix лёг собственный сервер картинок: `thumbs.filmixapp.vip`
отдавал `521` (это Cloudflare сообщает, что источник не отвечает) - и с обеих
коробок, и с машины в другой сети, и не по одному файлу, а корнем хоста. Их API
при этом продолжал выдавать ровно этот адрес для всех постеров, поэтому строки
честно несли мёртвую ссылку, а плитки стояли пустыми двенадцать часов. Владелец:
«И ты сломал постеры филмикс... Разбирайся и чини».

Своих постеров у нас для большинства строк уже есть - обогащение берёт их с
TMDb. Не было только одного: признака «их хост сейчас недоступен». Пока ссылка
непустая, разметка считает её годной - `String.IsEmpty` проверяет строку, а не
картинку.

КАК

Служба раз в пять минут проверяет ОДНУ настоящую ссылку на картинку - не корень
хоста: у filmix.zip корень отдавал 200, а `/posters/...` - 503, то есть по корню
беда не видна. Ответ запоминается в маленьком файле, и сборка строк читает только
его - ни одного лишнего запроса на строку.

Порядок такой: родной хост поставщика, затем замена (`MIRRORS`, по распоряжению
владельца - `filmix.zip`), и только если молчат оба - наш постер с TMDb. Ответит
любой из них - его картинки вернутся сами, без правок.

Мёртвым считается молчание и любой ответ уровня 5xx: 521-524 - это Cloudflare об
источнике, 503 - сам склад картинок. Ошибка одного файла (403, 404) хост мёртвым
НЕ делает.
"""
from __future__ import absolute_import, unicode_literals

import io
import json
import os
import time

import xbmc
import xbmcvfs

from .config import log

STORE = 'special://profile/addon_data/skin.sublime/host_health.json'
# Хосты проверяются не чаще раза в 3 часа (владелец 19.11.2026); отметка «не отвечает»
# живёт до следующей проверки.
CHECK_EVERY = 3 * 3600.0
DOWN_FOR = CHECK_EVERY
TIMEOUT = 4.0
# Ответы Cloudflare о недоступном источнике. 520 сюда не входит намеренно: это
# «источник ответил непонятно», то есть он всё-таки жив.
DEAD_CODES = (521, 522, 523, 524)

_CACHE = {'stamp': 0.0, 'data': None}


def _path():
    try:
        return xbmcvfs.translatePath(STORE)
    except Exception:
        return ''


def _load():
    path = _path()
    try:
        stamp = os.path.getmtime(path) if path else 0.0
    except OSError:
        stamp = 0.0
    if _CACHE['data'] is not None and stamp == _CACHE['stamp']:
        return _CACHE['data']
    data = {}
    if path and os.path.exists(path):
        try:
            with io.open(path, encoding='utf-8') as handle:
                loaded = json.load(handle)
            if isinstance(loaded, dict):
                data = loaded
        except Exception:
            data = {}
    _CACHE['data'] = data
    _CACHE['stamp'] = stamp
    return data


def _save(data):
    path = _path()
    if not path:
        return
    try:
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        with io.open(path, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(data, ensure_ascii=False))
        _CACHE['data'] = None
    except Exception as exc:
        log('состояние хостов не сохранено: %s' % exc, xbmc.LOGDEBUG)


def plain(url):
    """Адрес без обёртки `image://` - её ставят и Kodi, и сами плагины.

    Разбор адреса живёт ЗДЕСЬ и только здесь. 08.09.2026 это стоило владельцу
    пустых плиток дважды: сперва служба приняла за хост
    `%2fstorage%2f.kodi%2faddons%2f...` (местный файл в обёртке) и ушла щупать
    пустоту; потом, наоборот, обёртка стала отвергаться целиком - и строка, у
    которой провайдер завернул `fanart` и `icon`, а `poster` оставил как есть,
    получила разное обращение с одним и тем же мёртвым адресом: постер сняли,
    а обёрнутые ключи остались, и Kodi продолжал ходить в лёгший склад.
    """
    text = str(url or '')
    if text.startswith('image://'):
        try:
            from urllib.parse import unquote
        except ImportError:
            return ''
        try:
            text = unquote(text[8:]).rstrip('/')
        except Exception:
            return ''
    return text


def host_of(url):
    """Хост сетевой ссылки. Для местных путей - пусто."""
    text = plain(url)
    if not text.startswith('http://') and not text.startswith('https://'):
        return ''
    host = text.split('://', 1)[1].split('/', 1)[0].lower()
    return host if '.' in host and '%' not in host else ''


def is_down(url):
    """Хост этой ссылки числится недоступным? Только чтение файла, без сети."""
    host = host_of(url)
    if not host:
        return False
    record = (_load().get(host) or {})
    if not record.get('down'):
        return False
    return (time.time() - float(record.get('at') or 0)) < DOWN_FOR


def due(host):
    """Пора ли проверять этот хост."""
    host = str(host or '').lower()
    if not host:
        return False
    record = (_load().get(host) or {})
    return (time.time() - float(record.get('at') or 0)) >= CHECK_EVERY


MIRRORS = {
    # Замена хоста картинок, если родной молчит. Порядок владельца 08.09.2026:
    # «Поменяй адрес на https://filmix.zip». Проверяется он так же, как и
    # родной: если и он не отдаёт картинку, строка возьмёт наш постер с TMDb.
    'thumbs.filmixapp.vip': 'filmix.zip',
}


def mirror_url(url):
    """Тот же файл на замене хоста. Пусто - замены для этого хоста нет."""
    host = host_of(url)
    other = MIRRORS.get(host)
    if not other:
        return ''
    text = plain(url)
    tail = text.split('://', 1)[1].split('/', 1)
    path = tail[1] if len(tail) > 1 else ''
    return 'https://%s/%s' % (other, path)


def probe(host, sample='', samples=()):
    """Проверка хоста картинок по НАСТОЯЩИМ адресам, и по байтам.

    Корень хоста отвечать может, а склад картинок за ним - нет: 08.09.2026 у
    filmix.zip корень отдавал 200, а `/posters/...` - 503. Поэтому проверять
    надо тот путь, которым мы и пользуемся.

    Одного образца и HEAD мало - это стоило владельцу ещё одного круга пустых
    плиток. Замер на .30 08.09.2026: проба записала хосту 200, а четыре его
    файла в ту же минуту не ответили вовсе (000) ни по HEAD, ни по GET. Их CDN
    отдаёт часть путей с края, до склада не доходя, а HEAD ходит без тела -
    значит «ответил» ещё не значит «картинка придёт».

    Теперь берётся до трёх настоящих адресов, запрашивается первый килобайт, и
    хост считается живым, только если ХОТЬ ОДИН отдал байты.
    """
    host = str(host or '').lower()
    if not host:
        return True
    targets = [plain(one) for one in (list(samples) or [sample]) if plain(one)]
    targets = targets[:3] or ['http://%s/' % host]
    code = 0
    got_bytes = False
    for target in targets:
        try:
            import urllib.error
            import urllib.request
            request = urllib.request.Request(target)
            request.add_header('User-Agent', 'Kodi/22 sublime')
            request.add_header('Range', 'bytes=0-1023')
            try:
                with urllib.request.urlopen(request, timeout=TIMEOUT) as answer:
                    code = int(answer.status or 0)
                    got_bytes = bool(answer.read(1024))
            except urllib.error.HTTPError as exc:
                code = int(exc.code or 0)
        except Exception:
            code = 0
        if got_bytes:
            break
    # Живым хост считается только когда картинка дошла. Молчание, 5xx и пустой
    # ответ - это «нарисовать нечем»: 521-524 говорит Cloudflare об источнике,
    # 503 - сам склад картинок, 000 - не ответили вовсе.
    down = not got_bytes
    data = dict(_load())
    data[host] = {'down': bool(down), 'code': code, 'at': time.time(),
                  'checked': len(targets)}
    _save(data)
    log('хост картинок %s: %s (код %s, проверено адресов %d)'
        % (host, 'НЕ ОТВЕЧАЕТ' if down else 'жив', code or 'нет ответа',
           len(targets)),
        xbmc.LOGINFO if down else xbmc.LOGDEBUG)
    return not down
