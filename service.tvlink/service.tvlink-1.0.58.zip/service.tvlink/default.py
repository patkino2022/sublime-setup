"""Channels screen: group order, channel order, moves, renames, hidden channels.

Everything here edits channels.json; the daemon rebuilds the playlist within
seconds, and pvr.tvlink is restarted on exit so Kodi shows the new order.
"""
import json
import os
import sys
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ROOT = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
sys.path.insert(0, os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "resources", "lib"))

from tvlinkd import catalog as cat  # noqa: E402
from tvlinkd.store import Paths, load_config, read_json, write_json  # noqa: E402

DLG = xbmcgui.Dialog()
TITLE = "TVLink"
L = ADDON.getLocalizedString


class Editor:
    def __init__(self):
        self.paths = Paths(ROOT)
        self.cfg = load_config(self.paths)
        self.arr = cat.load_arrangement(self.paths)
        self.changed = False
        self.reload()

    def reload(self):
        self.catalog = cat.build(self.cfg, self.paths, persist=False)
        self.by_group = {}
        for c in self.catalog["channels"]:
            self.by_group.setdefault(c["group"], []).append(c)

    def save(self):
        write_json(self.paths.channels, self.arr)
        self.changed = True
        self.reload()

    def group(self, name):
        return next(g for g in self.arr["groups"] if g["name"] == name)

    # ---- groups ----------------------------------------------------------
    def groups_screen(self):
        pos = 0
        while True:
            gs = self.arr["groups"]
            labels = ["%s %s  (%d)" % ("[B]+[/B]" if g.get("enabled", True) else "-", g["name"],
                                       len(self.by_group.get(g["name"], ()))) for g in gs]
            i = DLG.select(L(30100), labels, preselect=pos)
            if i < 0:
                return
            g = gs[i]
            acts = [L(30101), L(30102), L(30103), L(30104),
                    L(30105) if g.get("enabled", True) else L(30106), L(30107), L(30108)]
            a = DLG.select(g["name"], acts)
            if a in (0, 1, 2, 3):
                j = {0: max(0, i - 1), 1: min(len(gs) - 1, i + 1), 2: 0, 3: len(gs) - 1}[a]
                gs.insert(j, gs.pop(i))
                pos = j
            elif a == 4:
                g["enabled"] = not g.get("enabled", True)
                pos = i
            elif a == 5:
                new = DLG.input(L(30109), g["name"]).strip()
                if not new or new == g["name"] or any(x["name"] == new for x in gs):
                    continue
                for ch in self.arr["channels"].values():
                    if ch.get("group") == g["name"]:
                        ch["group"] = new
                g["name"], pos = new, i
            elif a == 6:
                new = DLG.input(L(30110)).strip()
                if not new or any(x["name"] == new for x in gs):
                    continue
                gs.insert(i + 1, {"name": new, "enabled": True})
                pos = i + 1
            else:
                continue
            self.save()

    # ---- channels --------------------------------------------------------
    def pick_group(self, heading):
        names = [g["name"] for g in self.arr["groups"] if self.by_group.get(g["name"])]
        i = DLG.select(heading, ["%s  (%d)" % (n, len(self.by_group[n])) for n in names])
        return names[i] if i >= 0 else None

    def channels_screen(self):
        gname = self.pick_group(L(30111))
        while gname:
            chans = self.by_group.get(gname, [])
            labels = ["%d. %s" % (c["num"], c["title"]) for c in chans]
            labels.append(L(30112))
            i = DLG.select(L(30113) % gname, labels, preselect=getattr(self, "_pos", 0))
            if i < 0:
                gname = self.pick_group(L(30111))
                continue
            if i == len(chans):
                self.group(gname).pop("order", None)
                self.save()
                continue
            self._pos = i
            gname = self.channel_actions(gname, chans, i) or gname

    def channel_actions(self, gname, chans, i):
        c = chans[i]
        ids = [x["id"] for x in chans]
        meta = self.arr["channels"].setdefault(c["id"], {"title": c["title"], "group": gname})
        src = ", ".join(dict.fromkeys(ln["src"] for ln in c["links"]))
        also = meta.get("also") or []
        acts = [L(30101), L(30102), L(30114), L(30115), L(30116), L(30117),
                L(30107), L(30118), L(30119),
                L(30120) % (", ".join(also) or L(30121)), L(30122) % src]
        a = DLG.select(c["title"], acts)
        if a in (0, 1, 2, 3, 4):
            if a == 4:
                n = DLG.numeric(0, L(30123) % len(ids))
                if not n:
                    return None
                j = min(max(int(n) - 1, 0), len(ids) - 1)
            else:
                j = {0: max(0, i - 1), 1: min(len(ids) - 1, i + 1), 2: 0, 3: len(ids) - 1}[a]
            ids.insert(j, ids.pop(i))
            self.group(gname)["order"] = ids
            self._pos = j
        elif a == 5:
            to = self.pick_group(L(30124) % c["title"])
            if not to or to == gname:
                return None
            meta["group"] = to
            g = self.group(to)
            if g.get("order"):
                g["order"].append(c["id"])
        elif a == 6:
            new = DLG.input(L(30125), c["title"]).strip()
            if not new:
                return None
            meta["title"] = new.replace(",", " ")
        elif a == 7:
            meta["hidden"] = True
        elif a == 8:
            to = self.pick_group(L(30126) % c["title"])
            if not to or to == gname or to in also:
                return None
            meta["also"] = also + [to]
        elif a == 9 and also:
            meta.pop("also", None)
        else:
            return None
        self.save()
        return None

    def hidden_screen(self):
        hid = [(cid, ch) for cid, ch in self.arr["channels"].items() if ch.get("hidden")]
        if not hid:
            DLG.ok(TITLE, L(30127))
            return
        hid.sort(key=lambda x: (x[1].get("title") or "").casefold())
        sel = DLG.multiselect(L(30128), ["%s  [%s]" % (ch.get("title"), ch.get("group")) for _, ch in hid])
        if sel:
            for k in sel:
                hid[k][1].pop("hidden", None)
            self.save()

    def status_text(self):
        st = read_json(self.paths.status, {}) or {}
        when = lambda t: time.strftime("%d.%m %H:%M", time.localtime(t)) if t else "-"
        lines = [L(30129) % st.get("channels", len(self.catalog["channels"]))]
        for name, s in sorted((st.get("sources") or {}).items()):
            lines.append(L(30130) % (name, s.get("links", "?"), when(s.get("updated")),
                                     "  [COLOR red]%s[/COLOR]" % s["error"] if s.get("error") else ""))
        lines.append(L(30131) % (
            st.get("epg_channels", "-"), st.get("epg_programmes", "-"), when(st.get("epg_built"))))
        return "\n".join(lines)

    def main(self):
        while True:
            hidden = sum(1 for ch in self.arr["channels"].values() if ch.get("hidden"))
            items = [L(30132), L(30100), L(30133),
                     L(30134) % hidden, L(30017), L(30135)]
            i = DLG.select(TITLE, items)
            if i < 0:
                break
            if i == 0:
                DLG.textviewer(TITLE, self.status_text())
            elif i == 1:
                self.groups_screen()
            elif i == 2:
                self.channels_screen()
            elif i == 3:
                self.hidden_screen()
            elif i == 4:
                request_refresh(self.paths)
            elif i == 5:
                ADDON.openSettings()
        if self.changed and DLG.yesno(TITLE, L(30136)):
            apply_to_pvr()


def request_refresh(paths):
    with open(os.path.join(paths.root, "refresh.now"), "w") as f:
        f.write("1")
    xbmcgui.Dialog().notification(TITLE, L(30137), xbmcgui.NOTIFICATION_INFO, 3000)


def apply_to_pvr():
    """pvr.tvlink re-reads the playlist only on its interval; any change of its
    settings makes it reload now, in its own thread (see service.nudge_pvr_client:
    disabling the add-on instead can crash Kodi)."""
    time.sleep(6)   # daemon notices channels.json within 5 s
    cid = "pvr.sublime" if xbmc.getCondVisibility("System.AddonIsEnabled(pvr.sublime)") else "pvr.tvlink"
    pvr = xbmcaddon.Addon(cid)
    pvr.setSetting("m3uRefreshHour", "5" if pvr.getSetting("m3uRefreshHour") == "4" else "4")


if __name__ == "__main__":
    if "refresh" in sys.argv[1:]:
        request_refresh(Paths(ROOT))
    else:
        Editor().main()
