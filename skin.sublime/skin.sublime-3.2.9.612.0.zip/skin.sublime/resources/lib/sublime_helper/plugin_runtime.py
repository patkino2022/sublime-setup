# -*- coding: utf-8 -*-
"""Small, dependency-free lifecycle guard for plugin://skin.sublime calls.

Kodi can invoke the same addon as a directory plugin (non-negative handle) or
through RunPlugin (handle -1).  xbmcplugin methods are only valid for directory
handles.  This module also makes endOfDirectory idempotent inside one invoker.
"""
from __future__ import absolute_import, unicode_literals

import threading

_LOCK = threading.RLock()
_FINISHED = set()


def normalize_handle(handle):
    try:
        value = int(handle)
    except Exception:
        return -1
    return value if value >= 0 else -1


def begin_invocation(handle):
    """Start a new Kodi plugin invocation, including a reused numeric handle."""
    value = normalize_handle(handle)
    if value < 0:
        return False
    with _LOCK:
        _FINISHED.discard(value)
    return True


def finish_directory(handle, content='', category='', succeeded=True,
                     update_listing=False, cache_to_disc=False):
    """Finish a directory exactly once.  RunPlugin handles are ignored."""
    value = normalize_handle(handle)
    if value < 0:
        return False
    with _LOCK:
        if value in _FINISHED:
            return False
        try:
            import xbmcplugin
            if category:
                try:
                    xbmcplugin.setPluginCategory(value, str(category))
                except Exception:
                    pass
            if content:
                try:
                    xbmcplugin.setContent(value, str(content))
                except Exception:
                    pass
            xbmcplugin.endOfDirectory(
                value,
                succeeded=bool(succeeded),
                updateListing=bool(update_listing),
                cacheToDisc=bool(cache_to_disc),
            )
        except Exception:
            return False
        _FINISHED.add(value)
        return True
