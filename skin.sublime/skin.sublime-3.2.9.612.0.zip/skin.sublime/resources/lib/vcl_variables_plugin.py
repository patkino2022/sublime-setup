# -*- coding: utf-8 -*-
# VCL embedded VCLVariables-compatible plugin entrypoint.
# Namespaced into the skin so the external Skin Variables addon is no longer a dependency.
import os
import sys
import time
import traceback

_T0 = time.time()
import xbmcaddon
from urllib.parse import parse_qsl, unquote_plus

try:
    import xbmc
except Exception:
    xbmc = None
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None
try:
    import xbmcplugin
except Exception:
    xbmcplugin = None

# Kodi can launch script/plugin entrypoints from a skin addon without placing the
# skin addon root on sys.path. Add it explicitly so absolute imports like
# resources.lib.vcl_variables.* resolve exactly as they did in script.skinvariables.
_ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
if _ADDON_ROOT not in sys.path:
    sys.path.insert(0, _ADDON_ROOT)

# Готовая выдача вкладки хаба (hub/listing_cache.py) - до всех остальных импортов. При первом заходе
# в хаб Kodi запускает выдачу всех вкладок окна разом, и каждый процесс сначала грузил всю точку
# входа плагина: в толчее это 0,15-0,5 с на процесс до отдачи готового (замер .20, 22.11.2026).
_SERVED = False
if __name__ == '__main__' and len(sys.argv) > 2 and 'info=hub_' in sys.argv[2]:
    try:
        from resources.lib.hub import listing_cache as _listing_cache
        _SERVED = _listing_cache.serve(int(sys.argv[1]),
                                       dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True)))
        if _SERVED and xbmc:
            xbmc.log('[sublime plugin] готовая выдача %s: %d мс' % (
                sys.argv[2][:48], (time.time() - _T0) * 1000), xbmc.LOGINFO)
    except Exception as _exc:
        _SERVED = False
        if xbmc:
            xbmc.log('[sublime plugin] готовая выдача не отдана: %s' % _exc, xbmc.LOGWARNING)


try:
    BUILD = xbmcaddon.Addon('skin.sublime').getAddonInfo('version') or 'unknown'
except Exception:
    BUILD = 'unknown'
_KEYBOARD_HISTORY_LIMIT = 10
_KEYBOARD_HISTORY_FILE = 'special://profile/addon_data/skin.sublime/keyboard_history.json'


def _translate_path(path):
    try:
        if xbmcvfs:
            return xbmcvfs.translatePath(path)
    except Exception:
        pass
    try:
        if xbmc:
            return xbmc.translatePath(path)
    except Exception:
        pass
    return path


def _log(msg, level=None):
    try:
        if xbmc:
            xbmc.log('[sublime plugin %s] %s' % (BUILD, msg), level or xbmc.LOGINFO)
    except Exception:
        pass


def _builtin_escape(value):
    try:
        value = '' if value is None else str(value)
        value = value.replace('\\', '\\\\').replace('"', '\\"')
        return '"%s"' % value
    except Exception:
        return '""'


def _load_keyboard_history():
    return load_history(_KEYBOARD_HISTORY_FILE, _KEYBOARD_HISTORY_LIMIT)


def _sync_keyboard_skin_strings(items=None):
    try:
        items = _load_keyboard_history() if items is None else list(items or [])
        for idx in range(_KEYBOARD_HISTORY_LIMIT):
            key = 'Sublime.KeyboardRecent.%02d' % (idx + 1)
            val = items[idx] if idx < len(items) else ''
            if val:
                if xbmc:
                    xbmc.executebuiltin('Skin.SetString(%s,%s)' % (key, _builtin_escape(val)))
            else:
                if xbmc:
                    xbmc.executebuiltin('Skin.Reset(%s)' % key)
        return True
    except Exception as exc:
        _log('skin string sync skipped: %s' % exc, getattr(xbmc, 'LOGWARNING', 2) if xbmc else None)
        return False


def _push_keyboard_history(text):
    text = unquote_plus(text or '').strip()
    if not text:
        return False
    items = push_history(text, _KEYBOARD_HISTORY_FILE, _KEYBOARD_HISTORY_LIMIT)
    _sync_keyboard_skin_strings(items)
    _log('saved keyboard input atomically: %s' % text[:80])
    return True


if not _SERVED:
    from resources.lib.sublime_helper.keyboard_history import load_history, push_history
    from resources.lib.sublime_helper.plugin_routes import HANDLED as HELPER_ROUTES
    from resources.lib.sublime_helper.plugin_routes import HUB as HUB_ROUTES
    from resources.lib.sublime_helper.plugin_runtime import begin_invocation, finish_directory
    from resources.lib.vcl_variables.plugin import Plugin
    try:
        # дополнения, которых нет в каждой сборке скина
        from resources.lib.sublime_helper.home_extras import PLUGIN_ARGS as _EXTRA_ARGS
        from resources.lib.sublime_helper.home_extras import PLUGIN_ROUTES as _EXTRA_ROUTES
    except ImportError:
        _EXTRA_ROUTES, _EXTRA_ARGS = (), ()

if __name__ == '__main__' and not _SERVED:
    try:
        handle = int(sys.argv[1])
    except Exception:
        handle = -1
    begin_invocation(handle)
    params = dict(parse_qsl(sys.argv[2][1:], keep_blank_values=True)) if len(sys.argv) > 2 else {}
    info = params.get('info') or params.get('action') or ''
    succeeded = False
    try:
        if info == 'keyboard_save':
            _push_keyboard_history(params.get('text') or params.get('q') or params.get('label') or '')
            succeeded = True
        elif info == 'keyboard_recent_sync':
            _sync_keyboard_skin_strings()
            succeeded = True
        elif info in _EXTRA_ROUTES:
            # Маршруты дополнений, которых нет в каждой сборке (home_extras.py). Вызывают
            # их извне через Files.GetDirectory: в JSON-RPC нет XBMC.ExecuteBuiltin, а
            # Addons.ExecuteAddon для скина открывает плагин как раздел и двигает
            # интерфейс. Работа идёт в отдельном RunScript - ответ уходит сразу.
            _args = ','.join('%s=%s' % (_k, _builtin_escape(_v)) for _k, _v in params.items()
                             if _k in _EXTRA_ARGS)
            xbmc.executebuiltin('RunScript(skin.sublime,%s)' % _args)
            succeeded = True
        elif info in HUB_ROUTES:
            # The hub builds its lists from the provider's cache and Kodi's own
            # history - no TMDb clients, no PIL, so it is imported on its own.
            _t_entry = time.time()
            # готовую выдачу отдаёт начало файла; сюда доходит только пересчёт
            from resources.lib.hub.routes import run as run_hub
            _t_import = time.time()
            succeeded = bool(run_hub(handle, params))
            # время выдачи полосы хаба по частям: первый заход в хаб ждал выдачу 3,7 с (.30, 22.11.2026)
            _log('hub route %s: всего %d мс (запуск %d, импорт маршрутов %d, работа %d)' % (
                info, (time.time() - _T0) * 1000, (_t_entry - _T0) * 1000,
                (_t_import - _t_entry) * 1000, (time.time() - _t_import) * 1000))
        elif info in HELPER_ROUTES:
            # Import metadata providers only for routes that actually need them.
            from resources.lib.sublime_helper.plugin import run as run_sublime_helper_plugin
            succeeded = bool(run_sublime_helper_plugin(handle, params))
        else:
            succeeded = bool(Plugin(handle, sys.argv[2][1:]).run())
    except Exception as exc:
        _log('plugin route failed info=%s handle=%s error=%s\n%s' % (
            info or '<empty>', handle, exc, traceback.format_exc()),
            getattr(xbmc, 'LOGERROR', 4) if xbmc else None)
        succeeded = False
    finally:
        # Idempotent: helper/VCL routes that already finished are not finished twice.
        finish_directory(handle, succeeded=succeeded, cache_to_disc=False)
