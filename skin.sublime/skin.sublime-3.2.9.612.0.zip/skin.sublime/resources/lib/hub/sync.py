# -*- coding: utf-8 -*-
"""Carrying Kodi's own history between boxes.

Ported from plugin.video.watchhub, with one change of substance: the rows no
longer come from a store of ours. Kodi keeps the history now, so this pushes
what Kodi recorded on this box and applies what the other box recorded, through
history.py. The server stays exactly as it was - it stores rows and hands back
whatever changed - so both ends can be replaced independently.

The feedback ("recommend / do not recommend such") is ours and still travels
from store.py, because Kodi has nowhere to keep it.
"""
from __future__ import absolute_import, unicode_literals

import json
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

import xbmc

from . import history, shared_store
from .config import get_bool, get_int, get_str, log
from .provider import instance_id
from .store import db

PUSH_CURSOR = 'sync_push_cursor'
PUSH_F_CURSOR = 'sync_push_f_cursor'
PULL_CURSOR = 'sync_pull_cursor'
PULL_F_CURSOR = 'sync_pull_f_cursor'
LAST_OK_FLAG = 'sync_last_ok'
LAST_ERROR_FLAG = 'sync_last_error'
FAIL_STREAK_FLAG = 'sync_fail_streak'
FAIL_UNTIL_FLAG = 'sync_fail_until'
FAIL_BACKOFF_STEP = 300
FAIL_BACKOFF_MAX = 3600
# Настройки рекомендаций - одни на все коробки и лежат на сервере просмотров (владелец
# 25.11.2026). Подпись списка рекомендаций считается из них: с разными настройками каждая
# коробка отвергала общий список и собирала свой (.20 и .30, 25.11.2026).
SHARED_SETTINGS = ('preferred_genres', 'blocked_genres', 'excluded_countries', 'min_rating',
                   'min_year', 'prefer_acclaimed', 'diversity', 'fresh_percent',
                   'exclude_watched', 'widget_size', 'refresh_hours')
SETTINGS_HASH_FLAG = 'sync_settings_hash'
# Хозяин настроек - коробка, на которой работает сервер просмотров (установщик кладёт его сюда).
# Остальные коробки настройки рекомендаций только берут у сервера и сами их не меняют
# (владелец 25.11.2026).
SERVER_SCRIPT = '/storage/hub-server/watchhub_server.py'


def settings_master():
    """Эта коробка задаёт настройки рекомендаций: локально, через папку - или это коробка
    с сервером просмотров. Клиент сервера их только берёт."""
    import os
    if location() != 'server' or not enabled():
        return True
    return os.path.exists(SERVER_SCRIPT)


def settings_locked(key):
    """Пункт настроек нельзя менять на этой коробке - он приходит с сервера."""
    return key in SHARED_SETTINGS and not settings_master()
BATCH = 500
MAX_PAGES = 20


class SyncError(Exception):
    pass


def location():
    """Which transport carries the materials.

    'server' is the HTTP service, 'folder' is any path Kodi's VFS can reach,
    'local' means this box keeps everything to itself. The old sync_enabled
    switch still means the server, so nothing changes for a box already set up.
    """
    chosen = (get_str('state_location', 'local') or 'local').strip().lower()
    if chosen not in ('local', 'server', 'folder'):
        chosen = 'local'
    if chosen == 'local' and get_bool('sync_enabled', False):
        return 'server'
    return chosen


def enabled():
    place = location()
    if place == 'server':
        return bool(get_str('sync_url', '') and get_str('sync_token', ''))
    if place == 'folder':
        return bool(shared_store.base_path())
    return False


def _request(path, payload=None):
    base = get_str('sync_url', '').rstrip('/')
    if not base:
        raise SyncError('адрес сервера не задан')
    url = '%s/%s' % (base, path.lstrip('/'))
    data = None
    headers = {'Authorization': 'Bearer %s' % get_str('sync_token', ''),
               'Accept': 'application/json'}
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        headers['Content-Type'] = 'application/json'
    try:
        with urlopen(Request(url, data=data, headers=headers),
                     timeout=max(5, get_int('sync_timeout', 30))) as answer:
            return json.loads(answer.read().decode('utf-8') or '{}')
    except HTTPError as exc:
        raise SyncError('HTTP %s' % exc.code)
    except URLError as exc:
        raise SyncError(str(getattr(exc, 'reason', exc)))
    except Exception as exc:
        raise SyncError(str(exc))


def _cursor(store, flag):
    raw = store.get_flag(flag) or ''
    try:
        return int(raw)
    except (TypeError, ValueError):
        return 0


def _fail_streak(store):
    try:
        return int(store.get_flag(FAIL_STREAK_FLAG) or 0)
    except (TypeError, ValueError):
        return 0


def _as_watched_row(row):
    """One of Kodi's rows in the shape the server already speaks.

    The path is what matters and what the other box keys by; the title travels
    too, because a box whose provider cache has not yet met this post can still
    show a name.
    """
    return {
        'item_key': row['item_key'],
        'parent_key': row.get('parent_key') or '',
        'mediatype': row.get('mediatype') or '',
        'label': row.get('label') or '',
        'year': str(row.get('year') or ''),
        'season': int(row.get('season') or 0),
        'episode': int(row.get('episode') or 0),
        'genres': row.get('genres') or '',
        'countries': row.get('countries') or '',
        'studio': '',
        'rating': 0.0,
        'source': 'kodi',
        'playcount': int(row.get('playcount') or 0),
        'last_watched': int(row.get('last_watched') or 0),
        # Carried in the progress payload too, so a resume point can be applied
        # by path on the other side.
        'path': row.get('path') or '',
    }


def _as_progress_row(row):
    return {
        'item_key': row['item_key'],
        'parent_key': row.get('parent_key') or '',
        'mediatype': row.get('mediatype') or '',
        'label': row.get('label') or '',
        'path': row.get('path') or '',
        'position': float(row.get('position') or 0),
        'total': float(row.get('total') or 0),
        'updated_ts': int(row.get('last_watched') or 0),
    }


def push(store):
    """Send what Kodi recorded here since the last successful pass."""
    sent_w = sent_p = sent_f = 0
    for _page in range(MAX_PAGES):
        cursor = _cursor(store, PUSH_CURSOR)
        rows = history.changed_since(cursor, limit=BATCH)
        f_ts = _cursor(store, PUSH_F_CURSOR)
        feedback = store.feedback_changed_since(f_ts, '', limit=BATCH)
        if not rows and not feedback:
            break
        watched = [_as_watched_row(r) for r in rows if int(r.get('playcount') or 0) > 0]
        # снятые здесь отметки - как «снято» (playcount 0): сервер хранит это как намеренный ноль и
        # раздаёт другой коробке (merge_watched). Только снятые пунктом меню - не всё без отметки
        unmarked = history.unmarked()
        cleared = [r for r in rows if int(r.get('playcount') or 0) <= 0
                   and float(r.get('position') or 0) <= 0
                   and history.canon_path(r.get('path')) in unmarked]
        watched += [_as_watched_row(r) for r in cleared]
        progress = [_as_progress_row(r) for r in rows
                    if int(r.get('playcount') or 0) <= 0
                    and float(r.get('position') or 0) > 0]
        result = _request('push', payload={'watched': watched,
                                           'progress': progress,
                                           'feedback': feedback})
        if not result.get('ok'):
            raise SyncError('push отклонён: %s' % (result.get('error') or '?'))
        if rows:
            store.set_flag(PUSH_CURSOR, str(rows[-1]['last_watched']))
        if cleared:
            history.forget_unmarked([r.get('path') for r in cleared])
        if feedback:
            store.set_flag(PUSH_F_CURSOR, str(feedback[-1].get('updated_ts') or 0))
        sent_w += len(watched)
        sent_p += len(progress)
        sent_f += len(feedback)
        if len(rows) < BATCH and len(feedback) < BATCH:
            break
    return sent_w, sent_p, sent_f


def pull(store):
    """Apply what the other box recorded, into Kodi."""
    applied_w = applied_p = applied_f = 0
    named = []
    for _page in range(MAX_PAGES):
        w_ts = _cursor(store, PULL_CURSOR)
        f_ts = _cursor(store, PULL_F_CURSOR)
        result = _request('changes?w_since=%d&w_key=&p_since=%d&p_key=&f_since=%d&f_key='
                          % (w_ts, w_ts, f_ts))
        if not result.get('ok'):
            raise SyncError('changes отклонён: %s' % (result.get('error') or '?'))
        watched = result.get('watched') or []
        progress = result.get('progress') or []
        feedback = result.get('feedback') or []
        for row in watched:
            # A row this box authored used to be skipped here, to avoid applying
            # back what we had just sent. The cost of that shortcut was real: a
            # row recorded on this box long ago and since lost locally - every
            # row imported from the retired add-on before paths existed - could
            # never come home again. Measured: .30 held 2640 watched files and
            # .20 only 2498, with the store carrying paths for both and the
            # exchange reporting nothing left to do.
            #
            # Applying it is cheap and safe: apply_remote writes only when the
            # incoming row is newer than what Kodi already has, so our own echo
            # changes nothing.
            if history.apply_remote(row):
                applied_w += 1
        for row in progress:
            row = dict(row)
            row['last_watched'] = row.get('updated_ts') or 0
            if history.apply_remote(row):
                applied_p += 1
        named.extend(watched)
        named.extend(progress)
        for row in feedback:
            if store.merge_feedback(row):
                applied_f += 1
        store.set_flag(PULL_CURSOR, str(result.get('next_w_since') or w_ts))
        store.set_flag(PULL_F_CURSOR, str(result.get('next_f_since') or f_ts))
        if not (watched or progress or feedback) or not result.get('truncated'):
            break
    history.remember_names(named)
    return applied_w, applied_p, applied_f


def fetch_recommend(category):
    if location() == 'folder':
        return shared_store.read_list(category)
    try:
        answer = _request('recommend?category=%s' % quote(category))
    except SyncError:
        return None
    if not answer.get('ok') or not answer.get('items'):
        return None
    # Сервер отдаёт items/signature/built_by/updated_ts (watchhub_server.get_recommend). Перенос из
    # plugin.video.watchhub (3.2.9.397) читал поле 'list', которого нет: общий список не брала ни
    # одна коробка, и каждая показывала свой (.20 и .30 разные при одной подписи, 25.11.2026).
    return {'items': answer.get('items') or [],
            'signature': answer.get('signature') or '',
            'built_by': answer.get('built_by') or '',
            'updated_ts': int(answer.get('updated_ts') or 0)}


def publish_recommend(category, items, signature, built_by):
    if location() == 'folder':
        return shared_store.write_list(category, items, signature, built_by)
    try:
        _request('recommend', payload={'category': category, 'items': items,
                                       'signature': signature,
                                       'built_by': built_by})
        return True
    except SyncError as exc:
        log('список не опубликован: %s' % exc, xbmc.LOGWARNING)
        return False


def claim(name):
    if location() == 'folder':
        # A folder has no claim service. Two boxes building the same list a
        # minute apart is wasteful but harmless - the newer file simply wins -
        # so this says yes rather than pretending to coordinate.
        return True
    try:
        answer = _request('claim', payload={'name': name, 'owner': instance_id()})
    except SyncError:
        return False
    return bool(answer.get('ok') and answer.get('granted'))


def _settings_hash(values):
    import hashlib
    return hashlib.sha1(json.dumps(values, sort_keys=True, ensure_ascii=False)
                        .encode('utf-8')).hexdigest()[:16]


def _local_settings():
    from .config import values as _values
    current = _values()
    return {key: current.get(key) for key in SHARED_SETTINGS}


def _write_missing(values):
    """Ключи набора, которых нет в файле коробки (значение по умолчанию), - явно в файл, как у
    клиентов: по файлу видно, на каких настройках коробка."""
    try:
        from . import config
        with open(config._path(), encoding='utf-8') as handle:
            stored = json.load(handle)
    except Exception:
        stored = {}
    from .config import set_value
    for key, value in values.items():
        if isinstance(stored, dict) and key not in stored:
            set_value(key, value)


def sync_settings(store):
    """Свести настройки рекомендаций с общими. Сервер просмотров: набор задаёт коробка, на
    которой он работает, клиенты его берут. Общая папка: правка на этой коробке (набор
    отличается от последнего сведённого) уходит в папку, иначе берётся набор из папки.
    Пустое хранилище получает набор этой коробки."""
    folder = location() == 'folder'
    local = _local_settings()
    local_hash = _settings_hash(local)
    last = store.get_flag(SETTINGS_HASH_FLAG) or ''
    if folder:
        remote = shared_store.read_settings()
    else:
        remote = _request('settings?name=recommend')
        if not remote.get('ok'):
            raise SyncError('настройки не прочитаны')
    remote_values = {k: v for k, v in (remote.get('values') or {}).items() if k in SHARED_SETTINGS}
    if folder:
        send = (last and local_hash != last) or not remote_values
    elif settings_master():
        # хозяин: на сервере всегда его набор
        send = not remote_values or _settings_hash(
            {k: remote_values.get(k) for k in SHARED_SETTINGS}) != local_hash
    else:
        # клиент свой набор отдаёт только пустому серверу
        send = not remote_values
    if send:
        payload = {'name': 'recommend', 'values': local, 'updated_by': instance_id(),
                   'updated_ts': int(time.time())}
        if folder:
            if shared_store.writable():
                shared_store.write_settings(local, payload['updated_by'], payload['updated_ts'])
        else:
            _request('settings', payload=payload)
        _write_missing(local)
        store.set_flag(SETTINGS_HASH_FLAG, local_hash)
        log('настройки рекомендаций отправлены в общие')
        return 'push'
    remote_hash = _settings_hash({k: remote_values.get(k) for k in SHARED_SETTINGS})
    if remote_hash == local_hash:
        if last != local_hash:
            store.set_flag(SETTINGS_HASH_FLAG, local_hash)
        return ''
    from .config import set_value
    # все ключи набора - явно в файл коробки, и совпадающие со значением по умолчанию: по файлу
    # видно, что коробка работает на общих настройках (installer/regress.py сверяет файл с сервером)
    for key in SHARED_SETTINGS:
        if key in remote_values:
            set_value(key, remote_values[key])
    store.set_flag(SETTINGS_HASH_FLAG, _settings_hash(_local_settings()))
    log('настройки рекомендаций взяты из общих (правил %s)' % (remote.get('updated_by') or '?'))
    return 'pull'


def _run_folder(store):
    """One pass over the shared folder: merge both ways, apply what is new."""
    owner = instance_id()
    locked = shared_store.acquire_lock(owner)
    applied_h = applied_f = 0
    try:
        local_rows = history.changed_since(0, limit=5000)
        merged_h, incoming_h = shared_store.merge_history(
            local_rows, shared_store.read_doc(shared_store.HISTORY_DOC))
        merged_f, incoming_f = shared_store.merge_feedback(
            store.feedback_rows(), shared_store.read_doc(shared_store.FEEDBACK_DOC))
        for row in incoming_h:
            if history.apply_remote(row):
                applied_h += 1
        for row in incoming_f:
            if store.merge_feedback(row):
                applied_f += 1
        if shared_store.writable():
            shared_store.write_doc(shared_store.HISTORY_DOC, merged_h)
            shared_store.write_doc(shared_store.FEEDBACK_DOC, merged_f)
    finally:
        if locked:
            shared_store.release_lock(owner)
    if applied_h or applied_f:
        log('общая папка: принято %d записей истории, %d оценок'
            % (applied_h, applied_f))
    return applied_h, applied_f


def run_once(force=False):
    """One full pass. Returns True when it completed without error."""
    if not enabled():
        return False
    store = db()
    interval = max(60, get_int('sync_interval_minutes', 10) * 60)
    now = int(time.time())
    if not force:
        try:
            last = int(store.get_flag(LAST_OK_FLAG) or 0)
        except (TypeError, ValueError):
            last = 0
        if last and now - last < interval:
            return False
        # Back off while the server is unreachable: a full timeout on every
        # tick, for a server that is not going to answer, is pure waste.
        if _fail_streak(store):
            try:
                deadline = int(store.get_flag(FAIL_UNTIL_FLAG) or 0)
            except (TypeError, ValueError):
                deadline = 0
            if deadline and now < deadline:
                return False
    try:
        if location() == 'folder':
            _run_folder(store)
            sync_settings(store)
            store.set_flag(LAST_OK_FLAG, str(int(time.time())))
            store.set_flag(LAST_ERROR_FLAG, '')
            return True
        pushed = push(store)
        pulled = pull(store)
        sync_settings(store)
    except SyncError as exc:
        streak = _fail_streak(store) + 1
        wait = min(FAIL_BACKOFF_MAX, FAIL_BACKOFF_STEP * streak)
        store.set_flag(FAIL_STREAK_FLAG, str(streak))
        store.set_flag(FAIL_UNTIL_FLAG, str(int(time.time()) + wait))
        store.set_flag(LAST_ERROR_FLAG, str(exc))
        log('обмен не удался: %s (попытка %d, следующая через %d с)'
            % (exc, streak, wait), xbmc.LOGWARNING)
        return False
    store.set_flag(LAST_OK_FLAG, str(int(time.time())))
    store.set_flag(LAST_ERROR_FLAG, '')
    if _fail_streak(store):
        store.set_flag(FAIL_STREAK_FLAG, '0')
        store.set_flag(FAIL_UNTIL_FLAG, '0')
    if any(pushed) or any(pulled):
        log('обмен: отправлено %d/%d/%d, принято %d/%d/%d'
            ' (просмотры/прогресс/оценки)' % (pushed + pulled))
    return True
