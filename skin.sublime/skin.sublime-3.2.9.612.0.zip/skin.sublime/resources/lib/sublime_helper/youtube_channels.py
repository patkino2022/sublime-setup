# -*- coding: utf-8 -*-
"""Имя и аватар канала YouTube без ключа Data API.

Значок канала в правом нижнем углу скин берёт из кэша дополнения YouTube
(vcl_service._youtube_channel_avatar). Дополнение кладёт туда каналы, только
когда само их запрашивает, а без своего ключа Data API - с 17.11.2026 через
запасной путь форка (resource_manager._keyless_channels) и только для своих
списков. Полосы скина («В тренде», «Новости», «В эфире», «Чарты», подписки)
идут мимо дополнения, и на чистой установке значков у них не было вовсе.

Здесь тот же внутренний API сайта (browse по id канала, без ключа): имя и
аватар, свой кэш в addon_data скина. На фокусе запрос не ждут - он идёт в
фоне, а готовый ответ публикуется, если строка всё ещё та же.
"""
from __future__ import absolute_import, unicode_literals

import io
import json
import os
import re
import threading
import time

import xbmc
from . import tls as _tls

_tls.install()   # https при испорченном хранилище сертификатов системы (Windows)

URL = 'https://www.youtube.com/youtubei/v1/browse?prettyPrint=false'
CLIENT = {'clientName': 'WEB', 'clientVersion': '2.20251110.01.00'}
TTL = 30 * 86400            # имя и аватар канала меняются редко
MISS_TTL = 86400            # неизвестный канал - не спрашивать сутки
TIMEOUT = 10
WORKERS = 6
_ID = re.compile(r'^UC[A-Za-z0-9_-]{22}$')

_lock = threading.RLock()
_memory = {'data': None, 'dirty': False}
_pending = set()


def _path():
    try:
        import xbmcvfs
        root = xbmcvfs.translatePath('special://profile/addon_data/skin.sublime/')
    except Exception:
        root = xbmc.translatePath('special://profile/addon_data/skin.sublime/')
    return os.path.join(root, 'youtube_channels.json')


def _load():
    with _lock:
        if _memory['data'] is None:
            try:
                with io.open(_path(), encoding='utf-8') as fh:
                    _memory['data'] = json.load(fh) or {}
            except (OSError, ValueError):
                _memory['data'] = {}
        return _memory['data']


def _save():
    with _lock:
        data = dict(_load())
    path = _path()
    tmp = path + '.part'
    try:
        with io.open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass


def get(channel_id):
    """{'title', 'avatar'} из кэша, {} - канал известен как пустой, None - не спрашивали."""
    channel_id = str(channel_id or '')
    if not _ID.match(channel_id):
        return {}
    item = _load().get(channel_id)
    if not item:
        return None
    age = time.time() - float(item.get('at') or 0)
    if age > (TTL if item.get('avatar') else MISS_TTL):
        return None
    return item


def _language():
    try:
        lang = xbmc.getLanguage(xbmc.ISO_639_1) or 'ru'
    except Exception:
        lang = 'ru'
    return lang, ('RU' if lang == 'ru' else lang.upper())


def fetch(channel_id):
    """Спросить канал у сайта и запомнить. Сетевой вызов - не с потока фокуса."""
    import urllib.request
    language, region = _language()
    body = {'context': {'client': dict(CLIENT, hl=language, gl=region)}, 'browseId': channel_id}
    request = urllib.request.Request(URL, data=json.dumps(body).encode('utf-8'),
                                     headers={'Content-Type': 'application/json',
                                              'User-Agent': 'Mozilla/5.0',
                                              'Origin': 'https://www.youtube.com'})
    item = {'at': int(time.time()), 'title': '', 'avatar': ''}
    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT) as answer:
            data = json.loads(answer.read().decode('utf-8'))
        meta = (data.get('metadata') or {}).get('channelMetadataRenderer') or {}
        avatars = (meta.get('avatar') or {}).get('thumbnails') or []
        url = avatars[-1].get('url') if avatars else ''
        if url and '=s' in url:
            url = re.sub(r'=s\d+', '=s240', url)
        item.update(title=meta.get('title') or '', avatar=url or '')
    except Exception as exc:
        xbmc.log('[sublime youtube channels] %s: %s' % (channel_id, exc), xbmc.LOGDEBUG)
        return None                         # сеть - не повод запомнить канал пустым
    with _lock:
        _load()[channel_id] = item
    return item


def request(channel_id, done=None):
    """Спросить в фоне; done(item) - когда ответ готов."""
    channel_id = str(channel_id or '')
    if not _ID.match(channel_id):
        return
    with _lock:
        if channel_id in _pending:
            return
        _pending.add(channel_id)

    def work():
        try:
            item = fetch(channel_id)
            if item is not None:
                _save()
                if done is not None:
                    done(item)
        finally:
            with _lock:
                _pending.discard(channel_id)
    threading.Thread(target=work, name='SublimeYoutubeChannel', daemon=True).start()


def prefetch(channel_ids, cancel=None):
    """Заранее, пачкой: каналы, которых ещё нет в кэше (заполнение кэшей)."""
    todo = [c for c in dict.fromkeys(str(c or '') for c in channel_ids)
            if _ID.match(c) and get(c) is None]
    if not todo:
        return 0
    from concurrent.futures import ThreadPoolExecutor
    done = [0]

    def one(channel_id):
        if cancel is not None and cancel():
            return
        if fetch(channel_id) is not None:
            done[0] += 1
    with ThreadPoolExecutor(max_workers=WORKERS) as pool:
        list(pool.map(one, todo))
    _save()
    return done[0]
