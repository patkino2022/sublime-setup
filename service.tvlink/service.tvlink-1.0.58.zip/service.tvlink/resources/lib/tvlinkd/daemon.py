"""service.tvlink daemon: playlists in, a stable channel list and TS streams out.

Runs as a child python3 process of the Kodi service so streaming never shares
the GIL with Kodi's add-ons. It exits by itself when the parent goes away.

  python3 -I tvlinkd_run.py daemon <userdata dir> <parent pid>
"""
import json
import os
import select
import socket
import subprocess
import sys
import threading
import zlib
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from html import escape
from urllib.parse import parse_qs, urlsplit

from . import catalog as cat
from . import groups
from . import hls, logos, net, resolvers, streamer
from .store import Paths, age_hours, load_config, mtime, read_json, write_atomic, write_json

# Канал inputstream.adaptive: какой тип источника выдан (dash/hls) и когда - чтобы
# перечитывание манифеста посреди сеанса не сменило тип (daemon.H.adaptive).
ADAPTIVE_STICKY = 30
_adaptive_kind = {}

GROUP_LOGOS = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "group_logos")


# Демоны, запущенные в процессе Kodi (не ELEC: Windows, Android, macOS - отдельного python3
# там нет): служба останавливает их через stop_all() при выключении или обновлении
_IN_PROCESS = []


def stop_all():
    for st in list(_IN_PROCESS):
        st.stop.set()


class State:
    def __init__(self, root, parent):
        self.paths = Paths(root)
        self.parent = parent
        # в процессе самого Kodi: нет /proc у Windows и macOS, и родитель - этот же процесс
        self.in_process = parent == os.getpid()
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.cfg = load_config(self.paths)
        self.catalog = {"channels": [], "headers": {}}
        self.index = {}
        self.playlist = b""
        self.cfg_mtime = 0.0
        self.arr_mtime = 0.0
        self.busy = set()
        self.epg_force = False
        self._logo_lock = threading.Lock()
        self.status = {"started": int(time.time())}
        # сведения о гиде переживают перезапуск: гид на диске тот же, а пересобирается
        # он только при изменении источника - без этого status.json после перезагрузки
        # коробки оставался без числа каналов и передач гида
        prev = read_json(self.paths.status, {}) or {}
        for k in ("epg_channels", "epg_programmes", "epg_built", "epg_sig"):
            if k in prev and os.path.exists(self.paths.xmltv):
                self.status[k] = prev[k]
        # files of the former stream check: channels it had hidden are shown again
        for name in ("health.json", "health_links.json"):
            try:
                os.unlink(os.path.join(self.paths.cache, name))
            except OSError:
                pass
        # отметка старта - на диск сразу: ожидающие список каналов сравнивают с ней built
        self.save_status()
        self._logf = open(self.paths.log, "a", encoding="utf-8", buffering=1)

    def log(self, msg):
        line = "%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
        try:
            if self._logf.tell() > 2 * 1024 * 1024:
                self._logf.close()
                os.replace(self.paths.log, self.paths.log + ".old")
                self._logf = open(self.paths.log, "a", encoding="utf-8", buffering=1)
            self._logf.write(line)
        except (OSError, ValueError):
            pass

    def alive(self):
        return not self.stop.is_set()

    # ---- catalog -------------------------------------------------------
    def rebuild(self, why):
        self.cfg = load_config(self.paths)
        c = cat.build(self.cfg, self.paths)
        text = cat.render_playlist(self.cfg, c, self.paths)
        with self.lock:
            self.catalog = c
            self.index = {ch["id"]: ch for ch in c["channels"]}
            if c["channels"]:
                self.playlist = text.encode("utf-8")
        if c["channels"]:
            write_atomic(self.paths.playlist, text)
        self.cfg_mtime, self.arr_mtime = mtime(self.paths.config), mtime(self.paths.channels)
        self.status.update(channels=len(c["channels"]), built=int(time.time()),
                           playlist_sig="%08x" % (zlib.crc32(text.encode("utf-8")) & 0xFFFFFFFF))
        self.save_status()
        self.log("catalog (%s): %d channels" % (why, len(c["channels"])))
        threading.Thread(target=self.prefetch_logos, daemon=True).start()

    def prefetch_logos(self):
        """Every logo on disk before Kodi asks, in the pack's style (logos.py)."""
        if not self._logo_lock.acquire(blocking=False):
            return
        try:
            with self.lock:
                chans = list(self.catalog["channels"])
            if logos.refresh(self, chans):
                self.rebuild("logos")
        finally:
            self._logo_lock.release()

    def save_status(self):
        try:
            write_json(self.paths.status, self.status)
        except OSError:
            pass

    def refresh_playlists(self):
        ok = 0
        for pl in self.cfg["playlists"]:
            try:
                data = _read_playlist(pl["url"], self.cfg["user_agent"])
                text = data.decode("utf-8", "replace")
                n = text.count("#EXTINF")
                if n == 0:
                    raise ValueError("no channels in reply")
                write_atomic(self.paths.source(pl["name"]), text)
                self.status.setdefault("sources", {})[pl["name"]] = {"links": n, "updated": int(time.time())}
                self.log("playlist %s: %d links" % (pl["name"], n))
                ok += 1
            except (OSError, ValueError) as e:
                self.status.setdefault("sources", {}).setdefault(pl["name"], {})["error"] = str(e)[:200]
                self.log("playlist %s: kept previous copy (%s)" % (pl["name"], e))
        self.rebuild("playlists")
        return ok

    def refresh_local(self):
        """Playlists shipped with the add-on or on disk are read at every start:
        an add-on update brings new ones (19.10.2026: Србија kept old tvg-ids
        for 8 h because only remote refresh times were looked at)."""
        changed = False
        for pl in self.cfg["playlists"]:
            if not _is_local(pl["url"]):
                continue
            try:
                text = _read_playlist(pl["url"], self.cfg["user_agent"]).decode("utf-8", "replace")
            except OSError as e:
                self.log("playlist %s: %s" % (pl["name"], e))
                continue
            dest = self.paths.source(pl["name"])
            try:
                with open(dest, encoding="utf-8") as f:
                    if f.read() == text:
                        continue
            except OSError:
                pass
            write_atomic(dest, text)
            self.log("playlist %s: local copy updated" % pl["name"])
            changed = True
        return changed

    def refresh_epg(self, force_build=False):
        """Parsing 100+ MB of XMLTV is CPU work: do it in a niced child so the
        streams in this process never wait for the GIL."""
        t0 = time.time()
        if self.in_process:
            # в процессе Kodi sys.executable - сам Kodi (на Windows запустился бы второй
            # kodi.exe), на Android он пустой: гид собирается здесь же, в этом потоке
            try:
                from . import epg
                res = epg.run_job(self.paths.root, force_build, nice=False)
            except Exception as e:
                res = {"error": str(e)[:200]}
        else:
            run = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tvlinkd_run.py")
            cmd = [sys.executable, "-I", run, "epg", self.paths.root] + (["force"] if force_build else [])
            if os.path.exists("/usr/bin/nice"):
                cmd = ["/usr/bin/nice", "-n", "19"] + cmd
            try:
                out = subprocess.run(cmd, capture_output=True, timeout=3600, text=True).stdout
                res = json.loads(out.strip().splitlines()[-1]) if out.strip() else {}
            except (OSError, ValueError, subprocess.TimeoutExpired) as e:
                res = {"error": str(e)[:200]}
        res["epg_checked"] = int(time.time())
        self.status.update(res)
        self.save_status()
        self.log("epg job %.0fs: %s" % (time.time() - t0, res))

    # ---- schedule ------------------------------------------------------
    def scheduler(self):
        while self.alive():
            try:
                if not self.in_process and not os.path.exists("/proc/%d" % self.parent):
                    self.log("parent gone, exiting")
                    self.stop.set()
                    break
                if mtime(self.paths.config) != self.cfg_mtime:
                    old = self.cfg
                    self.rebuild("settings")
                    if [p["url"] for p in old["playlists"]] != [p["url"] for p in self.cfg["playlists"]]:
                        self.refresh_playlists()
                    window = ("epg", "epg_past_days", "epg_future_days", "strip_suffixes")
                    if any(old.get(k) != self.cfg.get(k) for k in window):
                        self.refresh_epg(force_build=True)
                elif mtime(self.paths.channels) != self.arr_mtime:
                    self.rebuild("arrangement")
                if os.path.exists(self.paths.root + "/refresh.now"):
                    os.unlink(self.paths.root + "/refresh.now")
                    self.refresh_playlists()
                    self.refresh_epg(force_build=True)
                stale = max([age_hours(self.paths.source(p["name"])) for p in self.cfg["playlists"]] or [0])
                if self.cfg["playlists"] and stale >= self.cfg["refresh_hours"]:
                    self.refresh_playlists()
                # the guide follows Kodi's own update interval; sources answer
                # If-Modified-Since, so an unchanged guide costs one request each
                if time.time() - getattr(self, "_rts_checked", 0) >= 3 * 3600:
                    self._rts_checked = time.time()
                    resolvers.recheck(self.cfg["user_agent"])
                due = time.time() - self.status.get("epg_checked", 0) >= self.cfg["epg_interval_min"] * 60
                if self.status.get("channels") and (due or self.epg_force or not os.path.exists(self.paths.xmltv)):
                    self.refresh_epg(force_build=self.epg_force)
                    self.epg_force = False
            except Exception as e:  # keep serving whatever happens in the background
                self.log("scheduler: %r" % e)
            self.stop.wait(5)


def _handler(state, kind):
    class H(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.0"

        def log_message(self, fmt, *args):
            pass

        def _send(self, code, body=b"", ctype="text/plain; charset=utf-8", extra=None):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def do_POST(self):
            if True:   # sublime-setup: страницы привязки RTS нет
                return self._send(404, b"not found")
            n = int(self.headers.get("Content-Length") or 0)
            form = parse_qs(self.rfile.read(min(n, 4096)).decode("utf-8", "replace"))
            code = (form.get("uuid") or [""])[0].strip()
            if code:
                resolvers.set_uuid(code)
                state.log("rtsplaneta device code set")    # never the code itself
            return self.setup_page()

        def setup_page(self):
            uuid, signed, text = resolvers.status(state.cfg["user_agent"])
            body = SETUP_HTML % {"text": escape(text), "uuid": escape(uuid or "-"),
                                 "cls": "ok" if signed else "no"}
            return self._send(200, body.encode("utf-8"), "text/html; charset=utf-8")

        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            u = urlsplit(self.path)
            path = u.path.rstrip("/") or "/"
            if kind == "stream":
                return self.stream(path.strip("/"), parse_qs(u.query))
            if path == "/playlist" or path.endswith("/playlist") or "/playlist/" in path:
                with state.lock:
                    body = state.playlist
                if not body:
                    return self._send(503, b"not ready")
                return self._send(200, body, "audio/x-mpegurl; charset=utf-8")
            if path == "/xmltv.status":
                return self._send(200, self.xmltv_status().encode())
            if path == "/xmltv":
                return self.xmltv()
            if path.startswith("/logo/"):
                return self.logo(path[6:])
            if path == "/status":
                return self._send(200, json.dumps(state.status, ensure_ascii=False).encode(),
                                  "application/json")
            return self._send(404, b"not found")

        def _clients(self):
            return read_json(state.paths.clients, {}) or {}

        def xmltv_status(self):
            got = self._clients().get(self.client_address[0], 0)
            return "Updated" if got and got >= mtime(state.paths.xmltv) else "Needed"

        def xmltv(self):
            p = state.paths.xmltv
            try:
                with open(p, "rb") as f:
                    body = f.read()
            except OSError:
                return self._send(503, b"epg not ready")
            self._send(200, body, "application/gzip")
            cl = self._clients()
            cl[self.client_address[0]] = mtime(p)
            try:
                write_json(state.paths.clients, cl)
            except OSError:
                pass

        def logo(self, name):
            cid = name.rsplit(".", 1)[0].upper()
            f = os.path.join(state.paths.logos, cid + ".png")
            if cid.startswith(groups.LOGO_PREFIX):
                # канал без своего логотипа - логотип его группы из дополнения
                f = os.path.join(GROUP_LOGOS, cid[len(groups.LOGO_PREFIX):].lower() + ".png")
            if not os.path.exists(f):
                # the playlist names only files on disk (or 0000); answer at once
                return self._send(404, b"")
            with open(f, "rb") as fh:
                body = fh.read()
            return self._send(200, body, "image/png", {"Cache-Control": "max-age=86400"})

        def adaptive(self, ch):
            """Канал, который играет inputstream.adaptive (есть источник DASH).

            Источники - по порядку плейлиста: DASH отдаётся исправленным манифестом
            (hls.fix_dash_manifest), HLS - мастер-плейлистом с абсолютными адресами;
            тип inputstream.adaptive берёт из Content-Type. Пока сеанс идёт
            (манифест DASH перечитывается каждые несколько секунд), тип не меняется:
            сбой посреди сеанса - 502, inputstream.adaptive повторит запрос.
            """
            now = time.time()
            kept = _adaptive_kind.get(ch["id"])
            sticky = kept[0] if kept and now - kept[1] < ADAPTIVE_STICKY else None
            for link in ch["links"]:
                is_dash = urlsplit(link["url"]).path.lower().endswith(".mpd")
                if sticky and (sticky == "dash") != is_dash:
                    continue
                hdr = dict({"User-Agent": state.cfg["user_agent"]}, **(link.get("headers") or {}))
                try:
                    url = resolvers.resolve(link["url"], hdr["User-Agent"])
                    text, base = net.get_text(url, hdr, 15)
                    if is_dash:
                        if "<MPD" not in text[:2000]:
                            raise ValueError("not a DASH manifest")
                        body, ctype = hls.fix_dash_manifest(text, base), "application/dash+xml"
                    else:
                        if "#EXTM3U" not in text[:64]:
                            raise ValueError("not an HLS playlist")
                        body, ctype = hls.absolute_playlist(text, base), "application/vnd.apple.mpegurl"
                except Exception as e:
                    resolvers.forget(link["url"])
                    state.log("[%s] src=%s dead: %s" % (ch["title"], link["src"], e))
                    continue
                if not kept or kept[0] != ("dash" if is_dash else "hls"):
                    state.log("[%s] adaptive %s src=%s" % (ch["title"], "dash" if is_dash else "hls", link["src"]))
                _adaptive_kind[ch["id"]] = ("dash" if is_dash else "hls", now)
                return self._send(200, body.encode("utf-8"), ctype, {"Cache-Control": "no-cache"})
            state.log("[%s] no working source" % ch["title"])
            return self._send(502, b"")

        def stream(self, cid, q):
            with state.lock:
                ch = state.index.get(cid.upper())
            if not ch:
                return self._send(404, b"unknown channel")
            utc = None
            if "utc" in q:
                try:
                    utc = int(q["utc"][0])
                except ValueError:
                    utc = None
                if utc and utc >= time.time() - 5:
                    utc = None
            if cat.dash_link(ch):
                return self.adaptive(ch)
            self.send_response(200)
            self.send_header("Content-Type", "video/mp2t")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            if self.command == "HEAD":
                return
            if utc is None:
                threading.Thread(target=_warm_neighbours, args=(state, ch), daemon=True).start()
            gone = threading.Event()
            sock = self.connection

            def alive():
                if not state.alive() or gone.is_set():
                    return False
                # Kodi closing the channel shows as EOF on our socket; noticing it
                # only at the next write kept the upstream session open ~5 s, and
                # Glanz then refused the next start of that channel with 403
                try:
                    r, _, _ = select.select([sock], [], [], 0)
                    if r and not sock.recv(1, socket.MSG_PEEK):
                        gone.set()
                        return False
                except OSError:
                    gone.set()
                    return False
                return True
            try:
                streamer.serve(ch, self.wfile, state.cfg, state.log, alive, utc)
            finally:
                gone.set()

    return H


RESOURCES = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


def _is_local(url):
    return url.startswith(("addon:", "file://", "/")) or (len(url) > 2 and url[1] == ":")


def _read_playlist(url, ua):
    """http(s) URL, a local path, or addon:<file> shipped in resources/ (Serbia)."""
    if url.startswith("addon:"):
        url = os.path.join(RESOURCES, os.path.basename(url[6:]))
    if url.startswith("file://"):
        url = url[7:]
    if url.startswith("/") or (len(url) > 2 and url[1] == ":"):
        with open(url, "rb") as f:
            return f.read(32 * 1024 * 1024)
    req = urllib.request.Request(url, headers={"User-Agent": ua})
    with urllib.request.urlopen(req, timeout=30) as r:
        return r.read(32 * 1024 * 1024)


def _warm_neighbours(state, ch):
    """Zapping goes to the next or previous number: resolve those now."""
    time.sleep(1.5)   # the channel being opened goes first
    with state.lock:
        chans = state.catalog["channels"]
    i = ch["num"] - 1
    for j in (i + 1, i - 1):
        if 0 <= j < len(chans) and chans[j]["links"]:
            ln = chans[j]["links"][0]
            hls.warm(ln["url"], dict({"User-Agent": state.cfg["user_agent"]}, **(ln.get("headers") or {})),
                     state.cfg["timeout"])


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


SETUP_HTML = """<!doctype html><html lang=ru><head><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1"><title>TVLink - RTS Planeta</title>
<style>body{font:16px system-ui,sans-serif;max-width:30em;margin:2em auto;padding:0 1em;background:#16191f;color:#e8e8e8}
.ok{color:#5fd38d}.no{color:#f0b35a}code{background:#22262e;padding:.2em .4em;border-radius:4px}</style></head>
<body><h2>RTS Planeta</h2><p class=%(cls)s>%(text)s</p><p>Код устройства сейчас: <code>%(uuid)s</code></p>
<form method=post action=/setup><label>Код устройства из браузера, где выполнен вход в RTS Planeta
<input name=uuid autocomplete=off style="width:100%%;box-sizing:border-box;padding:.6em;margin:.3em 0 1em;font-size:16px;border-radius:6px;border:1px solid #555;background:#22262e;color:#fff"></label>
<button type=submit style="padding:.7em 1.4em;font-size:16px;border:0;border-radius:6px;background:#3b82f6;color:#fff">Сохранить и проверить</button></form>
<p style="opacity:.6;font-size:13px">Вход в аккаунт RTS привязывает к нему этот uuid (страница /obw сайта rtsplaneta.rs).
Пароль на коробке не хранится.</p></body></html>"""


def main(root, parent):
    st = State(root, parent)
    if st.in_process:
        _IN_PROCESS.append(st)
    resolvers.ROOT = root
    st.log("start pid=%d" % os.getpid())
    # serve the last good playlist at once: pvr.tvlink asks right after Kodi starts
    # and does not ask again until its next refresh hour
    try:
        with open(st.paths.playlist, "rb") as f:
            st.playlist = f.read()
    except OSError:
        pass
    servers = []
    for port, kind in ((st.cfg["port"], "api"), (st.cfg["stream_port"], "stream")):
        # вне ELEC - только для этого устройства: на Windows и macOS прослушивание всех адресов
        # поднимает запрос брандмауэра, а плейлист нужен лишь ТВ-клиенту здесь же
        srv = Server(("127.0.0.1" if st.in_process else "0.0.0.0", port), _handler(st, kind))
        servers.append(srv)
        threading.Thread(target=srv.serve_forever, kwargs={"poll_interval": 0.5}, daemon=True).start()
    st.log("listening on %d/%d" % (st.cfg["port"], st.cfg["stream_port"]))
    st.epg_force = st.refresh_local()
    st.rebuild("start")
    if not st.catalog["channels"] and st.cfg["playlists"]:
        st.refresh_playlists()
    try:
        st.scheduler()
    finally:
        for s in servers:
            s.shutdown()
            try:
                s.server_close()
            except OSError:
                pass
        if st in _IN_PROCESS:
            _IN_PROCESS.remove(st)
        st.log("stopped")


if __name__ == "__main__":
    main(sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else os.getppid())
