# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import hashlib
import re
import time

import xbmc


# Trakt is removed from the skin. It allows a single connected application per
# account, and the skin was registered as its own application separate from
# plugin.video.filmix: each authorization revoked the other, which is what kept
# killing the plug-in's session on both boxes. The plug-in owns the Trakt
# connection now, and it is the one that needs it - watched state and
# recommendations. Without a client id use_trakt() is false, so no request and
# no device-code authorization can be made from here.

SKIN_SETTING_KEYS = {
    'metadata.language': 'SublimeHelper.MetadataLanguage',
    'metadata.region': 'SublimeHelper.MetadataRegion',
    'metadata.cache_hours': 'SublimeHelper.CacheHours',
    'metadata.timeout': 'SublimeHelper.RequestTimeout',
    'metadata.primary_source': 'SublimeHelper.MetadataPrimarySource',
    'metadata.priority.tmdb': 'SublimeHelper.MetadataPriorityTMDb',
    'metadata.priority.kinopoisk': 'SublimeHelper.MetadataPriorityKinopoisk',
    'metadata.priority.imdb': 'SublimeHelper.MetadataPriorityIMDb',
    'metadata.artwork_source': 'SublimeHelper.ArtworkPrimarySource',
    'metadata.rating_source': 'SublimeHelper.RatingPrimarySource',
    'api.tmdb_key': 'SublimeHelper.Api.TMDbKey',
    'api.tmdb_token': 'SublimeHelper.Api.TMDbToken',
    'api.fanart_key': 'SublimeHelper.Api.FanartKey',
    'api.fanart_client_key': 'SublimeHelper.Api.FanartClientKey',
    'api.omdb_key': 'SublimeHelper.Api.OMDbKey',
    'api.kinopoisk_key': 'SublimeHelper.Api.KinopoiskKey',
    'api.kinopoisk_dev_key': 'SublimeHelper.Api.KinopoiskDevKey',
    'api.mdblist_key': 'SublimeHelper.Api.MDBListKey',
    'integration.youtube_addon': 'SublimeHelper.Integration.YouTubeAddon',
}


def skin_string(key, default=''):
    try:
        # Not xbmc.getInfoLabel: see docs/CRASH_GETINFOLABEL_2026-08-23.md.
        from .core import read_label
        value = read_label('Skin.String(%s)' % key) or ''
        return value if value else default
    except Exception:
        return default


def set_skin_string(key, value):
    value = str(value or '')
    try:
        if value:
            escaped = value.replace('\\', '\\\\').replace('"', '\\"')
            xbmc.executebuiltin('Skin.SetString(%s,"%s")' % (key, escaped))
        else:
            xbmc.executebuiltin('Skin.Reset(%s)' % key)
    except Exception:
        pass


def set_setting(key, value):
    skin_key = SKIN_SETTING_KEYS.get(key)
    if skin_key:
        set_skin_string(skin_key, value)
        invalidate_provider_signature()

def setting(key, default=''):
    skin_key = SKIN_SETTING_KEYS.get(key)
    return skin_string(skin_key, default) if skin_key else default


def setting_int(key, default=0):
    try:
        value = setting(key, '')
        return int(value) if value not in (None, '') else default
    except Exception:
        return default


def language():
    value = setting('metadata.language', '')
    if value:
        return value
    try:
        iso = xbmc.getLanguage(xbmc.ISO_639_1, region=True) or 'en-GB'
        return iso.replace('_', '-')
    except Exception:
        return 'en-GB'


def region():
    value = setting('metadata.region', '')
    if value:
        return value.upper()
    lang = language()
    if '-' in lang:
        return lang.split('-', 1)[1].upper()
    return 'US'


def primary_source():
    value = setting('metadata.primary_source', '').strip().lower()
    return value if value in ('tmdb', 'kinopoisk', 'imdb') else 'auto'


def metadata_priority(source):
    defaults = {'tmdb': 1, 'kinopoisk': 2, 'imdb': 3}
    source = str(source or '').strip().lower()
    if source not in defaults:
        return 99
    raw = setting('metadata.priority.%s' % source, '')
    if raw in (None, ''):
        # Backward-compatible migration from the former single primary-source setting.
        old_primary = primary_source()
        if old_primary in defaults:
            ordered = [old_primary] + [name for name in ('tmdb', 'kinopoisk', 'imdb') if name != old_primary]
            return ordered.index(source) + 1
        return defaults[source]
    try:
        return max(1, min(99, int(raw)))
    except Exception:
        return defaults[source]


def metadata_source_priorities():
    canonical = ('tmdb', 'kinopoisk', 'imdb')
    return sorted(canonical, key=lambda source: (metadata_priority(source), canonical.index(source)))

def artwork_source():
    value = setting('metadata.artwork_source', '').strip().lower()
    return value if value in ('fanart', 'tmdb', 'kinopoisk', 'imdb') else 'auto'


def rating_source():
    value = setting('metadata.rating_source', '').strip().lower()
    # 'trakt' is no longer a selectable source; a profile still carrying it
    # falls back to 'auto' rather than selecting a provider that never answers.
    return value if value in ('kinopoisk', 'imdb', 'tmdb', 'mdblist') else 'auto'


def cache_hours():
    return max(1, setting_int('metadata.cache_hours', 24))


def request_timeout():
    return max(3, min(30, setting_int('metadata.timeout', 10)))


def online_enabled():
    return not xbmc.getCondVisibility('Skin.HasSetting(SublimeHelper.DisableOnline)')


def hide_adult():
    """Hide provider entries explicitly marked as adult content.

    Enabled by default. Users can opt in to adult metadata/artwork by setting
    SublimeHelper.AllowAdult in the skin settings UI.
    """
    return not xbmc.getCondVisibility('Skin.HasSetting(SublimeHelper.AllowAdult)')


def pvr_lookups_enabled():
    """Return the user-facing PVR SublimeHelper lookup setting."""
    return not xbmc.getCondVisibility('Skin.HasSetting(SublimeHelper.DisablePVR)')


# Ключ проекта sublime в TMDb (выдан для раздачи вместе со сборкой, 15.11.2026):
# без него у пользователя без своих ключей нет описаний, рейтингов, фонов, логотипов
# и трейлеров. Свой ключ из настроек скина главнее.
DEFAULT_TMDB_KEY = 'a3645e125eb4f041712a79bad226c3fe'


def tmdb_key():
    return setting('api.tmdb_key', '').strip() or DEFAULT_TMDB_KEY


def tmdb_token():
    return setting('api.tmdb_token', '').strip()


DEFAULT_FANART_KEY = 'd442432dbe5b92cf14219e6772cc5a9e'   # ключ проекта sublime в fanart.tv


def fanart_key():
    return setting('api.fanart_key', '').strip() or DEFAULT_FANART_KEY


def fanart_client_key():
    return setting('api.fanart_client_key', '').strip()


def omdb_key():
    return setting('api.omdb_key', '').strip()


def kinopoisk_key():
    return setting('api.kinopoisk_key', '').strip()


def kinopoisk_dev_key():
    """Ключ kinopoisk.dev - второго API Кинопоиска.

    Заведён 07.09.2026: у kinopoiskapiunofficial норма 500 запросов в сутки, и
    она исчерпывается («provider=kinopoisk status=quota_exhausted» в журнале
    .30). У kinopoisk.dev норма выше, а данные те же, поэтому при наличии
    этого ключа он идёт первым, а прежний остаётся запасным.
    """
    return setting('api.kinopoisk_dev_key', '').strip()


def mdblist_key():
    return setting('api.mdblist_key', '').strip()


def youtube_addon():
    return setting('integration.youtube_addon', 'plugin.video.youtube').strip() or 'plugin.video.youtube'


_YOUTUBE_VIDEO_ID = re.compile(r'[?&](?:video_id|v)=([A-Za-z0-9_-]{11})(?:[&#]|$)')


def youtube_play_url(video_id):
    """Адрес ролика YouTube - родной путь дополнения 8 (play?v=ID), тот же, что у его собственных
    списков: так у ролика одна запись в базе просмотров Kodi, откуда бы его ни открыли."""
    return 'plugin://%s/play?v=%s' % (youtube_addon(), video_id)


def youtube_video_id(path):
    """Идентификатор ролика из адреса дополнения YouTube: play?v=ID (8) и play/?video_id=ID (7).
    Только для адресов plugin.video.youtube - у других дополнений v= может значить своё."""
    path = str(path or '')
    if 'plugin.video.youtube/' not in path:
        return ''
    hit = _YOUTUBE_VIDEO_ID.search(path)
    return hit.group(1) if hit else ''


def use_fanart():
    return (not xbmc.getCondVisibility('Skin.HasSetting(SublimeHelper.DisableFanart)')) and bool(fanart_key())


def use_omdb():
    return (not xbmc.getCondVisibility('Skin.HasSetting(SublimeHelper.DisableOMDb)')) and bool(omdb_key())


def use_kinopoisk():
    # Годится ключ любой из двух служб: kinopoisk.dev самостоятелен и умеет
    # и поиск, и подробности. 07.09.2026 проверка на .30 показала, что
    # привязка только к прежнему ключу выключала бы Кинопоиск целиком у
    # владельца, оставившего один kinopoisk.dev.
    if xbmc.getCondVisibility('Skin.HasSetting(SublimeHelper.DisableKinopoisk)'):
        return False
    return bool(kinopoisk_key()) or bool(kinopoisk_dev_key())


def use_mdblist():
    return (not xbmc.getCondVisibility('Skin.HasSetting(SublimeHelper.DisableMDBList)')) and bool(mdblist_key())


_PROVIDER_SIGNATURE = ''
_PROVIDER_SIGNATURE_AT = 0.0
_PROVIDER_SIGNATURE_TTL = 2.0


def invalidate_provider_signature():
    global _PROVIDER_SIGNATURE, _PROVIDER_SIGNATURE_AT
    _PROVIDER_SIGNATURE = ''
    _PROVIDER_SIGNATURE_AT = 0.0


def feature_requested(name):
    setting_name = {'cast': 'VCL.ActionButtons.DisableCast', 'trailer': 'VCL.ActionButtons.DisableTrailer'}.get(str(name or '').lower())
    return True if not setting_name else not xbmc.getCondVisibility('Skin.HasSetting(%s)' % setting_name)


def rating_requested(source):
    """Return whether a provider is needed by the selected or visible rating fields."""
    source = str(source or '').strip().lower()
    if not source:
        return False
    selected = rating_source()
    visible = set()
    for content in ('Movies', 'TVShows'):
        for index in range(1, 7):
            value = skin_string('CustomRating.%s.Item%02d' % (content, index), '').strip().lower()
            if value and value != 'none':
                visible.add(value)
    if selected == source or source in visible:
        return True
    omdb_fields = {'imdb', 'metacritic', 'rottentomatoescritic', 'rottentomatoesuser', 'awards'}
    if source == 'imdb':
        return bool(visible & omdb_fields)
    if source == 'mdblist':
        if visible & {'mdblist', 'letterboxd'}:
            return True
        # MDBList is the fallback source for these scores when OMDb is unavailable.
        return (not use_omdb()) and bool(visible & {'metacritic', 'rottentomatoescritic', 'rottentomatoesuser'})
    return False


def provider_signature():
    """Cached non-secret fingerprint; direct Skin.SetString changes settle within two seconds."""
    global _PROVIDER_SIGNATURE, _PROVIDER_SIGNATURE_AT
    now = time.time()
    if _PROVIDER_SIGNATURE and now - _PROVIDER_SIGNATURE_AT < _PROVIDER_SIGNATURE_TTL:
        return _PROVIDER_SIGNATURE
    custom_ratings = tuple(
        skin_string('CustomRating.%s.Item%02d' % (content, index), '')
        for content in ('Movies', 'TVShows') for index in range(1, 7)
    )
    values = (
        # Bump this literal whenever an identity-chain code change would make a
        # previously-cached final-metadata blob wrong - it feeds every
        # SublimeHelper.*.Key, which the worker's on-disk cache (14-day TTL) and
        # in-memory results dict are both keyed by. v5->v6: the 2026-08-16
        # episode-identity fixes (series matched by show title, not the raw
        # "Серия N" row label; the path/post year no longer used as a hard
        # identity gate) changed what a resolved episode row should look like,
        # but nothing before this bump invalidated what was already cached under
        # the OLD, wrong rules. Measured live: «Хождение по мукам» kept
        # publishing SublimeHelper.Player.Title="Серия 3" during playback long
        # after the code was fixed, because the disk-cached blob from before the
        # fix was still within its TTL and got served as-is.
        # Отпечаток сменился вместе с уходом Trakt, то есть дисковый кеш
        # метаданных считается устаревшим и будет перечитан один раз.
        # v7->v8: логотипы САМОГО СЕРИАЛА пошли в общий список кандидатов
        # (core.py, ветка tvshow_art), и старые записи кэша об этом не знают -
        # у них в art.clearlogo лежит английский логотип, выбранный когда
        # русского в кандидатах не было вовсе. Без подъёма отпечатка правка
        # проявилась бы только через 14 дней, по истечении их срока.
        'metadata-identity-art-v7',
        online_enabled(), hide_adult(), pvr_lookups_enabled(), language(), region(), cache_hours(), request_timeout(),
        tuple((source, metadata_priority(source)) for source in ('tmdb', 'kinopoisk', 'imdb')), artwork_source(), rating_source(),
        tmdb_key(), tmdb_token(), fanart_key(), fanart_client_key(), omdb_key(), kinopoisk_key(), kinopoisk_dev_key(), mdblist_key(),
        use_fanart(), use_omdb(), use_kinopoisk(), use_mdblist(), youtube_addon(),
        feature_requested('cast'), feature_requested('trailer'), custom_ratings,
    )
    _PROVIDER_SIGNATURE = hashlib.sha1(repr(values).encode('utf-8', 'ignore')).hexdigest()[:12]
    _PROVIDER_SIGNATURE_AT = now
    return _PROVIDER_SIGNATURE
