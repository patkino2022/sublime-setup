# -*- coding: utf-8 -*-
"""Память студий: раз узнав студию фильма, помним её для любой полосы.

ЗАЧЕМ

Логотип студии рисуется по ИМЕНИ студии. У строк, которые собрал наш фоновый
сборщик, имя лежит прямо в строке (Sublime.Studio), поэтому логотип появляется
мгновенно - так же, как логотип канала у YouTube. Но есть полосы, которые
сборщик не трогает вовсе: «Избранное» и «Отложенные» провайдера - живые списки,
их снимок вреден (человек нажал - тайл обязан измениться сразу, hub/mirror.py,
category). Владелец это и увидел: «в избранном у сериалов нет студио лого»,
затем - «появились, но сильно позже, чем в списке Все».

Здесь общая память: сборщик, узнав студию для фильма, записывает её сюда, а
служба на фокусе спрашивает по названию и году. Тот же фильм в «Избранном»
получает логотип сразу, потому что его студию мы уже узнали в другой полосе.

ЧЕСТНО О ТОЧНОСТИ

Ключ - название и год, то же самое, чем скин опознаёт строку везде
(hub/identity.py). Два разных фильма с одним названием и годом дали бы одну
студию на двоих - цена ошибки здесь ровно один логотип в углу, и она не
сравнится с ожиданием опознания на каждом наведении.
"""
from __future__ import absolute_import, unicode_literals

import io
import json
import os
import threading

import xbmc
import xbmcvfs

from .config import log

FILE = 'special://profile/addon_data/skin.sublime/studios.json'
# Столько имён держим. Каталог владельца - около 17 тысяч строк, но студия
# нужна только тому, что он видел; при переполнении старое просто забывается.
LIMIT = 4000

_LOCK = threading.Lock()
_MEMORY = {'rows': None, 'dirty': False}


def _path():
    return xbmcvfs.translatePath(FILE)


def _load():
    if _MEMORY['rows'] is not None:
        return _MEMORY['rows']
    rows = {}
    try:
        path = _path()
        if os.path.isfile(path):
            with io.open(path, encoding='utf-8') as handle:
                data = json.load(handle)
            if isinstance(data, dict):
                rows = dict(data)
    except Exception as exc:
        log('память студий не прочитана: %s' % exc, xbmc.LOGDEBUG)
        rows = {}
    _MEMORY['rows'] = rows
    return rows


def key_for(title, year=''):
    """Ключ строки. Пусто - значит запоминать нечего."""
    name = ' '.join(str(title or '').split()).strip().lower()
    if not name:
        return ''
    digits = ''.join(ch for ch in str(year or '') if ch.isdigit())[:4]
    return '%s|%s' % (name, digits)


def lookup(title, year=''):
    key = key_for(title, year)
    if not key:
        return ''
    with _LOCK:
        return str(_load().get(key) or '')


def remember(title, year, studio):
    """Запомнить студию. Пустое имя ничего не стирает."""
    key = key_for(title, year)
    studio = str(studio or '').strip()
    if not key or not studio:
        return False
    with _LOCK:
        rows = _load()
        if rows.get(key) == studio:
            return False
        rows[key] = studio
        _MEMORY['dirty'] = True
        if len(rows) > LIMIT:
            # Простое ограничение: половину самых старых записей забываем.
            for old in list(rows)[:len(rows) // 2]:
                rows.pop(old, None)
    return True


def flush():
    """Сохранить, если что-то менялось. Зовётся фоновыми проходами."""
    with _LOCK:
        if not _MEMORY['dirty'] or _MEMORY['rows'] is None:
            return False
        rows = dict(_MEMORY['rows'])
        _MEMORY['dirty'] = False
    try:
        path = _path()
        folder = os.path.dirname(path)
        if folder and not os.path.isdir(folder):
            os.makedirs(folder)
        tmp = path + '.tmp'
        with io.open(tmp, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(rows, ensure_ascii=False))
        os.replace(tmp, path)
        return True
    except Exception as exc:
        log('память студий не сохранена: %s' % exc, xbmc.LOGWARNING)
        return False
