# -*- coding: utf-8 -*-
"""Готовые выдачи вкладок хабов: служба собирает их заранее, маршрут отдаёт готовое.

ЗАЧЕМ

При открытии хаба Kodi сразу запускает выдачу всех его вкладок, и каждая выдача заново считает
состояние просмотра, качество релизов, вид строк и прочее: 0,5-1 с процессора на вкладку. Пять
вкладок параллельно душили друг друга, и первая полоса стояла тёмной 2,5-3,7 с (замер .30,
22.11.2026). Владелец: «нужно, чтобы были уже собранные. Так же и для обновлений вкладок».

КАК

Служба (hub/service.py) вызывает тот же маршрут, что и Kodi, но в своей копии модуля routes, где
xbmcgui.ListItem и xbmcplugin подменены записывающими двойниками (_Item, _Plugin). Всё, что маршрут
сделал со строками, - метки, картинки, свойства, InfoTag, контекстное меню - пишется в файл выдачи
вместе с отпечатком входных данных. Маршрут в Kodi сначала смотрит файл: отпечаток совпал - строки
воспроизводятся теми же вызовами (десятки миллисекунд), нет - считает по-старому. Логика выдачи
одна, второй копии нет.

Отпечаток - время изменения и размер входов. Состояние просмотра (общая база скина и база Kodi)
обязано быть точным - его изменение сразу делает выдачу недействительной. Остальное (снимки,
хранилище строк, база хаба, кэш провайдера) меняется часто и понемногу: выдача с ним годится до
STALE_OK секунд, служба за это время её пересобирает.
"""
from __future__ import absolute_import, unicode_literals

import glob
import hashlib
import importlib.util
import json
import os
import threading
import time

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from .config import log

FOLDER = 'special://profile/addon_data/skin.sublime/listings/'
SEEN_FILE = 'special://profile/addon_data/skin.sublime/listings/seen.json'
def _version():
    """Формат и версия скина: выдача, собранная прежней версией, не отдаётся - иначе исправление
    строк доходило до экрана только через FORCE_REFRESH + STALE_OK (до 17 мин) после выкладки."""
    try:
        import xbmcaddon
        return '2|' + (xbmcaddon.Addon('skin.sublime').getAddonInfo('version') or '')
    except Exception:
        return '2|'


VERSION = _version()
SLOW_REBUILD = 300      # из-за «медленных» входов пересобирать не чаще: база хаба переписывается каждые
                        # 90 с долива, даже без новинок, - выдачи пересобирались каждые 1-2 мин (.30, 23.11.2026)
STALE_OK = 420          # сколько выдача годится при изменившихся «медленных» входах, с (SLOW_REBUILD с запасом)
FORCE_REFRESH = 600     # и пересобирается не реже - доходят данные Filmix, которых нет во входах
RENDERED_ROUTES = ('hub_lane', 'hub_widget', 'hub_continue', 'hub_smart')
_SKIP_PARAMS = ('selftest',)
_LOCK = threading.Lock()


def _path(name):
    return os.path.join(xbmcvfs.translatePath(FOLDER), name)


def key_of(params):
    """Ключ выдачи по параметрам маршрута (без служебных)."""
    clean = sorted((str(k), str(v)) for k, v in (params or {}).items() if k not in _SKIP_PARAMS)
    return hashlib.sha1(json.dumps(clean, ensure_ascii=False).encode('utf-8')).hexdigest()[:20]


def wanted(params):
    params = params or {}
    if any(k in params for k in _SKIP_PARAMS):
        return False
    return (params.get('info') or params.get('action') or '') in RENDERED_ROUTES


# ---- входы и отпечаток ---------------------------------------------------------------------

def _stat(path):
    try:
        info = os.stat(path)
        return [int(info.st_mtime * 1000), int(info.st_size)]
    except OSError:
        return [0, 0]


def _inputs():
    """(точные входы, медленные входы) - списки путей."""
    data = xbmcvfs.translatePath('special://profile/addon_data/skin.sublime/')
    # settings.xml - не точный вход: Kodi переписывает его каждые несколько десятков секунд без
    # изменения содержимого, и готовые выдачи после запуска все считались устаревшими (.30, 22.11.2026)
    exact = [os.path.join(data, name) for name in ('watch_by_title.json', 'watch_episodes.json',
                                                     'watch_names.json')]
    db = xbmcvfs.translatePath('special://profile/Database/')
    exact += sorted(glob.glob(os.path.join(db, 'MyVideos*.db')))[-1:]
    exact += [p + '-wal' for p in exact[-1:] if p.endswith('.db')]
    slow = [os.path.join(data, name) for name in ('row_store.db', 'row_store.db-wal', 'hub_state.db',
                                                    'hub_state.db-wal', 'continue_art.json',
                                                    'show_totals.json', 'settings.xml')]
    slow.append(os.path.join(data, 'widget_mirror'))
    # Базы Filmix во входах не участвуют: он пишет в них каждые 12-15 с, и выдачи пересобирались
    # раз в минуту (около 600 сборок в час, .20, 23.11.2026). Его данные (счёт серий, отметки с сайта)
    # доходят пересборкой не реже FORCE_REFRESH; отметки Kodi - точный вход, сразу.
    return exact, slow


def stamp():
    exact, slow = _inputs()
    return {'exact': [_stat(p) for p in exact], 'slow': [_stat(p) for p in slow]}


# ---- запись: двойники ListItem и xbmcplugin ------------------------------------------------

class _Tag(object):
    def __init__(self, calls):
        self._calls = calls
        self._values = {}

    def __getattr__(self, name):
        if name.startswith(('set', 'add')):
            def record(*args, **kwargs):
                self._calls.append(['tag', name, list(args), kwargs])
                if args:
                    self._values[name[3:].lower()] = args[0]
            return record
        if name.startswith('get'):
            key = name[3:].lower()
            return lambda *a, **k: self._values.get(key, 0 if 'count' in key or 'year' in key else '')
        raise AttributeError(name)


class _Item(object):
    def __init__(self, label='', label2='', path='', offscreen=False):
        self.calls = []
        self.ctor = {'label': label, 'label2': label2, 'path': path}
        self._props = {}
        self._label = label
        self._tag = None

    def getVideoInfoTag(self):
        if self._tag is None:
            self._tag = _Tag(self.calls)
        return self._tag

    def getProperty(self, key):
        return self._props.get(str(key).lower(), '')

    def getLabel(self):
        return self._label

    def __getattr__(self, name):
        if name.startswith(('set', 'add')):
            def record(*args, **kwargs):
                if name == 'setProperty' and len(args) >= 2:
                    self._props[str(args[0]).lower()] = args[1]
                if name == 'setLabel' and args:
                    self._label = args[0]
                self.calls.append(['li', name, list(args), kwargs])
            return record
        if name.startswith('get'):
            return lambda *a, **k: ''
        raise AttributeError(name)


class _GuiModule(object):
    """xbmcgui, в котором ListItem пишет вызовы; остальное - настоящее."""
    ListItem = _Item

    def __getattr__(self, name):
        return getattr(xbmcgui, name)


class _PluginModule(object):
    def __init__(self):
        self.items = []
        self.meta = {'content': '', 'sort': [], 'succeeded': True}

    def addDirectoryItem(self, handle, url, listitem, isFolder=False, totalItems=0):
        self.items.append({'url': url, 'folder': bool(isFolder), 'ctor': listitem.ctor,
                           'calls': listitem.calls})
        return True

    def addDirectoryItems(self, handle, items, totalItems=0):
        for entry in items:
            self.addDirectoryItem(handle, *entry)
        return True

    def setContent(self, handle, content):
        self.meta['content'] = content

    def addSortMethod(self, handle, method, *args, **kwargs):
        self.meta['sort'].append(int(method))

    def endOfDirectory(self, handle, succeeded=True, *args, **kwargs):
        self.meta['succeeded'] = bool(succeeded)

    def __getattr__(self, name):
        if name.startswith(('set', 'add')):
            return lambda *a, **k: None
        return getattr(xbmcplugin, name)


_RENDER_MODULE = {}


def _render_routes():
    """Своя копия routes с двойниками - чтобы не трогать модуль, которым пользуется служба."""
    mod = _RENDER_MODULE.get('mod')
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'routes.py')
    stamp_ = os.path.getmtime(path)
    if mod is None or _RENDER_MODULE.get('stamp') != stamp_:
        spec = importlib.util.spec_from_file_location(__package__ + '._routes_render', path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        _RENDER_MODULE.update(mod=mod, stamp=stamp_)
    return mod


def render(params):
    """Собрать выдачу маршрута и записать её в файл. True - записано."""
    if not wanted(params):
        return False
    with _LOCK:
        before = stamp()
        mod = _render_routes()
        plugin = _PluginModule()
        mod.xbmcgui = _GuiModule()
        mod.xbmcplugin = plugin
        ok = bool(mod.run(-7, dict(params)))
        if not ok or not plugin.meta.get('succeeded') or not plugin.items:
            return False
        payload = {'version': VERSION, 'params': params, 'stamp': before, 'built_at': time.time(),
                   'meta': plugin.meta, 'items': plugin.items}
        target = _path(key_of(params) + '.json')
        try:
            os.makedirs(os.path.dirname(target), exist_ok=True)
            tmp = '%s.%d.tmp' % (target, threading.get_ident())
            with open(tmp, 'w', encoding='utf-8') as handle:
                json.dump(payload, handle, ensure_ascii=False)
            os.replace(tmp, target)
        except (OSError, TypeError, ValueError) as exc:
            log('готовая выдача не записана %s: %s' % (params.get('info'), exc), xbmc.LOGWARNING)
            return False
    return True


# ---- выдача в Kodi --------------------------------------------------------------------------

_LOADED = {}


def _load(params):
    """Готовая выдача из файла. В долгоживущей службе разобранный файл помнится по времени записи:
    проход раз в 15 с разбирал JSON всех выдач (сотни КБ) ради отпечатка (аудит 23.11.2026)."""
    path = _path(key_of(params) + '.json')
    try:
        mark = _stat(path)
        memo = _LOADED.get(path)
        if memo is not None and memo[0] == mark and mark[0]:
            return memo[1]
        with open(path, encoding='utf-8') as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return None
    data = data if isinstance(data, dict) and data.get('version') == VERSION else None
    _LOADED[path] = (mark, data)
    return data


def fresh(data, now_stamp=None, now=None):
    """Годится ли выдача: точные входы не менялись, медленные - не старше STALE_OK."""
    if not data:
        return False
    now_stamp = now_stamp or stamp()
    saved = data.get('stamp') or {}
    if saved.get('exact') != now_stamp['exact']:
        return False
    if saved.get('slow') == now_stamp['slow']:
        # входы те же, но данных Filmix во входах нет - выдача годится FORCE_REFRESH с запасом
        return (now or time.time()) - float(data.get('built_at') or 0) <= FORCE_REFRESH + STALE_OK
    return (now or time.time()) - float(data.get('built_at') or 0) <= STALE_OK


def serve(handle, params):
    """Отдать готовую выдачу. True - отдано (маршрут не нужен)."""
    if not wanted(params):
        return False
    remember(params)
    data = _load(params)
    if not fresh(data):
        return False
    # сначала все строки, потом одним вызовом: сбой посреди сборки (InfoTag отверг аргумент)
    # раньше оставлял часть строк уже добавленной, и полный маршрут добавлял их ещё раз - список
    # задваивался (аудит 23.11.2026)
    built = []
    try:
        for entry in data.get('items') or []:
            ctor = entry.get('ctor') or {}
            li = xbmcgui.ListItem(label=ctor.get('label') or '', label2=ctor.get('label2') or '',
                                  path=ctor.get('path') or '', offscreen=True)
            tag = None
            for target, name, args, kwargs in entry.get('calls') or []:
                if target == 'tag':
                    if tag is None:
                        tag = li.getVideoInfoTag()
                    getattr(tag, name)(*args, **(kwargs or {}))
                else:
                    if name == 'addContextMenuItems':
                        args = [[tuple(pair) for pair in args[0]]] + list(args[1:])
                    getattr(li, name)(*args, **(kwargs or {}))
            built.append((entry.get('url') or '', li, bool(entry.get('folder'))))
    except Exception as exc:
        log('готовая выдача не отдана %s: %s' % (params.get('info'), exc), xbmc.LOGWARNING)
        return False
    try:
        xbmcplugin.addDirectoryItems(handle, built, len(built))
        meta = data.get('meta') or {}
        if meta.get('content'):
            xbmcplugin.setContent(handle, meta['content'])
        for method in meta.get('sort') or []:
            xbmcplugin.addSortMethod(handle, method)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return True
    except Exception as exc:
        log('готовая выдача не отдана %s: %s' % (params.get('info'), exc), xbmc.LOGWARNING)
        return False


# ---- какие выдачи собирать -----------------------------------------------------------------

def remember(params):
    """Параметры, с которыми Kodi зовёт вкладки: их служба и собирает заранее."""
    if not wanted(params):
        return
    key = key_of(params)
    seen = _seen()
    if key in seen:
        return
    seen[key] = dict(params)
    try:
        target = xbmcvfs.translatePath(SEEN_FILE)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        tmp = '%s.%d.tmp' % (target, threading.get_ident())
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(seen, handle, ensure_ascii=False)
        os.replace(tmp, target)
    except OSError:
        pass


def _seen():
    try:
        with open(xbmcvfs.translatePath(SEEN_FILE), encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def known(extra_paths=()):
    """Все выдачи для сборки: виденные Kodi и вкладки хабов из раскладки."""
    from urllib.parse import parse_qsl, urlsplit
    found = dict(_seen())
    for path in extra_paths or ():
        text = str(path or '')
        if not text.startswith('plugin://skin.sublime/'):
            continue
        params = dict(parse_qsl(urlsplit(text.replace('&amp;', '&')).query, keep_blank_values=True))
        if wanted(params):
            found.setdefault(key_of(params), params)
    return list(found.values())


_EMPTY = {}


def refresh_all(extra_paths=(), cancel=None):
    """Пересобрать устаревшие выдачи. Возвращает, сколько пересобрано."""
    now_stamp = stamp()
    done = 0
    for params in known(extra_paths):
        if cancel is not None and cancel():
            break
        key = key_of(params)
        # пустая выдача (пустые «Смотреть позже», «Продолжить») или несобранная файла не пишет, и
        # маршрут считался заново каждые 15 с; повтор - когда изменились просмотры или через
        # SLOW_REBUILD (аудит 23.11.2026)
        empty = _EMPTY.get(key)
        if empty and empty[0] == now_stamp['exact'] and time.time() - empty[1] < SLOW_REBUILD:
            continue
        data = _load(params)
        saved = (data or {}).get('stamp') or {}
        age = time.time() - float((data or {}).get('built_at') or 0)
        if data and saved == now_stamp and age < FORCE_REFRESH:
            continue
        # медленные входы (хранилище строк, снимки) меняются каждые полминуты, пока работает очередь -
        # пересобирать из-за них не чаще раза в минуту; точные (просмотры) - сразу
        if data and saved.get('exact') == now_stamp['exact'] and age < SLOW_REBUILD:
            continue
        built = False
        try:
            built = render(params)
        except Exception as exc:
            log('готовая выдача не собрана %s: %s' % (params.get('info'), exc), xbmc.LOGWARNING)
        if built:
            done += 1
            _EMPTY.pop(key, None)
        else:
            _EMPTY[key] = (now_stamp['exact'], time.time())
    return done
