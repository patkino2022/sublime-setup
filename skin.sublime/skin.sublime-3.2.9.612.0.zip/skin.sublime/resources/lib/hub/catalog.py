# -*- coding: utf-8 -*-
"""Where candidates come from.

Two sources, in order of preference:

1. The video add-on's own local post cache. Measured on <коробка>: 16808
   posts, of which 11841 carry a real IMDb rating and 9541 a KinoPoisk one,
   plus genres, countries, cast, duration and vote counts - all on disk, no
   network at all.
2. The add-on's plugin:// listing over JSON-RPC, as a generic fallback for a
   provider whose cache this does not know.

Why the cache is preferred rather than the tidy generic route: with Filmix in
source-only metadata mode its listing rows publish `rating: 0.0`, `votes: "0"`,
`top250: 0` and an empty `studio` - measured, not assumed. Everything a rating
threshold or a quality preference needs is missing there and present here, so
scoring against the listing alone would have silently ignored half the
settings this module exists to serve.

The provider's cache is opened read-only in place and never copied and never
written to - see _open_provider_readonly() for why the copy had to go.
"""
# Ported from plugin.video.watchhub. The algorithm is unchanged; the
# sources it reads are not: settings come from config.py, the built
# lists and the feedback from store.py, and the watched history from
# history.py - which reads and writes Kodi's own database.
from __future__ import absolute_import, unicode_literals

import glob
import json
import re
import time
import os
import sqlite3

import xbmc
import xbmcvfs

from . import identity
from .config import get_int, log
from .provider import catalog_directory, get_directory, video_addon
from .store import db

# No module-level row cache on purpose. Holding every post as a dict measured
# ~16800 rows x ~20 fields - tens of megabytes, in EVERY process that touched
# the catalogue - and these boxes went into safe mode under exactly that kind
# of memory pressure. Rows are streamed and scored one at a time instead; only
# the distilled result (a few dozen entries) is ever cached.


def _added_ts(value):
    """When the provider added this post, as a unix timestamp.

    `date` is a human string ("Сегодня, 17:34") but `date_atom` is ISO 8601 and
    present on all 16820 posts, so freshness needs no guessing from post ids -
    and the ids would have been wrong anyway: the provider's own listing leads
    with re-uploads of older posts, not with the newest ids.
    """
    text = str(value or '').strip()
    if not text:
        return 0
    try:
        import datetime
        return int(datetime.datetime.fromisoformat(text).timestamp())
    except Exception:
        return 0


def _int(value):
    try:
        return int(str(value).strip())
    except (TypeError, ValueError):
        return 0


def _num(value):
    try:
        text = str(value or '').replace(',', '.').strip()
        return float(text) if text and text != '-' else 0.0
    except (TypeError, ValueError):
        return 0.0


_THUMB_SIZE_RE = re.compile(r'/thumbs/w\d+/', re.IGNORECASE)


def _full_size_poster(url):
    """Upgrade the provider's thumbnail URL to the full-size original.

    The cache stores `poster` as .../posters/<id>/thumbs/w220/<name>.jpg - a
    220-pixel-wide image. The provider's own widget rows use
    .../posters/<id>/orig/<name>.jpg for the same file, and these TVs are 4K
    panels where trading resolution for load speed is explicitly refused. A
    220px poster looked faster only because it is a fraction of the pixels.
    """
    url = str(url or '')
    if not url:
        return ''
    # Схему адреса не меняем: какой дал источник, такой и идёт (склад vip по http
    # сам переадресует на https, склад зеркала cyou по https отдаёт чужой
    # сертификат - подъём http -> https делал его картинки серыми, .20 19.11.2026).
    return _THUMB_SIZE_RE.sub('/orig/', url)


def _joined(value):
    if isinstance(value, (list, tuple)):
        return ', '.join(str(v).strip() for v in value if str(v or '').strip())
    return str(value or '')


def _cache_path():
    path = xbmcvfs.translatePath(
        'special://profile/addon_data/%s/cache4.db' % video_addon())
    return path if os.path.exists(path) else ''


def _open_provider_readonly():
    """Open the provider's cache read-only, IN PLACE.

    This used to copy the file to tempfile.gettempdir() first. On CoreELEC
    /tmp is tmpfs - RAM - and the file measures 160 MB, so every catalogue read
    burned 160 MB of memory on a box that also has Kodi in it. <коробка>
    rebooted into safe mode twice while that was in place. SQLite reads a live
    database fine over a read-only URI connection (the same `file:...?mode=ro`
    pattern skin.sublime already uses for plugin.video.youtube's cache), so
    there is no reason to copy anything.
    """
    source = _cache_path()
    if not source:
        return None
    try:
        return sqlite3.connect('file:%s?mode=ro' % source, uri=True, timeout=10)
    except Exception as e:
        log('catalog: кэш провайдера не открылся: %s' % e, xbmc.LOGWARNING)
        return None


def resolved_external_ids():
    """The provider's own resolved IMDb/TMDb ids, by post id.

    The skin identifies a row from its uniqueid before it tries anything else,
    and getting that wrong is what produced the «Безумцы»/«Джек Ричер» mess.
    The provider keeps its resolutions in a `resolved_ids` table (measured:
    4602 of 16814 posts, and every sampled row carried a tmdb id), so a row
    published from here can carry exactly the same ids the provider's own row
    would - no guessing, and no worse than the alternative.
    """
    conn = _open_provider_readonly()
    if conn is None:
        return {}
    out = {}
    try:
        for post_id, details in conn.execute('SELECT post_id, details FROM resolved_ids'):
            try:
                payload = json.loads(details or '{}')
            except Exception:
                continue
            if not isinstance(payload, dict):
                continue
            # The provider marks its own bad resolutions, and those markers are
            # the only reliable filter - a low tmdb id is not suspicious by
            # itself (13, 59 and 69 are real films). Measured: «Переруг» carries
            # `_tmdb_guard_quarantined` together with tmdb=1, and publishing
            # that id hands the skin a wrong identity to chase.
            if (payload.get('_tmdb_guard_quarantined') or payload.get('_tmdb_miss_at')
                    or payload.get('_tmdb_reject_reason')
                    or payload.get('_tmdb_rejected_tmdb_id')):
                continue
            imdb = str(payload.get('resolved_imdb_id') or payload.get('imdb_id') or '')
            tmdb = str(payload.get('resolved_tmdb_id') or payload.get('tmdb_id') or '')
            if not imdb and not tmdb:
                continue
            out[str(post_id)] = {
                'imdb': imdb,
                'tmdb': tmdb,
                'type': str(payload.get('resolved_tmdb_type') or ''),
            }
    except Exception as e:
        log('catalog: resolved_ids не прочитаны: %s' % e, xbmc.LOGWARNING)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return out


def _release_of_payload(payload):
    """Качество и вид релиза строки: («WEB-DLRip», «1080»).

    Порядок источников: поле `rip` провайдера (в нём и вид, и высота), затем
    его же `quality` (только высота), и лишь потом скобка в названии - её
    оставляют не все плагины.
    """
    payload = payload or {}
    quality, resolution = identity.release_parts(payload.get('rip'))
    if not quality and not resolution:
        # У СПИСОЧНЫХ записей провайдера поля устроены иначе, чем у записи
        # поста: `rip` пуст, а вся строка релиза лежит в `quality` - замер по
        # кэшу на .30 10.09.2026: «Старый орёл» quality = «WEB-DLRip 1080+»,
        # «Надежда» - «TS 1080», и таких записей 9318 против 504 с `rip`.
        # Прежний код совал эту строку целиком в разрешение, поэтому у таких
        # строк чипа не было вовсе: владелец увидел это на «Старом орле» и
        # «Надежде».
        quality, resolution = identity.release_parts(payload.get('quality'))
    if not resolution:
        plain = str(payload.get('quality') or '').strip()
        if plain.isdigit():
            resolution = plain
    if not quality and not resolution:
        quality, resolution = identity.release_info(payload.get('title'))
    return quality, resolution


def _fresh_release(post_id, payload):
    """Вид и высота релиза поста - сначала по свежим списочным страницам.

    Запись поста в кэше провайдера обновляется только когда пост открывают, и
    застревает на первом релизе: 20.10.2026 на .20 «Тенцинг» в посте был
    «CAM 480» от 13.10, а страница каталога того же утра - «WEB-DLRip 2160»
    (и сам сайт отдал WEB-DL, когда пост открыли). Поэтому страница каталога
    главнее записи поста, а запись - запасной путь.
    """
    listed = _release_from_listings(str(post_id))
    if listed[0] or listed[1]:
        return listed
    return _release_of_payload(payload)


def _row_from(post_id, details, updated_ts=None):
    """One normalized candidate row from stored JSON, or None if unusable."""
    try:
        payload = json.loads(details or '{}')
    except Exception:
        return None
    return _row_from_payload(post_id, payload, updated_ts)


# Сведения поста старше этого не прячут его как «только трейлер» - то же правило, что у Filmix
# (cache.trailer_only_ids, 2.2.61.72): старый снимок не должен прятать вышедший фильм.
TRAILER_FRESH_SECONDS = 3 * 86400


def _trailer_only(payload, updated_ts=None):
    """Пост, у которого у источника только трейлер: ссылки поста - только на трейлер (то же
    правило - Filmix navigation._is_trailer_only и cache.trailer_only_ids). Категория «Трейлеры»
    признаком не служит: она остаётся и у вышедших фильмов. Сведения из кэша старше трёх суток
    признаком не служат тоже (updated_ts - время записи поста в кэше источника)."""
    links = payload.get('player_links')
    if not (isinstance(links, dict) and links.get('trailer')
            and not links.get('movie') and not links.get('playlist')):
        return False
    try:
        if updated_ts is not None and int(updated_ts or 0) < time.time() - TRAILER_FRESH_SECONDS:
            return False
    except (TypeError, ValueError):
        pass
    return True


def _row_from_payload(post_id, payload, updated_ts=None):
    """The same, for a payload already parsed - the provider's cached listing
    pages hold whole post objects, so they need no second round of JSON."""
    if not isinstance(payload, dict):
        return None
    title = payload.get('title') or payload.get('original_title') or ''
    alt = payload.get('alt_name') or ''
    if not title or not alt:
        return None
    # A serial is recognised by carrying episode structure, which is also what
    # decides the route (/serials/.../open/ vs /movies/.../play/) - `section`
    # is 0 for almost everything and says nothing useful.
    is_serial = bool(payload.get('serial_stats') or payload.get('last_episode'))
    release = _fresh_release(post_id, payload)
    if identity.is_screener(release[0]):
        # 20.10.2026 владелец: «Никаких экранок» - ни в одной полосе хаба.
        return None
    if _trailer_only(payload, updated_ts):
        # то, что нельзя включить (у источника пока только трейлер), не показывается нигде
        return None
    # The provider ships its own related-titles list on every post (measured:
    # 16814 of 16814, median 5 entries), each carrying the related post's id.
    # That is an item-to-item graph for free - the nearest thing to
    # collaborative filtering available without a network call or a model.
    relates = []
    for related in (payload.get('relates') or []):
        if not isinstance(related, dict):
            continue
        try:
            relates.append(int(related.get('id')))
        except (TypeError, ValueError):
            continue
    return {
        'post_id': str(post_id),
        'post_number': _int(post_id),
        'added_ts': _added_ts(payload.get('date_atom')),
        'relates': relates,
        'label': identity.clean_label(title),
        'title': identity.clean_label(title),
        # Качество и вид релиза. 09.09.2026 владелец: «надо предусмотреть
        # механизм, чтобы из этой информации собирались такие графические
        # иконки … и добавлялись в инфостроку». В названии его нет - мы его
        # оттуда срезаем, - зато у провайдера это отдельные поля: замер по
        # кэшу постов на .30 09.09.2026 - `rip` = «WEB-DLRip 1080»,
        # `quality` = «1080». Разбор один и тот же (identity.release_parts).
        'release_quality': release[0],
        'release_resolution': release[1],
        'originaltitle': payload.get('original_title') or '',
        'year': str(payload.get('year') or ''),
        'genre': _joined(payload.get('categories')),
        'country': _joined(payload.get('countries')),
        'actors': _joined(payload.get('actors')),
        'directors': _joined(payload.get('directors')),
        'plot': payload.get('short_story') or '',
        'poster': _full_size_poster(payload.get('poster')),
        'imdb_rating': _num(payload.get('imdb_rating')),
        'imdb_votes': _num(payload.get('imdb_votes')),
        'kp_rating': _num(payload.get('kp_rating')),
        'kp_votes': _num(payload.get('kp_votes')),
        'duration': _num(payload.get('duration')),
        'is_serial': is_serial,
        'file': 'plugin://%s/%s/%s-%s/%s/' % (
            video_addon(), 'serials' if is_serial else 'movies',
            post_id, alt, 'open' if is_serial else 'play'),
        'filetype': 'directory' if is_serial else 'file',
        'mediatype': 'tvshow' if is_serial else 'movie',
    }


_POST_IN_PATH = re.compile(r'/(\d{3,})-')
_RELEASE_BY_POST = {}


def prefetch_releases(paths):
    """Качество релиза для всей полосы одним запросом к кешу провайдера.

    release_for_path открывал базу провайдера (170 МБ) на каждую строку:
    профиль маршрута полосы «Все» сериалы на .30 17.10.2026 - 0.99 с из 2.55 с,
    из них 0.41 с одни закрытия соединения. Здесь одно соединение и одна
    выборка; release_for_path дальше отвечает из памяти.
    """
    wanted = []
    for path in paths or []:
        found = _POST_IN_PATH.search(str(path or ''))
        if found and found.group(1) not in _RELEASE_BY_POST and found.group(1) not in wanted:
            wanted.append(found.group(1))
    if not wanted:
        return
    conn = _open_provider_readonly()
    if conn is None:
        return
    got = {}
    try:
        for start in range(0, len(wanted), 400):
            chunk = wanted[start:start + 400]
            marks = ','.join('?' for _ in chunk)
            for post_id, details in conn.execute(
                    'SELECT post_id, details FROM posts WHERE post_id IN (%s)' % marks,
                    tuple(chunk)):
                try:
                    got[str(post_id)] = _release_of_payload(json.loads(details or '{}'))
                except Exception:
                    continue
    except Exception:
        return
    finally:
        try:
            conn.close()
        except Exception:
            pass
    for post_id in wanted:
        # Списочная страница главнее записи поста (см. _fresh_release).
        answer = _release_from_listings(post_id)
        if not answer[0] and not answer[1]:
            answer = got.get(post_id, ('', ''))
        _RELEASE_BY_POST[post_id] = answer


def release_for_path(path):
    """Качество и вид релиза по адресу строки: («WEB-DLRip», «1080»).

    Нужно для строк из СНИМКОВ виджетов. Снимок собирается через JSON-RPC, а он
    свои свойства строк не отдаёт вовсе - замер на .30 09.09.2026: в полосе
    хаба `sublime_release_quality` пусто, хотя маршрут его ставит. Номер поста
    в адресе есть всегда (`/movies/186784-...`), а качество лежит в кэше
    провайдера - там же, откуда его берёт и сборка каталога. Разбор тот же
    (_release_of_payload), запросы запоминаются на процесс.
    """
    text = str(path or '')
    if 'plugin.video.hdrezka' in text:
        return _hdrezka_release(text)
    found = _POST_IN_PATH.search(text)
    if not found:
        return '', ''
    post_id = found.group(1)
    if post_id in _RELEASE_BY_POST:
        return _RELEASE_BY_POST[post_id]
    # Списочная страница главнее записи поста (см. _fresh_release).
    answer = _release_from_listings(post_id)
    conn = _open_provider_readonly() if not (answer[0] or answer[1]) else None
    if conn is not None:
        try:
            row = conn.execute(
                'SELECT details FROM posts WHERE post_id = ? LIMIT 1',
                (post_id,)).fetchone()
            if row and row[0]:
                answer = _release_of_payload(json.loads(row[0]))
        except Exception:
            answer = ('', '')
        finally:
            try:
                conn.close()
            except Exception:
                pass
    _RELEASE_BY_POST[post_id] = answer
    return answer


def _hdrezka_release(path):
    """Качество строки HDRezka по адресу: лучшее качество потоков из карточки фильма, которую дополнение
    кладёт в addon_data/plugin.video.hdrezka.tv/cards/<номер>.json (с 3.3.4.9050). Номер поста -
    в закодированном uri строки (%2F71075-). Без этого у строк HDRezka в хабе плашки не было:
    снимок через JSON-RPC свойств строки не отдаёт, а кэш провайдера - только Filmix (22.11.2026)."""
    try:
        from urllib.parse import unquote
    except ImportError:
        from urllib import unquote
    found = _POST_IN_PATH.search(unquote(path))
    if not found:
        return '', ''
    key = 'hdrezka:' + found.group(1)
    if key in _RELEASE_BY_POST:
        return _RELEASE_BY_POST[key]
    answer = ('', '')
    try:
        card_path = xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.video.hdrezka.tv/cards/%s.json' % found.group(1))
        with open(card_path, encoding='utf-8') as fh:
            release = (json.load(fh) or {}).get('stream_quality') or ''
        if release:
            answer = identity.release_parts(release)
    except (OSError, ValueError, TypeError):
        pass
    if answer[0] or answer[1]:
        _RELEASE_BY_POST[key] = answer       # пустое не запоминать: карточка может появиться позже
    return answer


# Качество из СПИСОЧНЫХ кэшей провайдера, по номеру поста. Собирается один раз
# на процесс и только если запись поста качества не дала: у 450 постов из 14421
# поля `rip` и `quality` пусты, а в списочных страницах у тех же фильмов строка
# релиза есть («Старый орёл» - «WEB-DLRip 1080+»).
_RELEASE_LISTINGS = {}


# Индекс качества из списочных страниц - общий для запусков, на полчаса.
# Разбор 554 страниц стоил 0.6 с у «Рекомендаций» (профиль на .30 17.10.2026),
# а каждый экран Kodi запускает скин заново. Качество релиза у поста меняется
# редко; новинка без него просто покажет значок на полчаса позже.
_LISTINGS_FILE = 'special://temp/sublime_release_listings2.json'
_LISTINGS_TTL = 1800


def _listings_from_disk():
    try:
        path = xbmcvfs.translatePath(_LISTINGS_FILE)
        if time.time() - os.path.getmtime(path) > _LISTINGS_TTL:
            return False
        with open(path, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return False
        for key, value in data.items():
            if isinstance(value, list) and len(value) == 2:
                _RELEASE_LISTINGS[key] = (value[0], value[1])
        return bool(_RELEASE_LISTINGS)
    except Exception:
        return False


def _listings_to_disk():
    try:
        path = xbmcvfs.translatePath(_LISTINGS_FILE)
        tmp = '%s.%d.tmp' % (path, os.getpid())
        with open(tmp, 'w', encoding='utf-8') as handle:
            handle.write(json.dumps(dict((k, list(v)) for k, v in _RELEASE_LISTINGS.items()),
                                    ensure_ascii=False, separators=(',', ':')))
        os.replace(tmp, path)
    except Exception:
        pass


def _release_from_listings(post_id):
    if not _RELEASE_LISTINGS and _listings_from_disk():
        return _RELEASE_LISTINGS.get(post_id, ('', ''))
    if not _RELEASE_LISTINGS:
        conn = _open_provider_readonly()
        if conn is None:
            _RELEASE_LISTINGS['?'] = ('', '')
            return '', ''
        try:
            for table in ('catalog_cache', 'widget_snapshots'):
                # Свежие страницы первыми: побеждает первая встреченная запись
                # поста, а старая страница может помнить экранку.
                try:
                    rows = conn.execute('SELECT details FROM %s ORDER BY updated_ts DESC' % table)
                except Exception:
                    try:
                        rows = conn.execute('SELECT details FROM %s' % table)
                    except Exception:
                        continue
                for row in rows:
                    try:
                        items = json.loads(row[0] or '[]')
                    except Exception:
                        continue
                    if not isinstance(items, list):
                        continue
                    for item in items:
                        if not isinstance(item, dict):
                            continue
                        number = str(item.get('id') or '')
                        if not number or number in _RELEASE_LISTINGS:
                            continue
                        parsed = _release_of_payload(item)
                        if parsed[0] or parsed[1]:
                            _RELEASE_LISTINGS[number] = parsed
        except Exception:
            pass
        finally:
            try:
                conn.close()
            except Exception:
                pass
        _RELEASE_LISTINGS.setdefault('?', ('', ''))
        _listings_to_disk()
    return _RELEASE_LISTINGS.get(post_id, ('', ''))


def iter_post_rows():
    """Yield one normalized candidate row at a time, retaining none of them."""
    conn = _open_provider_readonly()
    if conn is None:
        return
    try:
        for post_id, details, updated_ts in conn.execute(
                'SELECT post_id, details, updated_ts FROM posts'):
            row = _row_from(post_id, details, updated_ts)
            if row is not None:
                yield row
    except Exception as e:
        log('catalog: чтение кэша не удалось: %s' % e, xbmc.LOGWARNING)
    finally:
        try:
            conn.close()
        except Exception:
            pass


def rows_for_paths(paths):
    """{адрес: строка каталога} для адресов Filmix - та же строка, что идёт в полосы
    (_row_from: описание short_story, постер, жанры, оценки). Нужна строкам, которые
    берутся не из каталога, а из базы просмотров: там только название и адрес."""
    wanted = {}
    marker = 'plugin://%s/' % video_addon()
    for path in paths:
        hit = _POST_IN_PATH.search(path or '') if (path or '').startswith(marker) else None
        if hit:
            wanted.setdefault(hit.group(1), []).append(path)
    if not wanted:
        return {}
    conn = _open_provider_readonly()
    if conn is None:
        return {}
    out = {}
    try:
        for post_id, details, updated_ts in conn.execute(
                'SELECT post_id, details, updated_ts FROM posts WHERE post_id IN (%s)'
                % ','.join('?' * len(wanted)), tuple(wanted)):
            row = _row_from(post_id, details, updated_ts)
            if row is not None:
                for path in wanted.get(str(post_id), ()):
                    out[path] = row
    except Exception as e:
        log('catalog: записи по адресам не прочитаны: %s' % e, xbmc.LOGWARNING)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return out


def recent_rows(limit=400):
    """The newest posts only - for topping lanes up between full rebuilds.

    A full pass reads 14k rows and costs tens of seconds, so lanes were rebuilt
    every twelve hours; measured on <коробка> that left the thirty newest
    films out of the home screen while they were already in the provider's own
    cache. The provider numbers its posts in order, so "newest" is the tail of
    the id order and can be read for a fraction of the cost.
    """
    conn = _open_provider_readonly()
    if conn is None:
        return []
    rows = []
    try:
        for post_id, details, updated_ts in conn.execute(
                'SELECT post_id, details, updated_ts FROM posts'
                ' ORDER BY CAST(post_id AS INTEGER) DESC LIMIT ?',
                (int(limit),)):
            row = _row_from(post_id, details, updated_ts)
            if row is not None:
                rows.append(row)
    except Exception as e:
        log('catalog: свежие посты не прочитаны: %s' % e, xbmc.LOGWARNING)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return rows


def _listing_rows(category, pages, enough=0):
    """Generic fallback: read the add-on's own directory pages.
    enough - остановиться, как только набралось столько строк."""
    rows = []
    seen = set()
    for page in range(1, max(1, pages) + 1):
        if enough and len(rows) >= enough:
            break
        try:
            directory = catalog_directory(category, page)
            if not directory:
                break
            # 90 с, а не 25: первая страница после переустановки - вход, проверка Anubis и
            # подбор зеркала, у HDRezka на .20 17.11.2026 это больше 25 с, и полосы
            # оставались пустыми
            files = get_directory(directory, timeout=90)
        except Exception as e:
            log('catalog: %s стр.%d не прочитана: %s' % (category, page, e), xbmc.LOGWARNING)
            break
        if not files:
            break
        for row in files:
            path = row.get('file') or ''
            if not path or path in seen:
                continue
            # «Следующая страница» дополнения - не фильм: HDrezka и Elementum кладут
            # её последней папкой списка, и она попадала в полосы хаба
            if row.get('filetype') == 'directory' and 'page=' in path and not row.get('uniqueid')                     and not str(row.get('year') or '').strip('0'):
                continue
            # строка «Войти в аккаунт» - действие, а не фильм: она вставала в полосу
            # «сверху» и жила в снимке и после входа (HDRezka, .20, 17.11.2026)
            if re.search(r'[?&]mode=(?:signin|authorize|logout|login)\b', path):
                continue
            # то же у любого источника (Filmix: plugin://plugin.video.filmix/login) - общая проверка
            try:
                from . import mirror as _mirror
                if _mirror.is_navigation(row):
                    continue
            except Exception:
                pass
            seen.add(path)
            art = row.get('art') or {}
            rows.append({
                'post_id': '',
                'post_number': 0,
                'added_ts': 0,
                'relates': [],
                'label': identity.clean_label(row.get('label')),
                'title': identity.clean_label(row.get('title')) or identity.clean_label(row.get('label')),
                'originaltitle': row.get('originaltitle') or '',
                'year': str(row.get('year') or ''),
                'genre': _joined(row.get('genre')),
                'country': _joined(row.get('country')),
                'actors': '',
                'directors': '',
                'plot': row.get('plot') or '',
                'poster': art.get('poster') or art.get('thumb') or '',
                # картинки источника целиком: без них фоном полосы становился постер
                'art': {k: v for k, v in art.items()
                        if k in ('poster', 'thumb', 'fanart', 'landscape', 'clearlogo') and v},
                'imdb_rating': _num(row.get('rating')),
                'imdb_votes': _num(row.get('votes')),
                'kp_rating': 0.0,
                'kp_votes': 0.0,
                'duration': 0.0,
                'is_serial': category == 'shows',
                'file': path,
                'filetype': row.get('filetype') or 'file',
                'mediatype': 'tvshow' if category == 'shows' else 'movie',
                'playcount': row.get('playcount'),
                'uniqueid': row.get('uniqueid') or {},
            })
    return rows


def provider_personal_ids():
    """Номера постов в «Избранном» и «Смотреть позже» у провайдера.

    Хаб кладёт в меню строки те же пункты, что сам Filmix: владелец 16.10.2026 -
    «не во всех категориях фильмов и сериалов в контекстных меню есть пункты
    Filmix». В его собственных разделах они есть, в полосах хаба («Все»,
    «Рекомендации», «Русские», «Сербские») не было. Направление переключателя
    («Добавить» или «Удалить») берём из тех же страниц, что Filmix перечитывает
    сразу после каждого переключения (actions.toogle_favorites).
    """
    found = {'favorites': set(), 'deferred': set()}
    conn = _open_provider_readonly()
    if conn is None:
        return found
    try:
        for section, details in conn.execute(
                'SELECT section, details FROM catalog_cache'
                " WHERE section IN ('favorites', 'deferred')"
                "   AND (filters = '' OR filters IS NULL)"):
            try:
                items = json.loads(details or '[]')
            except Exception:
                continue
            for item in items if isinstance(items, list) else []:
                if isinstance(item, dict) and item.get('id'):
                    found[section].add(str(item.get('id')))
    except Exception as e:
        log('catalog: избранное провайдера не прочитано: %s' % e, xbmc.LOGWARNING)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return found


def provider_list_rows(category, pages=1):
    """The provider's own list order, with every row completed from its cache.

    Ordering by post id finds new posts but not the ones the site leads with:
    measured on <коробка>, four of the fifty films on the provider's first
    page («Ограбить Лондон», «Драка», «Наш герой, Бальтазар», «Мандалорец и
    Грогу») carry spring dates and old ids and are there because the site puts
    re-uploads first.

    Asking the add-on for that page over JSON-RPC returned nothing from inside
    the service - a plugin directory read needs the main thread, so it is not
    available here. The add-on stores every page it fetched in `catalog_cache`.

    Those stored rows are LISTING rows, though, and they are thin: measured,
    a page item carries title, year, poster and quality and no `short_story`,
    no imdb/kp rating and no cast. Publishing them as they are emptied the plot
    of every film and series in the widgets - so each one is looked up in
    `posts`, which holds the full object, and only what the cache has never
    seen falls back to the thin row.
    """
    section = 'serials' if category == 'shows' else 'movies'
    conn = _open_provider_readonly()
    if conn is None:
        return []
    ordered = []
    try:
        for page in range(1, max(1, int(pages)) + 1):
            found = conn.execute(
                'SELECT details FROM catalog_cache'
                ' WHERE section = ? AND page = ?'
                "   AND (filters = '' OR filters IS NULL)"
                ' ORDER BY updated_ts DESC LIMIT 1',
                (section, str(page))).fetchone()
            if not found:
                continue
            try:
                items = json.loads(found[0] or '[]')
            except Exception:
                continue
            if not isinstance(items, list):
                continue
            for item in items:
                if isinstance(item, dict) and item.get('id'):
                    ordered.append((str(item.get('id')), item))
        if not ordered:
            return []
        full = {}
        # посты, которые источник включить не даст (только трейлер): за них нельзя подставлять
        # тонкую строку страницы - ссылок в ней нет, и фильм возвращался в полосу («Голос русалки»
        # в «Новых фильмах» на .20 и .30, 25.11.2026, при отброшенном посте)
        unplayable = set()
        listed_by_id = dict(ordered)
        ids = [post_id for post_id, _item in ordered]
        # A page is fifty rows, so one statement per page is enough.
        marks = ','.join('?' for _ in ids)
        for post_id, details, updated_ts in conn.execute(
                'SELECT post_id, details, updated_ts FROM posts WHERE post_id IN (%s)' % marks,
                tuple(ids)):
            try:
                payload = json.loads(details or '{}')
            except Exception:
                payload = {}
            if not isinstance(payload, dict):
                continue
            # Filmix.post does not return `alt_name` - the listing page does.
            # Without it _row_from_payload refuses the row and the page's own
            # thin version wins, which is how three films kept an empty
            # description while their posts sat in the cache WITH one
            # («Запретный город», «Игра на риск», «Грозовой шторм 3», measured
            # on .20). The two sources are about the same film: take the slug
            # from whichever has it.
            if not payload.get('alt_name'):
                listed = listed_by_id.get(str(post_id)) or {}
                if listed.get('alt_name'):
                    payload = dict(payload)
                    payload['alt_name'] = listed.get('alt_name')
            if _trailer_only(payload, updated_ts):
                unplayable.add(str(post_id))
                continue
            row = _row_from_payload(post_id, payload, updated_ts)
            if row is not None:
                full[str(post_id)] = row
    except Exception as e:
        log('catalog: список провайдера не прочитан: %s' % e, xbmc.LOGWARNING)
        return []
    finally:
        try:
            conn.close()
        except Exception:
            pass
    rows = []
    seen = set()
    thin = 0
    for post_id, item in ordered:
        if post_id in seen or post_id in unplayable:
            continue
        seen.add(post_id)
        row = full.get(post_id)
        if row is None:
            row = _row_from_payload(post_id, item)
            if row is None:
                continue
            # A listing item carries no `short_story`, so this row has no plot
            # of its own - and a film with an empty description looks broken,
            # which is what the owner reported («Грозовой шторм 3», «Игра на
            # риск», «Запретный город» - all of them exactly these rows). What
            # the page DOES carry is the site's own rating and the quality tag,
            # so at least those are published, and the plot is filled in from
            # what warming resolved (see lanes._learned_plots).
            try:
                rating = _num(item.get('rating'))
            except Exception:
                rating = 0.0
            if rating > 0:
                row['imdb_rating'] = rating
            row['_thin'] = True
            thin += 1
        row['listing_order'] = len(rows)
        rows.append(row)
    if thin:
        log('список %s: %d строк без полного описания (нет в кэше постов)'
            % (category, thin))
    return rows


def _playlist_episode_count(playlist):
    """Episodes in a provider playlist: {season: {translation: {ep: link}}}.

    Verified against the cache on <коробка> (post 183828 «Паутина
    Шарлотты»: season "1" -> two translations -> episodes "1".."3"). Some posts
    skip the season level and map translations straight to episodes, so both
    shapes are handled. Per season the longest translation wins - a translation
    that dubbed fewer episodes does not make the season shorter.
    """
    total = 0
    for _key, value in playlist.items():
        if not isinstance(value, dict) or not value:
            continue
        nested = [v for v in value.values() if isinstance(v, dict)]
        if nested and all(isinstance(v, dict) for v in value.values()):
            # season -> translation -> episodes
            total += max(len(v) for v in nested)
        else:
            # translation -> episodes
            total += len(value)
    return total


_provider_modules = {}


def _provider_module(name):
    """Модуль провайдера, загруженный из его каталога как есть (по mtime файла).

    Не через импорт пакета: у провайдера свой пакет `resources`, у скина свой,
    и имена столкнулись бы. Грузятся только модули без xbmc - cache.py и
    watch_stats.py.
    """
    path = xbmcvfs.translatePath('special://home/addons/%s/resources/libs/%s.py'
                                 % (video_addon(), name))
    stamp = os.path.getmtime(path)
    known = _provider_modules.get(name)
    if known and known[0] == stamp:
        return known[1]
    import importlib.util
    spec = importlib.util.spec_from_file_location('provider_%s' % name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    _provider_modules[name] = (stamp, module)
    return module


def _kodi_provider_rows():
    """{путь: (playcount,)} строк провайдера в базе Kodi - одно чтение на список.

    Kodi хранит путь элемента дополнения целиком в strFilename (а не в strPath +
    strFilename), поэтому склеивать их нельзя - так же читает и сам провайдер
    (kodi_state._full_path).
    """
    paths = sorted(glob.glob(xbmcvfs.translatePath(
        'special://profile/Database/MyVideos*.db')))
    if not paths:
        return {}
    prefix = 'plugin://%s/' % video_addon()
    rows = {}
    conn = None
    try:
        conn = sqlite3.connect('file:%s?mode=ro' % paths[-1], uri=True, timeout=5)
        for strpath, filename, playcount in conn.execute(
                'SELECT p.strPath, f.strFilename, f.playCount'
                ' FROM files f JOIN path p ON p.idPath = f.idPath'
                ' WHERE f.strFilename LIKE ? OR p.strPath LIKE ?',
                (prefix + '%', prefix + '%')):
            name = str(filename or '')
            full = name if name.startswith('plugin://') else str(strpath or '') + name
            if full.startswith(prefix):
                rows[full] = (int(playcount or 0),)
    except Exception as e:
        log('catalog: база Kodi для отметок не прочитана: %s' % e, xbmc.LOGWARNING)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    return rows


def provider_show_states(post_ids):
    """{post_id: состояние сериала} - посчитанное КОДОМ ПРОВАЙДЕРА.

    21.10.2026 владелец: «Почему нельзя сделать один механизм во всех
    виджетах? В данном случае как в виджете Избранное?» «Тед Лассо» в
    «Избранном» Filmix стоял с одной непросмотренной серией, а в полосе «Все»
    - просмотренным: полоса считала сама, по базе Kodi и самому длинному
    переводу. Теперь полоса зовёт тот же watch_stats.show_state, по которому
    строит строку «Избранное», на тех же данных его кэша. Своего счёта у скина
    для сериалов провайдера больше нет.

    Кэш открыт только на чтение, как и везде здесь: FilmixCache создаётся без
    своего __init__ (тот создаёт таблицы), ему отдаётся наше соединение.
    None - если у провайдера нет общего модуля или кэш не открылся.
    """
    wanted = [str(p) for p in post_ids if str(p or '').strip()]
    if not wanted:
        return {}
    try:
        stats = _provider_module('watch_stats')
        cache_class = _provider_module('cache').FilmixCache
    except Exception as e:
        log('catalog: счёт просмотра провайдера недоступен: %s' % e, xbmc.LOGWARNING)
        return None
    conn = _open_provider_readonly()
    if conn is None:
        return None
    cache = cache_class.__new__(cache_class)
    conn.row_factory = cache_class._dict_factory
    cache.conn = conn
    try:
        # Отметки Kodi поверх кэша провайдера (watch_stats.apply_kodi): кэш его
        # служба сверяет с Kodi раз в минуту, а полоса перечитывается сразу
        # после конца серии - 29.10.2026 «Полураспад» так и остался с одной
        # непросмотренной. Провайдер без apply_kodi принимает старый вызов.
        kodi_rows = _kodi_provider_rows()
        if kodi_rows and hasattr(stats, 'apply_kodi'):
            return stats.show_states(cache, wanted, kodi_rows=kodi_rows)
        return stats.show_states(cache, wanted)
    except Exception as e:
        log('catalog: счёт просмотра провайдера не удался: %s' % e, xbmc.LOGWARNING)
        return None
    finally:
        cache.close()


def episode_totals(post_ids):
    """{post_id: episode count} read from the provider's player topology.

    The provider stores playback as season -> translation -> episode list, so
    the honest total for a season is the longest translation of it (a
    translation that covers fewer episodes does not make the show shorter).
    Only asked for the handful of rows a listing is about to draw, never for
    the whole catalogue.
    """
    wanted = set(str(p) for p in post_ids if str(p or '').strip())
    if not wanted:
        return {}
    totals = {}
    conn = _open_provider_readonly()
    if conn is None:
        return {}
    try:
        marks = ','.join('?' * len(wanted))
        rows = conn.execute(
            'SELECT post_id, details FROM posts WHERE post_id IN (%s)' % marks,
            tuple(wanted))
        for post_id, payload in rows:
            try:
                details = json.loads(payload)
            except Exception:
                continue
            playlist = (details.get('player_links') or {}).get('playlist') or {}
            if not isinstance(playlist, dict):
                continue
            total = _playlist_episode_count(playlist)
            if total:
                totals[str(post_id)] = total
    except Exception as e:
        log('catalog: подсчёт эпизодов не удался: %s' % e, xbmc.LOGWARNING)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return totals


def iter_candidates(category):
    """Stream candidates for one category from the best available source.

    The caller scores each row and keeps only its own top N, so peak memory is
    the size of that top N rather than the size of the catalogue.
    """
    want_serial = (category == 'shows')
    seen_any = 0
    names = set()
    for row in iter_post_rows():
        if row['is_serial'] != want_serial:
            continue
        seen_any += 1
        names.add(identity.show_key(row.get('label'), row.get('year')))
        yield row
    # Кэш карточек источника заполняется постепенно (после переустановки в нём единицы), и
    # полосы, собранные только из него, оставались пустыми (.20, 17.11.2026: одна карточка
    # Filmix - «Русские» и «Лучшие» пусты). Пока карточек меньше экрана, добираем из списка.
    if seen_any >= CATALOG_ENOUGH_POSTS:
        return
    directory = catalog_directory(category, 1) or ''
    # Сайты банят адрес за обход каталога: хаб читал по 20 страниц фильмов и сериалов,
    # и так при каждой полосе без кэша - HDRezka утром 17.11.2026 (06:55, ~60 запросов за
    # полторы минуты) к 08:02 закрыла домашний адрес на всех зеркалах; Filmix в 15:26-15:27
    # получил 40 запросов за минуту. Теперь у любого источника - не больше, чем видно на
    # экране (50 карточек на категорию, владелец 17.11.2026), и один обход на категорию за
    # CATALOG_TTL. HDRezka без входа отдаёт только строку входа - её не спрашиваем вовсе
    if 'plugin.video.hdrezka' in directory and not _hdrezka_signed_in():
        log('catalog: HDRezka без входа - каталог не читаем')
        return
    pages, enough = CATALOG_PAGES, SCREEN_CARDS
    rows = _cached_listing(category, directory, pages, enough)
    log('catalog: %d кандидатов из списков (%d стр.)' % (len(rows), pages))
    for row in rows:
        if identity.show_key(row.get('label'), row.get('year')) in names:
            continue
        yield row


CATALOG_ENOUGH_POSTS = 300   # меньше карточек в кэше источника - кандидаты добираются из списка
CATALOG_PAGES = 3          # предел страниц; обход кончается раньше, как только набрано SCREEN_CARDS
SCREEN_CARDS = 50          # карточек на категорию домашнего экрана
CATALOG_TTL = 30 * 60      # не чаще раза в 30 мин (владелец 17.11.2026); столько же HDRezka держит страницу сайта
_CATALOG_CACHE = 'special://profile/addon_data/skin.sublime/catalog_rows/'


def _hdrezka_signed_in():
    try:
        import xbmcaddon
        addon = xbmcaddon.Addon('plugin.video.hdrezka.tv')
        # логин и пароль сохранены, а сессии нет (переустановка, очистка) - дополнение войдёт
        # само при первом запросе (default._quiet_login); без этого полосы HDRezka стояли
        # пустыми, пока владелец не откроет дополнение (.20, 17.11.2026)
        if addon.getSetting('username') and addon.getSetting('password'):
            return True
        raw = addon.getSetting('cookies')
        cookies = json.loads(raw) if raw else []
    except Exception:
        return False
    if isinstance(cookies, dict):
        cookies = [{'name': k, 'value': v} for k, v in cookies.items()]
    return any(isinstance(c, dict) and c.get('name') in ('dle_user_id', 'dle_password')
               and str(c.get('value') or '').strip() not in ('', '0', 'deleted')
               for c in (cookies if isinstance(cookies, list) else ()))


def _cached_listing(category, directory, pages, enough=0):
    """Строки каталога из диска, если обход моложе CATALOG_TTL; иначе обход и запись.
    Полосы одной категории («новое», «русское», «лучшее») берут один и тот же обход."""
    import hashlib
    folder = xbmcvfs.translatePath(_CATALOG_CACHE)
    path = os.path.join(folder, '%s.json' % hashlib.md5(
        ('%s|%s|%d' % (category, directory, pages)).encode('utf-8')).hexdigest())
    try:
        if time.time() - os.path.getmtime(path) < CATALOG_TTL:
            with open(path, encoding='utf-8') as fh:
                rows = json.load(fh)
            if rows:
                return rows
    except (OSError, ValueError):
        pass
    rows = _listing_rows(category, pages, enough)
    if rows:
        try:
            os.makedirs(folder, exist_ok=True)
            tmp = path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fh:
                json.dump(rows, fh, ensure_ascii=False)
            os.replace(tmp, path)
        except OSError as exc:
            log('catalog: кэш обхода не записан: %s' % exc, xbmc.LOGWARNING)
    return rows


VOCAB_FLAG = 'vocabulary_%s'
DF_FLAG = 'docfreq_%s'


VOCAB_TS_FLAG = 'vocabulary_ts'


def refresh_vocabulary_if_stale(max_age_seconds):
    """Recount the vocabulary only when it has aged out.

    The service loop called refresh_vocabulary() on every idle tick, so the
    provider's whole cache (16821 rows, ~2.1 s) was re-read every minute the box
    sat on the home screen - measured on <коробка>, twice inside one minute
    ("catalog: словарь обновлён" at 06:58:48 and 07:00:02). The genre and country
    lists do not change that fast, and those seconds were taken from the skin's
    metadata worker, which the user feels as art arriving late.
    """
    store = db()
    try:
        age = int(time.time()) - int(store.get_flag(VOCAB_TS_FLAG) or 0)
    except (TypeError, ValueError):
        age = max_age_seconds + 1
    if store.get_flag(VOCAB_FLAG % 'genre') and age < max_age_seconds:
        return False
    refresh_vocabulary()
    store.set_flag(VOCAB_TS_FLAG, str(int(time.time())))
    return True


def refresh_vocabulary(limit=60):
    """Recount the genre/country vocabularies and store them.

    Called from the service, never from a settings button: counting means
    reading the provider's whole cache (16808 posts, ~2.1 s measured on
    <коробка>), and a settings button that goes quiet for two seconds reads
    as "not working". One streaming pass; the two count dicts are a few dozen
    entries each and nothing else is retained.
    """
    genre_counts = {}
    country_counts = {}
    total = 0
    for row in iter_post_rows():
        total += 1
        for field, counts in (('genre', genre_counts), ('country', country_counts)):
            for value in str(row.get(field) or '').split(','):
                value = value.strip()
                if value:
                    counts[value] = counts.get(value, 0) + 1
    if not total:
        return False

    def top(counts):
        return [name for name, _ in sorted(counts.items(), key=lambda kv: kv[1],
                                           reverse=True)][:limit]

    store = db()
    store.set_flag(VOCAB_FLAG % 'genre', json.dumps(top(genre_counts), ensure_ascii=False))
    store.set_flag(VOCAB_FLAG % 'country', json.dumps(top(country_counts), ensure_ascii=False))
    # The same pass also yields how common each value is, which is what lets
    # scoring tell a real preference from a label everything carries: measured,
    # "Сериалы" sits on 4213 of 16808 posts and on 1615 of 1639 watched
    # episodes, so matching it says nothing about taste. Kept lower-cased, as
    # the scorer compares that way.
    store.set_flag(DF_FLAG % 'genre', json.dumps(
        dict((k.lower(), v) for k, v in genre_counts.items()), ensure_ascii=False))
    store.set_flag(DF_FLAG % 'country', json.dumps(
        dict((k.lower(), v) for k, v in country_counts.items()), ensure_ascii=False))
    store.set_flag(DF_FLAG % 'total', str(total))
    log('catalog: словарь обновлён (%d жанров, %d стран из %d записей)'
        % (len(genre_counts), len(country_counts), total))
    return True


def document_frequencies():
    """How many catalogue entries carry each genre/country, plus the total.

    Returns ({'genre': {...}, 'country': {...}}, total). Empty when the
    vocabulary pass has not run yet - the scorer then treats every value as
    equally informative, which is the behaviour it had before.
    """
    store = db()
    out = {}
    for field in ('genre', 'country'):
        try:
            values = json.loads(store.get_flag(DF_FLAG % field) or '{}')
            out[field] = values if isinstance(values, dict) else {}
        except Exception:
            out[field] = {}
    try:
        total = int(store.get_flag(DF_FLAG % 'total') or 0)
    except (TypeError, ValueError):
        total = 0
    return out, total


def _vocabulary(field, limit):
    raw = db().get_flag(VOCAB_FLAG % field)
    if raw:
        try:
            values = json.loads(raw)
            if isinstance(values, list) and values:
                return values[:limit]
        except Exception:
            pass
    # Nothing stored yet (first run before the service tick): count now rather
    # than hand the caller an empty list.
    if refresh_vocabulary(limit):
        try:
            values = json.loads(db().get_flag(VOCAB_FLAG % field) or '[]')
            if isinstance(values, list):
                return values[:limit]
        except Exception:
            pass
    return []




