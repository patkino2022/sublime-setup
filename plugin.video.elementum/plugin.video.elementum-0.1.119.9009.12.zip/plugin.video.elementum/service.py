# -*- coding: utf-8 -*-
# sublime-setup: апстрим elgatito 0.1.119 + правки автора (полный локальный движок,
# торрент в памяти вместо папки загрузок, без Trakt и библиотеки) - настройки принудительно при старте.
import io
import os
import re
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'resources', 'site-packages'))


def cleanup_settings():
    # Kodi auto-names id-less legacy settings labelN/actionN, and its counter grows on every settings reload, so stale ids pile up in user settings (#1208).
    # Must run before the first xbmcaddon.Addon() loads the values, otherwise they are saved back.
    try:
        from xbmcvfs import translatePath
    except ImportError:
        from xbmc import translatePath

    path = translatePath('special://profile/addon_data/plugin.video.elementum/settings.xml')
    try:
        with io.open(path, 'r', encoding='utf-8') as f:
            content = f.read()
        cleaned = re.sub(r'[ \t]*<setting id="(?:label|action)\d+"[^>]*?(?:/>|>[^<]*</setting>)[ \t]*\r?\n?', '', content)
        if cleaned != content:
            with io.open(path, 'w', encoding='utf-8') as f:
                f.write(cleaned)
    except Exception:
        pass


cleanup_settings()

from kodi_six import xbmcaddon

ADDON_ID = 'plugin.video.elementum'
BUILD_MARKER = 'ELEMENTUM_BUILD_0_1_119_9009_2_FULL_ENGINE_TAM_MAGNET_MEMORY_STORAGE_NO_TRAKT'


def _set(addon, key, value):
    # Пишем только отличающееся: ~75 setSetting на каждом старте сохраняли
    # settings.xml заново, даже когда всё уже стояло (21.11.2026).
    try:
        if addon.getSetting(key) != value:
            addon.setSetting(key, value)
    except Exception:
        pass


def _force_tam_magnet_low_memory_mode():
    addon = xbmcaddon.Addon(ADDON_ID)

    forced = {
        # Critical for TAM: Elementum must be a full local engine, not a thin/on-demand client.
        'local_only_client': 'false',
        'local_force_library': 'false',
        'startup_delay': '0',
        'greeting_enabled': 'false',

        # Reduce startup/background work. Direct magnet/TAM play does not need providers/library scans.
        'skip_burst_search': 'false',   # каталог Elementum ищет раздачи через Burst
        'skip_repository_search': 'true',
        'library_enabled': 'false',
        'library_sync_enabled': 'false',
        'library_sync_playback_enabled': 'false',
        'library_nfo_movies': 'false',
        'library_nfo_shows': 'false',
        'autoload_torrents': 'false',
        'autoload_torrents_paused': 'false',
        'use_torrent_history': 'false',
        'use_cache_search': 'false',
        'use_cache_selection': 'false',
        'use_cache_torrents': 'false',
        'show_files': 'false',
        'show_files_watched': 'false',
        'osdb_auto_load': 'false',
        'osdb_included_enabled': 'false',
        'platform_updates_interval': '0',

        # Torrent is kept in memory (no free space needed in a download folder).
        # Memory, buffer, connections and timeouts are sized by the installer
        # (install.py elementum_tuning) for the box RAM and line speed - not forced here.
        # The buffer before start is buffer_size only: auto_kodi_buffer_size would raise
        # it to Kodi's <cache><memorysize> from advancedsettings.xml (60-150 MB).
        'download_storage': '1',
        'auto_memory_size': 'false',
        'auto_memory_size_strategy': '0',
        'auto_adjust_memory_size': 'false',
        'auto_kodi_buffer_size': 'false',
        'disk_cache_size': '8',
        'keep_downloading': '2',
        'keep_files_playing': '2',
        'keep_files_finished': '2',
        'seed_forever': 'false',

        # Reduce LAN discovery/NAT chatter. Do NOT disable DHT/TCP because magnet reliability depends on them.
        'disable_lsd': 'true',
        'disable_upnp': 'true',
        'disable_natpmp': 'true',
        'disable_utp': 'false',
        'disable_tcp': 'false',
        'disable_dht': 'false',
        'listen_autodetect_ip': 'true',
        'listen_autodetect_port': 'true',

        # Silence noisy debug logs while keeping real errors visible.
        'log_level': '1',
        'use_libtorrent_logging': 'false',

        # Trakt must be completely disabled in this build.
        'trakt_token': '',
        'trakt_username': '',
        'trakt_refresh_token': '',
        'trakt_token_expiry': '0',
        'force_use_trakt': 'false',
        'trakt_scrobble': 'false',
        'trakt_sync_enabled': 'false',
        'trakt_sync_playback_enabled': 'false',
        'trakt_sync_collections': 'false',
        'trakt_sync_watchlist': 'false',
        'trakt_sync_userlists': 'false',
        'trakt_sync_watched': 'false',
        'trakt_sync_watchedback': 'false',
        'trakt_sync_playback_progress': 'false',
        'trakt_sync_hidden': 'false',
        'trakt_sync_added_movies': 'false',
        'trakt_sync_added_shows': 'false',
        'trakt_sync_removed_movies': 'false',
        'trakt_sync_removed_movies_back': 'false',
        'trakt_sync_removed_shows': 'false',
        'trakt_sync_removed_shows_back': 'false',
        'trakt_sync_frequency_min': '0',
    }

    for key, value in forced.items():
        _set(addon, key, value)
    _size_memory_from_ram(addon)


def _ram_gb():
    try:
        with open('/proc/meminfo') as fp:
            for line in fp:
                if line.startswith('MemTotal:'):
                    return int(line.split()[1]) / 1024.0 / 1024.0
    except Exception:
        pass
    return 0


def _size_memory_from_ram(addon):
    """Earlier builds forced memory_size=64 and buffer_size=20 on every start, which
    overwrote the installer sizing. Boxes still on that exact pair get the installer
    sizing (same table as install.py elementum_tuning); any other value is left alone."""
    try:
        if addon.getSetting('memory_size') != '64' or addon.getSetting('buffer_size') != '20':
            return
        ram = _ram_gb()
        if not ram:
            return
        memory = 40 if ram <= 1 else 80 if ram <= 2 else 160 if ram <= 4 else 300 if ram <= 8 else 400
        _set(addon, 'memory_size', str(memory))
        _set(addon, 'buffer_size', str(min(12, memory // 3)))
        _set(addon, 'magnet_resolve_timeout', '45')
    except Exception:
        pass


def _write_build_marker():
    try:
        addon = xbmcaddon.Addon(ADDON_ID)
        profile = addon.getAddonInfo('profile')
        try:
            from kodi_six import xbmcvfs
            profile = xbmcvfs.translatePath(profile)
        except Exception:
            try:
                import xbmc
                profile = xbmc.translatePath(profile)
            except Exception:
                pass
        if not os.path.exists(profile):
            os.makedirs(profile)
        marker_path = os.path.join(profile, BUILD_MARKER + '.txt')
        text = (BUILD_MARKER + '\n'
                'mode=full_local_engine_for_tam_and_magnet\n'
                'local_only_client=false\n'
                'elementumd_startup=enabled_required_for_tam\n'
                'trakt=disabled\n'
                'library_sync=disabled\n'
                'memory_profile=memory_storage_sized_by_ram_no_download_folder_space_check\n')
        # Метка не меняется - перезаписывать её на каждом старте незачем (21.11.2026).
        try:
            with open(marker_path) as fp:
                if fp.read() == text:
                    return
        except Exception:
            pass
        with open(marker_path, 'w') as fp:
            fp.write(text)
    except Exception:
        pass


_force_tam_magnet_low_memory_mode()
_write_build_marker()

from elementum import service, config  # noqa: E402

config.init()
service.run()
