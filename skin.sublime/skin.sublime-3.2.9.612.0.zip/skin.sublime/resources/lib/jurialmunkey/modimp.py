from importlib import import_module


def importmodule(module_name, import_attr=None):
    module = import_module(module_name)
    if not import_attr:
        return module
    return getattr(module, import_attr)


