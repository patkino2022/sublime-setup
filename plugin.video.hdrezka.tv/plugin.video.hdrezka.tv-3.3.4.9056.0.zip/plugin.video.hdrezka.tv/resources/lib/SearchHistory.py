# -*- coding: utf-8 -*-
# Writer (c) 2019, dandy
# Rev. 1.0.0
# Licence: GPL v.3: http://www.gnu.org/copyleft/gpl.html

import sys
import xbmcaddon

ID = 'script.module.dandy.search.history'
import xbmc


def _addon():
    """Объект настроек на каждый вызов: при reuselanguageinvoker модуль живёт между вызовами,
    и старый объект записал бы в settings.xml HDRezka устаревшие cookies (21.11.2026)."""
    try:
        # спросить Kodi, есть ли модуль, а не ловить отказ: отказ Kodi пишет в журнал как ошибку
        if not xbmc.getCondVisibility('System.HasAddon(%s)' % ID):
            raise RuntimeError(ID)
        return xbmcaddon.Addon(ID)
    except RuntimeError:
        # sublime: модуля dandy может не быть (его нет в репозиториях Kodi 22) - история
        # поиска хранится в настройках самой HDrezka (скрытая настройка history)
        return xbmcaddon.Addon('plugin.video.hdrezka.tv')

def get_history():
        words = []
        history = _addon().getSetting('history')
        if history:
        	words = history.split(",")
        return words

def clean():
    _addon().setSetting('history', '')

def add_to_history(keyword):
    addon = _addon()
    words = []
    history = addon.getSetting('history')
    if history:
        words = history.split(",")
    if keyword and keyword not in words:
        words.append(keyword)
        addon.setSetting('history', ','.join(words))

def delete_from_history(keyword):
    addon = _addon()
    words = []
    history = addon.getSetting('history')
    if history:
        words = history.split(",")
        if keyword and keyword in words:
            words.remove(keyword)
            addon.setSetting('history', ','.join(words))
