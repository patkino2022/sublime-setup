# -*- coding: utf-8 -*-
"""Build a widget's rows completely, before anyone looks at them.

This is the piece the whole design turns on (docs/CONCEPT_WIDGET_MIRROR.md).
Today a row is finished at the moment focus lands on it: the service reads 77
info labels off the interface, resolves the film, goes to the network, blurs a
poster and extracts a colour - all on the thread that draws the frame. Measured
on <коробка>, that is where every pause, stuck background and flicker of this
session came from.

Here the same work happens in the background, once, and its result is written
into the row itself: the background is a path to a file that already exists, the
colour is already extracted, the identity is already resolved. When focus lands,
there is nothing left to do but read what the row says.

Nothing here touches the interface. It reads no labels, publishes no window
properties and never asks Kodi about the focused item - so it cannot be the
reason anything on screen waits.
"""
from __future__ import absolute_import, unicode_literals

import os
import re
import time

import xbmc

from . import learned, mirror
from .config import log, pause, stopping

# A row is worth resolving against the metadata providers only if it can be a
# film or an episode. A YouTube clip or a channel cannot, and asking wasted a
# full round trip per row - measured cold at 1.9-2.3 s each.
ENRICHABLE_MARKS = ('plugin.video.filmix', 'plugin.video.hdrezka.tv', 'plugin.video.elementum',
                    'videodb://', 'library://')
WASH_WAIT_SECONDS = 2.0
WASH_POLL = 0.1
# One row's worth of network and CPU. A pass yields between rows so a build never
# competes with the screen.
ROW_PAUSE = 0.05
BUSY_PAUSE = 1.0
# Пока работают пультом, сборщик не останавливается, а идёт медленнее: секунда
# между строками вместо 0.05 с. Полная остановка оставляла коробку, которой
# пользуются, без фонов: 16.11.2026 на .20 после установки 37 полос из 40
# остались необогащёнными, и фон каждой строки догружался по фокусу. Отклику
# курсора проход не мешает (замер на .30, 17.10.2026: 0.15-0.20 с и под
# нагрузкой, и без) - решение владельца 16.11.2026.
REMOTE_ROW_PAUSE = 1.0

# Срок обогащения строк (time.time(); 0 - без срока). После него проход строки не
# обогащает, а сразу пишет снимок с тем, что есть: заполнение кэшей при установке
# (fill_caches._lanes) иначе ждало полного обогащения всех виджетов - на чистой
# коробке это 37 виджетов по ~50 строк по 2-3 с, десятки минут на «сборке полос»
# (.20, 17.11.2026). Описания и фоны доливает следующий проход службы.
_ENRICH_UNTIL = {'t': 0.0}


def enrich_until(deadline):
    _ENRICH_UNTIL['t'] = float(deadline or 0)

# Проверка остановки и прерываемая пауза - общие для всего пакета, см.
# hub/config.py. Проход по строке ходит в сеть и ждёт цвет, поэтому начатая
# сборка обязана бросать работу, а не досыпать свои паузы.
_stopping = stopping
_pause = pause
# Сколько готовая строка живёт, прежде чем её обогащают заново.
#
# Измерено 30.08.2026 на <коробка>: пересборка зеркала шла каждые 15 минут и
# каждый раз прогоняла ВСЕ строки через _enrich_one - проверки «уже обогащена»
# здесь не было вовсе. За час это 4 вспышки по 4-5 минут, 64.5 % ядра на
# простаивающей коробке, и результат тот же самый: из 399 элементов первой
# вспышки в последней повторились все 399. Для сравнения, на <коробка> в тот
# же час работы не было ни одной - но лишь потому, что там шло воспроизведение
# и _busy() всё подавлял.
#
# Новая строка обогащается сразу и всегда: у неё нет прошлого блока. Этот срок
# управляет только ПОВТОРНЫМ обогащением уже готовой строки, то есть тем, как
# быстро подхватываются чужие правки метаданных - исправленный кадр серии,
# дописанное описание, изменившаяся оценка. Двенадцать часов дают два
# обновления в сутки и снимают 47 из каждых 48 проходов.
# 0 - пропуск выключен: каждый проход обогащает каждую строку, как было до
# 30.08.2026. Отметка built_at продолжает писаться, так что включить пропуск
# обратно - это поменять одно число.
#
# Почему выключен. Ради процессора на простаивающей коробке здесь стояло 12
# часов, и это сняло работу по метаданным полностью: вспышки упали с ~2100
# строк до 1-8, каждый виджет писал «обогащено 0, оставлено свежими 50». А
# процессор почти не сдвинулся: 64.5 % -> 58.7 %, всего 5.8 пункта. Гипотеза,
# что метаданные и есть главный расход, оказалась неверной - разложение по
# потокам показало kodi.bin 32.8 % против 17 % у всего нашего Python, то есть
# больше половины простоя тратит отрисовка, которая скину неподвластна.
# docs/PERFORMANCE_2026-08-28.md называл её «две трети всего» ещё двумя днями
# раньше - я этого документа вовремя не прочёл.
#
# Владелец распорядился вернуть свежесть, и по цифрам он прав: платить
# двенадцатью часами свежести за неполные шесть пунктов не за что.
#
# 17.10.2026 - два часа. Аудит на .20: проход шёл ~240 с каждые 15 минут
# (больше четверти времени, почти целое ядро) и каждый раз заново обогащал все
# ~650 строк при «оставлено свежими 0». Замер на .30 показал, что курсору это
# не мешает (название, логотип, фон - медиана 0.15-0.20 с и под нагрузкой, и
# без), так что это экономия процессора и нагрева, а не скорость. Владелец
# велел делать всё из аудита; компромисс со свежестью - два часа вместо
# двенадцати: семь проходов из восьми, правки метаданных подхватываются не
# позже чем через два часа, новые строки и сами списки - как раньше, сразу и
# каждые 15 минут. Вернуть как было - 0.
REBUILD_AFTER_SECONDS = 2 * 3600


# Считать ли загруженное медиа занятостью.
#
# По умолчанию да - проход не должен мешать просмотру. Но «загружено» это не
# «мешает»: 03.09.2026 владелец оставил ТВ-канал открытым с 21:11 до 06:39, и
# всё это время фоновая работа была подавлена целиком. Утром хаб оказался
# вчерашним: последний завершённый проход в 21:10, полосы с пометкой «кэш
# устарел (40659 с)». Пропущенное обновление он и увидел как «виджет подписки
# устаревший».
#
# Поэтому hub/service.py на редкий проход во время воспроизведения выставляет
# терпимость, и тогда занятостью считается только работа с пультом. Уступать
# пульту по-прежнему обязательно: там владелец ждёт отклика прямо сейчас.
_PLAYBACK_TOLERANT = {'on': False}


def playback_tolerant(value):
    """Разрешить проходу работать при загруженном медиа. Ставит service.py."""
    _PLAYBACK_TOLERANT['on'] = bool(value)


def _busy():
    try:
        # Пауза по просьбе дополнения (Window(Home).Property(Sublime.Hold)): Kodi в
        # эти секунды открывает поток и аппаратный декодер, и проход сборщика
        # (10.10.2026 - подписи каналов YouTube) задерживал видео на 2-3 с.
        if xbmc.getInfoLabel('Window(Home).Property(Sublime.Hold)'):
            return True
        if not _PLAYBACK_TOLERANT['on'] and xbmc.getCondVisibility('Player.HasMedia'):
            return True
        return False
    except Exception:
        return False


def _remote_active():
    """Пультом работали последние секунды - сборщик идёт медленнее (REMOTE_ROW_PAUSE)."""
    try:
        return xbmc.getGlobalIdleTime() < 5
    except Exception:
        return False


# Лучший из существующих вариантов обложки YouTube. Дешёвая замена в
# hub/mirror.py уже поставила hqdefault (он есть всегда), а здесь, в фоне, можно
# позволить себе спросить сервер и взять картинку крупнее, если она существует.
YT_CANDIDATES = ('maxresdefault', 'sddefault', 'hqdefault')
YT_PROBE_TIMEOUT = 4.0


def _art_reachable(url):
    """Отдаёт ли адрес картинку. Сборщик может подождать, экран - нет."""
    plain = url.replace('%2f', '/').replace('%2F', '/')
    start = plain.find('i.ytimg.com')
    if start < 0:
        return False
    from urllib.request import Request, urlopen
    try:
        return urlopen(Request('https://' + plain[start:].rstrip('/'), method='HEAD'),
                       timeout=YT_PROBE_TIMEOUT).status == 200
    except Exception:
        return False


def _best_youtube_art(value):
    """То же правило, что и в воронке зеркала, но с проверкой в сети."""
    return mirror.youtube_art_fallback(value, probe=_art_reachable)


def _fix_youtube_row(row):
    art = (row or {}).get('art') or {}
    for key, value in list(art.items()):
        better = _best_youtube_art(value)
        if better != value:
            art[key] = better
    return row


def _art_source(row):
    """The picture a row's background is made from, in the order that matters."""
    art = (row or {}).get('art') or {}
    for key in ('poster', 'thumb', 'icon', 'fanart', 'landscape'):
        value = art.get(key)
        if value:
            return str(value)
    return ''


def _wash_colour(source):
    """The washed background colour, waited for rather than polled by the skin."""
    if not source:
        return ''
    # Сборщик работает в своём потоке - цвет считается здесь же (prepare_wash_color_now).
    # request_wash_color держит очередь на одно место: строки, собираемые параллельно (поиск,
    # hub/search_rows.py), вытесняли друг друга и каждая ждала до WASH_WAIT_SECONDS
    # (.20, 21.11.2026: 4 ролика YouTube из 18 за 6 с).
    try:
        from ..sublime_helper.image_wash import prepare_wash_color_now
        colour = prepare_wash_color_now(source) or ''
        if colour:
            return colour
    except Exception:
        pass
    try:
        from ..sublime_helper.image_wash import request_wash_color
    except Exception:
        return ''
    deadline = time.time() + WASH_WAIT_SECONDS
    while True:
        try:
            colour = request_wash_color(source) or ''
        except Exception:
            return ''
        if colour or time.time() >= deadline:
            return colour
        # Здесь ждали через xbmc.sleep, и это была самая длинная задержка
        # остановки: до двух секунд на КАЖДОЙ строке, которую сборщик не
        # прерывал ни при каких обстоятельствах.
        if _pause(WASH_POLL):
            return colour


def _background(source):
    """The blurred 1920x1080 background, made here and now.

    prepare_background_now exists for exactly this: it does the work on the
    caller's thread instead of taking the latest-wins slot that belongs to the
    row the user is looking at.
    """
    if not source:
        return ''
    try:
        from ..sublime_helper.poster_background import prepare_background_now
        return prepare_background_now('poster', source) or ''
    except Exception as exc:
        log('сборка подложки не удалась: %s' % exc, xbmc.LOGDEBUG)
        return ''


_POST_IN_PATH = re.compile(r'/(\d+)-')


def _post_id(row):
    # У HDrezka путь страницы лежит в адресе закодированным (uri=%2Fseries%2F...%2F93709-...),
    # и без раскодирования сериал HDrezka не считался опознаваемым вовсе
    from urllib.parse import unquote
    hit = _POST_IN_PATH.search(unquote(str((row or {}).get('file') or '')))
    return hit.group(1) if hit else ''


def _enrichable(row):
    path = str((row or {}).get('file') or '')
    # Явная категория виджета (владелец задаёт её в настройках) сильнее любого
    # угадывания: у канала PVR и ролика YouTube у поставщиков нечего искать.
    try:
        from . import widget_kinds
        if path and not widget_kinds.enrichable(path):
            return False
    except Exception:
        pass
    if not any(mark in path for mark in ENRICHABLE_MARKS):
        return False
    if str((row or {}).get('filetype') or 'file') != 'file':
        # Папки бывают двух разных видов, и это правило их не различало.
        # Список - жанры, страны, «ещё»: измерено на .20, виджеты жанров и стран
        # Filmix давали 500 строк, и каждую сборщик пытался опознать у
        # поставщиков по названию вроде «Драмы». Но сериал - тоже папка, папка
        # с сезонами, и он - настоящее название. Отбрасывая все папки разом, мы
        # оставляли без опознания каждую строку каждой полосы сериалов:
        # измерено на .20 - 0 из 50 в new_shows, top_shows, ru_shows и в виджете
        # сериалов, то есть ни логотипа, ни широкого фона, ни оценки, тогда как
        # у полос фильмов опознавалось 24-48 из 50. Отличает их номер поста в
        # адресе: у сериала он есть, у списка его нет.
        if _post_id(row):
            return True
        # сериал HDRezka и Elementum - тоже папка, но номера поста Filmix у него нет: опознаётся
        # по типу и адресу сериала, иначе фоном всех сериалов становился постер
        kind = str((row or {}).get('mediatype') or (row or {}).get('type') or '')
        return kind == 'tvshow' or '/show/' in path or '/series/' in path
    return True


def _row_media_type(row):
    """Кино это или сериал - по тому, что сказал источник строки.

    Строки нашего каталога называют это полем mediatype, строки Kodi - type.
    Читалось только второе, и наши полосы приходили на опознание без типа.
    """
    value = str((row or {}).get('type') or (row or {}).get('mediatype') or '').strip().lower()
    return '' if value in ('', 'unknown') else value


def _local_from_row(row):
    """A metadata model built from the ROW, not from the interface."""
    art = {k: v for k, v in ((row or {}).get('art') or {}).items() if v}
    year = row.get('year') or 0
    return {
        'dbid': 0,
        'dbtype': _row_media_type(row),
        'media_type': _row_media_type(row),
        'tmdb_type': '',
        'title': str(row.get('label') or row.get('title') or ''),
        # Оригинальное название выбрасывалось, и опознание шло по одному
        # русскому. «Бункер» на TMDb называется «Укрытие» (Silo, оценка 8.2) и
        # в выдаче по слову «Бункер» стоит третьим - строка так и оставалась
        # без опознания, а значит без логотипа, оценки и широкого кадра.
        'originaltitle': str(row.get('originaltitle') or ''),
        'plot': _clean_plot(str(row.get('plot') or '')),
        'premiered': str(row.get('premiered') or ''),
        'year': int(year) if str(year).isdigit() else 0,
        'genre': list(row.get('genre') or []),
        'country': [],
        'studio': [],
        'file': str(row.get('file') or ''),
        'art': art,
        'cast': [],
        'crew': {'director': [], 'writer': []},
        # Номера, которые дал сам источник (HDrezka со страницы фильма, Elementum,
        # библиотека Kodi): по ним опознание точное и без поиска по названию.
        # Раньше они до фонового опознания не доходили, и новинки HDrezka с
        # редким названием оставались без описания, логотипа и трейлера.
        'imdb_id': _row_id(row, 'imdb'),
        'tmdb_id': _row_id(row, 'tmdb'),
        'kinopoisk_id': _row_id(row, 'kinopoisk'),
    }


def _row_id(row, name):
    ids = (row or {}).get('uniqueid') or {}
    value = str(ids.get(name) or '').strip()
    if name == 'imdb' and not value.startswith('tt'):
        value = next((str(v) for v in ids.values() if str(v).startswith('tt')), '')
    return '' if value in ('', '0') else value


def _resolve(row, force=False):
    """What the providers know about this row. Empty dict if nothing applies.

    force - опознавать и строки источников вне ENRICHABLE_MARKS: результаты поиска (RuTor и
    любые другие) - это фильмы и сериалы по названию, без опознания у них не было оценок."""
    if not force and not _enrichable(row):
        return {}
    ids = {}
    if force and not _enrichable(row):
        # строка поиска чужого источника: опознаём только по номеру, который он дал сам, и
        # принимаем ответ, лишь если номер совпал. По одному названию раздача «Время
        # счастливых» стала документальным фильмом, а альбом «Северное сияние» - драмой (.20)
        ids = {k: _row_id(row, k) for k in ('kinopoisk', 'imdb', 'tmdb')}
        ids = {k: str(v) for k, v in ids.items() if v}
        if not ids:
            return {}
    try:
        from ..sublime_helper.core import fetch_online_metadata
        from ..sublime_helper import config as helper_config
    except Exception:
        return {}
    try:
        if not helper_config.online_enabled():
            return {}
    except Exception:
        pass
    local = _local_from_row(row)
    if not local['title']:
        return {}
    try:
        # cancel_check=stopping - потому что этот вызов синхронный и идёт из
        # главного цикла службы скина. Kodi даёт скрипту 5 секунд на остановку,
        # а здесь три источника подряд с таймаутом curl 12 с каждый: строки
        # [sublime metadata] шли в журнале ПОСЛЕ «Unloaded skin», и деплой на
        # <коробка> 03.09.2026 снова получил «script didn't stop in 5
        # seconds». Проверки остановки по строкам в build() было мало: она не
        # помогает строке, запрос по которой уже начался.
        #
        # Чего это НЕ даёт: мгновенной отмены. fetch_online_metadata смотрит
        # cancel_check на границах между источниками, а не внутри HTTP-запроса,
        # так что один запрос в полёте всё равно доживёт до своего таймаута.
        # Худший случай падает с трёх таймаутов до одного, а не до нуля.
        # kp_search=False: фоновый проход не тратит суточную норму Кинопоиска
        # на поиск личности - см. _resolve_kinopoisk в sublime_helper/core.py.
        # Уже опознанные строки он оттуда получит по кешу личности, бесплатно.
        # Результаты поиска (force) - действие владельца и единицы строк: Кинопоиск им можно,
        # иначе раздача с номером Кинопоиска опознавалась в TMDb по названию не тем фильмом
        # («Время счастливых» - документальный, .20, 21.11.2026).
        # логотип не откладывать: фон и так ждёт тишины, а отложенный логотип засчитывался как
        # «логотипа нет» и уходил в строку (аудит 22.11.2026)
        from ..sublime_helper.core import logo_fetch_scope
        with logo_fetch_scope(True):
            meta = fetch_online_metadata({'kp_search': bool(force)}, local,
                                         cancel_check=stopping) or {}
        if ids:
            got = {'kinopoisk': meta.get('kinopoisk_id') or (meta.get('uniqueid') or {}).get('kinopoisk'),
                   'imdb': meta.get('imdb_id'), 'tmdb': meta.get('tmdb_id')}
            if not any(str(got.get(k) or '') == v for k, v in ids.items()):
                log('опознание строки поиска отброшено: номер не совпал (%s / %s)' % (ids, got), xbmc.LOGINFO)
                return {}
        return meta
    except Exception as exc:
        log('опознание строки не удалось: %s' % exc, xbmc.LOGDEBUG)
        return {}


def _plot_for_screen(meta, row):
    """Описание строки: своё русское важнее нерусского из ответа."""
    local = str((row or {}).get('plot') or '')
    answer = str((meta or {}).get('plot') or '')
    try:
        from ..sublime_helper.core import prefer_local_plot
        return prefer_local_plot(answer, local)
    except Exception:
        return answer or local


def _title_for_screen(meta, row):
    """Название строки: своё русское важнее оригинального из ответа."""
    label = str((row or {}).get('label') or (row or {}).get('title') or '')
    answer = str((meta or {}).get('title') or '')
    try:
        from ..sublime_helper.core import prefer_local_title
        return prefer_local_title(answer, label)
    except Exception:
        return answer or label


# Столько строк за один проход.
#
# Шесть было слишком мало: полный обход 850 строк занимал два с половиной
# часа, и владелец видел «подложка есть у 48 строк из 50, а студия у 27».
# Двадцать пять оказалось слишком много: замер на .20 06.09.2026 - «сведения
# дописаны в 25 строк» каждую минуту без остановки, при этом коробка сидела в
# ожидании диска (41.8 % iowait, load average 4.9 на пяти ядрах), и владелец
# сказал «интерфейс лагает, канал включается долго». Каждая строка - это ответ
# поставщика И перезапись снимка на диск.
#
# Десять: обход 850 строк за час с небольшим, и это фон, а не работа наперегонки
# с плеером.
TOP_UP_LIMIT = 10


TOP_UP_KEYS = ('studio', 'premiered', 'rating', 'logo')


META_RECHECK_SECONDS = 24 * 3600      # строку без части сведений переспрашиваем не чаще раза в сутки


def _fallback_background(enriched):
    """Фон блока - постер самой строки (заглушка: кадра не было, фильм не опознался)."""
    background = str((enriched or {}).get('background') or '')
    poster = str((enriched or {}).get('poster') or '')
    return bool(background) and background == poster and not str((enriched or {}).get('tmdb_id') or '')


def _needs_meta(row):
    """Строка уже собрана, но части сведений в ней нет."""
    enriched = (row or {}).get('sublime') or {}
    if not enriched:
        return False
    if '<' in str(enriched.get('plot') or ''):
        # Описание с разметкой надо вычистить, даже если всё остальное на месте:
        # скин читает Sublime.Plot прямо из строки.
        return True
    if not any(not enriched.get(key) for key in TOP_UP_KEYS) and not _fallback_background(enriched):
        # Всё на месте.
        return False
    if enriched.get('_meta_checked') and enriched.get('_meta_tries'):
        # Три пустых попытки уже было - оставляем строку в покое на сутки (у поставщика
        # сведения могли появиться); без срока пометка терялась при пересборке и строку
        # опрашивали трижды каждые два часа (.30, 22.11.2026: «Вествуд» 176 раз за 11 часов).
        try:
            checked_at = float(enriched.get('_meta_checked_at') or 0)
        except (TypeError, ValueError):
            checked_at = 0
        # пометка без времени - от прежних версий: переспросить один раз и поставить время
        return not checked_at or time.time() - checked_at >= META_RECHECK_SECONDS
    if enriched.get('_meta_checked'):
        # Пометка от старого правила: она ставилась после ОДНОГО пустого
        # ответа поставщика, и на .20 05.09.2026 это дало 35 помеченных строк
        # из 48 при студии всего у 27 из 50. Счётчика у такой пометки нет, и
        # по нему её видно - даём строке те же три попытки, что и всем.
        return True
    return True


# Оценки, которые скин умеет показывать в инфостроке (слоты
# CustomRating.*.ItemNN). Ключ в строке -> источник в ответе поставщика и шкала.
#
# Шкала важна: десятибалльные печатаются с одним знаком, процентные - целым
# числом, и делить их на десять нельзя. До 07.09.2026 в строке лежала одна
# оценка на всех, и она публиковалась как TMDb - см. _row_ratings в
# sublime_helper/core.py.
RATING_SOURCES = (
    ('rating_tmdb', 'tmdb', 'ten'),
    ('rating_imdb', 'imdb', 'ten'),
    ('rating_kp', 'kinopoisk', 'ten'),
    ('rating_trakt', 'trakt', 'ten'),
    ('rating_letterboxd', 'letterboxd', 'ten'),
    ('rating_meta', 'metacritic', 'percent'),
    ('rating_rt', 'rottentomatoes', 'percent'),
    ('rating_rtuser', 'rottentomatoes_user', 'percent'),
    ('rating_mdblist', 'mdblist', 'percent'),
)


def _source_rating(meta, source, scale='ten'):
    """Оценка одного источника в том виде, в каком её показывает инфострока."""
    ratings = (meta or {}).get('ratings') or {}
    block = ratings.get(source)
    if source == 'kinopoisk' and not block:
        block = ratings.get('kp')
    value = block.get('rating') if isinstance(block, dict) else block
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ''
    if number <= 0:
        return ''
    if scale == 'percent':
        return '%d' % round(number)
    while number > 10.0:
        number /= 10.0
    return '%.1f' % number


def top_up_meta(limit=TOP_UP_LIMIT, cancel=None):
    """Дописать в готовые строки студию, дату и оценку. Картинки не трогает.

    Отдельно от общей сборки и БЕЗ требования простоя. Причина - замер на .20
    05.09.2026: коробка в руках владельца, сборщик ждёт минуты молчания пульта и
    не выполняется ни разу, поэтому в 749 собранных строках `wash` есть у всех, а
    `studio` и `premiered` - ни у одной. На экране это выглядит как «логотипы
    студий пропали» и «инфострока грузится через минуту после фона и цвета»:
    фон и цвет лежат в строке готовыми, а остальное ждёт опознания в TMDB на
    каждом наведении заново.

    Тяжёлого здесь ничего нет: ни скачивания картинки, ни размытия - только
    ответ провайдера, чаще всего уже лежащий в его кеше. Поэтому проход идёт
    малыми порциями и его можно держать на коротких часах.

    Строка, для которой провайдер ничего не знает, помечается и больше не
    переспрашивается.
    """
    # Прошлый проход дописывать было нечего и с тех пор ни один снимок не менялся - разбирать
    # все снимки снова незачем (раньше раз в минуту, аудит 21.11.2026).
    stamp = _snapshots_stamp()
    if _TOPUP_IDLE.get('stamp') == stamp:
        return 0
    done = _top_up_meta_pass(limit, cancel)
    _TOPUP_IDLE['stamp'] = stamp if done == 0 else None
    return done


_TOPUP_IDLE = {}


def _snapshots_stamp():
    """Отпечаток каталога снимков: имена, время изменения и размеры файлов."""
    try:
        folder = mirror._folder()
        return tuple(sorted((name, int(os.stat(os.path.join(folder, name)).st_mtime), os.path.getsize(os.path.join(folder, name)))
                            for name in os.listdir(folder) if name.endswith('.json')))
    except Exception:
        return None


def _top_up_meta_pass(limit, cancel):
    done = 0
    for src, rows in mirror.iter_snapshots():
        if done >= max(1, int(limit)):
            break
        changed = False
        for row in rows:
            if done >= max(1, int(limit)):
                break
            if cancel is not None:
                try:
                    if cancel():
                        return done
                except Exception:
                    pass
            # Разметку в описании лечим на месте, без поставщика. Раньше
            # «<br />» в снимке считался поводом переспросить всё заново
            # (_needs_meta), то есть тратил и норму Кинопоиска, и время - хотя
            # чистить текст сеть не нужна вовсе.
            stored = row.get('sublime') or {}
            plot = str(stored.get('plot') or '')
            if '<' in plot or '&' in plot:
                fixed = _clean_plot(plot)
                if fixed and fixed != plot:
                    stored = dict(stored)
                    stored['plot'] = fixed
                    row['sublime'] = stored
                    changed = True
            if not _needs_meta(row):
                continue
            try:
                meta = _resolve(row)
            except Exception as exc:
                log('дописать сведения не удалось: %s' % exc, xbmc.LOGDEBUG)
                meta = {}
            enriched = dict(row.get('sublime') or {})
            before = dict(enriched)
            row_title = enriched.get('title') or row.get('label') or ''
            row_year = enriched.get('year') or row.get('year') or ''
            if not enriched.get('studio'):
                enriched['studio'] = _remember_studio(meta, row_title, row_year)
            if not enriched.get('studio'):
                # Тот же фильм в другой полосе студию уже получил - берём
                # оттуда, без сети. Замер на .20 05.09.2026: «Холоп 3» в полосе
                # «Новинки» знал студию Yellow, Black & White, а он же в полосе
                # «Русские» стоял с пустой - и ждал опознания заново на каждом
                # наведении. Память для того и заведена (hub/studios.py), но её
                # только ЗАПОЛНЯЛИ и ни разу не спрашивали.
                try:
                    from . import studios
                    enriched['studio'] = studios.lookup(row_title, row_year)
                except Exception as exc:
                    log('память студий не прочитана: %s' % exc, xbmc.LOGDEBUG)
            if not enriched.get('premiered'):
                enriched['premiered'] = str(meta.get('premiered')
                                            or meta.get('release_date')
                                            or meta.get('first_air_date') or '')
            if not enriched.get('rating'):
                enriched['rating'] = _first_rating(meta)
            for key, source, scale in RATING_SOURCES:
                if not enriched.get(key):
                    enriched[key] = _source_rating(meta, source, scale)
            # Описание в уже собранной строке лечим на месте: скин читает
            # Sublime.Plot прямо из строки, а в снимках лежат описания с
            # разметкой от Кинопоиска (замер на .30 07.09.2026 - 152 строки).
            # Переопознание для этого не нужно.
            if '<' in str(enriched.get('plot') or ''):
                enriched['plot'] = _clean_plot(enriched.get('plot'))
            if _fallback_background(enriched):
                # Фон строки - постер-заглушка (собрана, пока фильм не опознавался), а теперь у
                # опознанного есть кадр: фон пересобирается из кадра. Раньше дозаполнение фон не
                # трогало вовсе, и «Формула-1» после опознания так и стояла на постере (.20, 22.11.2026)
                meta_art = meta.get('art') or {}
                source = meta_art.get('fanart') or meta_art.get('landscape') or ''
                if source:
                    prepared = _background(source)
                    if prepared:
                        enriched['background'] = str(source)
                        enriched['fanart'] = str(source)
                        enriched['prepared'] = prepared
                        enriched['wash'] = _wash_colour(prepared or source)
                        enriched['built_at'] = int(time.time())
                        if meta.get('tmdb_id'):
                            enriched['tmdb_id'] = str(meta.get('tmdb_id'))
            if not enriched.get('logo'):
                # Клиарлого туда же, в строку: инфопанель читает его из
                # готовой строки (core._model_from_row, ключ Logo), а не ждёт
                # опознания. На .20 05.09.2026 логотип был у 312 строк из 889.
                enriched['logo'] = str((meta.get('art') or {}).get('clearlogo')
                                       or '')
            if enriched == before or not meta:
                # Поставщик ответил, но ничего нового не дал. Раньше такая
                # строка оставалась непомеченной и переспрашивалась КАЖДУЮ
                # минуту вечно: замер на .20 05.09.2026 - «сведения дописаны в
                # 6 строк» в 10:20:13, 10:21:17, 10:22:20, и всё это одни и те
                # же шесть строк с status=no_match, то есть шесть поисков в
                # TMDb, IMDb и Кинопоиске за минуту без всякого толка. Трёх
                # попыток довольно: сеть могла и просто не ответить, а на
                # четвёртый раз ясно, что данных нет.
                try:
                    tries = int(enriched.get('_meta_tries') or 0) + 1
                except Exception:
                    tries = 1
                enriched['_meta_tries'] = tries
                if tries >= 3:
                    enriched['_meta_checked'] = True
                    enriched['_meta_checked_at'] = int(time.time())
            if all(enriched.get(key) for key in TOP_UP_KEYS):
                # Всё нашли - спрашивать больше нечего.
                enriched['_meta_checked'] = True
            if enriched != before:
                row['sublime'] = enriched
                changed = True
            done += 1
        if changed:
            mirror.store(src, rows)
    if done:
        try:
            from . import studios
            studios.flush()
        except Exception as exc:
            log('память студий не сохранена: %s' % exc, xbmc.LOGDEBUG)
        log('сведения дописаны в %d строк' % done)
    return done


def _clean_plot(value):
    """Описание без служебной разметки - см. sublime_helper/model.clean_text.

    Строка хаба хранит описание готовым, и разметка из ответа Кинопоиска
    («<br />») попадала в снимок, а оттуда на экран. Чистим здесь же, чтобы
    старые снимки вылечились сами при пересборке.
    """
    try:
        from ..sublime_helper.model import clean_text
        return clean_text(value)
    except Exception:
        return str(value or '')


def _first_rating(meta):
    """Оценка одним числом - в том виде, в каком её показывает инфострока."""
    value = (meta or {}).get('rating')
    if not value:
        ratings = (meta or {}).get('ratings') or {}
        for source in ('tmdb', 'imdb', 'kp', 'kinopoisk'):
            block = ratings.get(source) or {}
            value = block.get('rating') if isinstance(block, dict) else block
            if value:
                break
    try:
        number = float(value)
    except (TypeError, ValueError):
        return ''
    if number <= 0:
        return ''
    return '%.1f' % number


def _remember_studio(meta, title, year):
    """Имя студии для строки - и заодно в общую память.

    Память нужна полосам, которые сборщик не трогает: «Избранное» и
    «Отложенные» провайдера живые, снимка у них нет, и логотип студии там ждал
    опознания в TMDB. Владелец: «в избранном у сериалов нет студио лого» и
    «появились, но сильно позже, чем в списке Все».
    """
    # первое имя сети или студии, у которого есть картинка (hub/studio_logo.py), иначе первое как есть
    names = _all_names((meta or {}).get('networks')) + _all_names((meta or {}).get('studio'))
    name = ''
    try:
        from . import studio_logo
        name = studio_logo.first_with_logo(names)[0]
    except Exception as exc:
        log('картинка студии не проверена: %s' % exc, xbmc.LOGDEBUG)
    name = name or (names[0] if names else '')
    if name:
        try:
            from . import studios
            studios.remember(title, year, name)
        except Exception as exc:
            log('студия не запомнена: %s' % exc, xbmc.LOGDEBUG)
    return name


def _all_names(value):
    """Все имена из списка, строки («A, B» или «A / B») или словарей провайдера, по порядку."""
    if not value:
        return []
    if isinstance(value, str):
        return [part.strip() for part in re.split(r'\s*/\s*|\s*,\s*', value) if part.strip()]
    out = []
    try:
        for item in value:
            if isinstance(item, dict):
                name = str(item.get('name') or item.get('title') or '').strip()
            else:
                name = str(item or '').strip()
            if name and name not in out:
                out.append(name)
    except TypeError:
        pass
    return out


def _first_name(value):
    """Первое имя из того, что провайдер отдал списком, строкой или словарями."""
    if not value:
        return ''
    if isinstance(value, str):
        return value.split(',')[0].strip()
    try:
        for item in value:
            if isinstance(item, dict):
                name = str(item.get('name') or item.get('title') or '').strip()
            else:
                name = str(item or '').strip()
            if name:
                return name
    except TypeError:
        return ''
    return ''


def _enrich_one(row, force=False):
    """Everything this row needs to be drawn, computed here."""
    _fix_youtube_row(row)
    meta = _resolve(row, force=force)
    art = dict((meta.get('art') or {}))
    if not art:
        art = (row or {}).get('art') or {}
    source = (art.get('fanart') or art.get('landscape')
              or _art_source(row))
    poster = art.get('poster') or _art_source(row)
    prepared = _background(source or poster)
    enriched = {
        # В строке лежит НАСТОЯЩИЙ кадр - тот же, что показывает живой путь.
        # Раньше здесь лежал наш готовый файл, и разметка (Includes_Images.xml,
        # Image_Foreground) брала именно его, минуя службу: на экране это были
        # две разные картинки одного фильма - резкая в «Избранном» и размытая
        # в «Все», - и владелец это увидел. Готовый файл остаётся, но своим
        # свойством и для своего слоя: он показывается, пока Kodi не скачал
        # кадр, и в заглушке у строк, у которых кадра нет вовсе.
        'background': str(source or poster or ''),
        'prepared': prepared,
        # Готовая подложка - это обрезанный и размытый файл. Панелям сведений
        # нужна и исходная картинка: служба публикует её как Fanart, а подложку
        # как BlurImage (sublime_helper/core.py, _model_from_row).
        'fanart': str(source or ''),
        # Цвет берётся из ГОТОВОЙ подложки, а не из удалённого адреса: файл уже
        # лежит рядом, и цвет появляется вместе с картинкой, а не после её
        # загрузки. Владелец видел это как «washed color приезжает позже всего».
        'wash': _wash_colour(prepared or source or poster),
        'logo': art.get('clearlogo') or '',
        # Имя студии (для сериалов - сети) кладётся заранее, ровно как фон и
        # цвет. Владелец спросил, почему логотип канала ютуб появляется сразу, а
        # логотип студии - медленно: у строки ютуба идентификатор канала есть
        # сразу, а имя студии до сих пор приходило только после опознания фильма
        # в TMDB, и служба ждала именно опознания (vcl_service, кандидат
        # sublime-studio). Сам поиск файла логотипа мгновенный.
        'studio': _remember_studio(
            meta, _title_for_screen(meta, row),
            meta.get('year') or row.get('year') or ''),
        'poster': poster or '',
        'plot': _plot_for_screen(meta, row),
        'title': _title_for_screen(meta, row),
        'year': meta.get('year') or row.get('year') or '',
        'genre': ', '.join(str(x) for x in (meta.get('genre') or row.get('genre') or []) if x),
        'country': meta.get('country_text') or ', '.join(
            str(x) for x in (meta.get('country') or []) if x),
        # Оценка и дата - тоже заранее. Раньше здесь стояла пустая строка, и
        # инфострока ждала опознания в TMDB, чтобы показать рейтинг, дату,
        # жанры и страну; жанр и страна уже лежали в строке, а оценки и даты не
        # было вовсе. Владелец: «инфостроку с рейтингами, датами, жанрами и
        # странами тоже туда же заранее надо класть».
        'rating': _first_rating(meta),
        'premiered': str(meta.get('premiered') or meta.get('release_date')
                         or meta.get('first_air_date') or ''),
        'tmdb_id': meta.get('tmdb_id') or '',
        'tmdb_type': meta.get('tmdb_type') or '',
        # Когда эта строка была собрана. По ней build() решает, не рано ли
        # собирать её заново (REBUILD_AFTER_SECONDS). У строк из снимков,
        # сделанных до появления отметки, её нет - они пересобираются один раз
        # и дальше живут по общему правилу.
        'built_at': int(time.time()),
    }
    # Оценки по источникам - все, какие скин умеет показать в слотах
    # инфостроки. Владелец: «все включённые в настройках скина рейтинги туда
    # надо положить». Кладём всё, что поставщик дал: строка от этого длиннее на
    # несколько коротких строк, а показ каждой оценки перестаёт ждать сети.
    for _key, _source, _scale in RATING_SOURCES:
        _value = _source_rating(meta, _source, _scale)
        if _value:
            enriched[_key] = _value
    # Кадр просится в кеш текстур Kodi здесь же: строка попадёт на экран
    # позже, и к тому времени картинка уже будет разложена. Иначе первый показ
    # ждёт сеть - ровно то, чего в этом хабе быть не должно.
    try:
        from ..sublime_helper.core import _fetch_texture_async
        _fetch_texture_async(enriched.get('background') or '')
    except Exception:
        pass

    # What was found here is remembered for the lane builder, which is what
    # hub/warm.py used to do by reading the interface.
    # Номера постов у разных источников пересекаются: запоминаем только Filmix,
    # для которого эта память и заведена.
    post_id = _post_id(row) if 'plugin.video.filmix' in str((row or {}).get('file') or '') else ''
    if post_id:
        learned.remember_ids(post_id, {'tmdb': meta.get('tmdb_id'),
                                       'imdb': meta.get('imdb_id')})
        if enriched.get('plot'):
            learned.remember_plot(post_id, enriched['plot'])

    ratings = meta.get('ratings') or {}
    for name in ('tmdb', 'imdb', 'kinopoisk'):
        value = (ratings.get(name) or {}).get('rating') if isinstance(ratings.get(name), dict) else None
        if value:
            enriched['rating'] = str(value)
            break
    return {k: v for k, v in enriched.items() if v not in (None, '')}


def build(src, rows=None):
    """Build one widget's snapshot. Returns how many rows carry enrichment.

    Собирать заранее имеет смысл только каталог: у «избранного» и телегида
    ответ обязан быть сегодняшним, а не подготовленным (hub/mirror.py,
    category). Наши собственные полосы приходят сюда своим путём и каталогом
    являются по определению.
    """
    if rows is None and mirror.category(src) not in ('каталог', ''):
        return 0
    rows = rows if rows is not None else mirror.fetch(src)
    if not rows:
        return 0
    # Уже собранное из прошлого снимка. Пересборка берёт у источника свежие
    # строки, и до тех, до которых очередь не дошла, экран оставался без
    # картинки: сборка прерывается, как только владелец берётся за пульт, и
    # снимок сохранялся с горсткой обогащённых строк. Измерено на .20
    # 2026-08-29: в полосе новинок сериалов осталось 14 строк с фоном из 50, и
    # у «Джек Ричер» с «Великолепной пятёркой» вместо фона была заглушка.
    # Ничего не убирается с экрана, пока нечем заменить: строка без своего
    # свежего обогащения берёт прошлое.
    previous = {}
    try:
        for old_row in (mirror.rows(src) or []):
            block = old_row.get('sublime')
            key = str(old_row.get('file') or '') or str(old_row.get('label') or '')
            if key and isinstance(block, dict) and block:
                previous[key] = block
    except Exception:
        previous = {}

    def _keep_previous(row):
        if row.get('sublime'):
            return
        block = previous.get(str(row.get('file') or '') or str(row.get('label') or ''))
        if block:
            row['sublime'] = block

    def _still_fresh(row):
        """Готовый блок из прошлого снимка, если переделывать его ещё рано."""
        block = previous.get(str(row.get('file') or '') or str(row.get('label') or ''))
        if not isinstance(block, dict) or not block.get('background'):
            return None
        try:
            age = time.time() - float(block.get('built_at') or 0)
        except (TypeError, ValueError):
            return None
        return block if 0 <= age < REBUILD_AFTER_SECONDS else None

    built = 0
    fresh = 0
    for row in rows:
        # Свежую строку не трогаем совсем: ни сети, ни разбора, ни паузы. Это
        # проверяется ДО _busy(), потому что дешёвый пропуск не повод прерывать
        # проход - иначе на занятой коробке зеркало не обновится никогда.
        if _stopping():
            log('сборка прервана на %d строке: Kodi останавливают' % built)
            break
        ready = _still_fresh(row)
        if ready is not None:
            row['sublime'] = ready
            fresh += 1
            continue
        if _ENRICH_UNTIL['t'] and time.time() > _ENRICH_UNTIL['t']:
            break
        if _busy():
            # Просмотр или пауза по просьбе дополнения. Готовые строки
            # сохраняются, остальные - в следующий проход.
            log('сборка приостановлена на %d строке: бокс занят' % built)
            break
        try:
            enriched = _enrich_one(row)
        except Exception as exc:
            log('строка не собрана: %s' % exc, xbmc.LOGDEBUG)
            continue
        if enriched:
            # Пометку «спрашивали, данных нет» пересборка не стирает: иначе каждая пересборка
            # (раз в два часа) снова давала три опроса поставщиков на строку
            prev = previous.get(str(row.get('file') or '') or str(row.get('label') or '')) or {}
            for meta_key in ('_meta_tries', '_meta_checked', '_meta_checked_at'):
                if meta_key in prev and meta_key not in enriched:
                    enriched[meta_key] = prev[meta_key]
            row['sublime'] = enriched
            built += 1
        else:
            _keep_previous(row)
        if _pause(REMOTE_ROW_PAUSE if _remote_active() else ROW_PAUSE):
            log('сборка прервана после %d строки: Kodi останавливают' % built)
            break
    for row in rows:
        _keep_previous(row)
    kept = sum(1 for row in rows if row.get('sublime')) - built - fresh
    if built or fresh or kept:
        mirror.store(src, rows)
    log('собран виджет %s: обогащено %d, оставлено свежими %d, взято из '
        'прошлого снимка %d, всего строк %d'
        % (str(src)[-48:], built, fresh, max(0, kept), len(rows)))
    return built


LANE_SRC = 'plugin://skin.sublime/?info=hub_lane&name=%s'
WIDGET_SRC = 'plugin://skin.sublime/?info=hub_widget&category=%s'


def build_lane(name):
    """Our own lane, built the same way as anyone else's widget.

    The rows come from hub/lanes.py rather than from another add-on, and that is
    the only difference: they are enriched here, once, so the route can hand
    them over finished. This is what makes hub/warm.py unnecessary - it existed
    to have the same answers ready by reading them off the interface.
    """
    try:
        from . import lanes
        from .config import get_int
        rows = lanes.get_lane(name, max(3600, get_int('refresh_hours', 12) * 3600))
    except Exception as exc:
        log('полоса %s не прочитана: %s' % (name, exc), xbmc.LOGWARNING)
        return 0
    return build(LANE_SRC % name, list(rows or []))


def build_widget(category):
    """Same for a recommendation widget."""
    try:
        from . import recommend
        from .config import get_int
        rows = recommend.get_widget_items(
            category, max(3600, get_int('refresh_hours', 12) * 3600))
    except Exception as exc:
        log('виджет %s не прочитан: %s' % (category, exc), xbmc.LOGWARNING)
        return 0
    return build(WIDGET_SRC % category, list(rows or []))


def build_ours():
    """Every lane and widget this skin serves itself."""
    total = 0
    try:
        from . import lanes
        names = list(lanes.LANES)
    except Exception:
        names = []
    for name in names:
        if _stopping() or _busy():
            break
        total += build_lane(name)
    for category in ('movies', 'shows'):
        if _stopping() or _busy():
            break
        total += build_widget(category)
    # Своя лента подписок YouTube собирается не из чужого маршрута, а из
    # плейлистов каналов (hub/youtube_subs.py), поэтому её снимок готовых строк
    # надо обогатить здесь же - иначе полоса осталась бы без подложек и цвета,
    # которые есть у всех остальных.
    if not (_stopping() or _busy()):
        try:
            from . import youtube_subs
            # Снимок ленты пишут трое (см. youtube_subs._FEED_LOCK), и с
            # сбор идёт своим потоком - значит, встретиться они
            # могут. Замок берём без ожидания: обогащение не срочное, а
            # писать поверх чужой работы нельзя.
            lock = youtube_subs.feed_lock()
            if not lock.acquire(blocking=False):
                log('подписки YouTube: снимок занят, обогащение отложено',
                    xbmc.LOGDEBUG)
            else:
                try:
                    stored = youtube_subs.stored_rows()
                    if stored:
                        total += build(youtube_subs.SRC, rows=stored)
                finally:
                    lock.release()
        except Exception as exc:
            log('подписки YouTube: строки не собраны: %s' % exc,
                xbmc.LOGWARNING)
    return total


def build_all(sources):
    """Пересобрать все подключённые виджеты, самый старый снимок первым.

    Порядок здесь - не косметика, а лечение голодания. Раньше в docstring было
    заявлено «newest snapshot first», но сортировки не было вовсе:
    mirror_wire.sources() отдаёт источники в том порядке, в каком они стоят в
    раскладке, и проход всегда шёл по одному и тому же списку, обрываясь на
    первом же _busy(). На коробке, которой пользуются, виджеты в конце списка
    не доходили никогда.

    Замер 03.09.2026 на <коробка> (её смотрят, поэтому проходы обрываются
    часто): из 15 снимков два вообще без метки времени - ютубовские «Подписки»
    и «Рекомендации», - шесть возрастом 12.8 часа, четыре по 1.6 часа, и лишь
    три свежие. На <коробка>, которая простаивает, все 17 снимков
    укладывались в 15 минут. То есть виноват не таймер, а порядок.

    Теперь первым идёт тот, чей снимок старее всех: у обделённого виджета
    появляется приоритет ровно тогда, когда проход снова прерывается.
    """
    ordered = sorted(sources or [], key=mirror.stamp_of)
    total = 0
    for src in ordered:
        if _stopping():
            break
        if _busy():
            # Пауза «а вдруг отпустит» тоже была через xbmc.sleep - целая
            # секунда, которую остановка не могла прервать.
            if _pause(BUSY_PAUSE) or _busy():
                break
        total += build(src)
    return total


# Один сборщик за раз: заполнение кэшей (fill_caches) и проход службы хаба зовут эти
# функции из разных потоков одного процесса; без замка снимки писались дважды, и
# поздняя запись затирала дописанные сведения.
import threading as _threading
_BUILD_LOCK = _threading.RLock()


def _serialized(fn):
    # Без ожидания: служба зовёт это из потоков с перезапуском «зависших» (120/300 с),
    # ждущие потоки копились бы. Кто готов ждать (fill_caches), берёт _BUILD_LOCK сам.
    def wrapper(*args, **kwargs):
        if not _BUILD_LOCK.acquire(blocking=False):
            log('сборщик занят - %s пропущен' % fn.__name__, xbmc.LOGDEBUG)
            return 0
        try:
            return fn(*args, **kwargs)
        finally:
            _BUILD_LOCK.release()
    wrapper.__name__ = fn.__name__
    wrapper.__doc__ = fn.__doc__
    return wrapper


def build_category_lanes(category):
    """Собрать полосы одной категории сразу после долива новинок (hub/service.py). Раньше
    новые карточки ждали прохода зеркала - до 15 минут, и всё это время фон и оценки
    приходили через службу за 2,5 с и дольше («Рыцарь смерти», .20, 20.11.2026).
    Собранные строки build пропускает без сети, поэтому проход дешёвый."""
    try:
        from . import lanes
        names = [n for n in lanes.LANES if lanes.LANES[n][0] == category]
    except Exception:
        names = []
    total = 0
    for name in names:
        if _stopping() or _busy():
            break
        total += build_lane(name)
    return total


build_all = _serialized(build_all)
build_ours = _serialized(build_ours)
top_up_meta = _serialized(top_up_meta)
build_category_lanes = _serialized(build_category_lanes)
