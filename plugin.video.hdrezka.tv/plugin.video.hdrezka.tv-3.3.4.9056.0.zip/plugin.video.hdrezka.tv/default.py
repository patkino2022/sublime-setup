#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# Writer (c) 2012-2025, MrStealth, dandy

import os
import re
import sys
import socket
import urllib.parse
import json
import time
import hashlib
import threading

ADDON_PATH = os.path.dirname(__file__)
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")

if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)
if ADDON_PATH not in sys.path:
    sys.path.insert(0, ADDON_PATH)

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import XbmcHelpers
import SearchHistory as history
from Translit import Translit
from cache import HDRezkaCache

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

import actions
import helpers
import router
from mirrors import server_watch
from voidboost import parse_streams



# --- sublime: данные для скина ----------------------------------------------
def _set_unique_ids(item, ids):
    ids = {k: str(v) for k, v in ids.items() if v}
    if not ids:
        return
    try:
        item.getVideoInfoTag().setUniqueIDs(ids)
    except Exception:
        try:
            item.setUniqueIDs(ids)
        except Exception:
            pass


def _skin_properties(item, kind, year, country, post_id):
    """Свойства, по которым скин опознаёт запись (как у Filmix: SourceYear, SourceCountry)."""
    item.setProperty('tmdb_type', kind)
    item.setProperty('dbtype', 'tvshow' if kind == 'tv' else 'movie')
    item.setProperty('DBTYPE', 'tvshow' if kind == 'tv' else 'movie')
    if year:
        item.setProperty('SourceYear', str(year))
    if country:
        item.setProperty('SourceCountry', str(country).split(',')[0].strip())
        item.setProperty('SourceCountries', str(country))
    if post_id:
        item.setProperty('RezkaPostID', str(post_id))


_WATCH = {}


def reset_call_state():
    """Сбросить то, что рассчитано на один вызов. Kodi держит интерпретатор между вызовами
    (reuselanguageinvoker): отметки просмотра из базы Kodi иначе остались бы от прошлого
    вызова. Файлы скина кэшируются в helpers.cached_file по времени изменения (21.11.2026)."""
    _WATCH.clear()


def _watch_states():
    """{post_id: (позиция, длительность, playcount)} из базы Kodi - один запрос на процесс.

    Kodi сам не подставляет позицию и отметку «просмотрено» в строки дополнения: у «Сердца
    зверя» в базе стояло 40:13 из 105 минут, а значка недосмотренного не было (.20,
    17.11.2026). Filmix делает это сам (kodi_state.py), теперь и HDRezka. Ключ - номер
    фильма на сайте: один фильм приходит под адресами с «-latest» и без.
    """
    if 'map' in _WATCH:
        return _WATCH['map']
    out = {}
    try:
        con = helpers.open_videos_db()
        if con:
            rows = con.execute(
                "SELECT f.strFilename, f.playCount, f.lastPlayed, b.timeInSeconds, b.totalTimeInSeconds "
                "FROM files f LEFT JOIN bookmark b ON b.idFile = f.idFile AND b.type = 1 "
                "WHERE f.strFilename LIKE 'plugin://plugin.video.hdrezka.tv/%' "
                "ORDER BY f.lastPlayed").fetchall()
            con.close()
            for name, count, _last, pos, total in rows:
                m = re.search(r'/(\d+)-', urllib.parse.unquote(name or ''))
                if m:
                    out[m.group(1)] = (float(pos or 0), float(total or 0), int(count or 0))
    except Exception as ex:
        helpers.log(f'watch state fault: {ex}')
    _WATCH['map'] = out
    return out


def _title_states():
    """({ключ фильма: [playcount, позиция, длительность]}, key_for) по всем источникам - единая
    база просмотров скина (row_store.title_states, общее с Filmix)."""
    if 'title' in _WATCH:
        return _WATCH['title']
    store = _skin_row_store()
    try:
        value = store.title_states() if store is not None and hasattr(store, 'title_states') else ({}, None)
    except Exception:
        value = ({}, None)
    _WATCH['title'] = value
    return value


def _started_here(post_id):
    """Есть ли в базе Kodi начатая или просмотренная серия этого сериала HDRezka."""
    if 'started' not in _WATCH:
        found = set()
        try:
            con = helpers.open_videos_db()
            if con:
                for (name,) in con.execute(
                        "SELECT f.strFilename FROM files f LEFT JOIN bookmark b ON b.idFile = f.idFile "
                        "WHERE f.strFilename LIKE 'plugin://plugin.video.hdrezka.tv/%mode=play_episode%' "
                        "AND (f.playCount > 0 OR b.timeInSeconds > 0)"):
                    hit = re.search(r'post_id=(\d+)', name or '')
                    if hit:
                        found.add(hit.group(1))
                con.close()
        except Exception:
            pass
        _WATCH['started'] = found
    return post_id in _WATCH['started']


def _apply_watch_state(item, item_uri):
    m = re.search(r'/(\d+)-', urllib.parse.unquote(item_uri or ''))
    own = _watch_states().get(m.group(1)) if m else None
    shared = None
    try:
        tag = item.getVideoInfoTag()
        if tag.getMediaType() == 'movie' and tag.getYear():
            states, key_for = _title_states()
            if key_for:
                found = states.get(key_for(title=tag.getTitle(), year=str(tag.getYear()))[0])
                if found:
                    shared = (float(found[1]), float(found[2]), int(found[0]))
    except Exception:
        shared = None
    try:
        tag = item.getVideoInfoTag()
        if tag.getMediaType() == 'tvshow':
            # сериал, начатый в любом источнике или здесь, - значок «начат»
            _states, key_for = _title_states()
            started = bool(m and _started_here(m.group(1)))
            entry = None
            if key_for and tag.getYear():
                entry = _episode_shared()['shows'].get(
                    key_for(tvshowtitle=tag.getTitle(), year=str(tag.getYear()))[0])
            if started or entry:
                _publish_show_counts(item, tag, entry)
            return
    except Exception:
        pass
    # общая база уже сведена по всем источникам (и по этой же записи HDRezka) - по самому
    # свежему действию; своя запись - только если фильма в общей базе нет
    state = shared or own
    if not state:
        return
    pos, total, count = state
    try:
        tag = item.getVideoInfoTag()
        if pos > 0 and total > 0:
            tag.setResumePoint(pos, total)
        if count:
            tag.setPlaycount(count)
    except Exception:
        try:
            if pos > 0 and total > 0:
                item.setProperty('ResumeTime', str(pos))
                item.setProperty('TotalTime', str(total))
            if count:
                item.setInfo('video', {'playcount': count})
        except Exception:
            pass


def _not_content(text):
    """Страница входа или бана вместо содержимого. Прогрев до входа положил в кэш на 30 минут
    страницу «Вход на HDrezka» (код 200) по адресу /films/, и фильмы были пустыми, пока
    кэш не устарел (.20, 17.11.2026)"""
    head = text[:4000]
    return '<title>Вход' in head or 'Ошибка доступа' in head or 'Just a moment' in head


PAGE_TTL = 30 * 60      # страница сайта в кэше: 30 минут (прогрев освежает раньше)


class _CachedResponse(object):
    """Ответ из кэша страниц - то, чем пользуются обработчики: text, status_code, cookies."""
    status_code = 200
    cookies = {}

    def __init__(self, text):
        self.text = text

    def json(self):
        return json.loads(self.text)


def _page_cache_dir(profile):
    path = os.path.join(profile, 'pagecache')
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except OSError:
            pass
    return path


def _page_cache_get(profile, key):
    path = os.path.join(_page_cache_dir(profile), key + '.html')
    try:
        if time.time() - os.path.getmtime(path) < PAGE_TTL:
            with open(path, encoding='utf-8') as fh:
                return _CachedResponse(fh.read())
    except OSError:
        pass
    return None


def _page_cache_get_stale(profile, key, max_age=86400):
    """Страница старше PAGE_TTL, но моложе суток - для показа сразу, пока свежая качается."""
    path = os.path.join(_page_cache_dir(profile), key + '.html')
    try:
        if time.time() - os.path.getmtime(path) < max_age:
            with open(path, encoding='utf-8') as fh:
                return _CachedResponse(fh.read())
    except OSError:
        pass
    return None


def _page_cache_put(profile, key, text):
    folder = _page_cache_dir(profile)
    try:
        tmp = os.path.join(folder, key + '.tmp')
        with open(tmp, 'w', encoding='utf-8') as fh:
            fh.write(text)
        os.replace(tmp, os.path.join(folder, key + '.html'))
        # старше суток - убрать, чтобы кэш не рос
        if int(time.time()) % 50 == 0:
            for name in os.listdir(folder):
                full = os.path.join(folder, name)
                if time.time() - os.path.getmtime(full) > 86400:
                    os.remove(full)
    except OSError:
        pass

def _dub_properties(plugin, titles, ids, post_id, idt, uri):
    """Свойства для кнопки озвучки скина: сколько озвучек, текущая, команда выбора."""
    if not titles or not ids:
        return {}
    current = idt
    try:
        cached = plugin._get_cached_translator(post_id, ids)
        if cached is not None:
            current = cached
    except Exception:
        pass
    try:
        name = titles[ids.index(current)]
    except Exception:
        name = titles[0]
    try:
        stored = HDRezkaCache(plugin.profile).get_post_translation_name(post_id)
        if stored:
            name = stored
    except Exception:
        pass
    action = 'RunPlugin(%s)' % router.build_uri('select_translator', uri=uri, via='menu')
    return {'SourceTranslations': str(len(ids)), 'SourceTranslation': common.stripTags(name).strip(),
            'SourceTranslationAction': action, 'SourcePostID': str(post_id)}


class _EpisodeState(tuple):
    """(playcount, позиция, длительность); истина - если серия просмотрена (как было раньше)."""
    def __new__(cls, count, pos, total):
        return tuple.__new__(cls, (count, pos, total))

    def __bool__(self):
        return self[0] > 0


def _episode_shared():
    """Серии и сериалы по всем источникам (row_store.episode_states, общее с Filmix)."""
    if 'episodes' in _WATCH:
        return _WATCH['episodes']
    store = _skin_row_store()
    try:
        data = store.episode_states() if store is not None and hasattr(store, 'episode_states')             else {'episodes': {}, 'shows': {}}
    except Exception:
        data = {'episodes': {}, 'shows': {}}
    _WATCH['episodes'] = data
    return data


def _show_year(post_id):
    """Год сериала из его карточки (cards/<post_id>.json) - для ключа серии в единой базе."""
    try:
        with open(os.path.join(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.hdrezka.tv/cards/'),
                               '%s.json' % post_id), encoding='utf-8') as fh:
            return str(json.load(fh).get('year') or '')
    except Exception:
        return ''


def _publish_show_counts(item, tag, entry):
    """Счёт серий сериала по общему файлу скина - одно правило с Filmix (row_store.show_count_props)."""
    store = _skin_row_store()
    if store is None or not hasattr(store, 'show_count_props'):
        item.setProperty('SeriesStarted', 'true')
        return
    props, done = store.show_count_props(entry)
    for name, value in props.items():
        item.setProperty(name, value)
    if done:
        try:
            tag.setPlaycount(1)
        except Exception:
            pass


def _refused_page(response):
    """Отказ зеркала: 403, «Ошибка доступа», «подозрительная активность», страница проверки."""
    try:
        if response.status_code == 403:
            return True
        if response.status_code == 200 and len(response.text) < 40000:
            low = response.text[:40000].lower()
            return 'ошибка доступа' in low or 'подозрительн' in low
    except Exception:
        pass
    return False


def _show_name(title):
    """Название сериала для общей базы просмотров: русское, без «/ English»."""
    return re.split(r'\s+/\s+', str(title or '').strip())[0].strip()


def _show_card(post_id):
    """(название, год) сериала из его карточки (cards/<post_id>.json)."""
    try:
        with open(os.path.join(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.hdrezka.tv/cards/'),
                               '%s.json' % post_id), encoding='utf-8') as fh:
            card = json.load(fh)
        return _show_name(card.get('title') or ''), str(card.get('year') or '')
    except Exception:
        return '', ''


def _apply_episode_state(item, own, show_title, show_year, season, episode):
    """Серия: самое свежее действие из любого источника (файл скина), своя запись - запасная."""
    state = None
    try:
        _states, key_for = _title_states()
        if key_for and show_year and str(episode).isdigit():
            found = _episode_shared()['episodes'].get(key_for(
                tvshowtitle=_show_name(show_title), year=str(show_year), season=int(season or 0),
                episode=int(episode))[0])
            if found:
                state = (int(found[0] or 0), float(found[1] or 0), float(found[2] or 0))
    except Exception:
        state = None
    if state is None and isinstance(own, tuple):
        state = tuple(own)
    if not state:
        return
    count, pos, total = state
    try:
        tag = item.getVideoInfoTag()
        if pos > 0 and total > 0:
            tag.setResumePoint(pos, total)
            tag.setPlaycount(0)
        elif count:
            tag.setPlaycount(count)
    except Exception:
        pass


def _kodi_watched(post_id):
    """{(сезон, серия): True} - просмотренные серии сериала по базе Kodi (только чтение)."""
    out = {}
    try:
        con = helpers.open_videos_db()
        if not con:
            return out
        rows = con.execute(
            "SELECT f.strFilename, f.playCount, b.timeInSeconds, b.totalTimeInSeconds FROM files f "
            "LEFT JOIN bookmark b ON b.idFile = f.idFile AND b.type = 1 WHERE f.strFilename LIKE ?",
            ('plugin://plugin.video.hdrezka.tv/%post_id=' + str(post_id) + '%',)).fetchall()
        con.close()
        for name, count, pos, total in rows:
            q = dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(name).query))
            if q.get('season_id') and q.get('episode_id') and (count or pos):
                # (playcount, позиция, длительность); истина - если серия просмотрена
                out[(q['season_id'], q['episode_id'])] = _EpisodeState(int(count or 0), float(pos or 0), float(total or 0))
    except Exception as ex:
        helpers.log('watched lookup fault: %s' % ex)
    return out

TMDB_TTL = 7 * 86400


def _tmdb_auth():
    """Ключ TMDb: свой (настройка tmdb_api_key) или ключ скина sublime - ничего не копируем."""
    key = ''
    try:
        key = xbmcaddon.Addon('plugin.video.hdrezka.tv').getSetting('tmdb_api_key').strip()
    except Exception:
        pass
    token = ''
    if not key:
        key = (xbmc.getInfoLabel('Skin.String(SublimeHelper.Api.TMDbKey)') or '').strip()
        token = (xbmc.getInfoLabel('Skin.String(SublimeHelper.Api.TMDbToken)') or '').strip()
    if not key and not token:
        key = 'a3645e125eb4f041712a79bad226c3fe'     # ключ проекта sublime (тот же, что в скине)
    return key, token


def _tmdb_get(path, params=None):
    key, token = _tmdb_auth()
    if not key and not token:
        return None
    params = dict(params or {})
    headers = {'Accept': 'application/json'}
    if token:
        headers['Authorization'] = 'Bearer %s' % token
    else:
        params['api_key'] = key
    try:
        r = requests.get('https://api.themoviedb.org/3' + path, params=params, headers=headers, timeout=10)
        return r.json() if r.status_code == 200 else None
    except Exception as ex:
        helpers.log('tmdb fault %s: %s' % (path, ex))
        return None


def _tmdb_season(profile, imdb_id, season):
    """{номер серии: {name, overview, still, air_date}} сезона по IMDb сериала; кэш на неделю."""
    folder = _page_cache_dir(profile)
    cache = os.path.join(folder, 'tmdb2_%s_s%s.json' % (imdb_id, season))
    try:
        if time.time() - os.path.getmtime(cache) < TMDB_TTL:
            with open(cache, encoding='utf-8') as fh:
                return json.load(fh)
    except (OSError, ValueError):
        pass
    found = _tmdb_get('/find/%s' % imdb_id, {'external_source': 'imdb_id', 'language': 'ru-RU'}) or {}
    shows = found.get('tv_results') or []
    if not shows:
        return {}
    data = _tmdb_get('/tv/%s/season/%s' % (shows[0]['id'], season), {'language': 'ru-RU'}) or {}
    out = {}
    for ep in data.get('episodes') or []:
        num = str(ep.get('episode_number') or '')
        if not num:
            continue
        out[num] = {'name': ep.get('name') or '', 'overview': ep.get('overview') or '',
                    'air_date': ep.get('air_date') or '',
                    'still': ('https://image.tmdb.org/t/p/w780%s' % ep['still_path']) if ep.get('still_path') else ''}
    # у новых сериалов русских описаний серий в TMDb ещё нет - тогда английское, а не пусто
    # («Хорошая дочь» 2026 без описаний, .20, 21.11.2026)
    if any(not ep['overview'] for ep in out.values()):
        english = _tmdb_get('/tv/%s/season/%s' % (shows[0]['id'], season), {'language': 'en-US'}) or {}
        for ep in english.get('episodes') or []:
            num = str(ep.get('episode_number') or '')
            if num in out and not out[num]['overview'] and ep.get('overview'):
                out[num]['overview'] = ep['overview']
    if out:
        try:
            with open(cache, 'w', encoding='utf-8') as fh:
                json.dump(out, fh, ensure_ascii=False)
        except OSError:
            pass
    return out

CARD_TTL = 30 * 86400       # карточка фильма (описание, номера) меняется редко
CARD_EMPTY_TTL = 86400      # пустую (страница не открылась) - переспросить завтра
CARD_WAIT = 8               # сколько список ждёт недостающие карточки
CARD_BATCH = 24             # новых карточек за один показ списка; остальные - в следующий раз
CARD_WORKERS = 4


# вход - одна проверка с службой (helpers.logged_in, 21.11.2026)
_logged_in = helpers.logged_in


def _card_path(profile, post_id):
    folder = os.path.join(profile, 'cards')
    if not os.path.isdir(folder):
        try:
            os.makedirs(folder)
        except OSError:
            pass
    return os.path.join(folder, '%s.json' % re.sub(r'\D', '', str(post_id)))


def _card_get(profile, post_id):
    if not post_id:
        return {}
    path = _card_path(profile, post_id)
    try:
        with open(path, encoding='utf-8') as fh:
            card = json.load(fh)
        ttl = CARD_TTL if (card.get('plot') or card.get('ids')) else CARD_EMPTY_TTL
        # карточка до 22.11.2026 без качества (stream_quality) отдаётся как есть - описание и номера
        # IMDb/КП в ней верные; качество дозапрашивает _cards тем же пакетом (CARD_BATCH за показ).
        # Раньше такая карточка считалась отсутствующей, и после обновления у строк пропадали описание
        # и номера, пока сайт не отдаст все страницы заново (аудит 23.11.2026)
        if time.time() - os.path.getmtime(path) < ttl:
            return card
    except (OSError, ValueError):
        pass
    return None


def _card_put(profile, post_id, card):
    if not post_id:
        return
    path = _card_path(profile, post_id)
    try:
        tmp = '%s.%d.tmp' % (path, threading.get_ident())
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(card, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass


def _best_stream(html):
    m = re.search(r'"streams":"([^"]+)', html or '')
    if not m:
        return ''
    try:
        links = parse_streams(m.group(1))
    except ValueError:
        return ''
    return links[0][0] if links else ''


def _card_parse(html):
    """Описание, оригинальное название и номера IMDb/Кинопоиска со страницы фильма."""
    card = {}
    try:
        text = common.parseDOM(html, 'div', attrs={'class': 'b-post__description_text'})
        if text:
            card['plot'] = re.sub(r'\s+', ' ', __import__('html').unescape(common.stripTags(text[0]))).strip()
    except Exception:
        pass
    try:
        orig = common.parseDOM(html, 'div', attrs={'class': 'b-post__origtitle'})
        if orig:
            card['originaltitle'] = __import__('html').unescape(common.stripTags(orig[0])).strip()
    except Exception:
        pass
    ids = _page_unique_ids(html)
    if ids:
        card['ids'] = ids
    # Лучшее качество из потоков страницы («1080p», «4K») - плашка строки (skin row_store.release_props).
    # В списках сайта качества нет, а строка «В качестве» таблицы фильма - не про фильм: «720p» и у
    # «Аватара», у которого плеер отдаёт 1080p (22.11.2026). Ключ ставится всегда (и пустым): по его
    # отсутствию _card_get узнаёт карточку старого вида.
    card['stream_quality'] = _best_stream(html)
    # название, год, жанры, страны и сериал ли - по ним скин узнаёт просмотренное
    # HDrezka в истории и строит из неё вкус для рекомендаций (как по кэшу Filmix)
    try:
        h1 = common.parseDOM(html, 'h1')
        if h1:
            card['title'] = __import__('html').unescape(common.stripTags(h1[0])).strip()
    except Exception:
        pass
    m = re.search(r'/year/(\d{4})/', html or '')
    if m:
        card['year'] = m.group(1)
    card['genres'] = list(dict.fromkeys(re.findall(r'<span itemprop="genre">([^<]+)</span>', html or '')))
    card['countries'] = list(dict.fromkeys(re.findall(r'href="[^"]*/country/[^"]*"[^>]*>([^<]+)</a>', html or '')))
    card['serial'] = 'b-simple_episodes__list' in (html or '') or 'b-simple_seasons__list' in (html or '')
    # оценки IMDb и Кинопоиска с голосами: по ним скин ставит рейтинг в инфостроку,
    # а рекомендации отсекают по порогу и сортируют по признанию
    for name in ('imdb', 'kp'):
        m = re.search(r'b-post__info_rates %s".*?<span class="bold">([\d.,]+)</span>\s*<i>\(([\d\s ]+)\)</i>' % name,
                      html or '', re.S)
        if m:
            try:
                card[name] = [float(m.group(1).replace(',', '.')), int(re.sub(r'\D', '', m.group(2)) or 0)]
            except ValueError:
                pass
    return card


def _card_rating(card):
    """(оценка, голоса) карточки: IMDb, а если голосов там меньше - Кинопоиск."""
    best = (0.0, 0)
    for name in ('imdb', 'kp'):
        value = card.get(name) or []
        if len(value) == 2 and value[1] > best[1]:
            best = (float(value[0]), int(value[1]))
    return best

def _page_unique_ids(html):
    """IMDb и Кинопоиск со страницы фильма: ссылки там закодированы в /help/<base64>."""
    import base64
    ids = {}
    for enc in re.findall(r'/help/([A-Za-z0-9%+/=_-]{16,})', html or ''):
        try:
            raw = urllib.parse.unquote(urllib.parse.unquote(enc))
            raw += '=' * (-len(raw) % 4)
            url = urllib.parse.unquote(base64.b64decode(raw).decode('utf-8', 'ignore'))
        except Exception:
            continue
        m = re.search(r'imdb\.com/title/(tt\d+)', url)
        if m:
            ids.setdefault('imdb', m.group(1))
        m = re.search(r'kinopoisk\.ru/(?:film|series)/(\d+)', url)
        if m:
            ids.setdefault('kinopoisk', m.group(1))
    return ids

def anubis_pow(random_data, difficulty):

    nonce = 0

    zero_bytes = difficulty // 2
    half = difficulty % 2

    while True:

        digest = hashlib.sha256(
            (random_data + str(nonce)).encode()
        ).digest()

        ok = True

        for i in range(zero_bytes):
            if digest[i] != 0:
                ok = False
                break

        if ok and half:
            if digest[zero_bytes] >> 4 != 0:
                ok = False

        if ok:
            return digest.hex(), nonce

        nonce += 1


retry = Retry(
    total=3,
    backoff_factor=1,
    status_forcelist=[500,502,503,504]
)


common = XbmcHelpers
transliterate = Translit()

socket.setdefaulttimeout(120)

USER_AGENT = helpers.USER_AGENT

CDN_SERIES_URL = "/ajax/get_cdn_series/"
RUN_PLUGIN_FMT = "RunPlugin(%s)"
CONTAINER_REFRESH = "Container.Refresh()"
BUBBLE_CACHE_TTL = 3 * 24 * 3600

ANUBIS_CHALLENGE_RE = re.compile(
    r'<([a-z][a-z0-9]*)[^>]*\bid\s*=\s*["\']anubis_challenge["\'][^>]*>(.{0,10000}?)</\1\s*>',
    re.S | re.I
)


# Не чаще одного запроса к сайту за REQUEST_GAP секунд - на всю коробку: каждый список
# Kodi открывает отдельным процессом дополнения, поэтому отметка последнего запроса
# лежит в файле под замком. Обход каталога запрос в секунду сайт счёл ботом и закрыл
# домашний адрес на всех зеркалах (403 «подозрительная активность», .20, 17.11.2026)
REQUEST_GAP = 1.5
# Фоновые запросы (прогрев службы warm=1, обновление страницы в фоне) уступают пользователю:
# пока его последний запрос моложе INTERACTIVE_HOLD, фон ждёт. Общая частота не растёт.
INTERACTIVE_HOLD = 4.0


def _pace(profile, background=False, unpaced=False):
    try:
        import fcntl
    except ImportError:
        return
    try:
        os.makedirs(profile, exist_ok=True)
        mark = os.path.join(profile, 'interactive_at')
        if background:
            # не дольше трёх выдержек подряд: фон всё равно должен пройти
            for _ in range(3):
                try:
                    left = os.path.getmtime(mark) + INTERACTIVE_HOLD - time.time()
                except OSError:
                    break
                if left <= 0:
                    break
                time.sleep(min(left, INTERACTIVE_HOLD))
        else:
            try:
                with open(mark, 'a'):
                    pass
                os.utime(mark, None)
            except OSError:
                pass
            if unpaced:
                return
        with open(os.path.join(profile, 'last_request'), 'a+') as fh:
            fcntl.flock(fh, fcntl.LOCK_EX)
            fh.seek(0)
            try:
                last = float(fh.read().strip() or 0)
            except ValueError:
                last = 0.0
            wait = last + REQUEST_GAP - time.time()
            if 0 < wait <= REQUEST_GAP:
                time.sleep(wait)
            fh.seek(0)
            fh.truncate()
            fh.write('%.3f' % time.time())
            fh.flush()
    except OSError:
        pass


_SKIN_ROWS = {}


def _skin_row_store():
    """Общее хранилище собранных строк скина (skin.sublime/resources/lib/hub/row_store.py),
    подключается файлом, как identity.py. Перечитывается, когда файл изменился: после обновления
    скина дополнение иначе работало со старым кодом до перезапуска Kodi (аудит 22.11.2026)."""
    try:
        path = xbmcvfs.translatePath('special://home/addons/skin.sublime/resources/lib/hub/row_store.py')
        stamp = os.path.getmtime(path) if os.path.exists(path) else 0
    except Exception:
        path, stamp = '', 0
    if 'mod' in _SKIN_ROWS and _SKIN_ROWS.get('stamp') == stamp:
        return _SKIN_ROWS['mod']
    mod = None
    try:
        import importlib.util
        if stamp:
            spec = importlib.util.spec_from_file_location('sublime_row_store', path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
    except Exception as exc:
        xbmc.log('[plugin.video.hdrezka.tv] row_store: %s' % exc, xbmc.LOGWARNING)
        mod = None
    _SKIN_ROWS['mod'] = mod
    _SKIN_ROWS['stamp'] = stamp
    return mod


def _attach_skin_rows(pending):
    """Готовые свойства строк (фон, цвет, логотип, оценки, жанр, дата, чистое название, плашка
    качества) из хранилища скина одним вызовом на страницу (row_store.attach - общий с Filmix),
    затем строки в список. pending = [(адрес, ListItem, папка ли, row)]."""
    store = _skin_row_store()
    if store is not None and hasattr(store, 'attach'):
        try:
            store.attach([(item, row) for _uri, item, _folder, row in pending])
        except Exception as exc:
            xbmc.log('[plugin.video.hdrezka.tv] свойства строк скина: %s' % exc, xbmc.LOGWARNING)


_SELFTEST_KEYS = ('SeriesStarted', 'WatchedProgress', 'WatchedEpisodes', 'UnWatchedEpisodes',
                  'TotalEpisodes', 'WatchedEpisodePercent', 'sublime_release_quality',
                  'sublime_release_resolution', 'Sublime.Title')


def _selftest():
    return 'selftest=1' in (sys.argv[2] if len(sys.argv) > 2 else '')


def _add_rows(handle, pending):
    _attach_skin_rows(pending)
    test = _selftest()
    for uri, item, folder, _row in pending:
        if test:
            # самопроверка (sublime-box/installer/regress.py), как у Filmix: итог строки - в
            # названии, его видно снаружи через Files.GetDirectory; обычные списки не меняются
            seen = dict((k, item.getProperty(k)) for k in _SELFTEST_KEYS if item.getProperty(k))
            try:
                tag = item.getVideoInfoTag()
                seen['mediatype'] = tag.getMediaType()
                seen['playcount'] = tag.getPlayCount()
                seen['plot'] = len(tag.getPlot() or '')
            except Exception:
                pass
            item.setLabel('%s ⟦%s⟧' % (item.getLabel(), json.dumps(seen, ensure_ascii=False)))
        xbmcplugin.addDirectoryItem(handle, uri, item, folder)
    del pending[:]


class HdrezkaTV:

    def solve_anubis(self, html, original_url):
        m = ANUBIS_CHALLENGE_RE.search(html)
        if not m:
            helpers.log("No anubis_challenge found in HTML")
            return False

        try:
            data = json.loads(m.group(2))
            challenge = data["challenge"]
            start = time.time()
            hash_value, nonce = anubis_pow(
                challenge["randomData"],
                challenge["difficulty"]
            )
            elapsed = max(int((time.time() - start) * 1000), 50)
            helpers.log(f"Anubis solved nonce={nonce} in {elapsed}ms")

            pass_url = f"{self.url}/.within.website/x/cmd/anubis/api/pass-challenge"
            pass_params = {
                "id": challenge["id"],
                "response": hash_value,
                "nonce": nonce,
                "elapsedTime": elapsed,
                "redir": "/"
            }

            r = self.session.get(
                pass_url,
                params=pass_params,
                headers={"Referer": original_url, "User-Agent": USER_AGENT},
                proxies=self.proxies,
                allow_redirects=False,
                timeout=30
            )

            helpers.log(f"Anubis pass-challenge response: {r.status_code}")
            helpers.log("Session cookies: %s" % [(c.name, c.domain) for c in self.session.cookies])  # dict() падал на одноимённых куках разных зеркал
            self._save_session()
            return True
        except Exception as e:
            helpers.log(f"Anubis solve fault: {e}")
            return False

    def __init__(self):
        self.id = 'plugin.video.hdrezka.tv'
        self.addon = xbmcaddon.Addon(self.id)
        self.icon = self.addon.getAddonInfo('icon')
        self.icon_next = os.path.join(self.addon.getAddonInfo('path'), 'resources/icons/next.png')
        self.language = self.addon.getLocalizedString
        # service and RunScript invocations may come without a handle argument
        self.handle = int(sys.argv[1]) if len(sys.argv) > 1 else None
        self.profile = xbmcvfs.translatePath(self.addon.getAddonInfo('profile'))
        self.use_transliteration = self.addon.getSettingBool('use_transliteration')
        self.quality = self.addon.getSetting('quality')
        self.stream_type = self.addon.getSetting('stream_type') or 'hls'
        self.translator = self.addon.getSetting('translator')
        # зеркало - из сведений службы (server_watch): выбрано установщиком по проверке с
        # коробки, сменяется службой; настройка domain - только пока сведений нет
        self.watch = server_watch(self.profile, self.addon)
        self.domain = self.watch.current() if self.watch.auto else self.watch.default
        self.show_description = self.addon.getSettingBool('show_description')
        self.warm = False
        self.user_search = False
        self._cached_page = None
        # sublime: чистые названия, тип записи, id и свойства для скина; без запроса
        # quick_content на каждую строку - описание и оценки скин берёт сам (TMDb и др.)
        try:
            self.skin_mode = self.addon.getSettingBool('skin_mode')
        except Exception:
            self.skin_mode = True
        self.use_atl_names = self.addon.getSettingBool('use_atl_names')

        proto = self.addon.getSetting('dom_protocol') or 'https'
        self.url = proto + '://' + self.domain
        self.proxies = self._load_proxy_settings()
        self.session = self._load_session()

    def _save_session(self):
        # Писать настройки только при изменении куки: запись settings.xml не атомарна,
        # и другие процессы (служба, скин), читая его в этот момент, получали
        # «failed to load addon settings» - то есть «нет входа» (.20, 16.11.2026).
        try:
            dumped = helpers.dump_cookies(self.session.cookies)
            if dumped == self.addon.getSetting("cookies"):
                return
            self.addon.setSetting("cookies", dumped)
        except Exception as e:
            helpers.log("save cookies failed: %s" % e)

    def _load_session(self):
        session = requests.Session()

        retry = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[500, 502, 503, 504]
        )

        adapter = HTTPAdapter(max_retries=retry)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        session.headers.update({
            "User-Agent": USER_AGENT,
            "Referer": self.url + "/",
        })

        saved_cookies = self.addon.getSetting('cookies')
        if saved_cookies:
            session.cookies = helpers.load_cookies(
                self.addon.getSetting('cookies')
            )

        return session

    def _load_proxy_settings(self):
        use_proxy = self.addon.getSetting('use_proxy')
        if not use_proxy or str(use_proxy).lower() in ('false', '0'):
            return None
        proxy_protocol = self.addon.getSetting('protocol') or 'http'
        proxy_url = self.addon.getSetting('proxy_url')
        if not proxy_url or proxy_url == 'USERNAME:PASSWORD@IPADDRESS:PORT':
            return None
        return {
            'http': proxy_protocol + '://' + proxy_url,
            'https': proxy_protocol + '://' + proxy_url
        }

    def is_atl_mode(self, params=None):
        if params and params.get('atl', '').lower() == 'true':
            return True
        return self.use_atl_names

    def make_response(self, method, uri, params=None, data=None, cookies=None, headers=None, **kwargs):
        t0 = time.time()
        try:
            response = self._make_response_once(method, uri, params, data, cookies, headers, **kwargs)
        except Exception:
            self.watch.report(self.domain, False)
            raise
        # итог настоящего запроса - основной сигнал о зеркале (своих проб мало: бан не ловим);
        # чужие зеркала здесь не перебираются - переключает служба
        self.watch.report(self.domain, not _refused_page(response) and response.status_code < 500,
                          (time.time() - t0) * 1000)
        return response

    def _make_response_once(self, method, uri, params=None, data=None, cookies=None, headers=None, **kwargs):
        cache_key = None
        if method == 'GET' and data is None and self.skin_mode:
            cache_key = hashlib.sha1(('%s|%s|%s' % (self.domain, uri, sorted((params or {}).items()))).encode('utf-8')).hexdigest()
            if not self.warm:
                cached = _page_cache_get(self.profile, cache_key)
                if cached is None:
                    # Устаревшая страница показывается сразу, свежая качается в фоне: вход в
                    # сериал не ждёт сайт (то же, что у Filmix 2.2.61.51.0). Запросов к сайту
                    # столько же - бан не ближе.
                    cached = _page_cache_get_stale(self.profile, cache_key)
                    if cached is not None:
                        self._refresh_page_in_background(method, uri, params, cookies, headers, cache_key, kwargs)
                if cached is not None:
                    # страница из кэша не обновляет куки сессии; запомнить её, чтобы
                    # при отказе запроса к сайту перечитать вживую (см. ниже)
                    self._cached_page = (uri, params, cookies, headers)
                    return cached
        response = self._make_response(method, uri, params, data, cookies, headers, **kwargs)
        if method == 'POST' and response.status_code == 403 and getattr(self, '_cached_page', None):
            # озвучки и серии сайт отдаёт только с куки, которые ставит живая страница
            page_uri, page_params, page_cookies, page_headers = self._cached_page
            self._cached_page = None
            helpers.log('403 на %s: перечитываю страницу %s вживую' % (uri, page_uri))
            live = self._make_response('GET', page_uri, page_params, None, page_cookies, page_headers)
            if live.status_code == 200 and self.skin_mode:
                _page_cache_put(self.profile, hashlib.sha1(('%s|%s|%s' % (
                    self.domain, page_uri, sorted((page_params or {}).items()))).encode('utf-8')).hexdigest(), live.text)
            response = self._make_response(method, uri, params, data, cookies, headers, **kwargs)
        if cache_key and response.status_code == 200 and 'anubis_challenge' not in response.text \
                and len(response.text) > 2000 and not _not_content(response.text):
            _page_cache_put(self.profile, cache_key, response.text)
        return response

    def _refresh_page_in_background(self, method, uri, params, cookies, headers, cache_key, kwargs):
        import threading

        def _run():
            try:
                live = self._make_response(method, uri, params, None, cookies, headers, **kwargs)
                if live.status_code == 200 and 'anubis_challenge' not in live.text                         and len(live.text) > 2000 and not _not_content(live.text):
                    _page_cache_put(self.profile, cache_key, live.text)
            except Exception as ex:
                helpers.log('страница в фоне не обновлена: %s' % ex)

        threading.Thread(target=_run, name='hdrezka-page-refresh').start()

    def _make_response(self, method, uri, params=None, data=None, cookies=None, headers=None, **kwargs):
        _bg = bool(self.warm) or threading.current_thread().name.startswith('hdrezka-page-refresh')
        # сам запрос пользовательского поиска - мимо общей очереди (как поиск Filmix); карточки
        # найденного остаются в очереди: сайт закрывает адрес за частые запросы (17.11.2026)
        _pace(self.profile, background=_bg,
              unpaced=(not _bg and self.user_search and threading.current_thread() is threading.main_thread()))
        if cookies:
            self.session.cookies.update(cookies)

        if uri.startswith('http'):
            # Transparently normalize legacy or alternate mirror domains to current active mirror
            parsed = urllib.parse.urlsplit(uri)
            url = urllib.parse.urlunsplit((
                self.addon.getSetting('dom_protocol') or 'https',
                self.domain,
                parsed.path,
                parsed.query,
                parsed.fragment
            ))
        else:
            url = self.url + uri

        req_headers = {
            "User-Agent": USER_AGENT,
            "Referer": f"{self.url}/"
        }
        if headers:
            req_headers.update(headers)

        try:
            response = self.session.request(
                method,
                url,
                params=params,
                data=data,
                headers=req_headers,
                proxies=self.proxies,
                timeout=30,
                **kwargs
            )
        except requests.exceptions.RequestException as ex:
            helpers.log('make_response retry after ex: %s' % ex)
            time.sleep(1)
            response = self.session.request(
                method,
                url,
                params=params,
                data=data,
                headers=req_headers,
                proxies=self.proxies,
                timeout=30,
                **kwargs
            )

        if "anubis_challenge" in response.text:
            helpers.log("Anubis challenge detected in make_response, solving...")
            if self.solve_anubis(response.text, url):
                helpers.log("Retrying request after Anubis bypass...")
                response = self.session.request(
                    method,
                    url,
                    params=params,
                    data=data,
                    headers=req_headers,
                    proxies=self.proxies,
                    timeout=30,
                    **kwargs
                )

        if cookies or response.cookies:
            self._save_session()

        return response

    def _quiet_login(self):
        """Вход без окна по сохранённым логину и паролю, если сессии нет: после переустановки
        или очистки данных куки пусты, а логин с паролем в настройках - и каталог, полосы хаба и
        прогрев стояли со строкой «Войти» (.20, 17.11.2026). Неудача - как раньше, «Войти».
        После выхода (mode=logout) пароль стирается, поэтому сам он обратно не входит."""
        user = self.addon.getSetting('username')
        password = self.addon.getSetting('password')
        if not (user and password):
            return False
        # сайт отказал недавно (неверный пароль) - не стучаться с каждым запросом: частые входы
        # HDRezka считает «подозрительной активностью» и закрывает адрес
        mark = os.path.join(xbmcvfs.translatePath('special://profile/addon_data/plugin.video.hdrezka.tv/'),
                            'quiet_login_failed')
        try:
            if time.time() - os.path.getmtime(mark) < 600:
                return False
        except OSError:
            pass
        try:
            response = self.make_response('POST', '/ajax/login/', data={
                'login_name': user, 'login_password': password, 'login_not_save': '0'})
            ok = response.status_code == 200 and bool(response.json().get('success'))
        except Exception as ex:
            helpers.log('тихий вход не удался: %s' % ex)
            return False
        if ok:
            self._save_session()
            helpers.log('тихий вход по сохранённым данным: успешно')
        else:
            helpers.log('тихий вход по сохранённым данным: сайт отказал')
            try:
                open(mark, 'w').close()
            except OSError:
                pass
        return ok and _logged_in()

    def main(self, action):
        params = router.parse_uri(action)
        helpers.log(f'*** main params: {params}')
        # прогрев из service.py: страница грузится с сайта заново и кладётся в кэш
        self.warm = params.pop('warm', '') == '1'

        mode = params.get('mode')
        # каталог, поиск и воспроизведение - только с аккаунтом сайта
        if mode not in ('logout', 'authorize', 'signin') and not _logged_in() and not self._quiet_login():
            self.need_signin(mode)
            return
        if mode == 'signin':
            self.signin()
            return
        if mode == 'play':
            play_info = None
            if params.get('post_id'):
                play_info = {
                    'post_id': params.get('post_id'),
                    'translator_id': params.get('translator_id'),
                    'season': params.get('season'),
                    'episode': params.get('episode')
                }
            self.play(params.get('url'), play_info=play_info, title=urllib.parse.unquote_plus(params.get('title') or ''))
        elif mode == 'logout':
            actions.logout(self)
            return
        elif mode == 'authorize':
            actions.authorize(self)
            return
        elif mode == 'play_episode':
            self.play_episode(
                params.get('url'),
                params.get('post_id'),
                params.get('season_id'),
                params.get('episode_id'),
                urllib.parse.unquote_plus(params.get('title') or ''),
                params.get('image'),
                params.get('idt'),
                params.get('strm'),
                params.get('show_id')
            )
        elif mode == 'select_translator':
            self.select_translator_item(
                params.get('uri') or params.get('url'), params.get('via'), params.get('atl'), params.get('strm'))
        elif mode == 'show':
            self.show(params.get('uri') or params.get('url'), self.is_atl_mode(params), params.get('strm'),
                      params.get('season'))
        elif mode == 'index':
            self.index(params.get('uri') or params.get('url'), params.get('page'), params.get('query_filter'))
        elif mode == 'categories':
            self.categories()
        elif mode == 'sub_categories':
            self.sub_categories(params.get('uri') or params.get('url'))
        elif mode == 'search':
            external = 'main' if 'main' in params else None
            if not external:
                external = 'usearch' if 'usearch' in params else None
            self.search(params.get('keyword'), external)
        elif mode == 'history':
            self.history()
        elif mode == 'history_delete':
            self.delete_history(params.get('keyword'))
        elif mode == 'continue':
            self.continues()
        elif mode == 'continue_delete':
            self.delete_continue(params.get('id'))
        elif mode == 'collections':
            self.collections(int(params.get('page', 1)))
        else:
            self.menu()

    def need_signin(self, mode):
        if self.warm:
            xbmcplugin.endOfDirectory(self.handle, False)
            return
        if mode in ('play', 'play_episode'):
            xbmcgui.Dialog().notification('HDRezka', 'Войдите в свой аккаунт HDRezka', self.icon, 5000)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        if mode and self.skin_mode:
            # полосы скина и хаб открывают разделы каталога в фоне: строка входа
            # попадала в них как фильм и оставалась в снимке полосы и после входа
            # (.20, 17.11.2026: «сверху "Войти в аккаунт HDRezka" по совпадению вкуса»).
            # Вход предлагается только в корне дополнения.
            xbmcplugin.endOfDirectory(self.handle, True, cacheToDisc=False)
            return
        item = xbmcgui.ListItem('[COLOR=FF00FF00]Войти в аккаунт HDRezka[/COLOR]')
        item.setArt({'thumb': self.icon, 'icon': self.icon})
        xbmcplugin.addDirectoryItem(self.handle, router.build_uri('signin'), item, False)
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=False)

    def signin(self):
        """Логин и пароль своего аккаунта сайта - в настройки дополнения, затем вход."""
        dlg = xbmcgui.Dialog()
        login = dlg.input('HDRezka: логин (e-mail)', self.addon.getSetting('username') or '')
        if not login:
            return
        password = dlg.input('HDRezka: пароль', option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if not password:
            return
        self.addon.setSetting('username', login)
        self.addon.setSetting('password', password)
        actions.authorize(self)
        xbmc.executebuiltin(CONTAINER_REFRESH)

    def menu(self):
        menu_items = (
            ('search', 'FF00FF00', 30000),
            ('history', 'FF00FF00', 30008),
            ('categories', 'FF00FF00', 30003),
            ('index', 'FFDDD2CC', 30009),
            ('index_popular', 'FFDDD2CC', 30010),
            ('index_soon', 'FFDDD2CC', 30011),
            ('index_watching', 'FFDDD2CC', 30012),
            ('continue', 'FFDDD2CC', 30013),
        )
        for mode, color, translation_id in menu_items:
            uri = router.build_uri(mode)
            if '_' in mode:
                mode, query_filter = mode.split('_')
                uri = router.build_uri(mode, query_filter=query_filter)
            item = xbmcgui.ListItem(f'[COLOR={color}]{self.language(translation_id)}[/COLOR]')
            item.setArt({'thumb': self.icon})
            xbmcplugin.addDirectoryItem(self.handle, uri, item, True)

        xbmcplugin.setContent(self.handle, 'movies')
        xbmcplugin.endOfDirectory(self.handle, True)

    def categories(self):
        response = self.make_response('GET', '/')
        genres = common.parseDOM(response.text, "ul", attrs={"id": "topnav-menu"})

        titles = common.parseDOM(genres, "a", attrs={"class": "b-topnav__item-link"})
        links = common.parseDOM(genres, "a", attrs={"class": "b-topnav__item-link"}, ret='href')
        for i, title in enumerate(titles):
            title = common.stripTags(title)
            item_uri = router.build_uri('sub_categories', uri=links[i])
            item = xbmcgui.ListItem(title)
            item.setArt({'thumb': self.icon})
            xbmcplugin.addDirectoryItem(self.handle, item_uri, item, True)

        item_uri = router.build_uri('collections')
        item = xbmcgui.ListItem('Подборки')
        item.setArt({'thumb': self.icon})
        xbmcplugin.addDirectoryItem(self.handle, item_uri, item, True)

        xbmcplugin.setContent(self.handle, 'files')
        xbmcplugin.endOfDirectory(self.handle, True)

    def sub_categories(self, uri):
        response = self.make_response('GET', '/')
        genres = common.parseDOM(response.text, "ul", attrs={"class": "left"})

        titles = common.parseDOM(genres, "a")
        links = common.parseDOM(genres, "a", ret='href')

        item_uri = router.build_uri('index', uri=uri)
        item = xbmcgui.ListItem(f'[COLOR=FF00FFF0]{self.language(30007)}[/COLOR]')
        item.setArt({'thumb': self.icon})
        xbmcplugin.addDirectoryItem(self.handle, item_uri, item, True)

        for i, title in enumerate(titles):
            if not links[i].startswith(uri):
                continue
            item_uri = router.build_uri('index', uri=links[i])
            item = xbmcgui.ListItem(title)
            item.setArt({'thumb': self.icon})
            xbmcplugin.addDirectoryItem(self.handle, item_uri, item, True)

        xbmcplugin.setContent(self.handle, 'files')
        xbmcplugin.endOfDirectory(self.handle, True)

    def collections(self, page):
        uri = '/collections/'
        if page != 1:
            uri = f'/collections/page/{page}/'

        response = self.make_response('GET', uri)
        content = common.parseDOM(response.text, 'div', attrs={'class': 'b-content__collections_list clearfix'})
        titles = common.parseDOM(content, "a", attrs={"class": "title"})
        counts = common.parseDOM(content, 'div', attrs={"class": ".num"})
        links = common.parseDOM(content, "div", attrs={"class": "b-content__collections_item"}, ret="data-url")
        icons = common.parseDOM(content, "img", attrs={"class": "cover"}, ret="src")

        for i, name in enumerate(titles):
            item_uri = router.build_uri('index', uri=router.normalize_uri(links[i]))
            item = xbmcgui.ListItem(f'{name} [COLOR=55FFFFFF]({counts[i]})[/COLOR]')
            item.setArt({'thumb': icons[i]})
            xbmcplugin.addDirectoryItem(self.handle, item_uri, item, True)

        if not len(titles) < 32:
            item_uri = router.build_uri('collections', page=page + 1)
            item = xbmcgui.ListItem("[COLOR=orange]" + self.language(30004) + "[/COLOR]")
            item.setArt({'icon': self.icon_next})
            xbmcplugin.addDirectoryItem(self.handle, item_uri, item, True)

        xbmcplugin.setContent(self.handle, 'files')
        xbmcplugin.endOfDirectory(self.handle, True)

    def index(self, uri=None, page=None, query_filter=None):
        url = uri
        if not url:
            url = '/'
        if page:
            url += f'page/{page}/'
        if query_filter:
            url += f'?filter={query_filter}'

        response = self.make_response('GET', url)
        content = common.parseDOM(response.text, "div", attrs={"class": "b-content__inline_items"})

        items = common.parseDOM(content, "div", attrs={"class": "b-content__inline_item"})
        post_ids = common.parseDOM(content, "div", attrs={"class": "b-content__inline_item"}, ret="data-id")

        link_containers = common.parseDOM(items, "div", attrs={"class": "b-content__inline_item-link"})

        links = common.parseDOM(link_containers, "a", ret='href')
        titles = common.parseDOM(link_containers, "a")
        div_covers = common.parseDOM(items, "div", attrs={"class": "b-content__inline_item-cover"})

        serial_count = 0
        # карточки - только первым двум страницам: это начало полос хаба и то, что
        # человек видит. Хаб читает каталог на 20 страниц вглубь ради кандидатов, и
        # карточка на каждую строку - это ~700 страниц сайта за проход
        cards = {}
        if self.skin_mode and int(page or 1) <= 2:
            cards = self._cards([router.normalize_uri(l) for l in links], post_ids)
        pending = []
        for i, name in enumerate(titles):
            if self.skin_mode:
                info = {'rating': {'site': '', 'imdb': '', 'kp': ''}, 'age_limit': '', 'description': ''}
            else:
                info = self.get_item_additional_info(post_ids[i])
            country_divs = common.parseDOM(link_containers[i], "div")
            country_text = country_divs[0] if country_divs else ''
            name = common.stripTags(name).strip()
            title = name if self.skin_mode else helpers.built_title(name, country_text, **info)
            image = self._normalize_url(common.parseDOM(div_covers[i], "img", ret='src')[0])
            item_uri = router.build_uri('show', uri=router.normalize_uri(links[i]))
            year, country, genre = helpers.get_media_attributes(country_text)
            is_serial = common.parseDOM(div_covers[i], 'span', attrs={"class": "info"})
            item = xbmcgui.ListItem(title)
            item.setArt({'thumb': image, 'icon': image})
            item.addContextMenuItems(self._translator_menu(router.normalize_uri(links[i])))
            info_labels = {
                'title': title,
                'genre': genre,
                'country': country,
                'plot': info['description'],
                'rating': info['rating']['site']
            }
            if year:
                info_labels['year'] = year
            if info['age_limit']:
                info_labels['mpaa'] = info['age_limit']
            serial = bool(is_serial)
            serial_count += serial
            info_labels['mediatype'] = 'tvshow' if serial else 'movie'
            if serial:
                info_labels['tvshowtitle'] = title
            card = cards.get(str(post_ids[i]) if i < len(post_ids) else '') or {}
            if self.skin_mode:
                info_labels.pop('rating', None)
                info_labels.pop('plot', None)
                # описание и оригинальное название со страницы фильма - как в строках Filmix
                if card.get('plot'):
                    info_labels['plot'] = card['plot']
                if card.get('originaltitle'):
                    info_labels['originaltitle'] = card['originaltitle']
                rating, votes = _card_rating(card)
                if rating:
                    info_labels['rating'] = rating
                    info_labels['votes'] = str(votes)
            item.setInfo(type='video', infoLabels=info_labels)
            if self.skin_mode and card.get('ids'):
                # по IMDb/Кинопоиску скин опознаёт запись точно: логотип, трейлер, оценки
                _set_unique_ids(item, card['ids'])
            _skin_properties(item, 'tv' if serial else 'movie', year, country, post_ids[i])
            is_folder = True
            if (self.quality != 'select') and not is_serial:
                item.setProperty('IsPlayable', 'true')
                is_folder = False
            _apply_watch_state(item, item_uri)
            pending.append((item_uri, item, is_folder, {
                'file': item_uri, 'label': title, 'title': title,
                'originaltitle': card.get('originaltitle') or '',
                'year': year or 0, 'type': info_labels['mediatype'],
                'genre': genre, 'country': country,
                'plot': info_labels.get('plot') or '',
                'uniqueid': card.get('ids') or {}, 'release': card.get('stream_quality') or '', 'art': {'thumb': image, 'poster': image},
                'filetype': 'directory' if is_folder else 'file'}))
        _add_rows(self.handle, pending)

        if not len(titles) < 16:
            params = {'page': 2, 'uri': uri}
            if page:
                params['page'] = int(page) + 1
            if query_filter:
                params['query_filter'] = query_filter
            item_uri = router.build_uri('index', **params)
            item = xbmcgui.ListItem("[COLOR=orange]" + self.language(30004) + "[/COLOR]")
            item.setArt({'icon': self.icon_next})
            xbmcplugin.addDirectoryItem(self.handle, item_uri, item, True)

        # sublime: тип контейнера по большинству строк - скин выбирает по нему вид и поиск
        xbmcplugin.setContent(self.handle, 'tvshows' if titles and serial_count * 2 > len(titles) else 'movies')
        xbmcplugin.endOfDirectory(self.handle, True)

    def select_quality(self, streams, title, image, subtitles=None, strm=None, play_info=None):
        if strm == '1' and self.quality == 'select' and streams:
            name, quality, url = max(streams, key=lambda s: s[1])
            helpers.log(f'strm selected best quality name: {name}')
            self.play(url, subtitles, play_info, title)
            return
        for name, quality, url in streams:
            if self.quality != 'select' or strm == '1':
                if (name == self.quality) or (int(self.quality.split('p')[0]) >= quality):
                    helpers.log(f'selected quality name: {name}')
                    self.play(url, subtitles, play_info, title)
                    break
            else:
                film_title = f"{title} - [COLOR=orange]{name}[/COLOR]"
                play_params = {'url': url, 'title': title}
                if play_info:
                    for k in ('post_id', 'translator_id', 'season', 'episode'):
                        if play_info.get(k) is not None:
                            play_params[k] = play_info[k]
                item_uri = router.build_uri('play', **play_params)
                item = xbmcgui.ListItem(film_title)
                item.setArt({'icon': image})
                item.setInfo(
                    type='Video',
                    infoLabels={'title': film_title, 'overlay': xbmcgui.ICON_OVERLAY_WATCHED, 'playCount': 0}
                )
                item.setProperty('IsPlayable', 'true')
                helpers.set_item_subtitles(item, subtitles)
                xbmcplugin.addDirectoryItem(self.handle, item_uri, item, False)

    def _parse_translators(self, content):
        try:
            div = common.parseDOM(content, 'ul', attrs={'id': 'translators-list'})[0]
        except Exception as ex:
            helpers.log(
                'parse translators fault ex: %s has_list=%s translator_id_count=%d'
                % (ex, 'translators-list' in content, content.count('data-translator_id'))
            )
            init_m = re.search(r'initCDN(?:Movies|Series)Events\s*\(\s*\d+\s*,\s*(\d+)', content)
            if init_m:
                t_id = init_m.group(1)
                return ["По умолчанию"], [t_id], [False], [False], t_id
            return None, None, None, None, None

        titles = common.parseDOM(div, 'li', ret='title')
        if not titles:
            titles = common.parseDOM(div, 'a', ret='title')
        ids = common.parseDOM(div, 'li', ret="data-translator_id")
        if not ids:
            ids = common.parseDOM(div, 'a', ret="data-translator_id")

        if not ids:
            ids = re.findall(r'data-translator_id=[\'"](\d+)[\'"]', div)
            titles = re.findall(r'title=[\'"]([^\'"]+)[\'"]', div)

        # transform flag image into title suffix
        title_items = common.parseDOM(div, 'li')
        for index, title in enumerate(title_items):
            if index >= len(titles):
                break
            images = common.parseDOM(title, 'img', ret='title')
            for img in images:
                titles[index] += f' ({img})'

        directors = common.parseDOM(div, 'li', ret='data-director') or common.parseDOM(div, 'a', ret='data-director')
        if not directors:
            directors = [False] * len(ids)

        premium = ['b-prem_translator' in tag for tag in re.findall(r'<li\b[^>]*>', div)]
        if not premium or len(premium) != len(ids):
            premium = ['b-prem_translator' in tag for tag in re.findall(r'<a\b[^>]*>', div)]
        if not premium or len(premium) != len(ids):
            premium = [False] * len(ids)

        active_id = None
        for m in re.finditer(r'<li\b([^>]*)>(.*?)</li>', div, re.DOTALL | re.IGNORECASE):
            attrs, inner = m.group(1), m.group(2)
            combined = attrs + " " + inner
            if "active" in combined:
                id_m = re.search(r'data-translator_id=[\'"](\d+)[\'"]', combined)
                if id_m:
                    active_id = id_m.group(1)
                    break

        if not active_id:
            init_m = re.search(r'initCDN(?:Movies|Series)Events\s*\(\s*\d+\s*,\s*(\d+)', content)
            if init_m:
                active_id = init_m.group(1)

        return titles, ids, directors, premium, active_id

    def _get_cached_translator(self, post_id, ids):
        try:
            cached = HDRezkaCache(self.profile).get_post_translation(post_id)
        except Exception as ex:
            helpers.log(f'get cached translator fault ex: {ex}')
            return None
        if cached is not None and cached in (ids or []):
            return cached
        return None

    def _translator_menu(self, uri):
        item_uri = router.build_uri('select_translator', uri=uri, via='menu')
        return [(self.language(30006), RUN_PLUGIN_FMT % item_uri)]

    def _add_translator_item(self, titles, ids, premium, post_id, idt, uri):
        if not titles or not ids:
            return
        cached = self._get_cached_translator(post_id, ids)
        current = cached if cached is not None else idt
        try:
            current_index = ids.index(current)
            translator_name = titles[current_index]
        except Exception:
            current_index = 0
            translator_name = titles[0]
        try:
            stored_name = HDRezkaCache(self.profile).get_post_translation_name(post_id)
        except Exception:
            stored_name = None
        if stored_name:
            translator_name = stored_name
        if premium and current_index < len(premium) and premium[current_index]:
            translator_name = '%s [%s]' % (translator_name, self.language(30019))
        try:
            label = self.language(30014) % translator_name
        except Exception:
            label = translator_name
        item_uri = router.build_uri('select_translator', uri=uri, via='line')
        item = xbmcgui.ListItem(f'[COLOR=yellowgreen]{label}[/COLOR]')
        item.setArt({'thumb': self.icon, 'icon': self.icon})
        # explicit false: JSONRPC exposes requested ListItem properties to scans
        item.setProperty('IsPlayable', 'false')
        # Folder row served inline: scans skip folders, clicks never go empty.
        xbmcplugin.addDirectoryItem(self.handle, item_uri, item, True)

    def _cdn_headers(self, url):
        return {
            "Host": self.domain,
            "Origin": self.url,
            "Referer": url,
            "User-Agent": USER_AGENT,
            "X-Requested-With": "XMLHttpRequest"
        }

    def _count_translator_episodes(self, post_id, translator_id, url, director=None):
        data = {
            "id": post_id,
            "translator_id": translator_id,
            "action": "get_episodes"
        }
        if director:
            data['is_director'] = director
        try:
            response = self.make_response('POST', CDN_SERIES_URL, data=data, headers=self._cdn_headers(url)).json()
            playlist = common.parseDOM(response["episodes"], "ul", attrs={"class": "b-simple_episodes__list clearfix"})
            return sum(len(common.parseDOM(block, "li")) for block in playlist)
        except Exception as ex:
            helpers.log(f'count translator episodes fault ex: {ex}')
            return None

    def _annotate_translators(self, titles, ids, directors, premium, post_id, url, current=None, with_counts=True):
        display = list(titles)
        counts = {}
        if with_counts:
            with helpers.busy_dialog():
                for index, translator_id in enumerate(ids):
                    if index >= len(display):
                        break
                    director = None
                    if directors:
                        try:
                            director = directors[index]
                        except Exception:
                            director = None
                    counts[index] = self._count_translator_episodes(post_id, translator_id, url, director)
        for index, translator_id in enumerate(ids):
            if index >= len(display):
                break
            if premium and index < len(premium) and premium[index]:
                display[index] = '%s [%s]' % (display[index], self.language(30019))
            if counts.get(index) is not None:
                display[index] = '%s [%d]' % (display[index], counts[index])
            if current is not None and translator_id == current:
                display[index] = '* %s' % display[index]
        return display

    def select_translator_item(self, uri, via=None, atl=None, strm=None):
        response = self.make_response('GET', uri)
        if not response.text:
            helpers.log('select_translator_item empty response, retrying')
            response = self.make_response('GET', uri)
            if not response.text:
                return
        content_list = common.parseDOM(response.text, "div", attrs={"class": "b-content__main"})
        if not content_list:
            helpers.log("select_translator_item fault parse main content")
            return
        try:
            post_id = common.parseDOM(response.text, "input", attrs={"id": "post_id"}, ret="value")[0]
        except Exception as ex:
            helpers.log(f'select_translator_item fault post_id ex: {ex}')
            return
        titles, ids, directors, premium, active = self._parse_translators(content_list[0])
        if not titles or not ids:
            return
        cached = self._get_cached_translator(post_id, ids)
        atl_mode = (atl or '').lower() == 'true'
        picked_id = None
        if atl_mode:
            # Headless opens never dialog: keep cached choice, else site-active.
            current = cached if cached is not None else active
            helpers.log('select_translator_item atl silent, kept translator %s' % current)
        else:
            is_series = bool(common.parseDOM(response.text, "div", attrs={"id": "simple-episodes-tabs"}))
            display = self._annotate_translators(titles, ids, directors, premium, post_id, uri, cached, is_series)
            dialog = xbmcgui.Dialog()
            index_ = dialog.select(self.language(30006), display)
            if int(index_) >= 0:
                try:
                    picked_name = titles[index_] if index_ < len(titles) else ''
                    HDRezkaCache(self.profile).set_post_translation(post_id, ids[index_], picked_name)
                    helpers.log('select_translator_item saved post %s translator %s' % (post_id, ids[index_]))
                    picked_id = ids[index_]
                except Exception as ex:
                    helpers.log(f'select_translator_item fault save cache ex: {ex}')
        if via == 'menu':
            xbmc.executebuiltin(CONTAINER_REFRESH)
        else:
            try:
                self.show(uri, (atl or '').lower() == 'true', strm)
            except Exception as ex:
                helpers.log(f'select_translator_item fault rebuild ex: {ex}')
                xbmcplugin.endOfDirectory(self.handle, False)
                return
        # site sync is best-effort and always last: never block UI on it.
        if picked_id is not None:
            try:
                self._push_translator_to_site(post_id, picked_id, uri)
            except Exception as ex:
                helpers.log(f'select_translator_item fault push ex: {ex}')

    def _push_translator_to_site(self, post_id, translator_id, url):
        try:
            response = self.make_response('POST', '/ajax/send_watching/?t=', data={
                'id': post_id,
                'action': 'add',
                'translator_id': translator_id,
            }, headers=self._cdn_headers(url)).json()
            helpers.log('send_watching response: %s' % response)
        except Exception as ex:
            helpers.log('send_watching fault ex: %s' % ex)

    def select_translator(self, content, tv_show, post_id, url, idt, action, allow_dialog=False):
        titles, ids, directors, premium, _active = self._parse_translators(content)
        if not titles:
            return tv_show, idt, None
        cached = self._get_cached_translator(post_id, ids)
        if cached is not None:
            idt = cached
        elif allow_dialog and ids and titles:
            display = self._annotate_translators(titles, ids, directors, premium, post_id, url, cached, action != "get_movie")
            dialog = xbmcgui.Dialog()
            index_ = dialog.select(self.language(30006), display)
            if 0 <= int(index_) < len(ids):
                idt = ids[index_]
                try:
                    HDRezkaCache(self.profile).set_post_translation(post_id, idt, titles[index_])
                except Exception as ex:
                    helpers.log(f'select_translator fault save cache ex: {ex}')

        data = {
            "id": post_id,
            "translator_id": idt,
            "action": action
        }
        if directors:
            try:
                director = directors[ids.index(idt)]
            except Exception:
                director = None
            if director:
                data['is_director'] = director

        headers = self._cdn_headers(url)
        try:
            response = self.make_response('POST', CDN_SERIES_URL, data=data, headers=headers).json()
        except Exception as ex:
            helpers.log(f'select_translator fault request ex: {ex}')
            return tv_show, idt, None

        subtitles = None
        try:
            if action == "get_movie":
                playlist = [response["url"]]
                subtitles = helpers.get_subtitles(response)
            else:
                episodes = response["episodes"]
                playlist = common.parseDOM(episodes, "ul", attrs={"class": "b-simple_episodes__list clearfix"})
        except Exception as ex:
            helpers.log(f'select_translator fault playlist ex: {ex}')
            return tv_show, idt, None
        return playlist, idt, subtitles

    def show(self, uri, atl_mode=False, strm=None, season=None):
        response = self.make_response('GET', uri)

        content_list = common.parseDOM(
            response.text,
            "div",
            attrs={"class": "b-content__main"}
        )

        if not content_list:
            helpers.log("fault parse main content")
            return

        content = content_list[0]
        image = common.parseDOM(content, "img", attrs={"itemprop": "image"}, ret="src")[0]
        title = common.stripTags(common.parseDOM(content, "h1")[0]).strip()
        page_ids = _page_unique_ids(response.text)
        post_id = common.parseDOM(response.text, "input", attrs={"id": "post_id"}, ret="value")[0]
        page_card = _card_parse(response.text) or {}
        # описание сериала - последний запас для описания серии (владелец, 21.11.2026)
        show_plot = str(page_card.get('plot') or '').strip()
        if self.skin_mode and post_id:
            # страница уже здесь - карточка для полос и истории просмотров бесплатно
            _card_put(self.profile, post_id, page_card)
        translator_titles, translator_ids, _directors, translator_premium, translator_active = self._parse_translators(content)
        has_translator_choice = bool(translator_titles and translator_ids)
        idt = translator_active
        if idt is None:
            helpers.log('no active translator found')
            idt = "0"
            try:
                init_m = re.search(r'initCDNSeriesEvents\s*\(\s*\d+\s*,\s*(\d+)', response.text)
                if init_m:
                    idt = init_m.group(1)
                else:
                    idt = response.text.split("sof.tv.initCDNSeriesEvents")[-1].split("{")[0]
                    idt = idt.split(",")[1].strip()
            except Exception as ex:
                helpers.log(f'fault search CDN ex: {ex}')
        if not idt.isdigit():
            helpers.log('fault translator id, using default: %s' % idt)
            idt = "0"
        subtitles = None
        tv_show = common.parseDOM(response.text, "div", attrs={"id": "simple-episodes-tabs"})
        if not tv_show:
            tv_show = common.parseDOM(response.text, "ul", attrs={"id": "simple-episodes-tabs"})
        if not tv_show and ("initCDNSeriesEvents" in response.text or "/series/" in uri):
            tv_show = common.parseDOM(response.text, "ul", attrs={"class": "b-simple_episodes__list"}) or [response.text]
        if tv_show:
            if has_translator_choice and not self.skin_mode:
                self._add_translator_item(translator_titles, translator_ids, translator_premium, post_id, idt, uri)
            tv_show, idt, subtitles = self.select_translator(content, tv_show, post_id, uri, idt, "get_episodes", allow_dialog=not atl_mode and self.translator == 'select')
            titles = common.parseDOM(tv_show, "li")
            ids = common.parseDOM(tv_show, "li", ret='data-id')
            seasons = common.parseDOM(tv_show, "li", ret='data-season_id')
            episodes = common.parseDOM(tv_show, "li", ret='data-episode_id')
            dub = _dub_properties(self, translator_titles, translator_ids, post_id, idt, uri) if self.skin_mode else {}
            watched = _kodi_watched(post_id) if self.skin_mode else {}
            if self.skin_mode and not atl_mode and season is None and seasons:
                # как у Filmix: сериал -> папки сезонов -> серии сезона (экран сериала скина)
                order = []
                for s_id in seasons:
                    if s_id not in order:
                        order.append(s_id)
                for s_id in order:
                    eps = [e for s2, e in zip(seasons, episodes) if s2 == s_id]
                    seen = sum(1 for e in eps if watched.get((str(s_id), str(e))))
                    folder = xbmcgui.ListItem('%s %s' % (self.language(30005), s_id))
                    folder.setArt({'thumb': image, 'poster': image, 'icon': image})
                    labels = {'title': '%s %s' % (self.language(30005), s_id), 'mediatype': 'season', 'tvshowtitle': title}
                    if str(s_id).isdigit():
                        labels['season'] = int(s_id)
                    folder.setInfo(type='video', infoLabels=labels)
                    _set_unique_ids(folder, {'tvshow.' + k: v for k, v in page_ids.items()})
                    for key, value in dub.items():
                        folder.setProperty(key, value)
                    folder.setProperty('tmdb_type', 'tv')
                    folder.setProperty('TotalEpisodes', str(len(eps)))
                    folder.setProperty('totalepisodes', str(len(eps)))
                    folder.setProperty('WatchedEpisodes', str(seen))
                    folder.setProperty('UnWatchedEpisodes', str(len(eps) - seen))
                    folder.setProperty('WatchedEpisodePercent', str(int(100 * seen / len(eps)) if eps else 0))
                    if seen:
                        folder.setProperty('SeriesStarted', 'true')
                    xbmcplugin.addDirectoryItem(self.handle, router.build_uri('show', uri=uri, season=s_id), folder, True)
                xbmcplugin.setContent(self.handle, 'seasons')
                xbmcplugin.endOfDirectory(self.handle, True)
                return

            tmdb_eps = {}
            if self.skin_mode and season is not None and page_ids.get('imdb'):
                tmdb_eps = _tmdb_season(self.profile, page_ids['imdb'], season)
            for title_, episode_post_id, season_id, episode_id in zip(titles, ids, seasons, episodes):
                if season is not None and str(season_id) != str(season):
                    continue
                if atl_mode:
                    try:
                        season_no = int(season_id)
                        episode_no = int(episode_id)
                    except (TypeError, ValueError):
                        season_no = 0
                        episode_no = 0
                    label = "%s.s%02de%02d" % (title.strip(), season_no, episode_no)
                    episode_title = title
                else:
                    # в режиме скина сезон и так виден (папка сезона, 1x01) - без «(Сезон N)»
                    label = common.stripTags(title_).strip() if self.skin_mode else f"{title_} ({self.language(30005)} {season_id})"
                    episode_title = title_
                url_episode = uri
                # Library URLs carry ids alone; title/image serve the quality picker only.
                slim = atl_mode
                item_uri = router.build_uri(
                    'play_episode',
                    url=url_episode,
                    post_id=episode_post_id,
                    season_id=season_id,
                    episode_id=episode_id,
                    title=None if slim else episode_title,
                    image=None if slim else image,
                    idt=idt,
                    strm='1' if atl_mode else None,
                )
                item = xbmcgui.ListItem(label)
                item.setArt({'thumb': image, 'icon': image})
                episode_labels = {'title': label}
                if self.skin_mode:
                    episode_labels = {'title': common.stripTags(episode_title).strip(), 'mediatype': 'episode',
                                      'tvshowtitle': title}
                    if str(season_id).isdigit():
                        episode_labels['season'] = int(season_id)
                    if str(episode_id).isdigit():
                        episode_labels['episode'] = int(episode_id)
                ep = tmdb_eps.get(str(episode_id)) if tmdb_eps else None
                if show_plot:
                    # описание серии: русское, иначе английское (TMDb), иначе описание сериала
                    episode_labels['plot'] = show_plot
                if ep:
                    # кадр серии, название и описание из TMDb - как у Filmix
                    if ep.get('name'):
                        episode_labels['title'] = ep['name']
                    if ep.get('overview'):
                        episode_labels['plot'] = ep['overview']
                    if ep.get('air_date'):
                        episode_labels['aired'] = ep['air_date']
                    if ep.get('still'):
                        item.setArt({'thumb': ep['still'], 'landscape': ep['still'], 'still': ep['still'],
                                     'icon': ep['still'], 'poster': image, 'tvshow.poster': image})
                item.setInfo(type='Video', infoLabels=episode_labels)
                if self.skin_mode:
                    _set_unique_ids(item, {'tvshow.' + k: v for k, v in page_ids.items()})
                    item.setProperty('tmdb_type', 'tv')
                    item.setProperty('RezkaPostID', str(post_id))
                    for key, value in dub.items():
                        item.setProperty(key, value)
                if has_translator_choice:
                    item.addContextMenuItems(self._translator_menu(uri))
                if self.quality != 'select' or atl_mode:
                    item.setProperty('IsPlayable', 'true')
                if self.skin_mode:
                    _apply_episode_state(item, watched.get((str(season_id), str(episode_id))),
                                         title, _show_year(post_id), season_id, episode_id)
                xbmcplugin.addDirectoryItem(self.handle, item_uri, item, False if self.quality != 'select' or atl_mode else True)
        else:
            content = [response.text]
            if has_translator_choice and not self.skin_mode:
                self._add_translator_item(translator_titles, translator_ids, translator_premium, post_id, idt, uri)
            # Movie pages are never scanned headless, so asking on miss is safe.
            content, idt, subtitles = self.select_translator(content[0], content, post_id, uri, idt, "get_movie", allow_dialog=True)
            if subtitles is None:
                # when action == get_movie, None is returned only when some exception occurs,
                # so we set the streams_block to default
                streams_match = re.search(r'"streams":"([^"]+)', response.text)
                if not streams_match:
                    helpers.log('fault streams block')
                    return
                streams_block = streams_match.group(1)
            else:
                # success, get selected translator streams
                streams_block = content[0]
            links = parse_streams(streams_block, stream_type=self.stream_type)
            play_info = {
                'post_id': post_id,
                'translator_id': idt,
                'season': 0,
                'episode': 0,
            }
            self.select_quality(links, title, image, subtitles, '1' if strm == '1' else None, play_info)

        xbmcplugin.setContent(self.handle, 'episodes' if tv_show else 'videos')
        xbmcplugin.endOfDirectory(self.handle, True)

    def _cards(self, uris, post_ids):
        """{post_id: {plot, originaltitle, ids}} для строк списка; страница фильма - раз в неделю.

        В списке сайта у строки нет ни описания, ни IMDb/Кинопоиска, и скин не мог
        опознать новинки: без описания, логотипа и трейлера. Недостающие карточки
        грузятся параллельно и не дольше CARD_WAIT секунд; что не успело - догрузит
        фоновый прогрев (service.py) или следующее открытие.
        """
        from concurrent.futures import ThreadPoolExecutor, wait
        out, missing = {}, []
        for uri, post_id in zip(uris, post_ids):
            card = _card_get(self.profile, post_id)
            if card is not None:
                out[str(post_id)] = card
            if card is None or 'stream_quality' not in card:
                missing.append((uri, str(post_id)))

        missing = missing[:CARD_BATCH]
        refused = []
        deadline = time.time() + CARD_WAIT

        def load(job):
            uri, post_id = job
            if refused or time.time() > deadline:
                return
            try:
                response = self.make_response('GET', uri)
            except Exception as ex:
                helpers.log('card fault %s: %s' % (uri, ex))
                return
            if response.status_code in (403, 429, 503):
                refused.append(response.status_code)     # сайт отказал - остальные не просить
                return
            if response.status_code != 200 or 'b-post__title' not in response.text:
                return                                   # не страница фильма - просто пропустить
            card = _card_parse(response.text)
            _card_put(self.profile, post_id, card)
            out[post_id] = card

        if missing:
            pool = ThreadPoolExecutor(max_workers=CARD_WORKERS)
            futures = [pool.submit(load, job) for job in missing]
            wait(futures, timeout=CARD_WAIT)
            try:
                pool.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                # Python 3.8 (Kodi 21 на Windows): аргумента cancel_futures нет (23.11.2026)
                pool.shutdown(wait=False)
            if refused:
                helpers.log('карточки: сайт отказал (%s)' % refused[0])
        return out

    def get_item_additional_info(self, post_id):
        additional = {
            'rating': {
                'site': '',
                'imdb': '',
                'kp': ''
            },
            'age_limit': '',
            'description': ''
        }
        if not self.show_description:
            return additional

        try:
            cached = HDRezkaCache(self.profile).get_bubble(post_id, BUBBLE_CACHE_TTL)
        except Exception as ex:
            helpers.log(f'get bubble cache fault ex: {ex}')
            cached = None
        if cached is not None:
            return cached

        response = self.make_response('POST', '/engine/ajax/quick_content.php', data={
            "id": post_id,
            "is_touch": 1
        })

        try:
            additional['description'] = common.parseDOM(response.text, 'div', attrs={'class': 'b-content__bubble_text'})[0]
        except IndexError:
            helpers.log(f'fault parse description post_id: {post_id}', xbmc.LOGDEBUG)

        try:
            additional['age_limit'] = re.search(r'<b style="color: #333;">(\d+\+)</b>', response.text).group(1)
        except AttributeError:
            helpers.log(f'fault parse age_limit post_id: {post_id}', xbmc.LOGDEBUG)

        try:
            site_rating = common.parseDOM(response.text, 'div', attrs={'class': 'b-content__bubble_rating'})[0]
            additional['rating']['site'] = common.parseDOM(site_rating, 'b')[0]
        except IndexError:
            helpers.log(f'fault parse site rating post_id: {post_id}', xbmc.LOGDEBUG)

        try:
            imdb_rating_block = common.parseDOM(response.text, 'span', attrs={'class': 'imdb'})[0]
            imdb_rating = common.parseDOM(imdb_rating_block, 'b')[0]
            additional['rating']['imdb'] = imdb_rating
            additional['description'] = f'IMDb: {helpers.color_rating(imdb_rating)}\n{additional["description"]}'
        except IndexError:
            helpers.log(f'fault parse imdb rating post_id: {post_id}', xbmc.LOGDEBUG)

        try:
            kp_rating_block = common.parseDOM(response.text, 'span', attrs={'class': 'kp'})[0]
            kp_rating = common.parseDOM(kp_rating_block, 'b')[0]
            additional['rating']['kp'] = kp_rating
            additional['description'] = f' Кинопоиск: {helpers.color_rating(kp_rating)}\n{additional["description"]}'
        except IndexError:
            helpers.log(f'fault parse kp rating post_id: {post_id}', xbmc.LOGDEBUG)

        try:
            HDRezkaCache(self.profile).set_bubble(post_id, additional, BUBBLE_CACHE_TTL)
        except Exception as ex:
            helpers.log(f'set bubble cache fault ex: {ex}')

        return additional

    def history(self):
        words = history.get_history()
        for word in reversed(words):
            uri = router.build_uri('search', keyword=word, main=1)
            item = xbmcgui.ListItem(word)
            item.setArt({'thumb': self.icon, 'icon': self.icon})
            item.addContextMenuItems([(self.language(30015), RUN_PLUGIN_FMT % router.build_uri('history_delete', keyword=word))])
            xbmcplugin.addDirectoryItem(self.handle, uri, item, True)
        xbmcplugin.endOfDirectory(self.handle, True)

    def delete_history(self, keyword):
        if keyword:
            history.delete_from_history(keyword)
            xbmcgui.Dialog().notification(self.addon.getAddonInfo('name'), self.language(30017), self.icon)
        xbmc.executebuiltin(CONTAINER_REFRESH)

    def delete_continue(self, data_id):
        if data_id:
            response = self.make_response('POST', '/engine/ajax/cdn_saves_remove.php', data={'id': data_id})
            helpers.log(f'continues remove response: {response.status_code}')
            xbmcgui.Dialog().notification(self.addon.getAddonInfo('name'), self.language(30018), self.icon)
        xbmc.executebuiltin(CONTAINER_REFRESH)

    def continues(self):
        response = self.make_response('GET', '/continue/')
        genres = common.parseDOM(response.text, "div", attrs={"class": "b-videosaves__list_item"})
        titles = common.parseDOM(genres, "div", attrs={"class": "td title"})
        info = common.parseDOM(genres, "div", attrs={"class": "td info"})
        controls = common.parseDOM(genres, "div", attrs={"class": "td controls"})
        try:
            translator_cache = HDRezkaCache(self.profile)
        except Exception as ex:
            helpers.log(f'continues fault cache ex: {ex}')
            translator_cache = None

        rows = []
        progress_pattern = re.compile(r'^'
                                      r'(?:(.*?)(?=\s*(?:\d+\s*сезон|\d+\s*серия|смотреть|$)))?'
                                      r'(?:\s*(\d+)\s*сезон)?'
                                      r'(?:\s*(\d+)\s*серия)?'
                                      r'(?:\s*(\(.*?\)))?'
                                      r'(?:\s*смотреть\s*ещё\s*(\d+))?'
                                      r'(?:\s*смотреть\s*следующий\s*(\d+))?'
                                      r'.*?$', re.IGNORECASE | re.UNICODE | re.VERBOSE)

        for i, title_html in enumerate(titles):
            try:
                if i >= len(info):
                    continue
                try:
                    year = (common.parseDOM(title_html, "small")[0])[1:5]
                except (IndexError, TypeError):
                    year = ''
                try:
                    link_title = common.parseDOM(title_html, "a")[0]
                except IndexError:
                    continue
                episodes_text = common.stripTags(info[i])
                match = progress_pattern.match(episodes_text)

                result = None
                if match:
                    result = list(match.groups())
                    result = [x.strip() if x and j in (0, 3) else x for j, x in enumerate(result)]
                    result = [x if x and x.strip() else None for x in result]

                episodes = None
                translate = None
                season = None
                episode = None
                episode_new = None
                season_new = None
                if result is not None and len(result) == 6:
                    if result[0] is not None:
                        translate = '(%s)' % result[0]
                    if result[1] is not None:
                        season = result[1]
                    if result[2] is not None:
                        episode = result[2]
                    if result[3] is not None:
                        translate = result[3]
                    if result[4] is not None:
                        episode_new = result[4]
                    if result[5] is not None:
                        season_new = result[5]

                if season and episode:
                    episodes = '[s%se%s]' % (season, episode)
                    if episode_new:
                        episodes = episodes.replace(']', '')
                        episodes = '%s - новых %s в сезоне]' % (episodes, episode_new)
                    if season_new:
                        episodes = episodes.replace(']', '')
                        episodes = '%s - новый %sй сезон]' % (episodes, season_new)

                try:
                    item_link = common.parseDOM(info[i], "a", ret='href')[0]
                except IndexError:
                    try:
                        item_link = common.parseDOM(title_html, "a", ret='href')[0]
                    except IndexError:
                        continue
                if translator_cache is not None:
                    try:
                        show_post_id = re.search(r'/(\d+)-', item_link).group(1)
                        cached_name = translator_cache.get_post_translation_name(show_post_id)
                    except Exception:
                        cached_name = None
                    if cached_name:
                        translate = cached_name
                try:
                    thumb = self._normalize_url(common.parseDOM(title_html, "a", ret='data-cover_url')[0])
                except IndexError:
                    thumb = self.icon
                try:
                    save_id = common.parseDOM(controls[i], "a", attrs={"class": "i-sprt delete"}, ret='data-id')[0]
                except (IndexError, TypeError):
                    save_id = None
                rows.append({'title': common.stripTags(link_title).strip(), 'year': year, 'translate': translate,
                             'episodes': episodes, 'link': item_link, 'thumb': thumb, 'save_id': save_id,
                             'season': season, 'episode': episode})
            except Exception as ex:
                helpers.log(f'continues fault item ex: {ex}')
                continue

        # sublime: строки «Продолжить просмотр» - как строки каталога: чистое название, IMDb/
        # Кинопоиск и описание из карточки фильма. С названием «Побег из Шоушенка [COLOR=...]
        # (1994)(Дубляж)» и без идентификаторов скин не опознавал запись: ни описания, ни
        # фона, ни трейлера (.20, 17.11.2026)
        cards = {}
        if self.skin_mode and rows:
            post_ids = []
            for row in rows:
                m = re.search(r'/(\d+)-', row['link'])
                post_ids.append(m.group(1) if m else '')
            cards = self._cards([router.normalize_uri(r['link']) for r in rows], post_ids)
        pending = []
        for row in rows:
            try:
                m = re.search(r'/(\d+)-', row['link'])
                post_id = m.group(1) if m else ''
                is_serial = bool(row['episodes'])
                if self.skin_mode:
                    label = row['title']
                else:
                    label = '%s [COLOR=lawngreen](%s)[/COLOR]%s%s' % (
                        row['title'], row['year'],
                        '[COLOR=gold]%s[/COLOR]' % row['translate'] if row['translate'] is not None else '',
                        '[COLOR=cyan]%s[/COLOR]' % row['episodes'] if row['episodes'] is not None else '')
                item_uri = router.build_uri('show', uri=router.normalize_uri(row['link']))
                item = xbmcgui.ListItem(label)
                item.setArt({'thumb': row['thumb'], 'icon': row['thumb']})
                info_labels = {'title': label, 'mediatype': 'tvshow' if is_serial else 'movie'}
                if row['year']:
                    info_labels['year'] = row['year']
                if is_serial:
                    info_labels['tvshowtitle'] = label
                card = cards.get(post_id) or {}
                if self.skin_mode:
                    if card.get('plot'):
                        info_labels['plot'] = card['plot']
                    if card.get('originaltitle'):
                        info_labels['originaltitle'] = card['originaltitle']
                    rating, votes = _card_rating(card)
                    if rating:
                        info_labels['rating'] = rating
                        info_labels['votes'] = str(votes)
                item.setInfo(type='video', infoLabels=info_labels)
                if self.skin_mode:
                    if card.get('ids'):
                        _set_unique_ids(item, card['ids'])
                    _skin_properties(item, 'tv' if is_serial else 'movie', row['year'], '', post_id)
                    # перевод и место просмотра - отдельными свойствами, не в названии
                    if row['translate']:
                        item.setProperty('RezkaTranslation', str(row['translate']).strip('()'))
                    if row['season'] and row['episode']:
                        item.setProperty('RezkaProgress', 's%se%s' % (row['season'], row['episode']))
                menu_items = []
                if row['save_id']:
                    menu_items.append((self.language(30016), RUN_PLUGIN_FMT % router.build_uri('continue_delete', id=row['save_id'])))
                menu_items.extend(self._translator_menu(router.normalize_uri(row['link'])))
                item.addContextMenuItems(menu_items)
                is_folder = True
                if (self.quality != 'select') and not is_serial:
                    item.setProperty('IsPlayable', 'true')
                    is_folder = False
                _apply_watch_state(item, item_uri)
                pending.append((item_uri, item, is_folder, {
                    'file': item_uri, 'label': label, 'title': label,
                    'originaltitle': card.get('originaltitle') or '',
                    'year': row['year'] or 0, 'type': info_labels['mediatype'],
                    'plot': info_labels.get('plot') or '', 'uniqueid': card.get('ids') or {}, 'release': card.get('stream_quality') or '',
                    'art': {'thumb': row['thumb'], 'poster': row['thumb']},
                    'filetype': 'directory' if is_folder else 'file'}))
            except Exception as ex:
                helpers.log(f'continues fault item ex: {ex}')
                continue
        _add_rows(self.handle, pending)

        xbmcplugin.setContent(self.handle, 'movies')
        xbmcplugin.endOfDirectory(self.handle, True)

    def get_user_input(self):
        kbd = xbmc.Keyboard()
        kbd.setDefault('')
        kbd.setHeading(self.language(30000))
        kbd.doModal()
        keyword = None

        if kbd.isConfirmed():
            if self.use_transliteration:
                keyword = transliterate.rus(kbd.getText())
            else:
                keyword = kbd.getText()

            history.add_to_history(keyword)

        return keyword

    def search(self, keyword, external):
        helpers.log(f'*** search keyword: {keyword} external: {external}')

        keyword = urllib.parse.unquote_plus(keyword) if (external is not None) else self.get_user_input()
        if not keyword:
            return self.menu()

        params = {
            "do": "search",
            "subaction": "search",
            "q": str(keyword)
        }
        self.user_search = not self.warm
        try:
            response = self.make_response('GET', '/search/', params=params, cookies={"dle_user_taken": '1'})
        finally:
            self.user_search = False

        content = common.parseDOM(response.text, "div", attrs={"class": "b-content__inline_items"})
        items = common.parseDOM(content, "div", attrs={"class": "b-content__inline_item"})
        post_ids = common.parseDOM(content, "div", attrs={"class": "b-content__inline_item"}, ret="data-id")
        link_containers = common.parseDOM(items, "div", attrs={"class": "b-content__inline_item-link"})
        links = common.parseDOM(link_containers, "a", ret='href')
        titles = common.parseDOM(link_containers, "a")

        serial_count = 0
        cards = self._cards([router.normalize_uri(l) for l in links], post_ids) if self.skin_mode else {}
        pending = []
        for i, name in enumerate(titles):
            if self.skin_mode:
                info = {'rating': {'site': '', 'imdb': '', 'kp': ''}, 'age_limit': '', 'description': ''}
            else:
                info = self.get_item_additional_info(post_ids[i])
            country_divs = common.parseDOM(link_containers[i], "div")
            country_text = country_divs[0] if country_divs else ''
            name = common.stripTags(name).strip()
            title = name if self.skin_mode else helpers.built_title(name, country_text, **info)
            image = self._normalize_url(common.parseDOM(items[i], "img", ret='src')[0])
            item_uri = router.build_uri('show', uri=router.normalize_uri(links[i]))
            year, country, genre = helpers.get_media_attributes(country_text)
            is_serial = common.parseDOM(items[i], 'span', attrs={"class": "info"})
            item = xbmcgui.ListItem(title)
            item.setArt({'thumb': image, 'icon': image})
            item.addContextMenuItems(self._translator_menu(router.normalize_uri(links[i])))
            info_labels = {
                'title': title,
                'genre': genre,
                'country': country,
                'plot': info['description'],
                'rating': info['rating']['site']
            }
            if year:
                info_labels['year'] = year
            if info['age_limit']:
                info_labels['mpaa'] = info['age_limit']
            serial = bool(is_serial)
            serial_count += serial
            info_labels['mediatype'] = 'tvshow' if serial else 'movie'
            if serial:
                info_labels['tvshowtitle'] = title
            card = cards.get(str(post_ids[i]) if i < len(post_ids) else '') or {}
            if self.skin_mode:
                info_labels.pop('rating', None)
                info_labels.pop('plot', None)
                # описание и оригинальное название со страницы фильма - как в строках Filmix
                if card.get('plot'):
                    info_labels['plot'] = card['plot']
                if card.get('originaltitle'):
                    info_labels['originaltitle'] = card['originaltitle']
                rating, votes = _card_rating(card)
                if rating:
                    info_labels['rating'] = rating
                    info_labels['votes'] = str(votes)
            item.setInfo(type='video', infoLabels=info_labels)
            if self.skin_mode and card.get('ids'):
                # по IMDb/Кинопоиску скин опознаёт запись точно: логотип, трейлер, оценки
                _set_unique_ids(item, card['ids'])
            _skin_properties(item, 'tv' if serial else 'movie', year, country, post_ids[i])
            is_folder = True
            if (self.quality != 'select') and not is_serial:
                item.setProperty('IsPlayable', 'true')
                is_folder = False
            _apply_watch_state(item, item_uri)
            pending.append((item_uri, item, is_folder, {
                'file': item_uri, 'label': title, 'title': title,
                'originaltitle': card.get('originaltitle') or '',
                'year': year or 0, 'type': info_labels['mediatype'],
                'genre': genre, 'country': country, 'plot': info_labels.get('plot') or '',
                'uniqueid': card.get('ids') or {}, 'release': card.get('stream_quality') or '', 'art': {'thumb': image, 'poster': image},
                'filetype': 'directory' if is_folder else 'file'}))
        _add_rows(self.handle, pending)

        xbmcplugin.setContent(self.handle, 'movies')
        xbmcplugin.endOfDirectory(self.handle, True)

    def play(self, url, subtitles=None, play_info=None, title=None):
        helpers.log(f'*** play url: {url} subtitles: {subtitles}')

        raw_headers = urllib.parse.urlencode({
            'User-Agent': USER_AGENT,
            'Referer': f"{self.url}/"
        })
        if url and '|' not in url:
            playback_url = f"{url}|{raw_headers}"
        else:
            playback_url = url

        item = xbmcgui.ListItem(path=playback_url)
        item.setContentLookup(False)
        if '.m3u8' in (url or ''):
            item.setMimeType('application/vnd.apple.mpegurl')
            item.setProperty('inputstream', 'inputstream.adaptive')
            item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            item.setProperty('inputstream.adaptive.stream_headers', raw_headers)
        else:
            item.setMimeType('video/mp4')

        labels = {}
        if title:
            osd_title = re.sub(r'\s*\(\d{4}\)\s*$', '', title)
            labels['title'] = osd_title or title
        if play_info and play_info.get('tvshowtitle') and str(play_info.get('episode') or '').isdigit():
            labels.update(tvshowtitle=play_info['tvshowtitle'], mediatype='episode',
                          season=int(play_info.get('season') or 0), episode=int(play_info['episode']))
            if str(play_info.get('year') or '').isdigit():
                labels['year'] = int(play_info['year'])
        if labels:
            item.setInfo(type='Video', infoLabels=labels)
        if play_info:
            # HDRezkaPlayer sees only the resolved item: attach all ids here.
            item.setProperty('addon_id', self.id)
            for key, value in play_info.items():
                item.setProperty(key, '%s' % value)
        helpers.set_item_subtitles(item, subtitles)
        xbmcplugin.setResolvedUrl(self.handle, True, item)

    def play_episode(self, url, post_id, season_id, episode_id, title=None, image=None, idt=None, strm=None, show_id=None):
        if show_id is not None:
            try:
                cached = HDRezkaCache(self.profile).get_post_translation(show_id)
            except Exception as ex:
                helpers.log(f'play_episode fault read cache ex: {ex}')
                cached = None
            if cached is not None:
                idt = cached
        if not idt or idt == "0":
            try:
                page_res = self.make_response('GET', url)
                init_m = re.search(r'initCDNSeriesEvents\s*\(\s*\d+\s*,\s*(\d+)', page_res.text)
                if init_m:
                    idt = init_m.group(1)
            except Exception as ex:
                helpers.log(f'play_episode fallback idt ex: {ex}')

        data = {
            "id": post_id,
            "translator_id": idt,
            "season": season_id,
            "episode": episode_id,
            "action": "get_stream"
        }
        safe_referer = urllib.parse.quote(url, safe=":/%?&=#+@*~,;!-._") if url else f"{self.url}/"
        headers = {
            "Host": self.domain,
            "Origin": self.url,
            "Referer": safe_referer,
            "User-Agent": USER_AGENT,
            "X-Requested-With": "XMLHttpRequest"
        }
        resp = self.make_response('POST', CDN_SERIES_URL, data=data, headers=headers)
        try:
            response = resp.json()
        except ValueError:
            # не JSON: отказ сайта или антибот-страница
            page_title = re.search(r'<title>(.*?)</title>', resp.text, re.S)
            helpers.log('get_cdn_series: не JSON, %s, %d байт, %s: %s' % (
                resp.status_code, len(resp.text), resp.url,
                page_title.group(1).strip()[:120] if page_title else resp.text[:200]))
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return
        if not response.get("success"):
            msg = response.get("message", "Ошибка получения потока")
            helpers.log(f"get_cdn_series returned success=False: {msg}")
            xbmcgui.Dialog().notification("HDRezka", msg, self.icon, 3000)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return

        data = response["url"]
        subtitles = helpers.get_subtitles(response)
        links = parse_streams(data, stream_type=self.stream_type)
        play_info = {
            'post_id': post_id,
            'translator_id': idt,
            'season': season_id,
            'episode': episode_id,
        }
        # без названия сериала, сезона и серии скин записывал просмотр серии как «весь сериал»
        # (17.11.2026 на .20: «Гангстерленд» S1E1 стал v1|гангстерленд мобленд|2025)
        show_title, show_year = _show_card(post_id)
        if not show_title and url:
            # карточки ещё нет (свежая установка): название - со страницы сериала, год - из адреса
            try:
                page = self.make_response('GET', url)
                card = _card_parse(page.text)
                show_title = _show_name(card.get('title') or '')
                if card.get('title'):
                    # карточка нужна и скину: по ней он называет серию в общей базе просмотров
                    card['serial'] = True
                    _card_put(self.profile, post_id, card)
            except Exception as ex:
                helpers.log('play_episode: название сериала не получено: %s' % ex)
            m = re.search(r'-(\d{4})(?:-latest)?\.html', url)
            show_year = show_year or (m.group(1) if m else '')
        if show_title:
            play_info['tvshowtitle'] = show_title
            play_info['year'] = show_year
        self.select_quality(links, title, image, subtitles, strm, play_info)
        xbmcplugin.setContent(self.handle, 'episodes')
        xbmcplugin.endOfDirectory(self.handle, True)

    def _normalize_url(self, item):
        if not item.startswith("http"):
            item = self.url + item
        return item


def main():
    reset_call_state()
    plugin = HdrezkaTV()

    action = sys.argv[2] if len(sys.argv) > 2 else (sys.argv[1] if len(sys.argv) > 1 and not sys.argv[1].isdigit() else '')
    if action == 'authorize':
        actions.authorize(plugin)
    elif action == 'logout':
        actions.logout(plugin)
    elif action == 'external_config_update':
        actions.external_config_update(plugin)
    else:
        plugin.main(action)

if __name__ == '__main__':
    main()
