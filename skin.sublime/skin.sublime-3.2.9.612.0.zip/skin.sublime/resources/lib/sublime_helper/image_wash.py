# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Asynchronous artwork colour-wash extraction.

This follows TMDb Helper's Colors mechanism: build a small RGB thumbnail,
calculate the mean colour, and publish a muted ARGB wash colour.  The source
artwork itself is never replaced, so background textures cannot turn
monochrome or disappear while processing completes.
"""

import colorsys
import hashlib
import io
import os
import queue
import threading
import time
from collections import OrderedDict
from urllib.parse import unquote

import xbmc
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

# Цвета - в одной базе (ключ md5 источника -> ARGB). Прежде каждый цвет лежал своим файлом в
# wash_colors_v7: 10905 файлов по 8 байт занимали 43 МБ блоками по 4 КБ, а предел в 2 МБ считал байты
# (аудит 23.11.2026). Старые файлы переносятся в базу (migrate_legacy) и затем удаляются.
_DB_URI = 'special://profile/addon_data/skin.sublime/wash_colors.db'
_LEGACY_URI = 'special://profile/addon_data/skin.sublime/wash_colors_v7/'
# временные копии картинок при разборе цвета
_CACHE_URI = 'special://profile/addon_data/skin.sublime/wash_tmp/'
_MAX_DB_ROWS = 60000
_QUEUE = queue.Queue(maxsize=4)
_PENDING = set()
_RESULTS = OrderedDict()
_FAILURES = OrderedDict()
_IDENTITIES = OrderedDict()
_LOCK = threading.RLock()
_WORKER = None
_FAILURE_RETRY_SECONDS = 30.0
_MAX_MEMORY_RESULTS = 128
_MAX_MEMORY_FAILURES = 64
_MAX_MEMORY_IDENTITIES = 256
_MAX_DISK_BYTES = 2 * 1024 * 1024
_MAX_DISK_AGE = 60 * 86400
_PRUNE_INTERVAL = 12 * 3600
_LAST_PRUNE = 0.0
_DEFAULT_COLOR = 'FF39465A'
_WASH_ALPHA = 0xFF


def _log(message, level=xbmc.LOGDEBUG):
    try:
        xbmc.log('[sublime background wash] %s' % message, level)
    except Exception:
        pass


def default_wash_color():
    return _DEFAULT_COLOR


def _md5(value):
    return hashlib.md5(str(value or '').encode('utf-8', errors='surrogatepass')).hexdigest()


def _translate(path):
    if not path:
        return ''
    try:
        return xbmcvfs.translatePath(path) if xbmcvfs else path
    except Exception:
        try:
            return xbmc.translatePath(path)
        except Exception:
            return path


def _exists(path):
    try:
        if xbmcvfs:
            return bool(path and xbmcvfs.exists(path))
        return bool(path and os.path.exists(_translate(path)))
    except Exception:
        return False


def _ensure_cache():
    try:
        if xbmcvfs:
            if not xbmcvfs.exists(_CACHE_URI):
                xbmcvfs.mkdirs(_CACHE_URI)
        else:
            os.makedirs(_translate(_CACHE_URI), exist_ok=True)
    except Exception:
        pass
    return _CACHE_URI


def _normalize_source(source):
    source = str(source or '').strip()
    if not source:
        return ''
    low = source.lower()
    for scheme in ('http://', 'https://', 'special://', 'smb://', 'nfs://'):
        marker = '@' + scheme
        index = low.find(marker)
        if index >= 0:
            source = source[index + 1:]
            low = source.lower()
            break
    if low.startswith('image://'):
        source = unquote(source[8:])
        if source.endswith('/'):
            source = source[:-1]
    return source


def _source_identity(source):
    """Invalidate a local artwork result when the file changes in place."""
    try:
        # логотип канала tvlink - по содержимому файла, как подложка (poster_background)
        from .poster_background import tvlink_logo_file, file_md5
        logo = tvlink_logo_file(source)
        if logo:
            return 'tvlogo|%s' % file_md5(logo)
    except Exception:
        pass
    translated = _translate(source)
    try:
        if translated and os.path.isfile(translated):
            stat = os.stat(translated)
            stamp = getattr(stat, 'st_mtime_ns', int(stat.st_mtime * 1000000000))
            return '%s|%s|%s' % (source, stamp, stat.st_size)
    except Exception:
        pass
    return source


def _destination(identity):
    """Ключ цвета в базе (md5 источника) - то же имя, что было у файла в wash_colors_v7."""
    return _md5(identity)


_DB_READY = []


def _db():
    # журнал и таблица - один раз на процесс: на фокусе это 1-3 мс лишнего на каждой строке (аудит 23.11.2026)
    import sqlite3
    path = _translate(_DB_URI)
    fresh = not _DB_READY or not os.path.exists(path)   # базу могла снести чистка кэшей
    conn = sqlite3.connect(path, timeout=5)
    if fresh:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('CREATE TABLE IF NOT EXISTS wash (key TEXT PRIMARY KEY, color TEXT, ts REAL)')
        if not _DB_READY:
            _DB_READY.append(True)
    return conn


def _valid_color(value):
    value = str(value or '').strip().upper()
    return value if len(value) == 8 and all(ch in '0123456789ABCDEF' for ch in value) else ''


def _image_open(path):
    from PIL import Image
    if xbmcvfs:
        with xbmcvfs.File(path, 'rb') as handle:
            data = handle.readBytes()
        return Image.open(io.BytesIO(data))
    return Image.open(_translate(path))


def _read_text(key):
    """Цвет по ключу: из базы, иначе из файла прежнего образца (он сразу переносится в базу)."""
    try:
        conn = _db()
        try:
            row = conn.execute('SELECT color FROM wash WHERE key=?', (key,)).fetchone()
        finally:
            conn.close()
        if row and _valid_color(row[0]):
            return _valid_color(row[0])
    except Exception:
        pass
    legacy = os.path.join(_translate(_LEGACY_URI), '%s.txt' % key)
    try:
        with open(legacy, 'r', encoding='ascii') as handle:
            value = _valid_color(handle.read())
        if value:
            _write_text(key, value)
        return value
    except Exception:
        return ''


def _write_text(key, value):
    value = _valid_color(value)
    if not value:
        return
    conn = _db()
    try:
        conn.execute('INSERT OR REPLACE INTO wash (key, color, ts) VALUES (?, ?, ?)', (key, value, time.time()))
        conn.commit()
    finally:
        conn.close()


def migrate_legacy():
    """Перенести цвета из wash_colors_v7 в базу и удалить папку. Возвращает число перенесённых."""
    import shutil
    root = _translate(_LEGACY_URI)
    if not root or not os.path.isdir(root):
        return 0
    rows = []
    for name in os.listdir(root):
        if not name.endswith('.txt'):
            continue
        try:
            with open(os.path.join(root, name), 'r', encoding='ascii') as handle:
                value = _valid_color(handle.read())
            if value:
                rows.append((name[:-4], value, os.path.getmtime(os.path.join(root, name))))
        except Exception:
            continue
    conn = _db()
    try:
        conn.executemany('INSERT OR IGNORE INTO wash (key, color, ts) VALUES (?, ?, ?)', rows)
        conn.commit()
    finally:
        conn.close()
    shutil.rmtree(root, ignore_errors=True)
    return len(rows)


def _cached_candidates(source):
    try:
        get_cache_name = xbmc.getCacheThumbName
    except Exception:
        return []
    decoded = unquote(str(source or '').replace('image://', ''))
    if decoded.endswith('/'):
        decoded = decoded[:-1]
    candidates = []
    for value in (decoded, source):
        try:
            name = get_cache_name(value)
        except Exception:
            continue
        if not name:
            continue
        candidates.extend([
            'special://profile/Thumbnails/%s/%s.jpg' % (name[0], name[:-4]),
            'special://profile/Thumbnails/%s/%s.png' % (name[0], name[:-4]),
            'special://profile/Thumbnails/Video/%s/%s' % (name[0], name),
        ])
    return candidates


def _skin_media_path(source):
    """Путь внутри media скина - только для голого имени файла.

    os.path.join не считает «special://profile/...» абсолютным путём и молча
    приклеивает его к media скина: получалось
    «special://skin/media/special://profile/...». Проверено на <коробка> -
    при таком источнике открыть не удавалось ничего, и цвет считался с копии,
    сделанной лишним xbmcvfs.copy. У poster_background перед этой же веткой
    стоят проверки существования, здесь их не было. Возвращаем пустую строку,
    когда источник - не имя файла: тогда ветка просто не сработает.
    """
    text = str(source or '')
    if not text or '://' in text or text[:1] in ('/', chr(92)):
        return ''
    return 'special://skin/media/' + text.lstrip('/')


def _local_image(source):
    """Уже лежащий рядом файл - его читаем прямо, без копирования."""
    text = str(source or '')
    if not text:
        return None
    try:
        if text.startswith('special://') and _exists(text):
            return _image_open(text)
    except Exception:
        return None
    try:
        translated = _translate(text)
        if translated and os.path.isfile(translated):
            return _image_open(text)
    except Exception:
        return None
    return None


def _open_source(source, temp_path):
    for cached in _cached_candidates(source):
        if not _exists(cached):
            continue
        try:
            return _image_open(cached), ''
        except Exception:
            pass
    local = _local_image(source)
    if local is not None:
        return local, ''
    try:
        skin_path = (source if source.startswith('special://skin')
                     else _skin_media_path(source))
        if skin_path and xbmc.skinHasImage(source):
            return _image_open(skin_path), ''
    except Exception:
        pass
    if not xbmcvfs:
        return _image_open(source), ''
    try:
        if not xbmcvfs.exists(temp_path) and not xbmcvfs.copy(source, temp_path):
            return None, ''
        return _image_open(temp_path), temp_path
    except Exception:
        return None, ''


def _prune_cache(force=False):
    global _LAST_PRUNE
    now = time.time()
    if not force and now - _LAST_PRUNE < _PRUNE_INTERVAL:
        return
    _LAST_PRUNE = now
    root = _translate(_CACHE_URI)
    try:
        if root and os.path.isdir(root):
            for name in os.listdir(root):
                path = os.path.join(root, name)
                try:
                    if name.startswith('temp_') and now - os.path.getmtime(path) > 600:
                        os.remove(path)
                except OSError:
                    pass
        conn = _db()
        try:
            conn.execute('DELETE FROM wash WHERE ts < ?', (now - _MAX_DISK_AGE,))
            conn.execute('DELETE FROM wash WHERE key IN (SELECT key FROM wash ORDER BY ts DESC LIMIT -1 OFFSET ?)',
                         (_MAX_DB_ROWS,))
            conn.commit()
        finally:
            conn.close()
    except Exception as exc:
        _log('cache prune skipped: %s' % exc, xbmc.LOGDEBUG)


def _muted_average_color(image):
    """Return a darkened opaque wash colour derived from the source artwork."""
    from PIL import ImageStat
    # Palette PNG picons may carry byte transparency. Converting through
    # RGBA avoids Pillow's palette-transparency warning and preserves alpha.
    rgba = image.convert('RGBA')
    rgb = rgba.convert('RGB')
    try:
        rgb.thumbnail((128, 128))
        mean = ImageStat.Stat(rgb).mean
        r, g, b = [max(0, min(255, int(round(v)))) for v in mean[:3]]
        hue, lum, sat = colorsys.rgb_to_hls(r / 255.0, g / 255.0, b / 255.0)
        # Preserve the source hue and make it clearly visible, while keeping the
        # final wash darker than the artwork. This same colour is the base under
        # fanart, fallback art and PVR picons.
        sat = max(0.22, min(0.58, sat * 0.92 + 0.10))
        lum = max(0.17, min(0.32, lum * 0.58))
        r_f, g_f, b_f = colorsys.hls_to_rgb(hue, lum, sat)
        return '%02X%02X%02X%02X' % (
            _WASH_ALPHA,
            int(round(r_f * 255)),
            int(round(g_f * 255)),
            int(round(b_f * 255)),
        )
    finally:
        try:
            rgb.close()
        except Exception:
            pass
        try:
            rgba.close()
        except Exception:
            pass



def _open_fast_source(source):
    """Open only sources that are already local; never perform a network/copy wait."""
    for cached in _cached_candidates(source):
        if not _exists(cached):
            continue
        try:
            return _image_open(cached)
        except Exception:
            pass
    local = _local_image(source)
    if local is not None:
        return local
    try:
        skin_path = (source if source.startswith('special://skin')
                     else _skin_media_path(source))
        if skin_path and xbmc.skinHasImage(source):
            return _image_open(skin_path)
    except Exception:
        pass
    translated = _translate(source)
    try:
        if translated and os.path.isfile(translated):
            return _image_open(source)
    except Exception:
        pass
    # special:// and other VFS-local files can be opened directly when they exist.
    try:
        if source.startswith('special://') and _exists(source):
            return _image_open(source)
    except Exception:
        pass
    return None


def _generate_fast_local(source, identity):
    image = None
    try:
        image = _open_fast_source(source)
        if image is None:
            return ''
        color = _muted_average_color(image)
        if color:
            _ensure_cache()
            _write_text(_destination(identity), color)
        return color
    except Exception as exc:
        _log('fast colour extraction skipped for %s: %s' % (source, exc), xbmc.LOGDEBUG)
        return ''
    finally:
        try:
            if image is not None:
                image.close()
        except Exception:
            pass

def _generate(source, identity):
    if not source:
        return ''
    _ensure_cache()
    destination = _destination(identity)
    cached = _read_text(destination)
    if cached:
        return cached
    temp_path = _CACHE_URI + 'temp_%s.img' % _md5(identity)
    image = None
    copied_temp = ''
    try:
        if identity.startswith('tvlogo|'):
            from .poster_background import tvlink_logo_file
            source = tvlink_logo_file(source) or source
        image, copied_temp = _open_source(source, temp_path)
        if image is None:
            return ''
        color = _muted_average_color(image)
        if color:
            _write_text(destination, color)
            _prune_cache()
        return color
    except Exception as exc:
        _log('colour extraction failed for %s: %s' % (source, exc), xbmc.LOGWARNING)
        return ''
    finally:
        try:
            if image is not None:
                image.close()
        except Exception:
            pass
        try:
            if copied_temp and xbmcvfs and xbmcvfs.exists(copied_temp):
                xbmcvfs.delete(copied_temp)
        except Exception:
            pass


def _bounded_store(store, key, value, limit):
    store.pop(key, None)
    store[key] = value
    while len(store) > limit:
        store.popitem(last=False)


def _remember_identity(source, identity):
    _IDENTITIES.pop(source, None)
    _IDENTITIES[source] = identity
    if len(_IDENTITIES) <= _MAX_MEMORY_IDENTITIES:
        return
    for key in list(_IDENTITIES.keys()):
        if len(_IDENTITIES) <= _MAX_MEMORY_IDENTITIES:
            break
        if key in _PENDING:
            continue
        _IDENTITIES.pop(key, None)


def _worker_loop():
    while True:
        source, identity = _QUEUE.get()
        try:
            with _LOCK:
                current = _IDENTITIES.get(source)
            if current != identity:
                continue
            result = _generate(source, identity)
            with _LOCK:
                if _IDENTITIES.get(source) != identity:
                    continue
                if result:
                    _bounded_store(_RESULTS, source, (identity, result), _MAX_MEMORY_RESULTS)
                    _FAILURES.pop(source, None)
                else:
                    _bounded_store(_FAILURES, source, (identity, time.time()), _MAX_MEMORY_FAILURES)
                _PENDING.discard(source)
        except Exception as exc:
            with _LOCK:
                if _IDENTITIES.get(source) == identity:
                    _bounded_store(_FAILURES, source, (identity, time.time()), _MAX_MEMORY_FAILURES)
                    _PENDING.discard(source)
            _log('worker error: %s' % exc, xbmc.LOGWARNING)
        finally:
            _QUEUE.task_done()


def _ensure_worker():
    global _WORKER
    with _LOCK:
        if _WORKER is not None and _WORKER.is_alive():
            return
        _WORKER = threading.Thread(target=_worker_loop, name='SublimeBackgroundWash')
        _WORKER.daemon = True
        _WORKER.start()


def _enqueue_latest(source, identity):
    task = (source, identity)
    while True:
        try:
            _QUEUE.put_nowait(task)
            return
        except queue.Full:
            try:
                old_source, old_identity = _QUEUE.get_nowait()
                with _LOCK:
                    if _IDENTITIES.get(old_source) == old_identity:
                        _PENDING.discard(old_source)
                _QUEUE.task_done()
            except queue.Empty:
                return


def prepare_wash_color_now(source):
    """Extract and cache one wash colour on the CALLER's thread.

    request_wash_color() keeps a latest-wins slot so a fast scroll does not
    process every row it crosses; a warm-up calling it would throw away the job
    for the row the user is looking at. This entry point does the work where it
    is called - which for warming is a background thread that exists to be
    early - and shares the same cache, so the focused row later finds the colour
    already there instead of waiting for extraction.
    """
    source = _normalize_source(source)
    if not source:
        return ''
    identity = _source_identity(source)
    cached_disk = _read_text(_destination(identity))
    if cached_disk:
        with _LOCK:
            _remember_identity(source, identity)
            _bounded_store(_RESULTS, source, (identity, cached_disk), _MAX_MEMORY_RESULTS)
        return cached_disk
    color = _generate(source, identity)
    if color:
        with _LOCK:
            _remember_identity(source, identity)
            _bounded_store(_RESULTS, source, (identity, color), _MAX_MEMORY_RESULTS)
            _FAILURES.pop(source, None)
    return color


def request_wash_color(source):
    """Return a cached ARGB wash colour or queue extraction without blocking."""
    source = _normalize_source(source)
    if not source:
        return ''
    identity = _source_identity(source)
    # память раньше базы: строка, уже показанная в этом процессе, не идёт в sqlite
    with _LOCK:
        cached = _RESULTS.get(source)
        if cached and cached[0] == identity:
            _RESULTS.move_to_end(source)
            return cached[1]
    destination = _destination(identity)
    cached_disk = _read_text(destination)
    if cached_disk:
        with _LOCK:
            _remember_identity(source, identity)
            _bounded_store(_RESULTS, source, (identity, cached_disk), _MAX_MEMORY_RESULTS)
            _FAILURES.pop(source, None)
        return cached_disk
    now = time.time()
    with _LOCK:
        previous_identity = _IDENTITIES.get(source)
        _remember_identity(source, identity)
        cached = _RESULTS.get(source)
        if cached and cached[0] == identity:
            _RESULTS.move_to_end(source)
            return cached[1]
        failed = _FAILURES.get(source)
        if failed and failed[0] == identity and now - failed[1] < _FAILURE_RETRY_SECONDS:
            return ''

    # PVR picons, local posters and Kodi thumbnail-cache files are tiny/local.
    # Resolve them in this call so the wash follows focus without a visible delay.
    fast_color = _generate_fast_local(source, identity)
    if fast_color:
        with _LOCK:
            if _IDENTITIES.get(source) == identity:
                _bounded_store(_RESULTS, source, (identity, fast_color), _MAX_MEMORY_RESULTS)
                _FAILURES.pop(source, None)
                _PENDING.discard(source)
        return fast_color

    with _LOCK:
        if source in _PENDING:
            if previous_identity == identity:
                return ''
            _PENDING.discard(source)
        _PENDING.add(source)
    _ensure_worker()
    _enqueue_latest(source, identity)
    return ''
