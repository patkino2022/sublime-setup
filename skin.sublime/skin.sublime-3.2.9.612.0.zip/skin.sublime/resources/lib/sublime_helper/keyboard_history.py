# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Atomic, merge-safe keyboard history shared by skin script and plugin processes."""

import json
import os
import tempfile
import time

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

DEFAULT_PATH = 'special://profile/addon_data/skin.sublime/keyboard_history.json'


def translate_path(path):
    try:
        return xbmcvfs.translatePath(path) if xbmcvfs else path
    except Exception:
        return path


def _normalise(items, limit):
    output = []
    seen = set()
    for item in items if isinstance(items, list) else []:
        item = str(item or '').strip()
        key = item.casefold()
        if item and key not in seen:
            output.append(item)
            seen.add(key)
        if len(output) >= limit:
            break
    return output


def load_history(path=DEFAULT_PATH, limit=10):
    path = translate_path(path)
    try:
        if not path or not os.path.isfile(path):
            return []
        with open(path, 'r', encoding='utf-8') as fh:
            return _normalise(json.load(fh), limit)
    except Exception:
        return []


def _acquire_lock(lock_dir, timeout=2.0, stale_after=15.0):
    deadline = time.monotonic() + max(0.1, float(timeout))
    while True:
        try:
            os.mkdir(lock_dir)
            return True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock_dir) > stale_after:
                    os.rmdir(lock_dir)
                    continue
            except OSError:
                pass
        except OSError:
            return False
        if time.monotonic() >= deadline:
            return False
        time.sleep(0.02)


def _release_lock(lock_dir):
    try:
        os.rmdir(lock_dir)
    except OSError:
        pass


def _atomic_write(path, items):
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=os.path.basename(path) + '.', suffix='.tmp', dir=folder or None)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            json.dump(items, fh, ensure_ascii=False, indent=2)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        os.replace(tmp, path)
        tmp = ''
        return True
    finally:
        if tmp:
            try:
                os.remove(tmp)
            except OSError:
                pass


def push_history(text, path=DEFAULT_PATH, limit=10):
    text = str(text or '').strip()
    if not text:
        return load_history(path, limit)
    path = translate_path(path)
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    lock_dir = path + '.lock'
    if not _acquire_lock(lock_dir):
        return load_history(path, limit)
    try:
        items = load_history(path, limit)
        key = text.casefold()
        items = [item for item in items if item.casefold() != key]
        items.insert(0, text)
        items = _normalise(items, limit)
        _atomic_write(path, items)
        return items
    finally:
        _release_lock(lock_dir)
