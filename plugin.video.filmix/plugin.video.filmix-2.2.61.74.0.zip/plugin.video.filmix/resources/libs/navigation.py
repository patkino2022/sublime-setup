# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import calendar
import json
import re
import sys
import time

import simplemedia
import simpleplugin
import xbmc
import xbmcgui
import xbmcplugin
from future.utils import iteritems
from simplemedia import py2_decode

from .filters import Filters
from .listitems import ItemInfo, PostInfo, SeasonInfo, VideoInfo, EmptyListItem, ListItem, MainMenuItem, _looks_ukrainian_text, _clean_text, _select_plot
from .utilities import Utilities
from .utilities import plugin, _
from .utilities import filmix_save_resume_url_map
from .utilities import _filmix_lookup_resume_for_url
from .utilities import _skin_row_store


def _with_skin_identity(payload, post_id, tmdb_type):
    """Номер TMDb, уже опознанный скином для этого поста (row_store.identity_for_post), - в запрос
    опознания, если своего номера нет. Тогда TMDbResolver не ищет по названию, а только догружает и
    проверяет карточку по номеру: один фильм - один номер в скине и в Filmix, и запросом меньше.
    Своего поиска это не отменяет - он остаётся для постов, которых скин ещё не видел (23.11.2026)."""
    if not isinstance(payload, dict) or not post_id or TMDbResolver._extract_tmdb(payload):
        return payload
    try:
        store = _skin_row_store()
        if store is None or not hasattr(store, 'identity_for_post'):
            return payload
        tmdb_id, kind = store.identity_for_post('plugin.video.filmix', post_id)
    except Exception:
        return payload
    if tmdb_id and (not kind or not tmdb_type or kind == tmdb_type):
        payload = dict(payload)
        payload['resolved_tmdb_id'] = tmdb_id
        xbmc.log('[plugin.video.filmix] TMDb: номер скина post_id={0} tmdb={1}'.format(post_id, tmdb_id), xbmc.LOGINFO)
    return payload


def _resolve_with_skin(resolver, payload, post_id, tmdb_type):
    """Опознание с номером скина; номер не прошёл проверку Filmix - прежний поиск по названию."""
    tried = _with_skin_identity(payload, post_id, tmdb_type)
    result = resolver.resolve(tried, forced_type=tmdb_type)
    if tried is not payload and isinstance(result, dict) and not result.get('resolved_tmdb_id'):
        xbmc.log('[plugin.video.filmix] TMDb: номер скина не подошёл post_id={0} - свой поиск'.format(post_id),
                 xbmc.LOGINFO)
        result = resolver.resolve(payload, forced_type=tmdb_type)
    return result
from .cache import FilmixCache
from .tmdbresolver import TMDbResolver, _country_text_to_isos
from .web import (Filmix, FilmixError)
from .textutils import (
    normalize_filter_label as _normalize_filter_label,
    is_blocked_custom_filter_label as _is_blocked_custom_filter_label,
    find_filter_ids as _find_filter_ids,
)
from . import kodi_link
from . import watch_stats
from .prewarm import FilmixPrewarm
from .manual_overrides import apply_manual_override


class FilmixCatalogs(object):
    CONTEXT_MENU_COLOR = 'FF5E93B3'
    # Opening a show and then its season directory should not perform two API
    # calls seconds apart, but old playlists must never live forever.
    INTERACTIVE_PLAYER_TTL = 120
    # До стольких секунд плейлисту доверяем, если страница каталога не знает
    # серии новее (FilmixPrewarm._listing_ahead_of_playlist). Сериалы виджетов
    # главной служба держит свежими сама (FilmixPrewarm.warm_home_series), и
    # повторный запрос к сайту при каждом открытии стоил 0.36 с из 1.41 с
    # (замер на .30 17.10.2026, «Король Талсы»), а нового не приносил.
    TRUSTED_PLAYER_TTL = 1800
    LISTING_SECTIONS = ('serials', 'multserials', 'favorites', 'deferred')

    @classmethod
    def _cm_label(cls, text):
        # do not hardcode Filmix blue in Kodi context menus.
        # Let the active skin highlight/focus color style the row.
        # prefix every Filmix context-menu action with the
        # add-on's name. A list row can carry actions from more than one
        # add-on at once (Filmix's own + skin/ai.recommend actions, which
        # already prefix their own as "AI: ..."), and an unlabelled "Add to
        # Favorites"/"Change translation" gave no way to tell which add-on a
        # given entry would actually act on.
        text = str(text or '')
        return 'Filmix: {0}'.format(text) if text else text

    # Экранки (запись с экрана кинотеатра или до релиза): владелец 20.10.2026 -
    # «никаких экранок». Тип релиза - первое слово в quality строки каталога
    # и поиска («TS 1080», «CAM 480», «DVDScr 480»). Rip деталей поста не
    # смотрим: он застревает на первой экранке, когда фильм уже вышел в WEB-DL.
    _SCREENER_RIPS = frozenset(['cam', 'ts', 'tc', 'telesync', 'telecine', 'scr', 'screener',
                                'dvdscr', 'bdscr', 'webscr', 'dvdscreener'])

    @classmethod
    def _is_screener(cls, item):
        for key in ('rip', 'quality'):
            words = str(item.get(key) or '').split()
            if not words:
                continue
            kind = re.sub(r'[^a-z0-9]', '', words[0].lower())
            if kind.endswith('rip'):
                kind = kind[:-3]
            if kind.startswith('hd'):
                kind = kind[2:]
            if kind in cls._SCREENER_RIPS:
                return True
        return False

    @staticmethod
    def _is_trailer_only(item):
        """Пост, у которого на Filmix только трейлер: ссылки поста - только на трейлер. Включить
        его нельзя - в списках его нет (владелец 24.11.2026: «если нельзя воспроизвести - вообще не
        надо показывать»). Категория «Трейлеры» признаком не служит: она остаётся и у вышедших
        фильмов («Вествуд», «На цепи»)."""
        links = item.get('player_links')
        if isinstance(links, dict) and links.get('trailer') and not links.get('movie') and not links.get('playlist'):
            return True
        return False

    @classmethod
    def _drop_screeners(cls, items, route=''):
        kept = []
        dropped = []
        # строки списка сайта ссылок не несут - по кэшу постов: у кого там только трейлер
        try:
            unplayable = FilmixCache(plugin.profile_dir).trailer_only_ids(
                [i.get('id') for i in items or [] if isinstance(i, dict)])
        except Exception:
            unplayable = set()
        for item in items or []:
            if isinstance(item, dict) and (cls._is_trailer_only(item)
                                           or FilmixCache._norm(item.get('id')) in unplayable):
                dropped.append('{0}[трейлер]'.format(item.get('title') or item.get('id')))
            elif isinstance(item, dict) and cls._is_screener(item):
                dropped.append('{0}[{1}]'.format(item.get('title') or item.get('id'), item.get('rip') or item.get('quality')))
            else:
                kept.append(item)
        if dropped:
            try:
                xbmc.log('[plugin.video.filmix] ScreenerFilter: route={0} dropped={1} {2}'.format(route, len(dropped), ', '.join(dropped)), xbmc.LOGINFO)
            except Exception:
                pass
        return kept

    @staticmethod
    def _detect_container_content(items, fallback='videos'):
        has_movies = False
        has_tvshows = False
        for item in items or []:
            if not isinstance(item, dict):
                continue
            try:
                is_movie = Utilities.is_movie(item)
            except Exception:
                continue
            if is_movie:
                has_movies = True
            else:
                has_tvshows = True
            if has_movies and has_tvshows:
                return 'videos'
        if has_tvshows and not has_movies:
            return 'tvshows'
        if has_movies and not has_tvshows:
            return 'movies'
        return fallback

    # Окна, в которых список строится для виджета главной, а не открыт человеком:
    # сама главная (10000) и оба диапазона окон-концентраторов скина.
    WIDGET_WINDOW_RANGES = ((10000, 10000), (1100, 1199), (11100, 11199))

    @classmethod
    def _is_home_widget_listing_context(cls):
        """Список строится для виджета главной, а не открыт человеком.

        Нужно ровно для одного: в виджете не показывать «Страница N». Раньше это
        решал реестр окон, который вёл сам провайдер; реестр удалён вместе с
        остальной машинерией виджетов, и вопрос свёлся к номеру текущего окна.

        Возвращает False при любой неожиданности: показать лишнюю строку не
        страшно, уронить построение списка - страшно.
        """
        try:
            window_id = int(xbmcgui.getCurrentWindowId())
        except Exception:
            return False
        for low, high in cls.WIDGET_WINDOW_RANGES:
            if low <= window_id <= high:
                return True
        return False


    @staticmethod
    def _normalize_int_string(value, default=''):
        if value in [None, '', 'None']:
            return default
        try:
            return str(int(value))
        except Exception:
            return str(value)

    @classmethod
    def _iter_canonical_episode_keys(cls, item, season_filter=None):
        player_links = cls._get_player_links(item)
        season_filter = None if season_filter in [None, ''] else str(season_filter)
        result = []

        if isinstance(player_links, dict):
            for season_key, season_translations in iteritems(player_links):
                season_key = str(season_key)
                if season_filter is not None and season_key != season_filter:
                    continue
                episode_keys = set()
                for translation_name, episodes in iteritems(season_translations or {}):
                    if isinstance(episodes, list):
                        for index in range(len(episodes)):
                            episode_keys.add(str(index))
                    elif isinstance(episodes, dict):
                        for episode_key in episodes.keys():
                            episode_keys.add(str(episode_key))
                for episode_key in sorted(episode_keys, key=lambda x: int(x) if str(x).isdigit() else str(x)):
                    result.append((season_key, episode_key))
        else:
            episode_keys = set()
            for season_translations in player_links or []:
                for translation_name, episodes in iteritems(season_translations or {}):
                    if isinstance(episodes, list):
                        for index in range(len(episodes)):
                            episode_keys.add(str(index))
                    elif isinstance(episodes, dict):
                        for episode_key in episodes.keys():
                            episode_keys.add(str(episode_key))
            base_season = season_filter if season_filter is not None else '-1'
            for episode_key in sorted(episode_keys, key=lambda x: int(x) if str(x).isdigit() else str(x)):
                result.append((str(base_season), episode_key))

        return result

    @classmethod
    def _season_episode_keys(cls, item, season_filter=None):
        keys = set()
        for season_key, episode_key in cls._iter_canonical_episode_keys(item, season_filter=season_filter):
            if season_filter in [None, ''] or str(season_key) == str(season_filter):
                keys.add(cls._normalize_int_string(episode_key))
        return keys

    @classmethod
    def _season_uses_zero_based_episodes(cls, item, season_filter=None):
        keys = cls._season_episode_keys(item, season_filter=season_filter)
        if not keys:
            return False
        numeric = []
        for key in keys:
            try:
                numeric.append(int(key))
            except Exception:
                pass
        if not numeric:
            return False
        # Filmix playlist lists are often zero-based internally (0,1,2...),
        # while every consumer counts from one. Detect by the real playlist keys,
        # not by display numbering, so we do not touch episode labels or playback URLs.
        return 0 in numeric

    @classmethod
    def _canonical_episode_number(cls, item, season, episode):
        episode_norm = cls._normalize_int_string(episode)
        if episode_norm == '':
            return episode_norm
        try:
            episode_int = int(episode_norm)
        except Exception:
            return episode_norm
        if cls._season_uses_zero_based_episodes(item, season_filter=season):
            return str(episode_int + 1)
        return str(episode_int)


    @classmethod
    def _watched_state_from_map(cls, watched_map, post_id, season=None, episode=None):
        if watched_map is None:
            return None
        key = (FilmixCache._norm(post_id), FilmixCache._norm(season), FilmixCache._norm(episode))
        return watched_map.get(key) or {}

    @classmethod
    def _watched_summary_from_map(cls, watched_map, post_id, season=None):
        if watched_map is None:
            return None
        try:
            summary = watched_map.get('__filmix_summary_v1') or {}
            key = (FilmixCache._norm(post_id), FilmixCache._norm(season))
            return summary.get(key) or None
        except Exception:
            return None

    # Сериалы, у которых отметку на самом сериале уже сняли в этом процессе:
    # один раз на пост, чтобы список не писал в базу Kodi на каждой отрисовке.
    _dropped_show_marks = set()

    @classmethod
    def _drop_stale_show_mark(cls, cache, post_id):
        """Снять отметку «просмотрен», стоящую в базе Kodi на самом сериале.

        «Всегда солнечно в Филадельфии»: в избранном честно оставалась серия, а
        в полосе хаба сериал стоял просмотренным. Отметка была не на серии, а на
        сериале - Kodi держит её для пути `/serials/<id>-<...>/open/`, - и её
        видит всё, что читает состояние из Kodi: полосы хаба, наша корневая
        строка, контекстное меню. Пишет такие пути только старая схема пометки;
        нынешняя помечает пути серий по одному. Поэтому, когда счёт серий -
        тот же, по которому строится сам список, - говорит, что смотреть ещё
        есть что, отметке на сериале верить нельзя, и она снимается.

        Зовётся только из ветки со списком серий, где счёт настоящий, и только
        один раз на пост за процесс.
        """
        key = str(post_id or '')
        if not key or key in cls._dropped_show_marks:
            return 0
        cls._dropped_show_marks.add(key)
        try:
            paths = kodi_link.show_level_marks().get(key) or []
            if not paths:
                return 0
            done = kodi_link.set_watched(paths, False)
            try:
                cache.set_watched_state(key, False, playcount=0)
            except Exception:
                pass
            xbmc.log('[plugin.video.filmix] снята отметка с самого сериала '
                     'post_id={0}: путей {1}'.format(key, done), xbmc.LOGINFO)
            return done
        except Exception as exc:
            xbmc.log('[plugin.video.filmix] отметку с сериала post_id={0} снять '
                     'не удалось: {1}'.format(key, exc), xbmc.LOGWARNING)
            return 0

    @staticmethod
    def _state_is_watched(state):
        try:
            return bool(state and int(state.get('watched') or 0) > 0)
        except Exception:
            return bool(state and state.get('watched'))

    @classmethod
    def _get_episode_stats(cls, cache, post_id, season, episode, watched_map=None):
        if watched_map is not None:
            state = cls._watched_state_from_map(watched_map, post_id, season=season, episode=episode) or {}
            watched = cls._state_is_watched(state)
        else:
            watched = cache.is_watched(post_id, season=season, episode=episode)
            state = cache.get_watched_state(post_id, season=season, episode=episode) or {}
        return {
            'total': 1,
            'watched': 1 if watched else 0,
            'unwatched': 0 if watched else 1,
            'playcount': int(state.get('playcount') or 0)
        }

    @staticmethod
    def _sync_with_kodi(cache):
        try:
            kodi_link.sync_before_listing(cache)
        except Exception as exc:
            xbmc.log('[plugin.video.filmix] сверка с Kodi перед списком не прошла: {0}'.format(exc),
                     xbmc.LOGWARNING)

    @staticmethod
    def _stats_map(cache, item, watched_map):
        """Снимок watched_state для счёта: готовый списка или один запрос на пост."""
        if watched_map is not None:
            return watched_map
        try:
            return cache.get_watched_states_many([item.get('id')])
        except Exception:
            return {}

    # Счёт серий и отметка «сериал просмотрен» - в watch_stats.py, общем со
    # скином: полосы хаба зовут тот же код, что и эти списки.
    @classmethod
    def _get_season_stats(cls, cache, item, season, watched_map=None):
        return watch_stats.stats(item, cls._stats_map(cache, item, watched_map), season)

    @classmethod
    def _get_show_stats(cls, cache, item, watched_map=None):
        return watch_stats.stats(item, cls._stats_map(cache, item, watched_map))


    @classmethod
    def _apply_local_state(cls, listitem, item_info, source_item, cache, fast=False, watched_map=None):
        # Отметки - по кэшу, сверенному с Kodi до первой строки (один раз на
        # маршрут, см. kodi_link.sync_before_listing).
        cls._sync_with_kodi(cache)
        properties = {}
        mediatype = item_info.mediatype
        post_id = item_info.post_id
        if mediatype == 'movie':
            watched_state = (cls._watched_state_from_map(watched_map, post_id) if watched_map is not None else cache.get_watched_state(post_id)) or {}
            playcount = int(watched_state.get('playcount') or 0)
            item_info.item_info['local_playcount'] = playcount
            properties['playcount'] = playcount
        elif mediatype == 'episode':
            season = item_info.get_season()
            episode = item_info.get_episode()
            stats = cls._get_episode_stats(cache, post_id, season, episode, watched_map=watched_map)
            item_info.item_info['local_playcount'] = stats['playcount']
            properties['playcount'] = stats['playcount']
        elif mediatype == 'season':
            stats = cls._get_season_stats(cache, source_item, item_info.get_season(), watched_map=watched_map)
            if cls._series_started(post_id, stats):
                properties['SeriesStarted'] = 'true'
            properties.update(watch_stats.count_properties(stats))
            playcount = 1 if stats['total'] and stats['unwatched'] == 0 else 0
            item_info.item_info['local_playcount'] = playcount
            properties['playcount'] = playcount
        elif mediatype == 'tvshow':
            state = watch_stats.show_state(source_item, cls._stats_map(cache, source_item, watched_map))
            if state['counted']:
                if cls._series_started(post_id, state):
                    properties['SeriesStarted'] = 'true'
                properties.update(state['properties'])
                if state['total'] and state['unwatched']:
                    cls._drop_stale_show_mark(cache, post_id)
            # playcount задаётся всегда, 0 тоже: не заданный Kodi берёт из
            # своей записи по пути, а там у сериала бывает старая корневая
            # отметка («В Филадельфии всегда солнечно», 04.09.2026).
            item_info.item_info['local_playcount'] = state['playcount']
            properties['playcount'] = state['playcount']

        listitem.set_properties(properties)

    @staticmethod
    def _series_started(post_id, stats):
        """Начат ли сериал: хоть одна серия просмотрена или начата.

        Владелец 16.10.2026: «если сериал не начинали смотреть (хотя бы одну
        серию) - число серий не надо показывать». Скин рисует счётчик по этому
        свойству; начатую, но не досмотренную серию видно только по точке
        продолжения в базе Kodi, поэтому смотрим ещё и её (тот же общий снимок
        закладок, что даёт маркеры прогресса строкам).
        """
        if int((stats or {}).get('watched') or 0) > 0:
            return True
        try:
            from .utilities import _filmix_load_resume_index_snapshot
            index = _filmix_load_resume_index_snapshot(max_age=180) or {}
            # Начатая серия лежит в снимке под ключом filmix-post:<id>:s:..:e:..
            prefix = 'filmix-post:{0}:'.format(post_id)
            return any(str(key).startswith(prefix) for key in index)
        except Exception:
            return False

    @classmethod
    def _append_watch_context_menu(cls, context_menu, item_info, source_item, cache, watched_map=None):
        cls._sync_with_kodi(cache)
        mediatype = item_info.mediatype
        post_id = item_info.post_id
        state = {'watched': False, 'partial': False}

        if mediatype == 'movie':
            state['watched'] = cls._state_is_watched(cls._watched_state_from_map(watched_map, post_id)) if watched_map is not None else cache.is_watched(post_id)
        elif mediatype == 'episode':
            if watched_map is not None:
                state['watched'] = cls._state_is_watched(cls._watched_state_from_map(watched_map, post_id, season=item_info.get_season(), episode=item_info.get_episode()))
            else:
                state['watched'] = cache.is_watched(post_id, season=item_info.get_season(), episode=item_info.get_episode())
        elif mediatype == 'season' and source_item.get('player_links') is not None:
            stats = cls._get_season_stats(cache, source_item, item_info.get_season(), watched_map=watched_map)
            state['watched'] = bool(stats['total'] and stats['unwatched'] == 0)
            state['partial'] = bool(stats['watched'] and stats['unwatched'])
        elif mediatype == 'tvshow' and source_item.get('player_links') is not None:
            stats = cls._get_show_stats(cache, source_item, watched_map=watched_map)
            state['watched'] = bool(stats['total'] and stats['unwatched'] == 0)
            state['partial'] = bool(stats['watched'] and stats['unwatched'])
        elif mediatype == 'tvshow':
            root_state = (cls._watched_state_from_map(watched_map, post_id) if watched_map is not None else cache.get_watched_state(post_id)) or {}
            state['watched'] = bool(int(root_state.get('playcount') or 0) > 0 or root_state.get('watched'))
        elif mediatype == 'season':
            root_state = (cls._watched_state_from_map(watched_map, post_id, season=item_info.get_season()) if watched_map is not None else cache.get_watched_state(post_id, season=item_info.get_season())) or {}
            state['watched'] = bool(int(root_state.get('playcount') or 0) > 0 or root_state.get('watched'))

        url_params = {'id': post_id, 'm': mediatype}
        if mediatype in ['season', 'episode']:
            url_params['s'] = item_info.get_season()
        if mediatype == 'episode':
            url_params['e'] = item_info.get_episode()

        mark_watched_url = plugin.url_for('mark_watched', **url_params)
        mark_unwatched_url = plugin.url_for('mark_unwatched', **url_params)

        # One wording everywhere. The owner asked for exactly this: the same
        # two entries in every section, doing the same thing. Which rows the
        # action covers is already decided by the row the user opened the menu
        # on, so saying "season" or "TV show" in the label only made the menu
        # look like three different features.
        watched_label = 'Отметить просмотренным'
        unwatched_label = 'Снять отметку просмотра'

        # Always both, always in this order. Showing only the opposite toggle
        # depended on the list's own idea of the state being right, and a just
        # refreshed list could offer the wrong one - with two entries there is
        # nothing to get wrong, and the menu is identical in every section.
        context_menu.append((watched_label, 'RunPlugin({0})'.format(mark_watched_url)))
        context_menu.append((unwatched_label, 'RunPlugin({0})'.format(mark_unwatched_url)))

    @classmethod
    def _append_translation_context_menu(cls, context_menu, item, item_info=None):
        try:
            if not isinstance(item, dict):
                return
            mediatype = getattr(item_info, 'mediatype', None) if item_info is not None else None
            if mediatype not in ['tvshow', 'season', 'episode']:
                return
            translations = Utilities.get_tvshow_translations(cls._get_player_links(item)) or {}
            if len(translations) <= 1:
                return
            # 09.09.2026: пункт убран - выбор озвучки переехал в кнопку на
            # экране (скин рисует её по свойствам FilmixTranslations/
            # FilmixPostID). Маршрут select_translation остался тот же, зовёт
            # его теперь кнопка.
            return
        except Exception:
            pass

    # Полная страница каталога Filmix: в кэше movies|1| и serials|1| по 50.
    _USER_LIST_PAGE = 50
    _user_lists = {}
    # маршрут - пользовательский поиск (см. search): описания найденного мимо общей очереди
    _user_search = [False]
    # описания, догруженные для строк списка: пишутся в кэш после endOfDirectory
    _deferred_posts = []

    @classmethod
    def flush_deferred_posts(cls):
        pending, cls._deferred_posts[:] = list(cls._deferred_posts), []
        if not pending:
            return 0
        cache = FilmixCache(plugin.profile_dir)
        for post_id, info in pending:
            try:
                cache.set_post_details(post_id, info, player_fresh=False, preserve_richer_player=True)
            except Exception as e:
                xbmc.log('[plugin.video.filmix] deferred post write failed post_id={0} err={1}'.format(post_id, e),
                         xbmc.LOGWARNING)
        return len(pending)

    @classmethod
    def _user_list_ids(cls, cache, section):
        """Ид поста в закэшированном списке пользователя («favorites»,
        «deferred») или None, если в кэше не весь список.

        Отметки favorited/watch_later в описании поста - снимок на момент, когда
        описание скачивали, и дальше они не меняются. 06.11.2026 на .20
        «Книготорговцы» с 01.11 лежали в избранном, а описание от 30.10 говорило
        «не в избранном»: меню всё время предлагало «Добавить», а сайт Filmix на
        этот вызов не добавляет, а переключает (api/v2/toggle_fav) - и фильм из
        избранного убрался. Сами списки перечитываются после каждого
        переключения и прогревом, поэтому ответ берётся из них.
        """
        if section in cls._user_lists:
            return cls._user_lists[section]
        ids, complete = set(), False
        try:
            for page in range(1, 41):
                cached = cache.get_any_catalog_cache(section, str(page), '')
                if not cached:
                    break
                items = cached.get('items') or []
                ids.update(str(i.get('id')) for i in items
                           if isinstance(i, dict) and i.get('id') is not None)
                if len(items) < cls._USER_LIST_PAGE:
                    complete = True
                    break
        except Exception:
            complete = False
        cls._user_lists[section] = ids if complete else None
        return cls._user_lists[section]

    @classmethod
    def _user_list_state(cls, cache, item, flag, section):
        """В списке ли пост: по самому списку, если он в кэше целиком, иначе по
        отметке в описании. None - отметки нет вовсе (меню не показывать)."""
        value = item.get(flag)
        if value is None:
            return None
        ids = cls._user_list_ids(cache, section)
        if ids is None:
            return bool(value)
        return str(item.get('id')) in ids

    @staticmethod
    def _is_series_item(item, item_info=None):
        """Сериал или мультсериал (разделы 7 и 93), а не фильм."""
        section = str((item or {}).get('section') if (item or {}).get('section') is not None else '')
        if section:
            return section in ('7', '93')
        mediatype = getattr(item_info, 'mediatype', '') if item_info is not None else ''
        return mediatype in ('tvshow', 'season', 'episode')

    @classmethod
    def _get_context_menu(cls, item, item_info=None, cache=None, watched_map=None):
        context_menu = []

        if plugin.get_setting('user_login'):
            cache = cache or FilmixCache(plugin.profile_dir)
            # Владелец 06.11.2026: у сериалов только «В избранное» / «Из
            # избранного», у фильмов только «Смотреть позже» / «Не смотреть
            # позже» (подписи - в strings.po, #30050-30053).
            series = cls._is_series_item(item, item_info)
            favorited = cls._user_list_state(cache, item, 'favorited', 'favorites')
            if favorited is not None and series:
                url = plugin.url_for('toogle_favorites', id=item['id'], value=(0 if favorited else 1))
                if favorited:
                    context_menu.append((cls._cm_label(_('Remove from Favorites')), 'RunPlugin({0})'.format(url)))
                else:
                    context_menu.append((cls._cm_label(_('Add to Favorites')), 'RunPlugin({0})'.format(url)))

            watch_later = cls._user_list_state(cache, item, 'watch_later', 'deferred')
            if watch_later is not None and not series:
                url = plugin.url_for('toogle_watch_later', id=item['id'], value=(0 if watch_later else 1))
                if watch_later:
                    context_menu.append((cls._cm_label(_('Remove from Watch Later')), 'RunPlugin({0})'.format(url)))
                else:
                    context_menu.append((cls._cm_label(_('Add to Watch Later')), 'RunPlugin({0})'.format(url)))

        if item_info is not None:
            cache = cache or FilmixCache(plugin.profile_dir)
            cls._append_translation_context_menu(context_menu, item, item_info=item_info)
            cls._append_watch_context_menu(context_menu, item_info, item, cache, watched_map=watched_map)

        return context_menu

    CUSTOM_COUNTRIES = [
        {'label': 'Россия', 'countries': ['русские', 'россия', 'ссср', 'ссср/россия', 'ussr', 'soviet', 'russia']},
    ]

    CUSTOM_GENRES = [
        {'label': 'Аниме', 'categories': ['аниме', 'anime']},
        {'label': 'Биография', 'categories': ['биография', 'biography']},
        {'label': 'Боевики', 'categories': ['боевик', 'боевики', 'action']},
        {'label': 'Вестерн', 'categories': ['вестерн', 'western']},
        {'label': 'Военный', 'categories': ['военный', 'war']},
        {'label': 'Детектив', 'categories': ['детектив', 'криминал', 'detective', 'crime']},
        {'label': 'Детский', 'categories': ['детский', 'children', 'kids']},
        {'label': 'Для взрослых', 'categories': ['для взрослых', 'adult']},
        {'label': 'Документальные', 'categories': ['документальный', 'документальные', 'documentary']},
        {'label': 'Дорамы', 'categories': ['дорамы', 'дорама', 'drama asia', 'dorama']},
        {'label': 'Драмы', 'categories': ['драма', 'драмы', 'drama']},
        {'label': 'Исторический', 'categories': ['исторический', 'history', 'historical']},
        {'label': 'Комедия', 'categories': ['комедия', 'ситком', 'comedy', 'sitcom']},
        {'label': 'Мелодрама', 'categories': ['мелодрама', 'melodrama', 'romance']},
        {'label': 'Мистика', 'categories': ['мистика', 'mystic', 'mystery']},
        {'label': 'Музыка', 'categories': ['музыка', 'мюзикл', 'music', 'musical']},
        {'label': 'Приключения', 'categories': ['приключения', 'adventure']},
        {'label': 'Семейный', 'categories': ['семейный', 'family']},
        {'label': 'Спорт', 'categories': ['спорт', 'sport']},
        {'label': 'Триллеры', 'categories': ['триллер', 'триллеры', 'thriller']},
        {'label': 'Ужасы', 'categories': ['ужасы', 'horror']},
        {'label': 'Фантастика', 'categories': ['фантастика', 'sci-fi', 'science fiction']},
        {'label': 'Фэнтези', 'categories': ['фэнтези', 'fantasy']},
    ]

    @staticmethod
    def _normalize_filter_label(label):
        return _normalize_filter_label(label)

    @classmethod
    def _is_blocked_custom_filter_label(cls, label):
        return _is_blocked_custom_filter_label(label)

    @classmethod
    def _find_filter_ids(cls, values, aliases):
        return _find_filter_ids(values, aliases)

    @classmethod
    def _build_custom_genres(cls, section):
        categories_values = Filters._get_filter_values('categories')
        genre_items = []
        for entry in cls.CUSTOM_GENRES:
            filter_ids = []
            filter_ids.extend(cls._find_filter_ids(categories_values, entry.get('categories')))
            unique_ids = []
            for value in filter_ids:
                if value not in unique_ids:
                    unique_ids.append(value)
            if not unique_ids:
                continue
            genre_items.append({'label': entry['label'], 'filters': '-'.join(unique_ids), 'section': section})
        return genre_items

    @classmethod
    def _country_sort_key(cls, label):
        # 2.2.27 COUNTRY_ALPHA_ORDER:
        # Keep merged Россия/Сербия entries, but do not pin them above the rest.
        # Both movie and serial country directories must be pure alphabetical lists.
        text = cls._normalize_filter_label(label)
        return text.casefold() if hasattr(text, 'casefold') else text.lower()

    @classmethod
    def _build_custom_countries(cls, section):
        # 2.2.27 COUNTRY_ALPHA_ORDER:
        # The Countries directories still show ALL Filmix countries. Россия and
        # Сербия remain merged entries:
        #   Россия = Россия + СССР / Русские
        #   Сербия = Сербия + Югославия / Сербские
        # Their original single country rows are hidden to avoid duplicates, but
        # the final menu is sorted alphabetically instead of pinning them first.
        # Prewarm policy is separate: only Россия/Сербия result lists stay hot.
        countries_values = Filters._get_filter_values('countries')
        country_items = []
        consumed_ids = set()

        for entry in cls.CUSTOM_COUNTRIES:
            filter_ids = []
            filter_ids.extend(cls._find_filter_ids(countries_values, entry.get('countries')))
            unique_ids = []
            for value in filter_ids:
                if value not in unique_ids:
                    unique_ids.append(value)
            if not unique_ids:
                continue
            for value in unique_ids:
                consumed_ids.add(value)
            country_items.append({'label': entry['label'], 'filters': '-'.join(unique_ids), 'section': section})

        for item in countries_values or []:
            item_id = item.get('id')
            label = str(item.get('val') or '').strip()
            if not item_id or not label:
                continue
            if item_id in consumed_ids:
                continue
            country_items.append({'label': label, 'filters': item_id, 'section': section})

        return sorted(country_items, key=lambda row: cls._country_sort_key(row.get('label')))

    @classmethod
    def _availability_task(cls, section, filter_kind, entry):
        return {
            'section': section,
            'page': '1',
            'filters': entry.get('filters') or '',
            'kind': filter_kind,
            'label': entry.get('label') or '',
        }

    @classmethod
    def _read_availability_state(cls, cache, section, filters):
        try:
            row = cache.get_control_flag(FilmixPrewarm.filter_availability_flag_for(section, filters))
        except Exception:
            row = None
        value = (row or {}).get('flag_value') or ''
        if not value:
            return None, 0
        try:
            data = json.loads(value)
            if isinstance(data, dict):
                return data, int((row or {}).get('updated_ts') or 0)
        except Exception:
            pass
        return None, 0

    @classmethod
    def _write_availability_nonempty_from_cache(cls, cache, section, filter_kind, entry, count):
        try:
            payload = {
                'section': section,
                'filters': entry.get('filters') or '',
                'kind': filter_kind,
                'label': entry.get('label') or '',
                'status': 'nonempty',
                'item_count': int(count or 0),
                'empty_count': 0,
                'hide': False,
                'checked_ts': FilmixCache._ts(),
                'source': 'catalog_cache',
            }
            cache.set_control_flag(
                FilmixPrewarm.filter_availability_flag_for(section, entry.get('filters') or ''),
                json.dumps(payload, ensure_ascii=False, sort_keys=True))
        except Exception:
            pass

    @classmethod
    def _filter_visible_catalog_filters(cls, section, filter_kind, entries):
        # 2.2.31 FILTER_AVAILABILITY_SERVICE_TICK_FIX:
        # Hide only entries whose own first page is confirmed empty more than once.
        # Unknown/stale entries stay visible and are queued for a low-rate background
        # check.  A non-empty catalog cache immediately overrides a stale empty flag.
        if not entries:
            return []
        try:
            cache = FilmixCache(plugin.profile_dir)
        except Exception:
            return entries
        visible = []
        queue = []
        now = FilmixCache._ts()
        hidden = 0
        for entry in entries:
            filters = entry.get('filters') or ''
            if not filters:
                visible.append(entry)
                continue
            try:
                cached = cache.get_any_catalog_cache(section, '1', filters)
            except Exception:
                cached = None
            if cached is not None:
                try:
                    cached_count = len(cached.get('items') or [])
                except Exception:
                    cached_count = 0
                if cached_count > 0:
                    cls._write_availability_nonempty_from_cache(cache, section, filter_kind, entry, cached_count)
                    visible.append(entry)
                    try:
                        if FilmixPrewarm.is_catalog_stale(cached, section, filters):
                            queue.append(cls._availability_task(section, filter_kind, entry))
                    except Exception:
                        pass
                    continue

            state, updated_ts = cls._read_availability_state(cache, section, filters)
            hide = False
            stale = True
            if isinstance(state, dict):
                try:
                    stale = (now - int(updated_ts or state.get('checked_ts') or 0)) > int(FilmixPrewarm.FILTER_AVAIL_RECHECK_INTERVAL)
                except Exception:
                    stale = True
                try:
                    hide = bool(state.get('hide')) and int(state.get('empty_count') or 0) >= int(FilmixPrewarm.FILTER_AVAIL_EMPTY_CONFIRMATIONS)
                except Exception:
                    hide = False
            if hide:
                hidden += 1
            else:
                visible.append(entry)
            if stale:
                queue.append(cls._availability_task(section, filter_kind, entry))

        try:
            if queue:
                FilmixPrewarm(plugin).request_filter_availability_checks(queue, force=False)
        except Exception:
            pass
        try:
            xbmc.log('[plugin.video.filmix] FilterAvailabilityMenu: section={0} kind={1} total={2} visible={3} hidden={4} queued={5}'.format(
                section, filter_kind, len(entries), len(visible), hidden, len(queue)), xbmc.LOGINFO)
        except Exception:
            pass
        return visible


    @classmethod
    def genre_catalog(cls, section):
        genre_items = cls._filter_visible_catalog_filters(section, 'genre', cls._build_custom_genres(section))
        icon = Utilities.get_filter_icon('categories')

        def _items():
            for entry in genre_items:
                menu_item = MainMenuItem({'label': entry['label'], 'icon': icon})
                menu_item.set_url(plugin.url_for(section, filters=entry['filters']))
                yield menu_item.get_item()

        category_label = 'Жанры фильмов' if section == 'movies' else 'Жанры сериалов'
        plugin.create_directory(_items(), content='', category=category_label)

    @classmethod
    def country_catalog(cls, section):
        country_items = cls._filter_visible_catalog_filters(section, 'country', cls._build_custom_countries(section))
        icon = Utilities.get_filter_icon('countries')

        def _items():
            for entry in country_items:
                menu_item = MainMenuItem({'label': entry['label'], 'icon': icon})
                menu_item.set_url(plugin.url_for(section, filters=entry['filters']))
                yield menu_item.get_item()

        category_label = 'Страны фильмов' if section == 'movies' else 'Страны сериалов'
        plugin.create_directory(_items(), content='', category=category_label)

    @classmethod
    def root(cls):
        plugin.create_directory(cls._root_items(), content='', category=plugin.name)

    @classmethod
    def _root_items(cls):

        sections = Utilities.get_sections()
        for section_item in sections:

            if not section_item.get('visible', False):
                continue

            url = plugin.url_for(section_item['section'])

            item_info = MainMenuItem(section_item)
            item_info.set_url(url)

            yield item_info.get_item()


    @classmethod
    def catalog(cls, section):

        section_item = Utilities.get_section_item(section)

        filters = plugin.params.get('filters', '')

        page = plugin.params.get('page', '1')

        catalog_items = None
        catalog_from_cache = False
        cache = FilmixCache(plugin.profile_dir)
        cacheable = FilmixPrewarm.is_cacheable_catalog(section, page, filters)
        catalog_key = FilmixPrewarm.make_task_key(section, page, filters) if cacheable else ''
        if cacheable:
            cached = cache.get_any_catalog_cache(section, page, filters)
            if cached is not None:
                catalog_items = cached.get('items') or []
                catalog_from_cache = True
                #                 # Do not trust stale empty account-list cache after login.
                # This keeps Home/widgets cache-only for normal lists, but allows a
                # one-time live refresh for Favorites/Watch Later when an old logged-out
                # empty row is stuck in catalog_cache.
                try:
                    if section in ('favorites', 'deferred') and not catalog_items and (plugin.get_setting('user_login') or plugin.get_setting('user_dev_token')):
                        try:
                            xbmc.log('[plugin.video.filmix] AccountCacheFix: bypass empty account cache key={0}'.format(catalog_key), xbmc.LOGINFO)
                        except Exception:
                            pass
                        try:
                            cache.clear_catalog_cache(section)
                        except Exception:
                            pass
                        catalog_items = None
                        catalog_from_cache = False
                except Exception:
                    pass
                try:
                    age = FilmixCache._ts() - int(cached.get('updated_ts') or 0)
                except Exception:
                    age = -1
                try:
                    stale = FilmixPrewarm.is_catalog_stale(cached, section, filters)
                except Exception:
                    stale = False
                try:
                    xbmc.log('[plugin.video.filmix] CatalogCache: hit key={0} items={1} age={2}s stale={3}'.format(catalog_key, len(catalog_items), age, int(bool(stale))), xbmc.LOGINFO)
                except Exception:
                    pass
                # 2.2.32 AM8_4GB_CACHE_ONLY_WIDGETS:
                # A cache hit must return immediately.  Do not synchronously
                # refresh stale widget/list routes before ListItems are built:
                # that reintroduced long ROUTE_DONE times on 4GB boxes.
                # Keep the old cache for this render and let the service refresh
                # this exact key later in the background.
                try:
                    if stale:
                        xbmc.log('[plugin.video.filmix] CatalogCache: stale_cache_only key={0} action=background_refresh'.format(catalog_key), xbmc.LOGINFO)
                        FilmixPrewarm(plugin).request_refresh([catalog_key])
                except Exception as e:
                    try:
                        xbmc.log('[plugin.video.filmix] CatalogCache: stale_cache_only_queue_error key={0} err={1}'.format(catalog_key, e), xbmc.LOGWARNING)
                    except Exception:
                        pass
            else:
                try:
                    xbmc.log('[plugin.video.filmix] CatalogCache: miss key={0}'.format(catalog_key), xbmc.LOGINFO)
                except Exception:
                    pass

        try:
            if catalog_items is None:
                _live_t0 = time.time()
                if section == 'popular':
                    catalog_items = Filmix().popular(page)
                elif section == 'top_views':
                    catalog_items = Filmix().top_views(page)
                elif section == 'favorites':
                    catalog_items = Filmix().favourites(page)
                elif section == 'deferred':
                    catalog_items = Filmix().deferred(page)
                elif section == 'history':
                    catalog_items = Filmix().history(page)
                else:
                    catalog_items = Filmix().catalog(page, section_item['id'], filters)
                if cacheable:
                    try:
                        checksum = FilmixPrewarm._checksum(catalog_items)
                        cache.set_catalog_cache(section, page, filters, catalog_items, checksum)
                        try:
                            xbmc.log('[plugin.video.filmix] CatalogCache: live_fetch_store key={0} items={1} elapsed={2:.3f}s'.format(catalog_key, len(catalog_items or []), time.time() - _live_t0), xbmc.LOGINFO)
                        except Exception:
                            pass
                    except Exception as e:
                        try:
                            xbmc.log('[plugin.video.filmix] CatalogCache: store_failed key={0} err={1}'.format(catalog_key, e), xbmc.LOGWARNING)
                        except Exception:
                            pass
                    # Draw even the first live-loaded catalog in lite mode.
                    # Otherwise first open of a list can trigger one Filmix.post()/TMDb
                    # pass for every visible item, which is the main slowdown.
                    catalog_from_cache = True
        except (FilmixError, simplemedia.WebClientError) as e:
            if cacheable:
                cached = cache.get_any_catalog_cache(section, page, filters)
                if cached is not None:
                    catalog_items = cached.get('items') or []
                    catalog_from_cache = True
                else:
                    plugin.notify_error(e)
                    plugin.create_directory([], succeeded=False)
                    return
            else:
                plugin.notify_error(e)
                plugin.create_directory([], succeeded=False)
                return

        # Widget-maker calls must be cache-only when a warmed catalog exists.
        # Do not build filter selector rows for wm_link=1: they are not yielded in
        # _list_items() anyway, but building them can call Filmix filter endpoints.
        if plugin.params.get('wm_link') == '1':
            filters_items = []
        else:
            filters_items = Filters.get_filters_items(section_item)

        wm_params = {'filters': filters,
                     }

        wm_properties = {'wm_link': plugin.url_for(section_item['section'], wm_link=1, **wm_params),
                         'wm_addon': plugin.id,
                         'wm_label': section_item['label'],
                         }

        category_parts = [section_item['label'],
                          '{0} {1}'.format(_('Page'), page),
                          ]

        total_items = len(catalog_items)

        pages = Utilities.get_pages(total_items, page, section, filters=filters)
        if pages and cls._is_home_widget_listing_context():
            try:
                xbmc.log('[plugin.video.filmix] HomeWidgetPages: hidden section={0} count={1}'.format(section, len(pages)), xbmc.LOGINFO)
            except Exception:
                pass
            pages = []

        # После расчёта страниц: следующая страница зависит от полной выдачи сайта.
        catalog_items = cls._drop_screeners(catalog_items, route=section)
        total_items = len(catalog_items) + len(filters_items) + len(pages)

        container_content = cls._detect_container_content(catalog_items, fallback=section_item['content'] or 'videos')

        result = {'items': cls._list_items(catalog_items, wm_properties, filters_items, pages, lite=catalog_from_cache),
                  'total_items': total_items,
                  'content': container_content,
                  'category': ' / '.join(category_parts),
                  'sort_methods': {'sortMethod': xbmcplugin.SORT_METHOD_NONE, 'label2Mask': '%Y / %O'},
                  'update_listing': (page != '1'),
                  }
        plugin.create_directory(**result)

    @staticmethod
    def _missing_source_plot(source):
        """True when Filmix source row/post lacks a local Russian plot."""
        try:
            source = source or {}
            return not bool(_select_plot(source))
        except Exception:
            return False

    @staticmethod
    def _missing_usable_plot(source, resolved_ids):
        # Provider overview must not block Filmix.post() source-plot fill.
        return FilmixCatalogs._missing_source_plot(source)

    @staticmethod
    def _overview_miss_recent(resolved_ids):
        try:
            miss_at = int((resolved_ids or {}).get('_tmdb_overview_miss_at') or 0)
            miss_build = str((resolved_ids or {}).get('_tmdb_overview_miss_build') or '')
            if miss_build != FilmixPrewarm.TMDB_MISS_BUILD:
                return False
            return bool(miss_at and (FilmixCache._ts() - miss_at) < (6 * 60 * 60))
        except Exception:
            return False

    @classmethod
    def _needs_metadata_enrich(cls, item, post_info, resolved_ids):
        # Обогащение делает скин, и оно у провайдера удалено ().
        # Спрашивать «не нужно ли обогатить» больше не у кого.
        return False
        try:
            if not isinstance(item, dict) or not item.get('id'):
                return False
            need_post = not isinstance(post_info, dict)
            if isinstance(post_info, dict) and not Utilities.is_movie(post_info):
                # Serial rows need full Filmix post details for seasons/episode counts.
                try:
                    playlist = (post_info.get('player_links') or {}).get('playlist')
                    if not isinstance(playlist, dict) or not playlist:
                        need_post = True
                except Exception:
                    need_post = True
            plot_source = post_info if isinstance(post_info, dict) else item
            plot_needs_overview = bool(cls._missing_usable_plot(plot_source, resolved_ids)
                                       and not cls._overview_miss_recent(resolved_ids))
            # Ландшафта здесь больше не ждут: задник не публикуется вовсе
            # (listitems.get_fanart), его строит скин. Раньше отсутствие
            # resolved_landscape само по себе означало «надо опознать заново» -
            # то есть запрос к TMDb ради картинки, которая никуда не пойдёт.
            need_resolve = (not isinstance(resolved_ids, dict)
                            or not resolved_ids.get('resolved_tmdb_id')
                            or not resolved_ids.get('resolved_premiered')
                            or plot_needs_overview)
            if isinstance(resolved_ids, dict) and resolved_ids.get('_tmdb_miss_at'):
                try:
                    miss_at = int(resolved_ids.get('_tmdb_miss_at') or 0)
                    miss_build = str(resolved_ids.get('_tmdb_miss_build') or '')
                    # 2.2.50: old cached TMDb misses from previous metadata logic must not
                    # suppress fresh visible-row retries for missing release date/overview.
                    if miss_at and miss_build == FilmixPrewarm.TMDB_MISS_BUILD and (FilmixCache._ts() - miss_at) < int(FilmixPrewarm.TMDB_MISS_TTL):
                        # Do not suppress an overview-only retry unless that
                        # overview retry also has its own recent miss marker.
                        need_resolve = bool(plot_needs_overview)
                except Exception:
                    pass
            return bool(need_post or need_resolve)
        except Exception:
            return False

    @classmethod
    def _list_items(cls, items, wm_properties=None, filters=None, pages=None, lite=False):

        filters = filters or []
        pages = pages or []

        wm_link = (plugin.params.get('wm_link') == '1')

        if not wm_link:
            for filter_item in filters:
                yield filter_item.get_item()

        properties = {}
        if wm_properties is not None:
            properties.update(wm_properties or {})

        # 2.2 STRICT_RU_SR_PLOT_CRASH_DIAG:
        # Catalog list itself is still cache-first, but widget/list rows must be
        # complete immediately. If a new Filmix item is missing post details or
        # TMDb release/id data, fetch and store it synchronously while building
        # the list item. Lists update rarely; after this first fill the same rows
        # come from SQLite cache and remain fast.
        cache_only = bool(lite or wm_link)
        api = None

        cache = FilmixCache(plugin.profile_dir)
        # Резолвер на маршруте списка не строится: опознание - работа скина.
        resolver = None

        metadata_enrich_ids = []
        sync_posts = 0
        sync_resolved = 0
        sync_failed = 0
        fast_widget_build_count = 0
        fast_widget_build_elapsed = 0.0
        inline_plot_posts = 0
        #         # Keep the exact ListItem/art/cache path, but fully disable
        # the same-pass Filmix.post() fill that logged InlineVisiblePlot.
        inline_plot_cap = 50
        inline_plot_visible_cap = 50

        # 2.2.35 AM8_4GB_BULK_CACHE_READ:
        # Materialize the current directory/widget rows once, then fetch the
        # per-row cached payloads in bulk.  This keeps the 2.2.33 cache-only
        # behaviour but removes hundreds of tiny SQLite reads from AF3 Home.
        items_list = [i for i in (items or []) if isinstance(i, dict)]
        post_ids = []
        for _bulk_item in items_list:
            try:
                _pid = str(_bulk_item.get('id') or '')
                if _pid:
                    post_ids.append(_pid)
            except Exception:
                pass

        bulk_post_details = {}
        bulk_resolved_ids = {}
        bulk_watched_states = None
        if cache_only and post_ids:
            try:
                _bulk_t0 = time.time()
                bulk_post_details = cache.get_post_details_many(post_ids)
                bulk_resolved_ids = cache.get_resolved_ids_many(post_ids)
                cls._sync_with_kodi(cache)
                bulk_watched_states = cache.get_watched_snapshot_many(post_ids)
                _snapshot_mode = 'unknown'
                _summary_rows = 0
                try:
                    _snapshot_mode = bulk_watched_states.get('__filmix_snapshot_mode') or 'unknown'
                    _summary_rows = len(bulk_watched_states.get('__filmix_summary_v1') or {})
                except Exception:
                    pass
                xbmc.log('[plugin.video.filmix] BulkCacheRead: ids={0} posts={1} resolved={2} watched_keys={3} watched_summary={4} mode={5} elapsed={6:.3f}s'.format(
                    len(set(post_ids)), len(bulk_post_details), len(bulk_resolved_ids), len(bulk_watched_states or {}), _summary_rows, _snapshot_mode, time.time() - _bulk_t0), xbmc.LOGINFO)
            except Exception as e:
                bulk_post_details = {}
                bulk_resolved_ids = {}
                bulk_watched_states = None
                xbmc.log('[plugin.video.filmix] BulkCacheRead: failed fallback_to_single_reads err={0}'.format(e), xbmc.LOGWARNING)

        # Описания для первых строк - разом и параллельно, а не по одному в
        # цикле ниже. Поиск «Время» на .30 17.10.2026: 50 строк, у большинства
        # описания в кеше нет, по 0.05-0.35 с на запрос подряд - 4-5 с из 5.0 с
        # маршрута. Условие то же, что в цикле (_inline_needs_post); ответы
        # цикл берёт отсюда, порядок строк и запись в кеш прежние.
        inline_prefetched = {}
        if cache_only and items_list:
            _need = []
            for _idx, _it in enumerate(items_list[:inline_plot_visible_cap]):
                _pid = _it.get('id')
                if not _pid:
                    continue
                _cached = bulk_post_details.get(FilmixCache._norm(_pid))
                _src = _cached or _it
                if not cls._inline_needs_post(_src):
                    continue
                # Пост уже в кеше и описание в нём есть - не хватает только
                # даты, а её Filmix в посте не отдаёт: повторный запрос ничего
                # не принесёт. Замер на .30 17.10.2026: повторный поиск «Время»
                # заново спрашивал все 50 постов ради одной даты.
                if isinstance(_cached, dict) and not cls._missing_source_plot(_cached):
                    continue
                _need.append(_pid)
            _need = _need[:inline_plot_cap]
            if len(_need) > 1:
                _pre_t0 = time.time()
                inline_prefetched = cls._fetch_posts_parallel(_need)
                xbmc.log('[plugin.video.filmix] InlineVisiblePlot: parallel posts={0} ok={1} elapsed={2:.3f}s'.format(
                    len(_need), sum(1 for v in inline_prefetched.values() if isinstance(v, dict)),
                    time.time() - _pre_t0), xbmc.LOGINFO)

        for item_index, item in enumerate(items_list):

            item_id = item.get('id')
            item_id_norm = FilmixCache._norm(item_id)
            post_info = bulk_post_details.get(item_id_norm) if cache_only else cache.get_post_details(item_id)
            # 21.11.2026: догрузка поста на маршруте списка (load_content_info)
            # убрана - она была выключена жёстко, настройка удалена.

            # 2.2.59 AM8_4GB_INLINE_VISIBLE_PLOT:
            # Keep widgets cache-only for heavy TMDb work, but do a tiny
            # same-pass Filmix-post fill for the first visible rows when the
            # row already has ratings/artwork yet no user-visible plot/date.
            # This restores the old behavior users see on focus: plot arrives
            # together with the other metadata, without re-enabling full
            # synchronous TMDbResolve/InstantMetadata for all 50 items.
            if cache_only and inline_plot_posts < inline_plot_cap and item_index < inline_plot_visible_cap:
                try:
                    _plot_source = post_info if isinstance(post_info, dict) else item
                    _missing_plot = cls._missing_source_plot(_plot_source)
                    _missing_date = not bool(_clean_text((_plot_source or {}).get('resolved_premiered')
                                                         or (_plot_source or {}).get('premiered')
                                                         or (_plot_source or {}).get('release_date')
                                                         or (_plot_source or {}).get('date_release')
                                                         or (_plot_source or {}).get('release')))
                except Exception:
                    _missing_plot = False
                    _missing_date = False
                if _missing_date and not _missing_plot and isinstance(post_info, dict) and item_id not in inline_prefetched:
                    # См. отбор перед циклом: ради одной даты пост не перечитываем.
                    _missing_date = False
                if (_missing_plot or _missing_date) and item_id:
                    try:
                        _inline_t0 = time.time()
                        if item_id in inline_prefetched:
                            _inline_post = inline_prefetched[item_id]
                            if isinstance(_inline_post, Exception):
                                raise _inline_post
                        else:
                            if api is None:
                                # описание строки, которую пользователь сейчас откроет, - не фон
                                api = Filmix(background=False, unpaced=cls._user_search[0])
                            _inline_post = api.post(item_id)
                    except Exception as e:
                        sync_failed += 1
                        try:
                            xbmc.log('[plugin.video.filmix] InlineVisiblePlot: failed post_id={0} err={1}'.format(item_id, e), xbmc.LOGWARNING)
                        except Exception:
                            pass
                    else:
                        if isinstance(_inline_post, dict):
                            post_info = _inline_post
                            # в кэш - после отдачи списка Kodi (default.py): запись ждала замок базы,
                            # пока её пишет служба, до 1,7 с на строку, и список стоял
                            cls._deferred_posts.append((item_id, post_info))
                            inline_plot_posts += 1
                            try:
                                _inline_plot = not cls._missing_usable_plot(post_info, {})
                                _inline_premiered = (post_info.get('premiered') or post_info.get('release_date')
                                                     or post_info.get('date_release') or post_info.get('release'))
                                xbmc.log('[plugin.video.filmix] InlineVisiblePlot: post_id={0} plot={1} premiered={2} elapsed={3:.3f}s'.format(item_id, int(bool(_inline_plot)), _inline_premiered or '', time.time() - _inline_t0), xbmc.LOGINFO)
                            except Exception:
                                pass

            resolved_ids = (bulk_resolved_ids.get(item_id_norm) if cache_only else cache.get_resolved_ids(item_id)) or {}

            def _source_identity_props(_item, _post):
                """Immutable Filmix identity fields for skin-side validation.

                These values must be captured before resolved_ids are applied: stale
                TMDb cache rows can contain provider year/country and must not
                overwrite the Filmix source identity used to reject wrong art.
                """
                def _clean(v):
                    try:
                        return str(v).strip()
                    except Exception:
                        return ''
                def _year_from(v):
                    v = _clean(v)
                    m = re.search(r'((?:19|20)\d{2})', v)
                    return m.group(1) if m else ''
                def _pick_year(*rows):
                    for row in rows:
                        if not isinstance(row, dict):
                            continue
                        for key in ('source_year', 'filmix_year', 'year'):
                            y = _year_from(row.get(key))
                            if y:
                                return y
                        for key in ('premiered', 'release_date', 'released', 'date_release',
                                    'release', 'air_date', 'first_air_date', 'date_atom'):
                            y = _year_from(row.get(key))
                            if y:
                                return y
                    return ''
                def _as_list(v):
                    if v in (None, '', []):
                        return []
                    if isinstance(v, dict):
                        values = list(v.values())
                    elif isinstance(v, (list, tuple, set)):
                        values = list(v)
                    else:
                        values = re.split(r'[,/;|]+', str(v))
                    out = []
                    for x in values:
                        x = _clean(x)
                        if x and x not in out:
                            out.append(x)
                    return out
                countries = []
                for row in (_item, _post):
                    if not isinstance(row, dict):
                        continue
                    for key in ('source_countries', 'filmix_countries', 'countries', 'country'):
                        for value in _as_list(row.get(key)):
                            if value and value not in countries:
                                countries.append(value)
                    if countries:
                        break
                year = _pick_year(_item, _post)
                props = {}
                if year:
                    props['FilmixSourceYear'] = year
                    props['SourceYear'] = year
                if countries:
                    text = ' / '.join(countries)
                    props['FilmixSourceCountry'] = text
                    props['FilmixSourceCountries'] = text
                    props['SourceCountry'] = text
                    props['SourceCountries'] = text
                try:
                    if isinstance(_item, dict) and _item.get('id'):
                        props['FilmixPostID'] = str(_item.get('id'))
                except Exception:
                    pass
                return props

            _filmix_source_identity_props = _source_identity_props(item, post_info)
            try:
                item, _manual_item = apply_manual_override(item, post_id=item_id)
                if isinstance(post_info, dict):
                    post_info, _manual_post = apply_manual_override(post_info, hint=item, post_id=item_id)
                else:
                    _manual_post = False
                if isinstance(resolved_ids, dict):
                    resolved_ids, _manual_resolved = apply_manual_override(resolved_ids, hint=post_info or item, post_id=item_id)
                else:
                    _manual_resolved = False
                if _manual_item or _manual_post or _manual_resolved:
                    try:
                        cache.set_resolved_ids(item_id, resolved_ids)
                    except Exception:
                        pass
                    try:
                        xbmc.log('[plugin.video.filmix] ManualIDOverride: post_id={0} title={1} tmdb={2} imdb={3}'.format(item_id, item.get('title'), resolved_ids.get('resolved_tmdb_id'), resolved_ids.get('resolved_imdb_id')), xbmc.LOGINFO)
                    except Exception:
                        pass
            except Exception:
                pass
            # validate cached/widget resolved_ids before item.update().
            # A stale false positive in cache must not reach ListItem.Art/Info and
            # must not trigger skin metadata for the wrong TMDb identity.  This is
            # intentionally source-data driven: no post ids and no title blacklist.
            try:
                if isinstance(resolved_ids, dict) and resolved_ids.get('resolved_tmdb_id'):
                    _validation_source = {}
                    if isinstance(post_info, dict):
                        _validation_source.update(post_info)
                    if isinstance(item, dict):
                        # Source catalog fields override post_details for validation: post_details
                        # can already be poisoned by stale resolved_ids/provider metadata.
                        _validation_source.update(item)
                    _forced_type = 'movie' if Utilities.is_movie(_validation_source) else 'tv'
                    _valid_cached, _reject_cached = TMDbResolver.validate_resolved_match(
                        _validation_source, resolved_ids, details=None, tmdb_type=_forced_type)
                    if not _valid_cached:
                        resolved_ids = {
                            '_tmdb_miss_at': FilmixCache._ts(),
                            '_tmdb_miss_type': _forced_type,
                            '_tmdb_miss_build': FilmixPrewarm.TMDB_MISS_BUILD,
                            '_tmdb_rejected_tmdb_id': str(resolved_ids.get('resolved_tmdb_id') or ''),
                            '_tmdb_reject_reason': _reject_cached or 'cached_identity_validation_failed'
                        }
                        cache.set_resolved_ids(item_id, resolved_ids)
                        xbmc.log('[plugin.video.filmix] TMDbResolve: reject cached resolved_ids post_id={0} title={1} tmdb={2} reason={3}'.format(
                            item_id, item.get('title'), resolved_ids.get('_tmdb_rejected_tmdb_id'), resolved_ids.get('_tmdb_reject_reason')), xbmc.LOGINFO)
            except Exception as e:
                try:
                    xbmc.log('[plugin.video.filmix] TMDbResolve: cached id validation skipped post_id={0} err={1}'.format(item_id, e), xbmc.LOGDEBUG)
                except Exception:
                    pass

            if (not cache_only) and resolver is not None and getattr(resolver, 'enabled', False):
                resolve_source = post_info if post_info is not None else item
                forced_type = 'movie' if Utilities.is_movie(resolve_source) else 'tv'
                miss_recent = False
                try:
                    miss_at = int(resolved_ids.get('_tmdb_miss_at') or 0)
                    miss_type = resolved_ids.get('_tmdb_miss_type') or ''
                    # 2.2.27 NAV_TMDB_MISS_TTL_FIX: keep navigation in sync with prewarm;
                    # unresolved TMDb misses block retry for only 6h, not 7 days.
                    miss_recent = bool(miss_at and (not miss_type or miss_type == forced_type)
                                       and (FilmixCache._ts() - miss_at) < (6 * 60 * 60))
                except Exception:
                    miss_recent = False
                plot_needs_overview = bool(cls._missing_usable_plot(resolve_source, resolved_ids)
                                           and not cls._overview_miss_recent(resolved_ids))
                need_resolve = (not resolved_ids or not resolved_ids.get('resolved_tmdb_id') or not resolved_ids.get('resolved_premiered') or plot_needs_overview) and not miss_recent
                if need_resolve:
                    try:
                        _resolve_payload = dict(resolve_source or {})
                        if isinstance(resolved_ids, dict):
                            _resolve_payload.update(resolved_ids)
                        new_ids = _resolve_with_skin(resolver, _resolve_payload, item_id, forced_type)
                    except Exception as e:
                        simpleplugin.log_exception(e)
                        new_ids = None
                    blocked_without_tmdb = bool(new_ids and new_ids.get('_tmdb_title_resolve_blocked')
                                                and not new_ids.get('resolved_tmdb_id'))
                    has_useful_ids = bool(new_ids and not blocked_without_tmdb
                                          and (new_ids.get('resolved_tmdb_id')
                                               or new_ids.get('resolved_imdb_id')
                                               or new_ids.get('resolved_premiered')
                                               or new_ids.get('resolved_overview')))
                    if has_useful_ids:
                        resolved_ids.update(new_ids)
                        resolved_ids.pop('_tmdb_miss_at', None)
                        resolved_ids.pop('_tmdb_miss_type', None)
                        if new_ids.get('resolved_overview'):
                            resolved_ids.pop('_tmdb_overview_miss_at', None)
                            resolved_ids.pop('_tmdb_overview_miss_build', None)
                        elif plot_needs_overview:
                            resolved_ids['_tmdb_overview_miss_at'] = FilmixCache._ts()
                            resolved_ids['_tmdb_overview_miss_build'] = FilmixPrewarm.TMDB_MISS_BUILD
                        cache.set_resolved_ids(item_id, resolved_ids)
                        sync_resolved += 1
                        try:
                            xbmc.log('[plugin.video.filmix] TMDbResolve: ok post_id={0} title={1} type={2} tmdb={3} premiered={4}'.format(item.get('id'), item.get('title'), forced_type, new_ids.get('resolved_tmdb_id'), new_ids.get('resolved_premiered')), xbmc.LOGINFO)
                        except Exception:
                            pass
                    else:
                        resolved_ids['_tmdb_miss_at'] = FilmixCache._ts()
                        resolved_ids['_tmdb_miss_type'] = forced_type
                        cache.set_resolved_ids(item_id, resolved_ids)
                        try:
                            xbmc.log('[plugin.video.filmix] TMDbResolve: miss cached post_id={0} title={1} original={2} alt={3} type={4} year={5}'.format(item.get('id'), item.get('title'), item.get('original_title'), item.get('alt_name'), forced_type, item.get('year')), xbmc.LOGINFO)
                        except Exception:
                            pass


            if resolved_ids:
                item.update(resolved_ids)
                if post_info is not None:
                    post_info.update(resolved_ids)

            # 2.2.52 AM8_4GB_WIDGET_PLOT_MERGE_FIX:
            # Cache-only Home widgets can have a partial post_details row
            # (ids/art/ratings already resolved) while the catalog row still
            # carries the Filmix story/short_story.  The previous fast-widget
            # path used post_details alone and therefore dropped the plot in
            # widgets, even though opening the same Filmix list showed it.
            # Build the ListItem from a merged display payload: catalog row as
            # fallback + full post_details + resolved ids.  Heavy fields such as
            # player_links still come from post_details when present.
            source_item = item
            if post_info is not None:
                merged_source = {}
                try:
                    if isinstance(item, dict):
                        merged_source.update(item)
                    if isinstance(post_info, dict):
                        merged_source.update(post_info)
                    for _display_key in ('short_story', 'plot', 'description', 'story',
                                         'premiered', 'release_date', 'resolved_premiered',
                                         'year', 'resolved_year', 'categories', 'countries',
                                         'poster', 'fanart', 'landscape', 'backdrop',
                                         'backdrop_path'):
                        _cur = merged_source.get(_display_key)
                        _fallback = item.get(_display_key) if isinstance(item, dict) else None
                        if (_cur in [None, ''] or (isinstance(_cur, str) and not _cur.strip())) and _fallback not in [None, '']:
                            merged_source[_display_key] = _fallback
                    # Тип релиза - из строки каталога/поиска: детали поста в кэше
                    # остаются с первой экранкой («Тенцинг» CAM 480 от 13.10), а
                    # каталог 20.10 уже даёт WEB-DLRip 2160. В строке каталога
                    # quality - это и есть rip («WEB-DLRip 2160»), в посте - число.
                    _row_rip = str(item.get('quality') or '').strip() if isinstance(item, dict) else ''
                    if re.search(r'[A-Za-z]', _row_rip):
                        merged_source['rip'] = _row_rip
                    if isinstance(resolved_ids, dict):
                        merged_source.update(resolved_ids)
                except Exception:
                    merged_source = post_info
                source_item = merged_source
                item_info = PostInfo(source_item)
            else:
                if isinstance(resolved_ids, dict):
                    item.update(resolved_ids)
                item_info = ItemInfo(item)

            listitem = ListItem(item_info)
            url = cls._get_listitem_url(item_info)

            listitem.set_url(url)
            merged_properties = {}
            merged_properties.update(properties)
            try:
                # Must override any generic property names from older snapshots.
                # These source identity fields are read by the skin before ListItem.Year/Country.
                merged_properties.update(_filmix_source_identity_props or {})
            except Exception:
                pass
            if cache_only:
                # Consumed by the Kodi-native directory renderer to avoid a
                # MyVideos resume DB scan while Home widgets are being built.
                merged_properties['FilmixCacheOnlyWidget'] = 'true'
            listitem.set_properties(merged_properties)
            cls._apply_local_state(listitem, item_info, source_item, cache, fast=cache_only, watched_map=bulk_watched_states)
            listitem.set_context_menu(cls._get_context_menu(source_item, item_info, cache, watched_map=bulk_watched_states))

            if cache_only:
                _fw_t0 = time.time()
                _fw_item = listitem.get_cache_widget_item()
                fast_widget_build_elapsed += (time.time() - _fw_t0)
                fast_widget_build_count += 1
                yield _fw_item
            else:
                yield listitem.get_item()

        if not wm_link:
            for page in pages:
                yield page

        try:
            if cache_only:
                xbmc.log('[plugin.video.filmix] CacheOnlyWidget: sync_metadata_disabled posts={0} resolved={1} failed={2} inline_plot_posts={3} queued_left={4}'.format(
                    sync_posts, sync_resolved, sync_failed, inline_plot_posts, len(metadata_enrich_ids)), xbmc.LOGINFO)
                xbmc.log('[plugin.video.filmix] FastWidgetItemBuild: count={0} elapsed={1:.3f}s'.format(
                    fast_widget_build_count, fast_widget_build_elapsed), xbmc.LOGINFO)
            elif (sync_posts or sync_resolved or sync_failed):
                xbmc.log('[plugin.video.filmix] InstantMetadata: done posts={0} resolved={1} failed={2} queued_left={3}'.format(
                    sync_posts, sync_resolved, sync_failed, len(metadata_enrich_ids)), xbmc.LOGINFO)
        except Exception:
            pass

    @classmethod
    def open_tvshow(cls, content_name, section=None):
        # 2.2 DEFAULT_OPEN:
        # Standard Kodi route for TV shows. Home widgets no longer receive the
        # forced-info workaround; OK opens the series/seasons list normally.
        return cls.post_seasons(content_name)

    @classmethod
    def _has_playlist(cls, info):
        try:
            return isinstance(info, dict) and bool(info.get('player_links', {}).get('playlist'))
        except Exception:
            return False

    @classmethod
    def _empty_directory(cls, label=None):
        # never call gettext for the empty-directory label here.
        # simpleplugin raises when a UI string is absent from strings.po, so an empty/error directory must
        # be safe even if localization files are incomplete.
        safe_label = label
        if not safe_label:
            safe_label = 'Нет элементов'
            try:
                lang = xbmc.getLanguage(xbmc.ISO_639_1).lower()
                if not lang.startswith('ru'):
                    safe_label = 'No items'
            except Exception:
                pass
        return [{'label': safe_label,
                 'is_folder': False,
                 'is_playable': False,
                 'url': '',
                 'fanart': plugin.fanart}]

    @classmethod
    def _playlist_log_summary(cls, info):
        try:
            summary = FilmixCache.playlist_summary(info)
            parts = []
            for season in sorted(summary.keys(), key=lambda value: (0, int(value)) if str(value).isdigit() else (1, str(value))):
                translations = summary.get(season) or {}
                values = ['{0}:{1}'.format(name, count) for name, count in sorted(translations.items())]
                parts.append('s{0}[{1}]'.format(season, ','.join(values)))
            return ';'.join(parts) or 'none'
        except Exception:
            return 'error'

    @staticmethod
    def _tmdb_art_url(value):
        try:
            text = str(value or '').strip().lower()
            return bool(text.startswith('/') or 'image.tmdb.org/' in text or 'themoviedb.org/t/p/' in text or 'assets.fanart.tv/' in text)
        except Exception:
            return False

    @classmethod
    def _clean_country_values(cls, value):
        values = []
        if value in (None, '', []):
            return values
        if isinstance(value, dict):
            raw_values = list(value.values())
        elif isinstance(value, (list, tuple, set)):
            raw_values = list(value)
        else:
            raw_values = re.split(r'[,/;|]+', str(value))
        for raw in raw_values:
            text = _clean_text(raw)
            if text and text not in values:
                values.append(text)
        return values

    @classmethod
    def _source_country_values(cls, item, cache=None):
        """Return Filmix/source country labels for identity guards.

        Prefer immutable/source keys and post cache over generic provider fields.
        Do not merge conflicting generic rows: one wrong US value alongside a clean
        HK/VN value would otherwise make a foreign US TMDb identity look valid.
        """
        rows = []
        try:
            post_id = item.get('id') or item.get('post_id') if isinstance(item, dict) else ''
            if cache is not None and post_id:
                post = cache.get_post_details(post_id)
                if isinstance(post, dict):
                    rows.append(post)
        except Exception:
            pass
        if isinstance(item, dict):
            rows.append(item)

        source_keys = ('filmix_countries', 'source_countries', 'FilmixSourceCountries',
                       'FilmixSourceCountry', 'SourceCountries', 'SourceCountry')
        generic_keys = ('countries', 'country')
        for keys in (source_keys, generic_keys):
            for row in rows:
                if not isinstance(row, dict):
                    continue
                values = []
                for key in keys:
                    for value in cls._clean_country_values(row.get(key)):
                        if value and value not in values:
                            values.append(value)
                if values:
                    return values
        return []

    @classmethod
    def _source_country_isos(cls, item, cache=None):
        isos = set()
        for value in cls._source_country_values(item, cache):
            isos |= _country_text_to_isos(value)
        return isos

    @classmethod
    def _provider_identity_reject_record(cls, tmdb_id, tmdb_type, reason):
        return {
            '_tmdb_miss_at': FilmixCache._ts(),
            '_tmdb_miss_type': tmdb_type or 'tv',
            '_tmdb_miss_build': FilmixPrewarm.TMDB_MISS_BUILD,
            '_tmdb_rejected_tmdb_id': str(tmdb_id or ''),
            '_tmdb_reject_reason': reason or 'identity_validation_failed'
        }

    @classmethod
    def _source_year_value(cls, item, cache=None):
        """Return the Filmix/catalog year that must survive provider rejection.

        Rejected TMDb rows can leave a generic item['year']/premiered from the
        wrong candidate (for example Allegiance 2015).  Prefer immutable/source
        fields and the Filmix slug/title; only then use generic numeric fields.
        """
        def _clean(v):
            try:
                return str(v or '').strip()
            except Exception:
                return ''
        def _year_from(v):
            v = _clean(v)
            m = re.search(r'(?<!\d)((?:19|20)\d{2}|2100)(?!\d)', v)
            return m.group(1) if m else ''
        rows = []
        try:
            post_id = item.get('id') or item.get('post_id') if isinstance(item, dict) else ''
            if cache is not None and post_id:
                post = cache.get_post_details(post_id)
                if isinstance(post, dict):
                    rows.append(post)
        except Exception:
            pass
        if isinstance(item, dict):
            rows.append(item)

        source_keys = ('source_year', 'filmix_year', 'SourceYear', 'FilmixSourceYear',
                       'title', 'alt_name', 'post_url', 'url', 'link', 'href',
                       'date_release', 'released', 'release')
        generic_keys = ('year', 'release_year', 'production_year', 'premiered',
                        'release_date', 'first_air_date', 'air_date',
                        'original_title', 'name', 'original_name')
        for keys in (source_keys, generic_keys):
            for row in rows:
                if not isinstance(row, dict):
                    continue
                for key in keys:
                    y = _year_from(row.get(key))
                    if y:
                        return y
        return ''

    @staticmethod
    def _provider_art_url(value):
        try:
            text = str(value or '').strip().lower()
        except Exception:
            return False
        if not text:
            return False
        return bool(text.startswith('/') or
                    'image.tmdb.org/' in text or
                    'themoviedb.org/t/p/' in text or
                    'assets.fanart.tv/' in text or
                    'fanart.tv/fanart/' in text or
                    'thetvdb.com/' in text or
                    'artworks.thetvdb.com/' in text)

    @classmethod
    def _strip_episode_provider_art(cls, episode_data):
        if not isinstance(episode_data, dict):
            return episode_data
        cleaned = dict(episode_data)
        for key in ('still', 'thumb', 'thumbnail', 'image', 'fanart', 'landscape',
                    'backdrop', 'poster_path', 'backdrop_path', 'still_path',
                    'resolved_poster', 'resolved_landscape', 'resolved_fanart'):
            if key in cleaned:
                # For an identity-rejected show, any per-episode art may be from the
                # rejected provider cache.  Drop it completely and let the row fall
                # back to the Filmix parent poster instead of a wrong still.
                cleaned.pop(key, None)
        return cleaned

    @classmethod
    def _strip_rejected_provider_identity(cls, item, cache=None, reason='', tmdb_id=''):
        if not isinstance(item, dict):
            return item
        cleaned = dict(item)
        # Remove all externally-resolved ids and provider fields that can make a
        # season/episode row resolve as a different show. Keep Filmix source title,
        # plot, poster and player playlist intact.
        for key in (
                'resolved_tmdb_id', 'tmdb_id', 'tmdb', 'resolved_imdb_id', 'imdb_id', 'imdb',
                'resolved_tmdb_type', 'tmdb_type', 'resolved_title', 'resolved_original_title',
                'original_title', 'original_name', 'name',
                'resolved_premiered', 'premiered', 'release_date', 'first_air_date',
                'air_date', 'resolved_year', 'year', 'release_year', 'production_year',
                'resolved_overview', 'tmdb_overview',
                'provider_country', 'provider_countries', 'origin_country', 'production_countries',
                'studio', 'studios', 'network', 'networks', 'ratings', 'rating', 'votes',
                'resolved_poster', 'resolved_landscape', 'resolved_fanart', 'poster_path',
                'backdrop_path', 'fanart', 'landscape', 'backdrop', 'still', 'clearlogo',
                'resolved_clearlogo', 'trailer', 'resolved_trailer'):
            cleaned.pop(key, None)
        for key in ('poster', 'thumb', 'thumbnail', 'image'):
            if cls._provider_art_url(cleaned.get(key)):
                cleaned.pop(key, None)
        countries = cls._source_country_values(item, cache)
        if countries:
            cleaned['countries'] = list(countries)
            cleaned['filmix_countries'] = list(countries)
            cleaned['source_countries'] = list(countries)
        year = cls._source_year_value(item, cache)
        if year:
            cleaned['year'] = year
            cleaned['source_year'] = year
            cleaned['filmix_year'] = year
        if reason:
            cleaned['_filmix_identity_rejected'] = '1'
            cleaned['_filmix_identity_reject_reason'] = reason
        if tmdb_id:
            cleaned['_filmix_rejected_tmdb_id'] = str(tmdb_id)
        return cleaned

    @classmethod
    def _validate_tv_identity_for_episode_lookup(cls, item, cache=None, route=''):
        """Validate and scrub TV identities before creating season/episode rows.

        Previous builds correctly wrote a rejection to resolved_ids but still built
        SeasonInfo/VideoInfo from the original post_details dict, where stale
        tmdb_id/tvshow.tmdb survived. The skin then trusted that stale id and
        loaded foreign fanart for the season list. This helper makes rejection
        affect the actual ListItem payload.
        """
        if not isinstance(item, dict):
            return item
        tmdb_id = (item.get('resolved_tmdb_id') or item.get('tmdb_id') or item.get('tmdb'))
        if not tmdb_id:
            return item
        try:
            tmdb_id = str(int(str(tmdb_id)))
        except Exception:
            return item
        post_id = item.get('id') or item.get('post_id') or ''
        try:
            resolver = TMDbResolver(timeout=5)
            if not getattr(resolver, 'enabled', False):
                return item
            details = resolver._details(tmdb_id, 'tv') or {}
            probe = dict(item)
            probe['resolved_tmdb_id'] = tmdb_id
            probe['resolved_tmdb_type'] = 'tv'
            source_isos = cls._source_country_isos(item, cache)
            valid, reject_reason = TMDbResolver.validate_resolved_match(
                item, probe, details=details, tmdb_type='tv',
                source_countries=(source_isos or None))
            if valid:
                return item
            try:
                if cache is not None and post_id:
                    cache.set_resolved_ids(post_id, cls._provider_identity_reject_record(tmdb_id, 'tv', reject_reason))
            except Exception:
                pass
            try:
                xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: scrub rejected identity post_id={0} tmdb={1} route={2} reason={3}'.format(
                    post_id, tmdb_id, route or '-', reject_reason or 'identity_validation_failed'), xbmc.LOGINFO)
            except Exception:
                pass
            return cls._strip_rejected_provider_identity(item, cache=cache, reason=(reject_reason or 'identity_validation_failed'), tmdb_id=tmdb_id)
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: identity scrub skipped post_id={0} tmdb={1} route={2} err={3}'.format(
                    post_id, tmdb_id, route or '-', e), xbmc.LOGDEBUG)
            except Exception:
                pass
        return item

    @classmethod
    def _inline_needs_post(cls, source):
        """Нужен ли строке пост Filmix ради описания или даты (как в цикле)."""
        try:
            if cls._missing_source_plot(source):
                return True
            return not bool(_clean_text((source or {}).get('resolved_premiered')
                                        or (source or {}).get('premiered')
                                        or (source or {}).get('release_date')
                                        or (source or {}).get('date_release')
                                        or (source or {}).get('release')))
        except Exception:
            return False

    INLINE_POST_WORKERS = 6

    @classmethod
    def _fetch_posts_parallel(cls, post_ids):
        """{post_id: пост | исключение}. У каждого потока свой клиент: сессия
        requests между потоками не делится."""
        import threading
        from concurrent.futures import ThreadPoolExecutor
        local = threading.local()

        def one(pid):
            try:
                client = getattr(local, 'api', None)
                if client is None:
                    # описания строк открываемого списка ждёт пользователь - не фон (очередь _pace)
                    client = local.api = Filmix(background=False, unpaced=cls._user_search[0])
                return pid, client.post(pid)
            except Exception as e:
                return pid, e

        result = {}
        with ThreadPoolExecutor(max_workers=cls.INLINE_POST_WORKERS) as pool:
            for pid, value in pool.map(one, post_ids):
                result[pid] = value
        return result

    @classmethod
    def _listing_item(cls, cache, post_id):
        """Строка сериала с первой страницы каталога, если он там есть."""
        wanted = str(post_id or '')
        for section in cls.LISTING_SECTIONS:
            try:
                cached = cache.get_any_catalog_cache(section, '1', '')
            except Exception:
                cached = None
            for item in (cached or {}).get('items') or []:
                if isinstance(item, dict) and str(item.get('id') or '') == wanted:
                    return item
        return None

    @classmethod
    def _playlist_needs_refresh(cls, content_id, cached_info, cache):
        if not cls._has_playlist(cached_info):
            return True
        age = cache.get_post_player_age(content_id)
        if age is None or age >= cls.TRUSTED_PLAYER_TTL:
            return True
        if age < cls.INTERACTIVE_PLAYER_TTL:
            return False
        try:
            return FilmixPrewarm._listing_ahead_of_playlist(
                cls._listing_item(cache, content_id), cached_info)
        except Exception:
            return True

    @classmethod
    def _refresh_post_in_background(cls, content_id, cached_info):
        import threading

        def _run():
            try:
                fresh = Filmix().post(content_id, force_refresh=True)
                if not (isinstance(fresh, dict) and cls._has_playlist(fresh)):
                    return
                worker_cache = FilmixCache(plugin.profile_dir)
                try:
                    before = FilmixCache.player_identity((cached_info or {}).get('player_links') or {})
                    merged = worker_cache.set_post_details(content_id, fresh, player_fresh=True,
                                                           preserve_richer_player=True)
                    after = FilmixCache.player_identity((merged or {}).get('player_links') or {})
                finally:
                    try:
                        worker_cache.close()
                    except Exception:
                        pass
                xbmc.log('[plugin.video.filmix] POST_PLAYLIST_REFRESH background post_id={0} changed={1}'.format(
                    content_id, int(after != before)), xbmc.LOGINFO)
                if after != before:
                    FilmixPrewarm(plugin).notify_player_topology_changed(content_id, source='interactive_directory')
                    # перерисовать, только если этот сериал ещё на экране
                    if '/serials/%s-' % content_id in (xbmc.getInfoLabel('Container.FolderPath') or ''):
                        xbmc.executebuiltin('Container.Refresh')
            except Exception as e:
                xbmc.log('[plugin.video.filmix] POST_PLAYLIST_REFRESH background failed post_id={0} err={1}'.format(
                    content_id, e), xbmc.LOGWARNING)

        threading.Thread(target=_run, name='FilmixPlaylistRefresh').start()

    @classmethod
    def _load_post_for_directory(cls, content_id, cache):
        cached_info = cache.get_post_details(content_id)
        content_info = cached_info
        needs_refresh = cls._playlist_needs_refresh(content_id, cached_info, cache)

        if needs_refresh and cls._has_playlist(cached_info):
            # Вход в сериал не ждёт сеть, когда плейлист уже есть: список строится из
            # сохранённого сразу, свежий запрашивается в фоне, и при новых сериях открытый
            # список перерисовывается. Раньше каждый вход стоял ~0,4 с на запросе к API
            # (.20, 20.11.2026, «Закон и порядок: Торонто»: open 0.97 с, requests=1).
            cls._refresh_post_in_background(content_id, cached_info)
            needs_refresh = False

        if needs_refresh:
            try:
                fresh_info = Filmix().post(content_id, force_refresh=True)
            except (FilmixError, simplemedia.WebClientError) as e:
                # A usable cached directory is preferable to an empty screen on
                # a transient API failure. Only notify when no playlist exists.
                if not cls._has_playlist(cached_info):
                    plugin.notify_error(e)
                try:
                    xbmc.log('[plugin.video.filmix] POST_PLAYLIST_REFRESH failed post_id={0} cached={1} err={2}'.format(
                        content_id, cls._playlist_log_summary(cached_info), e), xbmc.LOGWARNING)
                except Exception:
                    pass
            else:
                if isinstance(fresh_info, dict) and cls._has_playlist(fresh_info):
                    api_summary = cls._playlist_log_summary(fresh_info)
                    cached_identity = FilmixCache.player_identity((cached_info or {}).get('player_links') or {}) if isinstance(cached_info, dict) else {}
                    content_info = cache.set_post_details(
                        content_id, fresh_info, player_fresh=True,
                        preserve_richer_player=True)
                    used_identity = FilmixCache.player_identity((content_info or {}).get('player_links') or {}) if isinstance(content_info, dict) else {}
                    if used_identity != cached_identity:
                        try:
                            FilmixPrewarm(plugin).notify_player_topology_changed(content_id, source='interactive_directory')
                        except Exception as e:
                            xbmc.log('[plugin.video.filmix] PLAYER_TOPOLOGY_NOTIFY failed post_id={0} err={1}'.format(content_id, e), xbmc.LOGWARNING)
                    decision = ('merged_richer_cache'
                                if FilmixCache.playlist_summary(content_info) != FilmixCache.playlist_summary(fresh_info)
                                else 'accepted_api')
                    try:
                        xbmc.log('[plugin.video.filmix] POST_PLAYLIST_REFRESH ok post_id={0} decision={1} cached={2} api={3} used={4}'.format(
                            content_id, decision, cls._playlist_log_summary(cached_info),
                            api_summary, cls._playlist_log_summary(content_info)), xbmc.LOGINFO)
                    except Exception:
                        pass
                elif cls._has_playlist(cached_info):
                    # Do not replace a working playlist with an incomplete API
                    # response. Keep it stale so the next open retries.
                    content_info = cached_info
                    try:
                        xbmc.log('[plugin.video.filmix] POST_PLAYLIST_REFRESH rejected post_id={0} cached={1} fresh={2}'.format(
                            content_id, cls._playlist_log_summary(cached_info),
                            cls._playlist_log_summary(fresh_info)), xbmc.LOGWARNING)
                    except Exception:
                        pass
                else:
                    content_info = fresh_info
                    if isinstance(fresh_info, dict):
                        cache.set_post_details(content_id, fresh_info, player_fresh=False)
        else:
            try:
                xbmc.log('[plugin.video.filmix] POST_PLAYLIST_CACHE hit post_id={0} age={1} ttl={2} playlist={3}'.format(
                    content_id, cache.get_post_player_age(content_id),
                    cls.TRUSTED_PLAYER_TTL,
                    cls._playlist_log_summary(cached_info)), xbmc.LOGINFO)
            except Exception:
                pass

        try:
            content_info, touched = apply_manual_override(content_info, post_id=content_id)
            if touched:
                cache.set_resolved_ids(content_id, content_info)
        except Exception:
            pass
        return content_info

    @classmethod
    def _load_post_for_playback(cls, content_id):
        """Avoid a duplicate post request immediately after opening episodes.

        Player URLs are reused only for a very short window. Outside it, playback
        keeps the existing force-refresh behavior. A cached player is also an
        emergency fallback when Filmix is temporarily unreachable.
        """
        cache = FilmixCache(plugin.profile_dir)
        cached = cache.get_post_details(content_id)
        age = cache.get_post_player_age(content_id)
        if FilmixCache._has_playback_data(cached) and age is not None and age <= 30:
            try:
                xbmc.log('[plugin.video.filmix] PLAY_POST_CACHE hit post_id={0} age={1}'.format(
                    content_id, age), xbmc.LOGINFO)
            except Exception:
                pass
            return cached, cache
        try:
            fresh = Filmix().post(content_id, force_refresh=True)
        except (FilmixError, simplemedia.WebClientError):
            if FilmixCache._has_playback_data(cached):
                try:
                    xbmc.log('[plugin.video.filmix] PLAY_POST_CACHE fallback post_id={0} age={1}'.format(
                        content_id, age), xbmc.LOGWARNING)
                except Exception:
                    pass
                return cached, cache
            raise
        if isinstance(fresh, dict):
            cached_identity = FilmixCache.player_identity((cached or {}).get('player_links') or {}) if isinstance(cached, dict) else {}
            fresh = cache.set_post_details(content_id, fresh, player_fresh=True,
                                           preserve_richer_player=True)
            used_identity = FilmixCache.player_identity((fresh or {}).get('player_links') or {}) if isinstance(fresh, dict) else {}
            if used_identity != cached_identity:
                try:
                    FilmixPrewarm(plugin).notify_player_topology_changed(content_id, source='interactive_playback')
                except Exception:
                    pass
        return fresh, cache

    @classmethod
    def post_seasons(cls, content_name):
        content = Utilities.get_content_params(content_name)
        cache = FilmixCache(plugin.profile_dir)
        content_id = content.get('id')
        content_info = cls._load_post_for_directory(content_id, cache)

        if not cls._has_playlist(content_info):
            category = content_name
            if isinstance(content_info, dict):
                category = content_info.get('title') or category
            result = {'items': cls._empty_directory(),
                      'content': 'seasons',
                      'category': category,
                      'sort_methods': xbmcplugin.SORT_METHOD_NONE,
                      }
            plugin.create_directory(**result)
            return

        title = content_info.get('title') or content_name
        translation = cls._get_current_tvshow_translation(content_info, cache)
        category = title
        if translation:
            category = '{0} · {1}'.format(title, _('Voice: {0}').format(translation))

        result = {'items': cls._list_serial_seasons(content_info, active_translation=translation),
                  'content': 'seasons',
                  'category': category,
                  'sort_methods': xbmcplugin.SORT_METHOD_TITLE,
                  }

        plugin.create_directory(**result)

    @classmethod
    def _get_current_tvshow_translation(cls, item, cache=None, translations=None):
        try:
            if not isinstance(item, dict):
                return ''
            if cache is None:
                cache = FilmixCache(plugin.profile_dir)
            if translations is None:
                player_links = cls._get_player_links(item)
                translations = Utilities.get_tvshow_translations(player_links) or {}
            if not translations:
                return ''
            translation = cache.get_post_translation(item.get('id'))
            if translation is None or translations.get(translation) is None:
                translation = cls._get_default_translation(translations)
            if translation and translations.get(translation) is not None:
                return translation
        except Exception:
            pass
        return ''

    @classmethod
    def _translation_row_properties(cls, item, translation, translations):
        """Свойства строки для кнопки выбора озвучки в скине.

        09.09.2026 владелец: «выбор озвучки надо перенести из контекстного меню
        в кнопку в левой нижней части экрана списка эпизодов». Кнопке нужны три
        вещи, и взять их она может только из строки: номер поста (для адреса
        select_translation), название текущей озвучки (для надписи) и сколько
        озвучек всего (кнопка не нужна, если выбирать не из чего).
        """
        try:
            post_id = (item or {}).get('id') if isinstance(item, dict) else ''
            # Считаются только РАЗНЫЕ НЕПУСТЫЕ названия. 09.09.2026 владелец:
            # «когда у сериала нет выбора озвучек … кнопка вообще не должна
            # появляться», и на его снимке («Хождение по мукам») кнопка стояла с
            # пустым названием - значит счёт брал и то, у чего имени нет.
            names = []
            for name in (translations or {}):
                clean = '{0}'.format(name or '').strip()
                if clean and clean not in names:
                    names.append(clean)
            if not post_id or len(names) <= 1:
                return {}
            current = '{0}'.format(translation or '').strip() or names[0]
            return {
                'FilmixPostID': '{0}'.format(post_id),
                'FilmixTranslation': current,
                'FilmixTranslations': '{0}'.format(len(names)),
            }
        except Exception:
            return {}

    @classmethod
    def _notify_translation_hint_once(cls, item, translation, route=''):
        """Show a non-focusable one-time-per-session hint for voice switching.

        This is intentionally a standard Kodi notification, not a ListItem: it
        cannot steal focus from Season/Episode rows and it does not become part
        of skin layouts.  Window(10000) properties live for the Kodi session,
        which is enough to avoid repeating the hint every time a route process
        is spawned.
        """
        try:
            if not translation:
                return
            post_id = item.get('id') if isinstance(item, dict) else ''
            if not post_id:
                return
            key = 'plugin.video.filmix.translation_hint_shown.{0}'.format(post_id)
            window = xbmcgui.Window(10000)
            if window.getProperty(key) == '1':
                return
            window.setProperty(key, '1')
            plugin.dialog_notification_info('', _('Voice: {0}. Change it from the context menu.').format(translation), 5000, False)
            try:
                xbmc.log('[plugin.video.filmix] TRANSLATION_HINT_NOTIFY post_id={0} route={1} translation={2}'.format(post_id, route, translation), xbmc.LOGINFO)
            except Exception:
                pass
        except Exception:
            pass


    @classmethod
    def _list_serial_seasons(cls, item, active_translation=None):
        use_atl_names = Utilities.use_atl_names()
        cache = FilmixCache(plugin.profile_dir)

        try:
            player_links = cls._get_player_links(item)
            translations = Utilities.get_tvshow_translations(player_links) or {}
        except Exception as e:
            simpleplugin.log_exception(e)
            return

        if not translations:
            return

        translation = active_translation or cls._get_current_tvshow_translation(item, cache, translations=translations)

        if not translation or translations.get(translation) is None:
            return

        season_parent_item = cls._validate_tv_identity_for_episode_lookup(
            cls._merge_resolved_ids_for_episode_lookup(item, cache), cache, route='seasons')

        # 09.09.2026 владелец: «убрать уведомление при входе в список эпизодов о
        # смене озвучки нажатием на контекстменю». Уведомление больше не нужно:
        # выбор озвучки стоит кнопкой на экране (скин читает свойства строк
        # FilmixPostID / FilmixTranslation / FilmixTranslations, которые
        # ставятся ниже).

        translation_seasons = translations.get(translation) or []

        # pre-warm metadata for the first visible season inside the
        # already-open show route.  It preserves direct-play episode rows and
        # avoids doing the same TMDb season request during the subsequent
        # /episodes/ route.  This is bounded to one season and cached for a week.
        try:
            if translation_seasons:
                first_season = (translation_seasons[0] or {}).get('season') if isinstance(translation_seasons[0], dict) else None
                if first_season:
                    cls._tmdb_episode_metadata_map(season_parent_item, first_season)
        except Exception:
            pass

        for season_item in translation_seasons:
            try:
                season_info = SeasonInfo(season_parent_item)
                season_info.set_season_info(translation, season_item.get('season'), season_item.get('episodes'))
                url = cls._get_listitem_url(season_info, use_atl_names)
                listitem = ListItem(season_info)
                listitem.set_url(url)
                season_props = {
                    'ContentLookup': 'false', 'content_lookup': 'false',
                    'IsPlayable': 'false', 'isplayable': 'false',
                    'IsFolder': 'true', 'isfolder': 'true',
                    'FilmixSeasonRow': 'true'
                }
                # Те же свойства, что и у серий: кнопка выбора озвучки нужна и
                # на экране сезонов (_translation_row_properties).
                season_props.update(
                    cls._translation_row_properties(item, translation, translations))
                listitem.set_properties(season_props)
                if isinstance(season_parent_item, dict) and season_parent_item.get('_filmix_identity_rejected'):
                    listitem.set_properties({
                        'FilmixIdentityRejected': 'true',
                        'FilmixRejectedTmdbID': str(season_parent_item.get('_filmix_rejected_tmdb_id') or ''),
                        'SublimeMetadataLookup': 'false',
                        'NoExternalMetadata': 'true'
                    })
                cls._apply_local_state(listitem, season_info, item, cache)
                listitem.set_context_menu(cls._get_context_menu(season_parent_item, season_info, cache))
                yield listitem.get_item()
            except Exception as e:
                simpleplugin.log_exception(e)
                continue

    @classmethod
    def _merge_resolved_ids_for_episode_lookup(cls, item, cache=None):
        """Merge trusted cached TV ids into a post dict before episode TMDb season lookup.

        2.2.59.23: some post_details rows do not contain resolved_tmdb_id,
        although the same post_id already has a valid TV mapping in resolved_ids.
        Without this merge, episode rows are built without real episode metadata and
        the skin falls back to the parent show plot for every episode.
        """
        if not isinstance(item, dict):
            return item
        try:
            post_id = item.get('id') or item.get('post_id')
            if not post_id:
                return item
            if cache is None:
                cache = FilmixCache(plugin.profile_dir)
            resolved = cache.get_resolved_ids(post_id) or {}
            if not isinstance(resolved, dict) or not resolved:
                return item
            r_type = resolved.get('resolved_tmdb_type') or resolved.get('tmdb_type')
            if r_type and str(r_type).lower() not in ('tv', 'show', 'series', 'tvshow'):
                try:
                    xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: skip post_id={0} reason=resolved_wrong_type type={1}'.format(post_id, r_type), xbmc.LOGINFO)
                except Exception:
                    pass
                return item
            r_tmdb = resolved.get('resolved_tmdb_id') or resolved.get('tmdb_id') or resolved.get('tmdb')
            r_imdb = resolved.get('resolved_imdb_id') or resolved.get('imdb_id') or resolved.get('imdb')
            if not r_tmdb and not r_imdb:
                return item
            if r_tmdb:
                try:
                    resolver = TMDbResolver(timeout=5)
                    if getattr(resolver, 'enabled', False):
                        details = resolver._details(str(r_tmdb), 'tv') or {}
                        # validate the episode/season identity against the
                        # post's ORIGINAL Filmix catalog country, not the season item's
                        # (which can be overwritten by a previous wrong resolution). This
                        # rejects a US show resolved for an HK series ("Сезон" -> 277439)
                        # so its fanart cannot become the season-list background.
                        _src_isos = set()
                        try:
                            _pd = (cache.get_post_details(post_id) or {}) if cache else {}
                            for _k in ('source_countries', 'filmix_countries', 'countries', 'country'):
                                _v = _pd.get(_k)
                                if isinstance(_v, (list, tuple, set)):
                                    for _e in _v:
                                        _src_isos |= _country_text_to_isos(_e)
                                elif _v:
                                    _src_isos |= _country_text_to_isos(_v)
                        except Exception:
                            _src_isos = set()
                        valid, reject_reason = TMDbResolver.validate_resolved_match(
                            item, resolved, details=details, tmdb_type='tv',
                            source_countries=(_src_isos or None))
                        if not valid:
                            miss = {
                                '_tmdb_miss_at': FilmixCache._ts(),
                                '_tmdb_miss_type': 'tv',
                                '_tmdb_miss_build': FilmixPrewarm.TMDB_MISS_BUILD,
                                '_tmdb_rejected_tmdb_id': str(r_tmdb),
                                '_tmdb_reject_reason': reject_reason or 'identity_validation_failed'
                            }
                            cache.set_resolved_ids(post_id, miss)
                            xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: reject cached resolved_ids post_id={0} tmdb={1} reason={2}'.format(post_id, r_tmdb, miss.get('_tmdb_reject_reason')), xbmc.LOGINFO)
                            return item
                except Exception as e:
                    try:
                        xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: cached id validation skipped post_id={0} tmdb={1} err={2}'.format(post_id, r_tmdb, e), xbmc.LOGDEBUG)
                    except Exception:
                        pass
            merged = dict(item)
            changed = False
            if r_tmdb and not (merged.get('resolved_tmdb_id') or merged.get('tmdb_id') or merged.get('tmdb')):
                merged['resolved_tmdb_id'] = str(r_tmdb)
                merged['tmdb_id'] = str(r_tmdb)
                changed = True
            if r_imdb and not (merged.get('resolved_imdb_id') or merged.get('imdb_id') or merged.get('imdb')):
                merged['resolved_imdb_id'] = str(r_imdb)
                merged['imdb_id'] = str(r_imdb)
                changed = True
            if not merged.get('resolved_tmdb_type'):
                merged['resolved_tmdb_type'] = 'tv'
                changed = True
            if changed:
                try:
                    xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: merged resolved_ids post_id={0} tmdb={1} imdb={2}'.format(post_id, merged.get('resolved_tmdb_id') or merged.get('tmdb_id'), merged.get('resolved_imdb_id') or merged.get('imdb_id')), xbmc.LOGINFO)
                except Exception:
                    pass
                return merged
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: resolved merge failed post_id={0} err={1}'.format(item.get('id') or item.get('post_id'), e), xbmc.LOGDEBUG)
            except Exception:
                pass
        return item

    @staticmethod
    def _episode_tmdb_cache_key(tmdb_id, season_num):
        try:
            return 'episode_tmdb_meta|{0}|{1}|ru-en'.format(str(int(str(tmdb_id))), int(season_num))
        except Exception:
            return ''

    @staticmethod
    def _episode_tmdb_cache_get(cache, key, max_age=604800):
        try:
            if not cache or not key:
                return None
            row = cache.get_control_flag(key)
            if not row:
                return None
            updated_ts = 0
            try:
                updated_ts = int(row.get('updated_ts') or 0)
            except Exception:
                updated_ts = 0
            if updated_ts and time.time() - updated_ts > max_age:
                return None
            payload = json.loads(row.get('flag_value') or '{}')
            rows = payload.get('rows') if isinstance(payload, dict) else None
            if isinstance(rows, dict):
                return rows
        except Exception:
            pass
        return None

    @staticmethod
    def _episode_tmdb_cache_set(cache, key, rows):
        try:
            if cache and key and isinstance(rows, dict) and rows:
                cache.set_control_flag(key, json.dumps({'ts': int(time.time()), 'rows': rows}, ensure_ascii=False, sort_keys=True))
        except Exception:
            pass

    @classmethod
    def _resolve_series_identity_for_episodes(cls, item):
        """Resolve a series' TMDb id from an opened /episodes/ directory.

        Only for a post that has no identity yet and no recent recorded miss -
        an existing `_tmdb_miss_at` is respected exactly as the navigation path
        respects it, so a series TMDb genuinely does not have is not re-queried
        on every open. Returns the id as a string, or None.
        """
        try:
            post_id = item.get('id') or item.get('post_id')
            if not post_id:
                return None
            cache = FilmixCache(plugin.profile_dir)
            resolved_ids = cache.get_resolved_ids(post_id) or {}
            if resolved_ids.get('resolved_tmdb_id'):
                return str(resolved_ids.get('resolved_tmdb_id'))
            try:
                miss_at = int(resolved_ids.get('_tmdb_miss_at') or 0)
            except Exception:
                miss_at = 0
            # A miss recorded by an older build was decided by rules this build
            # no longer applies, so it is not evidence any more - the same
            # build-marker rule the navigation and prewarm paths already use.
            if str(resolved_ids.get('_tmdb_miss_build') or '') != FilmixPrewarm.TMDB_MISS_BUILD:
                miss_at = 0
            if miss_at and (FilmixCache._ts() - miss_at) < int(FilmixPrewarm.TMDB_MISS_TTL):
                xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: identity resolve skipped post_id={0} reason=recent_miss'.format(post_id), xbmc.LOGINFO)
                return None
            resolver = TMDbResolver(timeout=6)
            if not getattr(resolver, 'enabled', False):
                return None
            payload = dict(item or {})
            # Only real resolved fields. The bookkeeping keys are internal, and
            # passing them in made the resolver treat the `_tmdb_miss_at`
            # timestamp as an id: measured on <коробка>, post 8294 "resolved"
            # to tmdb=1786859909, which then failed validation because no such
            # show exists.
            payload.update({k: v for k, v in resolved_ids.items()
                            if v and not str(k).startswith('_')})
            new_ids = _resolve_with_skin(resolver, payload, post_id, 'tv') or {}
            tmdb_id = new_ids.get('resolved_tmdb_id')
            try:
                # TMDb ids are small; anything of unix-timestamp size is a stray
                # internal value, never a show.
                tmdb_id = str(int(str(tmdb_id))) if 0 < int(str(tmdb_id)) < 50000000 else None
            except Exception:
                tmdb_id = None
            if tmdb_id:
                resolved_ids.update(new_ids)
                resolved_ids.pop('_tmdb_miss_at', None)
                resolved_ids.pop('_tmdb_miss_type', None)
                cache.set_resolved_ids(post_id, resolved_ids)
                xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: identity resolved on open post_id={0} title={1} tmdb={2}'.format(
                    post_id, item.get('title'), tmdb_id), xbmc.LOGINFO)
                return str(tmdb_id)
            resolved_ids['_tmdb_miss_at'] = FilmixCache._ts()
            resolved_ids['_tmdb_miss_type'] = 'tv'
            resolved_ids['_tmdb_miss_build'] = FilmixPrewarm.TMDB_MISS_BUILD
            if new_ids.get('_tmdb_miss_reason'):
                resolved_ids['_tmdb_reject_reason'] = new_ids.get('_tmdb_miss_reason')
            cache.set_resolved_ids(post_id, resolved_ids)
            xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: identity miss on open post_id={0} title={1} reason={2}'.format(
                post_id, item.get('title'), new_ids.get('_tmdb_miss_reason') or 'no_match'), xbmc.LOGINFO)
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: identity resolve failed post_id={0} err={1}'.format(
                    (item or {}).get('id'), e), xbmc.LOGWARNING)
            except Exception:
                pass
        return None

    @classmethod
    def _tmdb_episode_metadata_map(cls, item, season):
        """Return TMDb episode still/plot/date data for one season.

        2.2.59.20: episode directories remain direct-play plugin rows, but the
        skin/TMDbHelper needs real episode metadata and still images. Fetch one
        TMDb season payload only when the user opens an episode directory, never
        from Home widgets.
        """
        result = {}
        # source-only mode remains active for Home/widgets and background
        # enrichment, but an already-open /episodes/ directory must publish native
        # Kodi ListItem still/thumb/plot before the first skin render. This function
        # is only called from post_episodes(), never from Home widget rendering.
        try:
            if not isinstance(item, dict):
                return result
            tmdb_id = (item.get('resolved_tmdb_id') or item.get('tmdb_id') or item.get('tmdb'))
            tmdb_type = item.get('resolved_tmdb_type') or item.get('tmdb_type')
            if tmdb_type and str(tmdb_type).lower() not in ('tv', 'show', 'series', 'tvshow'):
                try:
                    xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: skip post_id={0} reason=wrong_type type={1}'.format(item.get('id'), tmdb_type), xbmc.LOGINFO)
                except Exception:
                    pass
                return result
            if not tmdb_id:
                try:
                    _, tmdb_id = PostInfo(item)._resolved_ids()
                except Exception:
                    tmdb_id = None
            if not tmdb_id:
                # Source-only mode never builds resolved_ids at all: _list_items()
                # no longer constructs a resolver on a list route at all, so
                # a series can sit in the catalogue with no identity and this
                # function skipped on every open. Measured on <коробка> with
                # post 157139 «Джек Ричер» had no resolved_ids row
                # whatsoever, so its episodes stayed "Серия N" with the show
                # poster and no still. An episode directory the user has already
                # opened is the one place this file is allowed to call TMDb in
                # source-only mode - the same exemption the rest of this function
                # relies on - so resolve the series here, once, and store it like
                # any other resolution.
                tmdb_id = cls._resolve_series_identity_for_episodes(item)
            if not tmdb_id:
                try:
                    xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: skip post_id={0} reason=no_tmdb_id season={1}'.format(item.get('id'), season), xbmc.LOGINFO)
                except Exception:
                    pass
                return result
            try:
                tmdb_id = str(int(str(tmdb_id)))
            except Exception:
                return result
            # a stale TMDb id can be embedded directly in post_details,
            # not only in resolved_ids. Validate that direct id before reading a
            # cached TMDb season payload, otherwise an already rejected identity can
            # still leak wrong episode rows/art.
            try:
                resolver_probe = TMDbResolver(timeout=5)
                if getattr(resolver_probe, 'enabled', False):
                    probe = dict(item)
                    probe['resolved_tmdb_id'] = tmdb_id
                    probe['resolved_tmdb_type'] = 'tv'
                    details_probe = resolver_probe._details(tmdb_id, 'tv') or {}
                    valid_probe, reject_probe = TMDbResolver.validate_resolved_match(
                        item, probe, details=details_probe, tmdb_type='tv',
                        source_countries=(cls._source_country_isos(item, FilmixCache(plugin.profile_dir)) or None))
                    if not valid_probe:
                        try:
                            FilmixCache(plugin.profile_dir).set_resolved_ids(item.get('id'), {
                                '_tmdb_miss_at': FilmixCache._ts(),
                                '_tmdb_miss_type': 'tv',
                                '_tmdb_miss_build': FilmixPrewarm.TMDB_MISS_BUILD,
                                '_tmdb_rejected_tmdb_id': str(tmdb_id),
                                '_tmdb_reject_reason': reject_probe or 'direct_identity_validation_failed'
                            })
                        except Exception:
                            pass
                        xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: reject direct tmdb post_id={0} tmdb={1} reason={2}'.format(
                            item.get('id'), tmdb_id, reject_probe or 'direct_identity_validation_failed'), xbmc.LOGINFO)
                        return result
            except Exception as e:
                try:
                    xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: direct id validation skipped post_id={0} tmdb={1} err={2}'.format(item.get('id'), tmdb_id, e), xbmc.LOGDEBUG)
                except Exception:
                    pass
            try:
                season_num = int(str(season))
            except Exception:
                season_num = 1
            # audit/refactor: cache complete season episode
            # metadata.  This removes repeated TMDb season calls when the user
            # opens the same season after the show/open route and shortens the
            # interval where Kodi can keep the previous episode thumbnails on
            # screen while the new plugin directory is resolving.
            cache = FilmixCache(plugin.profile_dir)
            cache_key = cls._episode_tmdb_cache_key(tmdb_id, season_num)
            cached = cls._episode_tmdb_cache_get(cache, cache_key)
            if cached:
                try:
                    xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: cache hit tmdb={0} season={1} rows={2}'.format(tmdb_id, season_num, len(cached)), xbmc.LOGINFO)
                except Exception:
                    pass
                return cached
            resolver = TMDbResolver(timeout=6)
            if not resolver.enabled:
                return result
            data = resolver._get('/tv/{0}/season/{1}'.format(tmdb_id, season_num), {}) or {}
            # if Russian TMDb has no episode overview/name, keep
            # the Russian request as primary but fetch an English season payload
            # as a fallback for missing episode plots/names. Empty episode plots
            # in the skin are worse than an English fallback.
            en_by_ep = {}
            try:
                needs_en = False
                for _ep in data.get('episodes') or []:
                    if isinstance(_ep, dict) and not (_ep.get('overview') or '').strip():
                        needs_en = True
                        break
                if needs_en:
                    en_data = resolver._get('/tv/{0}/season/{1}'.format(tmdb_id, season_num), {'language': 'en-US'}) or {}
                    for _ep in en_data.get('episodes') or []:
                        try:
                            _no = int(_ep.get('episode_number'))
                        except Exception:
                            continue
                        if isinstance(_ep, dict):
                            en_by_ep[_no] = _ep
            except Exception:
                en_by_ep = {}
            for ep in data.get('episodes') or []:
                if not isinstance(ep, dict):
                    continue
                try:
                    ep_no = int(ep.get('episode_number'))
                except Exception:
                    continue
                still = TMDbResolver._tmdb_image_url(ep.get('still_path'))
                row = {}
                en_ep = en_by_ep.get(ep_no) or {}
                ep_name = ep.get('name') or en_ep.get('name')
                ep_overview = ep.get('overview') or en_ep.get('overview')
                if ep_name:
                    row['name'] = ep_name
                    row['title'] = ep_name
                if ep_overview:
                    row['plot'] = ep_overview
                    row['description'] = ep_overview
                    row['short_story'] = ep_overview
                    if not ep.get('overview') and en_ep.get('overview'):
                        row['plot_language'] = 'en'
                if ep.get('air_date'):
                    row['aired'] = ep.get('air_date')
                    row['premiered'] = ep.get('air_date')
                    row['air_date'] = ep.get('air_date')
                if still:
                    row['still'] = still
                    row['thumb'] = still
                    row['image'] = still
                    row['fanart'] = still
                    row['landscape'] = still
                    row['backdrop'] = still
                if row:
                    result[str(ep_no)] = row
            if result:
                valid_rows, row_reason = TMDbResolver.validate_season_episode_rows(item, season_num, len(result))
                if not valid_rows:
                    try:
                        cache.set_resolved_ids(item.get('id'), {
                            '_tmdb_miss_at': FilmixCache._ts(),
                            '_tmdb_miss_type': 'tv',
                            '_tmdb_miss_build': FilmixPrewarm.TMDB_MISS_BUILD,
                            '_tmdb_rejected_tmdb_id': str(tmdb_id),
                            '_tmdb_reject_reason': row_reason or 'episode_rows_validation_failed'
                        })
                    except Exception:
                        pass
                    xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: reject tmdb={0} post_id={1} season={2} rows={3} reason={4}'.format(tmdb_id, item.get('id'), season_num, len(result), row_reason), xbmc.LOGINFO)
                    return {}
                try:
                    cls._episode_tmdb_cache_set(cache, cache_key, result)
                except Exception:
                    pass
                xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: post_id={0} tmdb={1} season={2} rows={3}'.format(item.get('id'), tmdb_id, season_num, len(result)), xbmc.LOGINFO)
            else:
                try:
                    xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: miss post_id={0} tmdb={1} season={2}'.format(item.get('id'), tmdb_id, season_num), xbmc.LOGINFO)
                except Exception:
                    pass
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] EpisodeTMDbInfo: failed post_id={0} season={1} err={2}'.format(item.get('id') if isinstance(item, dict) else '', season, e), xbmc.LOGDEBUG)
            except Exception:
                pass
        return result

    @classmethod
    def post_episodes(cls, content_name):
        content = Utilities.get_content_params(content_name)
        cache = FilmixCache(plugin.profile_dir)
        content_id = content.get('id')
        serial_info = cls._load_post_for_directory(content_id, cache)

        if not cls._has_playlist(serial_info):
            category = content_name
            if isinstance(serial_info, dict):
                category = serial_info.get('title') or category
            result = {'items': cls._empty_directory(),
                      'content': 'episodes',
                      'category': category,
                      'sort_methods': xbmcplugin.SORT_METHOD_NONE,
                      }
            plugin.create_directory(**result)
            return

        season = plugin.params.s
        translation = plugin.params.get('t')

        # The rows are already in episode order and the listing declares
        # SORT_METHOD_NONE below, so nothing here decides a sort method.
        result = {'items': cls._list_episodes_items(serial_info, season, translation),
                  # expose real episode metadata to the skin/TMDbHelper,
                  # while each row keeps explicit direct-play flags.
                  'content': 'episodes',
                  'category': ' / '.join([serial_info.get('title') or content_name, '{0} {1}'.format(_('Season'), season)]),
                  'sort_methods': xbmcplugin.SORT_METHOD_NONE,
                  }

        plugin.create_directory(**result)

    @classmethod
    def _list_episodes_items(cls, item, season=None, translation=None):
        use_atl_names = Utilities.use_atl_names()
        cache = FilmixCache(plugin.profile_dir)
        episode_parent_item = cls._validate_tv_identity_for_episode_lookup(
            cls._merge_resolved_ids_for_episode_lookup(item, cache), cache, route='episodes')

        try:
            season_translation = cls._get_season_translation(item, season, translation)
        except Exception as e:
            simpleplugin.log_exception(e)
            return

        if season_translation is None:
            return

        # Озвучка для кнопки на экране: её номер поста, название текущей озвучки
        # и сколько их всего. Уведомление про контекстное меню убрано
        # 09.09.2026 по требованию владельца - выбор стоит кнопкой.
        dub_props = {}
        try:
            player_links = cls._get_player_links(item)
            translations = Utilities.get_tvshow_translations(player_links) or {}
            current_translation = translation or cls._get_current_tvshow_translation(item, cache, translations=translations)
            dub_props = cls._translation_row_properties(item, current_translation, translations)
        except Exception:
            dub_props = {}

        episode_tmdb = cls._tmdb_episode_metadata_map(episode_parent_item, season)

        # отметки всех серий поста одним запросом: построчно это было три SELECT на серию
        # (_get_episode_stats и пункт меню), отметки те же - строки watched_state этого поста
        watched_map = None
        _post = {}
        try:
            _post = (episode_parent_item if isinstance(episode_parent_item, dict) else item) or {}
            if _post.get('id'):
                watched_map = cache.get_watched_states_many([_post.get('id')])
        except Exception:
            watched_map = None

        if isinstance(season_translation, list):
            iterator = enumerate(season_translation)
        else:
            iterator = iteritems(season_translation)

        for episode, episode_data in iterator:
            try:
                episode_key = cls._normalize_int_string(episode)
                lookup_key = cls._canonical_episode_number(item, season, episode)
                tmdb_episode = episode_tmdb.get(str(lookup_key)) or episode_tmdb.get(str(episode_key)) or {}
                if isinstance(episode_parent_item, dict) and episode_parent_item.get('_filmix_identity_rejected'):
                    episode_data = cls._strip_episode_provider_art(episode_data)
                    tmdb_episode = {}
                if isinstance(episode_data, dict) and tmdb_episode:
                    merged_episode = dict(tmdb_episode)
                    merged_episode.update(episode_data)
                    # Keep TMDb still/art even when Filmix episode item lacks it.
                    for _art_key in ('still', 'thumb', 'image', 'fanart', 'landscape', 'backdrop'):
                        if tmdb_episode.get(_art_key) and not merged_episode.get(_art_key):
                            merged_episode[_art_key] = tmdb_episode.get(_art_key)
                    episode_data = merged_episode
                elif tmdb_episode:
                    episode_data = dict(tmdb_episode)
                # описание серии: русское, иначе английское (TMDb), иначе описание сериала
                # (владелец, 21.11.2026)
                try:
                    if isinstance(episode_data, dict) and not str(episode_data.get('plot') or '').strip():
                        _show_plot = ''
                        if isinstance(episode_parent_item, dict):
                            for _k in ('short_story', 'plot', 'description', 'story'):
                                _show_plot = str(episode_parent_item.get(_k) or '').strip()
                                if _show_plot:
                                    break
                        if _show_plot:
                            episode_data = dict(episode_data)
                            episode_data['plot'] = _show_plot
                            episode_data['description'] = _show_plot
                            episode_data['short_story'] = _show_plot
                except Exception:
                    pass
                episode_info = VideoInfo(episode_parent_item, atl_names=use_atl_names)
                episode_info.set_episode_info(season, episode, translation, episode_data)
                listitem = ListItem(episode_info)
                listitem.set_force_direct_play(True)
                url = cls._get_listitem_url(episode_info, use_atl_names)
                listitem.set_url(url)
                episode_props = {'IsPlayable': 'true', 'isplayable': 'true',
                                 'IsFolder': 'false', 'isfolder': 'false',
                                 'ForceDirectPlay': 'true',
                                 'FilmixDirectEpisode': 'true',
                                 'ContentLookup': 'false', 'content_lookup': 'false',
                                 'dbid': '', 'DBID': ''}
                episode_props.update(dub_props)
                listitem.set_properties(episode_props)
                try:
                    xbmc.log('[plugin.video.filmix] EPISODE_DIRECT_PLAY_ITEM post_id={0} s={1} e={2} url={3}'.format(episode_info.post_id, season, episode, url), xbmc.LOGDEBUG)
                except Exception:
                    pass
                _map = watched_map if str(episode_info.post_id) == str(_post.get('id')) else None
                cls._apply_local_state(listitem, episode_info, episode_parent_item, cache, watched_map=_map)
                listitem.set_context_menu(cls._get_context_menu(episode_parent_item, episode_info, cache, watched_map=_map))
                yield listitem.get_item()
            except Exception as e:
                simpleplugin.log_exception(e)
                continue


    @staticmethod
    def _parse_resume_seconds(value):
        if value in [None, '', 'None']:
            return 0.0
        try:
            if isinstance(value, (int, float)):
                return float(value)
        except Exception:
            pass
        text = str(value).strip()
        if not text:
            return 0.0
        text = text.replace(',', '.')
        try:
            return float(text)
        except Exception:
            pass
        parts = text.split(':')
        try:
            parts = [float(p or 0) for p in parts]
        except Exception:
            return 0.0
        if len(parts) == 3:
            return parts[0] * 3600.0 + parts[1] * 60.0 + parts[2]
        if len(parts) == 2:
            return parts[0] * 60.0 + parts[1]
        return 0.0

    @staticmethod
    def _resume_choice_from_argv():
        # Kodi passes an explicit resume:true / resume:false decision to plugin
        # routes after its native Resume/Start-over dialog. the previous build collapsed
        # explicit resume:false and a missing flag into the same False value,
        # so Filmix could show its fallback dialog after Kodi had already asked.
        # Keep this tri-state: True = resume, False = start over, None = no Kodi decision.
        try:
            for arg in sys.argv[3:]:
                text = str(arg or '').strip().lower()
                if text.startswith('resume:'):
                    value = text.split(':', 1)[1].strip()
                    return value in ('true', '1', 'yes', 'resume')
        except Exception:
            pass
        return None


    @staticmethod
    def _current_route_url():
        try:
            base = sys.argv[0] if len(sys.argv) > 0 else ''
            query = sys.argv[2] if len(sys.argv) > 2 else ''
            if query:
                if not query.startswith('?'):
                    query = '?' + query
                return base + query
            return base
        except Exception:
            return ''

    @classmethod
    def _get_kodi_resume_point(cls, route_url, post_id=None, season=None, episode=None):
        # Kodi passes resume:true/false to plugins, but not the numeric bookmark.
        # Read Kodi's own MyVideos resume bookmark for the plugin URL, then the
        # service seeks after Filmix has selected translation and playback starts.
        for label in ('ListItem.ResumeTime', 'ListItem.StartOffset'):
            try:
                seconds = cls._parse_resume_seconds(xbmc.getInfoLabel(label))
                if seconds > 5.0:
                    return seconds, 0.0, 'infolabel:' + label
            except Exception:
                pass

        # 2.2.23 MOVIE_RESUME_STREAMMAP_DB_FORCE:
        # Directory/widget rows already use Utilities._filmix_lookup_resume_for_url(),
        # which reads Kodi's MyVideos bookmarks and also applies Filmix's
        # resolved-stream -> plugin-route map. Movie playback was still using only
        # direct plugin:// DB queries below. When Kodi saved the bookmark under the
        # resolved HTTP stream, widgets showed ResumeTag but play route returned
        # source=none/native_start_over. Reuse the same lookup here before the
        # direct SQL fallback. This is safe for episodes too because the helper
        # normalizes s/e keys and does not cross-apply one episode to another.
        try:
            mapped_pos, mapped_total, mapped_bm = _filmix_lookup_resume_for_url(route_url)
            if float(mapped_pos or 0.0) > 5.0:
                try:
                    xbmc.log('[plugin.video.filmix] ResumePlan: stream-map DB hit seek={0:.3f} total={1:.3f} bookmark={2} route={3}'.format(float(mapped_pos or 0.0), float(mapped_total or 0.0), mapped_bm, route_url), xbmc.LOGINFO)
                except Exception:
                    pass
                return float(mapped_pos or 0.0), float(mapped_total or 0.0), 'db:stream_map'
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] ResumePlan: stream-map lookup failed: {0}'.format(e), xbmc.LOGINFO)
            except Exception:
                pass

        try:
            import sqlite3
            from .kodi_state import newest_myvideos_db
            db_path = newest_myvideos_db()
            if not db_path:
                return 0.0, 0.0, 'db:no_myvideos'

            candidates = []
            if route_url:
                candidates.append(route_url)
            try:
                if route_url and '?' in route_url:
                    candidates.append(route_url.split('?', 1)[0])
            except Exception:
                pass

            # Safety: for episode routes, always keep matching strict even if
            # caller forgot to pass s/e explicitly.
            try:
                import re
                if route_url and (season in [None, ''] or episode in [None, '']):
                    m_s = re.search(r'[?&]s=([^&]+)', str(route_url))
                    m_e = re.search(r'[?&]e=([^&]+)', str(route_url))
                    if season in [None, ''] and m_s:
                        season = m_s.group(1)
                    if episode in [None, ''] and m_e:
                        episode = m_e.group(1)
            except Exception:
                pass

            # только чтение: база принадлежит Kodi (21.11.2026)
            conn = sqlite3.connect('file:%s?mode=ro' % db_path, uri=True, timeout=5)
            conn.row_factory = sqlite3.Row
            try:
                cur = conn.cursor()
                for candidate in candidates:
                    try:
                        cur.execute("""SELECT b.timeInSeconds AS pos, b.totalTimeInSeconds AS total,
                                              p.strPath AS pth, f.strFilename AS fn
                                       FROM bookmark b
                                       JOIN files f ON f.idFile = b.idFile
                                       JOIN path p ON p.idPath = f.idPath
                                       WHERE b.type = 1 AND (CASE WHEN f.strFilename LIKE 'plugin://%' THEN f.strFilename ELSE p.strPath || f.strFilename END) = ?
                                       ORDER BY b.idBookmark DESC LIMIT 1""", (candidate,))
                        row = cur.fetchone()
                    except Exception:
                        row = None
                    if row:
                        pos = float(row['pos'] or 0.0)
                        total = float(row['total'] or 0.0)
                        if pos > 5.0:
                            return pos, total, 'db:exact'

                like_parts = []
                if post_id:
                    like_parts.append('%/{0}-%/play/%'.format(post_id))
                    like_parts.append('%/{0}-%/play/?%'.format(post_id))
                    like_parts.append('%/{0}-%/play%'.format(post_id))
                if post_id:
                    where = ' OR '.join(["(CASE WHEN f.strFilename LIKE 'plugin://%' THEN f.strFilename ELSE p.strPath || f.strFilename END) LIKE ?" for _ in like_parts])
                    if where:
                        sql = """SELECT b.timeInSeconds AS pos, b.totalTimeInSeconds AS total,
                                        (CASE WHEN f.strFilename LIKE 'plugin://%' THEN f.strFilename ELSE p.strPath || f.strFilename END) AS url, b.idBookmark AS bid
                                 FROM bookmark b
                                 JOIN files f ON f.idFile = b.idFile
                                 JOIN path p ON p.idPath = f.idPath
                                 WHERE b.type = 1 AND ({0})
                                 ORDER BY b.idBookmark DESC LIMIT 20""".format(where)
                        try:
                            cur.execute(sql, like_parts)
                            rows = cur.fetchall() or []
                        except Exception:
                            rows = []
                        season_s = str(season) if season not in [None, ''] else None
                        episode_s = str(episode) if episode not in [None, ''] else None
                        for row in rows:
                            url = str(row['url'] or '')
                            if season_s is not None and ('s=' + season_s) not in url:
                                continue
                            if episode_s is not None and ('e=' + episode_s) not in url:
                                continue
                            pos = float(row['pos'] or 0.0)
                            total = float(row['total'] or 0.0)
                            if pos > 5.0:
                                if season_s is not None or episode_s is not None:
                                    return pos, total, 'db:episode'
                                return pos, total, 'db:movie'
            finally:
                try:
                    conn.close()
                except Exception:
                    pass
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] ResumePlan: db lookup failed: {0}'.format(e), xbmc.LOGINFO)
            except Exception:
                pass
        return 0.0, 0.0, 'none'

    @staticmethod
    def _format_resume_seconds(seconds):
        try:
            seconds = int(float(seconds or 0))
        except Exception:
            seconds = 0
        if seconds < 0:
            seconds = 0
        h = seconds // 3600
        m = (seconds % 3600) // 60
        s = seconds % 60
        if h:
            return '{0:d}:{1:02d}:{2:02d}'.format(h, m, s)
        return '{0:d}:{1:02d}'.format(m, s)

    RESTORE_FLAG = 'special://temp/filmix_restore_position.json'

    @classmethod
    def _caller_restores_position(cls, post_id, season=None, episode=None):
        """Включивший серию сам поставит место - Filmix не спрашивает и не мотает.

        Владелец 17.10.2026: после выкладки серия возвращалась двумя перемотками
        сразу - Filmix ставил точку из своей базы (624 с), инструмент выкладки -
        запомненную (653 с). «Убери перемотку из Filmix, оставь только один».
        Метку пишет tools/deploy.py скина прямо перед Player.Open: файл с
        post_id, s, e и сроком годности; Filmix стирает её при первом чтении,
        так что следующий обычный запуск ведёт себя как всегда. Адрес серии не
        меняется - иначе Kodi завёл бы под ним отдельную историю просмотра.
        """
        import os
        try:
            import xbmcvfs
            path = xbmcvfs.translatePath(cls.RESTORE_FLAG)
            if not os.path.exists(path):
                return False
            with open(path, encoding='utf-8') as handle:
                flag = json.load(handle)
            try:
                os.remove(path)
            except Exception:
                pass
            if float(flag.get('until') or 0) < time.time():
                return False
            same = (str(flag.get('post_id') or '') == str(post_id or '')
                    and str(flag.get('s') or '') == str(season or '')
                    and str(flag.get('e') or '') == str(episode or ''))
            xbmc.log('[plugin.video.filmix] ResumePlan: caller restores position={0} post_id={1} s={2} e={3}'.format(
                same, post_id, season, episode), xbmc.LOGINFO)
            return same
        except Exception as exc:
            try:
                xbmc.log('[plugin.video.filmix] ResumePlan: restore flag unreadable: {0}'.format(exc), xbmc.LOGINFO)
            except Exception:
                pass
            return False

    @classmethod
    def _resume_dialog_fallback(cls, seek, total=0.0, source=''):
        try:
            seek = float(seek or 0.0)
        except Exception:
            seek = 0.0
        if seek <= 5.0:
            return False
        try:
            label = cls._format_resume_seconds(seek)
            choice = xbmcgui.Dialog().contextmenu(['Возобновить с {0}'.format(label), 'Сначала'])
            if choice == 0:
                try:
                    xbmc.log('[plugin.video.filmix] ResumePromptFallback: resume seek={0:.3f} total={1:.3f} source={2}'.format(float(seek or 0.0), float(total or 0.0), source), xbmc.LOGINFO)
                except Exception:
                    pass
                return True
            try:
                xbmc.log('[plugin.video.filmix] ResumePromptFallback: start_over seek={0:.3f} total={1:.3f} source={2} choice={3}'.format(float(seek or 0.0), float(total or 0.0), source, choice), xbmc.LOGINFO)
            except Exception:
                pass
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] ResumePromptFallback: dialog failed seek={0:.3f} err={1}'.format(float(seek or 0.0), e), xbmc.LOGINFO)
            except Exception:
                pass
        return False

    @classmethod
    def play_video(cls, content_name):
        content = Utilities.get_content_params(content_name)
        resume_choice = cls._resume_choice_from_argv()
        resume_requested = (resume_choice is True)
        resume_route_url = cls._current_route_url()
        resume_seek = 0.0
        resume_total = 0.0
        resume_source = 'not_requested'

        succeeded = True
        # записи, которые видео не ждёт (озвучка фильма, карта адреса потока для закладки Kodi), -
        # после resolve_url: Kodi открывает поток, пока они пишутся
        after_resolve = []

        try:
            post_info, cache = cls._load_post_for_playback(content['id'])
        except (FilmixError, simplemedia.WebClientError) as e:
            plugin.notify_error(e, True)
            succeeded = False
            listitem = EmptyListItem()
        else:
            # PLAYBACK_LANDSCAPE_ART: the browsing/widget row may already have
            # TMDb backdrop in resolved_ids, but VideoPlayer only sees the
            # resolved playback ListItem. Merge cached resolved art before
            # plugin.resolve_url so fullscreen pause OSD can show landscape.
            try:
                resolved_for_playback = cache.get_resolved_ids(content['id']) or {}
            except Exception:
                resolved_for_playback = {}
            if isinstance(resolved_for_playback, dict) and resolved_for_playback:
                try:
                    post_info.update({k: v for k, v in resolved_for_playback.items() if v not in [None, '']})
                except Exception:
                    pass

            translation = plugin.params.get('t')
            season = plugin.params.get('s')
            episode = plugin.params.get('e')

            try:
                resume_seek, resume_total, resume_source = cls._get_kodi_resume_point(resume_route_url, content.get('id'), season, episode)
            except Exception as e:
                resume_seek, resume_total, resume_source = 0.0, 0.0, 'lookup_error'
                try:
                    xbmc.log('[plugin.video.filmix] ResumePlan: lookup exception post_id={0} err={1}'.format(content.get('id'), e), xbmc.LOGINFO)
                except Exception:
                    pass

            if cls._caller_restores_position(content.get('id'), season, episode):
                # Место ставит тот, кто включил серию (tools/deploy.py скина после
                # выкладки): без вопроса «возобновить» и без своей перемотки.
                resume_choice = None
                resume_requested = False
                resume_seek, resume_total, resume_source = 0.0, 0.0, 'caller_restores'

            native_resume_requested = (resume_choice is True)
            native_resume_decided = (resume_choice is not None)
            fallback_prompted = False
            if resume_source == 'caller_restores':
                pass
            elif (resume_choice is None) and (not resume_requested) and float(resume_seek or 0.0) > 5.0:
                fallback_prompted = True
                if cls._resume_dialog_fallback(resume_seek, resume_total, resume_source):
                    resume_requested = True
                    resume_source = 'dialog_fallback:' + str(resume_source)
                else:
                    resume_seek, resume_total, resume_source = 0.0, 0.0, 'start_over'
            elif (resume_choice is False) and float(resume_seek or 0.0) > 5.0:
                #                 # After episode rows were exposed as real episodes for season
                # artwork/info, Kodi still appends resume:false to the plugin
                # play route but the native resume dialog is not reliably shown
                # because Filmix rows keep direct-play/content-lookup suppression.
                # Treat resume:false as unreliable for both movies and episodes:
                # if a Kodi bookmark exists, show Filmix's own resume dialog.
                _is_movie_resume = False
                try:
                    _is_movie_resume = bool(Utilities.is_movie(post_info))
                except Exception:
                    _is_movie_resume = False
                fallback_prompted = True
                _prompt_kind = 'movie' if _is_movie_resume else 'episode'
                _prompt_source = _prompt_kind + '_resume_false:' + str(resume_source)
                if cls._resume_dialog_fallback(resume_seek, resume_total, _prompt_source):
                    resume_requested = True
                    resume_source = 'dialog_' + _prompt_kind + '_resume_false:' + str(resume_source)
                else:
                    resume_seek, resume_total, resume_source = 0.0, 0.0, _prompt_kind + '_start_over'

            if not resume_requested:
                resume_seek, resume_total = 0.0, 0.0

            try:
                xbmc.log('[plugin.video.filmix] ResumePlan: requested={0} native_requested={1} native_decided={2} fallback_prompted={3} post_id={4} s={5} e={6} seek={7:.3f} total={8:.3f} source={9} route={10}'.format(
                    bool(resume_requested), bool(native_resume_requested), bool(native_resume_decided), bool(fallback_prompted), content.get('id'), season, episode, float(resume_seek or 0.0), float(resume_total or 0.0), resume_source, resume_route_url), xbmc.LOGINFO)
            except Exception:
                pass

            video_item = VideoInfo(post_info, True)

            if Utilities.is_movie(post_info):
                # For movies, always allow choosing a translation on every start.
                # Cached translation may still be stored, but is not auto-applied here.
                path, translation = cls._get_movie_link(post_info, translation)
                if translation:
                    after_resolve.append(lambda _t=translation: cache.set_post_translation(content['id'], _t))
            else:
                episode_item = cls._get_episode_item(post_info, season, episode, translation)
                video_item.set_episode_info(season, episode, translation, episode_item)
                path = cls._get_episode_link(post_info, season, episode, translation)

            listitem = ListItem(video_item)
            try:
                _art = listitem.art or {}
                xbmc.log('[plugin.video.filmix] PlaybackArt: post_id={0} mediatype={1} thumb={2} fanart={3} landscape={4}'.format(
                    content['id'], video_item.mediatype,
                    1 if _art.get('thumb') else 0,
                    1 if _art.get('fanart') else 0,
                    1 if _art.get('landscape') else 0), xbmc.LOGINFO)
            except Exception:
                pass
            cls._apply_local_state(listitem, video_item, post_info, cache)

            if not Utilities.is_movie(post_info):
                listitem.set_properties({
                    'dbid': '',
                    'DBID': '',
                    'IsFolder': 'false',
                    'IsPlayable': 'true',
                    'VideoPlayer.Content': 'episodes'
                })

            if path is None:
                # Фильм, у которого на Filmix пока только трейлер (новинка в прокате):
                # ссылок на сам фильм нет, и без сообщения отказ выглядел поломкой
                try:
                    _links = post_info.get('player_links') or {}
                    if not _links.get('movie') and not _links.get('playlist'):
                        xbmcgui.Dialog().notification(
                            'Filmix', 'Фильм пока недоступен - на Filmix есть только трейлер'
                            if _links.get('trailer') else 'Фильм пока недоступен на Filmix',
                            xbmcgui.NOTIFICATION_INFO, 5000)
                except Exception:
                    pass
                plugin.resolve_url({}, False)
                for task in after_resolve:
                    try:
                        task()
                    except Exception:
                        pass
                return

            # v47.19 resume map: Kodi may save the native bookmark under the
            # resolved HTTP stream. Save stream -> plugin route so later list
            # rows can attach that Kodi DB bookmark and trigger the native
            # Resume dialog.
            after_resolve.append(lambda _p=path: filmix_save_resume_url_map(
                _p, resume_route_url, content.get('id'), season, episode))

            listitem.set_path(path)

            url = cls._get_listitem_url(video_item)
            listitem.set_url(url)

            data = {'post_id': content['id'],
                    'translation': translation,
                    'season': season,
                    'episode': episode,
                    'mediatype': ('movie' if Utilities.is_movie(post_info) else 'episode'),
                    'resume_requested': bool(resume_requested),
                    'resume_seek': float(resume_seek or 0.0),
                    'resume_total': float(resume_total or 0.0),
                    'resume_source': resume_source,
                    'resume_route': resume_route_url,
                    'stream_path': path,
                    }
            plugin.send_notification('OnPlay', data)

        plugin.resolve_url(listitem.get_item(), succeeded)
        for task in after_resolve:
            try:
                task()
            except Exception:
                pass

    @classmethod
    def play_trailer(cls, content_name):
        content = Utilities.get_content_params(content_name)

        try:
            api = Filmix()
            post_info = api.post(content['id'], force_refresh=True)
        except (FilmixError, simplemedia.WebClientError) as e:
            plugin.notify_error(e)
            plugin.resolve_url({}, False)
        else:
            cache = FilmixCache(plugin.profile_dir)

            cache.set_post_details(content['id'], post_info, player_fresh=True, preserve_richer_player=True)

            listitem = {'path': cls._get_trailer_link(post_info),
                        }

            plugin.resolve_url(listitem)

    @classmethod
    def _get_season_translation(cls, item, season, translation):
        player_links = cls._get_player_links(item)

        if isinstance(player_links, dict):
            link_season = FilmixCache._canonical_playlist_key(season or '-1')
            season_translations = player_links.get(link_season)
            if season_translations is None:
                season_translations = player_links.get(season)

            if isinstance(season_translations, dict):
                season_translation = season_translations.get(translation)
                if season_translation is None:
                    for key, translation_info in iteritems(season_translations):
                        season_translation = translation_info
                        break
            else:
                season_translation = None
        else:
            season_translation = None
            for season_translations in (player_links or []):
                for key, translation_info in iteritems(season_translations):
                    if key == translation \
                            or translation is None:
                        season_translation = translation_info
                        break
                    elif season_translation is None:
                        season_translation = translation_info

        return season_translation

    @classmethod
    def _get_player_links(cls, item):
        link_source = 'movie' if Utilities.is_movie(item) else 'playlist'
        links = (item or {}).get('player_links') or {}
        if not isinstance(links, dict):
            return {} if link_source == 'playlist' else []
        return links.get(link_source) or ({} if link_source == 'playlist' else [])

    @classmethod
    def _get_movie_link(cls, item, translation=None):
        player_links = cls._get_player_links(item)

        link_item = Utilities.get_translation_link(player_links, translation)
        if link_item is None:
            return None, translation

        selected_translation = link_item.get('translation') or translation or ''

        if link_item.get('translation') == 'Заблокировано правообладателем!':
            plugin.notify_error(link_item.get('translation'), True)
            return None, selected_translation

        url = link_item.get('link')
        if not url:
            return None, selected_translation

        sub_a = url.find('[')
        sub_b = url.find(']')

        if sub_a >= 0 and sub_b > sub_a:
            qualities = url[sub_a + 1:sub_b].split(',')
            url = url.replace(url[sub_a:sub_b + 1], '%s')
        else:
            qualities = []

        return cls._get_stream_url(url, qualities), selected_translation

    @classmethod
    def _get_episode_item(cls, item, season, episode, translation=None):
        season_translation = cls._get_season_translation(item, season, translation)

        if season_translation is None:
            return None

        if isinstance(season_translation, list):
            try:
                return season_translation[int(episode)]
            except Exception:
                return None
        try:
            return season_translation[episode]
        except Exception:
            return season_translation.get(str(episode)) if hasattr(season_translation, 'get') else None

    @classmethod
    def _get_episode_link(cls, item, season, episode, translation=None):
        season_translation = cls._get_season_translation(item, season, translation)

        if season_translation is None:
            return None

        if isinstance(season_translation, list):
            try:
                episode_info = season_translation[int(episode)]
            except Exception:
                return None
        else:
            try:
                episode_info = season_translation[episode]
            except Exception:
                episode_info = season_translation.get(str(episode)) if hasattr(season_translation, 'get') else None
        if not episode_info:
            return None

        if not isinstance(episode_info, dict):
            return None
        url = episode_info.get('link')
        qualities = episode_info.get('qualities') or []
        if not url:
            return None

        return cls._get_stream_url(url, qualities)

    @classmethod
    def _get_trailer_link(cls, item):
        links = (item or {}).get('player_links') or {}
        player_links = links.get('trailer') if isinstance(links, dict) else None

        if player_links is None \
                or len(player_links) == 0:
            return ''

        first = player_links[0] if isinstance(player_links[0], dict) else {}
        url = first.get('link')
        if not url:
            return ''


        sub_a = url.find('[')
        sub_b = url.find(']')

        if sub_a >= 0 and sub_b > sub_a:
            qualities = url[sub_a + 1:sub_b].split(',')
            url = url.replace(url[sub_a:sub_b + 1], '%s')
        else:
            qualities = []

        return cls._get_stream_url(url, qualities)

    @classmethod
    def _get_stream_url(cls, url, qualities):
        if not url:
            return None
        str_qualities = []
        for quality in qualities:
            if not quality:
                continue
            if isinstance(quality, str):
                str_qualities.append(quality)
            else:
                str_qualities.append('%s' % quality)

        video_quality = plugin.get_setting('video_quality')
        quality_list = cls._available_qualities()

        use_http_links = plugin.get_setting('use_http_links')
        check_source_link = plugin.get_setting('check_source_link')
        # клиент API (две сессии requests, настройки, сведения о серверах) нужен только для
        # проверки ссылки; без неё запуск видео его не ждёт
        api = Filmix() if check_source_link else None

        if '%s' not in url:
            path = url.replace('https://', 'http://') if use_http_links else url
            if check_source_link and not api.url_available(path):
                return None
            return path

        path = None
        try:
            max_quality_index = min(max(0, int(video_quality)), len(quality_list) - 1)
        except Exception:
            max_quality_index = len(quality_list) - 1
        # Preserve the old choice exactly: prefer the highest available
        # quality at or below the selected ceiling; if none exists, fall back
        # to the lowest available quality above it. Probe in that decision
        # order and stop at the first working source.
        candidates = ([q for q in reversed(quality_list[:max_quality_index + 1])
                       if q in str_qualities]
                      + [q for q in quality_list[max_quality_index + 1:]
                         if q in str_qualities])
        for q in candidates:
            stream_url = url % q
            if use_http_links:
                stream_url = stream_url.replace('https://', 'http://')
            if not check_source_link or api.url_available(stream_url):
                path = stream_url
                break

        if use_http_links \
                and path is not None:
            try:
                api = Filmix()
                direct_path = api.get_direct_link(path)
            except Exception:
                direct_path = path
            path = direct_path.replace('https://', 'http://')

        return path

    @classmethod
    def _available_qualities(cls):
        if plugin.get_setting('is_pro_plus'):
            return ['360', '480', '720', '1080', '1440', '2160']
        elif plugin.get_setting('is_pro'):
            # PRO - до 1080p; раньше он попадал в ветку обычного аккаунта, и при любой
            # настройке качества играло не выше 720p (17.11.2026)
            return ['360', '480', '720', '1080']
        elif plugin.get_setting('user_login'):
            return ['360', '480', '720']
        else:
            return ['360', '480']

    @staticmethod
    def search_history():
        result = {'items': plugin.search_history_items(),
                  'content': '',
                  'category': ' / '.join([plugin.name, _('Search')]),
                  'sort_methods': xbmcplugin.SORT_METHOD_NONE,
                  }

        plugin.create_directory(**result)

    @staticmethod
    def search_remove(index):
        plugin.search_history_remove(index)

    @staticmethod
    def search_clear():
        plugin.search_history_clear()

    @classmethod
    def search(cls):
        keyword = plugin.params.keyword or ''
        usearch = (plugin.params.usearch == 'True')

        new_search = (keyword == '')

        if not keyword:
            keyword = plugin.get_keyboard_text('', _('Search'))

        if keyword \
                and new_search \
                and not usearch:
            with plugin.get_storage('__history__.pcl') as storage:
                _history = storage.get('history', [])
                _history.insert(0, {'keyword': keyword})
                if len(_history) > plugin.get_setting('history_length'):
                    _history.pop(-1)
                storage['history'] = _history

            plugin.create_directory([], succeeded=False)

            url = plugin.url_for('search', keyword=py2_decode(keyword))
            xbmc.executebuiltin('Container.Update("%s")' % url)

        elif keyword:
            try:
                # поиск, набранный пользователем, - мимо общей очереди запросов, и описания найденного
                # тоже (_user_search читает догрузка описаний); сбрасывается в начале каждого маршрута
                cls._user_search[0] = True
                api = Filmix(unpaced=True)
                search_items = api.search(keyword)
            except (FilmixError, simplemedia.WebClientError) as e:
                plugin.notify_error(e)
                plugin.create_directory([], succeeded=False)
            else:
                search_items = cls._drop_screeners(search_items, route='search')

                container_content = cls._detect_container_content(search_items, fallback='videos')

                # 2.2.44 AM8_4GB_FAST_SEARCH_ROUTE:
                # Search must behave like the optimized cache/widget routes: return
                # the Filmix API results immediately and queue missing TMDb/post
                # enrichment for the background service.  Do not run synchronous
                # InstantMetadata/TMDbResolve while Kodi/AF3 is waiting for /search;
                # that was the root cause of stale previous search results staying
                # visible until the heavy route finally finished.
                try:
                    xbmc.log('[plugin.video.filmix] SearchFastRoute: query={0} items={1} mode=no_sync_metadata'.format(keyword, len(search_items)), xbmc.LOGINFO)
                except Exception:
                    pass

                result = {'items': cls._list_items(search_items, lite=True),
                          'total_items': len(search_items),
                          'content': container_content,
                          'category': ' / '.join([_('Search'), keyword]),
                          'sort_methods': xbmcplugin.SORT_METHOD_NONE,

                          }
                plugin.create_directory(**result)

    @classmethod
    def mark_watched(cls):
        cls._set_watched(True)

    @classmethod
    def mark_unwatched(cls):
        cls._set_watched(False)

    @classmethod
    def _get_post_info_for_state(cls, post_id, cache):
        post_info = cache.get_post_details(post_id)
        # Bulk mark for serial/season needs full post details with player playlist.
        # Lite list/post cache without playlist made "mark TV show as watched" a no-op.
        if post_info is None or not cls._has_playlist(post_info):
            try:
                fresh = Filmix().post(post_id)
            except (FilmixError, simplemedia.WebClientError) as e:
                plugin.notify_error(e)
                return post_info if cls._has_playlist(post_info) else None
            else:
                post_info = fresh
                cache.set_post_details(post_id, post_info, player_fresh=True, preserve_richer_player=True)
        return post_info

    @classmethod
    def _set_watched(cls, watched):
        post_id = plugin.params.get('id') or ''
        mediatype = plugin.params.get('m') or ''
        season = plugin.params.get('s')
        episode = plugin.params.get('e')
        cache = FilmixCache(plugin.profile_dir)

        if not post_id or mediatype not in ['movie', 'tvshow', 'season', 'episode']:
            xbmc.executebuiltin('Container.Refresh()')
            return

        # One store: Kodi. These used to write watched_state here, which is why
        # a season marked in this add-on never reached the recommendations and
        # why three places disagreed about the same film. The URL written is the
        # one the row itself would open, which is the key Kodi uses.
        details = cache.get_post_details(post_id) or {}
        if mediatype == 'movie':
            kodi_link.set_watched([kodi_link.route_for(post_id, details, 'movie')],
                                  bool(watched))
        elif mediatype == 'episode':
            kodi_link.set_watched(
                [kodi_link.route_for(post_id, details, 'episode', season, episode)],
                bool(watched))
            try:
                xbmc.log('[plugin.video.filmix] MARK_WATCHED_EPISODE_KODI post_id={0} watched={1} s={2} e={3}'.format(post_id, int(bool(watched)), season, episode), xbmc.LOGINFO)
            except Exception:
                pass
        else:
            post_info = cls._get_post_info_for_state(post_id, cache)
            if post_info is None:
                # Still keep the visible aggregate state for lite/widget rows.
                if mediatype == 'tvshow':
                    cache.set_watched_state(post_id, watched, playcount=(1 if watched else 0))
                elif mediatype == 'season':
                    cache.set_watched_state(post_id, watched, season=season, playcount=(1 if watched else 0))
                xbmc.executebuiltin('Container.Refresh()')
                return
            applied_count = 0
            paths = []
            for season_key, episode_key in cls._iter_canonical_episode_keys(post_info, season_filter=(season if mediatype == 'season' else None)):
                route = kodi_link.route_for(post_id, post_info, 'episode',
                                            season_key, episode_key)
                if route:
                    paths.append(route)
                applied_count += 1
            # A whole season or show is one action to the user and many rows to
            # Kodi, which has no season row of its own - so every episode path
            # is written, in one pass.
            applied_count = kodi_link.set_watched(paths, bool(watched)) or applied_count
            try:
                xbmc.log('[plugin.video.filmix] MARK_WATCHED_BULK post_id={0} mediatype={1} watched={2} episodes={3}'.format(post_id, mediatype, watched, applied_count), xbmc.LOGINFO)
            except Exception:
                pass

        try:
            kodi_link.mirror(cache)
        except Exception as exc:
            xbmc.log('[plugin.video.filmix] kodi mirror after mark failed: {0}'.format(exc),
                     xbmc.LOGWARNING)

        try:
            xbmc.executebuiltin('Container.Refresh()')
        except Exception:
            try:
                xbmc.executebuiltin('Container.Refresh()')
            except Exception:
                pass


    @staticmethod
    def _get_listitem_url(item_info, use_atl_names=False):

        url_params = {
            'content_name': item_info.content_name,
            'section': item_info.get_section()
        }

        if use_atl_names \
                and item_info.mediatype in ['movie', 'episode']:
            url_params['strm'] = 1
        elif use_atl_names \
                and item_info.mediatype in ['tvshow', 'season']:
            url_params['atl'] = 1

        if item_info.mediatype == 'movie':
            return plugin.url_for('play_video', **url_params)

        elif item_info.mediatype == 'episode':
            return plugin.url_for('play_video', s=item_info.get_season(), e=item_info.get_episode(),
                                  t=item_info.get_translation(), **url_params)

        elif item_info.mediatype == 'tvshow':
            return plugin.url_for('open_tvshow', **url_params)

        elif item_info.mediatype == 'season':
            return plugin.url_for('post_episodes', t=item_info.get_translation(), s=item_info.get_season(),
                                  **url_params)

    @staticmethod
    def _get_default_translation(translations):
        if isinstance(translations, list):
            return translations[0]['translation']
        elif isinstance(translations, dict):
            for translation, translations_seasons in iteritems(translations):
                return translation


    @classmethod
    def select_translation(cls):

        post_id = plugin.params.id or ''

        cache = FilmixCache(plugin.profile_dir)

        post_info = cache.get_post_details(post_id)
        player_links = cls._get_player_links(post_info)

        translations_info = Utilities.get_tvshow_translations(player_links) or {}

        translation_values = []
        translation_titles = []
        for translation, translation_info in iteritems(translations_info):

            seasons = 0
            episodes = 0
            for season_info in translation_info:
                seasons += 1
                episodes += season_info['episodes']

            translation_title = '{0} ({1}: {2}, {3}: {4})'.format(translation, _('Seasons'), seasons,
                                                                  _('Episodes'), episodes)

            translation_titles.append(translation_title)
            translation_values.append(translation)

        def _return_to_seasons():
            try:
                if isinstance(post_info, dict) and post_info:
                    item_info = PostInfo(post_info)
                    url = cls._get_listitem_url(item_info)
                    if url:
                        xbmc.executebuiltin('Container.Update("%s")' % url)
                        return
            except Exception:
                pass
            try:
                xbmc.executebuiltin('Container.Refresh()')
            except Exception:
                pass

        if not translation_titles:
            _return_to_seasons()
            return

        import xbmcgui
        selected = xbmcgui.Dialog().select(_('Select translation'), translation_titles)
        selected_translation = None
        if selected >= 0:
            selected_translation = translation_values[selected]
            cache.set_post_translation(post_id, selected_translation)
        _return_to_seasons()
        if selected_translation:
            try:
                xbmc.Monitor().waitForAbort(0.15)
            except Exception:
                pass
            try:
                plugin.dialog_notification_info('Filmix', _('Voice changed: {0}').format(selected_translation), 5000, False)
                xbmc.log('[plugin.video.filmix] TRANSLATION_CHANGED_NOTIFY post_id={0} translation={1}'.format(post_id, selected_translation), xbmc.LOGINFO)
            except Exception:
                try:
                    xbmcgui.Dialog().notification('Filmix', _('Voice changed: {0}').format(selected_translation), xbmcgui.NOTIFICATION_INFO, 5000, False)
                except Exception:
                    pass
