"""service.tvlink daemon package (stdlib only, no xbmc imports)."""
