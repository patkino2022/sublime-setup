# -*- coding: utf-8 -*-
"""Serve someone else's widget from a snapshot we keep ourselves.

Measured on <коробка>, cold, straight after a restart: YouTube's
subscriptions route costs 6.08 s to answer, the provider's favourites 2.37 s,
its deferred list 1.64 s - 12.67 s across the six widget routes on Home. Asking
those routes ahead of time (hub/preload.py) bought about a tenth of that,
because the time is not the network: it is the add-on running and building fifty
list items, and it pays that on every single call.

So the rows are kept. This module stores what a route answered, and a widget
pointed at

    plugin://skin.sublime/?info=hub_mirror&src=<the original path>

is answered from that store - the same rows, the same file paths, so playing an
item still goes through the add-on that owns it. The store is refreshed in the
background by the same pass that used to merely ask (see hub/preload.py), which
is what the owner asked for: «загрузка всех виджетов на главной при загрузке
коди, а также периодическое обновление их в фоне».

Nothing is invented here: if there is no snapshot yet, the route is asked once,
on the spot, exactly as before.
"""
from __future__ import absolute_import, unicode_literals

import hashlib
import json
import threading
import os
import re
import time

import xbmc
import xbmcvfs

from .config import log

FOLDER = 'special://profile/addon_data/skin.sublime/widget_mirror'
# Fields worth keeping: what a row needs to be drawn and played.
# 'mediatype' is NOT among them: Files.GetDirectory rejects it and the whole
# request fails with "Invalid params", which is how a first attempt stored
# nothing at all - 25 routes asked, 0 rows kept. The row's own 'type' field
# carries the same fact.
# 'dateadded' and 'premiered' are here for a reason the first version missed:
# the widget's own container carries a sortby/sortorder, and rows that lack the
# field it sorts on all compare equal - with a descending order that turned the
# owner's recommendations row upside down. The mirror must carry the same keys
# the add-on's own rows carried.
PROPERTIES = ['title', 'art', 'plot', 'year', 'playcount', 'file', 'season',
              'episode', 'duration', 'rating', 'genre', 'lastplayed', 'resume',
              'dateadded', 'premiered', 'originaltitle', 'uniqueid']
# Generous, because trimming is the widget's business: its own container carries
# the limit the owner configured, and a mirror that kept only its own idea of
# "enough" would quietly shorten his row. A first version capped at 60.
SNAPSHOT_VERSION = 2
MAX_ROWS = 120
STALE_SECONDS = 3600
# Rows that are navigation, not content - recognised by their label, because a
# folder can be either: «Следующая страница» is navigation, a subscribed channel
# is content. Serving the first as a video is how that tile appeared in the
# recommendations row; treating the second as navigation is how the «Каналы»
# widget came back empty.
NAVIGATION_WORDS = ('следующая страниц', 'next page', 'предыдущая страниц',
                    'previous page', 'ещё…', 'more…')


def is_navigation(row):
    """Only paging rows. A FOLDER is content, not navigation.

    The first version treated every folder as navigation, and the owner's
    «Каналы» widget - a list of subscribed channels, every one of them a folder -
    came back empty, so the category disappeared from the YouTube hub entirely.
    What has to go is the paging row, and that is recognised by its label.
    """
    label = str((row or {}).get('label') or '').strip().lower()
    if not label:
        return True
    # служебный пункт дополнения «Войти в аккаунт …» (гостю): не фильм. Снимок, снятый
    # до входа, нёс его в «Рекомендации» и после входа (.20, 17.11.2026)
    path = str((row or {}).get('file') or '').split('?')[0].rstrip('/')
    if path.endswith('/login') or 'войти в аккаунт' in label:
        return True
    return any(word in label for word in NAVIGATION_WORDS)


# Обложка ролика YouTube. Дополнение отдаёт самый крупный вариант, которого у
# части видео просто нет: измерено на .20 - из 49 строк «Рекомендаций» 9 несли
# fhddefault.jpg, и все проверенные отвечали 404, то есть плитка оставалась
# пустой. hqdefault.jpg есть у каждого видео, поэтому здесь дешёвая замена без
# сети; сборщик потом подберёт лучший вариант из существующих
# (hub/builder.py, _best_youtube_art).
# Имена обложек, которые у YouTube есть всегда. Всё остальное - «fhddefault»,
# «fhddefault_live» и прочие варианты с хвостом запроса - живёт не у каждого
# ролика и отдаёт 404: на экране это чёрная плитка. Правило одно на весь скин;
# раньше их было два - здесь узкое, в сборщике широкое, - и починка сборщика
# на снимки не влияла, потому что строка проходит через эту воронку последней.
_YT_GOOD = ('maxresdefault', 'sddefault', 'hqdefault', 'mqdefault', 'default')
# Те же имена по убыванию качества: сборщик поднимается по этому списку
# снизу вверх, пока сервер не подтвердит, что картинка есть.
_YT_BEST = ('maxresdefault', 'sddefault', 'hqdefault', 'mqdefault', 'default')
_YT_PATTERN = re.compile(r'(i\.ytimg\.com(?:%2f|/)vi(?:%2f|/)[A-Za-z0-9_-]+(?:%2f|/))'
                         r'([A-Za-z0-9_]+)(\.jpg)(\?\S*)?')


_PROBE_MEMO = {}
PROBE_TIMEOUT = 4.0


def probe_art(url):
    """Есть ли такая обложка на сервере. Один вопрос на адрес за сеанс.

    Живёт здесь, а не только в сборщике, потому что спрашивать нужно и там, где
    строки записываются: подъём качества внутри посточечной сборки до дальних
    строк не доходит - она обрывается, как только владелец берётся за пульт.
    Замер на .20 05.09.2026: в ленте подписок 31 строка из 60 осталась с
    hqdefault (480x360), и подложка 1920x1080 строилась растягиванием вчетверо.
    У того ролика, на который жаловался владелец (cIq4acZ4m14), maxresdefault
    существует - 1280x720, код 200.

    Спрашивать можно только в фоне: на пути к экрану сеть не трогаем.
    """
    text = str(url or '')
    known = _PROBE_MEMO.get(text)
    if known is not None:
        return known
    plain = text.replace('%2f', '/').replace('%2F', '/')
    start = plain.find('i.ytimg.com')
    if start < 0:
        return False
    from urllib.request import Request, urlopen
    try:
        answer = urlopen(Request('https://' + plain[start:].rstrip('/'),
                                 method='HEAD'), timeout=PROBE_TIMEOUT)
        ok = getattr(answer, 'status', 0) == 200
    except Exception:
        ok = False
    if len(_PROBE_MEMO) > 4000:
        _PROBE_MEMO.clear()
    _PROBE_MEMO[text] = ok
    return ok


def youtube_art_fallback(value, probe=None):
    """Заменить имя обложки на то, которое у ролика точно есть.

    probe - необязательная проверка доступности (её даёт сборщик, у которого
    есть время сходить в сеть). Без неё берётся hqdefault: он есть у любого
    ролика, тогда как maxresdefault бывает не у всех.
    """
    text = str(value or '')
    hit = _YT_PATTERN.search(text)
    if not hit:
        return text
    name = hit.group(2)
    if probe is None:
        # Без сети имя не улучшаем: hqdefault есть у любого ролика, а спрашивать
        # сервер на пути к экрану нельзя.
        if name in _YT_GOOD and not hit.group(4):
            return text
        candidates = ('hqdefault',)
    else:
        # Со проверкой в сети - поднимаем качество. Замер на .30 04.09.2026: у
        # всех 60 строк ленты подписок стояло hqdefault, то есть 480x360, и
        # подложка 1920x1080 строилась растягиванием этой картинки. Владелец
        # увидел это как «фон ужасного качества». API YouTube отдаёт hqdefault
        # даже там, где maxresdefault существует, поэтому сборщик обязан
        # спросить, а не поверить.
        try:
            start = _YT_BEST.index(name)
        except ValueError:
            start = _YT_BEST.index('hqdefault')
        candidates = _YT_BEST[:start + 1] or ('hqdefault',)
    for candidate in candidates:
        fresh = text.replace(hit.group(0), hit.group(1) + candidate + hit.group(3))
        if probe is None or probe(fresh):
            return fresh
    return text


def fix_row_art(row):
    """Заменить заведомо отсутствующие обложки YouTube на существующие."""
    art = (row or {}).get('art') or {}
    for key, value in list(art.items()):
        fixed = youtube_art_fallback(value)
        if fixed != value:
            art[key] = fixed
    if row.get('thumbnail'):
        row['thumbnail'] = youtube_art_fallback(row['thumbnail'])
    return row


def content_rows(rows):
    """Only what a widget should show, in the order the add-on gave it."""
    return [fix_row_art(row) for row in (rows or []) if not is_navigation(row)]


def _folder():
    path = xbmcvfs.translatePath(FOLDER)
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass
    return path


def _file(src):
    name = hashlib.sha1(str(src or '').encode('utf-8')).hexdigest()[:16]
    return os.path.join(_folder(), '%s.json' % name)


def stamp_of(src):
    """Когда снимок этого источника последний раз записан. 0 - если никогда.

    Берётся время файла, а не поле `stamp` внутри: они выставляются в один и
    тот же миг в store(), а читать mtime - это один системный вызов вместо
    разбора всего JSON со всеми строками. Нужно для порядка обхода в
    hub/builder.build_all, где иначе пришлось бы распарсить семнадцать файлов
    только чтобы их отсортировать.
    """
    try:
        return int(os.path.getmtime(_file(src)))
    except Exception:
        return 0


def fetch(src):
    """Ask the real route, once. Returns its rows."""
    try:
        raw = xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
            'params': {'directory': src, 'media': 'video',
                       'properties': PROPERTIES},
        })) or '{}'
        answer = json.loads(raw)
    except Exception as exc:
        log('зеркало не получило %s: %s' % (str(src)[:60], exc), xbmc.LOGWARNING)
        return []
    if answer.get('error'):
        log('зеркало отклонено %s: %s' % (
            str(src)[:60], answer['error'].get('message') or '?'), xbmc.LOGDEBUG)
        return []
    files = ((answer.get('result') or {}).get('files') or [])
    # 'filetype' is not among the properties we ask for - it comes with every
    # row anyway - and it is what tells a video from a navigation folder.
    return files[:MAX_ROWS]


# What a built row carries beyond the add-on's own fields. Everything here is
# ready to draw: paths point at files that already exist locally, the colour is
# already extracted, the identity is already resolved. This is the whole point of
# the design - see docs/CONCEPT_WIDGET_MIRROR.md.
# одна копия контракта строки - в hub/row_store.py (его подключают и дополнения)
from .row_store import ENRICHED_KEYS, PROPERTY_PREFIX  # noqa: E402


# Чем виджет является по своей природе. Одно место на весь скин: и проводка
# зеркала, и сборщик спрашивают здесь, потому что «мирить» и «обогащать» имеет
# смысл ровно для одного вида списков.
#
# «каталог» - список, который живёт на чужой стороне и меняется медленно:
#   подписки YouTube, новинки и подборки Filmix. Его снимок стоит делать, а
#   строки собирать заранее.
# «состояние» - список, который показывает действия самого владельца: избранное,
#   «посмотреть позже», продолжить просмотр, история. Снимок здесь вреден:
#   человек нажал - тайл обязан измениться сразу, а не через четверть часа.
# «живое» - PVR и телегид: содержимое меняется само по часам.
LIVE_PREFIXES = ('pvr://',)
STATE_PREFIXES = ('favourites://', 'library://', 'videodb://')
# Куски пути, по которым виден список «моего»: работают для любого дополнения,
# потому что все называют это примерно одинаково.
STATE_MARKS = ('favorite', 'favourite', 'deferred', 'watch_later', 'watchlater',
               'watchlist', 'continue', 'history', 'resume', 'playlist',
               'liked', 'my_ratings')


def category(path):
    """'живое' | 'состояние' | 'каталог' | '' (не список дополнения)."""
    text = str(path or '').strip().lower()
    if not text:
        return ''
    if text.startswith(LIVE_PREFIXES):
        return 'живое'
    if text.startswith(STATE_PREFIXES):
        return 'состояние'
    if not text.startswith('plugin://'):
        return ''
    if any(mark in text for mark in STATE_MARKS):
        return 'состояние'
    return 'каталог'


def row_properties(row):
    """{имя свойства: значение} для одной собранной строки - правило живёт в row_store."""
    from . import row_store
    return row_store.row_properties((row or {}).get('sublime') or {})


# Параметры, которыми виджет фильтрует СПИСОК. В адресе воспроизведения им
# делать нечего, а они туда попадают - и Kodi, который привязывает позицию
# просмотра к пути, считает один и тот же ролик разными записями. Снято
# 03.09.2026: «lLG8kHxc7-c» лежал дважды - 599 секунд под
# hide_shorts&hide_live и 596 под hide_live&hide_folders, - поэтому просмотр,
# начатый в одном виджете, не продолжался в другом и не переезжал на вторую
# коробку. Порядок параметров у виджетов тоже разный, так что даже один и тот
# же набор давал разные пути.
_YT_LISTING_PARAMS = ('hide_shorts', 'hide_live', 'hide_folders', 'category_label',
                      'page', 'page_token', 'refresh')


def clean_youtube_play_url(url):
    """Адрес воспроизведения без параметров фильтрации списка."""
    text = str(url or '')
    if 'plugin.video.youtube' not in text or '?' not in text:
        return text
    head, _, query = text.partition('?')
    kept = []
    for part in query.split('&'):
        if not part:
            continue
        name = part.split('=', 1)[0].lower()
        if name in _YT_LISTING_PARAMS:
            continue
        kept.append(part)
    # Порядок фиксируется: иначе один и тот же набор параметров, собранный
    # двумя виджетами в разном порядке, снова даст два разных пути.
    kept.sort()
    return head + ('?' + '&'.join(kept) if kept else '')


def clean_youtube_rows(rows):
    """Убрать фильтры списка из адресов строк YouTube."""
    for row in (rows or []):
        if not isinstance(row, dict):
            continue
        value = str(row.get('file') or '')
        if 'plugin.video.youtube' not in value:
            continue
        fresh = clean_youtube_play_url(value)
        if fresh != value:
            row['file'] = fresh
    return rows


def youtube_feed_rows(src, rows):
    """Ленты YouTube: без папок и трансляций, новое сверху.

    Три отдельные жалобы владельца, у которых один корень - мы полагались на
    параметры адреса (`hide_shorts`, `hide_live`, `hide_folders`), а они стоят
    не у всех виджетов и на наш снимок никак не влияют:

    * в «Подписках» и «Рекомендациях» появлялись прямые трансляции и папки
      («Прямая трансляция» первой строкой - снято на .20 03.09.2026);
    * новые видео не выходили вперёд: «Рекомендации» приходят в порядке
      YouTube, а не по дате, и свежее оказывалось в середине списка. Владелец
      это видел как «виджеты не обновляются»;
    * «Каналы» - тоже лента YouTube, но там КАЖДАЯ строка папка, и убирать
      папки в ней нельзя: список каналов просто исчезнет.

    Поэтому папки убираются только там, где есть хоть одна не-папка, а
    сортировка применяется только когда даты вообще есть.
    """
    text = str(src or '')
    # свои полосы YouTube (тренды, эфиры, новости, чарты, подписки) - тоже ленты: новое
    # сверху (владелец 17.11.2026: «виджеты ютуб не сортированы по убыванию даты»).
    # Поиск остаётся по релевантности
    ours = text.startswith('sublime://youtube_') and 'search' not in text
    if 'plugin.video.youtube' not in text and not ours:
        return rows
    rows = [row for row in (rows or []) if isinstance(row, dict)]
    videos = [row for row in rows
              if str(row.get('filetype') or 'file') == 'file']
    if videos and len(videos) != len(rows):
        rows = videos
    if not ours and videos:
        # списки дополнения 8 («Рекомендации») даты не несут вовсе (у Data API версии 7 она
        # была): точное время и крупная обложка - тем же запросом player, что у своих полос,
        # с кэшем на диске («у рекомендаций нет дат», .20, 26.11.2026)
        try:
            from .youtube_tvfeed import finish_rows
            rows = finish_rows(rows)
        except Exception as exc:
            log('время роликов YouTube не проставлено: %s' % exc, xbmc.LOGWARNING)
    dated =[row for row in rows if str(row.get('dateadded') or row.get('premiered') or '')]
    if len(dated) >= max(2, len(rows) // 2):
        rows.sort(key=lambda row: str(row.get('dateadded')
                                      or row.get('premiered') or ''), reverse=True)
    return rows


def _to_row_store(rows):
    """Собранные строки - ещё и в общее хранилище по адресу (hub/row_store.py): из него их
    свойства берут списки дополнений в окне «Видео». Слияние в обе стороны: найденное в хранилище
    (логотип, собранный очередью дополнений) возвращается в строку снимка, а пустым полем снимка
    хранилище не затирается (22.11.2026)."""
    try:
        from . import row_store
        merged = row_store.put_merged({str(r.get('file') or ''): r.get('sublime') for r in rows
                                       if isinstance(r, dict) and r.get('sublime')})
        for row in rows:
            if isinstance(row, dict) and row.get('sublime'):
                block = merged.get(str(row.get('file') or ''))
                if block:
                    row['sublime'] = block
    except Exception as exc:
        log('общее хранилище строк не обновлено: %s' % exc, xbmc.LOGDEBUG)


def store(src, rows):
    if not rows:
        return False
    # Единственная воронка, через которую строка попадает в снимок: сборщик
    # берёт строки прямо из fetch(), минуя content_rows(), и первая версия
    # заплатки для обложек YouTube поэтому не срабатывала вовсе - снимок снова
    # получал fhddefault.jpg, которого нет.
    rows = clean_youtube_rows(youtube_feed_rows(src, rows))
    rows = [row for row in rows if not is_navigation(row)]
    if not rows:
        return False
    for row in rows:
        fix_row_art(row)
        clean_row_text(row)
    try:
        # Название канала YouTube: Kodi его для строк без типа не отдаёт, а
        # инфо-строка скина его показывает - чип берёт ListItem.Studio.
        from . import youtube_meta
        youtube_meta.fill_channels(rows)
    except Exception as exc:
        log('канал YouTube не проставлен: %s' % exc, xbmc.LOGDEBUG)
    # сначала слияние с общим хранилищем - в снимок идут уже слитые строки
    _to_row_store(rows)
    payload = {'src': src, 'version': SNAPSHOT_VERSION,
               'stamp': int(time.time()), 'rows': rows}
    target = _file(src)
    tmp = '%s.%d.tmp' % (target, threading.get_ident())
    try:
        # через временный файл: снимок читают маршруты и заполнение кэшей в ту же секунду
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False)
        os.replace(tmp, target)
        return True
    except Exception as exc:
        try:
            os.remove(tmp)
        except Exception:
            pass
        log('зеркало не сохранено %s: %s' % (str(src)[:60], exc), xbmc.LOGWARNING)
        return False


ORPHAN_AFTER_SECONDS = 36 * 3600


def prune_orphans(known, now=None):
    """Убрать снимки виджетов, которых на экране больше нет.

    Аудит .30 07.09.2026: в папке лежало 967 строк в 19 снимках, и 353 из них
    (36 %) - в снимках возрастом 23 часа и 3 суток: старые пути виджетов,
    которых владелец давно не держит на экране. Доливка сведений делит свой
    бюджет по всем снимкам подряд, то есть треть её работы уходила на строки,
    которые никто не увидит.

    Сносим только то, что одновременно (1) не запрашивалось больше полутора
    суток и (2) не входит в список живых источников. Список даёт вызывающий -
    здесь мы про виджеты владельца ничего не знаем.
    """
    now = time.time() if now is None else float(now)
    folder = _folder()
    alive = {str(src or '') for src in (known or ())}
    alive_files = {_file(src) for src in alive if src}
    removed = []
    try:
        names = sorted(os.listdir(folder))
    except Exception:
        return removed
    for name in names:
        if not name.endswith('.json'):
            continue
        path = os.path.join(folder, name)
        if path in alive_files:
            continue
        try:
            age = now - os.path.getmtime(path)
        except OSError:
            continue
        if age < ORPHAN_AFTER_SECONDS:
            continue
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                src = str((json.load(handle) or {}).get('src') or '')
        except Exception:
            src = ''
        if src and src in alive:
            continue
        try:
            os.remove(path)
            removed.append(src or name)
        except OSError:
            continue
    if removed:
        log('снимки без виджета убраны: %d (%s)'
            % (len(removed), ', '.join(str(item)[:40] for item in removed[:4])))
    return removed


_ITER_OFFSET = [0]


def iter_snapshots():
    """(источник, строки) по каждому снимку на диске.

    Нужен дописывателю сведений (hub/builder.top_up_meta): он ходит по уже
    собранным строкам всех виджетов, а не по одному источнику.
    """
    folder = _folder()
    try:
        names = sorted(os.listdir(folder))
    except Exception:
        return
    names = [name for name in names if name.endswith('.json')]
    # Обход идёт ПО КРУГУ, а не всегда с первого снимка.
    #
    # Замер на .30 07.09.2026 (аудит полноты данных): в виджетах
    # «Рекомендации» логотип есть у 46 строк из 50 и оценка у 49, а в наших
    # полосах - логотип у 27 из 50 и оценка у 35. У недостающих строк
    # `_meta_checked` и `_meta_tries` пустые, то есть доливка сведений до них
    # НИ РАЗУ не дошла: она берёт по десять строк за проход и всегда начинает с
    # первого снимка в алфавитном порядке, поэтому весь её бюджет уходил на
    # одни и те же виджеты. Смещение продолжает обход с того места, где
    # закончился предыдущий, и за несколько минут покрывает все снимки.
    if names:
        offset = _ITER_OFFSET[0] % len(names)
        names = names[offset:] + names[:offset]
        _ITER_OFFSET[0] = (offset + 1) % len(names)
    for name in names:
        try:
            with open(os.path.join(folder, name), 'r', encoding='utf-8') as handle:
                payload = json.load(handle)
        except Exception:
            continue
        src = str((payload or {}).get('src') or '')
        rows = (payload or {}).get('rows') or []
        if src and rows:
            yield src, rows


def clean_row_text(row):
    """Описание строки - без служебной разметки, и в строке, и в обогащении.

    07.09.2026 владелец прислал снимок «Джека Ричера» с «< br / >» посреди
    описания. Чистка была только в обогащении (sublime.plot), а список читает
    ОБЫЧНОЕ описание строки - его в снимке лежало 157 штук с разметкой, потому
    что сборщик берёт строки прямо из fetch(), минуя разбор поставщика.
    Чистим здесь: это единственная воронка снимка, а на чтении та же чистка
    лечит уже лежащие снимки, не переписывая файл (переписать - значит сбить
    отметку свежести, по ней считается возраст ленты).
    """
    if not isinstance(row, dict):
        return
    holders = [row]
    enriched = row.get('sublime')
    if isinstance(enriched, dict):
        holders.append(enriched)
    text_pairs = [(holder, str(holder.get('plot') or '')) for holder in holders]
    if not any(('<' in text or '&' in text) for _holder, text in text_pairs):
        return
    try:
        from ..sublime_helper.model import clean_text
    except Exception:
        return
    for holder, text in text_pairs:
        if '<' not in text and '&' not in text:
            continue
        fixed = clean_text(text)
        if fixed and fixed != text:
            holder['plot'] = fixed


def load(src):
    """Rows and their age. A version 1 snapshot (rows without enrichment) still
    loads: it simply has no 'sublime' block, and the skin falls back to the
    service the way it always did."""
    try:
        with open(_file(src), 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
    except Exception:
        return [], 0
    rows = payload.get('rows') or []
    for row in rows:
        clean_row_text(row)
    return rows, int(payload.get('stamp') or 0)


def enrichment_index(src):
    """{путь строки: обогащение} из снимка этого виджета.

    Нужен там, где строки строит не зеркало, а мы сами (полосы хаба): строка
    приходит из своего источника, а готовые картинки и опознание берутся из
    снимка по пути.
    """
    rows, _stamp = load(src)
    index = {}
    for row in rows or []:
        path = str((row or {}).get('file') or '')
        enriched = (row or {}).get('sublime') or {}
        if path and enriched:
            index[path] = enriched
    return index


def enriched_count(rows):
    return sum(1 for row in (rows or []) if (row or {}).get('sublime'))


def refresh(src):
    """Ask the real route and keep the answer. Returns how many rows."""
    rows = fetch(src)
    if rows:
        store(src, rows)
    return len(rows)


def rows(src):
    """What the widget should show right now - the store if it has anything."""
    kept, stamp = load(src)
    # Правило лент YouTube применяется и на выдаче, а не только при записи
    # снимка: снимок мог быть собран прошлой версией, а сборщик на занятой
    # коробке ждёт своей очереди часами. Владелец всё это время видит папки,
    # трансляции и старое сверху.
    kept = content_rows(clean_youtube_rows(youtube_feed_rows(src, kept)))
    if kept:
        if time.time() - stamp > STALE_SECONDS:
            # Old, but shown anyway: an hour-old list beats an empty widget and
            # the background pass will replace it shortly.
            log('зеркало устарело (%d мин): %s'
                % (int((time.time() - stamp) / 60), str(src)[:60]), xbmc.LOGDEBUG)
        return kept
    fresh = fetch(src)
    if fresh:
        store(src, fresh)
    return content_rows(clean_youtube_rows(youtube_feed_rows(src, fresh)))


def upgrade_youtube_art(cancel=None, workers=8):
    """Крупные обложки во всех снимках полос YouTube - отдельным проходом в фоне.

    Полосы YouTube строятся с обложкой, которая есть у любого ролика (hqdefault
    480x360 / sddefault 640x480); крупную maxresdefault подставлял только
    сборщик при обогащении строки, и на чистой установке, пока он не дошёл до
    этих строк, подложка 1920x1080 растягивалась из маленькой картинки (.20,
    17.11.2026: «фоны низкого качества»). Здесь каждая обложка проверяется
    запросом HEAD (probe_art, параллельно) и поднимается до лучшей из
    существующих. Возвращает число заменённых адресов.
    """
    from concurrent.futures import ThreadPoolExecutor
    fixed = 0
    for src, rows in iter_snapshots():
        if 'youtube' not in str(src) or not rows:
            continue
        if cancel is not None and cancel():
            break
        values = sorted({str(v) for row in rows for v in (row.get('art') or {}).values()
                         if _YT_PATTERN.search(str(v or ''))})
        with ThreadPoolExecutor(max_workers=workers) as pool:
            better = dict(zip(values, pool.map(
                lambda v: youtube_art_fallback(v, probe=probe_art), values)))
        changed = False
        for row in rows:
            art = row.get('art') or {}
            for key, value in list(art.items()):
                new = better.get(str(value))
                if new and new != value:
                    art[key] = new
                    changed = True
                    fixed += 1
        if changed:
            store(src, rows)
    return fixed

