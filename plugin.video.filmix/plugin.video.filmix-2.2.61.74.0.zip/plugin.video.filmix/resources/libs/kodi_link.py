# -*- coding: utf-8 -*-
"""Writing watched state to Kodi and mirroring it back for display.

The owner's rule: Kodi keeps the history, everyone else reads it. So the context
menu here no longer writes this add-on's own table - it writes Kodi, through the
public API, using the same play URL the row would open. That is the URL Kodi
itself keys by (verified in the live database: episodes appear as
`.../serials/183454-.../play/?s=1&e=1`, movies as `.../movies/183067-.../play/`).

`watched_state` stays, demoted to a display cache: the lists here draw their
ticks from it without a cross-add-on query per row, and `mirror()` makes it
agree with Kodi - including removing marks Kodi no longer has, which is how an
un-mark made anywhere else arrives.
"""
import json
import os
import time
from urllib.parse import quote

import xbmc

from . import watch_stats
from .kodi_state import _load as _kodi_rows  # single read, cached
from .kodi_state import newest_myvideos_db
from .kodi_state import invalidate as invalidate_state

# когда служба сверялась в последний раз (time.time())
_last_mirror = [0.0]


def _log(message, level=xbmc.LOGINFO):
    try:
        xbmc.log('[plugin.video.filmix][kodi] {0}'.format(message), level)
    except Exception:
        pass


def _norm(value):
    return '' if value in (None, '', 'None') else str(value)


def _section_for(details, media_type):
    """Which catalogue section the post lives in - it is part of its URL."""
    try:
        section = str(details.get('section') or details.get('section_id')
                      or details.get('cat_id') or '')
    except Exception:
        section = ''
    if section == '7':
        return 'serials'
    if section == '93':
        return 'multserials'
    if section == '14':
        return 'multfilms'
    return 'serials' if media_type in ('episode', 'tvshow') else 'movies'


def route_for(post_id, details, media_type='movie', season='', episode=''):
    """The play URL for this row - the key Kodi uses.

    Same shape the list items publish, verified against Kodi's own database:
    a film is `.../movies/<id>-<slug>/play/`, an episode the same with
    `?s=<season>&e=<episode>`. Built here rather than in a shared module, so the
    context menu depends on nothing that was retired with the old sync code.
    """
    details = details or {}
    alt = _norm(details.get('alt_name') or details.get('alias')
                or details.get('url')).strip()
    try:
        alt = quote(alt, safe='')
    except Exception:
        pass
    alt = alt.replace('/', '_')
    section = _section_for(details, media_type)
    route = 'plugin://plugin.video.filmix/{0}/{1}-{2}/play/'.format(
        section, _norm(post_id), alt)
    if media_type == 'episode' or _norm(season) or _norm(episode):
        route += '?s={0}&e={1}'.format(_norm(season), _norm(episode))
    return route


def _jsonrpc(method, params):
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': method, 'params': params})) or '{}')
        if answer.get('error'):
            _log('{0}: {1}'.format(method, answer['error']), xbmc.LOGWARNING)
            return False
        return True
    except Exception as exc:
        _log('{0} не прошёл: {1}'.format(method, exc), xbmc.LOGWARNING)
        return False


def set_watched(paths, watched=True):
    """Mark or clear these paths in Kodi. Returns how many were written."""
    done = 0
    stamp = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())
    for path in paths:
        if not path:
            continue
        params = {'file': path, 'media': 'video',
                  'playcount': 1 if watched else 0,
                  'resume': {'position': 0.0, 'total': 0.0}}
        if watched:
            params['lastplayed'] = stamp
        if _jsonrpc('Files.SetFileDetails', params):
            done += 1
    if done:
        invalidate_state()
    return done


# Разделы каталога, в которых пост - сериал. Отметка на самом сериале имеет
# смысл только для них: у фильма путь без серий - это и есть путь фильма.
SHOW_SECTIONS = ('/serials/', '/multserials/')


def show_level_marks():
    """{post_id: [пути]} - отметки, которые Kodi держит на самом сериале.

    Не на серии, а на сериале. Такие пути (`/serials/<id>-<...>/open/`) пишет
    только старая схема пометки: нынешняя помечает пути серий по одному. Так
    «Всегда солнечно в Филадельфии» стоял просмотренным в полосах хаба, которые
    читают состояние из Kodi, и честно показывал оставшуюся серию в избранном,
    где счёт идёт по сериям.
    """
    found = {}
    for path, (playcount, _pos, _total) in _kodi_rows().items():
        if 'plugin.video.filmix' not in path or playcount <= 0:
            continue
        if not any(section in path for section in SHOW_SECTIONS):
            continue
        key = _key_of(path)
        if not key or key[1] or key[2]:
            continue
        found.setdefault(key[0], []).append(path)
    return found


def _key_of(path):
    """(post_id, season, episode) as this add-on's own table keys them."""
    if 'plugin.video.filmix' not in str(path or ''):
        return None
    return watch_stats.kodi_key(path)


def mirror(cache, interval_seconds=0):
    """Make this add-on's display cache agree with Kodi.

    Applies what Kodi has and removes what it does not, because an un-mark is a
    fact too and used to be the one that never travelled.
    """
    # Срок проверяется первым и в памяти: служба зовёт сверку каждый такт, и до
    # срока не должно быть ни stat базы Kodi, ни чтения флага из sqlite
    # (21.11.2026). Срок передаёт только служба - один процесс, флаг в базе не нужен.
    if interval_seconds:
        now = time.time()
        if now - _last_mirror[0] < float(interval_seconds):
            return 0
        _last_mirror[0] = now
    # Отпечаток базы Kodi снимается ДО чтения: запись, сделанная Kodi после
    # чтения, сменит отпечаток, и следующий список сверится снова.
    db_stamp = _db_stamp()

    # Only ADD. Absence in Kodi is not the same as "not watched": an episode
    # watched long before Kodi held the history has no row of its own there, and
    # treating that silence as an un-mark wiped about fifteen hundred marks off
    # this add-on's lists in one pass - which is exactly what the owner saw.
    # An explicit un-mark is a row in Kodi with playcount 0, and that is what
    # `cleared` below reacts to; anything Kodi has never heard of is left alone.
    # The rule itself lives in watch_stats.kodi_marks - the same one the lists
    # apply on the fly (watch_stats.apply_kodi).
    # Читаем базу заново: строки, закэшированные в процессе на 20 с, могли
    # быть старше отпечатка, и флаг соврал бы, что сверка свежая.
    invalidate_state()
    wanted, cleared = watch_stats.kodi_marks(_kodi_rows())

    try:
        rows = list(cache.conn.execute(
            'SELECT post_id, season, episode, watched FROM watched_state'))
    except Exception as exc:
        _log('watched_state не прочитан: {0}'.format(exc), xbmc.LOGWARNING)
        return 0

    changed = 0
    have = set()
    for row in rows:
        post_id = str(row['post_id'] if isinstance(row, dict) else row[0])
        season = str((row['season'] if isinstance(row, dict) else row[1]) or '')
        episode = str((row['episode'] if isinstance(row, dict) else row[2]) or '')
        watched = int((row['watched'] if isinstance(row, dict) else row[3]) or 0)
        key = (post_id, season, episode)
        have.add(key)
        should = key in wanted
        if watched and key in cleared and not should:
            cache.set_watched_state(post_id, False, season=season or None,
                                    episode=episode or None, playcount=0)
            changed += 1
        elif should and not watched:
            cache.set_watched_state(post_id, True, season=season or None,
                                    episode=episode or None,
                                    playcount=wanted[key])
            changed += 1
    for key, playcount in wanted.items():
        if key in have:
            continue
        post_id, season, episode = key
        cache.set_watched_state(post_id, True, season=season or None,
                                episode=episode or None, playcount=playcount)
        changed += 1
    if changed:
        _log('состояние просмотра синхронизировано с Kodi: изменено {0}'.format(changed))
    if db_stamp:
        try:
            cache.set_control_flag(DB_FLAG, db_stamp)
        except Exception:
            pass
    return changed


DB_FLAG = 'kodi_mirror_db'
_synced_this_process = [False]


def _db_stamp():
    """Отпечаток базы Kodi: путь, время и размер файла. '' - базы нет."""
    try:
        path = newest_myvideos_db()
        info = os.stat(path)
        return '{0}|{1}|{2}'.format(path, int(info.st_mtime * 1000), info.st_size)
    except Exception:
        return ''


def sync_before_listing(cache):
    """Сверить кэш с Kodi перед тем, как список прочтёт отметки - если Kodi с
    прошлой сверки что-то записал. Один раз на процесс маршрута.

    29.10.2026 на .20 «Избранное» перечитывалось через 5 с после конца серии,
    служба сверялась через 10 с (раз в минуту), и «Полураспад» остался с одной
    непросмотренной серией: список посчитан по кэшу без неё и больше не
    перечитывался. Kodi пишет просмотр в базу до того, как перечитывает
    списки, поэтому сверка в начале списка всегда успевает. Если база не
    менялась, это один stat и одно чтение флага.
    """
    if _synced_this_process[0]:
        return 0
    _synced_this_process[0] = True
    stamp = _db_stamp()
    if not stamp:
        return 0
    try:
        row = cache.get_control_flag(DB_FLAG)
        known = (row or {}).get('flag_value') if isinstance(row, dict) else (row[0] if row else '')
    except Exception:
        known = ''
    if str(known or '') == stamp:
        return 0
    invalidate_state()
    return mirror(cache)
