# -*- coding: utf-8 -*-
"""Имя студии, у которого есть картинка в resource.images.studios.coloured.

Одно правило для службы (логотип в углу хаба, vcl_service) и сборщика строк (Sublime.Studio в
строке, hub/builder.py): из имён студий и сетей берётся первое, у которого есть файл, - точное
имя, затем без общих хвостов («Netflix Animation Studios» -> «Netflix»). Раньше бралось первое имя
как есть, и у «Сводных сестёр» (Paper Kite Productions, Netflix Animation Studios) логотипа не было,
хотя «Netflix» в наборе есть (.20, 22.11.2026).
"""
from __future__ import absolute_import, unicode_literals

import re

try:
    import xbmcvfs
except Exception:          # проверка без Kodi
    xbmcvfs = None

RESOURCE = 'resource://resource.images.studios.coloured/%s.png'

TAIL_WORDS = frozenset((
    'studios', 'studio', 'animation', 'animations', 'pictures', 'picture', 'productions', 'production',
    'entertainment', 'films', 'film', 'media', 'company', 'co', 'inc', 'llc', 'ltd', 'group',
    'international', 'distribution', 'television', 'tv', 'network', 'networks', 'originals'))

_EXISTS = {}


def candidates(name):
    """Варианты одного имени: как есть, с заменой &/: и без общих хвостов по одному слову."""
    name = re.sub(r'\s+', ' ', str(name or '')).strip()
    if not name:
        return []
    out = []
    for cand in (name, name.replace('&amp;', '&'), name.replace('&', 'and'), name.replace(':', '')):
        cand = re.sub(r'\s+', ' ', cand).strip()
        if cand and cand not in out:
            out.append(cand)
    words = out[0].split(' ')
    while len(words) > 1 and words[-1].strip('.,').lower() in TAIL_WORDS:
        words = words[:-1]
        cand = ' '.join(words).strip(' ,.-')
        if cand and cand not in out:
            out.append(cand)
    return out


def _exists(path):
    if path in _EXISTS:
        return _EXISTS[path]
    found = False
    try:
        found = bool(xbmcvfs and xbmcvfs.exists(path))
    except Exception:
        found = False
    if len(_EXISTS) > 4000:
        _EXISTS.clear()
    _EXISTS[path] = found
    return found


def path_for(name):
    """(имя с картинкой, путь) для одного имени студии или ('', '')."""
    for cand in candidates(name):
        path = RESOURCE % cand
        if _exists(path):
            return cand, path
    return '', ''


def first_with_logo(names):
    """Первое из имён (по порядку), у которого есть картинка: (имя, путь) или ('', '')."""
    for name in names or ():
        found = path_for(name)
        if found[0]:
            return found
    return '', ''
