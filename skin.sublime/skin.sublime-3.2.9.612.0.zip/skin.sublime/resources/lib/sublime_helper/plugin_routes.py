# -*- coding: utf-8 -*-
"""Route names kept separate so the entrypoint can dispatch without importing
metadata providers, PIL helpers and thread-pool code for simple VCL actions."""
# The hub's own routes: catalogue lanes, recommendations, continue-watching and
# the actions on their rows. Kept in a separate set because they need none of
# the metadata providers the routes below pull in.
HUB = frozenset({
    'hub_lane', 'hub_widget', 'hub_continue', 'hub_root', 'hub_feedback',
    'hub_smart',
    'hub_mark_watched', 'hub_mark_unwatched', 'hub_why', 'hub_rebuild',
    'hub_sync_now', 'hub_import_history', 'hub_settings', 'hub_mirror',
    # Своя лента подписок YouTube (hub/youtube_subs.py). Имя маршрута
    # нужно ЗДЕСЬ, а не только в hub/routes.py: точка входа сверяется с
    # этим набором и на незнакомое имя отвечает отказом. 04.09.2026 полоса
    # была пустой именно поэтому - в журнале «unknown skin plugin route:
    # hub_subs», и поймала это проверка tools/box_readonly.py, а не глаз.
    'hub_subs',
    'hub_trending',
    'hub_ytlane',
    'hub_ytsearch',
    'hub_search',
    # результаты поиска любого дополнения, собранные как строки хабов (hub/search_rows.py)
    'hub_wrap',
})

HANDLED = frozenset({
    'details','cast','crew','fanart','images','videos','seasons','episodes','flatseasons','collection',
    'recommendations','next_recommendation','stars_in_movies','stars_in_tvshows','stars_in_both','crew_in_both',
    'search',
})
