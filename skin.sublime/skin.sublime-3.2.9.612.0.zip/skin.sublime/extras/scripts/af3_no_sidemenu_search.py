# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import time
import os
import json
import sys
import xbmc
import xbmcgui

SEARCH_WINDOW_IDS = (1105, 11105)

_ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
if _ADDON_ROOT not in sys.path:
    sys.path.insert(0, _ADDON_ROOT)
from resources.lib.sublime_helper.keyboard_history import load_history, push_history


def builtin(cmd):
    try:
        xbmc.executebuiltin(cmd)
    except Exception:
        pass



KEYBOARD_HISTORY_LIMIT = 10
KEYBOARD_HISTORY_FILE = 'special://profile/addon_data/skin.sublime/keyboard_history.json'


def translate_path(path):
    try:
        return xbmc.translatePath(path)
    except Exception:
        try:
            import xbmcvfs
            return xbmcvfs.translatePath(path)
        except Exception:
            return path


def builtin_escape(value):
    try:
        value = '' if value is None else str(value)
        value = value.replace('\\', '\\\\').replace('"', '\\"')
        return '"%s"' % value
    except Exception:
        return '""'


def load_keyboard_history():
    return load_history(KEYBOARD_HISTORY_FILE, KEYBOARD_HISTORY_LIMIT)


def save_keyboard_history(text):
    text = (text or '').strip()
    if not text:
        return
    try:
        items = push_history(text, KEYBOARD_HISTORY_FILE, KEYBOARD_HISTORY_LIMIT)
        for idx in range(KEYBOARD_HISTORY_LIMIT):
            skey = 'Sublime.KeyboardRecent.%02d' % (idx + 1)
            if idx < len(items):
                builtin('Skin.SetString(%s,%s)' % (skey, builtin_escape(items[idx])))
            else:
                builtin('Skin.Reset(%s)' % skey)
        xbmc.log('[sublime keyboard history] saved atomically from no_sidemenu_search', xbmc.LOGINFO)
    except Exception as exc:
        try:
            xbmc.log('[sublime keyboard history] save failed: %s' % exc, xbmc.LOGWARNING)
        except Exception:
            pass


def current_window():
    try:
        return xbmcgui.getCurrentWindowId()
    except Exception:
        return 0


def wait_for_search_window(timeout_ms=1600):
    deadline = time.time() + timeout_ms / 1000.0
    while time.time() < deadline:
        if current_window() in SEARCH_WINDOW_IDS:
            return True
        try:
            if xbmc.getCondVisibility('Window.IsVisible(1105)') or xbmc.getCondVisibility('Window.IsVisible(11105)'):
                return True
        except Exception:
            pass
        xbmc.sleep(40)
    return False


def main():
    kb = xbmc.Keyboard('', xbmc.getLocalizedString(137) or 'Search', False)
    kb.doModal()

    if not kb.isConfirmed():
        return

    query = (kb.getText() or '').strip()
    if not query:
        return

    save_keyboard_history(query)

    try:
        xbmcgui.Window(10000).setProperty('AF3NoSideMenu.SearchQuery', query)
    except Exception:
        pass

    # Visible search field is removed; search dialog reads AF3NoSideMenu.SearchQuery directly.
    builtin('ActivateWindow(1105)')
    wait_for_search_window(1600)
    xbmc.sleep(160)
    builtin('SetFocus(601)')


if __name__ == '__main__':
    main()
