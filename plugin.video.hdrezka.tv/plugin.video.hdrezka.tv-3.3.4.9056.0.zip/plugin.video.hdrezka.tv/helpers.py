import json
import os
import re
from contextlib import contextmanager

import xbmc

ADDON_ID = 'plugin.video.hdrezka.tv'


# Одна строка браузера на вход и на все запросы к сайту. Прежде вход шёл как
# Firefox 40, а каталог и потоки - как Chrome 120: сайт ведёт сессию по связке
# «аккаунт + браузер», и после запросов с разных адресов пометил связку с Chrome 120
# как подозрительную (403 «смените VPN» на get_cdn_series, .20, 16.11.2026).
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"


def dump_cookies(cookies):
    data = []

    for cookie in cookies:
        data.append({
            "name": cookie.name,
            "value": cookie.value,
            "domain": cookie.domain,
            "path": cookie.path,
            "secure": cookie.secure,
            "expires": cookie.expires,
        })

    return json.dumps(data)


def load_cookies(src):
    # requests - только здесь: служба берёт helpers, а requests ей не нужен (21.11.2026)
    from requests.cookies import RequestsCookieJar, create_cookie
    jar = RequestsCookieJar()

    try:
        cookies = json.loads(src)
        if isinstance(cookies, dict):
            # legacy format: plain {name: value} mapping
            cookies = [{"name": name, "value": value} for name, value in cookies.items()]
        for c in cookies:
            try:
                if not isinstance(c, dict) or not c.get("name"):
                    continue
                jar.set_cookie(
                    create_cookie(
                        name=c["name"],
                        value=c.get("value", ""),
                        domain=c.get("domain", ""),
                        path=c.get("path", "/"),
                        secure=c.get("secure", False),
                        expires=c.get("expires")
                    )
                )
            except Exception as ex:
                log(f"load cookie fault ex: {ex}")
    except Exception as e:
        log(f"load cookies failed: {e}")

    return jar
def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f'hdrezka: {msg}', level)


def logged_in(addon=None):
    """Вошёл ли пользователь - по куке сессии dle_user_id/dle_password, а не по логину в
    настройках: логин остаётся и после выхода, и после неудачного входа. Без addon настройка
    читается заново (вход мог случиться в другом процессе). Одна проверка для дополнения и
    службы (21.11.2026)."""
    try:
        if addon is None:
            import xbmcaddon
            addon = xbmcaddon.Addon(ADDON_ID)
        raw = addon.getSetting('cookies')
        cookies = json.loads(raw) if raw else []
    except Exception:
        return False
    if isinstance(cookies, dict):
        cookies = [{'name': k, 'value': v} for k, v in cookies.items()]
    for c in cookies if isinstance(cookies, list) else ():
        if isinstance(c, dict) and c.get('name') in ('dle_user_id', 'dle_password'):
            value = str(c.get('value') or '').strip()
            if value and value not in ('0', 'deleted'):
                return True
    return False


def open_videos_db():
    """База Kodi MyVideos самой старшей версии, только для чтения; None - базы нет.
    Один поиск для дополнения и службы (21.11.2026)."""
    import glob
    import sqlite3
    import xbmcvfs
    dbs = glob.glob(xbmcvfs.translatePath('special://database/MyVideos*.db'))
    if not dbs:
        return None
    newest = max(dbs, key=lambda p: int(re.sub(r'\D', '', os.path.basename(p)) or 0))
    return sqlite3.connect('file:%s?mode=ro' % newest, uri=True, timeout=2)


_FILE_CACHE = {}


def cached_file(path, load):
    """load(path), пока файл не менялся (время и размер) - повторно бесплатно в том же
    интерпретаторе (reuselanguageinvoker). Ошибки load не кэшируются (21.11.2026)."""
    st = os.stat(path)
    stamp = (st.st_mtime_ns, st.st_size)
    hit = _FILE_CACHE.get(path)
    if hit and hit[0] == stamp:
        return hit[1]
    value = load(path)
    _FILE_CACHE[path] = (stamp, value)
    return value

@contextmanager
def busy_dialog():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        yield
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')


def get_media_attributes(source):
    items = (source or '').split(',')
    if len(items) == 3:
        year, country, genre = items
    elif len(items) == 2:
        year, genre = items
        country = 'Unknown'
    else:
        year, country, genre = '', 'Unknown', ''
    return year, country, genre


def color_rating(rating):
    if not rating:
        return ''
    rating = float(rating)
    if 0 <= rating < 5:
        return '[COLOR=red][%s][/COLOR]' % rating
    elif 5 <= rating < 7:
        return '[COLOR=yellow][%s][/COLOR]' % rating
    elif rating >= 7:
        return '[COLOR=green][%s][/COLOR]' % rating


def built_title(name, country_years, **kwargs):
    colored_rating = color_rating(kwargs["rating"]["site"])
    colored_info = f'[COLOR=55FFFFFF]{kwargs["age_limit"]} ({country_years})[/COLOR]'
    return f'{name} {colored_rating} {colored_info}'



def get_subtitles(response):
    subtitles = None
    try:
        subtitles = response["subtitle"].split(',')
        for si in range(len(subtitles)):
            parts = subtitles[si].split(']')
            subtitles[si] = parts[1].replace("\\/", "/")
    except Exception as ex:
        log(f'fault decode subtitles ex: {ex}', xbmc.LOGDEBUG)
    return subtitles

def set_item_subtitles(item, subtitles):
    if subtitles:
        if not isinstance(subtitles, list):
            subtitles = [ subtitles ]

        item.setSubtitles(subtitles) 
