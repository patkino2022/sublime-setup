# -*- coding: utf-8 -*-
"""Общее хранилище собранных строк: адрес строки -> всё, что рисуется вокруг карточки.

Зачем. Хабы и поиск отдают строки, которые сами несут фон, цвет, логотип, оценки, жанр и дату
(Sublime.*), и разметка рисует их в кадре смены фокуса. Списки, которые строят дополнения
(окно «Видео»: каталоги Filmix, сезоны, HDRezka), этих свойств не несли, и всё это догоняла
служба скина на своём такте - чужой фон, пустая инфострока, задержки. Владелец 21.11.2026:
«зачем в скине ещё остаётся старый путь?»

Как. Сборщик скина (hub/builder.py) кладёт сюда каждую собранную строку по её адресу.
Дополнение при выдаче списка берёт готовые свойства по адресам своих строк (properties) и
ставит недостающие в очередь (ask); служба скина собирает очередь в фоне (take / put).

Модуль автономный - только sqlite3/json/xbmc: дополнения подключают его файлом
(importlib, как identity.py), без пакета скина.
"""
import json
import os
import re
import sqlite3
import time

try:
    import xbmc
    import xbmcvfs
except Exception:          # офлайн-проверки
    xbmc = xbmcvfs = None

DB = 'special://profile/addon_data/skin.sublime/row_store.db'
KEEP_SECONDS = 30 * 24 * 3600
QUEUE_LIMIT = 400

# поля собранной строки, которые становятся свойствами Sublime.<Поле> (hub/mirror.row_properties)
ENRICHED_KEYS = ('background', 'prepared', 'fanart', 'wash', 'logo', 'poster',
                 'plot', 'title', 'year', 'genre', 'country', 'rating',
                 'rating_tmdb', 'rating_imdb', 'rating_kp', 'rating_trakt',
                 'rating_letterboxd', 'rating_meta', 'rating_rt',
                 'rating_rtuser', 'rating_mdblist',
                 'tmdb_id', 'tmdb_type', 'studio', 'premiered')
PROPERTY_PREFIX = 'Sublime.'
ROW_RATINGS = (('rating_tmdb', 'TMDb_Rating'), ('rating_imdb', 'IMDb_Rating'),
               ('rating_kp', 'Kinopoisk_Rating'), ('rating_trakt', 'Trakt_Rating'),
               ('rating_letterboxd', 'Letterboxd_Rating'), ('rating_meta', 'MetaCritic_Rating'),
               ('rating_rt', 'RottenTomatoes_Rating'), ('rating_rtuser', 'RottenTomatoes_UserMeter'),
               ('rating_mdblist', 'MDBList_Rating'))
RATING_FALLBACK = ('Kinopoisk', 'TMDb', 'IMDb')
YEAR_ONLY = ('movie', 'tvshow', 'season', 'movies', 'tvshows', 'seasons', 'set')
_SLOT_CHOICE = {}


def _path():
    if xbmcvfs is None:
        return os.path.join(os.path.dirname(__file__), 'row_store.db')
    return xbmcvfs.translatePath(DB)


def _connect(readonly=False):
    path = _path()
    if readonly:
        if not os.path.exists(path):
            return None
        return sqlite3.connect('file:%s?mode=ro' % path, uri=True, timeout=3)
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder, exist_ok=True)
    conn = sqlite3.connect(path, timeout=5)
    # журнал WAL: запись службы (очередь раз в 15 с) не держит замок от чтения на фокусе и не
    # делает два fsync на флеш; так же устроен hub/store.py. Режим хранится в самой базе.
    try:
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
    except sqlite3.Error:
        pass
    conn.execute('CREATE TABLE IF NOT EXISTS rows (path TEXT PRIMARY KEY, block TEXT, built_at REAL)')
    conn.execute('CREATE TABLE IF NOT EXISTS queue (path TEXT PRIMARY KEY, row TEXT, asked_at REAL)')
    return conn


# ---- чтение и запись ----------------------------------------------------------------------

def get_many(paths):
    """{адрес: собранный блок} для известных адресов. Только чтение, быстро."""
    paths = [str(p) for p in (paths or []) if p]
    if not paths:
        return {}
    found = {}
    try:
        conn = _connect(readonly=True)
    except Exception:
        conn = None
    if conn is None:
        return found
    try:
        for start in range(0, len(paths), 400):
            chunk = paths[start:start + 400]
            marks = ','.join('?' * len(chunk))
            for path, block in conn.execute('SELECT path, block FROM rows WHERE path IN (%s)' % marks, chunk):
                try:
                    found[path] = json.loads(block)
                except Exception:
                    pass
    except Exception:
        pass
    finally:
        conn.close()
    return found


def _merged(old, new):
    """Новый блок поверх прежнего: пустое поле нового не стирает найденное раньше. Логотип
    «Вествуда» собрала очередь, а снимок полосы «Все» со старым блоком без логотипа записывал его
    поверх - логотип пропадал и из «Смотреть позже» (22.11.2026). Непустое новое значение
    по-прежнему заменяет старое."""
    if not isinstance(old, dict) or not old:
        return new
    if not isinstance(new, dict) or not new:
        return old
    # главный - собранный позже (built_at): снимок полосы мог записать старый блок, собранный до
    # опознания (фон - постер Filmix), поверх нового блока очереди с кадром TMDb («Формула-1», .20,
    # 22.11.2026); старый только заполняет пустые поля
    def _built(block):
        try:
            return float(block.get('built_at') or 0)
        except (TypeError, ValueError):
            return 0.0
    newer, older = (old, new) if _built(old) > _built(new) else (new, old)
    out = dict(newer)
    # отметки дозаполнения (builder._top_up_meta_pass: попытки и «проверено») - из обоих блоков:
    # дозаполнение не трогает built_at, и более новый блок очереди стирал «попытку», строка
    # переспрашивалась у TMDb и Кинопоиска каждый проход (петля 05.09; аудит 23.11.2026)
    tries = max(_int(newer.get('_meta_tries')), _int(older.get('_meta_tries')))
    if tries:
        out['_meta_tries'] = tries
    if newer.get('_meta_checked') or older.get('_meta_checked'):
        out['_meta_checked'] = True
        stamp = max(_int(newer.get('_meta_checked_at')), _int(older.get('_meta_checked_at')))
        if stamp:
            out['_meta_checked_at'] = stamp
    # описание без разметки - то, что дозаполнение уже вычистило
    plot_new, plot_old = str(out.get('plot') or ''), str(older.get('plot') or '')
    if plot_old and ('<' in plot_new or '&' in plot_new) and '<' not in plot_old and '&' not in plot_old:
        out['plot'] = plot_old
    # другой фильм: пустые поля нового опознания старыми не заполнять - логотип, фон и студия
    # прошлого фильма оставались у переопознанной строки (аудит 23.11.2026)
    id_new, id_old = str(newer.get('tmdb_id') or ''), str(older.get('tmdb_id') or '')
    if id_new and id_old and id_new != id_old:
        return out
    for key in ENRICHED_KEYS:
        if not out.get(key) and older.get(key):
            out[key] = older[key]
    return out


def _int(value):
    try:
        return int(float(value or 0))
    except (TypeError, ValueError):
        return 0


def identity_for_post(addon_id, post_id):
    """(номер TMDb, тип) из собранной строки поста дополнения - опознание скина, уже проверенное.
    Дополнение берёт его вместо своего поиска по названию: один фильм - один номер везде, и меньше
    запросов к TMDb (23.11.2026). Нет такой строки - ('', '')."""
    post = re.sub(r'\D', '', str(post_id or ''))
    if not post or not addon_id:
        return '', ''
    try:
        conn = _connect(readonly=True)
    except Exception:
        return '', ''
    if conn is None:
        return '', ''
    try:
        for (block,) in conn.execute('SELECT block FROM rows WHERE path LIKE ? ORDER BY built_at DESC LIMIT 5',
                                     ('plugin://%s/%%/%s-%%' % (addon_id, post),)):
            try:
                data = json.loads(block)
            except Exception:
                continue
            tmdb = str(data.get('tmdb_id') or '').strip()
            if tmdb.isdigit():
                kind = str(data.get('tmdb_type') or '').strip()
                return tmdb, ('tv' if kind in ('tv', 'tvshow', 'season', 'episode') else 'movie' if kind else '')
    except Exception:
        pass
    finally:
        conn.close()
    return '', ''


def put_merged(blocks):
    """Записать блоки {адрес: блок}, слив с уже известными (_merged); снимает их из очереди.
    Возвращает {адрес: итоговый блок} - снимок хаба забирает его себе (mirror.store)."""
    blocks = dict((str(p), b) for p, b in (blocks or {}).items() if p and isinstance(b, dict) and b)
    if not blocks:
        return {}
    # чтение, слияние и запись - одна транзакция: очередь, дозаполнение и снимки хаба пишут из
    # разных потоков службы, и слияние со старым прочитанным блоком стирало только что записанный
    # логотип (аудит 23.11.2026)
    conn = _connect()
    try:
        conn.execute('BEGIN IMMEDIATE')
        known = {}
        paths = list(blocks)
        for start in range(0, len(paths), 400):
            chunk = paths[start:start + 400]
            marks = ','.join('?' * len(chunk))
            for path, block in conn.execute('SELECT path, block FROM rows WHERE path IN (%s)' % marks, chunk):
                try:
                    known[path] = json.loads(block)
                except Exception:
                    pass
        merged = dict((p, _merged(known.get(p), b)) for p, b in blocks.items())
        items = [(p, json.dumps(b, ensure_ascii=False), float((b or {}).get('built_at') or time.time()))
                 for p, b in merged.items() if isinstance(b, dict) and b]
        conn.executemany('INSERT OR REPLACE INTO rows (path, block, built_at) VALUES (?, ?, ?)', items)
        conn.executemany('DELETE FROM queue WHERE path = ?', [(p,) for p, _b, _t in items])
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
    return merged


def put_many(blocks):
    """Записать собранные блоки {адрес: блок} как есть; снимает их из очереди. Слияние с прежними
    блоками - put_merged (им пишут служба и снимки хаба)."""
    items = [(str(p), json.dumps(b, ensure_ascii=False), float((b or {}).get('built_at') or time.time()))
             for p, b in (blocks or {}).items() if p and isinstance(b, dict) and b]
    if not items:
        return 0
    conn = _connect()
    try:
        conn.executemany('INSERT OR REPLACE INTO rows (path, block, built_at) VALUES (?, ?, ?)', items)
        conn.executemany('DELETE FROM queue WHERE path = ?', [(p,) for p, _b, _t in items])
        conn.execute('DELETE FROM rows WHERE built_at < ?', (time.time() - KEEP_SECONDS,))
        conn.commit()
    finally:
        conn.close()
    return len(items)


def ask(rows):
    """Поставить в очередь сборки строки, которых в хранилище нет (дополнение при выдаче)."""
    items = []
    for row in rows or []:
        path = str((row or {}).get('file') or '')
        if path:
            items.append((path, json.dumps(row, ensure_ascii=False), time.time()))
    if not items:
        return 0
    try:
        conn = _connect()
    except Exception:
        return 0
    try:
        conn.executemany('INSERT OR IGNORE INTO queue (path, row, asked_at) VALUES (?, ?, ?)', items)
        conn.execute('DELETE FROM queue WHERE path NOT IN (SELECT path FROM queue ORDER BY asked_at DESC LIMIT ?)',
                     (QUEUE_LIMIT,))
        conn.commit()
    finally:
        conn.close()
    return len(items)


def take(limit=8):
    """Строки из очереди, самые свежие просьбы первыми (служба скина)."""
    try:
        conn = _connect()
    except Exception:
        return []
    try:
        out = []
        for path, row in conn.execute('SELECT path, row FROM queue ORDER BY asked_at DESC LIMIT ?', (int(limit),)):
            try:
                out.append(json.loads(row))
            except Exception:
                conn.execute('DELETE FROM queue WHERE path = ?', (path,))
        conn.commit()
        return out
    finally:
        conn.close()


def drop(paths):
    """Снять из очереди то, что собрать не вышло, - не переспрашивать по кругу."""
    try:
        conn = _connect()
    except Exception:
        return
    try:
        conn.executemany('DELETE FROM queue WHERE path = ?', [(str(p),) for p in paths or [] if p])
        conn.commit()
    finally:
        conn.close()


# ---- свойства строки (одно правило для хабов, поиска и дополнений) ---------------------------

def _text(value):
    if isinstance(value, (list, tuple)):
        return ', '.join(str(v) for v in value if v)
    return str(value or '')


COUNTRY_RU = {
    'united states of america': 'США', 'united states': 'США', 'usa': 'США', 'u s a': 'США', 'us': 'США', 'u s': 'США',
    'united kingdom': 'Великобритания', 'great britain': 'Великобритания', 'uk': 'Великобритания', 'gb': 'Великобритания',
    'russian federation': 'Россия', 'russia': 'Россия', 'ru': 'Россия',
    'soviet union': 'СССР', 'ussr': 'СССР',
    'serbia': 'Сербия', 'rs': 'Сербия',
    'france': 'Франция', 'fr': 'Франция',
    'germany': 'Германия', 'de': 'Германия',
    'italy': 'Италия', 'it': 'Италия',
    'spain': 'Испания', 'es': 'Испания',
    'japan': 'Япония', 'jp': 'Япония',
    'china': 'Китай', 'cn': 'Китай',
    'hong kong': 'Гонконг', 'hk': 'Гонконг',
    'south korea': 'Южная Корея', 'korea': 'Южная Корея', 'kr': 'Южная Корея',
    'canada': 'Канада', 'ca': 'Канада',
    'australia': 'Австралия', 'au': 'Австралия',
    'new zealand': 'Новая Зеландия', 'nz': 'Новая Зеландия',
    'india': 'Индия', 'in': 'Индия',
    'mexico': 'Мексика', 'mx': 'Мексика',
    'brazil': 'Бразилия', 'br': 'Бразилия',
    'argentina': 'Аргентина', 'ar': 'Аргентина',
    'ireland': 'Ирландия', 'ie': 'Ирландия',
    'belgium': 'Бельгия', 'be': 'Бельгия',
    'netherlands': 'Нидерланды', 'nl': 'Нидерланды',
    'denmark': 'Дания', 'dk': 'Дания',
    'sweden': 'Швеция', 'se': 'Швеция',
    'norway': 'Норвегия', 'no': 'Норвегия',
    'finland': 'Финляндия', 'fi': 'Финляндия',
    'poland': 'Польша', 'pl': 'Польша',
    'czech republic': 'Чехия', 'czechia': 'Чехия', 'cz': 'Чехия',
    'slovakia': 'Словакия', 'sk': 'Словакия',
    'hungary': 'Венгрия', 'hu': 'Венгрия',
    'romania': 'Румыния', 'ro': 'Румыния',
    'bulgaria': 'Болгария', 'bg': 'Болгария',
    'croatia': 'Хорватия', 'hr': 'Хорватия',
    'slovenia': 'Словения', 'si': 'Словения',
    'bosnia and herzegovina': 'Босния и Герцеговина', 'ba': 'Босния и Герцеговина',
    'montenegro': 'Черногория', 'me': 'Черногория',
    'north macedonia': 'Северная Македония', 'mk': 'Северная Македония',
    'ukraine': 'Украина', 'ua': 'Украина',
    'belarus': 'Беларусь', 'by': 'Беларусь',
    'turkey': 'Турция', 'tr': 'Турция',
    'greece': 'Греция', 'gr': 'Греция',
    'israel': 'Израиль', 'il': 'Израиль',
    'iran': 'Иран', 'ir': 'Иран',
    'south africa': 'ЮАР', 'za': 'ЮАР',
}


_JUNK_GENRES = ('другое', 'неизвестно', 'другоенеизвестно', 'other', 'unknown', 'otherunknown',
                'nongenre', 'nogeneres', 'nogenre')


def _russian():
    try:
        return (xbmc.getLanguage(xbmc.ISO_639_1) or '').lower().startswith('ru')
    except Exception:
        return True


def _country_key(value):
    value = re.sub(r'[^a-zа-яё0-9]+', ' ', (value or '').lower(), flags=re.U).strip()
    return re.sub(r'\s+', ' ', value, flags=re.U)


def _parts(value):
    return [re.sub(r'\s+', ' ', p.strip(), flags=re.U)
            for p in re.split(r'\s*/\s*|\s*•\s*|\s*,\s*|\s*;\s*|\s*\|\s*', _text(value).replace('[CR]', ' / '))
            if p and p.strip()]


GENRE_RU = {
    'action': 'Боевик', 'adventure': 'Приключения', 'animation': 'Мультфильм', 'comedy': 'Комедия',
    'crime': 'Криминал', 'documentary': 'Документальный', 'drama': 'Драма', 'family': 'Семейный',
    'fantasy': 'Фэнтези', 'history': 'История', 'horror': 'Ужасы', 'music': 'Музыка',
    'mystery': 'Детектив', 'romance': 'Мелодрама', 'science fiction': 'Фантастика',
    'sci fi': 'Фантастика', 'sci fi fantasy': 'Фантастика', 'thriller': 'Триллер', 'war': 'Военный',
    'western': 'Вестерн', 'tv movie': 'Телефильм', 'action adventure': 'Боевик',
    'war politics': 'Военный', 'kids': 'Детский', 'news': 'Новости', 'reality': 'Реалити-шоу',
    'soap': 'Мыльная опера', 'talk': 'Ток-шоу', 'biography': 'Биография', 'sport': 'Спорт',
    'musical': 'Мюзикл', 'short': 'Короткометражный',
}


def first_genre(value):
    """Один жанр, без «другое/неизвестно», с заглавной - как у службы (vcl_service._first_genre)."""
    for part in _parts(value):
        norm = re.sub(r'[\s\W_]+', '', part.lower().replace('ё', 'е'), flags=re.U)
        if norm in _JUNK_GENRES:
            continue
        if _russian():
            part = GENRE_RU.get(_country_key(part), part)
        return part[:1].upper() + part[1:]
    return ''


def first_country(value):
    """Одна страна, английское название - по-русски на русском Kodi (словарь COUNTRY_RU)."""
    for part in _parts(value):
        if _russian():
            part = COUNTRY_RU.get(_country_key(part), part)
        if part:
            return part
    return ''


def local_date(value):
    """Дата в формате Kodi (как показывала служба): 2026-11-20 -> 20.11.2026."""
    hit = re.search(r'((?:19|20)\d{2})-(\d{1,2})-(\d{1,2})', value or '')
    if not hit:
        return ''
    try:
        stamp = time.strptime('%s-%s-%s' % hit.groups(), '%Y-%m-%d')
        fmt = (xbmc.getRegion('dateshort') if xbmc is not None else '') or '%d.%m.%Y'
        return time.strftime(fmt, stamp)
    except Exception:
        return '%s.%s.%s' % (hit.group(3).zfill(2), hit.group(2).zfill(2), hit.group(1))


def rating_props(block, mediatype):
    props = {'Sublime.RatingsReady': '1'}
    for key, name in ROW_RATINGS:
        value = str((block or {}).get(key) or '')
        if value:
            props['Sublime.' + name] = value
    content = 'TVShows' if str(mediatype or '') in ('tvshow', 'season', 'episode', 'tv') else 'Movies'
    if content not in _SLOT_CHOICE:
        choice = []
        for slot in ('Item01', 'Item02'):
            try:
                choice.append(xbmc.getInfoLabel('Skin.String(CustomRating.%s.%s)' % (content, slot)).strip())
            except Exception:
                choice.append('')
        _SLOT_CHOICE[content] = choice

    def has(source):
        return bool(props.get('Sublime.%s_Rating' % source))
    picks, taken = ['', ''], set()
    for index, source in enumerate(_SLOT_CHOICE[content]):
        if source and has(source) and source not in taken:
            picks[index] = source
            taken.add(source)
    for index in range(2):
        if not picks[index]:
            for source in RATING_FALLBACK:
                if source not in taken and has(source):
                    picks[index] = source
                    taken.add(source)
                    break
    for index, source in enumerate(picks):
        if source:
            props['Sublime.RatingSlot.Item0%d' % (index + 1)] = source
    return props


_EMPTY = ('n/a', 'na', 'n\a', '-', '—', 'none', 'null', 'unknown', 'неизвестно')


def _value(*candidates):
    """Первое непустое значение; «N/A» и подобные - пусто (сборщик хранит их как есть: страна
    «N/A» становилась «N», .20, 21.11.2026)."""
    for value in candidates:
        text = _text(value).strip()
        if text and text.lower() not in _EMPTY:
            return value
    return ''


def info_props(block, row):
    """Жанр, страна и дата инфостроки: у фильмов и сериалов год, у остального дата."""
    block = block or {}
    row = row or {}
    props = {}
    genre = first_genre(_value(block.get('genre'), row.get('genre')))
    country = first_country(_value(block.get('country'), row.get('country')))
    kind = str(row.get('mediatype') or row.get('type') or '').lower()
    date = ''
    if kind not in YEAR_ONLY:
        date = local_date(str(block.get('premiered') or row.get('premiered') or row.get('aired')
                              or row.get('firstaired') or ''))
        # у ролика дата выхода - дата публикации в dateadded (то же правило, что у службы,
        # vcl_service._container_release_display): без неё у роликов ленты подписок вместо даты
        # стоял год «2026» и перекрывал полную дату службы (.20, 23.11.2026)
        if not date and (kind == 'video' or 'plugin.video.youtube' in str(row.get('file') or '')):
            date = local_date(str(row.get('dateadded') or ''))
    if not date:
        hit = re.search(r'(19|20)\d{2}', str(block.get('year') or row.get('year') or ''))
        date = hit.group(0) if hit else ''
    for name, value in (('Genres2', genre), ('Country2', country), ('ReleaseDateDisplay', date)):
        if value:
            props['Sublime.' + name] = value
    return props


_RELEASE_IN_TITLE = re.compile(r'\s*\[[^\]]*(?:rip|web|bd|hd|uhd|4k|2160|1080|720|480|cam|ts)[^\]]*\]\s*$', re.I)


def row_properties(block):
    props = {}
    for key in ENRICHED_KEYS:
        value = (block or {}).get(key)
        if value in (None, ''):
            continue
        if key == 'logo' and '/title_logos_v1/' in str(value):
            continue        # логотип-название старого образца (рисовался со скобками) - пусть текст
        if key == 'logo' and str(value).lower().split('?')[0].endswith('.svg'):
            continue        # SVG Kodi не рисует - пусть название текстом
        if key == 'title':
            # вид релиза в скобках - не часть названия, его показывает плашка (21.11.2026)
            value = _RELEASE_IN_TITLE.sub('', str(value)).strip() or value
        props[PROPERTY_PREFIX + key[:1].upper() + key[1:]] = str(value)
    return props


_IDENTITY = {}


def _identity():
    """identity.py скина файлом (как этот модуль у дополнений): один разбор вида релиза."""
    if 'mod' not in _IDENTITY:
        mod = None
        try:
            import importlib.util
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'identity.py')
            spec = importlib.util.spec_from_file_location('sublime_identity_rows', path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
        except Exception:
            mod = None
        _IDENTITY['mod'] = mod
    return _IDENTITY['mod']


def release_props(row):
    """Плашка качества строки дополнения (sublime_release_quality/_resolution) - те же свойства и
    то же правило, что у строк хаба (routes._set_release_props). Без них в своих списках
    дополнения («Смотреть позже» Filmix) плашке не из чего было взять текст, пока фокус на
    вкладке: на .30 она пропадала, на .20 пустела (22.11.2026)."""
    row = row or {}
    quality = str(row.get('release_quality') or '')
    resolution = str(row.get('release_resolution') or '')
    if not quality and not resolution:
        ident = _identity()
        if ident is not None:
            try:
                if row.get('release'):
                    # готовая строка релиза от дополнения (HDRezka: лучшее качество потоков страницы фильма)
                    quality, resolution = ident.release_parts(row['release'])
                else:
                    quality, resolution = ident.release_info(row.get('label') or row.get('title') or '')
            except Exception:
                quality, resolution = '', ''
    if '4K' in quality.upper() and resolution == '2160':
        resolution = ''
    return {name: value for name, value in (('sublime_release_quality', quality),
                                             ('sublime_release_resolution', resolution)) if value}


def properties(block, row=None):
    """Все свойства Sublime.* для одной собранной строки (и плашка качества). Строка ещё не
    собрана (block пуст) - чистое название и плашка, чтобы до сборки не было скобки в названии."""
    row = row or {}
    if not block:
        props = release_props(row)
        clean = _RELEASE_IN_TITLE.sub('', str(row.get('title') or row.get('label') or '')).strip()
        if clean:
            props[PROPERTY_PREFIX + 'Title'] = clean
        # жанр, страна и год/дата - из данных самой строки, пока она не собрана: без них при
        # фокусе на вкладке чипы инфостроки пропадали (служба сверяет путь вкладки), аудит 22.11
        props.update(info_props(None, row))
        return props
    props = row_properties(block)
    props.update(rating_props(block, row.get('mediatype') or row.get('type')))
    props.update(info_props(block, row))
    props.update(release_props(row))
    return props


def attach(pairs):
    """Готовые свойства строк дополнения одним вызовом на страницу: pairs = [(ListItem, row)].
    Один запрос к хранилищу на всё и одна заявка на сборку недостающих - вместо двух
    подключений к sqlite на строку (так было у HDRezka). Общий для Filmix и HDRezka."""
    pairs = [(li, row) for li, row in (pairs or ()) if row and row.get('file')]
    if not pairs:
        return 0
    known = get_many([row['file'] for _li, row in pairs])
    missing = []
    for li, row in pairs:
        block = known.get(row['file'])
        for name, value in properties(block, row).items():
            li.setProperty(name, value)
        if not block:
            missing.append(row)
        elif not block.get('logo') and time.time() - float(block.get('built_at') or 0) > 86400:
            # собрана без логотипа больше суток назад - пересобрать: блок живёт 30 дней, и строки
            # «Смотреть позже» без логотипа так и оставались без него (аудит 22.11.2026)
            missing.append(row)
    if missing:
        ask(missing)
    return len(pairs) - len(missing)


def show_count_props(entry):
    """Счёт серий сериала из общего файла скина (watch_episodes.json: сериал = [просмотрено,
    начат, вышло]) - одно правило для Filmix и HDRezka. Возвращает (свойства, досмотрен ли).
    Число известно - непросмотренные и галочка у досмотренного; неизвестно - «в процессе»."""
    props = {'SeriesStarted': 'true'}
    try:
        watched = int((entry or [0])[0] or 0)
        total = int(entry[2]) if entry and len(entry) > 2 and entry[2] else 0
    except (TypeError, ValueError):
        watched, total = 0, 0
    if not total:
        props['WatchedProgress'] = '1'
        return props, False
    props.update({'TotalEpisodes': str(total), 'WatchedEpisodes': str(watched),
                  'UnWatchedEpisodes': str(max(0, total - watched)),
                  'WatchedEpisodePercent': str(min(100, int(round(100.0 * watched / total))))})
    return props, watched >= total


_WATCH_FILES = {}


def _watch_file(name):
    """Файл единой базы просмотров скина (watch_by_title.json, watch_episodes.json) с перечитыванием
    по времени изменения - одно чтение для Filmix и HDRezka (раньше у каждого своя копия кода)."""
    try:
        import xbmcvfs as _vfs
        path = _vfs.translatePath('special://profile/addon_data/skin.sublime/' + name)
    except Exception:
        return None
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        return None
    hit = _WATCH_FILES.get(name)
    if hit and hit[0] == stamp:
        return hit[1]
    try:
        with open(path, encoding='utf-8') as fh:
            data = json.load(fh)
    except Exception:
        return None
    _WATCH_FILES[name] = (stamp, data)
    return data


def title_states():
    """({ключ фильма: [playcount, позиция, длительность, время]}, identity.key_for) - фильмы по
    всем источникам; ключ строится той же функцией скина, чтобы совпал до символа."""
    ident = _identity()
    return (_watch_file('watch_by_title.json') or {}), (ident.key_for if ident is not None else None)


def episode_states():
    """{'episodes': {ключ серии: [...]}, 'shows': {ключ сериала: [просмотрено, начат, вышло]}}."""
    data = _watch_file('watch_episodes.json')
    return data if isinstance(data, dict) else {'episodes': {}, 'shows': {}}
