"""One channel request -> walk its sources until one plays.

Live: http://host:2021/<id>
Archive (pvr.tvlink, directCatchup off): http://host:2021/<id>?utc=<start>&lutc=<now>
"""
import re
import time

from . import resolvers
from .hls import ClientGone, Relay, StreamDead

PREFER_SECONDS = 600
_prefer = {}      # channel id -> (link index that took over, when)

_FLUSSONIC = re.compile(r"/(video|index|mono)(-[^/?]*)?\.m3u8")


def archive_url(link, utc, now):
    url, kind = link["url"], link["catchup"]
    if kind == "none":
        return None
    if kind == "flussonic":
        rel = max(0, int(now - utc))
        new, n = _FLUSSONIC.subn("/video-timeshift_rel-%d.m3u8" % rel, url, count=1)
        return new if n else None
    if kind == "default" and link.get("catchup_source"):
        return _fill(link["catchup_source"], utc, now)
    if kind == "append" and link.get("catchup_source"):
        return url + _fill(link["catchup_source"], utc, now)
    return url + ("&" if "?" in url else "?") + "utc=%d&lutc=%d" % (utc, now)


def _fill(tpl, utc, now):
    vals = {"utc": utc, "start": utc, "lutc": now, "now": now, "timestamp": now,
            "offset": max(0, now - utc), "duration": max(0, now - utc)}
    return re.sub(r"\$?\{(\w+)\}", lambda m: str(vals.get(m.group(1), m.group(0))), tpl)


def serve(channel, out, cfg, log, alive, utc=None):
    """Stream until the client leaves or every source failed twice in a row."""
    links = channel["links"]
    name = channel["title"]
    delivered = 0.0   # archive media seconds already sent
    failures = 0
    pref = _prefer.get(channel["id"])
    idx = pref[0] if pref and time.time() - pref[1] < PREFER_SECONDS and pref[0] < len(links) else 0
    while alive() and failures < 2 * len(links):
        link = links[idx % len(links)]
        now = int(time.time())
        if utc:
            # resume where the previous source stopped: original start + media sent
            url = archive_url(link, int(utc + delivered), now)
        else:
            try:
                url = resolvers.resolve(link["url"], (link.get("headers") or {}).get("User-Agent", cfg["user_agent"]))
            except Exception as e:     # a resolver is network work too
                log("[%s] resolve %s: %r" % (name, link["url"], e))
                url = None
        if not url:
            failures += 1
            idx += 1
            continue
        log("[%s] %s src=%s idx=%d" % (name, "archive" if utc else "live", link["src"], idx % len(links)))
        relay = Relay(url, cfg, out, log, alive, live=not utc, headers=link.get("headers"))
        try:
            relay.run()
            if utc:
                log("[%s] archive ended" % name)
                return
            raise StreamDead("upstream closed")
        except ClientGone:
            log("[%s] client left after %d KB" % (name, relay.sent_bytes // 1024))
            if relay.sent_bytes > 512 * 1024:
                # the next start of this channel goes straight to the source that played,
                # not through the one that refused a minute ago
                _prefer[channel["id"]] = (idx % len(links), time.time())
            return
        except StreamDead as e:
            resolvers.forget(link["url"])
            delivered += relay.sent_seconds
            log("[%s] src=%s dead: %s" % (name, link["src"], e))
            failures = 0 if relay.sent_bytes > 512 * 1024 else failures + 1
            idx += 1
    log("[%s] no working source" % name)
