"""Entry for the child processes, run as `python3 -I tvlinkd_run.py ...`.

-I keeps the user's site-packages (/storage/.local) out - that tree once broke
add-ons through requests -> charset_normalizer - but it also drops PYTHONPATH,
so the package directory is added here.

  tvlinkd_run.py daemon <userdata dir> <parent pid>
  tvlinkd_run.py epg <userdata dir> [force]
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

if sys.argv[1] == "daemon":
    from tvlinkd import daemon
    daemon.main(sys.argv[2], int(sys.argv[3]))
elif sys.argv[1] == "epg":
    from tvlinkd import epg
    epg.job(sys.argv[2], "force" in sys.argv[3:])
