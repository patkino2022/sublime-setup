# -*- coding: utf-8 -*-
"""Online metadata helper embedded in skin.sublime.

The package communicates directly with configured provider APIs and publishes only
SublimeHelper.* properties and plugin routes owned by skin.sublime.
"""
