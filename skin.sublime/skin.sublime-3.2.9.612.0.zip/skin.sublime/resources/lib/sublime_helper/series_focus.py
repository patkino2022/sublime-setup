# -*- coding: utf-8 -*-
"""Фокус при открытии сериала - на серии, которую смотреть дальше.

Владелец 17.10.2026: «чтобы при открытии сериала фокус был на последней
непросмотренной или неоконченной серии». В Kodi это умеет настройка
videolibrary.tvshowsselectfirstunwatcheditem (на .20 включена), но только для
библиотеки: CGUIWindowVideoNav::SelectDefaultItem сразу выходит, если папка
не videodb://. Серии Filmix - папки дополнения, поэтому это делает скин.

Какая серия: последняя, которую владелец смотрел в этом сериале (по времени
просмотра из базы Kodi, hub/history). Не досмотрена - она сама; досмотрена -
следующая за ней, в этом сезоне или первая следующего. Сериал, который не
начинали, не трогаем: там и так первая серия.

Окно сериала - вид 521: список 521 - сезоны, полоса 531 - серии выбранного
сезона (её адрес - FolderPath текущего сезона). Ставим сезон в 521, ждём,
пока полоса перечитает этот сезон, и ставим фокус на серию в 531. Если
владелец успел нажать кнопку раньше - ничего не трогаем.
"""
from __future__ import absolute_import, unicode_literals

import re
import threading
import time
try:
    from urllib.parse import parse_qs, urlsplit
except ImportError:  # pragma: no cover
    from urlparse import parse_qs, urlsplit

import xbmc

SEASONS = 521
EPISODES = 531
# Дольше полоса серий на .20 не грузится; дальше - уже не «при открытии».
GIVE_UP_SECONDS = 6.0

# С главного экрана сериал открывается маршрутом open/ (на .20 17.10.2026 -
# .../162271-coroll-talsui-2022/open/), из каталога - без него.
_SERIES_FOLDER = re.compile(
    r'^plugin://plugin\.video\.filmix/[^/?]+/(\d+)-[^/?]*/(?:open/)?(?:\?.*)?$')
# Папка одного сезона - в обычных видах (не 521) серии открываются так.
_SEASON_FOLDER = re.compile(
    r'^plugin://plugin\.video\.filmix/[^/?]+/(\d+)-[^/?]*/episodes/\?(?:.*&)?s=(\d+)')


def _match_other(folder):
    """HDrezka: (номер записи, сезон или None) для папки сериала или сезона, иначе None."""
    if not folder.startswith('plugin://plugin.video.hdrezka.tv/'):
        return None
    query = parse_qs(urlsplit(folder).query)
    if (query.get('mode') or [''])[0] != 'show':
        return None
    found = re.search(r'/(\d+)-', (query.get('uri') or query.get('url') or [''])[0])
    if not found:
        return None
    season = (query.get('season') or [None])[0]
    return found.group(1), (int(season) if season and season.isdigit() else None)


def _belongs(path, post_id):
    """Строка истории относится к этому сериалу (Filmix: /<id>-, HDrezka: post_id=<id>)."""
    if '/%s-' % post_id in path:
        return True
    return bool(re.search(r'[?&]post_id=%s(?:&|$)' % re.escape(str(post_id)), path))


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[skin.sublime] series focus: %s' % msg, level)


def _label(name):
    try:
        return xbmc.getInfoLabel(name) or ''
    except Exception:
        return ''


def _cond(name):
    try:
        return bool(xbmc.getCondVisibility(name))
    except Exception:
        return False


def _num(value, default=-1):
    try:
        return int(value)
    except Exception:
        return default


def _episode_states(post_id):
    """{(сезон, серия): (playcount, позиция, время просмотра)} для сериала."""
    from resources.lib.hub import history
    states = {}
    for row in history._rows():
        path = str(row.get('path') or '')
        if not row.get('episode') or not _belongs(path, post_id):
            continue
        key = (int(row.get('season') or 0), int(row.get('episode') or 0))
        current = (int(row.get('playcount') or 0), float(row.get('position') or 0),
                   int(row.get('last_watched') or 0))
        previous = states.get(key)
        # Одна серия бывает записана в нескольких озвучках - берём самое свежее.
        if previous is None or current[2] > previous[2] or \
                (current[2] == previous[2] and current[0] > previous[0]):
            states[key] = current
    return states


def target_for(post_id):
    """(сезон, серия, сдвиг): сдвиг 0 - сама серия, 1 - следующая за ней."""
    states = _episode_states(post_id)
    touched = [(stamp, key, playcount, position)
               for key, (playcount, position, stamp) in states.items()
               if playcount > 0 or position > 0]
    if not touched:
        return None
    stamp, (season, episode), playcount, position = max(touched)
    if playcount <= 0 and position > 0:
        return season, episode, 0
    return season, episode, 1


def _seasons():
    count = _num(_label('Container(%d).NumItems' % SEASONS), 0)
    found = []
    for index in range(count):
        season = _num(_label('Container(%d).ListItemAbsolute(%d).Season' % (SEASONS, index)))
        found.append(season)
    return found


def _episodes():
    count = _num(_label('Container(%d).NumItems' % EPISODES), 0)
    found = []
    for index in range(count):
        base = 'Container(%d).ListItemAbsolute(%d).' % (EPISODES, index)
        if _cond('Container(%d).ListItemAbsolute(%d).IsFolder' % (EPISODES, index)):
            found.append(-1)
            continue
        found.append(_num(_label(base + 'Episode')))
    return found


class Focuser(threading.Thread):
    """Дёшево, пока не открыт сериал Filmix: одно чтение адреса папки."""

    def __init__(self, monitor):
        super(Focuser, self).__init__(name='sublime-series-focus')
        self.daemon = True
        self._monitor = monitor
        self._folder = ''
        self._was_playing = False

    def _wait(self, seconds):
        return self._monitor.waitForAbort(seconds)

    def _place(self, folder, post_id):
        target = target_for(post_id)
        if not target:
            return
        season, episode, step = target
        deadline = time.time() + GIVE_UP_SECONDS
        # Список сезонов должен догрузиться.
        while _cond('Container(%d).IsUpdating' % SEASONS) or \
                not _num(_label('Container(%d).NumItems' % SEASONS), 0):
            if time.time() > deadline or self._wait(0.1) or _label('Container.FolderPath') != folder:
                return
        seasons = _seasons()
        if season not in seasons:
            return
        season_index = seasons.index(season)
        for attempt in range(2):
            builtin = 'SetFocus(%d,%d,absolute)' % (SEASONS, season_index)
            xbmc.executebuiltin(builtin)
            # Полоса 531 перечитывает сезон под новым курсором.
            episodes = []
            while time.time() < deadline:
                if self._wait(0.15) or _label('Container.FolderPath') != folder:
                    return
                if _cond('Container(%d).IsUpdating' % EPISODES):
                    continue
                if _num(_label('Container(%d).ListItem.Season' % SEASONS)) != seasons[season_index]:
                    continue
                episodes = _episodes()
                if episodes and _num(_label('Container(%d).ListItemAbsolute(0).Season' % EPISODES)) \
                        in (seasons[season_index], -1):
                    break
                episodes = []
            if not episodes:
                return
            if step == 0:
                wanted = episode if seasons[season_index] == season else None
                if wanted in episodes:
                    index = episodes.index(wanted)
                    break
                return
            later = [e for e in episodes if e > episode] if seasons[season_index] == season \
                else [e for e in episodes if e > 0]
            if later:
                index = episodes.index(min(later))
                break
            # Серия была последней в сезоне - первая серия следующего.
            if attempt == 0 and season_index + 1 < len(seasons):
                season_index += 1
                continue
            # Досмотрен весь сериал - оставляем на последней просмотренной.
            if episode in episodes:
                index = episodes.index(episode)
                break
            return
        else:
            return
        if _label('Container.FolderPath') != folder:
            return
        # Владелец успел сам уйти на другой сезон или в другой список - его
        # выбор важнее нашего.
        if _label('Container(%d).CurrentItem' % SEASONS) != str(season_index + 1) or                 _num(_label('System.CurrentControlId')) not in (SEASONS, EPISODES, 500):
            _log('%s: владелец уже выбрал сам' % post_id)
            return
        if not _cond('Control.IsVisible(%d)' % SEASONS):
            return
        xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (EPISODES, index))
        _log('%s: сезон %s, серия %s (%s)' % (
            post_id, seasons[season_index], episodes[index],
            'начатая' if step == 0 else 'следующая за последней просмотренной'))

    def _settled(self, folder):
        """Дождаться, пока окно перестанет менять вид.

        После загрузки папки скин ставит сохранённый для неё вид (sublime
        viewtypes), и на .30 17.10.2026 фокус, поставленный до этого, остался
        на полосе 531 уже скрытого вида 521. Ждём, пока вид не меняется 0,6 с.
        """
        deadline = time.time() + 3.0
        mode = None
        since = time.time()
        while time.time() < deadline:
            if _label('Container.FolderPath') != folder:
                return False
            current = (_label('Container.ViewMode'), _cond('Container.IsUpdating'))
            if current != mode:
                mode = current
                since = time.time()
            elif not current[1] and time.time() - since >= 0.6:
                return True
            if self._wait(0.1):
                return False
        return not _cond('Container.IsUpdating')

    def _place_plain(self, folder, post_id, season_folder=None):
        """Обычный вид: в списке сезонов - сезон, в папке сезона - серия."""
        target = target_for(post_id)
        if not target:
            return
        season, episode, step = target
        deadline = time.time() + GIVE_UP_SECONDS
        while _cond('Container.IsUpdating') or not _num(_label('Container.NumItems'), 0):
            if time.time() > deadline or self._wait(0.1) or _label('Container.FolderPath') != folder:
                return
        view = _num(_label('System.CurrentControlId'))
        if view == SEASONS and season_folder is None:
            # Вид 521 бывает ещё «невидим» в миг, когда папка уже загружена
            # (.20, 17.10.2026: сезон поставлен, серия в полосе - нет). Решаем
            # по списку, который в фокусе.
            self._place(folder, post_id)
            return
        if not 500 <= view < 600:
            return
        start_item = _label('Container.CurrentItem')
        count = _num(_label('Container.NumItems'), 0)
        index = None
        if season_folder is None:
            # Список сезонов: следующая серия могла уже быть в следующем
            # сезоне, но этого не узнать, не открыв сезон, - ставим сезон
            # последней серии, внутри него фокус встанет при входе.
            for i in range(count):
                if _num(_label('Container.ListItemAbsolute(%d).Season' % i)) == season:
                    index = i
                    break
            what = 'сезон %s' % season
        else:
            if season_folder != season:
                return
            numbers = []
            for i in range(count):
                if _cond('Container.ListItemAbsolute(%d).IsFolder' % i):
                    numbers.append(-1)
                else:
                    numbers.append(_num(_label('Container.ListItemAbsolute(%d).Episode' % i)))
            if step == 0 and episode in numbers:
                index = numbers.index(episode)
            elif step == 1:
                later = [n for n in numbers if n > episode]
                index = numbers.index(min(later)) if later else (
                    numbers.index(episode) if episode in numbers else None)
            what = 'серия %s' % (numbers[index] if index is not None else '?')
        if index is None or _label('Container.FolderPath') != folder:
            return
        if _label('Container.CurrentItem') != start_item or                 _num(_label('System.CurrentControlId')) != view:
            _log('%s: владелец уже выбрал сам' % post_id)
            return
        xbmc.executebuiltin('SetFocus(%d,%d,absolute)' % (view, index))
        _log('%s: %s (вид %d)' % (post_id, what, view))

    def _step(self):
        playing = xbmc.Player().isPlayingVideo()
        if playing:
            self._was_playing = True
            return 1.0
        if not _cond('Window.IsActive(videos)'):
            self._folder = ''
            return 0.5
        folder = _label('Container.FolderPath')
        series = _SERIES_FOLDER.match(folder)
        season = None if series else _SEASON_FOLDER.match(folder)
        other = None if (series or season) else _match_other(folder)
        if not (series or season or other):
            self._folder = folder
            return 0.5
        # Новый сериал или сезон - или вернулись к нему после просмотра серии.
        if folder != self._folder or self._was_playing:
            self._folder = folder
            self._was_playing = False
            if not self._settled(folder):
                return 0.3
            try:
                if other:
                    post_id, season_no = other
                    if season_no is None and _cond('Control.IsVisible(%d)' % SEASONS):
                        self._place(folder, post_id)
                    else:
                        self._place_plain(folder, post_id, season_no)
                elif series and _cond('Control.IsVisible(%d)' % SEASONS):
                    self._place(folder, series.group(1))
                elif series:
                    self._place_plain(folder, series.group(1))
                else:
                    self._place_plain(folder, season.group(1), int(season.group(2)))
            except Exception as exc:
                _log('сбой: %s' % exc, xbmc.LOGWARNING)
        return 0.3

    def run(self):
        while not self._monitor.abortRequested():
            try:
                pause = self._step()
            except Exception as exc:
                _log('сбой: %s' % exc, xbmc.LOGWARNING)
                pause = 2.0
            if self._wait(pause):
                break


def start(monitor):
    focuser = Focuser(monitor)
    focuser.start()
    return focuser
