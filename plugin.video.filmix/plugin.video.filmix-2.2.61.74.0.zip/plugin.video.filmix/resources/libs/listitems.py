# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import html
import re

import simplemedia
from future.utils import iteritems

from .utilities import Utilities
from .utilities import plugin
from .manual_overrides import apply_manual_override
from .tmdbresolver import TMDbResolver

__all__ = ['MainMenuItem', 'ItemInfo', 'PostInfo', 'SeasonInfo', 'VideoInfo', 'EmptyListItem', 'ListItem', 'FilterItem']

# Reuse the single shared addon instance (same addon-id, settings and gettext)
# created in utilities.py instead of constructing a second native Addon.
addon = plugin
_ = addon.initialize_gettext()


def _clean_text(value):
    if value is None:
        return ''
    if isinstance(value, (list, tuple, set)):
        value = ' / '.join([_clean_text(v) for v in value if v not in [None, '']])
    elif isinstance(value, dict):
        value = ' / '.join([_clean_text(v) for _, v in sorted(value.items()) if v not in [None, '']])
    elif not isinstance(value, str):
        value = str(value)
    try:
        value = html.unescape(value)
    except Exception:
        pass
    value = addon.remove_html(value)
    value = value.replace(' ', ' ')
    value = re.sub(r'\s+', ' ', value, flags=re.UNICODE).strip()
    return value


def _looks_ukrainian_text(value):
    text = _clean_text(value).lower()
    if not text:
        return False
    # Ukrainian-only Cyrillic letters. Russian/Serbian text must not contain these.
    if re.search(r'[іїєґ]', text, flags=re.UNICODE):
        return True
    # Extra safety for common Ukrainian words when input was transliterated/mixed.
    return bool(re.search(r"\b(вирушає|бабусі|дрімучий|зовсім|здається|червона|маленька)\b", text, flags=re.UNICODE))


def _looks_russian_compatible_text(value):
    text = _clean_text(value)
    if not text:
        return False
    if _looks_ukrainian_text(text):
        return False
    # Filmix RU UI must prefer Cyrillic source plot; never expose English provider
    # overview as a replacement for a Filmix source description.
    return bool(re.search(r'[А-Яа-яЁё]', text, flags=re.UNICODE))


def _select_plot(item_info):
    item_info = item_info or {}
    # Source Filmix fields seen across API/cache/post payloads. Keep provider
    # overview last and only if it is already Cyrillic/RU-compatible.
    source_keys = (
        'short_story', 'full_story', 'plot', 'description', 'descr', 'desc',
        'story', 'storyline', 'summary', 'synopsis', 'annotation', 'about',
        'body', 'text', 'content', 'fullplot', 'full_plot', 'shortplot',
        'short_plot', 'originalplot', 'original_plot', 'plot_ru',
        'overview_ru', 'description_ru', 'fullDescription', 'shortDescription',
        'full_description', 'short_description', 'comment', 'info',
    )
    for key in source_keys:
        plot = _clean_text(item_info.get(key))
        if plot and _looks_russian_compatible_text(plot):
            return plot
    # If the source plot is Cyrillic but tripped a keyword false positive, prefer
    # it over empty. Only block explicit Ukrainian-only letters.
    for key in source_keys:
        plot = _clean_text(item_info.get(key))
        if plot and re.search(r'[А-Яа-яЁё]', plot, flags=re.UNICODE) and not re.search(r'[іїєґ]', plot.lower(), flags=re.UNICODE):
            return plot
    overview = _clean_text(item_info.get('resolved_overview') or item_info.get('tmdb_overview'))
    if overview and _looks_russian_compatible_text(overview):
        return overview
    return ''


def _clean_list(value):
    if value is None:
        return []
    if isinstance(value, dict):
        items = list(value.values())
    elif isinstance(value, (list, tuple, set)):
        items = list(value)
    else:
        items = [value]
    result = []
    for item in items:
        cleaned = _clean_text(item)
        if cleaned:
            result.append(cleaned)
    return result


def _is_blocked_genre_label(value):
    text = _clean_text(value).lower().replace('ё', 'е')
    text = re.sub(r'[^\w\s]+', ' ', text, flags=re.UNICODE)
    text = re.sub(r'\s+', ' ', text, flags=re.UNICODE).strip()
    # Language/voice tags must not be exposed as Kodi/TMDb genres.
    blocked = (
        'на украинском',
        'украинский',
        'украинские',
        'українською',
        'ukrainian',
        'ukraine language',
    )
    return any(b in text for b in blocked)


def _filter_genre_list(values):
    return [v for v in (values or []) if not _is_blocked_genre_label(v)]

def _extract_external_ids(value):
    imdb_id = None
    tmdb_id = None

    def _walk(obj, parent_key=''):
        nonlocal imdb_id, tmdb_id
        if isinstance(obj, dict):
            for key, val in obj.items():
                key_l = str(key).lower()
                if any(marker in key_l for marker in ('reject', 'miss', 'blocked')):
                    continue
                if imdb_id is None and 'imdb' in key_l and isinstance(val, str) and val.startswith('tt'):
                    imdb_id = val
                if tmdb_id is None and 'tmdb' in key_l and isinstance(val, (str, int)) and str(val).isdigit():
                    tmdb_id = str(val)
                _walk(val, key_l)
        elif isinstance(obj, (list, tuple)):
            for val in obj:
                _walk(val, parent_key)
        elif isinstance(obj, str):
            if any(marker in str(parent_key or '').lower() for marker in ('reject', 'miss', 'blocked')):
                return
            if imdb_id is None:
                m = re.search(r'\btt\d{6,10}\b', obj)
                if m:
                    imdb_id = m.group(0)
            if tmdb_id is None and 'tmdb' in parent_key:
                m = re.search(r'\b\d{1,12}\b', obj)
                if m:
                    tmdb_id = m.group(0)

    _walk(value)
    return imdb_id, tmdb_id


class ItemInfo(simplemedia.VideoInfo):
    _path = None
    _trailer = None
    _mediatype = None
    _post_info = None
    post_id = 0
    content_name = ''

    def __init__(self, item_info, for_play=False, atl_names=False):
        try:
            item_info, _ = apply_manual_override(item_info)
        except Exception:
            pass
        self._item_info = item_info
        self._for_play = for_play
        self._atl_names = atl_names and not for_play
        self.post_id = item_info['id']
        self.content_name = '{0}-{1}'.format(item_info['id'], item_info['alt_name'])

    @property
    def date(self):
        return None

    @property
    def premiered(self):
        # Prefer TMDb/explicit release date, but fall back to every Filmix release-date
        # field seen in API payloads. Do not use date_atom here: it is Filmix add-date,
        # not release date.
        value = (self._item_info.get('resolved_premiered')
                 or self._item_info.get('premiered')
                 or self._item_info.get('release_date')
                 or self._item_info.get('released')
                 or self._item_info.get('date_release')
                 or self._item_info.get('release')
                 or self._item_info.get('air_date')
                 or self._item_info.get('first_air_date'))
        if value and re.match(r'^\d{4}-\d{2}-\d{2}$', str(value)):
            return str(value)
        if value:
            m = re.search(r'(\d{4}-\d{2}-\d{2})', str(value))
            if m:
                return m.group(1)

    @property
    def aired(self):
        if self.mediatype in ['tvshow', 'season', 'episode']:
            return self.premiered

    @property
    def genre(self):
        return _filter_genre_list(_clean_list(self._item_info.get('categories')))

    @property
    def country(self):
        return _clean_list(self._item_info.get('countries'))

    @property
    def year(self):
        if self.mediatype in ['movie', 'tvshow']:
            year = self._item_info.get('resolved_year') or self._item_info.get('year')
            if not year:
                premiered = self.premiered
                if premiered and len(str(premiered)) >= 4 and str(premiered)[:4].isdigit():
                    year = str(premiered)[:4]
            if year:
                return int(year)

    @property
    def episode(self):
        if self.mediatype in ['tvshow']:
            return 0

    @property
    def season(self):
        if self.mediatype in ['tvshow', 'season']:
            return 1

    @property
    def cast(self):
        actors = self._item_info.get('actors')
        if isinstance(actors, list):
            return actors
        elif isinstance(actors, dict):
            cast = []
            for key, val in iteritems(actors):
                cast.append(_clean_text(val))
            return cast

    @property
    def title(self):
        if self._atl_names:
            title = self._atl_title()
        else:
            title = self._base_title()
        return _clean_text(title)

    @property
    def display_title(self):
        return _clean_text(self._title())

    @property
    def original_title(self):
        if self.mediatype in ['tvshow', 'movie']:
            title = self._item_info.get('original_title') or self._item_info.get('title')
            return _clean_text(title)

    @property
    def originaltitle(self):
        return self.original_title

    @property
    def tvshowtitle(self):
        if self.mediatype in ['tvshow', 'season', 'episode']:
            title = self._base_title() or self.original_title
            return _clean_text(title)

    @property
    def imdbnumber(self):
        imdb_id, _ = self._resolved_ids()
        return imdb_id

    @property
    def status(self):
        if self.mediatype == 'tvshow':
            serial_stats = self._item_info.get('serial_stats')
            if serial_stats is not None:
                return serial_stats.get('comment')

    @property
    def path(self):
        return self._path

    @property
    def trailer(self):
        return self._trailer

    @property
    def dateadded(self):
        if self.mediatype in ['movie', 'tvshow']:
            date_atom = self._item_info.get('date_atom') or ''
            if len(date_atom) >= 19:
                return '{0} {1}'.format(date_atom[0:10], date_atom[11:19])

    @property
    def playcount(self):
        value = self._item_info.get('local_playcount')
        if value not in [None, '']:
            try:
                return int(value)
            except Exception:
                return None

    @property
    def mediatype(self):
        _mediatype = self._mediatype
        if _mediatype is None:
            if Utilities.is_movie(self._item_info):
                _mediatype = 'movie'
            else:
                _mediatype = 'tvshow'
            self._mediatype = _mediatype
        return self._mediatype

    def _base_title(self):
        return _clean_text(self._item_info.get('title'))

    def _title(self):
        title = self._base_title()
        quality = _clean_text(self._item_info.get('quality'))
        if quality and not self._for_play:
            title = '{0} [{1}]'.format(title, quality)
        return title

    def _resolved_ids(self):
        imdb_id = self._item_info.get('resolved_imdb_id') or self._item_info.get('imdb_id')
        tmdb_id = self._item_info.get('resolved_tmdb_id') or self._item_info.get('tmdb_id')
        if not imdb_id or not tmdb_id:
            rec_imdb, rec_tmdb = _extract_external_ids(self._item_info)
            imdb_id = imdb_id or rec_imdb
            tmdb_id = tmdb_id or rec_tmdb
        return imdb_id, tmdb_id

    @property
    def unique_ids(self):
        if isinstance(self._item_info, dict) and self._item_info.get('_filmix_identity_rejected'):
            return {}
        imdb_id, tmdb_id = self._resolved_ids()
        ids = {}
        if self.mediatype in ['episode', 'season']:
            if imdb_id:
                ids['tvshow.imdb'] = imdb_id
            if tmdb_id:
                ids['tvshow.tmdb'] = tmdb_id
        else:
            if imdb_id:
                ids['imdb'] = imdb_id
            if tmdb_id:
                ids['tmdb'] = tmdb_id
        return ids

    @property
    def infoproperties(self):
        props = {}
        if isinstance(self._item_info, dict) and self._item_info.get('_filmix_identity_rejected'):
            props['FilmixIdentityRejected'] = 'true'
            if self._item_info.get('_filmix_rejected_tmdb_id'):
                props['FilmixRejectedTmdbID'] = str(self._item_info.get('_filmix_rejected_tmdb_id'))
            return props
        imdb_id, tmdb_id = self._resolved_ids()
        tmdb_type = self._item_info.get('resolved_tmdb_type')
        if not tmdb_type:
            if self.mediatype in ['movie']:
                tmdb_type = 'movie'
            elif self.mediatype in ['tvshow', 'season', 'episode']:
                tmdb_type = 'tv'
        if tmdb_type:
            props['tmdb_type'] = tmdb_type
        if tmdb_id:
            if self.mediatype in ['episode', 'season']:
                props['tvshow.tmdb_id'] = tmdb_id
            props['tmdb_id'] = tmdb_id
        if imdb_id:
            props['imdb_id'] = imdb_id
        return props

    def _atl_title(self):
        title_parts = []
        if self.mediatype == 'movie':
            title_parts.append(self.original_title)
            if self.year is not None:
                title_parts.append('({0})'.format(self.year))
        elif self.mediatype == 'episode':
            title_parts.append(self.original_title or self._item_info.get('title'))
            title_parts.append('s%02de%02d' % (self.season, self.episode))
        else:
            title_parts.append(self._title())
        return '.'.join([_clean_text(i) for i in title_parts if i])

    @staticmethod
    def _normalize_art_url(value, kind='landscape'):
        if not value:
            return None
        value = str(value).strip()
        # Filmix API/cache can hold protocol-relative or already-trimmed source
        # poster URLs.  Kodi may still show the poster in cards, but the skin's
        # background preprocessor can fail on malformed URLs, leaving an empty
        # background (seen on "Сезон").  Normalize them before publishing art.
        if value.startswith('//'):
            value = 'https:' + value
        # Схему адреса картинки не меняем: какой дал API, такой и идёт. Склад
        # vip по http сам переадресует на свой https, склад зеркала cyou
        # отвечает по http, а по https отдаёт чужой сертификат (filmix.biz).
        # Прежний подъём http -> https на всё filmixapp ломал картинки cyou:
        # на .20 19.11.2026 плитки новинок стояли серыми (178 ошибок SSL).
        if value.startswith('umbs.filmix'):
            value = 'http://th' + value
        elif value.startswith('thumbs.filmix') or value.startswith('filmix'):
            value = 'http://' + value
        # Filmix's own thumbnail CDN: its `orig` is the source image, not an
        # oversized master, so keep upgrading those. The TMDb entries that used
        # to be rewritten *up* to /original/ are gone - see below.
        for src, dst in (('thumbs/w220', 'orig'), ('thumbs/w300', 'orig'),
                         ('thumbs/w500', 'orig'), ('thumbs/w780', 'orig')):
            value = value.replace(src, dst)
        # Pin TMDb art to the size the 1920x1080 GUI surface can show.
        if value.startswith('/'):
            value = '{0}{1}{2}'.format(TMDbResolver.TMDB_IMAGE_BASE,
                                       TMDbResolver.tmdb_size_for(kind), value)
        else:
            value = TMDbResolver.normalize_tmdb_size(value, kind)
        return value

    @staticmethod
    def _is_tmdb_art_url(value):
        try:
            text = str(value or '').strip().lower()
            return bool(text.startswith('/') or 'image.tmdb.org/' in text or 'themoviedb.org/t/p/' in text)
        except Exception:
            return False

    def get_poster(self):
        # Только постер источника. Кешированный TMDb-арт мог остаться от старых
        # сборок, и публиковать его нельзя: опознание и картинки - работа скина.
        for key in ('poster', 'thumb', 'thumbnail', 'image'):
            poster = self._item_info.get(key) or ''
            if poster and not self._is_tmdb_art_url(poster):
                return self._normalize_art_url(poster, 'poster')
        return None

    def get_thumb(self):
        if self.mediatype == 'episode':
            episode_item = getattr(self, '_episode_item', None) or {}
            if isinstance(episode_item, dict):
                for key in ('thumb', 'thumbnail', 'image', 'still', 'poster'):
                    value = episode_item.get(key)
                    if value:
                        return self._normalize_art_url(value)
            return self.get_fanart() or self.get_poster()
        # Fullscreen OSD skins often read VideoPlayer.Art(thumb) for the large
        # horizontal pause thumbnail. For playback prefer landscape/fanart over poster.
        if self.for_play:
            return self.get_fanart() or self.get_poster()
        return self.get_poster()

    def get_fanart(self):
        # Задник и ландшафт - метаданные скина. Провайдер их не отдаёт, иначе в
        # виджет утечёт TMDb-арт из старого кеша.
        return None

    def set_path(self, path):
        self._path = path


    @property
    def item_info(self):
        return self._item_info

    @property
    def for_play(self):
        return self._for_play

    def get_section(self):
        section_id = self._item_info['section']
        if section_id in [0, 999]:
            section = 'movies'
        elif section_id == 7:
            section = 'serials'
        elif section_id == 14:
            section = 'multfilms'
        elif section_id == 93:
            section = 'multserials'
        else:
            section = 'none'
        return section


class PostInfo(ItemInfo):

    def __init__(self, item_info):
        super(PostInfo, self).__init__(item_info, False, False)

    @property
    def plot(self):
        return _select_plot(self._item_info)

    @property
    def director(self):
        if isinstance(self._item_info.get('directors'), dict):
            directors = []
            for key, val in iteritems(self._item_info['directors']):
                directors.append(_clean_text(val))
        else:
            directors = self._item_info.get('directors')
        return directors

    @property
    def episode(self):
        if self.mediatype == 'tvshow':
            total_episodes = 0
            playlist = self._item_info['player_links']['playlist']
            if isinstance(playlist, dict):
                for season, season_translations in iteritems(playlist):
                    episode = 0
                    for translation, episodes in iteritems(season_translations):
                        episode = max(episode, len(episodes))
                    total_episodes += episode
            return total_episodes

    @property
    def season(self):
        if self.mediatype == 'tvshow':
            playlist = self._item_info['player_links']['playlist']
            return len(playlist)

    def _title(self):
        title = self._base_title()
        rip = _clean_text(self._item_info.get('rip'))
        if rip:
            title = '{0} [{1}]'.format(title, rip)
        return title


class SeasonInfo(ItemInfo):
    _season = None
    _episodes = None
    _translation = None

    def __init__(self, item_info):
        super(SeasonInfo, self).__init__(item_info, False, False)
        self._mediatype = 'season'

    @property
    def plot(self):
        return _select_plot(self._item_info)

    @property
    def director(self):
        if isinstance(self._item_info.get('directors'), dict):
            directors = []
            for key, val in iteritems(self._item_info['directors']):
                directors.append(_clean_text(val))
        else:
            directors = self._item_info.get('directors')
        return directors

    @property
    def episode(self):
        return self._episodes

    @property
    def season(self):
        return max(1, int(self._season))

    @property
    def title(self):
        return _clean_text('{0} {1}'.format(_('Season'), self._season))

    def get_translation(self):
        return self._translation

    def get_season(self):
        return self._season

    def set_season_info(self, translation, season, episodes):
        self._translation = translation
        self._season = season
        self._episodes = episodes


class VideoInfo(ItemInfo):
    _episode = None
    _season = None
    _translation = None
    _episode_item = None

    def __init__(self, item_info, for_play=False, atl_names=False):
        super(VideoInfo, self).__init__(item_info, for_play, atl_names)

    def _episode_data(self):
        return self._episode_item if isinstance(self._episode_item, dict) else {}

    def _episode_field(self, *keys):
        episode_item = self._episode_data()
        for key in keys:
            value = episode_item.get(key)
            if value not in [None, '', []]:
                return value
        return None

    @property
    def display_title(self):
        if self.mediatype == 'episode':
            name = self._episode_field('title', 'name')
            if name:
                return _clean_text(name)
            ep = self.episode
            if ep is not None:
                try:
                    num = int(ep)
                except Exception:
                    num = ep
                return _clean_text('{0} {1}'.format(_('Episode'), num))
        return super(VideoInfo, self).display_title

    @property
    def title(self):
        if self.mediatype == 'episode':
            return self.display_title
        return super(VideoInfo, self).title

    @property
    def episode(self):
        if self.mediatype == 'episode':
            return int(self._episode)

    @property
    def season(self):
        if self.mediatype == 'episode' and self._season is not None:
            return max(1, int(self._season))

    @property
    def originaltitle(self):
        if self.mediatype == 'episode':
            return self.title
        return super(VideoInfo, self).originaltitle

    @property
    def plot(self):
        if self.mediatype == 'episode':
            plot = self._episode_field('short_story', 'description', 'plot', 'story')
            if plot and not _looks_ukrainian_text(plot):
                return _clean_text(plot)
            # do not fall back to the parent TV-show plot for
            # episode rows. If TMDb/Filmix has no episode plot, the skin should
            # show its normal "information unavailable" state instead of the
            # same series synopsis on every episode.
            return None
        return _select_plot(self._item_info)

    @property
    def duration(self):
        duration = self._episode_field('duration') if self.mediatype == 'episode' else None
        if duration in [None, '']:
            duration = self._item_info.get('duration')
        try:
            duration = int(float(duration))
        except Exception:
            return None
        return duration * 60

    @property
    def mediatype(self):
        _mediatype = self._mediatype
        if _mediatype is None:
            _mediatype = super(VideoInfo, self).mediatype
            if _mediatype == 'tvshow':
                _mediatype = 'episode'
            self._mediatype = _mediatype
        return self._mediatype

    def _title(self):
        if self.mediatype == 'episode':
            return self.display_title
        return super(VideoInfo, self)._title()

    @property
    def premiered(self):
        premiered = self._episode_field('premiered', 'aired', 'air_date', 'date')
        if premiered and re.match(r'^\d{4}-\d{2}-\d{2}$', str(premiered)):
            return str(premiered)
        return super(VideoInfo, self).premiered

    @property
    def aired(self):
        return self.premiered

    def set_episode_info(self, season, episode, translation, episode_item=None):
        self._season = season
        self._episode = episode
        self._translation = translation
        self._episode_item = episode_item if isinstance(episode_item, dict) else None

    def get_translation(self):
        return self._translation

    def get_season(self):
        return self._season

    def get_episode(self):
        return self._episode


class EmptyListItem(simplemedia.ListItemInfo):
    _url = None
    _path = None
    _info = None

    @property
    def path(self):
        return self._path

    @property
    def url(self):
        return self._url

    def set_url(self, url):
        self._url = url

    def set_path(self, path):
        self._path = path


class ListItem(EmptyListItem):
    _properties = None
    _context_menu = None

    def __init__(self, video_info):
        self._info = video_info
        self._item_info = video_info.item_info
        self._mediatype = video_info.mediatype
        self._for_play = video_info.for_play
        self._force_tvshow_folder = False
        self._force_content_lookup = None
        self._force_direct_play = False
        self._suppress_info_lookup = False
        self.post_id = video_info.post_id

    @property
    def label(self):
        return getattr(self._info, 'display_title', self._info.title)

    @property
    def path(self):
        return self._path

    @property
    def is_folder(self):
        if isinstance(self._info, VideoInfo):
            return False
        # 2.2 DEFAULT_OPEN:
        # Remove the old Home-widget TV-show info workaround. TV shows and seasons
        # are normal folders again, so Kodi/skin opens them with the default action.
        return self._mediatype in ['season', 'tvshow']

    @property
    def is_playable(self):
        if isinstance(self._info, VideoInfo):
            return True
        return self._mediatype in ['movie', 'episode']

    @property
    def content_lookup(self):
        if self._mediatype == 'tvshow':
            return False
        if getattr(self, '_suppress_info_lookup', False):
            return False
        if self._force_direct_play:
            return False
        if self._mediatype in ['season', 'episode']:
            return False
        if self._force_content_lookup is not None:
            return bool(self._force_content_lookup)
        return True

    @property
    def art(self):
        art = {}
        poster = self._info.get_poster()
        thumb = self._info.get_thumb()
        fanart = self._info.get_fanart()

        if poster:
            art['poster'] = poster
            art['icon'] = poster
            if self._mediatype in ['season', 'episode']:
                art['tvshow.poster'] = poster

        if fanart:
            art['fanart'] = fanart
            art['landscape'] = fanart
            if self._mediatype in ['tvshow', 'season', 'episode']:
                art['tvshow.fanart'] = fanart

        if thumb:
            # During playback thumb must be horizontal when possible; on browsing rows
            # existing poster behaviour stays intact through ListItem.thumb.
            art['thumb'] = thumb
            if not poster:
                art['icon'] = thumb

        if self._mediatype == 'episode':
            try:
                episode_item = self._info._episode_data()
            except Exception:
                episode_item = {}
            episode_still = None
            if isinstance(episode_item, dict):
                for key in ('still', 'thumb', 'thumbnail', 'image', 'landscape', 'fanart', 'backdrop'):
                    value = episode_item.get(key)
                    if value:
                        episode_still = self._info._normalize_art_url(value)
                        break
            if episode_still:
                # publish episode-native artwork as normal Kodi ListItem.Art.
                # Skins must not need focused-row Window.Property or Container.Refresh
                # to draw episode thumbnails on the first render.
                art['still'] = episode_still
                art['thumb'] = episode_still
                art['landscape'] = episode_still
                art.setdefault('fanart', episode_still)
                art['icon'] = episode_still

        art = {k: v for k, v in art.items() if v not in [None, '']}
        # Адрес на хосте, который не отвечает, Kodi не отдаём: он останавливает
        # загрузчик текстур и с ним всю отрисовку экрана. См. image_host.py.
        try:
            from . import image_host
            art = {k: v for k, v in art.items() if image_host.usable(v)}
        except Exception:
            pass
        return art

    @property
    def thumb(self):
        if self._mediatype in ['movie', 'tvshow', 'season']:
            return self._info.get_poster()
        elif self._mediatype in ['episode']:
            return self._info.get_thumb()

    @property
    def fanart(self):
        return self._info.get_fanart()

    @property
    def info(self):
        info = self._info.get_info()
        if getattr(self, '_suppress_info_lookup', False):
            # Direct-play episode rows must not be treated as library/TMDb info targets
            # by Kodi global default-select action. Keep a minimal playable video item.
            title = getattr(self._info, 'display_title', None) or getattr(self._info, 'title', None)
            minimal = {'mediatype': 'video'}
            if title:
                minimal['title'] = title
            playcount = None
            if isinstance(self._properties, dict):
                playcount = self._properties.get('playcount')
            if playcount not in [None, '']:
                try:
                    minimal['playcount'] = int(playcount)
                except Exception:
                    pass
            return {'video': minimal}

        info['mediatype'] = self._mediatype

        title = getattr(self._info, 'title', None)
        if self._mediatype == 'episode':
            title = getattr(self._info, 'display_title', title)
        if title:
            info['title'] = title

        try:
            plot = getattr(self._info, 'plot', None)
            if plot:
                info['plot'] = plot
                info['plotoutline'] = plot
        except Exception:
            pass

        originaltitle = getattr(self._info, 'originaltitle', None)
        if originaltitle:
            info['originaltitle'] = originaltitle

        if self._mediatype in ['tvshow', 'season', 'episode']:
            tvshowtitle = getattr(self._info, 'tvshowtitle', None)
            if tvshowtitle:
                info['tvshowtitle'] = tvshowtitle

        season = getattr(self._info, 'season', None)
        if season is not None and self._mediatype in ['tvshow', 'season', 'episode']:
            info['season'] = season

        episode = getattr(self._info, 'episode', None)
        if episode is not None and self._mediatype in ['tvshow', 'season', 'episode']:
            info['episode'] = episode

        premiered = getattr(self._info, 'premiered', None)
        if premiered:
            info['premiered'] = premiered
            if self._mediatype in ['tvshow', 'season', 'episode']:
                info['aired'] = premiered
        else:
            info.pop('premiered', None)

        year = getattr(self._info, 'year', None)
        if year not in [None, '']:
            try:
                info['year'] = int(year)
            except Exception:
                pass

        playcount = getattr(self._info, 'playcount', None)
        if playcount is None and isinstance(self._properties, dict):
            playcount = self._properties.get('playcount')
        if playcount is not None and playcount != '':
            try:
                info['playcount'] = int(playcount)
            except Exception:
                pass

        info.pop('date', None)
        return {'video': info}

    @property
    def unique_ids(self):
        if getattr(self, '_suppress_info_lookup', False):
            return None
        return getattr(self._info, 'unique_ids', None)

    @property
    def infoproperties(self):
        if getattr(self, '_suppress_info_lookup', False):
            return {}
        return getattr(self._info, 'infoproperties', None)

    @property
    def context_menu(self):
        return self._context_menu

    @property
    def properties(self):
        properties = {}
        if isinstance(self._properties, dict):
            properties.update(self._properties)
        info_props = getattr(self._info, 'infoproperties', None)
        if isinstance(info_props, dict):
            properties.update(info_props)

        # 2.2.52/2.2.59: AF3 Home sometimes reads plot/date from ListItem
        # properties rather than only InfoTagVideo.  FastWidgetItemBuild used
        # to keep the plot only in the video info block; expose the same
        # already-merged display fields as cheap properties too.
        try:
            data = self._item_info if isinstance(self._item_info, dict) else {}
            if self._mediatype == 'episode':
                plot = getattr(self._info, 'plot', None)
            else:
                plot = _select_plot(data)
            if plot:
                for _key in ('Plot', 'plot', 'Description', 'description',
                             'ShortPlot', 'shortplot', 'short_story',
                             'Overview', 'overview', 'PlotOutline', 'plotoutline'):
                    properties.setdefault(_key, plot)
            premiered = (data.get('resolved_premiered') or data.get('premiered') or
                         data.get('release_date') or data.get('released') or
                         data.get('date_release') or data.get('release') or
                         data.get('air_date') or data.get('first_air_date'))
            if premiered:
                m = re.search(r'(\d{4}-\d{2}-\d{2})', str(premiered))
                if m:
                    premiered = m.group(1)
                properties.setdefault('Premiered', str(premiered))
                properties.setdefault('premiered', str(premiered))
                properties.setdefault('ReleaseDate', str(premiered))
                properties.setdefault('release_date', str(premiered))
            year = data.get('resolved_year') or data.get('year')
            if not year and premiered:
                m_year = re.search(r'((?:19|20)\d{2})', str(premiered))
                if m_year:
                    year = m_year.group(1)
            if year not in [None, '']:
                properties.setdefault('Year', str(year))
                properties.setdefault('year', str(year))
                properties.setdefault('ResolvedYear', str(year))
                properties.setdefault('resolved_year', str(year))
            country = (_clean_list(data.get('filmix_countries')) or
                       _clean_list(data.get('source_countries')) or
                       _clean_list(data.get('countries')))
            if country:
                country_text = ' / '.join(country)
                properties.setdefault('Country', country_text)
                properties.setdefault('country', country_text)
                properties.setdefault('Countries', country_text)
                properties.setdefault('countries', country_text)
                properties.setdefault('FilmixSourceCountry', country_text)
                properties.setdefault('FilmixSourceCountries', country_text)
                properties.setdefault('SourceCountry', country_text)
                properties.setdefault('SourceCountries', country_text)
            if data.get('id') not in [None, '']:
                properties.setdefault('FilmixPostID', str(data.get('id')))
        except Exception:
            pass

        if self._mediatype in ['movie', 'tvshow', 'season', 'episode']:
            properties['dbtype'] = self._mediatype
            properties['DBTYPE'] = self._mediatype

        if self._mediatype == 'tvshow':
            # 2.2 DEFAULT_OPEN: keep folder/playable flags aligned
            # with the real Kodi item type; do not disguise TV shows as non-folders.
            properties.setdefault('IsFolder', 'true')
            properties.setdefault('isfolder', 'true')
            properties.setdefault('IsPlayable', 'false')
            properties.setdefault('isplayable', 'false')

        total_seasons = getattr(self._info, 'season', None)
        total_episodes = getattr(self._info, 'episode', None)

        if self._mediatype in ['tvshow', 'season'] and total_seasons is not None:
            properties['TotalSeasons'] = '{0}'.format(total_seasons)

        if self._mediatype in ['tvshow', 'season'] and total_episodes is not None:
            properties.setdefault('TotalEpisodes', '{0}'.format(total_episodes))
            properties.setdefault('WatchedEpisodes', '0')
            properties.setdefault('UnWatchedEpisodes', '{0}'.format(total_episodes))
            properties.setdefault('NumEpisodes', '{0}'.format(total_episodes))

        if self._mediatype == 'episode':
            season = getattr(self._info, 'season', None)
            episode = getattr(self._info, 'episode', None)
            tvshowtitle = getattr(self._info, 'tvshowtitle', None)
            if season is not None:
                properties.setdefault('Season', '{0}'.format(season))
            if episode is not None:
                properties.setdefault('Episode', '{0}'.format(episode))
            if tvshowtitle:
                properties.setdefault('TVShowTitle', tvshowtitle)

        if self._force_direct_play or self._mediatype == 'episode':
            # Strongly hint Kodi/skin that episode rows are playable plugin items.
            # keeps DBTYPE=episode and season/episode/tvshow.tmdb
            # properties visible for the skin/TMDbHelper, while direct-play flags
            # still make OK launch the Filmix stream.
            properties['IsPlayable'] = 'true'
            properties['isplayable'] = 'true'
            properties['IsFolder'] = 'false'
            properties['isfolder'] = 'false'
            properties.setdefault('ContentLookup', 'false')
            properties.setdefault('content_lookup', 'false')
            properties['ForceDirectPlay'] = 'true'
            properties['dbid'] = ''
            properties['DBID'] = ''

        if 'WatchedEpisodes' in properties:
            properties.setdefault('watchedepisodes', properties['WatchedEpisodes'])
        if 'UnWatchedEpisodes' in properties:
            properties.setdefault('unwatchedepisodes', properties['UnWatchedEpisodes'])
        if 'TotalEpisodes' in properties:
            properties.setdefault('totalepisodes', properties['TotalEpisodes'])
        if 'NumEpisodes' in properties:
            properties.setdefault('numepisodes', properties['NumEpisodes'])

        for _src, _prefix in (('kp', 'filmix.kp'), ('imdb', 'filmix.imdb')):
            _rating = self._item_info.get(_src + '_rating')
            _votes = self._item_info.get(_src + '_votes')
            if _rating not in [None, '', '-']:
                properties.setdefault(_prefix + '_rating', _rating)
            if _votes not in [None, '', '-']:
                properties.setdefault(_prefix + '_votes', _votes)

        normalized = {}
        for key, value in properties.items():
            if value is None:
                normalized[key] = ''
            elif isinstance(value, str):
                normalized[key] = value
            else:
                normalized[key] = str(value)

        return normalized

    @property
    def season(self):
        if self._mediatype in ['season', 'episode'] and self._info.season is not None:
            return {'number': self._info.season}

    @property
    def ratings(self):
        # Оценки выбирает скин. Здесь их нет ещё и потому, что deprecated
        # ListItem.setRating() ронял Kodi 22 на пути сведений о сериале.
        return None


    def _fast_cache_widget_unique_ids(self):
        """Fast unique-id builder for cache-only Home/widget rows.

        Avoids simplemedia's reflective get_item() path, which asks every
        VideoInfo property and can walk large tvshow playlists just to render
        a Home widget row.  Keep the IDs that AF3/TMDbHelper need.
        """
        try:
            data = self._item_info if isinstance(self._item_info, dict) else {}
            if data.get('_filmix_identity_rejected'):
                return None
            imdb_id = data.get('resolved_imdb_id') or data.get('imdb_id')
            tmdb_id = data.get('resolved_tmdb_id') or data.get('tmdb_id')
            if (not imdb_id) or (not tmdb_id):
                try:
                    rec_imdb, rec_tmdb = self._info._resolved_ids()
                    imdb_id = imdb_id or rec_imdb
                    tmdb_id = tmdb_id or rec_tmdb
                except Exception:
                    pass
            ids = {}
            if self._mediatype in ['episode', 'season']:
                if imdb_id:
                    ids['tvshow.imdb'] = str(imdb_id)
                if tmdb_id:
                    ids['tvshow.tmdb'] = str(tmdb_id)
            else:
                if imdb_id:
                    ids['imdb'] = str(imdb_id)
                if tmdb_id:
                    ids['tmdb'] = str(tmdb_id)
            return ids or None
        except Exception:
            return None

    def _fast_cache_widget_properties(self):
        """Properties for 50-row AF3 widgets without expensive tvshow scans."""
        properties = {}
        if isinstance(self._properties, dict):
            properties.update(self._properties)

        data = self._item_info if isinstance(self._item_info, dict) else {}

        # 2.2.59 AM8_4GB_INLINE_VISIBLE_PLOT:
        # AF3 often reads the large Home plot from ListItem properties, while
        # FastWidgetItemBuild used to expose the plot only in InfoTagVideo.
        # Put the exact same already-merged plot/date into cheap properties in
        # the first render, so plot appears together with ratings/artwork when
        # the data is already available.
        try:
            plot = _select_plot(data)
            if plot:
                for _key in ('Plot', 'plot', 'Description', 'description',
                             'ShortPlot', 'shortplot', 'short_story',
                             'Overview', 'overview', 'PlotOutline',
                             'plotoutline', 'ListItem.Plot'):
                    properties.setdefault(_key, plot)
            premiered = (data.get('resolved_premiered') or data.get('premiered') or
                         data.get('release_date') or data.get('released') or
                         data.get('date_release') or data.get('release') or
                         data.get('air_date') or data.get('first_air_date'))
            if premiered:
                m = re.search(r'(\d{4}-\d{2}-\d{2})', str(premiered))
                if m:
                    premiered = m.group(1)
                for _key in ('Premiered', 'premiered', 'ReleaseDate',
                             'release_date', 'Aired', 'aired'):
                    properties.setdefault(_key, str(premiered))
            year = data.get('resolved_year') or data.get('year')
            if not year and premiered:
                m_year = re.search(r'((?:19|20)\d{2})', str(premiered))
                if m_year:
                    year = m_year.group(1)
            if year not in [None, '']:
                for _key in ('Year', 'year', 'ResolvedYear', 'resolved_year'):
                    properties.setdefault(_key, str(year))
            country = (_clean_list(data.get('filmix_countries')) or
                       _clean_list(data.get('source_countries')) or
                       _clean_list(data.get('countries')))
            if country:
                country_text = ' / '.join(country)
                for _key in ('Country', 'country', 'Countries', 'countries',
                             'FilmixSourceCountry', 'FilmixSourceCountries',
                             'SourceCountry', 'SourceCountries'):
                    properties.setdefault(_key, country_text)
            if data.get('id') not in [None, '']:
                properties.setdefault('FilmixPostID', str(data.get('id')))
        except Exception:
            pass

        try:
            if data.get('_filmix_identity_rejected'):
                properties['FilmixIdentityRejected'] = 'true'
                if data.get('_filmix_rejected_tmdb_id'):
                    properties['FilmixRejectedTmdbID'] = str(data.get('_filmix_rejected_tmdb_id'))
                imdb_id = None
                tmdb_id = None
                tmdb_type = None
            else:
                imdb_id = data.get('resolved_imdb_id') or data.get('imdb_id')
                tmdb_id = data.get('resolved_tmdb_id') or data.get('tmdb_id')
                tmdb_type = data.get('resolved_tmdb_type')
            if (not data.get('_filmix_identity_rejected')) and not tmdb_type:
                if self._mediatype in ['movie']:
                    tmdb_type = 'movie'
                elif self._mediatype in ['tvshow', 'season', 'episode']:
                    tmdb_type = 'tv'
            if tmdb_type:
                properties['tmdb_type'] = str(tmdb_type)
            if tmdb_id:
                if self._mediatype in ['episode', 'season']:
                    properties['tvshow.tmdb_id'] = str(tmdb_id)
                properties['tmdb_id'] = str(tmdb_id)
            if imdb_id:
                properties['imdb_id'] = str(imdb_id)
        except Exception:
            pass

        if self._mediatype in ['movie', 'tvshow', 'season', 'episode']:
            properties['dbtype'] = self._mediatype
            properties['DBTYPE'] = self._mediatype

        if self._mediatype == 'tvshow':
            properties.setdefault('IsFolder', 'true')
            properties.setdefault('isfolder', 'true')
            properties.setdefault('IsPlayable', 'false')
            properties.setdefault('isplayable', 'false')

        # Preserve already-computed aggregate show/season stats from
        # Navigation._apply_local_state().  Do not call PostInfo.season/episode
        # here; those scan player_links for every one of 50 widget rows.
        if 'WatchedEpisodes' in properties:
            properties.setdefault('watchedepisodes', properties['WatchedEpisodes'])
        if 'UnWatchedEpisodes' in properties:
            properties.setdefault('unwatchedepisodes', properties['UnWatchedEpisodes'])
        if 'TotalEpisodes' in properties:
            properties.setdefault('totalepisodes', properties['TotalEpisodes'])
        if 'NumEpisodes' in properties:
            properties.setdefault('numepisodes', properties['NumEpisodes'])

        for _src, _prefix in (('kp', 'filmix.kp'), ('imdb', 'filmix.imdb')):
            _rating = data.get(_src + '_rating')
            _votes = data.get(_src + '_votes')
            if _rating not in [None, '', '-']:
                properties.setdefault(_prefix + '_rating', _rating)
            if _votes not in [None, '', '-']:
                properties.setdefault(_prefix + '_votes', _votes)

        if self._mediatype == 'episode':
            try:
                season = getattr(self._info, 'season', None)
                episode = getattr(self._info, 'episode', None)
                tvshowtitle = getattr(self._info, 'tvshowtitle', None)
                if season is not None:
                    properties.setdefault('Season', '{0}'.format(season))
                if episode is not None:
                    properties.setdefault('Episode', '{0}'.format(episode))
                if tvshowtitle:
                    properties.setdefault('TVShowTitle', tvshowtitle)
            except Exception:
                pass

        normalized = {}
        for key, value in properties.items():
            if value is None:
                normalized[key] = ''
            elif isinstance(value, str):
                normalized[key] = value
            else:
                normalized[key] = str(value)
        return normalized

    def _fast_cache_widget_info(self):
        """Minimal-but-rich info block for Home/cache-only 50-row widgets.

        Keeps title, original title, date/year, plot, genre/country, ids and
        watched playcount, but avoids simplemedia reflection and avoids walking
        full tvshow playlists for episode/season totals.  Totals/progress are
        supplied via properties from the aggregate watched-state path.
        """
        data = self._item_info if isinstance(self._item_info, dict) else {}
        info = {'mediatype': self._mediatype}
        try:
            title = getattr(self._info, 'title', None)
            if self._mediatype == 'episode':
                title = getattr(self._info, 'display_title', title)
            if title:
                info['title'] = title
        except Exception:
            pass
        try:
            originaltitle = data.get('original_title') or data.get('title')
            originaltitle = _clean_text(originaltitle)
            if originaltitle:
                info['originaltitle'] = originaltitle
        except Exception:
            pass
        try:
            if self._mediatype in ['tvshow', 'season', 'episode']:
                tvshowtitle = data.get('title') or data.get('original_title')
                tvshowtitle = _clean_text(tvshowtitle)
                if tvshowtitle:
                    info['tvshowtitle'] = tvshowtitle
        except Exception:
            pass
        try:
            premiered = (data.get('resolved_premiered') or data.get('premiered') or
                         data.get('release_date') or data.get('released') or
                         data.get('date_release') or data.get('release') or
                         data.get('air_date') or data.get('first_air_date'))
            if premiered:
                m = re.search(r'(\d{4}-\d{2}-\d{2})', str(premiered))
                if m:
                    premiered = m.group(1)
                    info['premiered'] = premiered
                    if self._mediatype in ['tvshow', 'season', 'episode']:
                        info['aired'] = premiered
        except Exception:
            pass
        try:
            year = data.get('resolved_year') or data.get('year')
            if not year and info.get('premiered'):
                year = str(info['premiered'])[:4]
            if year not in [None, '']:
                info['year'] = int(year)
        except Exception:
            pass
        try:
            plot = _select_plot(data)
            if plot:
                info['plot'] = plot
                info['plotoutline'] = plot
        except Exception:
            pass
        try:
            genre = _filter_genre_list(_clean_list(data.get('categories')))
            if genre:
                info['genre'] = genre
        except Exception:
            pass
        try:
            country = (_clean_list(data.get('filmix_countries')) or
                       _clean_list(data.get('source_countries')) or
                       _clean_list(data.get('countries')))
            if country:
                info['country'] = country
        except Exception:
            pass
        try:
            playcount = None
            if isinstance(self._properties, dict):
                playcount = self._properties.get('playcount')
            if playcount not in [None, '']:
                info['playcount'] = int(playcount)
        except Exception:
            pass
        try:
            imdb_id = data.get('resolved_imdb_id') or data.get('imdb_id')
            if imdb_id:
                info['imdbnumber'] = str(imdb_id)
        except Exception:
            pass
        return {'video': info}

    def get_cache_widget_item(self):
        """Fast non-reflective get_item() for cache-only 50-item Home widgets."""
        result = {}
        label = self.label
        if label is not None:
            result['label'] = label
        url = self.url
        if url is not None:
            result['url'] = url
        path = self.path
        if path is not None:
            result['path'] = path
        result['is_folder'] = self.is_folder
        result['is_playable'] = self.is_playable
        art = self.art
        if art:
            result['art'] = art
        thumb = self.thumb
        if thumb:
            result['thumb'] = thumb
        fanart = self.fanart
        if fanart:
            result['fanart'] = fanart
        result['content_lookup'] = self.content_lookup
        result['info'] = self._fast_cache_widget_info()
        props = self._fast_cache_widget_properties()
        if props:
            result['properties'] = props
        context_menu = self.context_menu
        if context_menu is not None:
            result['context_menu'] = context_menu
        unique_ids = self._fast_cache_widget_unique_ids()
        if unique_ids:
            result['unique_ids'] = unique_ids
            result['online_db_ids'] = unique_ids
        return result


    def set_force_direct_play(self, value=True):
        self._force_direct_play = bool(value)
        if value:
            self._force_content_lookup = False


    def set_properties(self, properties):
        merged = {}
        if isinstance(self._properties, dict):
            merged.update(self._properties)
        if isinstance(properties, dict):
            merged.update(properties)
        self._properties = merged

    def set_context_menu(self, context_menu):
        self._context_menu = context_menu


class MainMenuItem(EmptyListItem):

    def __init__(self, section_info):
        self._info = section_info

    @property
    def label(self):
        return self._info.get('label')

    @property
    def content_lookup(self):
        return False

    @property
    def icon(self):
        return self._info.get('icon')

    @property
    def fanart(self):
        return plugin.fanart


class FilterItem(EmptyListItem):
    _filter_name = ''
    _values = None

    def __init__(self, filter_name, values):
        self._filter_name = filter_name
        self._values = values

    @property
    def label(self):
        if self._filter_name in ['vo', 'translation']:
            return '[B]{0}[/B]'.format(self._values)
        title = Utilities.get_filter_title(self._filter_name)
        return self._make_label('yellowgreen', title, self._values)

    @property
    def content_lookup(self):
        return False

    @property
    def icon(self):
        return Utilities.get_filter_icon(self._filter_name)

    @property
    def fanart(self):
        return plugin.fanart

    @property
    def is_folder(self):
        return False

    @property
    def is_playable(self):
        return False

    @staticmethod
    def _make_label(color, title, values):
        # no hardcoded label colors; let skin highlight/focus styling apply.
        return '[B]{0}:[/B] {1}'.format(title, values)
