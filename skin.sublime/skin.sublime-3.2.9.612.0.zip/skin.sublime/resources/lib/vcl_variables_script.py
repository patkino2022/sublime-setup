# -*- coding: utf-8 -*-
# VCL embedded VCLVariables-compatible script entrypoint.
# Namespaced into the skin so the external Skin Variables addon is no longer a dependency.
import os
import sys

# Kodi can launch script/plugin entrypoints from a skin addon without placing the
# skin addon root on sys.path. Add it explicitly so absolute imports like
# resources.lib.vcl_variables.* resolve exactly as they did in script.skinvariables.
_ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
if _ADDON_ROOT not in sys.path:
    sys.path.insert(0, _ADDON_ROOT)


from resources.lib.vcl_variables.script import Script


def _parse_args(args):
    params = {}
    for arg in args:
        if '=' in arg:
            key, value = arg.split('=', 1)
            params[key.strip()] = value.strip().strip('\"').strip("'")
        elif arg:
            params[arg.strip()] = True
    return params


if __name__ == '__main__':
    from resources.lib.sublime_helper.actions import run as run_sublime_helper_action
    _params = _parse_args(sys.argv[1:])
    if _params.get('pvr_action'):
        from resources.lib.vcl_pvr_guide_popup import main as run_pvr_popup
        run_pvr_popup({
            'action': _params.get('pvr_action', 'open'),
            'path': _params.get('pvr_path', ''),
            'channelid': _params.get('channelid', ''),
            'channel': _params.get('channel', ''),
            'time_offset': _params.get('time_offset', 0),
            'channel_offset': _params.get('channel_offset', 0),
        })
    elif _params.get('focus_control'):
        from resources.lib.vcl_focus_guard import main as run_focus_guard
        run_focus_guard(
            _params.get('focus_control'),
            expected_window=_params.get('expected_window'),
            wait_ms=_params.get('wait_ms'),
            fallback=_params.get('fallback'),
        )
    elif run_sublime_helper_action(_params) is False:
        Script(*sys.argv[1:]).run()
