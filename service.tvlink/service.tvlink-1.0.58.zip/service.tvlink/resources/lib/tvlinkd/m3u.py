"""M3U playlist reader: only what IPTV playlists actually carry."""
import re

_ATTR = re.compile(r'([A-Za-z0-9_-]+)=("([^"]*)"|[^\s,]+)')


def _attrs(text):
    out = {}
    for m in _ATTR.finditer(text):
        val = m.group(3) if m.group(3) is not None else m.group(2)
        out[m.group(1).lower()] = val.strip()
    return out


# Служебные строки плейлистов, а не каналы: заголовки сборок («-compilation»,
# «-compilation <дата> User: ... IP: ...»), «agregate from -rebuild» и т.п.
_SERVICE = re.compile(r'^\s*-|User:\s*\S+.*IP:|^\s*agregate\s+from', re.I)


def is_service(title):
    return bool(_SERVICE.search(title or ""))


def parse(text):
    """Return (header_attrs, entries). Entry: title, url, group, logo, attrs."""
    if text.startswith("﻿"):
        text = text[1:]
    header, entries = {}, []
    cur, grp = None, None
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("#EXTM3U"):
            header.update(_attrs(line[7:]))
        elif line.startswith("#EXTINF"):
            body = line.split(":", 1)[1] if ":" in line else ""
            # attributes are quoted, the title is after the last comma outside quotes
            q, cut = False, -1
            for i, ch in enumerate(body):
                if ch == '"':
                    q = not q
                elif ch == "," and not q:
                    cut = i
            info, title = (body[:cut], body[cut + 1:]) if cut >= 0 else (body, "")
            a = _attrs(info)
            cur = {"title": title.strip(), "attrs": a,
                   "group": a.get("group-title", ""), "logo": a.get("tvg-logo", "")}
            grp = None
        elif line.startswith("#EXTVLCOPT:") and cur is not None:
            k, _, v = line[11:].partition("=")
            k = k.strip().lower()
            name = {"http-referrer": "Referer", "http-referer": "Referer", "http-user-agent": "User-Agent",
                    "http-origin": "Origin"}.get(k)
            if name and v.strip():
                cur.setdefault("headers", {})[name] = v.strip()
        elif line.startswith("#EXTGRP:"):
            grp = line[8:].strip()
        elif line.startswith("#"):
            continue
        elif cur is not None:
            if grp and not cur["group"]:
                cur["group"] = grp
            cur["group"] = cur["group"].split(";")[0].strip()
            cur["url"] = line
            if not is_service(cur["title"]):
                entries.append(cur)
            cur, grp = None, None
    return header, entries
