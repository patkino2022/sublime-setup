# -*- coding: utf-8 -*-
"""Skin strings for Python: the text Kodi shows in the user's language.

The ids live in language/resource.language.*/strings.po (31900-31999 for the
strings the Python side shows). The Russian file carries exactly the text the
code used to hard-wire, so a Russian Kodi sees the same bytes as before.
"""
from __future__ import absolute_import, unicode_literals

import time

import xbmc
import xbmcaddon

ADDON_ID = 'skin.sublime'

_ADDON = {'obj': None}
_LANG = {'ru': None, 'at': 0.0}
# Kodi's language changes only from its settings screen; the hot service loop
# asks often, so the answer is kept for a few seconds rather than per call.
_LANG_TTL = 5.0


def _addon():
    if _ADDON['obj'] is None:
        _ADDON['obj'] = xbmcaddon.Addon(ADDON_ID)
    return _ADDON['obj']


def tr(string_id):
    """The skin string `string_id` in Kodi's current language."""
    try:
        return _addon().getLocalizedString(int(string_id)) or ''
    except Exception:
        try:
            return xbmc.getLocalizedString(int(string_id)) or ''
        except Exception:
            return ''


def is_russian():
    """True when Kodi's interface language is Russian."""
    now = time.time()
    if _LANG['ru'] is None or now - _LANG['at'] > _LANG_TTL:
        try:
            _LANG['ru'] = (xbmc.getLanguage(xbmc.ISO_639_1) or '').lower() == 'ru'
        except Exception:
            _LANG['ru'] = True
        _LANG['at'] = now
    return _LANG['ru']
