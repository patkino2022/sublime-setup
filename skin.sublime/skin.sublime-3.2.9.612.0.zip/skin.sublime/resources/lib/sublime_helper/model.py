# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import datetime
import re

from . import config

TMDB_IMAGE = 'https://image.tmdb.org/t/p/'

# Kodi composites this skin into a 1920x1080 surface on the target boxes
# ("GUI format 1920x1080, Display 3840x2160" in kodi.log) and advancedsettings
# caps cached textures at imageres/fanartres 1080, so 16:9 art is stored at
# exactly 1920x1080 and nothing larger can reach the panel.
#
# w1920 is undocumented in TMDb's configuration payload but the CDN serves it,
# returning exactly 1920x1080; w1440, w2160 and h1080 all answer HTTP 400. It
# replaces two opposite mistakes: `original`, which fetched up to 3840x2160 and
# discarded three quarters of it (2030 KB -> 463 KB on a 4K backdrop), and
# `w1280`, which was 1280x720 and therefore *below* what the surface shows.
#
# Posters stay at w780 (780x1170, above the 720x1080 a 2:3 poster is cached at),
# and poster_original deliberately stays `original`: it feeds the
# poster-to-landscape crop, which needs the width, and a w1920 poster is
# 1920x2880 - larger than `original` for most titles.
TMDB_SIZE_16_9 = 'w1920'
_DEFAULT_LANGUAGE = object()


# Разметка внутри описания. Кинопоиск отдаёт описания с HTML: «...сводит людей с
# ума.<br /><br />Заперевшись в квартире...». Kodi показывает такой текст как
# есть, и владелец увидел на экране «< br / >< br / >» посреди фразы. Ни один из
# наших источников чистого текста не обещает, поэтому чистим на входе все.
_PLOT_BREAKS = re.compile(r"<\s*br\s*/?\s*>", re.IGNORECASE)
_PLOT_TAGS = re.compile(r"<[^<>]{1,40}>")
_PLOT_SPACES = re.compile(r"[ \t ]{2,}")
# Пробелы вокруг переноса. «завтра. <br />Действие» давало «завтра. \nДействие»
# с висячим пробелом в конце строки - на экране это лишняя дырка.
_PLOT_EDGES = re.compile("[ \t ]*\n[ \t ]*")
_PLOT_BLANKS = re.compile("%s{2,}" % chr(10))
_PLOT_ENTITIES = (
    ("&nbsp;", " "), ("&laquo;", "«"), ("&raquo;", "»"),
    ("&mdash;", "—"), ("&ndash;", "–"), ("&quot;", '"'),
    ("&apos;", "'"), ("&#39;", "'"), ("&lt;", "<"), ("&gt;", ">"), ("&amp;", "&"),
)


def clean_text(value):
    """Текст без служебной разметки. Пустое остаётся пустым."""
    text = str(value or "")
    if not text:
        return ""
    # Чистим в несколько проходов. Один проход не спасал от экранированной
    # разметки: описание приходило как «&lt;br /&gt;», срезка тегов её не
    # видела (это ещё не тег), а следующая строка раскрывала мнемоники - и на
    # экран уходил настоящий «<br />». Владелец увидел это на «Джеке Ричере»
    # 07.09.2026. Теперь раскрытие и срезка повторяются, пока текст меняется,
    # но не больше трёх раз - хватает и на двойное экранирование
    # («&amp;lt;br&amp;gt;»), и от бесконечного цикла страхует.
    for _ in range(3):
        if "<" not in text and "&" not in text:
            break
        before = text
        text = _PLOT_BREAKS.sub("\n", text)
        text = _PLOT_TAGS.sub("", text)
        for what, with_what in _PLOT_ENTITIES:
            text = text.replace(what, with_what)
        if text == before:
            break
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _PLOT_EDGES.sub("\n", text)
    # Пустых строк в описании не оставляем. «<br /><br />» - это абзац в
    # вёрстке Кинопоиска, но в нашей полосе описания видно всего пять строк, и
    # пустая строка съедала одну из них: владелец увидел это на «Джеке Ричере»
    # 07.09.2026 - «лишний отступ в абзаце». Перенос остаётся, дырка уходит.
    text = _PLOT_BLANKS.sub("\n", text)
    text = _PLOT_SPACES.sub(" ", text)
    return text.strip()


def safe_int(value, default=0):
    try:
        return int(float(value))
    except Exception:
        return default


def safe_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default


def first(value, default=''):
    if isinstance(value, (list, tuple)):
        return value[0] if value else default
    return value if value not in (None, '') else default


def join_names(items, separator=' / '):
    out = []
    for item in items or []:
        if isinstance(item, dict):
            item = item.get('name') or item.get('title') or item.get('original_name') or ''
        item = str(item or '').strip()
        if item and item not in out:
            out.append(item)
    return separator.join(out)


def image_url(path, size='original'):
    path = str(path or '')
    if not path:
        return ''
    if path.startswith(('http://', 'https://', 'image://', 'special://')):
        return path
    if not path.startswith('/'):
        path = '/' + path
    return '%s%s%s' % (TMDB_IMAGE, size, path)


def language_code(value=_DEFAULT_LANGUAGE):
    """Return a normalized ISO-639-1 code; empty means language-neutral."""
    if value is _DEFAULT_LANGUAGE:
        value = config.language()
    value = str(value or '').strip().replace('_', '-').lower()
    if not value or value in ('00', 'und', 'null', 'none'):
        return ''
    return value.split('-', 1)[0]


def language_rank(value, preferred=None):
    """Preferred UI language, then neutral, then English, then everything else."""
    preferred = language_code(config.language() if preferred is None else preferred)
    value = language_code(value)
    if preferred and value == preferred:
        return 0
    if not value:
        return 1
    if value == 'en':
        return 0 if preferred == 'en' else 2
    return 3


def trailer_rank(row, preferred=None):
    """Rank one trailer candidate independently from provider priority."""
    row = row or {}
    kind = str(row.get('type') or '').strip().lower()
    official = row.get('official')
    if isinstance(official, str):
        official = official.strip().lower() in ('1', 'true', 'yes')
    return (
        language_rank(row.get('language'), preferred),
        0 if official else 1,
        0 if kind == 'trailer' else 1 if kind == 'teaser' else 2,
    )


def _candidate_language(row):
    return language_code(
        row.get('language') or row.get('iso_639_1') or row.get('lang') or row.get('iso639_1')
    )


def _year(date_value):
    match = re.match(r'^(\d{4})', str(date_value or ''))
    return safe_int(match.group(1)) if match else 0


def _runtime(data, media_type):
    runtime = data.get('runtime')
    if not runtime and media_type == 'tv':
        runtime = first(data.get('episode_run_time') or [])
    return safe_int(runtime) * 60


def _certificate(data, media_type):
    region = config.region()
    if media_type == 'movie':
        results = (data.get('release_dates') or {}).get('results') or []
        preferred = [x for x in results if x.get('iso_3166_1') == region] or [x for x in results if x.get('iso_3166_1') == 'US']
        for group in preferred:
            for item in group.get('release_dates') or []:
                if item.get('certification'):
                    return item.get('certification')
    if media_type == 'tv':
        results = (data.get('content_ratings') or {}).get('results') or []
        preferred = [x for x in results if x.get('iso_3166_1') == region] or [x for x in results if x.get('iso_3166_1') == 'US']
        if preferred:
            return preferred[0].get('rating') or ''
    return ''


def _crew(data):
    credits = data.get('aggregate_credits') or data.get('credits') or {}
    crew = list(credits.get('crew') or [])
    people = {'director': [], 'writer': [], 'creator': [], 'producer': [], 'sound_department': [], 'art_department': [], 'photography': [], 'editor': []}
    for person in crew:
        department = str(person.get('department') or person.get('known_for_department') or '')
        jobs = person.get('jobs') or [person]
        for job_item in jobs:
            job = str(job_item.get('job') or person.get('job') or '')
            row = dict(person)
            row['job'] = job
            row['role'] = job
            row['thumb'] = image_url(person.get('profile_path'), 'h632')
            if job == 'Director':
                people['director'].append(row)
            if department == 'Writing' or job in ('Writer', 'Screenplay', 'Teleplay', 'Story', 'Novel'):
                people['writer'].append(row)
            if job in ('Creator', 'Executive Producer') and department in ('Production', 'Creator'):
                people['creator'].append(row)
            if department == 'Production':
                people['producer'].append(row)
            if department == 'Sound':
                people['sound_department'].append(row)
            if department == 'Art':
                people['art_department'].append(row)
            if department in ('Camera', 'Lighting') or job == 'Director of Photography':
                people['photography'].append(row)
            if department == 'Editing':
                people['editor'].append(row)
    for creator in data.get('created_by') or []:
        row = dict(creator)
        row['job'] = 'Creator'
        row['role'] = 'Creator'
        row['thumb'] = image_url(creator.get('profile_path'), 'h632')
        people['creator'].append(row)
    for key, values in people.items():
        dedup = []
        seen = set()
        for row in values:
            ident = (row.get('id'), row.get('job'))
            if ident in seen:
                continue
            seen.add(ident)
            dedup.append(row)
        people[key] = dedup
    return people


def _cast(data):
    credits = data.get('aggregate_credits') or data.get('credits') or {}
    out = []
    for item in credits.get('cast') or []:
        roles = item.get('roles') or []
        role = ' / '.join([x.get('character') or '' for x in roles if x.get('character')]) or item.get('character') or item.get('role') or ''
        out.append({
            'id': item.get('id'),
            'name': item.get('name') or item.get('original_name') or '',
            'role': role,
            'job': 'Actor',
            'order': safe_int(item.get('order')),
            'thumb': image_url(item.get('profile_path'), 'h632'),
            'gender': item.get('gender'),
            'department': item.get('known_for_department') or 'Acting',
        })
    return out


def _art(data, media_type):
    art = {
        'poster': image_url(data.get('poster_path'), 'w780'),
        'poster_original': image_url(data.get('poster_path'), 'original'),
        'fanart': image_url(data.get('backdrop_path'), TMDB_SIZE_16_9),
        'landscape': image_url(data.get('backdrop_path'), TMDB_SIZE_16_9),
        # Кадр серии - картинка 16:9, и с недавних пор он идёт фоном на весь
        # экран. В размере w780 его растягивало с 780 до 1920 - в два с
        # половиной раза, - и на фоне это видно. Портретные запасные варианты
        # (лицо человека, постер) остаются в w780: их шириной никто не меряет.
        'thumb': (image_url(data.get('still_path'), TMDB_SIZE_16_9)
                  or image_url(data.get('profile_path') or data.get('poster_path'), 'w780')),
        'icon': image_url(data.get('profile_path') or data.get('poster_path'), 'w500'),
    }
    images = data.get('images') or {}

    def ranked(rows):
        return sorted(rows or [], key=lambda row: (
            language_rank(_candidate_language(row)),
            -safe_float(row.get('vote_average')), -safe_int(row.get('vote_count')),
        ))

    # SVG Kodi не рисует - такие логотипы не кандидаты
    logos = ranked([row for row in (images.get('logos') or [])
                    if not str(row.get('file_path') or '').lower().endswith('.svg')])
    posters = ranked(images.get('posters'))
    backdrops = ranked(images.get('backdrops'))
    stills = ranked(images.get('stills'))
    if logos:
        art['clearlogo'] = image_url(logos[0].get('file_path'), 'original')
    if posters and not art.get('poster'):
        art['poster'] = image_url(posters[0].get('file_path'), 'w780')
        art['poster_original'] = image_url(posters[0].get('file_path'), 'original')
    if backdrops and not art.get('fanart'):
        art['fanart'] = image_url(backdrops[0].get('file_path'), TMDB_SIZE_16_9)
        art['landscape'] = image_url(backdrops[0].get('file_path'), TMDB_SIZE_16_9)
    if stills and not art.get('thumb'):
        art['thumb'] = image_url(stills[0].get('file_path'), TMDB_SIZE_16_9)
    if media_type == 'person':
        profiles = ranked(images.get('profiles'))
        if profiles:
            art['poster'] = image_url(profiles[0].get('file_path'), 'h632')
            art['thumb'] = art['poster']
            art['icon'] = art['poster']
    return {k: v for k, v in art.items() if v}


def _tmdb_logo_candidates(data):
    images = data.get('images') or {}
    rows = images.get('logos') or []
    output = []
    for row in rows:
        url = image_url(row.get('file_path'), 'original')
        if not url or url.lower().endswith('.svg'):
            continue
        actual_language = _candidate_language(row)
        output.append({
            'url': url,
            # The language tag returned with each image is authoritative. A
            # server-side image filter is only a request hint and must never
            # relabel an English or untagged logo as the selected UI language.
            'language': actual_language,
            'original_language': actual_language,
            'server_filtered': False,
            'file_path': row.get('file_path') or '',
            'vote_average': safe_float(row.get('vote_average')),
            'vote_count': safe_int(row.get('vote_count')),
        })
    return output


def _tmdb_trailer_candidates(videos):
    output = []
    for row in videos or []:
        if str(row.get('site') or '').lower() != 'youtube' or not row.get('key'):
            continue
        kind = str(row.get('type') or '').strip()
        if kind not in ('Trailer', 'Teaser'):
            continue
        output.append({
            'url': config.youtube_play_url(row.get('key')),
            'key': row.get('key'),
            'language': _candidate_language(row),
            'official': bool(row.get('official')),
            'type': kind,
            'name': row.get('name') or '',
            'size': safe_int(row.get('size')),
            'published_at': row.get('published_at') or '',
        })
    return output


def normalize_tmdb(data, media_type):
    media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
    if not data:
        return {}
    if media_type == 'person':
        birthday = data.get('birthday') or ''
        deathday = data.get('deathday') or ''
        age = ''
        try:
            born = datetime.datetime.strptime(birthday, '%Y-%m-%d').date()
            end = datetime.datetime.strptime(deathday, '%Y-%m-%d').date() if deathday else datetime.date.today()
            age = end.year - born.year - ((end.month, end.day) < (born.month, born.day))
        except Exception:
            pass
        return {
            'media_type': 'person', 'tmdb_type': 'person', 'tmdb_id': safe_int(data.get('id')),
            'title': data.get('name') or '', 'originaltitle': data.get('name') or '',
            'plot': clean_text(data.get('biography')), 'birthday': birthday, 'deathday': deathday,
            'age': age, 'gender': data.get('gender') or '', 'place_of_birth': data.get('place_of_birth') or '',
            'known_for_department': data.get('known_for_department') or '',
            'imdb_id': (data.get('external_ids') or {}).get('imdb_id') or data.get('imdb_id') or '',
            'homepage': data.get('homepage') or '', 'art': _art(data, 'person'),
            'images': data.get('images') or {}, 'combined_credits': data.get('combined_credits') or {},
        }

    title = data.get('title') or data.get('name') or data.get('episode_name') or ''
    original = data.get('original_title') or data.get('original_name') or title
    preferred_translation = {}
    preferred_language = language_code()
    if preferred_language:
        for row in (data.get('translations') or {}).get('translations') or []:
            if not isinstance(row, dict) or language_code(row.get('iso_639_1')) != preferred_language:
                continue
            row_data = row.get('data') or {}
            if isinstance(row_data, dict):
                preferred_translation = row_data
                break
    translated_title = preferred_translation.get('title') or preferred_translation.get('name') or ''
    if translated_title:
        title = translated_title
    premiered = data.get('release_date') or data.get('first_air_date') or data.get('air_date') or ''
    external = data.get('external_ids') or {}
    people = _crew(data)
    genres = data.get('genres') or []
    companies = data.get('production_companies') or []
    networks = data.get('networks') or []
    countries = data.get('production_countries') or data.get('origin_country') or []
    languages = data.get('spoken_languages') or []
    collection = data.get('belongs_to_collection') or {}
    next_episode = data.get('next_episode_to_air') or {}
    last_episode = data.get('last_episode_to_air') or {}
    alternative_rows = ((data.get('alternative_titles') or {}).get('titles') or
                        (data.get('alternative_titles') or {}).get('results') or [])
    alternative_titles = []
    for row in alternative_rows:
        value = (row.get('title') if isinstance(row, dict) else row) or ''
        value = str(value).strip()
        if value and value not in alternative_titles:
            alternative_titles.append(value)
    # TMDb's localized title can differ completely from the original title. Include
    # every translated movie/show/season/episode name in strict identity matching.
    for row in (data.get('translations') or {}).get('translations') or []:
        translation = row.get('data') if isinstance(row, dict) else {}
        translation = translation if isinstance(translation, dict) else {}
        for value in (translation.get('title'), translation.get('name')):
            value = str(value or '').strip()
            if value and value not in alternative_titles:
                alternative_titles.append(value)
    providers = ((data.get('watch/providers') or {}).get('results') or {}).get(config.region()) or {}
    provider_rows = []
    for bucket in ('flatrate', 'free', 'ads', 'rent', 'buy'):
        for item in providers.get(bucket) or []:
            if not any(x.get('provider_id') == item.get('provider_id') for x in provider_rows):
                provider_rows.append(item)
    result = {
        'media_type': media_type, 'tmdb_type': media_type, 'tmdb_id': safe_int(data.get('id')),
        'adult': bool(data.get('adult')),
        'title': title, 'originaltitle': original, 'alternative_titles': alternative_titles,
        'plot': clean_text(preferred_translation.get('overview') or data.get('overview')),
        'tagline': preferred_translation.get('tagline') or data.get('tagline') or '', 'status': data.get('status') or '',
        'premiered': premiered, 'year': _year(premiered), 'runtime': _runtime(data, media_type),
        'mpaa': _certificate(data, media_type), 'rating': safe_float(data.get('vote_average')),
        'votes': safe_int(data.get('vote_count')), 'popularity': safe_float(data.get('popularity')),
        'genre': [x.get('name') for x in genres if x.get('name')], 'genres': genres,
        'country': [(x.get('name') or x.get('iso_3166_1') or '') if isinstance(x, dict) else str(x or '') for x in countries],
        'language': [(x.get('english_name') or x.get('name') or x.get('iso_639_1') or '') if isinstance(x, dict) else str(x or '') for x in languages],
        'studio': [x.get('name') for x in companies if x.get('name')], 'networks': networks,
        'budget': safe_int(data.get('budget')), 'revenue': safe_int(data.get('revenue')),
        'homepage': data.get('homepage') or '', 'trailer': '', 'art': _art(data, media_type),
        'art_candidates': {'clearlogo': _tmdb_logo_candidates(data)},
        'images': data.get('images') or {}, 'videos': (data.get('videos') or {}).get('results') or [],
        'recommendations': (data.get('recommendations') or {}).get('results') or [],
        'similar': (data.get('similar') or {}).get('results') or [],
        'reviews': (data.get('reviews') or {}).get('results') or [],
        'cast': _cast(data), 'crew': people,
        'imdb_id': external.get('imdb_id') or data.get('imdb_id') or '',
        'tvdb_id': external.get('tvdb_id') or '', 'wikidata_id': external.get('wikidata_id') or '',
        'facebook_id': external.get('facebook_id') or '', 'instagram_id': external.get('instagram_id') or '',
        'twitter_id': external.get('twitter_id') or '',
        'collection_id': safe_int(collection.get('id')), 'collection_name': collection.get('name') or '',
        'collection_poster': image_url(collection.get('poster_path'), 'w780'),
        'collection_fanart': image_url(collection.get('backdrop_path'), 'original'),
        'providers': provider_rows,
        'seasons': data.get('seasons') or [], 'number_of_seasons': safe_int(data.get('number_of_seasons')),
        'number_of_episodes': safe_int(data.get('number_of_episodes')),
        'next_aired': next_episode, 'last_aired': last_episode,
        'season': safe_int(data.get('season_number')), 'episode': safe_int(data.get('episode_number')),
        'episode_type': data.get('episode_type') or '',
        'production_code': data.get('production_code') or '',
        'ratings': {'tmdb': {'rating': safe_float(data.get('vote_average')), 'votes': safe_int(data.get('vote_count'))}},
    }
    result['videos'] = sorted(
        result['videos'],
        key=lambda row: trailer_rank({
            'language': _candidate_language(row),
            'official': row.get('official'),
            'type': row.get('type'),
        }) + (-safe_int(row.get('size')), str(row.get('name') or '').lower()),
    )
    result['trailer_candidates'] = _tmdb_trailer_candidates(result['videos'])
    if result['trailer_candidates']:
        chosen = sorted(
            result['trailer_candidates'],
            key=lambda row: trailer_rank(row) + (-safe_int(row.get('size')), str(row.get('name') or '').lower()),
        )[0]
        result['trailer'] = chosen.get('url') or ''
        result['trailer_language'] = chosen.get('language') or ''
        result['trailer_official'] = bool(chosen.get('official'))
    return result


def _date_iso(value):
    value = str(value or '').strip()
    if not value or value == 'N/A':
        return ''
    if re.match(r'^\d{4}-\d{2}-\d{2}', value):
        return value[:10]
    for fmt in ('%d %b %Y', '%d %B %Y'):
        try:
            return datetime.datetime.strptime(value, fmt).strftime('%Y-%m-%d')
        except Exception:
            pass
    return value


def normalize_omdb(data, media_type=''):
    if not data or str(data.get('Response', 'True')).lower() == 'false':
        return {}
    omdb_type = str(data.get('Type') or '').lower()
    if not media_type:
        media_type = 'tv' if omdb_type in ('series', 'episode') else 'movie'
    media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
    match_year = re.search(r'\d{4}', str(data.get('Year') or ''))
    year = safe_int(match_year.group(0)) if match_year else 0
    runtime_match = re.search(r'(\d+)', str(data.get('Runtime') or ''))
    runtime = safe_int(runtime_match.group(1)) * 60 if runtime_match else 0
    actors = [x.strip() for x in str(data.get('Actors') or '').split(',') if x.strip() and x.strip() != 'N/A']
    directors = [x.strip() for x in str(data.get('Director') or '').split(',') if x.strip() and x.strip() != 'N/A']
    writers = [x.strip() for x in str(data.get('Writer') or '').split(',') if x.strip() and x.strip() != 'N/A']
    poster = data.get('Poster') if data.get('Poster') not in ('', None, 'N/A') else ''
    provider_media_type = 'tv' if omdb_type in ('series', 'episode') else 'movie' if omdb_type == 'movie' else ''
    result = {
        'media_type': media_type, 'tmdb_type': media_type, 'dbtype': 'tvshow' if media_type == 'tv' else media_type,
        'provider_media_type': provider_media_type,
        'adult': bool(data.get('adult') or data.get('isAdult')),
        'title': data.get('Title') or '', 'originaltitle': data.get('Title') or '',
        'plot': '' if data.get('Plot') == 'N/A' else clean_text(data.get('Plot')),
        'premiered': _date_iso(data.get('Released')), 'year': year, 'runtime': runtime,
        'mpaa': '' if data.get('Rated') == 'N/A' else data.get('Rated') or '',
        'genre': [x.strip() for x in str(data.get('Genre') or '').split(',') if x.strip() and x.strip() != 'N/A'],
        'country': [x.strip() for x in str(data.get('Country') or '').split(',') if x.strip() and x.strip() != 'N/A'],
        'language': [x.strip() for x in str(data.get('Language') or '').split(',') if x.strip() and x.strip() != 'N/A'],
        'studio': [] if data.get('Production') in ('', None, 'N/A') else [data.get('Production')],
        'status': '', 'trailer': '', 'art': {'poster': poster, 'thumb': poster, 'icon': poster} if poster else {},
        'cast': [{'id': '', 'name': name, 'role': '', 'job': 'Actor', 'order': idx, 'thumb': ''} for idx, name in enumerate(actors)],
        'crew': {
            'director': [{'id': '', 'name': name, 'role': 'Director', 'job': 'Director', 'thumb': ''} for name in directors],
            'writer': [{'id': '', 'name': name, 'role': 'Writer', 'job': 'Writer', 'thumb': ''} for name in writers],
        },
        'imdb_id': data.get('imdbID') or '', 'ratings': {}, 'rating': 0, 'votes': 0,
    }
    merge_omdb(result, data)
    imdb = (result.get('ratings') or {}).get('imdb') or {}
    result['rating'] = safe_float(imdb.get('rating'))
    result['votes'] = safe_int(imdb.get('votes'))
    return result


def _youtube_id(value):
    match = re.search(r'(?:v=|youtu\.be/|embed/)([A-Za-z0-9_-]{11})', str(value or ''))
    return match.group(1) if match else ''


def _kinopoisk_trailer_candidates(videos):
    output = []
    for row in videos or []:
        if str(row.get('site') or '').upper() != 'YOUTUBE' or not row.get('url'):
            continue
        video_id = _youtube_id(row.get('url'))
        if not video_id:
            continue
        name = str(row.get('name') or '')
        lowered = name.lower()
        kind = 'Trailer' if ('трейлер' in lowered or 'trailer' in lowered) else 'Teaser' if ('тизер' in lowered or 'teaser' in lowered) else 'Video'
        output.append({
            'url': config.youtube_play_url(video_id),
            'key': video_id,
            # Kinopoisk does not expose a language tag for video rows. Its localized
            # trailer feed is Russian, so it participates as Russian rather than as
            # language-neutral artwork/video for every configured UI language.
            'language': 'ru',
            'official': ('официаль' in lowered or 'official' in lowered),
            'type': kind,
            'name': name,
            'size': 0,
            'published_at': '',
        })
    return output


_KP_DEV_TYPES = {
    'movie': 'FILM', 'cartoon': 'FILM', 'anime': 'FILM',
    'tv-series': 'TV_SERIES', 'animated-series': 'TV_SERIES',
    'mini-series': 'MINI_SERIES', 'tv-show': 'TV_SHOW',
}


def kinopoisk_dev_to_legacy(data):
    """Ответ kinopoisk.dev в тех же полях, что у kinopoiskapiunofficial.

    Так у нас остаётся ОДИН разбор Кинопоиска (normalize_kinopoisk), а второй
    API - лишь другой источник тех же сведений. Заведено 07.09.2026, когда
    норма 500 запросов в сутки у прежнего API исчерпалась.
    """
    if not isinstance(data, dict) or not data:
        return {}
    rating = data.get('rating') or {}
    votes = data.get('votes') or {}
    poster = data.get('poster') or {}
    backdrop = data.get('backdrop') or {}
    logo = data.get('logo') or {}
    external = data.get('externalId') or {}
    out = {
        'kinopoiskId': data.get('id'),
        'nameRu': data.get('name') or '',
        'nameEn': data.get('enName') or data.get('alternativeName') or '',
        'nameOriginal': data.get('alternativeName') or data.get('name') or '',
        'type': _KP_DEV_TYPES.get(str(data.get('type') or '').lower(), 'FILM'),
        'description': data.get('description') or '',
        'shortDescription': data.get('shortDescription') or '',
        'year': data.get('year') or '',
        'ratingKinopoisk': rating.get('kp') or '',
        'ratingKinopoiskVoteCount': votes.get('kp') or '',
        'ratingImdb': rating.get('imdb') or '',
        'ratingImdbVoteCount': votes.get('imdb') or '',
        'posterUrl': poster.get('url') or '',
        'posterUrlPreview': poster.get('previewUrl') or poster.get('url') or '',
        'coverUrl': backdrop.get('url') or '',
        'logoUrl': logo.get('url') or '',
        'filmLength': data.get('movieLength') or '',
        'slogan': data.get('slogan') or '',
        'imdbId': external.get('imdb') or '',
        'genres': [{'genre': str((item or {}).get('name') or '')}
                   for item in (data.get('genres') or [])],
        'countries': [{'country': str((item or {}).get('name') or '')}
                      for item in (data.get('countries') or [])],
        'ratingAgeLimits': ('age%s' % data.get('ageRating')) if data.get('ageRating') else '',
        'serial': str(data.get('type') or '').lower().endswith('series'),
    }
    premiere = (data.get('premiere') or {}).get('world') or ''
    if premiere:
        out['premiereWorld'] = str(premiere)[:10]
    return out


def normalize_kinopoisk(data, media_type=''):
    if not data:
        return {}
    raw_type = str(data.get('type') or '').upper()
    provider_media_type = 'tv' if raw_type in ('TV_SERIES', 'MINI_SERIES', 'TV_SHOW') else 'movie'
    if not media_type:
        media_type = provider_media_type
    media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
    russian = config.language().lower().startswith('ru')
    title = (data.get('nameRu') if russian else data.get('nameEn')) or data.get('nameRu') or data.get('nameEn') or data.get('nameOriginal') or ''
    original = data.get('nameOriginal') or data.get('nameEn') or title
    staff = data.get('_staff') or []
    cast = []
    crew = {'director': [], 'writer': [], 'producer': [], 'sound_department': [], 'art_department': [], 'photography': [], 'editor': []}
    mapping = {
        'DIRECTOR': ('director', 'Director'), 'WRITER': ('writer', 'Writer'), 'PRODUCER': ('producer', 'Producer'),
        'COMPOSER': ('sound_department', 'Composer'), 'OPERATOR': ('photography', 'Director of Photography'),
        'EDITOR': ('editor', 'Editor'), 'DESIGN': ('art_department', 'Production Design'),
    }
    for idx, person in enumerate(staff if isinstance(staff, list) else []):
        profession = str(person.get('professionKey') or '').upper()
        name = (person.get('nameRu') if russian else person.get('nameEn')) or person.get('nameRu') or person.get('nameEn') or ''
        row = {'id': person.get('staffId') or '', 'source': 'kinopoisk', 'name': name, 'role': person.get('description') or '', 'thumb': person.get('posterUrl') or '', 'order': idx}
        if profession == 'ACTOR':
            actor = dict(row)
            actor['job'] = 'Actor'
            cast.append(actor)
        elif profession in mapping:
            key, job = mapping[profession]
            item = dict(row)
            item['job'] = job
            item['role'] = job
            crew.setdefault(key, []).append(item)
    poster = data.get('posterUrl') or ''
    art = {k: v for k, v in {
        'poster': poster, 'poster_original': poster,
        'thumb': data.get('posterUrlPreview') or poster, 'icon': data.get('posterUrlPreview') or poster,
        # coverUrl is a card/cover fallback, not guaranteed to be a fanart image.
        # Keep it as landscape while allowing the lazy FAN_ART/WALLPAPER lookup.
        'landscape': data.get('coverUrl') or '', 'clearlogo': data.get('logoUrl') or '',
    }.items() if v}
    fanart_urls, poster_urls = [], []
    image_priority = {'FAN_ART': 0, 'WALLPAPER': 1, 'COVER': 2, 'STILL': 3, 'SCREENSHOT': 4, 'POSTER': 5}
    images = sorted(data.get('_images') or [], key=lambda row: image_priority.get(str(row.get('_type') or '').upper(), 99))
    for image in images:
        url = image.get('imageUrl') or ''
        kind = str(image.get('_type') or '').upper()
        if not url:
            continue
        if kind == 'POSTER':
            poster_urls.append(url)
        else:
            fanart_urls.append(url)
    if poster_urls and not art.get('poster'):
        art['poster'] = poster_urls[0]
        art['poster_original'] = poster_urls[0]
    if fanart_urls and not art.get('fanart'):
        art['fanart'] = fanart_urls[0]
        art['landscape'] = fanart_urls[0]
    trailer = ''
    videos = (data.get('_videos') or {}).get('items') or []
    trailer_candidates = _kinopoisk_trailer_candidates(videos)
    if trailer_candidates:
        chosen = sorted(
            trailer_candidates,
            key=lambda row: trailer_rank(row) + (str(row.get('name') or '').lower(),),
        )[0]
        trailer = chosen.get('url') or ''
    kp_rating = safe_float(data.get('ratingKinopoisk'))
    kp_votes = safe_int(data.get('ratingKinopoiskVoteCount'))
    imdb_rating = safe_float(data.get('ratingImdb'))
    imdb_votes = safe_int(data.get('ratingImdbVoteCount'))
    ratings = {}
    if kp_rating > 0:
        ratings['kinopoisk'] = {'rating': kp_rating, 'votes': kp_votes}
    if imdb_rating > 0:
        ratings['imdb'] = {'rating': imdb_rating, 'votes': imdb_votes}
    premiered = data.get('premiereWorld') or data.get('premiereRu') or ''
    return {
        'media_type': media_type, 'tmdb_type': media_type, 'dbtype': 'tvshow' if media_type == 'tv' else media_type,
        'provider_media_type': provider_media_type,
        'adult': bool(data.get('adult') or data.get('isAdult')),
        'kinopoisk_id': safe_int(data.get('kinopoiskId') or data.get('filmId')), 'imdb_id': data.get('imdbId') or '',
        'title': title, 'originaltitle': original, 'plot': clean_text(data.get('description')), 'plotoutline': data.get('shortDescription') or '',
        'tagline': str(data.get('slogan') or '').strip(' "'), 'premiered': premiered, 'year': safe_int(data.get('year') or data.get('startYear')),
        'runtime': safe_int(data.get('filmLength')) * 60, 'mpaa': str(data.get('ratingMpaa') or '').upper(),
        'genre': [str(row.get('genre') or '').capitalize() for row in data.get('genres') or [] if row.get('genre')],
        'country': [row.get('country') for row in data.get('countries') or [] if row.get('country')],
        'studio': [], 'status': data.get('productionStatus') or '', 'trailer': trailer, 'art': art,
        'art_candidates': {'clearlogo': ([{'url': art.get('clearlogo'), 'language': 'ru'}] if art.get('clearlogo') else [])},
        'trailer_candidates': trailer_candidates,
        'trailer_language': (chosen.get('language') if trailer_candidates else ''),
        'trailer_official': (bool(chosen.get('official')) if trailer_candidates else False),
        'fanart_art': {'fanart': fanart_urls, 'poster': poster_urls}, 'cast': cast, 'crew': crew,
        'rating': kp_rating or imdb_rating, 'votes': kp_votes or imdb_votes, 'ratings': ratings,
    }


def merge_omdb(meta, data):
    if not data:
        return meta
    meta['awards'] = data.get('Awards') or meta.get('awards') or ''
    awards_text = meta.get('awards') or ''
    win_values = [safe_int(x) for x in re.findall(r'Won\s+(\d+)\s+(?:award|awards|Oscar|Oscars|Primetime Emmy|Primetime Emmys)', awards_text, re.I)]
    win_values += [safe_int(x) for x in re.findall(r'Another\s+(\d+)\s+(?:win|wins)', awards_text, re.I)]
    if not win_values:
        win_values = [safe_int(x) for x in re.findall(r'(\d+)\s+(?:win|wins)', awards_text, re.I)]
    nomination_values = [safe_int(x) for x in re.findall(r'(\d+)\s+(?:nomination|nominations)', awards_text, re.I)]
    nomination_values += [safe_int(x) for x in re.findall(r'Nominated for\s+(\d+)\s+(?:Oscar|Oscars|Primetime Emmy|Primetime Emmys)', awards_text, re.I)]
    meta['total_awards_won'] = sum(win_values)
    meta['total_awards_nominated'] = sum(nomination_values)
    meta['awards_won_cr'] = awards_text if meta['total_awards_won'] else ''
    meta['awards_nominated_cr'] = awards_text if meta['total_awards_nominated'] else ''
    meta['language_text'] = data.get('Language') or ''
    meta['country_text'] = data.get('Country') or ''
    meta['boxoffice'] = data.get('BoxOffice') or ''
    if data.get('Poster') and data.get('Poster') != 'N/A' and not meta.get('art', {}).get('poster'):
        meta.setdefault('art', {})['poster'] = data.get('Poster')
    ratings = meta.setdefault('ratings', {})
    imdb = data.get('imdbRating')
    if imdb and imdb != 'N/A':
        ratings['imdb'] = {'rating': safe_float(imdb), 'votes': str(data.get('imdbVotes') or '').replace(',', '')}
    metascore = data.get('Metascore')
    if metascore and metascore != 'N/A':
        ratings['metacritic'] = {'rating': safe_float(metascore)}
    for row in data.get('Ratings') or []:
        source = row.get('Source')
        value = row.get('Value') or ''
        if source == 'Rotten Tomatoes':
            ratings['rottentomatoes'] = {'rating': safe_float(str(value).replace('%', ''))}
    return meta


def merge_mdblist(meta, data):
    if not data:
        return meta
    ratings = meta.setdefault('ratings', {})
    aliases = {'tomatoes': 'rottentomatoes', 'popcorn': 'rottentomatoes_user', 'tomatoesaudience': 'rottentomatoes_user', 'tomatoes_audience': 'rottentomatoes_user'}
    for row in data.get('ratings') or []:
        raw_source = str(row.get('source') or '').strip().lower().replace(' ', '').replace('-', '').replace('_', '')
        source = aliases.get(raw_source, raw_source)
        if not source:
            continue
        value = row.get('value') if row.get('value') is not None else row.get('score')
        # MDBList can expose TMDb/IMDb/Trakt values as 0..100 scores.  Those
        # must never replace the direct 0..10 provider value already present.
        numeric = safe_float(value)
        if source in ('tmdb', 'imdb', 'trakt', 'kinopoisk'):
            while numeric > 10.0:
                numeric /= 10.0
            value = numeric
        existing = ratings.get(source) or {}
        if safe_float(existing.get('rating')) <= 0:
            ratings[source] = {'rating': value, 'score': row.get('score'), 'votes': row.get('votes'), 'url': row.get('url')}
    if data.get('score_average') is not None:
        ratings['mdblist'] = {'rating': data.get('score_average')}
    meta['released_digital'] = data.get('released_digital') or ''
    meta['rottentomatoes_consensus'] = data.get('rottentomatoes_consensus') or data.get('tomatoes_consensus') or data.get('tomato_consensus') or ''
    meta['rottentomatoes_reviewsfresh'] = data.get('rottentomatoes_reviewsfresh') or data.get('tomatoes_reviews_fresh') or ''
    meta['rottentomatoes_reviewstotal'] = data.get('rottentomatoes_reviewstotal') or data.get('tomatoes_reviews_total') or ''
    return meta


def _fanart_url(value):
    value = str(value or '')
    if not value:
        return ''
    if value.startswith(('http://', 'https://')):
        return value
    return 'https://assets.fanart.tv/fanart/%s' % value.lstrip('/')


def merge_fanart(meta, data):
    if not data:
        return meta
    mapping = {
        'clearlogo': ('hdmovielogo', 'movielogo', 'hdtvlogo', 'clearlogo'),
        'clearart': ('hdmovieclearart', 'movieart', 'hdclearart', 'clearart'),
        'fanart': ('moviebackground', 'showbackground'),
        'poster': ('movieposter', 'tvposter'),
        'banner': ('moviebanner', 'tvbanner'),
        'landscape': ('moviethumb', 'tvthumb'),
        'discart': ('moviedisc',),
        'characterart': ('characterart',),
    }
    all_art = meta.setdefault('fanart_art', {})
    art_candidates = meta.setdefault('art_candidates', {})
    for target, source_keys in mapping.items():
        rows = []
        for key in source_keys:
            rows.extend(data.get(key) or [])
        if target == 'clearlogo':
            rows.sort(key=lambda row: (
                language_rank(_candidate_language(row)),
                -safe_int(row.get('likes')),
            ))
            candidates = []
            for row in rows:
                url = _fanart_url(row.get('url'))
                if url:
                    candidates.append({
                        'url': url,
                        'language': _candidate_language(row),
                        'likes': safe_int(row.get('likes')),
                    })
            if candidates:
                art_candidates[target] = candidates
        else:
            rows.sort(key=lambda row: safe_int(row.get('likes')), reverse=True)
        urls = [_fanart_url(row.get('url')) for row in rows if row.get('url')]
        if urls:
            all_art[target] = urls
            meta.setdefault('art', {}).setdefault(target, urls[0])
    return meta


def all_images(meta):
    output = []
    seen = set()
    images = meta.get('images') or {}
    groups = [('backdrop', images.get('backdrops') or []), ('poster', images.get('posters') or []), ('logo', images.get('logos') or []), ('profile', images.get('profiles') or []), ('still', images.get('stills') or [])]
    for kind, rows in groups:
        for row in rows:
            url = image_url(row.get('file_path'), 'original')
            if url and url not in seen:
                seen.add(url)
                output.append({'type': kind, 'url': url, 'thumb': image_url(row.get('file_path'), 'w780'), 'language': row.get('iso_639_1') or '', 'width': row.get('width'), 'height': row.get('height'), 'vote_average': row.get('vote_average')})
    for kind, urls in (meta.get('fanart_art') or {}).items():
        for url in urls:
            if url and url not in seen:
                seen.add(url)
                output.append({'type': kind, 'url': url, 'thumb': url, 'language': '', 'width': 0, 'height': 0, 'vote_average': 0})
    for kind, url in (meta.get('art') or {}).items():
        if url and url not in seen:
            seen.add(url)
            output.append({'type': kind, 'url': url, 'thumb': url, 'language': '', 'width': 0, 'height': 0, 'vote_average': 0})
    return output


def _days_between(date_value):
    try:
        day = datetime.datetime.strptime(str(date_value)[:10], '%Y-%m-%d').date()
        return (day - datetime.date.today()).days
    except Exception:
        return ''


def _is_episode_meta(meta):
    """Whether this model describes one episode rather than a show or a film."""
    meta = meta or {}
    if str(meta.get('dbtype') or '').lower() == 'episode':
        return True
    if str(meta.get('media_type') or '').lower() == 'episode':
        return True
    # A resolved TMDb episode keeps the show's media_type ('tv') and is told
    # apart by carrying both coordinates plus TMDb's own episode_type.
    return bool(meta.get('episode_type') and safe_int(meta.get('episode')) > 0)




def release_short(quality):
    """Короткая форма вида релиза для показа: «WEB-DLRip» -> «WEB-DL».

    Разбор и хранение не меняются - короче становится только надпись на экране.
    Хвост «Rip» ничего не сообщает: и «WEB-DLRip», и «WEB-DL» - это один и тот
    же вид, а места он занимает как три-четыре знака.

    Но только пока от вида остаётся его имя. «BDRip» -> «BD» - уже неправда:
    BD это диск целиком, а BDRip - пережатая с него копия; то же с «HDRip» и
    «TVRip». Замер на .30 11.09.2026 по строке РуТора «Один дома»: в чипе
    стояло «BD» при релизе BDRip. Поэтому хвост снимается только когда остаток
    не короче трёх знаков: WEB-DLRip -> WEB-DL, HDTVRip -> HDTV, DVDRip -> DVD,
    WEBRip -> WEB, CAMRip -> CAM, а BDRip, HDRip и TVRip остаются как есть.
    """
    text = str(quality or '').strip()
    if len(text) >= 6 and text.lower().endswith('rip'):
        text = text[:-3].rstrip('-. ')
    return text


def window_properties(meta, prefix='SublimeHelper.ListItem'):
    art = meta.get('art') or {}
    tv_art = meta.get('tvshow_art') or {}
    ratings = meta.get('ratings') or {}
    props = {
        'Title': meta.get('title'), 'OriginalTitle': meta.get('originaltitle'),
        # Чистим ЗДЕСЬ тоже, а не только на входе от поставщика: в
        # metadata_cache и в снимках строк уже лежат описания с разметкой
        # (замер на .30 07.09.2026: 152 строки с «<br»), и лечить их
        # переопознанием было бы расточительно.
        'Plot': clean_text(meta.get('plot')),
        'biography': meta.get('plot') if meta.get('media_type') == 'person' else '',
        'Tagline': meta.get('tagline'), 'Year': meta.get('year') or '', 'Premiered': meta.get('premiered'),
        'FirstAired': meta.get('premiered'), 'Premiered_Long': meta.get('premiered'), 'Status': meta.get('status'),
        # Номер сезона и серии - для строки «Сезон 2 · Серия 5 · Похороны»
        # под заголовком (Info_Sublime_EpisodeLine). До 07.09.2026 наружу
        # они не выдавались вовсе, а у Kodi их взять негде: в окне сериала
        # фокус стоит на полосе сезонов, и там ListItem.Episode - это число
        # серий в сезоне.
        # Качество релиза: «WEB-DLRip» и «1080» отдельно, чтобы разметка
        # собрала из них значок инфостроки. Показывается короткая форма:
        # 10.09.2026 владелец - «вся строка не помещается … как содержимое
        # сделать компактнее?». Замер на .30: строка 924 px, из них рамка 230.
        # Хвост «Rip» смысла не добавляет («WEB-DLRip» = «WEB-DL»), а стоит ~45
        # px, поэтому в показ идёт короткая форма (release_short).
        'Release_Quality': release_short(meta.get('release_quality')),
        'Release_Resolution': meta.get('release_resolution') or '',
        # Одной строкой: что за раздача, вес, сиды, озвучка. Составляет её
        # плагин-источник, скин показывает под инфострокой.
        'Release_Details': meta.get('release_details') or '',
        'Season': (str(meta.get('season')) if safe_int(meta.get('season')) > 0 else ''),
        'Episode': (str(meta.get('episode')) if safe_int(meta.get('episode')) > 0 else ''),
        'Type': meta.get('episode_type') or meta.get('media_type'), 'Genre': join_names(meta.get('genre')),
        'Genres': join_names(meta.get('genre')), 'Country': meta.get('country_text') or join_names(meta.get('country')),
        'Countries': meta.get('country_text') or join_names(meta.get('country')), 'Language': meta.get('language_text') or join_names(meta.get('language')),
        'Studio': join_names(meta.get('studio')), 'Budget': ('$%s' % meta.get('budget')) if meta.get('budget') else '',
        'Revenue': ('$%s' % meta.get('revenue')) if meta.get('revenue') else '', 'Awards': meta.get('awards'),
        'Awards_Won_CR': meta.get('awards_won_cr'), 'Awards_Nominated_CR': meta.get('awards_nominated_cr'),
        'rottentomatoes_consensus': meta.get('rottentomatoes_consensus'),
        'rottentomatoes_reviewsfresh': meta.get('rottentomatoes_reviewsfresh'),
        'rottentomatoes_reviewstotal': meta.get('rottentomatoes_reviewstotal'),
        'Total_Awards_Won': meta.get('total_awards_won'), 'Total_Awards_Nominated': meta.get('total_awards_nominated'),
        'Trailer': meta.get('trailer'), 'TrailerFallback': meta.get('trailer_fallback'),
        'Kinopoisk_ID': meta.get('kinopoisk_id'), 'IMDb_ID': meta.get('imdb_id'), 'TMDB_ID': meta.get('tmdb_id'), 'TMDb_ID': meta.get('tmdb_id'),
        'Item.TMDb_ID': meta.get('item_tmdb_id'), 'TMDB_Type': meta.get('tmdb_type'), 'TMDb_Type': meta.get('tmdb_type'),
        'DBType': meta.get('dbtype') or meta.get('media_type'), 'DBID': meta.get('dbid'),
        'IdentityRejected': 'true' if (meta.get('_identity_rejected')
                                       and not meta.get('_background_has_enriched_art')) else '',
        'IdentityPending': 'true' if meta.get('_identity_pending') else '',
        'DateAdded': meta.get('dateadded'), 'LastPlayed': meta.get('lastplayed'), 'PlayCount': meta.get('playcount'),
        'Top250': meta.get('top250') if safe_int(meta.get('top250')) > 0 else '', 'filenameandpath': meta.get('file'), 'TVShowTitle': meta.get('tvshowtitle'),
        'Poster': art.get('poster'), 'PosterOriginal': art.get('poster_original') or art.get('poster'),
        'Fanart': art.get('fanart'), 'Landscape': art.get('landscape'),
        'ClearLogo': art.get('clearlogo'), 'ClearArt': art.get('clearart'),
        # An episode's still is the picture that row is about, and it is the one
        # piece of episode art no provider publishes as a background. It was
        # resolved and merged all along - art['thumb'] held
        # image.tmdb.org/.../w780/... for «Джек Ричер» s1e1 - and then went
        # nowhere: nothing in this map exposed 'thumb' on its own, and Base_Icon
        # put art['icon'] first, which on this chain is KinoPoisk's kp_small
        # SHOW poster. So the still was fetched, cached and thrown away.
        'Still': art.get('thumb') if _is_episode_meta(meta) else '',
        'Thumb': art.get('thumb'),
        'Base_Icon': ((art.get('thumb') or art.get('icon') or art.get('poster'))
                      if _is_episode_meta(meta)
                      else (art.get('icon') or art.get('thumb') or art.get('poster'))),
        'Base_Poster': art.get('poster'), 'Base_Clearlogo': art.get('clearlogo'), 'Birthday': meta.get('birthday'),
        'Deathday': meta.get('deathday'), 'Age': meta.get('age'), 'Gender': meta.get('gender'), 'Episode_type': meta.get('episode_type'),
        'Set.TMDb_ID': meta.get('collection_id'), 'Set.Name': meta.get('collection_name'),
        'tvshow.tmdb_id': meta.get('tvshow_tmdb_id') or (meta.get('tmdb_id') if meta.get('tmdb_type') == 'tv' else ''),
        'TVShow.TMDb_ID': meta.get('tvshow_tmdb_id') or (meta.get('tmdb_id') if meta.get('tmdb_type') == 'tv' else ''),
        'TVShow.Fanart': tv_art.get('fanart'), 'TVShow.Landscape': tv_art.get('landscape') or tv_art.get('fanart'),
        'base_Title': meta.get('title'), 'base_title': meta.get('title'), 'base_label': meta.get('title'),
        'base_tvshowtitle': meta.get('tvshowtitle'), 'base_plot': meta.get('plot'), 'base_dbtype': meta.get('dbtype'),
        'base_folderpath': meta.get('file'), 'base_poster': art.get('poster'), 'base_clearlogo': art.get('clearlogo'),
        'base_icon': art.get('icon') or art.get('thumb') or art.get('poster'),
    }
    rating_map = {
        'TMDb_Rating': 'tmdb', 'IMDb_Rating': 'imdb', 'Trakt_Rating': 'trakt', 'MetaCritic_Rating': 'metacritic',
        'RottenTomatoes_Rating': 'rottentomatoes', 'RottenTomatoes_UserMeter': 'rottentomatoes_user',
        'MDBList_Rating': 'mdblist', 'Letterboxd_Rating': 'letterboxd', 'Kinopoisk_Rating': 'kinopoisk',
    }
    # Оценки по десятибалльной шкале печатаются с одним знаком - все, а не
    # только TMDb. Кинопоиск отдаёт и «7», и «7.813»; на экране рядом с «7.4» от
    # TMDb это выглядело как разнобой, и владелец сказал: «рейтинг КП не округлён
    # до десятых». Проценты (Metacritic, Rotten Tomatoes, MDBList) сюда не
    # входят - у них своя шкала и свой знак процента в разметке.
    ten_point = ('TMDb_Rating', 'IMDb_Rating', 'Kinopoisk_Rating', 'Trakt_Rating',
                 'Letterboxd_Rating')
    for prop, source in rating_map.items():
        value = (ratings.get(source) or {}).get('rating')
        if prop in ten_point:
            numeric = safe_float(value)
            # Final guard for cached/third-party 0..100 scores.
            while numeric > 10.0:
                numeric /= 10.0
            if numeric > 0:
                props[prop] = '%.1f' % numeric
        elif value not in (None, ''):
            props[prop] = value
    rt_value = (ratings.get('rottentomatoes') or {}).get('rating')
    if rt_value not in (None, ''):
        rt = safe_float(rt_value)
        props['RottenTomatoes_Image'] = 'certified' if rt >= 75 else ('fresh' if rt >= 60 else 'rotten')
    next_ep = meta.get('next_aired') or {}
    last_ep = meta.get('last_aired') or {}
    props.update({
        'Next_Aired': next_ep.get('air_date') or '', 'Next_Aired.Season': next_ep.get('season_number') or '',
        'Next_Aired.Episode': next_ep.get('episode_number') or '', 'Next_Aired.Days_Until_Aired': _days_between(next_ep.get('air_date')),
        'Next_Aired.Long': next_ep.get('air_date') or '', 'Last_Aired': last_ep.get('air_date') or '',
        'Last_Aired.Days_From_Aired': abs(_days_between(last_ep.get('air_date'))) if isinstance(_days_between(last_ep.get('air_date')), int) else '',
        'Last_Aired.Long': last_ep.get('air_date') or '',
    })
    for idx, row in enumerate(meta.get('providers') or [], 1):
        props['Provider.%d.Name' % idx] = row.get('provider_name') or ''
        props['Provider.%d.Icon' % idx] = image_url(row.get('logo_path'), 'w185')
    for idx, row in enumerate(meta.get('networks') or [], 1):
        props['Network.%d.Name' % idx] = row.get('name') or ''
    for idx, name in enumerate(meta.get('studio') or [], 1):
        props['Studio.%d.Name' % idx] = name
    for idx, name in enumerate(meta.get('genre') or []):
        props['Genres.%d.Name' % idx] = name
    for idx, name in enumerate(meta.get('country') or []):
        props['Countries.%d.Name' % idx] = name
        props['Country.%d.Name' % idx] = name
    groups = [('Cast', meta.get('cast') or [])]
    crew = meta.get('crew') or {}
    groups.extend([
        ('Director', crew.get('director') or []), ('Writer', crew.get('writer') or []), ('Creator', crew.get('creator') or []),
        ('Producer', crew.get('producer') or []), ('Sound_Department', crew.get('sound_department') or []),
        ('Art_Department', crew.get('art_department') or []), ('Photography', crew.get('photography') or []), ('Editor', crew.get('editor') or []),
    ])
    for group, rows in groups:
        props[group] = join_names(rows)
        for idx, row in enumerate(rows[:20], 1):
            props['%s.%d.Name' % (group, idx)] = row.get('name') or ''
            props['%s.%d.Role' % (group, idx)] = row.get('role') or row.get('job') or ''
            props['%s.%d.job' % (group, idx)] = row.get('job') or row.get('role') or ''
            props['%s.%d.Thumb' % (group, idx)] = row.get('thumb') or ''
            props['%s.%d.TMDb_ID' % (group, idx)] = row.get('id') or ''
            props['%s.%d.TMDB_ID' % (group, idx)] = row.get('id') or ''
    return {'%s.%s' % (prefix, key): value for key, value in props.items() if value not in (None, '')}

