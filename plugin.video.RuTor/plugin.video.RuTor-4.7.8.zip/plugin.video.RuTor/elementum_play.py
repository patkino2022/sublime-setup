# -*- coding: utf-8 -*-
"""Воспроизведение релиза движком Elementum - без ТАМа.

Владелец 11.09.2026: «отвяжи его от TAM, пусть воспроизводит движком Elementum
сходу». Раньше строка релиза вела в plugin://plugin.video.tam/?mode=open: ТАМ
разбирал торрент, показывал свой список файлов и в конце всё равно звал тот же
движок - в его main.play_elementum адрес ровно такой же, какой строится здесь
(plugin://plugin.video.elementum/play?uri=...&oindex=...). Посредник убран, а
движок остался тот же, что и был.

Что отдаём движку: магнит, если РуТор его дал (у него в списке он есть почти
всегда), иначе ссылку на .torrent. Магнит предпочтительнее не из вкусовых
соображений: сборка Elementum на этих коробках собрана «for TAM and magnet» с
памятью вместо папки загрузки, и по
магниту она стартует, не скачивая файл торрента через сайт, который бывает
заблокирован.

Выбор файла внутри торрента движок делает сам: у фильма файл один, а у сериала
включён smart_episode_choose - при номерах сезона и серии в метках он берёт
нужную серию. Если файлов много и выбрать не из чего, движок покажет свой
список - это его окно, не наше.
"""
from __future__ import absolute_import, unicode_literals

import sys

if sys.version_info.major > 2:
    from urllib.parse import quote
else:
    from urllib import quote

ELEMENTUM = 'plugin://plugin.video.elementum'


def playback_uri(url, info=None):
    """Что отдать движку: магнит, если он есть, иначе ссылка на .torrent."""
    info = info or {}
    magnet = ''
    try:
        magnet = str(info.get('magnet') or '').strip()
    except Exception:
        magnet = ''
    if magnet.startswith('magnet:'):
        return magnet
    return str(url or '')


def play_url(url, info=None, index=None):
    """Адрес, по которому Kodi играет релиз движком Elementum."""
    uri = playback_uri(url, info)
    if not uri:
        return ''
    address = '%s/play?uri=%s' % (ELEMENTUM, quote(uri, safe=''))
    if index is not None and str(index) != '':
        # Тот же параметр, которым номер файла передавал ТАМ: у движка начиная
        # с 0.1.52 это oindex (см. plugin.video.tam/main.py, play_elementum).
        address += '&oindex=%s' % quote(str(index), safe='')
    return address


def context_items(url, info=None):
    """Контекстное меню строки релиза.

    Пункты ТАМа («Сохранить фильм», «Настройки ТАМ») сняты вместе с самим
    посредником. Остаётся то, что относится к движку: показать его список
    файлов, когда автоматический выбор не устраивает.
    """
    uri = playback_uri(url, info)
    if not uri:
        return []
    return [(
        '[B]Выбрать файл в торренте[/B]',
        'RunPlugin(%s/playuri?uri=%s)' % (ELEMENTUM, quote(uri, safe='')),
    )]
