import copy
import json
import os
import sqlite3
import datetime
import hashlib
import time

__all__ = ['FilmixCache']


class FilmixCache(object):

    # 8: снять widget_snapshots - при 7 удаление ниже не запускалось (6 МБ с августа, 23.11.2026)
    SCHEMA_VERSION = 8
    PLAYER_SHRINK_CONFIRMATIONS = 2
    PLAYER_SHRINK_MIN_CONFIRM_AGE = 60
    PLAYER_SHRINK_CANDIDATE_TTL = 24 * 60 * 60

    def __init__(self, cache_dir):
        self._version = 4

        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)

        db_path = os.path.join(cache_dir, 'cache{0}.db'.format(self._version))

        # Keep GUI/plugin routes responsive if a background worker owns the WAL
        # writer lock.  The old 30s timeout multiplied by eight retries could
        # block one route for roughly four minutes.
        self.conn = sqlite3.connect(db_path, timeout=2, isolation_level=None)
        self.conn.row_factory = self._dict_factory
        self._configure_connection()
        self.create_database()

    def __del__(self):
        self.close()

    def close(self):
        try:
            conn = getattr(self, 'conn', None)
            if conn is not None:
                conn.close()
                self.conn = None
        except Exception:
            pass

    def _configure_connection(self):
        try:
            self.conn.execute('PRAGMA journal_mode=WAL')
        except Exception:
            pass
        try:
            self.conn.execute('PRAGMA synchronous=NORMAL')
        except Exception:
            pass
        try:
            self.conn.execute('PRAGMA busy_timeout=1000')
        except Exception:
            pass

    def _write(self, query, sql_params=None, retries=2, sleep_sec=0.10):
        sql_params = sql_params or {}
        last_error = None
        for _ in range(retries):
            try:
                c = self.conn.cursor()
                c.execute(query, sql_params)
                return c
            except sqlite3.OperationalError as e:
                if 'locked' not in str(e).lower():
                    raise
                last_error = e
                import time
                time.sleep(sleep_sec)
        raise last_error

    @staticmethod
    def _dict_factory(cursor, row):
        d = {}
        for idx, col in enumerate(cursor.description):
            d[col[0]] = row[idx]
        return d

    @staticmethod
    def _norm(value):
        if value in [None, '', 'None']:
            return ''
        return str(value)

    @staticmethod
    def _now():
        return datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')

    @staticmethod
    def _ts():
        try:
            return int(time.time())
        except Exception:
            return 0

    def _ensure_column(self, table_name, column_name, column_type):
        try:
            c = self.conn.cursor()
            c.execute('PRAGMA table_info({0})'.format(table_name))
            columns = [str(row.get('name') or '') for row in (c.fetchall() or [])]
            if column_name not in columns:
                c.execute('ALTER TABLE {0} ADD COLUMN {1} {2}'.format(
                    table_name, column_name, column_type))
        except Exception:
            # Cache migration must never make the addon unusable. A later open
            # can still fall back to the legacy details-only behaviour.
            pass

    @staticmethod
    def _episode_collection_count(value):
        if isinstance(value, list):
            return len([item for item in value if item not in (None, '', False)])
        if isinstance(value, dict):
            numeric = 0
            for key, item in value.items():
                try:
                    int(str(key))
                except Exception:
                    continue
                if item not in (None, '', False):
                    numeric += 1
            return numeric if numeric else len(value)
        return 0

    @classmethod
    def playlist_summary(cls, details):
        result = {}
        try:
            player_links = (details or {}).get('player_links') or {}
            playlist = player_links.get('playlist') if isinstance(player_links, dict) else None
            if not isinstance(playlist, dict):
                return result
            for season, translations in playlist.items():
                season_key = str(season)
                result[season_key] = {}
                if not isinstance(translations, dict):
                    continue
                for translation, episodes in translations.items():
                    result[season_key][str(translation)] = cls._episode_collection_count(episodes)
        except Exception:
            return {}
        return result


    @classmethod
    def _has_playback_data(cls, details):
        try:
            links = (details or {}).get('player_links') or {}
            if not isinstance(links, dict):
                return False
            if links.get('movie'):
                return True
            return bool(links.get('playlist'))
        except Exception:
            return False

    @staticmethod
    def _canonical_playlist_key(value):
        if value in (None, ''):
            return ''
        try:
            text = str(value)
            if text.lstrip('-').isdigit():
                return str(int(text))
            return text
        except Exception:
            return value

    @classmethod
    def _normalize_episode_collection(cls, episodes):
        if isinstance(episodes, list):
            return copy.deepcopy(episodes)
        if not isinstance(episodes, dict):
            return copy.deepcopy(episodes)
        result = {}
        for episode, payload in episodes.items():
            key = cls._canonical_playlist_key(episode)
            if key not in result:
                result[key] = copy.deepcopy(payload)
                continue
            current = result.get(key)
            current_score = len(current) if isinstance(current, dict) else int(bool(current))
            payload_score = len(payload) if isinstance(payload, dict) else int(bool(payload))
            if payload_score >= current_score:
                result[key] = copy.deepcopy(payload)
        return result

    @classmethod
    def _collection_identity_keys(cls, value):
        """Return stable structural keys without stream URLs or metadata."""
        if isinstance(value, dict):
            result = []
            for key, payload in value.items():
                if payload in (None, '', False):
                    continue
                result.append(cls._canonical_playlist_key(key))
            return sorted(set(result), key=lambda item: (not str(item).lstrip('-').isdigit(),
                                                          int(item) if str(item).lstrip('-').isdigit() else str(item)))
        if isinstance(value, list):
            return [str(index + 1) for index, payload in enumerate(value)
                    if payload not in (None, '', False)]
        if value not in (None, '', False):
            return ['value']
        return []

    @classmethod
    def player_identity(cls, player_links):
        """Stable playback topology used for shrink confirmation.

        Signed/rotating CDN URLs deliberately do not participate.  Only movie
        quality keys and season/translation/episode identities are compared.
        """
        links = cls.normalize_player_links(player_links or {})
        if not isinstance(links, dict):
            return {}
        result = {}
        movie = links.get('movie')
        if movie:
            result['movie'] = cls._collection_identity_keys(movie)
        playlist = links.get('playlist')
        if isinstance(playlist, dict):
            seasons = {}
            for season, translations in playlist.items():
                season_key = cls._canonical_playlist_key(season)
                if not isinstance(translations, dict):
                    seasons[season_key] = {'': cls._collection_identity_keys(translations)}
                    continue
                translated = {}
                for translation, episodes in translations.items():
                    translated[str(translation)] = cls._collection_identity_keys(episodes)
                seasons[season_key] = translated
            result['playlist'] = seasons
        return result

    @classmethod
    def normalize_player_links(cls, player_links):
        if not isinstance(player_links, dict):
            return copy.deepcopy(player_links)
        result = copy.deepcopy(player_links)
        playlist = player_links.get('playlist')
        if isinstance(playlist, dict):
            normalized = {}
            for season, translations in playlist.items():
                season_key = cls._canonical_playlist_key(season)
                target = normalized.setdefault(season_key, {})
                if not isinstance(translations, dict):
                    if not target:
                        normalized[season_key] = copy.deepcopy(translations)
                    continue
                if not isinstance(target, dict):
                    target = {}
                    normalized[season_key] = target
                for translation, episodes in translations.items():
                    translation_key = str(translation)
                    incoming = cls._normalize_episode_collection(episodes)
                    if translation_key not in target:
                        target[translation_key] = incoming
                    elif cls._episode_collection_count(incoming) >= cls._episode_collection_count(target.get(translation_key)):
                        target[translation_key] = incoming
            result['playlist'] = normalized
        return result

    @classmethod
    def _player_is_shrink(cls, existing_links, incoming_links):
        if not isinstance(existing_links, dict) or not existing_links:
            return False
        if not isinstance(incoming_links, dict) or not incoming_links:
            return True

        old_identity = cls.player_identity(existing_links)
        new_identity = cls.player_identity(incoming_links)

        old_movie = set(old_identity.get('movie') or [])
        new_movie = set(new_identity.get('movie') or [])
        if old_movie and not old_movie.issubset(new_movie):
            return True

        old_playlist = old_identity.get('playlist')
        new_playlist = new_identity.get('playlist')
        if isinstance(old_playlist, dict) and old_playlist:
            if not isinstance(new_playlist, dict) or not new_playlist:
                return True
            for season, old_translations in old_playlist.items():
                season_key = cls._canonical_playlist_key(season)
                new_translations = new_playlist.get(season_key)
                if not isinstance(old_translations, dict):
                    continue
                if not isinstance(new_translations, dict):
                    return True
                for translation, old_episodes in old_translations.items():
                    translation_key = str(translation)
                    if translation_key not in new_translations:
                        return True
                    old_keys = set(old_episodes or [])
                    new_keys = set(new_translations.get(translation_key) or [])
                    if not old_keys.issubset(new_keys):
                        return True
        return False

    @classmethod
    def _player_checksum(cls, player_links):
        try:
            payload = json.dumps(cls.player_identity(player_links), ensure_ascii=False,
                                 sort_keys=True, separators=(',', ':'))
            return hashlib.sha1(payload.encode('utf-8')).hexdigest()
        except Exception:
            return ''


    @classmethod
    def _refresh_common_collection(cls, existing, incoming):
        """Refresh payloads for identities already present without changing topology."""
        existing = cls._normalize_episode_collection(existing)
        incoming = cls._normalize_episode_collection(incoming)
        if isinstance(existing, dict) and isinstance(incoming, dict):
            result = copy.deepcopy(existing)
            for key in list(result.keys()):
                canonical = cls._canonical_playlist_key(key)
                if canonical in incoming:
                    result[canonical] = copy.deepcopy(incoming.get(canonical))
            return result
        if isinstance(existing, list) and isinstance(incoming, list):
            result = copy.deepcopy(existing)
            for index in range(min(len(result), len(incoming))):
                result[index] = copy.deepcopy(incoming[index])
            return result
        return copy.deepcopy(existing)

    @classmethod
    def merge_player_links_pending_shrink(cls, existing_details, incoming_details):
        """Apply safe fresh payloads while a topology reduction is unconfirmed.

        Existing episode/quality identities remain exactly visible until the same
        structural reduction is confirmed. Fresh URLs for common identities and
        wholly new seasons/translations are still accepted immediately.
        """
        existing_links = cls.normalize_player_links((existing_details or {}).get('player_links') or {})
        incoming_links = cls.normalize_player_links((incoming_details or {}).get('player_links') or {})
        if not isinstance(existing_links, dict):
            existing_links = {}
        if not isinstance(incoming_links, dict):
            incoming_links = {}
        result = copy.deepcopy(existing_links)

        for key, value in incoming_links.items():
            if key not in ('movie', 'playlist'):
                result[key] = copy.deepcopy(value)

        old_movie = existing_links.get('movie')
        new_movie = incoming_links.get('movie')
        if old_movie:
            old_keys = set(cls._collection_identity_keys(old_movie))
            new_keys = set(cls._collection_identity_keys(new_movie))
            if old_keys.issubset(new_keys):
                result['movie'] = copy.deepcopy(new_movie)
            else:
                result['movie'] = cls._refresh_common_collection(old_movie, new_movie)
        elif new_movie:
            result['movie'] = copy.deepcopy(new_movie)

        old_playlist = existing_links.get('playlist')
        new_playlist = incoming_links.get('playlist')
        if isinstance(old_playlist, dict):
            merged_playlist = copy.deepcopy(old_playlist)
            if isinstance(new_playlist, dict):
                for season, new_translations in new_playlist.items():
                    season_key = cls._canonical_playlist_key(season)
                    if season_key not in merged_playlist:
                        merged_playlist[season_key] = copy.deepcopy(new_translations)
                        continue
                    old_translations = merged_playlist.get(season_key)
                    if not isinstance(old_translations, dict) or not isinstance(new_translations, dict):
                        continue
                    for translation, new_episodes in new_translations.items():
                        translation_key = str(translation)
                        if translation_key not in old_translations:
                            old_translations[translation_key] = copy.deepcopy(new_episodes)
                            continue
                        old_episodes = old_translations.get(translation_key)
                        old_keys = set(cls._collection_identity_keys(old_episodes))
                        new_keys = set(cls._collection_identity_keys(new_episodes))
                        if old_keys.issubset(new_keys):
                            old_translations[translation_key] = copy.deepcopy(new_episodes)
                        else:
                            old_translations[translation_key] = cls._refresh_common_collection(
                                old_episodes, new_episodes)
            result['playlist'] = merged_playlist
        elif isinstance(new_playlist, dict):
            result['playlist'] = copy.deepcopy(new_playlist)
        return cls.normalize_player_links(result)


    def create_database(self):
        c = self.conn.cursor()
        try:
            row = c.execute('PRAGMA user_version').fetchone() or {}
            current_version = int(row.get('user_version') or 0)
        except Exception:
            current_version = 0
        if current_version >= int(self.SCHEMA_VERSION):
            return

        try:
            c.execute('BEGIN IMMEDIATE')
            row = c.execute('PRAGMA user_version').fetchone() or {}
            if int(row.get('user_version') or 0) >= int(self.SCHEMA_VERSION):
                c.execute('COMMIT')
                return

            c.execute('''CREATE TABLE IF NOT EXISTS posts (
                            post_id text,
                            details text,
                            updated_at text,
                            updated_ts integer,
                            player_updated_ts integer
                         )''')
            self._ensure_column('posts', 'updated_at', 'text')
            self._ensure_column('posts', 'updated_ts', 'integer')
            self._ensure_column('posts', 'player_updated_ts', 'integer')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS posts_idx ON posts(post_id)')
            c.execute('CREATE TABLE IF NOT EXISTS translations (post_id text, translation text)')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS translations_idx ON translations(post_id)')
            c.execute('CREATE TABLE IF NOT EXISTS resolved_ids (post_id text, details text)')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS resolved_ids_idx ON resolved_ids(post_id)')
            c.execute('''CREATE TABLE IF NOT EXISTS watched_state (
                            post_id text, season text, episode text, watched integer,
                            playcount integer, last_watched text
                         )''')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS watched_state_idx ON watched_state(post_id, season, episode)')

            c.execute('DROP INDEX IF EXISTS resume_state_idx')
            c.execute('DROP TABLE IF EXISTS resume_state')

            # Trakt is gone from this add-on: the boxes keep their history in
            # Kodi and share it through the skin's hub. Its five tables are
            # dropped rather than left behind, because a dead table in a live
            # database is only a thing to wonder about later.
            for dead in ('widget_snapshots',
                         'trakt_map', 'trakt_pending', 'trakt_remote_state',
                         'trakt_local_override', 'trakt_resume_sent',
                         'trakt_movies_watched', 'trakt_episodes_watched'):
                c.execute('DROP INDEX IF EXISTS %s_idx' % dead)
                c.execute('DROP TABLE IF EXISTS %s' % dead)

            c.execute('''CREATE TABLE IF NOT EXISTS catalog_cache (
                            cache_key text, section text, page text, filters text,
                            details text, checksum text, updated_at text, updated_ts integer
                         )''')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS catalog_cache_idx ON catalog_cache(cache_key)')
            c.execute('''CREATE TABLE IF NOT EXISTS control_flags (
                            flag_key text, flag_value text, updated_at text, updated_ts integer
                         )''')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS control_flags_idx ON control_flags(flag_key)')
            c.execute('''CREATE TABLE IF NOT EXISTS player_shrink_candidates (
                            post_id text, checksum text, details text,
                            confirmations integer, updated_ts integer
                         )''')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS player_shrink_candidates_idx ON player_shrink_candidates(post_id)')
            c.execute('''CREATE TABLE IF NOT EXISTS jobs (
                            job_kind text NOT NULL,
                            identity text NOT NULL,
                            payload text,
                            state text NOT NULL DEFAULT 'queued',
                            due_ts integer NOT NULL DEFAULT 0,
                            priority integer NOT NULL DEFAULT 0,
                            lease_owner text,
                            lease_until integer NOT NULL DEFAULT 0,
                            attempts integer NOT NULL DEFAULT 0,
                            last_error text,
                            requeue_requested integer NOT NULL DEFAULT 0,
                            created_ts integer NOT NULL DEFAULT 0,
                            updated_ts integer NOT NULL DEFAULT 0
                         )''')
            c.execute('CREATE UNIQUE INDEX IF NOT EXISTS jobs_identity_idx ON jobs(job_kind, identity)')
            c.execute('CREATE INDEX IF NOT EXISTS jobs_due_idx ON jobs(job_kind, state, due_ts, priority, updated_ts)')
            c.execute('PRAGMA user_version={0}'.format(int(self.SCHEMA_VERSION)))
            c.execute('COMMIT')
        except Exception:
            try:
                c.execute('ROLLBACK')
            except Exception:
                pass
            raise

    def get_post_details_record(self, post_id):
        sql_params = {'post_id': self._norm(post_id)}
        c = self.conn.cursor()
        try:
            c.execute('''SELECT details, updated_at, updated_ts, player_updated_ts
                         FROM posts WHERE post_id = :post_id LIMIT 1''', sql_params)
        except sqlite3.OperationalError:
            c.execute('SELECT details FROM posts WHERE post_id = :post_id LIMIT 1', sql_params)
        result = c.fetchone()
        if result is None:
            return None
        try:
            details = json.loads(result.get('details') or '{}')
            if isinstance(details, dict) and isinstance(details.get('player_links'), dict):
                details['player_links'] = self.normalize_player_links(details.get('player_links'))
        except Exception:
            return None
        return {
            'details': details,
            'updated_at': result.get('updated_at') or '',
            'updated_ts': int(result.get('updated_ts') or 0),
            'player_updated_ts': int(result.get('player_updated_ts') or 0),
        }

    def get_post_details(self, post_id):
        record = self.get_post_details_record(post_id)
        if record is not None:
            return record.get('details')

    def get_post_player_updated_ts(self, post_id):
        record = self.get_post_details_record(post_id)
        return int((record or {}).get('player_updated_ts') or 0)

    def get_post_player_age(self, post_id):
        updated_ts = self.get_post_player_updated_ts(post_id)
        if updated_ts <= 0:
            return None
        try:
            return max(0, self._ts() - updated_ts)
        except Exception:
            return None

    def is_post_player_stale(self, post_id, ttl_seconds):
        updated_ts = self.get_post_player_updated_ts(post_id)
        if updated_ts <= 0:
            return True
        try:
            return (self._ts() - updated_ts) >= max(0, int(ttl_seconds or 0))
        except Exception:
            return True

    @staticmethod
    def _unique_norm_ids(post_ids):
        result = []
        seen = set()
        for post_id in post_ids or []:
            value = FilmixCache._norm(post_id)
            if value and value not in seen:
                seen.add(value)
                result.append(value)
        return result

    def _json_rows_by_post_id(self, table_name, post_ids):
        # 2.2.35 AM8_4GB_BULK_CACHE_READ:
        # Widget routes previously performed one SELECT per row for posts and
        # resolved_ids.  On AM8 4GB this multiplied SQLite waits across many AF3
        # widgets.  Keep cache-only routes cache-only, but read all row payloads
        # for the current widget in a few bulk SELECTs.
        ids = self._unique_norm_ids(post_ids)
        if not ids:
            return {}
        result = {}
        chunk_size = 400
        c = self.conn.cursor()
        for i in range(0, len(ids), chunk_size):
            chunk = ids[i:i + chunk_size]
            placeholders = ','.join(['?'] * len(chunk))
            query = 'SELECT post_id, details FROM {0} WHERE post_id IN ({1})'.format(table_name, placeholders)
            c.execute(query, chunk)
            for row in c.fetchall() or []:
                try:
                    details = row.get('details')
                    if details:
                        result[self._norm(row.get('post_id'))] = json.loads(details)
                except Exception:
                    pass
        return result

    def get_post_details_many(self, post_ids):
        return self._json_rows_by_post_id('posts', post_ids)

    def get_post_player_ages_many(self, post_ids):
        """Return cached player ages with one SELECT for widget snapshots."""
        ids = self._unique_norm_ids(post_ids)
        if not ids:
            return {}
        now = self._ts()
        result = {}
        chunk_size = 400
        c = self.conn.cursor()
        for i in range(0, len(ids), chunk_size):
            chunk = ids[i:i + chunk_size]
            placeholders = ','.join(['?'] * len(chunk))
            c.execute('SELECT post_id, player_updated_ts FROM posts WHERE post_id IN ({0})'.format(placeholders), chunk)
            for row in c.fetchall() or []:
                post_id = self._norm(row.get('post_id'))
                updated_ts = int(row.get('player_updated_ts') or 0)
                result[post_id] = (max(0, now - updated_ts) if updated_ts > 0 else None)
        return result

    TRAILER_FRESH_SECONDS = 3 * 86400
    # Сведения такого поста перепроверяются чаще, чем прячется пост: вышедший фильм получает ссылки
    # и появляется в списках в пределах этого срока, а не через трое суток
    TRAILER_RECHECK_SECONDS = 6 * 3600

    def trailer_only_ids(self, post_ids, stale=False):
        """Ид постов из кэша, у которых ссылки только на трейлер (ни фильма, ни серий). Только
        посты, полученные за последние трое суток: старый снимок не прячет вышедший фильм.
        stale=True - такие посты, чьи сведения пора перепроверить (старше TRAILER_RECHECK_SECONDS):
        prewarm.request_post_details ставит их в очередь. Иначе старый снимок не обновлялся никогда
        («Вински и тайна Перевёрнутого города» - сведения 102 дней, .20, 25.11.2026), а вышедший
        фильм ждал бы до трёх суток."""
        ids = self._unique_norm_ids(post_ids)
        out = set()
        fresh_since = self._ts() - (self.TRAILER_RECHECK_SECONDS if stale else self.TRAILER_FRESH_SECONDS)
        c = self.conn.cursor()
        for i in range(0, len(ids), 400):
            chunk = ids[i:i + 400]
            sql = ("SELECT post_id FROM posts WHERE post_id IN (" + ','.join(['?'] * len(chunk)) + ") "
                   "AND updated_ts " + ("< ? " if stale else ">= ? ") +
                   "AND json_extract(details, '$.player_links.trailer') IS NOT NULL "
                   "AND COALESCE(json_array_length(json_extract(details, '$.player_links.movie')), 0) = 0 "
                   "AND (json_extract(details, '$.player_links.playlist') IS NULL "
                   "OR json_extract(details, '$.player_links.playlist') IN ('{}', '[]'))")
            c.execute(sql, list(chunk) + [fresh_since])
            for row in c.fetchall() or []:
                out.add(self._norm(row.get('post_id')))
        return out

    def get_serial_status_many(self, post_ids):
        """{post_id: serial_stats.status} одним SELECT без разбора постов целиком: прогреву
        сериалов раз в 15 с нужно только это поле."""
        ids = self._unique_norm_ids(post_ids)
        result = {}
        c = self.conn.cursor()
        for i in range(0, len(ids), 400):
            chunk = ids[i:i + 400]
            c.execute("SELECT post_id, json_extract(details, '$.serial_stats.status') AS status "
                      "FROM posts WHERE post_id IN ({0})".format(','.join(['?'] * len(chunk))), chunk)
            for row in c.fetchall() or []:
                result[self._norm(row.get('post_id'))] = row.get('status')
        return result

    def get_resolved_ids_many(self, post_ids):
        return self._json_rows_by_post_id('resolved_ids', post_ids)

    def get_watched_states_many(self, post_ids):
        # Return every root/season/episode watched row for the supplied Filmix ids
        # in a single pass so small episode directories do not scan SQLite per
        # row while Home widgets are being built.
        ids = self._unique_norm_ids(post_ids)
        if not ids:
            return {}
        result = {}
        chunk_size = 400
        c = self.conn.cursor()
        for i in range(0, len(ids), chunk_size):
            chunk = ids[i:i + chunk_size]
            placeholders = ','.join(['?'] * len(chunk))
            c.execute('''SELECT post_id, season, episode, watched, playcount, last_watched
                         FROM watched_state
                         WHERE post_id IN ({0})'''.format(placeholders), chunk)
            for row in c.fetchall() or []:
                try:
                    key = (self._norm(row.get('post_id')),
                           self._norm(row.get('season')),
                           self._norm(row.get('episode')))
                    result[key] = row
                except Exception:
                    pass
        return result

    def get_watched_snapshot_many(self, post_ids, aggregate_threshold=20):
        # 2.2.36 AM8_4GB_SHOW_WATCH_STATS_AGGREGATE:
        # TV-show Home widgets previously loaded every watched_state episode row
        # for 50 shows (thousands of rows) only to calculate counters.  For large
        # widget pages, keep exact root/season states but use SQL GROUP BY
        # aggregates for episode progress.  Small directories still receive exact
        # rows, so episode/season screens keep precise per-row markers.
        ids = self._unique_norm_ids(post_ids)
        if not ids:
            return {}
        if len(ids) <= int(aggregate_threshold or 0):
            result = self.get_watched_states_many(ids)
            try:
                result['__filmix_snapshot_mode'] = 'full'
            except Exception:
                pass
            return result

        result = {'__filmix_summary_v1': {}, '__filmix_snapshot_mode': 'aggregate'}
        summary = result['__filmix_summary_v1']
        chunk_size = 400
        c = self.conn.cursor()
        for i in range(0, len(ids), chunk_size):
            chunk = ids[i:i + chunk_size]
            placeholders = ','.join(['?'] * len(chunk))

            # Root movie/tvshow rows and explicit season rows are needed for
            # context-menu state, but episode rows are replaced by aggregate
            # counters below.
            c.execute('''SELECT post_id, season, episode, watched, playcount, last_watched
                         FROM watched_state
                         WHERE post_id IN ({0}) AND episode = '' '''.format(placeholders), chunk)
            for row in c.fetchall() or []:
                try:
                    key = (self._norm(row.get('post_id')),
                           self._norm(row.get('season')),
                           self._norm(row.get('episode')))
                    result[key] = row
                except Exception:
                    pass

            c.execute('''SELECT post_id, season,
                                SUM(CASE WHEN watched > 0 THEN 1 ELSE 0 END) AS watched_count,
                                COUNT(*) AS row_count,
                                GROUP_CONCAT(CASE WHEN watched > 0 THEN episode END) AS watched_keys
                         FROM watched_state
                         WHERE post_id IN ({0}) AND episode <> ''
                         GROUP BY post_id, season'''.format(placeholders), chunk)
            for row in c.fetchall() or []:
                try:
                    post_key = self._norm(row.get('post_id'))
                    season_key = self._norm(row.get('season'))
                    watched_count = int(row.get('watched_count') or 0)
                    row_count = int(row.get('row_count') or 0)
                    season_summary = summary.setdefault((post_key, season_key), {'watched': 0, 'rows': 0, 'keys': set()})
                    season_summary['watched'] = int(season_summary.get('watched') or 0) + watched_count
                    # Номера просмотренных серий сезона: по ним watch_stats
                    # выбирает перевод так же, как по полному снимку.
                    season_summary['keys'].update(k for k in str(row.get('watched_keys') or '').split(',') if k)
                    season_summary['rows'] = int(season_summary.get('rows') or 0) + row_count
                    show_summary = summary.setdefault((post_key, ''), {'watched': 0, 'rows': 0})
                    show_summary['watched'] = int(show_summary.get('watched') or 0) + watched_count
                    show_summary['rows'] = int(show_summary.get('rows') or 0) + row_count
                except Exception:
                    pass
        return result

    def set_post_details(self, post_id, details, player_fresh=False, preserve_richer_player=True):
        if not isinstance(details, dict):
            return details

        post_id = self._norm(post_id)
        incoming = copy.deepcopy(details)
        if isinstance(incoming.get('player_links'), dict):
            incoming['player_links'] = self.normalize_player_links(incoming.get('player_links'))

        last_error = None
        for _ in range(2):
            c = self.conn.cursor()
            try:
                c.execute('BEGIN IMMEDIATE')
                c.execute('''SELECT details, updated_at, updated_ts, player_updated_ts
                             FROM posts WHERE post_id = :post_id LIMIT 1''', {'post_id': post_id})
                row = c.fetchone() or {}
                try:
                    existing = json.loads(row.get('details') or '{}') if row else {}
                except Exception:
                    existing = {}
                if not isinstance(existing, dict):
                    existing = {}
                if isinstance(existing.get('player_links'), dict):
                    existing['player_links'] = self.normalize_player_links(existing.get('player_links'))

                merged = dict(existing)
                merged.update(incoming)
                existing_links = existing.get('player_links') if isinstance(existing.get('player_links'), dict) else {}
                incoming_links = incoming.get('player_links') if isinstance(incoming.get('player_links'), dict) else {}
                existing_has_player = self._has_playback_data(existing)
                incoming_has_player = self._has_playback_data(incoming)
                accepted_fresh_player = False

                if player_fresh and incoming_has_player:
                    use_incoming = True
                    if preserve_richer_player and existing_has_player and self._player_is_shrink(existing_links, incoming_links):
                        checksum = self._player_checksum(incoming_links)
                        c.execute('''SELECT checksum, confirmations, updated_ts
                                     FROM player_shrink_candidates
                                     WHERE post_id = :post_id LIMIT 1''', {'post_id': post_id})
                        candidate = c.fetchone() or {}
                        candidate_age = self._ts() - int(candidate.get('updated_ts') or 0)
                        if candidate.get('checksum') == checksum and 0 <= candidate_age <= int(self.PLAYER_SHRINK_CANDIDATE_TTL):
                            confirmations = int(candidate.get('confirmations') or 0)
                            if candidate_age >= int(self.PLAYER_SHRINK_MIN_CONFIRM_AGE):
                                confirmations += 1
                                candidate_updated_ts = self._ts()
                            else:
                                candidate_updated_ts = int(candidate.get('updated_ts') or self._ts())
                        else:
                            confirmations = 1
                            candidate_updated_ts = self._ts()
                        c.execute('''INSERT OR REPLACE INTO player_shrink_candidates
                                     (post_id, checksum, details, confirmations, updated_ts)
                                     VALUES (:post_id, :checksum, :details, :confirmations, :updated_ts)''', {
                                         'post_id': post_id,
                                         'checksum': checksum,
                                         'details': json.dumps(incoming_links, ensure_ascii=False, sort_keys=True),
                                         'confirmations': confirmations,
                                         'updated_ts': candidate_updated_ts,
                                     })
                        use_incoming = confirmations >= int(self.PLAYER_SHRINK_CONFIRMATIONS)
                    else:
                        c.execute('DELETE FROM player_shrink_candidates WHERE post_id = :post_id', {'post_id': post_id})

                    if use_incoming:
                        merged['player_links'] = copy.deepcopy(incoming_links)
                        accepted_fresh_player = True
                        c.execute('DELETE FROM player_shrink_candidates WHERE post_id = :post_id', {'post_id': post_id})
                    else:
                        # Preserve old missing/longer branches, but still accept
                        # new seasons/translations and refreshed URLs from this
                        # response while shrink confirmation is pending.
                        merged['player_links'] = self.merge_player_links_pending_shrink(existing, incoming)
                elif existing_has_player:
                    # Metadata/prewarm writes must never alter player payload.
                    merged['player_links'] = copy.deepcopy(existing_links)
                elif incoming_has_player:
                    # First background record may keep its payload, but it remains
                    # stale until an interactive Filmix response validates it.
                    merged['player_links'] = copy.deepcopy(incoming_links)

                now_ts = self._ts()
                player_updated_ts = int(row.get('player_updated_ts') or 0)
                if accepted_fresh_player:
                    player_updated_ts = now_ts
                params = {
                    'post_id': post_id,
                    'details': json.dumps(merged, ensure_ascii=False),
                    'updated_at': self._now(),
                    'updated_ts': now_ts,
                    'player_updated_ts': player_updated_ts,
                }
                c.execute('''UPDATE posts SET details=:details, updated_at=:updated_at,
                             updated_ts=:updated_ts, player_updated_ts=:player_updated_ts
                             WHERE post_id=:post_id''', params)
                if int(c.rowcount or 0) == 0:
                    c.execute('''INSERT INTO posts
                                 (post_id, details, updated_at, updated_ts, player_updated_ts)
                                 VALUES (:post_id, :details, :updated_at, :updated_ts, :player_updated_ts)''', params)
                c.execute('COMMIT')
                return merged
            except sqlite3.OperationalError as e:
                try:
                    c.execute('ROLLBACK')
                except Exception:
                    pass
                if 'locked' not in str(e).lower():
                    raise
                last_error = e
                time.sleep(0.10)
            except Exception:
                try:
                    c.execute('ROLLBACK')
                except Exception:
                    pass
                raise
        raise last_error

    def get_post_translation(self, post_id):
        sql_params = {'post_id': post_id}
        c = self.conn.cursor()
        c.execute('SELECT translation FROM translations WHERE post_id = :post_id LIMIT 1', sql_params)
        result = c.fetchone()
        if result is not None:
            return result['translation']

    def set_post_translation(self, post_id, translation):
        sql_params = {'post_id': post_id, 'translation': translation}
        self._write('INSERT OR REPLACE INTO translations (post_id, translation) VALUES (:post_id, :translation)', sql_params)

    def get_resolved_ids(self, post_id):
        sql_params = {'post_id': post_id}
        c = self.conn.cursor()
        c.execute('SELECT details FROM resolved_ids WHERE post_id = :post_id LIMIT 1', sql_params)
        result = c.fetchone()
        if result is not None and result.get('details'):
            try:
                return json.loads(result['details'])
            except Exception:
                return None

    def set_resolved_ids(self, post_id, details):
        details_json = json.dumps(details or {}, ensure_ascii=False, sort_keys=True)
        try:
            current = self.get_resolved_ids(post_id)
            if current is not None and json.dumps(current or {}, ensure_ascii=False, sort_keys=True) == details_json:
                return
        except Exception:
            pass
        sql_params = {'post_id': post_id, 'details': details_json}
        self._write('INSERT OR REPLACE INTO resolved_ids (post_id, details) VALUES (:post_id, :details)', sql_params)

    def get_watched_state(self, post_id, season=None, episode=None):
        sql_params = {
            'post_id': self._norm(post_id),
            'season': self._norm(season),
            'episode': self._norm(episode)
        }
        c = self.conn.cursor()
        c.execute('''SELECT watched, playcount, last_watched
                     FROM watched_state
                     WHERE post_id = :post_id AND season = :season AND episode = :episode
                     LIMIT 1''', sql_params)
        return c.fetchone()

    def is_watched(self, post_id, season=None, episode=None):
        result = self.get_watched_state(post_id, season, episode)
        return bool(result and int(result.get('watched') or 0) > 0)

    def set_watched_state(self, post_id, watched, season=None, episode=None, playcount=None):
        watched_val = 1 if watched else 0
        state = self.get_watched_state(post_id, season, episode) or {}
        if playcount is None:
            if watched_val:
                current = int(state.get('playcount') or 0)
                playcount = max(1, current)
            else:
                playcount = 0
        playcount = int(playcount)
        if state:
            try:
                if int(state.get('watched') or 0) == watched_val and int(state.get('playcount') or 0) == playcount:
                    return
            except Exception:
                pass
        sql_params = {
            'post_id': self._norm(post_id),
            'season': self._norm(season),
            'episode': self._norm(episode),
            'watched': watched_val,
            'playcount': playcount,
            # Stamped on un-marking too. The hub reads this table
            # incrementally by this column to keep one shared history, and an
            # un-mark that left the stamp empty simply never travelled - the
            # title stayed "watched" everywhere else. Nothing reads the stamp as
            # proof of watching on its own; the `watched` flag decides that.
            'last_watched': self._now()
        }
        self._write('''INSERT OR REPLACE INTO watched_state
                     (post_id, season, episode, watched, playcount, last_watched)
                     VALUES (:post_id, :season, :episode, :watched, :playcount, :last_watched)''', sql_params)

    def increment_playcount(self, post_id, season=None, episode=None):
        state = self.get_watched_state(post_id, season, episode) or {}
        playcount = int(state.get('playcount') or 0) + 1
        self.set_watched_state(post_id, True, season=season, episode=episode, playcount=playcount)


    @staticmethod
    def make_catalog_cache_key(section, page='1', filters=''):
        return '{0}|{1}|{2}'.format(FilmixCache._norm(section), FilmixCache._norm(page) or '1', FilmixCache._norm(filters))

    def get_catalog_cache(self, section, page='1', filters='', max_age=None):
        cache_key = self.make_catalog_cache_key(section, page, filters)
        c = self.conn.cursor()
        c.execute('''SELECT details, checksum, updated_at, updated_ts
                     FROM catalog_cache
                     WHERE cache_key = :cache_key
                     LIMIT 1''', {'cache_key': cache_key})
        row = c.fetchone()
        if not row:
            return None
        if max_age is not None:
            try:
                age = self._ts() - int(row.get('updated_ts') or 0)
            except Exception:
                age = int(max_age) + 1
            if age > int(max_age):
                return None
        try:
            details = json.loads(row.get('details') or '[]')
        except Exception:
            return None
        return {'items': details,
                'checksum': row.get('checksum') or '',
                'updated_at': row.get('updated_at') or '',
                'updated_ts': int(row.get('updated_ts') or 0)}

    def get_any_catalog_cache(self, section, page='1', filters=''):
        return self.get_catalog_cache(section, page=page, filters=filters, max_age=None)

    def set_catalog_cache(self, section, page='1', filters='', items=None, checksum=''):
        cache_key = self.make_catalog_cache_key(section, page, filters)
        now = self._now()
        ts = self._ts()
        details = json.dumps(items or [], ensure_ascii=False)
        sql_params = {'cache_key': cache_key,
                      'section': self._norm(section),
                      'page': self._norm(page) or '1',
                      'filters': self._norm(filters),
                      'details': details,
                      'checksum': self._norm(checksum),
                      'updated_at': now,
                      'updated_ts': ts}
        self._write('''INSERT OR REPLACE INTO catalog_cache
                     (cache_key, section, page, filters, details, checksum, updated_at, updated_ts)
                     VALUES (:cache_key, :section, :page, :filters, :details, :checksum, :updated_at, :updated_ts)''', sql_params)

    def clear_catalog_cache(self, section=None):
        if section:
            self._write('DELETE FROM catalog_cache WHERE section = :section', {'section': self._norm(section)})
        else:
            self._write('DELETE FROM catalog_cache')


    def set_control_flag(self, key, value='1'):
        sql_params = {'flag_key': self._norm(key),
                      'flag_value': self._norm(value),
                      'updated_at': self._now(),
                      'updated_ts': self._ts()}
        self._write('''INSERT OR REPLACE INTO control_flags
                     (flag_key, flag_value, updated_at, updated_ts)
                     VALUES (:flag_key, :flag_value, :updated_at, :updated_ts)''', sql_params)

    def get_control_flag(self, key):
        c = self.conn.cursor()
        c.execute('SELECT flag_value, updated_at, updated_ts FROM control_flags WHERE flag_key = :flag_key LIMIT 1',
                  {'flag_key': self._norm(key)})
        return c.fetchone()

    def clear_control_flag(self, key):
        self._write('DELETE FROM control_flags WHERE flag_key = :flag_key', {'flag_key': self._norm(key)})

    def list_control_flags(self, prefix=''):
        c = self.conn.cursor()
        prefix = self._norm(prefix)
        if prefix:
            c.execute('''SELECT flag_key, flag_value, updated_at, updated_ts
                         FROM control_flags
                         WHERE flag_key LIKE :prefix
                         ORDER BY updated_ts DESC''', {'prefix': prefix + '%'})
        else:
            c.execute('''SELECT flag_key, flag_value, updated_at, updated_ts
                         FROM control_flags
                         ORDER BY updated_ts DESC''')
        return c.fetchall() or []

    # Durable background jobs -------------------------------------------------
    # control_flags remains for lightweight state/telemetry.  Work that must
    # survive concurrent producers and process crashes uses this queue with a
    # claim/lease/ack lifecycle.

    @staticmethod
    def _job_payload_dump(payload):
        if isinstance(payload, str):
            return payload
        try:
            return json.dumps(payload if payload is not None else {}, ensure_ascii=False,
                              sort_keys=True, separators=(',', ':'))
        except Exception:
            return '{}'

    @staticmethod
    def job_payload(row, default=None):
        if not isinstance(row, dict):
            return default
        value = row.get('payload')
        if isinstance(value, (dict, list)):
            return value
        try:
            return json.loads(value or '')
        except Exception:
            return default

    def enqueue_job(self, job_kind, identity, payload=None, due_ts=0, priority=0,
                    attempts=None):
        job_kind = self._norm(job_kind)
        identity = self._norm(identity)
        if not job_kind or not identity:
            return False
        now = self._ts()
        due_ts = max(0, int(due_ts or 0))
        priority = int(priority or 0)
        payload_text = self._job_payload_dump(payload)
        last_error = None
        for _ in range(2):
            c = self.conn.cursor()
            try:
                c.execute('BEGIN IMMEDIATE')
                c.execute('''SELECT state, due_ts, priority, attempts, requeue_requested
                             FROM jobs WHERE job_kind=:job_kind AND identity=:identity LIMIT 1''',
                          {'job_kind': job_kind, 'identity': identity})
                row = c.fetchone() or {}
                if row:
                    state = str(row.get('state') or 'queued')
                    current_due = int(row.get('due_ts') or 0)
                    effective_due = due_ts
                    if current_due > 0 and due_ts > 0:
                        effective_due = min(current_due, due_ts)
                    elif current_due > 0 and due_ts <= 0:
                        effective_due = 0
                    effective_attempts = int(row.get('attempts') or 0)
                    if attempts is not None:
                        effective_attempts = max(0, int(attempts or 0))
                    elif state == 'dead':
                        effective_attempts = 0
                    if state == 'leased':
                        # A producer requested the same identity while a worker
                        # owns it.  Keep the lease, but make ack put it back in
                        # the queue instead of deleting the new request.
                        c.execute('''UPDATE jobs SET payload=:payload, due_ts=:due_ts,
                                     priority=:priority, attempts=:attempts,
                                     requeue_requested=1, updated_ts=:updated_ts
                                     WHERE job_kind=:job_kind AND identity=:identity''', {
                                         'payload': payload_text,
                                         'due_ts': effective_due,
                                         'priority': max(priority, int(row.get('priority') or 0)),
                                         'attempts': effective_attempts,
                                         'updated_ts': now,
                                         'job_kind': job_kind,
                                         'identity': identity,
                                     })
                    else:
                        c.execute('''UPDATE jobs SET payload=:payload, state='queued',
                                     due_ts=:due_ts, priority=:priority, lease_owner='',
                                     lease_until=0, attempts=:attempts, last_error='',
                                     requeue_requested=0, updated_ts=:updated_ts
                                     WHERE job_kind=:job_kind AND identity=:identity''', {
                                         'payload': payload_text,
                                         'due_ts': effective_due,
                                         'priority': max(priority, int(row.get('priority') or 0)),
                                         'attempts': effective_attempts,
                                         'updated_ts': now,
                                         'job_kind': job_kind,
                                         'identity': identity,
                                     })
                else:
                    c.execute('''INSERT INTO jobs
                                 (job_kind, identity, payload, state, due_ts, priority,
                                  lease_owner, lease_until, attempts, last_error,
                                  requeue_requested, created_ts, updated_ts)
                                 VALUES (:job_kind, :identity, :payload, 'queued', :due_ts,
                                         :priority, '', 0, :attempts, '', 0, :created_ts,
                                         :updated_ts)''', {
                                             'job_kind': job_kind,
                                             'identity': identity,
                                             'payload': payload_text,
                                             'due_ts': due_ts,
                                             'priority': priority,
                                             'attempts': max(0, int(attempts or 0)),
                                             'created_ts': now,
                                             'updated_ts': now,
                                         })
                c.execute('COMMIT')
                return True
            except sqlite3.OperationalError as e:
                try:
                    c.execute('ROLLBACK')
                except Exception:
                    pass
                if 'locked' not in str(e).lower():
                    raise
                last_error = e
                time.sleep(0.10)
            except Exception:
                try:
                    c.execute('ROLLBACK')
                except Exception:
                    pass
                raise
        if last_error is not None:
            raise last_error
        return False

    def list_jobs(self, job_kind, states=None, limit=None):
        params = {'job_kind': self._norm(job_kind)}
        where = ['job_kind=:job_kind']
        if states:
            values = [self._norm(value) for value in states if self._norm(value)]
            if values:
                placeholders = []
                for index, value in enumerate(values):
                    key = 'state_{0}'.format(index)
                    params[key] = value
                    placeholders.append(':' + key)
                where.append('state IN ({0})'.format(','.join(placeholders)))
        query = '''SELECT job_kind, identity, payload, state, due_ts, priority,
                          lease_owner, lease_until, attempts, last_error,
                          requeue_requested, created_ts, updated_ts
                   FROM jobs WHERE {0}
                   ORDER BY priority DESC, due_ts ASC, updated_ts ASC'''.format(' AND '.join(where))
        if limit is not None:
            query += ' LIMIT {0}'.format(max(0, int(limit or 0)))
        c = self.conn.cursor()
        c.execute(query, params)
        return c.fetchall() or []

    def count_jobs(self, job_kind, states=None, due_only=False):
        params = {'job_kind': self._norm(job_kind)}
        where = ['job_kind=:job_kind']
        if states:
            values = [self._norm(value) for value in states if self._norm(value)]
            if values:
                placeholders = []
                for index, value in enumerate(values):
                    key = 'state_{0}'.format(index)
                    params[key] = value
                    placeholders.append(':' + key)
                where.append('state IN ({0})'.format(','.join(placeholders)))
        if due_only:
            params['now_ts'] = self._ts()
            where.append('due_ts <= :now_ts')
        c = self.conn.cursor()
        c.execute('SELECT COUNT(*) AS value FROM jobs WHERE ' + ' AND '.join(where), params)
        row = c.fetchone() or {}
        return int(row.get('value') or 0)

    def has_due_jobs(self, job_kind):
        return self.count_jobs(job_kind, states=('queued',), due_only=True) > 0

    def claim_jobs(self, job_kind, limit=1, lease_seconds=300, owner=''):
        job_kind = self._norm(job_kind)
        owner = self._norm(owner) or 'worker-{0}'.format(os.getpid())
        limit = max(1, int(limit or 1))
        now = self._ts()
        lease_until = now + max(5, int(lease_seconds or 300))
        last_error = None
        for _ in range(2):
            c = self.conn.cursor()
            try:
                c.execute('BEGIN IMMEDIATE')
                c.execute('''UPDATE jobs SET state='queued', lease_owner='', lease_until=0,
                             updated_ts=:now_ts
                             WHERE job_kind=:job_kind AND state='leased'
                               AND lease_until > 0 AND lease_until <= :now_ts''',
                          {'job_kind': job_kind, 'now_ts': now})
                c.execute('''SELECT identity FROM jobs
                             WHERE job_kind=:job_kind AND state='queued' AND due_ts <= :now_ts
                             ORDER BY priority DESC, due_ts ASC, updated_ts ASC
                             LIMIT {0}'''.format(limit),
                          {'job_kind': job_kind, 'now_ts': now})
                identities = [row.get('identity') for row in (c.fetchall() or []) if row.get('identity')]
                for identity in identities:
                    c.execute('''UPDATE jobs SET state='leased', lease_owner=:owner,
                                 lease_until=:lease_until, updated_ts=:now_ts
                                 WHERE job_kind=:job_kind AND identity=:identity
                                   AND state='queued' ''', {
                                       'owner': owner,
                                       'lease_until': lease_until,
                                       'now_ts': now,
                                       'job_kind': job_kind,
                                       'identity': identity,
                                   })
                rows = []
                if identities:
                    placeholders = ','.join(['?'] * len(identities))
                    c.execute('''SELECT job_kind, identity, payload, state, due_ts, priority,
                                        lease_owner, lease_until, attempts, last_error,
                                        requeue_requested, created_ts, updated_ts
                                 FROM jobs WHERE job_kind=? AND identity IN ({0})
                                 ORDER BY priority DESC, due_ts ASC, updated_ts ASC'''.format(placeholders),
                              [job_kind] + identities)
                    rows = c.fetchall() or []
                c.execute('COMMIT')
                return rows
            except sqlite3.OperationalError as e:
                try:
                    c.execute('ROLLBACK')
                except Exception:
                    pass
                if 'locked' not in str(e).lower():
                    raise
                last_error = e
                time.sleep(0.10)
            except Exception:
                try:
                    c.execute('ROLLBACK')
                except Exception:
                    pass
                raise
        if last_error is not None:
            raise last_error
        return []

    def ack_job(self, job_kind, identity, owner=''):
        params = {'job_kind': self._norm(job_kind), 'identity': self._norm(identity)}
        c = self.conn.cursor()
        c.execute('BEGIN IMMEDIATE')
        try:
            c.execute('''SELECT lease_owner, requeue_requested FROM jobs
                         WHERE job_kind=:job_kind AND identity=:identity LIMIT 1''', params)
            row = c.fetchone() or {}
            if not row:
                c.execute('COMMIT')
                return False
            if owner and self._norm(row.get('lease_owner')) != self._norm(owner):
                c.execute('COMMIT')
                return False
            if int(row.get('requeue_requested') or 0):
                c.execute('''UPDATE jobs SET state='queued', lease_owner='', lease_until=0,
                             requeue_requested=0, updated_ts=:updated_ts
                             WHERE job_kind=:job_kind AND identity=:identity''',
                          dict(params, updated_ts=self._ts()))
            else:
                c.execute('DELETE FROM jobs WHERE job_kind=:job_kind AND identity=:identity', params)
            c.execute('COMMIT')
            return True
        except Exception:
            try:
                c.execute('ROLLBACK')
            except Exception:
                pass
            raise

    def retry_job(self, job_kind, identity, delay_seconds=30, error='', owner='', increment=True):
        params = {
            'job_kind': self._norm(job_kind),
            'identity': self._norm(identity),
            'due_ts': self._ts() + max(0, int(delay_seconds or 0)),
            'last_error': str(error or '')[:500],
            'updated_ts': self._ts(),
            'increment': 1 if increment else 0,
            'owner': self._norm(owner),
        }
        owner_clause = ''
        if params['owner']:
            owner_clause = " AND lease_owner=:owner"
        c = self._write('''UPDATE jobs SET state='queued', due_ts=:due_ts,
                           lease_owner='', lease_until=0,
                           attempts=attempts+:increment, last_error=:last_error,
                           requeue_requested=0, updated_ts=:updated_ts
                           WHERE job_kind=:job_kind AND identity=:identity''' + owner_clause, params)
        return int(c.rowcount or 0) > 0

    def release_job(self, job_kind, identity, delay_seconds=0, owner=''):
        return self.retry_job(job_kind, identity, delay_seconds=delay_seconds,
                              error='', owner=owner, increment=False)

    def fail_job(self, job_kind, identity, error='', owner=''):
        params = {
            'job_kind': self._norm(job_kind),
            'identity': self._norm(identity),
            'last_error': str(error or '')[:500],
            'updated_ts': self._ts(),
            'owner': self._norm(owner),
        }
        owner_clause = ''
        if params['owner']:
            owner_clause = " AND lease_owner=:owner"
        c = self._write('''UPDATE jobs SET state='dead', lease_owner='', lease_until=0,
                           attempts=attempts+1, last_error=:last_error,
                           requeue_requested=0, updated_ts=:updated_ts
                           WHERE job_kind=:job_kind AND identity=:identity''' + owner_clause, params)
        return int(c.rowcount or 0) > 0

    def delete_job(self, job_kind, identity):
        c = self._write('DELETE FROM jobs WHERE job_kind=:job_kind AND identity=:identity',
                        {'job_kind': self._norm(job_kind), 'identity': self._norm(identity)})
        return int(c.rowcount or 0) > 0

    def prune_jobs(self, job_kind, max_count, states=('queued',)):
        max_count = max(0, int(max_count or 0))
        rows = self.list_jobs(job_kind, states=states)
        if len(rows) <= max_count:
            return 0
        removed = 0
        for row in rows[max_count:]:
            try:
                if self.delete_job(job_kind, row.get('identity')):
                    removed += 1
            except Exception:
                pass
        return removed

