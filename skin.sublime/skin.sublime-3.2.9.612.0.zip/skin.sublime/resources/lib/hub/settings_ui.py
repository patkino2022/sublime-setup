# -*- coding: utf-8 -*-
"""A settings screen for the hub, built from Kodi's own dialogs.

The values live in hub_config.json and until now could only be changed by
editing that file over SSH. A skin has no add-on settings page to inherit, and
adding one in skin XML means new windows, new control ids and a translation
pass for every field - so this screen is built from the dialogs Kodi already
has: one select list of «name: current value» rows, and the appropriate editor
for the row that was picked. It is reachable from the hub's own root listing and
from a skin button, works with a remote, and cannot desynchronise from the
defaults because the list below is the description of those same keys.

Where the materials live is the first group deliberately: it decides whether
the other boxes see this box's history at all.
"""
from __future__ import absolute_import, unicode_literals

import xbmc
import xbmcgui

from . import config, sync
from .config import log
from ..l10n import tr

# (key, label, kind, extra) - kind decides which dialog edits it. Labels are
# skin string ids (language/*/strings.po), resolved when shown, so the screen
# follows Kodi's language.
#   bool   : toggled in place
#   int    : numeric keyboard
#   float  : text keyboard, stored as typed ('' means "no floor")
#   text   : text keyboard
#   choice : select from extra, a tuple of (value, label)
FIELDS = (
    ('__group__', 31954, 'group', ()),
    ('state_location', 31955, 'choice',
     (('local', 31956),
      ('server', 31957),
      ('folder', 31958))),
    ('state_path', 31959, 'text', ()),
    ('sync_url', 31960, 'text', ()),
    ('sync_token', 31961, 'text', ()),
    ('sync_interval_minutes', 31962, 'int', ()),
    ('sync_timeout', 31963, 'int', ()),

    ('__group__', 31964, 'group', ()),
    ('auto_refresh', 31965, 'bool', ()),
    ('refresh_hours', 31966, 'int', ()),
    ('widget_size', 31967, 'int', ()),
    ('filter_lanes', 31968, 'bool', ()),

    ('__group__', 31969, 'group', ()),
    ('exclude_watched', 31970, 'bool', ()),
    ('prefer_acclaimed', 31971, 'bool', ()),
    ('diversity', 31972, 'bool', ()),
    ('fresh_percent', 31973, 'int', ()),
    ('min_rating', 31974, 'float', ()),
    ('min_year', 31975, 'int', ()),
    ('preferred_genres', 31976, 'text', ()),
    ('blocked_genres', 31977, 'text', ()),
    ('excluded_countries', 31978, 'text', ()),

    ('__group__', 31979, 'group', ()),
    ('video_addon_id', 31980, 'text', ()),
    ('movies_catalog_path', 31981, 'text', ()),
    ('shows_catalog_path', 31982, 'text', ()),
    ('candidate_pages', 31983, 'int', ()),
)

def _location_labels():
    """The location field's own labels, reused when reporting what was chosen."""
    return dict((value, tr(label)) for value, label in FIELDS[1][3])


def _shown(key, value):
    """What the row shows on the right - never a raw empty string."""
    if key == 'state_location':
        return _location_labels().get(str(value), str(value))
    if isinstance(value, bool):
        return tr(31984) if value else tr(31985)
    text = '' if value is None else str(value)
    if key == 'sync_token' and text:
        return '••••••'
    return text or tr(31986)


def _relevant(key, values):
    """Hide what the chosen location makes meaningless.

    A box set to «only here» has no server address to type, and one pointed at
    a share has no token - showing those anyway is how a setting gets filled in
    and then quietly ignored.
    """
    location = str(values.get('state_location') or 'local')
    if key in ('sync_url', 'sync_token', 'sync_interval_minutes', 'sync_timeout'):
        return location == 'server'
    if key == 'state_path':
        return location == 'folder'
    return True


def _ask(label, current):
    """Ask for text and say whether the user confirmed it.

    xbmc.Keyboard is used rather than Dialog().input() precisely because it has
    isConfirmed(): with the dialog, backing out of the prompt is indistinguish-
    able from clearing the field, and that difference is the difference between
    «I changed my mind» and «this box no longer has a sync token».
    """
    keyboard = xbmc.Keyboard(str(current if current is not None else ''), label)
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return False, ''
    return True, keyboard.getText() or ''


def _edit(key, label, kind, extra, current):
    """Ask for one new value. Returns (changed, value)."""
    dialog = xbmcgui.Dialog()
    if kind == 'bool':
        return True, (not bool(current))
    if kind == 'choice':
        values = [v for v, _l in extra]
        labels = [tr(l) for _v, l in extra]
        try:
            preselect = values.index(str(current))
        except ValueError:
            preselect = -1
        picked = dialog.select(label, labels, preselect=preselect)
        if picked < 0:
            return False, current
        return True, values[picked]
    # Dialog().input() and Dialog().numeric() both return an empty string when
    # the user backs out, so they cannot tell «cancel» from «clear». Measured
    # live: cancelling the token prompt wrote an empty token and this box
    # stopped syncing. xbmc.Keyboard says which of the two happened.
    confirmed, typed = _ask(label, current)
    if not confirmed:
        return False, current
    typed = typed.strip()
    if kind == 'int':
        if not typed:
            # Cleared on purpose is a real answer for a floor: keep it empty
            # rather than turning it into a zero that filters nothing.
            return True, ''
        try:
            return True, int(typed)
        except (TypeError, ValueError):
            dialog.notification(tr(31934), tr(31987),
                                xbmcgui.NOTIFICATION_WARNING, 2500)
            return False, current
    if kind == 'float' and typed:
        candidate = typed.replace(',', '.')
        try:
            float(candidate)
        except ValueError:
            dialog.notification(tr(31934), tr(31988),
                                xbmcgui.NOTIFICATION_WARNING, 2500)
            return False, current
        return True, candidate
    return True, typed


def _rows(values):
    """The select list: group headers, then one line per visible field."""
    rows = []
    for key, label, kind, extra in FIELDS:
        if kind == 'group':
            rows.append((None, '[COLOR grey]— %s —[/COLOR]' % tr(label), None, None))
            continue
        if not _relevant(key, values):
            continue
        if sync.settings_locked(key):
            # клиент сервера просмотров: значение приходит с сервера, здесь только показ
            rows.append((key, '[COLOR grey]%s: %s (%s)[/COLOR]'
                         % (tr(label), _shown(key, values.get(key)), tr(31991)), 'locked', extra))
            continue
        rows.append((key, '%s: [COLOR blue]%s[/COLOR]'
                     % (tr(label), _shown(key, values.get(key))), kind, extra))
    return rows


def open_screen():
    """The screen itself: pick a row, edit it, see the new value, repeat."""
    dialog = xbmcgui.Dialog()
    while True:
        values = config.values()
        rows = _rows(values)
        picked = dialog.select(tr(31915), [row[1] for row in rows])
        if picked < 0:
            return True
        key, _shown_label, kind, extra = rows[picked]
        if key is None:
            continue  # a group header is not editable
        if kind == 'locked':
            dialog.notification(tr(31934), tr(31992), xbmcgui.NOTIFICATION_INFO, 3000)
            continue
        label = tr(dict((f[0], f[1]) for f in FIELDS if f[0] != '__group__')[key])
        changed, value = _edit(key, label, kind, extra, values.get(key))
        if not changed:
            continue
        config.set_value(key, value)
        log('настройка %s = %r' % (key, value))
        if key == 'state_location':
            # The old switch still means «server» on its own, so choosing a
            # location has to move it too - otherwise picking «only here» on a
            # box that once synced would silently keep syncing.
            config.set_value('sync_enabled', value == 'server')
            # The location decides where everything is read from, so say what
            # this box will actually do rather than leaving it to be discovered.
            try:
                where = sync.location()
            except Exception:
                where = str(value)
            dialog.notification(tr(31934), tr(31989)
                                % _location_labels().get(where, where),
                                xbmcgui.NOTIFICATION_INFO, 3000)


def route(handle, params):
    """Plugin route wrapper - the screen is modal, so nothing is listed."""
    try:
        return open_screen()
    except Exception as exc:
        log('экран настроек упал: %s' % exc, xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(tr(31934), tr(31990),
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return True
