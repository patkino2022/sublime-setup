# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import hashlib
import json
import os
import shutil
import threading
import time
import tempfile
from collections import OrderedDict

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

_LOCK = threading.RLock()
_MEMORY = OrderedDict()
_MEMORY_LIMIT = 128
_MAX_DISK_BYTES = 64 * 1024 * 1024
_MAX_DISK_AGE = 45 * 86400
_PRUNE_INTERVAL = 6 * 3600
_LAST_PRUNE = 0.0


# Каталоги кешей, которые скин больше не пишет и не читает. Измерено на .30
# 2026-08-29: desaturate_v2 - 66 МБ, последняя запись 14 июня; 
# poster_backgrounds_v1 - 45 МБ, 15 июня (его заменил fallback_backgrounds_v2);
# pvr_popup_runtime - 14 МБ, 18 июня. Возрастная чистка их не трогает, потому
# что чистит каждый кеш изнутри, а эти никто не открывает.
_RETIRED_DIRS = ('desaturate_v2', 'poster_backgrounds_v1', 'pvr_popup_runtime',
                 'nodes_pre_ai_sync_2026-08-14_backup',
                 # логотипы названий первой версии: с перехода на title_logos_v2 их никто не пишет,
                 # а хранилище строк отбрасывает (row_store.py), 80-104 МБ на коробке (23.11.2026)
                 'title_logos_v1')
_PROFILE_URI = 'special://profile/addon_data/skin.sublime/'
_RETIRED_MARK = 'retired_caches_swept.txt'


def sweep_retired():
    """Удалить кеши прошлых версий скина. Один раз на коробку.

    Возвращает, сколько мегабайт освободилось.
    """
    root = translate(_PROFILE_URI)
    if not root or not os.path.isdir(root):
        return 0
    mark = os.path.join(root, _RETIRED_MARK)
    # повторить, когда список пополнился: раньше отметка ставилась раз навсегда, и новый пункт
    # списка на коробке уже не убирался
    try:
        with open(mark, encoding='utf-8') as handle:
            if handle.read().strip() == ','.join(_RETIRED_DIRS):
                return 0
    except OSError:
        pass
    freed = 0
    for name in _RETIRED_DIRS:
        path = os.path.join(root, name)
        if not os.path.isdir(path):
            continue
        for base, _dirs, files in os.walk(path):
            for filename in files:
                try:
                    freed += os.path.getsize(os.path.join(base, filename))
                except OSError:
                    pass
        try:
            shutil.rmtree(path, ignore_errors=True)
        except Exception:
            pass
    try:
        with open(mark, 'w', encoding='utf-8') as handle:
            handle.write(','.join(_RETIRED_DIRS))
    except Exception:
        pass
    return int(freed / 1048576)


def translate(path):
    try:
        return xbmcvfs.translatePath(path) if xbmcvfs else path
    except Exception:
        return path


CACHE_ROOT = translate('special://profile/addon_data/skin.sublime/metadata_cache')


def _path(key):
    digest = hashlib.sha1(str(key).encode('utf-8', 'ignore')).hexdigest()
    return os.path.join(CACHE_ROOT, digest[:2], digest + '.json')


def _memory_set(key, saved, data):
    _MEMORY.pop(key, None)
    _MEMORY[key] = (saved, data)
    while len(_MEMORY) > _MEMORY_LIMIT:
        _MEMORY.popitem(last=False)


def _prune(force=False):
    global _LAST_PRUNE
    now = time.time()
    if not force and now - _LAST_PRUNE < _PRUNE_INTERVAL:
        return
    _LAST_PRUNE = now
    try:
        if not os.path.isdir(CACHE_ROOT):
            return
        entries = []
        total = 0
        for base, _, files in os.walk(CACHE_ROOT):
            for filename in files:
                path = os.path.join(base, filename)
                try:
                    stat = os.stat(path)
                except OSError:
                    continue
                if filename.endswith('.tmp') or now - stat.st_mtime > _MAX_DISK_AGE:
                    try:
                        os.remove(path)
                    except OSError:
                        pass
                    continue
                if filename.endswith('.json'):
                    entries.append((stat.st_mtime, stat.st_size, path))
                    total += stat.st_size
        if total > _MAX_DISK_BYTES:
            for _, size, path in sorted(entries):
                try:
                    os.remove(path)
                    total -= size
                except OSError:
                    pass
                if total <= _MAX_DISK_BYTES:
                    break
    except Exception:
        pass


def get(key, max_age):
    now = time.time()
    with _LOCK:
        cached = _MEMORY.get(key)
        if cached:
            saved, data = cached
            if max_age is None or now - saved <= max_age:
                _MEMORY.move_to_end(key)
                return data
            _MEMORY.pop(key, None)
    path = _path(key)
    try:
        if not os.path.exists(path):
            return None
        if max_age is not None and now - os.path.getmtime(path) > max_age:
            # просроченная запись остаётся на диске (размер держит _prune): её отдаёт get_json,
            # когда поставщик отказал - норма кончилась или сеть легла (api._stale, 22.11.2026)
            return None
        with _LOCK:
            with open(path, 'r', encoding='utf-8') as fh:
                payload = json.load(fh)
            saved = float(payload.get('saved') or os.path.getmtime(path))
            if max_age is not None and now - saved > max_age:
                return None
            data = payload.get('data')
            _memory_set(key, saved, data)
        return data
    except Exception:
        return None


# Сколько человек из состава имеет смысл хранить. Экран показывает единицы;
# TMDb отдаёт для сериала весь состав всех серий, и на .20 самая большая
# запись кеша занимала 1391 КБ, из них 1353 КБ - aggregate_credits. Кеш при
# этом стоял ровно на своём пределе в 64 МБ (3171 запись, 64 МБ), то есть
# каждая новая запись вытесняла старую, и вытесненное приходилось выкачивать
# заново.
_MAX_CAST = 30
_MAX_CREW = 30


def _slim(data):
    """Убрать из ответа то, что заведомо не поместится на экран.

    Трогаются только списки людей и только их длина: состав, съёмочная группа.
    Всё остальное сохраняется как пришло.
    """
    if not isinstance(data, dict):
        return data
    trimmed = None
    for name in ('credits', 'aggregate_credits'):
        block = data.get(name)
        if not isinstance(block, dict):
            continue
        for field, limit in (('cast', _MAX_CAST), ('crew', _MAX_CREW)):
            people = block.get(field)
            if isinstance(people, list) and len(people) > limit:
                if trimmed is None:
                    trimmed = dict(data)
                block_copy = dict(trimmed.get(name) or {})
                block_copy[field] = people[:limit]
                trimmed[name] = block_copy
    return trimmed if trimmed is not None else data


def set(key, data):
    path = _path(key)
    tmp = ''
    now = time.time()
    try:
        folder = os.path.dirname(path)
        os.makedirs(folder, exist_ok=True)
        data = _slim(data)
        payload = {'saved': int(now), 'data': data}
        fd, tmp = tempfile.mkstemp(prefix=os.path.basename(path) + '.', suffix='.tmp', dir=folder)
        with os.fdopen(fd, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'))
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                pass
        with _LOCK:
            os.replace(tmp, path)
            tmp = ''
            _memory_set(key, now, data)
        _prune()
        return True
    except Exception:
        try:
            if tmp and os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return False


def delete(key):
    """Atomically remove one cached value from memory and disk."""
    if not key:
        return False
    path = _path(key)
    with _LOCK:
        _MEMORY.pop(key, None)
        try:
            if os.path.isfile(path):
                os.remove(path)
            return True
        except OSError:
            return False


def clear():
    removed = 0
    with _LOCK:
        _MEMORY.clear()
    try:
        if not os.path.isdir(CACHE_ROOT):
            return 0
        for root, _, files in os.walk(CACHE_ROOT, topdown=False):
            for filename in files:
                try:
                    os.remove(os.path.join(root, filename))
                    removed += 1
                except Exception:
                    pass
            try:
                if root != CACHE_ROOT:
                    os.rmdir(root)
            except Exception:
                pass
    except Exception:
        pass
    return removed


def _trailer_failure_key(url):
    value = str(url or '').strip()
    if not value:
        return ''
    digest = hashlib.sha1(value.encode('utf-8', 'ignore')).hexdigest()
    return 'trailer-failed-v1:%s' % digest


_TRAILER_FAILURE_TTLS = {
    # Only reasons observable from the Kodi Player lifecycle are retained.
    'playback_timeout': 5 * 60,
    'playback_error': 15 * 60,
}
_TRAILER_FAILURE_DEFAULT_TTL = 15 * 60


def _trailer_failure_ttl(reason):
    return _TRAILER_FAILURE_TTLS.get(str(reason or '').strip().lower(), _TRAILER_FAILURE_DEFAULT_TTL)


def trailer_failure(url):
    """Return an unexpired failure row, expiring it by its recorded reason."""
    key = _trailer_failure_key(url)
    if not key:
        return None
    row = get(key, None)
    if not isinstance(row, dict):
        if row is not None:
            delete(key)
        return None
    return get(key, _trailer_failure_ttl(row.get('reason')))


def is_trailer_failed(url, max_age=None):
    key = _trailer_failure_key(url)
    if not key:
        return False
    if max_age is not None:
        return get(key, max_age) is not None
    return trailer_failure(url) is not None


def mark_trailer_failed(url, reason=''):
    key = _trailer_failure_key(url)
    if not key:
        return False
    reason = str(reason or '').strip().lower()
    previous = get(key, None)
    attempts = int((previous or {}).get('attempts') or 0) + 1 if isinstance(previous, dict) else 1
    return set(key, {
        'reason': reason,
        'url': str(url or ''),
        'attempts': attempts,
    })


def clear_trailer_failure(url):
    return delete(_trailer_failure_key(url))
