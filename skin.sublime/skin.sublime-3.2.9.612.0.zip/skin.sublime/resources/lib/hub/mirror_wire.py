# -*- coding: utf-8 -*-
"""Point the expensive widgets on Home at the mirror, and back again.

The widget rows are built by the shortcuts generator, not by us, so this edits
what it produced: a `<param name="content">` naming another add-on's directory
becomes the same directory behind our own route,

    plugin://skin.sublime/?info=hub_mirror&src=<the original path>

The original path travels inside the replacement, so undoing this is exact -
there is nothing to remember and nothing to lose if the setting is turned off
again, or if the generator rewrites the file from scratch.

Why, with numbers measured on <коробка>, three passes each:

    YouTube «Подписки»    5.99 s -> 0.64 s (51 rows)
    Filmix «Избранное»    2.57 s -> 1.50 s (12 rows)
    Filmix «Отложенные»   1.23 s -> 0.46 s (12 rows)

Only other add-ons' directories are touched. Our own routes are already the
cheap ones (0.5-0.9 s), PVR channel lists are Kodi's own, and a path the skin
fills in at runtime is not a widget at all.
"""
from __future__ import absolute_import, unicode_literals

import os
import re
from urllib.parse import quote

import xbmc
import xbmcvfs

from . import mirror
from .config import get_str, log

FOLDERS = ('special://home/addons/skin.sublime/1080i',
           'special://profile/addon_data/skin.sublime/generated_includes')
FILE_PREFIX = 'vclvariables-generator-includes-'
CONTENT_PARAM = re.compile(
    r'(<param\s+name="content">)\s*([^<]+?)\s*(</param>)', re.IGNORECASE)
MIRROR_PREFIX = 'plugin://skin.sublime/?info=hub_mirror&src='
SETTING = 'mirror_widgets'

# Add-ons whose directories are worth mirroring. Ours are already cheap, and a
# PVR or favourites node is Kodi's own work, not an add-on's.
SKIP_PREFIXES = ('plugin://skin.sublime', 'pvr://', 'favourites://',
                 'library://', 'videodb://')
PLACEHOLDER_MARKS = ('$PARAM', '$INFO', '$VAR', '$EXP', ',]', ',return)',
                     'search?keyword=,', 'search/?q=,', 'notvalid')


def _files():
    found = []
    for folder in FOLDERS:
        base = xbmcvfs.translatePath(folder)
        try:
            names = sorted(os.listdir(base))
        except Exception:
            continue
        for name in names:
            if name.startswith(FILE_PREFIX) and name.endswith('.xml'):
                found.append(os.path.join(base, name))
    return found


def _allowed_addons():
    """Список дополнений или ('*',) - «все каталоги».

    По умолчанию теперь «все»: зеркало имеет смысл для любого каталожного
    виджета, а не только для YouTube. Ограничение осталось настройкой на случай,
    если какое-то одно дополнение поведёт себя странно.
    """
    raw = get_str('mirror_addons', '*') or ''
    # На боксах в файле настроек может лежать прежнее умолчание, записанное до
    # этой правки. Настройка нигде не показывается, выставить её можно было
    # только правкой файла, поэтому ровно прежнее умолчание считается «не
    # выбирал» - иначе «все каталоги» не включились бы там, где это нужнее всего.
    if raw.strip() == 'plugin.video.youtube':
        raw = '*'
    return tuple(part.strip() for part in raw.split(',') if part.strip())


def _mirrorable(path):
    text = str(path or '').strip()
    if not text.startswith('plugin://'):
        return False
    if text.startswith(SKIP_PREFIXES):
        return False
    if any(mark in text for mark in PLACEHOLDER_MARKS):
        return False
    # Природа списка решает раньше настройки: снимок «избранного» или телегида
    # вреден в любом случае (hub/mirror.py, category).
    if mirror.category(text) != 'каталог':
        return False
    allowed = _allowed_addons()
    # Пустая строка в настройке по-прежнему значит «ничего», а не «всё»: первый
    # заход взял все дополнения разом и сломал виджет. Сломал он его, впрочем, не
    # широтой охвата, а тем, что считал служебной любую папку - это исправлено и
    # закрыто проверками в tools/test_mirror.py. Поэтому «все каталоги» теперь
    # пишется явной звёздочкой.
    if '*' in allowed or 'all' in allowed:
        return True
    return any(('plugin://%s' % name) in text for name in allowed)


def _wrap(path):
    return MIRROR_PREFIX + quote(path.replace('&amp;', '&'), safe='')


def _unwrap(path):
    from urllib.parse import unquote
    return unquote(path[len(MIRROR_PREFIX):])


def _rewrite(text, enabled):
    """Returns (new text, how many rows changed)."""
    changed = [0]

    def swap(match):
        head, value, tail = match.group(1), match.group(2), match.group(3)
        # The file keeps ampersands as entities, so every comparison is made on
        # the plain form. Missing this meant a wired widget could not be
        # unwired: the check for our own prefix never matched and turning the
        # setting off changed nothing.
        plain = value.strip().replace('&amp;', '&')
        already = plain.startswith(MIRROR_PREFIX)
        if enabled:
            if already or not _mirrorable(plain):
                return match.group(0)
            changed[0] += 1
            return head + _wrap(plain).replace('&', '&amp;') + tail
        if not already:
            return match.group(0)
        changed[0] += 1
        return head + _unwrap(plain).replace('&', '&amp;') + tail

    return CONTENT_PARAM.sub(swap, text), changed[0]


def apply(enabled=True):
    """Point the widgets at the mirror (or back). Returns rows changed."""
    total = 0
    files = _files()
    if not files:
        log('зеркало виджетов: файлов включений не найдено', xbmc.LOGWARNING)
    for path in files:
        try:
            with open(path, 'r', encoding='utf-8', errors='replace') as handle:
                text = handle.read()
        except Exception as exc:
            log('зеркало виджетов: %s не прочитан: %s' % (os.path.basename(path), exc),
                xbmc.LOGWARNING)
            continue
        new_text, changed = _rewrite(text, enabled)
        if not changed or new_text == text:
            log('зеркало виджетов: %s без изменений (%d символов)'
                % (os.path.basename(path), len(text)), xbmc.LOGDEBUG)
            continue
        try:
            with open(path, 'w', encoding='utf-8', newline='') as handle:
                handle.write(new_text)
        except Exception as exc:
            log('зеркало виджетов: %s не записан: %s' % (os.path.basename(path), exc),
                xbmc.LOGWARNING)
            continue
        total += changed
        log('зеркало виджетов: %s, строк изменено %d' % (os.path.basename(path), changed))
    return total


def sources():
    """Every original path currently served through the mirror."""
    found = []
    for path in _files():
        try:
            with open(path, 'r', encoding='utf-8', errors='replace') as handle:
                text = handle.read()
        except Exception:
            continue
        for _head, value, _tail in CONTENT_PARAM.findall(text):
            raw = value.strip().replace('&amp;', '&')
            if raw.startswith(MIRROR_PREFIX):
                src = _unwrap(raw)
                if src and src not in found:
                    found.append(src)
    return found


