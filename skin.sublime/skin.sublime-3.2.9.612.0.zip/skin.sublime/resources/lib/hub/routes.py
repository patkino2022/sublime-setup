# -*- coding: utf-8 -*-
"""The hub's directory routes, served by the skin's own plugin.

These used to be plugin.video.watchhub's default.py. The lists are the same and
so is the code that builds them; what changed is that the watched markers come
from Kodi (history.py) and the marking actions write there too, so a tick drawn
here and the resume the player offers are the same fact.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import re
from urllib.parse import quote, unquote

import xbmc
import xbmcgui
import xbmcplugin

from . import catalog, history, identity, lanes, mirror, recommend, sync
from ..l10n import tr
from .config import get_int, log
from .store import db
from .youtube_text import clean_row

ROOT = 'plugin://skin.sublime/'
HANDLED = frozenset({'hub_lane', 'hub_widget', 'hub_continue', 'hub_smart', 'hub_feedback',
                     'hub_mark_watched', 'hub_mark_unwatched', 'hub_why',
                     'hub_rebuild', 'hub_sync_now', 'hub_root',
                     'hub_import_history', 'hub_mirror', 'hub_subs',
                     'hub_trending', 'hub_ytlane', 'hub_ytsearch', 'hub_search'})


def _max_age():
    return max(3600, get_int('refresh_hours', 12) * 3600)


def _url(info, **params):
    parts = ['info=%s' % info]
    for key, value in params.items():
        parts.append('%s=%s' % (key, quote(str(value or ''))))
    return ROOT + '?' + '&'.join(parts)


# ---- what the skin needs published on every row -----------------------

def _publish_identity_hints(li, row):
    """Give the skin's metadata pipeline the same hints the provider gives.

    A row carrying only a title and a year makes the pipeline search TMDB blind
    and then verify the result; the provider's rows instead carry the source
    year and its own post id, and the identity gate reads exactly those names.
    A source COUNTRY is deliberately not published: the gate treats it as a hard
    veto, and a row that declares one and then resolves to an entry without one
    is rejected outright - leaving the previous row's art on screen.
    """
    year = str(row.get('year') or '').strip()
    if year:
        for name in ('Year', 'year', 'SourceYear', 'FilmixSourceYear'):
            li.setProperty(name, year)
    post_id = str(row.get('post_id') or '').strip()
    if post_id:
        li.setProperty('FilmixPostID', post_id)
    mediatype = str(row.get('mediatype') or '').strip()
    if mediatype:
        li.setProperty('dbtype', mediatype)
        li.setProperty('DBTYPE', mediatype)


def _watch_state(rows):
    """Everything the listing needs to draw ticks and progress bars.

    Read once for the whole listing from Kodi, not per row.
    """
    state = {'playcounts': history.playcounts(),
             'progress': history.progress_map(),
             'episodes': history.watched_episode_counts(),
             'started': history.started_shows(),
             'totals': {},
             'provider': {}}
    # Сериалы провайдера считает сам провайдер - тем же кодом, что его
    # «Избранное» (catalog.provider_show_states). Своим счётом остаются только
    # чужие строки.
    prefix = 'plugin://%s/' % catalog.video_addon()
    own = [str(row['post_id']) for row in rows
           if row.get('post_id') and row.get('mediatype') == 'tvshow'
           and str(row.get('file') or '').startswith(prefix)]
    if own:
        state['provider'] = catalog.provider_show_states(own) or {}
    # Число серий нужно каждому НАЧАТОМУ сериалу, а не только тому, где есть
    # просмотренная серия. 16.10.2026 «Война» после снятия ложной отметки
    # осталась с нулём просмотренных и одной начатой серией - и в полосе хаба
    # пропал всякий маркер. Не начатым счётчик не нужен вовсе (владелец).
    if not state['started']:
        return state
    need = []
    for row in rows:
        key = identity.show_key(row.get('label'), row.get('year'))
        if (key and key in state['started'] and row.get('post_id')
                and str(row['post_id']) not in state['provider']):
            need.append(str(row['post_id']))
    if need:
        try:
            state['totals'] = catalog.episode_totals(need)
        except Exception as exc:
            log('подсчёт эпизодов пропущен: %s' % exc, xbmc.LOGWARNING)
    # Число серий у источника есть только в кэше Filmix. С источником HDRezka или Elementum
    # и после переустановки (кэш пуст) у начатых сериалов не было счётчика ни в одной
    # вкладке (.20, 17.11.2026). Запас - вышедшие серии по TMDb, по ключу сериала.
    try:
        state['totals_by_key'] = _show_totals(
            [row for row in rows
             if identity.show_key(row.get('label'), row.get('year')) in state['started']
             and not state['totals'].get(str(row.get('post_id') or ''))
             and str(row.get('post_id') or '') not in state['provider']])
    except Exception as exc:
        log('число серий по TMDb не получено: %s' % exc, xbmc.LOGDEBUG)
    return state


SHOW_TOTALS = 'special://profile/addon_data/skin.sublime/show_totals.json'


def _aired_episodes(meta):
    """Вышедшие серии без спецвыпусков: сезоны до последнего вышедшего - целиком, в нём -
    до последней вышедшей серии. Анонсированные серии не считаются непросмотренными."""
    seasons = [s for s in (meta.get('seasons') or []) if isinstance(s, dict)
               and int(s.get('season_number') or 0) > 0]
    last = meta.get('last_aired') or {}
    last_season = int(last.get('season_number') or 0) if isinstance(last, dict) else 0
    last_episode = int(last.get('episode_number') or 0) if isinstance(last, dict) else 0
    if last_season and last_episode:
        return sum(int(s.get('episode_count') or 0) for s in seasons
                   if int(s.get('season_number') or 0) < last_season) + last_episode
    return int(meta.get('number_of_episodes') or 0)


SHOW_TOTALS_TTL = 3600            # сериал в эфире: новая серия видна в течение часа
SHOW_TOTALS_ENDED_TTL = 86400     # завершён или закрыт


def _tv_now(tmdb_id):
    """Свежий ответ TMDb по сериалу (не 14-дневный кэш сведений): вышедшие серии и
    завершён ли сериал."""
    from ..sublime_helper.api import TMDb
    data = TMDb().request('/tv/%s' % tmdb_id, ttl=SHOW_TOTALS_TTL) or {}
    meta = {'seasons': data.get('seasons') or [],
            'last_aired': data.get('last_episode_to_air') or {},
            'number_of_episodes': data.get('number_of_episodes') or 0}
    ended = str(data.get('status') or '') in ('Ended', 'Canceled')
    return _aired_episodes(meta), ended


def _show_totals(rows, budget=6.0):
    """{ключ сериала: вышедших серий} - для сериалов не из Filmix (HDRezka, Elementum).
    Сериал в эфире перепроверяется раз в час, завершённый - раз в сутки (Filmix - тем же
    правилом в своём кэше), без открытия сериала."""
    import time as _time
    import xbmcvfs
    if not rows:
        return {}
    path = xbmcvfs.translatePath(SHOW_TOTALS)
    try:
        with open(path, encoding='utf-8') as fh:
            cache = json.load(fh)
    except Exception:
        cache = {}
    out, changed, started = {}, False, _time.time()
    for row in rows:
        key = identity.show_key(row.get('label'), row.get('year'))
        if not key or key in out:
            continue
        hit = cache.get(key) or {}
        ttl = SHOW_TOTALS_ENDED_TTL if hit.get('ended') else SHOW_TOTALS_TTL
        if hit and _time.time() - float(hit.get('t') or 0) < ttl:
            if hit.get('n'):
                out[key] = int(hit['n'])
            continue
        if _time.time() - started > budget:
            if hit.get('n'):
                out[key] = int(hit['n'])     # пока прежнее число, перепроверка в следующий раз
            continue
        total, ended, tmdb_id = 0, False, hit.get('tmdb') or ''
        try:
            if not tmdb_id:
                from . import builder
                from ..sublime_helper.core import fetch_online_metadata
                probe = dict(row, filetype='file', mediatype='tvshow')
                local = builder._local_from_row(probe)
                local['media_type'] = local['dbtype'] = 'tvshow'
                meta = fetch_online_metadata({}, local) or {}
                tmdb_id = str(meta.get('tmdb_id') or '')
                total = _aired_episodes(meta)
            if tmdb_id:
                fresh, ended = _tv_now(tmdb_id)
                total = fresh or total
        except Exception as exc:
            log('число серий %s: %s' % (key, exc), xbmc.LOGDEBUG)
        if not total and hit.get('n'):
            total = int(hit['n'])            # сеть не ответила - не обнулять
        cache[key] = {'n': total, 't': int(_time.time()), 'ended': ended, 'tmdb': tmdb_id}
        changed = True
        if total:
            out[key] = total
    if changed:
        try:
            with open(path + '.tmp', 'w', encoding='utf-8') as fh:
                json.dump(cache, fh, ensure_ascii=False)
            os.replace(path + '.tmp', path)
        except Exception as exc:
            log('число серий не записано: %s' % exc, xbmc.LOGDEBUG)
    return out


def _publish_watch_state(li, tag, row, state):
    """Publish watched / resume / episodes-seen in the names the skin reads:
    ListItem.PercentPlayed with IsResumable, Property(WatchedProgress),
    Playcount, and Property(WatchedEpisodePercent) for the series ring."""
    key = identity.show_key(row.get('label'), row.get('year'))
    if not key:
        return
    own = state['provider'].get(str(row.get('post_id') or ''))
    if own is not None:
        _publish_provider_show(li, tag, own, key in state.get('started', ()))
    else:
        _publish_counted_state(li, tag, key, row, state)
    _publish_resume(li, tag, key, state)


def _publish_provider_show(li, tag, own, started):
    """Сериал провайдера: ровно те свойства, что ставит его «Избранное»
    (navigation._apply_local_state, ветка tvshow), из его же счёта."""
    if own.get('counted'):
        total, watched = int(own['total']), int(own['watched'])
        if watched or started:
            li.setProperty('SeriesStarted', 'true')
        # Набор свойств счёта (всего / просмотрено / осталось / процент для
        # кольца) собирает провайдер - watch_stats.count_properties, тот же,
        # что он ставит в «Избранном». 21.10.2026 кольцо было только здесь, а
        # в «Избранном» нет. Свой расчёт - лишь для провайдера без этого ключа.
        properties = own.get('properties')
        if not isinstance(properties, dict):
            properties = {'TotalEpisodes': str(total), 'WatchedEpisodes': str(watched),
                          'UnWatchedEpisodes': str(own['unwatched']), 'NumEpisodes': str(total)}
            if total:
                properties['WatchedEpisodePercent'] = str(
                    min(100, int(round(100.0 * watched / total))))
        for name, value in properties.items():
            li.setProperty(name, str(value))
    # 0 тоже задаётся: не заданный Kodi берёт из своей записи по пути.
    playcount = int(own.get('playcount') or 0)
    try:
        tag.setPlaycount(playcount)
    except Exception:
        pass
    li.setProperty('playcount', str(playcount))


def _publish_counted_state(li, tag, key, row, state):
    """Строки не провайдера: счёт по базе Kodi."""
    playcount = int(state['playcounts'].get(key) or 0)
    watched_eps = int(state['episodes'].get(key) or 0)
    total_eps = int(state['totals'].get(str(row.get('post_id') or '')) or 0)         or int((state.get('totals_by_key') or {}).get(key) or 0)
    started = key in state.get('started', ())
    if started:
        # По нему скин и решает, рисовать ли счётчик (Filmix публикует то же
        # свойство: navigation._series_started).
        li.setProperty('SeriesStarted', 'true')
    if started and total_eps and not watched_eps:
        # Начат, но ни одной досмотренной: всего, просмотрено 0, непросмотрено
        # = всего - те же свойства, что публикует Filmix.
        li.setProperty('WatchedEpisodes', '0')
        li.setProperty('TotalEpisodes', str(total_eps))
        li.setProperty('UnWatchedEpisodes', str(total_eps))
    if watched_eps:
        li.setProperty('WatchedEpisodes', str(watched_eps))
        li.setProperty('TotalEpisodes', str(total_eps or watched_eps))
        li.setProperty('UnWatchedEpisodes', str(max(0, total_eps - watched_eps)))
        if total_eps:
            percent = min(100, int(round(100.0 * watched_eps / total_eps)))
            li.setProperty('WatchedEpisodePercent', str(percent))
            if watched_eps >= total_eps and not playcount:
                # Все серии просмотрены - значит сериал просмотрен. Правило не
                # наше: ровно так решает провайдер (navigation.py,
                # _apply_local_state: playcount = 1 if total and not unwatched),
                # и другого определения у нас быть не должно - владелец требует
                # одинаковых цифр во всех разделах.
                #
                # 04.09.2026 без этой строки «В Филадельфии всегда солнечно» на
                # .30 не имел НИКАКОГО маркера: серий 181 из 181, значок серий
                # скрыт (непросмотренных ноль), а галочки нет, потому что
                # корневую отметку провайдер снял 29.08, когда серии ещё
                # оставались. «Тед Лассо» галочку показывал - у него корневая
                # отметка в базе Kodi сохранилась. Одно и то же состояние
                # выглядело по-разному.
                playcount = 1
            # Галочку «просмотрен» здесь больше НЕ выдумываем.
            #
            # Было: percent >= 100 -> playcount = 1. Знаменатель приходит из
            # catalog.episode_totals, то есть из КЕША провайдера, и кеш
            # отстаёт. Замер 03.09.2026 на <коробка> (скин ,
            # провайдер 2.2.61.3.0), «В Филадельфии всегда солнечно»:
            #
            #     провайдер по живому плейлисту  total=181 watched=180 -> 1 осталась
            #     кеш, из которого считали мы    total=180 watched=180 -> 100 %
            #
            # Вышла новая серия. Провайдер честно показывал её в «Избранном»,
            # а полоса хаба ставила галочку - и владелец видел одну и ту же
            # вещь по-разному в двух разделах. Жаловался на это несколько раз.
            #
            # Процент остаётся: кольцо прогресса рисовать по нему можно, там
            # отставание на одну серию незаметно. А вот бинарный вывод
            # «просмотрено целиком» по устаревшему числу делать нельзя -
            # ошибка на одну серию переворачивает его целиком.
            #
            # Кто вправе решать: провайдер. Он единственный видит живой
            # плейлист, и CLAUDE.md прямо это закрепляет - скин не
            # восстанавливает данные за Filmix и не переопределяет их.
    if playcount:
        try:
            tag.setPlaycount(playcount)
        except Exception:
            pass
        li.setProperty('playcount', str(playcount))


def _publish_resume(li, tag, key, state):
    position, total = state['progress'].get(key) or (0.0, 0.0)
    if position > 0 and total > 0:
        try:
            tag.setResumePoint(position, total)
        except Exception:
            pass
        percent = max(0, min(100, int(round(100.0 * position / total))))
        li.setProperty('WatchedProgress', str(percent))
        li.setProperty('PercentPlayed', str(percent))
        li.setProperty('ResumeTime', str(int(position)))
        li.setProperty('TotalTime', str(int(total)))


def _plot_text(value):
    """Описание без служебной разметки, даже если снимок собран давно.

    Строку с описанием пишет сборщик, и он её чистит. Но снимок живёт неделями:
    07.09.2026 на «Джеке Ричере» в полосе виджета торчали «<br />» из старого
    снимка. Чистим и на выдаче - это одна регулярка на строку и только когда в
    тексте есть «<» или «&».
    """
    text = str(value or '')
    if '<' not in text and '&' not in text:
        return text
    try:
        from ..sublime_helper.model import clean_text
    except Exception:
        return text
    return clean_text(text) or text


def _set_release_props(li, row):
    """Качество релиза строки (плашка) - одно правило для всех выдач хаба: своё поле строки,
    иначе каталог провайдера по номеру поста. Снимки виджетов его не ставили, и плашку показывала
    служба - позже жанра и года (владелец, 21.11.2026)."""
    release_quality = str(row.get('release_quality') or '')
    release_resolution = str(row.get('release_resolution') or '')
    if not release_quality and not release_resolution:
        try:
            from . import catalog as _catalog
            release_quality, release_resolution = _catalog.release_for_path(
                row.get('file'))
        except Exception:
            release_quality, release_resolution = '', ''
    # «4K UHD 2160»: у 4K высота повторяется - плашка «4K UHD», иначе она вытесняла страну из
    # инфостроки (владелец, 21.11.2026)
    if '4K' in release_quality.upper() and release_resolution == '2160':
        release_resolution = ''
    for name, value in (('sublime_release_quality', release_quality),
                        ('sublime_release_resolution', release_resolution)):
        text_value = str(value or '')
        if text_value:
            li.setProperty(name, text_value)


def _apply_row(li, row):
    tag = li.getVideoInfoTag()
    for key, setter in (('plot', 'setPlot'), ('title', 'setTitle'),
                        ('originaltitle', 'setOriginalTitle')):
        value = row.get(key)
        if key == 'plot':
            value = _plot_text(value)
        if value:
            try:
                getattr(tag, setter)(value)
            except Exception:
                pass
    if row.get('duration'):
        try:
            tag.setDuration(int(row['duration']))
        except Exception:
            pass
    if row.get('year'):
        try:
            tag.setYear(int(str(row['year'])[:4]))
        except Exception:
            pass
    if row.get('genre'):
        try:
            tag.setGenres([g for g in row['genre'] if g])
        except Exception:
            pass
    if row.get('country'):
        try:
            tag.setCountries([c for c in row['country'] if c])
        except Exception:
            pass
    if row.get('rating'):
        try:
            tag.setRating(float(row['rating']), int(row.get('votes') or 0))
        except Exception:
            pass
    if row.get('mediatype'):
        try:
            tag.setMediaType(row['mediatype'])
        except Exception:
            pass
    if row.get('uniqueid'):
        try:
            tag.setUniqueIDs(dict(row['uniqueid']),
                             'imdb' if row['uniqueid'].get('imdb') else 'tmdb')
        except Exception:
            pass
    art = _own_art(row)
    if art:
        li.setArt(art)
    kind = _kind_of_row(row)
    if kind:
        li.setProperty('sublime_kind', kind)
    # Качество релиза: строка несёт его с собой, потому что в названии его уже
    # нет (мы его оттуда срезали), а служба публикует значок по строке. Строки
    # из снимков виджетов его не несут - снимок собирается через JSON-RPC, а он
    # свои свойства не отдаёт, - поэтому для них качество берётся по номеру
    # поста в адресе, из того же кэша провайдера (catalog.release_for_path).
    _set_release_props(li, row)
    return tag




def _kind_of_row(row, source=''):
    """Категория САМОЙ строки - «movies», «shows», «tv», «video», «other».

    08.09.2026 владелец: «Мы на хрена делали категории виджетов?! Ты должен был
    предусмотреть ВСЁ, что связано с разделением категорий!» - и он прав.
    Категории решали только два вопроса (кого обогащать и кого прогревать), а
    «что это за строка» разметка каждый раз угадывала заново: по наличию
    channel_id, по ListItem.Artist, по префиксу метки «Серия», по куску пути.
    Из-за этого добавление channel_id ради аватара канала выбило имя канала из
    инфостроки: два чипа различались по тому же признаку.

    Теперь вид строки публикуется свойством sublime_kind, и разметке не нужно
    гадать. Правила те же, что у виджетов (widget_kinds), поэтому ответ не
    может разойтись с тем, как та же строка обогревается и обогащается.
    """
    try:
        from . import widget_kinds
    except Exception:
        return ''
    for candidate in (str(row.get('file') or ''), str(source or '')):
        try:
            kind = widget_kinds.kind_of(candidate)
        except Exception:
            kind = ''
        if kind:
            return kind
    return ''

# Что подменили за этот показ - одна строка в журнал вместо строки на каждую
# плитку: 08.09.2026 подмена дважды не срабатывала молча, и понять это по
# журналу было нельзя.
_swapped = set()


def _own_art(row):
    """Картинки строки, дополненные НАШИМИ - и только там, где своих нет.

    08.09.2026, снимок владельца со списком серий: все плитки показывали одну
    и ту же чужую картинку (футболиста в чужом сериале). Причина не в данных, а
    в разметке: построчные цепочки картинок (Includes_Images.xml,
    Image_Episode_Card и Image_LandscapeOnly_Container) последним запасным
    значением брали ОКОННОЕ свойство - `SublimeHelper.ListItem.Landscape` и
    ему подобные. Оконное свойство одно на весь экран и принадлежит последней
    опубликованной строке, поэтому в момент, когда своя картинка ещё не
    пришла, каждая плитка рисовала чужую. Владелец: «айтемы наследуют чужие
    фоны, рейтинги, клир лого и тп. Такое поведение надо исключить».

    Теперь у строки есть СВОЯ запасная картинка, и оконные значения из
    построчных цепочек убраны. Порядок владельца от 08.09.2026: «Filmix
    первым, наш - когда его нет», поэтому ничего не подменяется - только
    заполняются пустые ключи.
    """
    art = dict((row or {}).get('art') or {})
    sub = (row or {}).get('sublime') or {}
    fanart = str(sub.get('fanart') or sub.get('background') or '')
    poster = str(sub.get('poster') or '')
    ours = (('poster', poster),
            # thumb и icon - тоже картинка строки: их берут списковые виды и
            # ими же Kodi отвечает на Files.GetDirectory. Пока склад
            # поставщика молчит, они должны меняться вместе с постером.
            ('thumb', poster),
            ('icon', poster),
            ('fanart', fanart),
            ('landscape', fanart),
            ('clearlogo', str(sub.get('logo') or '')))
    for key, value in ours:
        if value and not str(art.get(key) or ''):
            art[key] = value
    # SVG Kodi не рисует: такой логотип - пустое место вместо названия
    if str(art.get('clearlogo') or '').lower().split('?')[0].endswith('.svg'):
        art.pop('clearlogo', None)
    # Пока хост картинок поставщика не отвечает, ставим СВОЮ картинку вместо
    # его. 08.09.2026 у Filmix лёг собственный сервер картинок (521 от
    # Cloudflare - «источник не отвечает», с обеих коробок и из другой сети,
    # корнем хоста), а его API продолжал выдавать ровно этот адрес. Ссылка
    # непустая, поэтому разметка считала её годной, и плитки стояли пустыми
    # двенадцать часов, хотя наши постеры с TMDb лежали рядом.
    #
    # Это не подмена по вкусу: порядок владельца - «Filmix первым, наш - когда
    # его нет» (08.09.2026), и здесь его как раз НЕТ. Проверку делает служба
    # раз в пять минут одним запросом (hub/host_health.py), сборка строк только
    # читает готовый ответ. Ответит их сервер - вернутся их картинки сами.
    try:
        from . import host_health
        for key, value in ours:
            current = str(art.get(key) or '')
            if not current or not host_health.is_down(current):
                continue
            # Сначала замена хоста - тот же файл по адресу, который назвал
            # владелец. Если и она молчит, берём свою картинку.
            other = host_health.mirror_url(current)
            if other and not host_health.is_down(other):
                art[key] = other
                _swapped.add('%s->замена' % key)
            elif value and value != current:
                art[key] = value
                _swapped.add('%s->наша' % key)
            else:
                # Своей картинки нет - мёртвый адрес снимаем. Причина не в
                # красоте пустой плитки, а в том, что загрузчик текстур у Kodi
                # ОДИН: по кадрам записи владельца 08.09.2026 видно, как на
                # строке с мёртвым адресом разом гаснут ВСЕ плитки полосы и фон
                # замирает на прошлой строке - в журнале в эти же секунды Kodi
                # по кругу ждёт по 10 секунд на каждой попытке достучаться до
                # лёгшего склада. Один мёртвый адрес останавливает отрисовку
                # всего экрана.
                #
                # Решение принимает ТОЛЬКО пятиминутная проба хоста, и ничего
                # больше. Раньше я добавил сюда ещё и проверку «лежит ли
                # картинка в кэше Kodi» - решение стало меняться на каждой
                # отрисовке, и владелец увидел «постеры загружаются, потом
                # пропадают, потом опять появляются».
                #
                # Снятие живёт только на время отрисовки: в снимке строки адрес
                # нетронут, и как только их склад ответит пробе, картинка
                # вернётся сама. Пустая плитка рисует название (Layout_Poster).
                art.pop(key, None)
                _swapped.add('%s->снят (склад молчит, своей нет)' % key)
    except Exception:
        pass
    return {k: v for k, v in art.items() if v}

_FILMIX = 'plugin://plugin.video.filmix/'


def _filmix_personal():
    """Что у владельца в «Избранном» и «Смотреть позже» у Filmix - или None.

    None, когда вход в Filmix не выполнен: сам Filmix в этом случае пунктов не
    показывает (navigation._get_context_menu смотрит на user_login), и
    переключатель без входа всё равно не сработал бы.
    """
    try:
        import xbmcaddon
        # без Filmix (источник HDrezka/Elementum) - не спрашивать: отказ Kodi пишет ошибкой в журнал
        if not xbmc.getCondVisibility('System.HasAddon(plugin.video.filmix)'):
            return None
        if not xbmcaddon.Addon('plugin.video.filmix').getSetting('user_login'):
            return None
    except Exception:
        return None
    return catalog.provider_personal_ids()


def _filmix_context(row, personal):
    """Пункты «Избранное» и «Смотреть позже» самого Filmix для строки хаба.

    Владелец 16.10.2026: в виджетах главной в контекстном меню есть не во всех
    категориях пункты Filmix. В его собственных разделах («Избранное», «Смотреть
    позже») они есть, у строк хаба («Все», «Рекомендации», «Русские»,
    «Сербские») - нет: меню строки собирает тот, кто её отдаёт. Подписи и
    маршруты - ровно те, что у Filmix (toogle_favorites, toogle_watch_later);
    переключение он делает на сервере сам и сам перечитывает свой список.
    """
    if personal is None:
        return []
    path = str(row.get('file') or '')
    post_id = str(row.get('post_id') or '')
    if not post_id or not path.startswith(_FILMIX):
        return []
    # Владелец 06.11.2026: у сериалов только «В избранное» / «Из избранного»,
    # у фильмов только «Смотреть позже» / «Не смотреть позже» - так же, как в
    # меню самого Filmix (navigation._get_context_menu).
    series = (str(row.get('mediatype') or '') == 'tvshow'
              or '/serials/' in path or '/multserials/' in path)
    choices = ((('favorites', 'toogle_favorites', tr(31916), tr(31917)),)
               if series else
               (('deferred', 'toogle_watch_later', tr(31918), tr(31919)),))
    items = []
    for section, route, add, remove in choices:
        inside = post_id in personal.get(section, ())
        items.append(('Filmix: %s' % (remove if inside else add),
                      'RunPlugin(%s%s?id=%s&value=%d)'
                      % (_FILMIX, route, post_id, 0 if inside else 1)))
    return items


def _context(row, category, personal=None, feedback=False):
    """feedback - пункты «Рекомендовать такое / Не рекомендовать такое»: они
    есть только в полосе «Рекомендации» (владелец 06.11.2026)."""
    label = row.get('label') or ''
    year = row.get('year') or ''
    items = _filmix_context(row, personal) + [
        (tr(31920),
         'RunPlugin(%s)' % _url('hub_mark_watched', path=row.get('file'),
                                label=label, year=year, category=category)),
        (tr(31921),
         'RunPlugin(%s)' % _url('hub_mark_unwatched', path=row.get('file'),
                                label=label, year=year, category=category)),
    ]
    if not feedback:
        return items
    return items + [
        (tr(31922),
         'RunPlugin(%s)' % _url('hub_feedback', kind='like', label=label,
                                year=year, genre=','.join(row.get('genre') or []),
                                country=','.join(row.get('country') or []),
                                mediatype=row.get('mediatype') or '',
                                category=category)),
        (tr(31923),
         'RunPlugin(%s)' % _url('hub_feedback', kind='dislike', label=label,
                                year=year, genre=','.join(row.get('genre') or []),
                                country=','.join(row.get('country') or []),
                                mediatype=row.get('mediatype') or '',
                                category=category)),
    ]


# offscreen=True: элемент строится для списка дополнения, а не для окна.
# Без него каждый setProperty/setArt ждёт блокировку интерфейса Kodi, пока
# главный поток рисует экран: замер на .30 17.10.2026 - 828 setProperty
# РуТора то 0.35 с, то 2.75 с при открытом окне поиска.
def _row_rating_props(built, mediatype):
    """Оценки строки и раскладка по слотам - одно правило для всех (hub/row_store.py)."""
    from . import row_store
    return row_store.rating_props(built, mediatype)


def _row_info_props(built, row):
    """Жанр, дата и страна инфостроки - одно правило для всех (hub/row_store.py)."""
    from . import row_store
    return row_store.info_props(built, row)


SELFTEST_KEYS = ('SeriesStarted', 'WatchedProgress', 'WatchedEpisodes', 'UnWatchedEpisodes',
                 'TotalEpisodes', 'WatchedEpisodePercent', 'Sublime.Plot', 'sublime_new_episodes')


def _selftest():
    import sys
    return 'selftest=1' in (sys.argv[2] if len(sys.argv) > 2 else '')


def _selftest_label(li, tag, row):
    """Самопроверка (sublime-box/installer/regress.py): итог строки - в названии, его видно
    снаружи через Files.GetDirectory; обычные списки не меняются."""
    seen = dict((k, li.getProperty(k)) for k in SELFTEST_KEYS if li.getProperty(k))
    if 'Sublime.Plot' in seen:
        seen['Sublime.Plot'] = len(seen['Sublime.Plot'])
    try:
        seen['playcount'] = tag.getPlayCount()
        seen['plot'] = len(tag.getPlot() or '')
    except Exception:
        pass
    seen['mediatype'] = str(row.get('mediatype') or '')
    li.setLabel('%s ⟦%s⟧' % (li.getLabel(), json.dumps(seen, ensure_ascii=False)))


def _publish_rows(handle, rows, category, content, enrichment=None, feedback=False):
    """Publish our own rows, carrying whatever the builder finished for them.

    The enrichment index is keyed by the row's path, so a lane keeps its own
    ordering and its own freshness logic while the finished picture, colour and
    identity travel with each row - see hub/builder.py.
    """
    rows = [row for row in (rows or []) if not mirror.is_navigation(row)]
    enrichment = enrichment or {}
    # блок из индекса сборщика - в строку, затем общее хранилище добирает его пустые поля
    rows = [dict(r, sublime=enrichment[str(r.get('file') or '')]) if enrichment.get(str(r.get('file') or '')) else r
            for r in rows]
    _attach_row_store(rows)
    state = _watch_state(rows)
    personal = _filmix_personal()
    # Вид релиза строк провайдера - всегда заново по номеру поста: собранная
    # полоса хранит его с момента сборки, а запись поста застревает на первой
    # экранке (20.10.2026 на .20 «Тенцинг» - «CAM 480», хотя фильм уже вышел
    # в WEB-DL). Экранки не показываем вовсе - владелец: «Никаких экранок».
    provider_prefix = 'plugin://%s/' % catalog.video_addon()
    try:
        catalog.prefetch_releases([row.get('file') for row in rows
                                   if str(row.get('file') or '').startswith(provider_prefix)
                                   or not (row.get('release_quality') or row.get('release_resolution'))])
    except Exception as exc:
        log('качество релизов не прочитано разом: %s' % exc, xbmc.LOGWARNING)
    screeners = []
    for row in rows:
        if str(row.get('file') or '').startswith(provider_prefix):
            try:
                fresh = catalog.release_for_path(row.get('file'))
            except Exception:
                fresh = ('', '')
            if fresh[0] or fresh[1]:
                row = dict(row, release_quality=fresh[0], release_resolution=fresh[1])
        if identity.is_screener(row.get('release_quality')):
            screeners.append('%s[%s]' % (row.get('label') or row.get('file'), row.get('release_quality')))
            continue
        # Обогащение привязываем к строке ДО сборки картинок. 08.09.2026:
        # подмена картинки на нашу (когда склад поставщика лежит) не срабатывала
        # именно здесь - в этой ветке строки приходят без блока «sublime», он
        # подавался отдельно и только свойствами, поэтому подменять было нечем.
        built = row.get('sublime') or enrichment.get(str(row.get('file') or ''))
        if built:
            row = dict(row)
            row['sublime'] = built
        row = clean_row(row)
        li = xbmcgui.ListItem(label=row.get('label') or '', offscreen=True)
        tag = _apply_row(li, row)
        _publish_identity_hints(li, row)
        _publish_watch_state(li, tag, row, state)
        reasons = row.get('_reasons') or []
        if reasons:
            # Say why the row is here. Not folded into the plot: the plot is the
            # film's own text, and overwriting it to explain ourselves would be
            # taking something away to add something.
            li.setProperty('WatchHub.Reasons',
                           ' • '.join(recommend.display_reason(r) for r in reasons))
        if row.get('new_episodes'):
            # сериал в рекомендациях из-за вышедших серий: начат вами нарочно (recommend._new_episode_rows)
            li.setProperty('sublime_new_episodes', str(row['new_episodes']))
        if row.get('smart_line'):
            # вторая строка карточки полосы подсказок (hub_smart)
            li.setProperty('Sublime.SmartLine', row['smart_line'])
        li.addContextMenuItems(_context(row, category, personal, feedback))
        if built:
            for name, value in mirror.row_properties({'sublime': built}).items():
                li.setProperty(name, value)
            for name, value in _row_rating_props(built, row.get('mediatype')).items():
                li.setProperty(name, value)
            for name, value in _row_info_props(built, row).items():
                li.setProperty(name, value)
        if row.get('smart_line'):
            _smart_meta_props(li, row)
        if _selftest():
            _selftest_label(li, tag, row)
        is_folder = str(row.get('filetype') or 'file') != 'file'
        xbmcplugin.addDirectoryItem(handle, row.get('file') or '', li, is_folder)
    if screeners:
        log('экранки не показаны (%s): %s' % (category, ', '.join(screeners)), xbmc.LOGINFO)
    if _swapped:
        log('картинки подменены (склад поставщика молчит): %s'
            % ', '.join(sorted(_swapped)), xbmc.LOGINFO)
        _swapped.clear()
    xbmcplugin.setContent(handle, content)
    # The rows are already ranked and that ranking is the product; letting Kodi
    # sort them would throw it away.
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
    return True


# ---- routes ------------------------------------------------------------

def hub_widget(handle, params):
    category = params.get('category') or 'movies'
    rows = recommend.get_widget_items(category, _max_age())
    from . import builder
    return _publish_rows(handle, rows, category,
                         'movies' if category == 'movies' else 'tvshows',
                         mirror.enrichment_index(builder.WIDGET_SRC % category),
                         feedback=True)


# ---- полоса подсказок (hub_smart) ---------------------------------------
# Узкая полоса внизу хабов «Фильмы» и «Сериалы»: сериал с новыми сериями и лучшие по счёту
# рекомендации (владелец 25.11.2026). Карточка - широкий кадр с затемнением под надпись, поэтому
# строка без широкой картинки (fanart/landscape) в полосу не идёт. Строки публикуются тем же
# _publish_rows, что и виджеты: в фокусе карточки верх экрана показывает её как обычную строку.
SMART_FOLLOW_DAYS = 120      # сериал «смотрите», если серия в нём была за это время
SMART_FOLLOW_SHARE = 0.5     # и просмотрено не меньше половины вышедших серий
SMART_CARDS = 10   # карусель по кругу (владелец 25.11.2026)
SMART_NEW_EPISODE_CARDS = 3


def _plural(n, one, few, many):
    n = abs(int(n))
    if n % 10 == 1 and n % 100 != 11:
        return one
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return few
    return many


def _smart_wide(row, enrichment):
    """Есть ли у строки широкая картинка - своя или из обогащения."""
    art = row.get('art') or {}
    if art.get('fanart') or art.get('landscape'):
        return True
    built = row.get('sublime') or enrichment.get(str(row.get('file') or '')) or {}
    return bool(built.get('fanart') or built.get('background') or built.get('landscape'))


def _followed_posts():
    """Сериалы, которые вы смотрите, - это сериалы из «Избранного» Filmix (владелец 25.11.2026):
    просмотренное вне избранного просматриваемым не считается."""
    try:
        return set(str(pid) for pid in catalog.provider_personal_ids().get('favorites') or ())
    except Exception:
        return set()


def _smart_new_episodes():
    """[(вышло новых, время последнего просмотра, ид поста, начало пути)] - сериалы из «Избранного»
    Filmix (серия за SMART_FOLLOW_DAYS, просмотрено не меньше половины), у которых серий у
    источника больше, чем просмотрено в этом же посте."""
    import time
    now = time.time()
    followed = _followed_posts()
    if not followed:
        return []
    posts = {}
    for row in history._rows():
        if int(row.get('playcount') or 0) <= 0 or row.get('mediatype') != 'episode':
            continue
        hit = re.match(r'^(.*?/serials/(\d+)-)', str(row.get('path') or ''))
        if not hit or hit.group(2) not in followed:
            continue
        entry = posts.setdefault(hit.group(2), {'prefix': hit.group(1), 'keys': set(), 'last': 0})
        entry['keys'].add(row.get('item_key'))
        entry['last'] = max(entry['last'], int(row.get('last_watched') or 0))
    recent = dict((pid, e) for pid, e in posts.items()
                  if now - e['last'] < SMART_FOLLOW_DAYS * 86400)
    if not recent:
        return []
    try:
        totals = catalog.episode_totals(list(recent))
    except Exception:
        totals = {}
    out = []
    for pid, entry in recent.items():
        total, seen = int(totals.get(pid) or 0), len(entry['keys'])
        if total > seen and seen >= total * SMART_FOLLOW_SHARE:
            out.append((total - seen, entry['last'], pid, entry['prefix']))
    return out


def _smart_reason(reasons):
    """Вторая строка плитки «Для вас» - почему это рекомендовано (владелец 25.11.2026). Причины
    recommend.score_candidate («в ролях X», «режиссёр X») читались как титры, «похоже на то, что вы
    смотрели» отбрасывалась, а без причин шли жанр и год - не причина вовсе."""
    reasons = [str(r) for r in reasons if r and r != 'вы это бросили']
    try:
        from ..l10n import is_russian
        russian = is_russian()
    except Exception:
        russian = True
    if not russian:
        shown = [recommend.display_reason(r) for r in reasons]
        return shown[0] if shown else ''
    for r in reasons:
        if r.startswith('похоже на то'):
            return 'Похоже на то, что вы смотрели'
    for r in reasons:
        if r == 'этот сериал вы уже смотрите':
            return 'Вы уже смотрите этот сериал'
    for r in reasons:
        if r.startswith('режиссёр '):
            return 'Из вашей истории: режиссёр %s' % r[len('режиссёр '):]
    for r in reasons:
        if r.startswith('в ролях '):
            return 'Из вашей истории: %s' % r[len('в ролях '):]
    for r in reasons:
        if r == 'знакомый режиссёр':
            return 'Режиссёр из вашей истории'
        if r == 'знакомые актёры':
            return 'Актёры из вашей истории'
    return 'По вашей истории просмотров'


def _first_of(value):
    if isinstance(value, (list, tuple)):
        value = value[0] if value else ''
    return re.split(r'\s*(?:/|,)\s*', str(value or ''))[0].strip()


def _smart_meta_props(li, row):
    """Справа на плитке «Для вас»: значки оценок, затем «год · жанр · страна» - одним блоком по правому
    полю, как в инфостроке. В раскладке элемента списка Kodi не выстраивает grouplist, поэтому ширину
    подписи считает маршрут (smart_font - ширины знаков шрифта font_tiny), а значки сдвигаются на неё
    двоичными шагами: свойство Sublime.SmartMetaB<N> включает сдвиг на N px (Includes_Hubs.xml)."""
    from . import smart_font
    genre = li.getProperty('Sublime.Genres2') or _first_of(row.get('genre'))
    country = li.getProperty('Sublime.Country2') or _first_of(row.get('country'))
    text = ' · '.join(str(v) for v in (row.get('year'), genre, country) if v)
    li.setProperty('Sublime.SmartMeta', text)
    shift = int(round(smart_font.text_width(text))) + (10 if text else 0)
    for bit in (2, 4, 8, 16, 32, 64, 128, 256, 512, 1024):
        if shift & bit:
            li.setProperty('Sublime.SmartMetaB%d' % bit, '1')


def _smart_recs(category):
    """Рекомендации полосы в порядке счёта. mixed - фильмы и сериалы вперемешку, лучший первым."""
    if category in ('movies', 'shows'):
        return recommend.get_widget_items(category, _max_age()) or []
    rows = []
    for cat in ('movies', 'shows'):
        try:
            rows += [dict(r, _smart_cat=cat) for r in (recommend.get_widget_items(cat, _max_age()) or [])
                     if not r.get('new_episodes')]
        except Exception as exc:
            log('полоса подсказок: рекомендаций %s нет: %s' % (cat, exc), xbmc.LOGWARNING)
    rows.sort(key=lambda r: float(r.get('_score') or 0), reverse=True)
    # в смешанной полосе - и фильм, и сериал: лучший каждого вида вперёд
    first = []
    for cat in ('movies', 'shows'):
        best = next((r for r in rows if r.get('_smart_cat') == cat), None)
        if best is not None:
            first.append(best)
    first.sort(key=lambda r: float(r.get('_score') or 0), reverse=True)
    return first + [r for r in rows if r not in first]


def hub_smart(handle, params):
    """Полоса подсказок: сериал с новыми сериями (в «Сериалах» и смешанной полосе), затем лучшие по
    счёту рекомендации. «Фильмы» - только фильмы, «Сериалы» - только сериалы, остальные хабы -
    вперемешку (владелец 25.11.2026)."""
    category = params.get('category') or 'mixed'
    from . import builder
    enrichment = {}
    for src in (builder.WIDGET_SRC % 'movies', builder.WIDGET_SRC % 'shows',
                builder.LANE_SRC % 'new_shows', builder.LANE_SRC % 'new_movies'):
        try:
            for path, built in mirror.enrichment_index(src).items():
                enrichment.setdefault(path, built)
        except Exception:
            pass
    cards = []
    try:
        fresh = _smart_new_episodes() if category != 'movies' else []
    except Exception as exc:
        log('полоса подсказок: новые серии не посчитаны: %s' % exc, xbmc.LOGWARNING)
        fresh = []
    if fresh:
        found = catalog.rows_for_paths([prefix for _n, _l, _pid, prefix in fresh])
        shown = []
        for new, last, _pid, prefix in fresh:
            source = found.get(prefix)
            if not source:
                continue
            entries = lanes._entries([(None, source)], 'shows', {}, 1)
            if entries and _smart_wide(entries[0], enrichment):
                shown.append((source.get('added_ts') or 0, new, last, entries[0]))
        # первым - сериал, чей пост источник обновлял последним (вышла серия); дальше - больше серий
        shown.sort(key=lambda t: (t[0], t[1], t[2]), reverse=True)
        # в карусели места хватает: у каждого сериала с новыми сериями - своя плитка
        for _ts, new, _last, card in shown[:SMART_NEW_EPISODE_CARDS]:
            line = '%d %s %s' % (new, _plural(new, 'новая', 'новые', 'новых'),
                                 _plural(new, 'серия', 'серии', 'серий'))
            cards.append(dict(card, smart_line=line))
    taken = set(str(c.get('file') or '') for c in cards)
    try:
        recs = _smart_recs(category)
    except Exception as exc:
        log('полоса подсказок: рекомендаций нет: %s' % exc, xbmc.LOGWARNING)
        recs = []
    for row in recs:
        if len(cards) >= SMART_CARDS:
            break
        if row.get('new_episodes') or str(row.get('file') or '') in taken:
            continue
        if not _smart_wide(row, enrichment):
            continue
        cards.append(dict(row, smart_line=_smart_reason(row.get('_reasons') or [])[:70]))
    cards = [dict((k, v) for k, v in c.items() if k != '_smart_cat') for c in cards]
    return _publish_rows(handle, cards, 'shows' if category == 'shows' else 'movies',
                         'tvshows' if category == 'shows' else 'movies', enrichment, feedback=True)


def hub_lane(handle, params):
    name = params.get('name') or 'new_movies'
    rows = lanes.get_lane(name, _max_age())
    from . import builder
    return _publish_rows(handle, rows, 'shows' if name.endswith('shows') else 'movies',
                         'tvshows' if name.endswith('shows') else 'movies',
                         mirror.enrichment_index(builder.LANE_SRC % name))


def hub_mirror(handle, params):
    """Another add-on's widget, answered from our own store.

    The rows are exactly what that add-on last returned, file paths included, so
    opening or playing one goes straight to it. Why this exists, with numbers,
    is in hub/mirror.py.
    """
    src = params.get('src') or ''
    if not src:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return False
    return _publish_stored_rows(handle, _only_kind(mirror.rows(src), src))


_SHOW_TYPES = ('tvshow', 'season', 'episode')


def _row_is_show(row):
    kind = str(row.get('mediatype') or row.get('type') or '')
    if kind:
        return kind in _SHOW_TYPES
    path = str(row.get('file') or '')
    return '/serials/' in path or '/series/' in path or '/show/' in path


def _only_kind(rows, src):
    """Вкладка фильмов - только фильмы, сериалов - только сериалы (владелец 17.11.2026:
    «Одиссея» в «Сейчас смотрят» сериалов). Смешанный список источника (Filmix top_views)
    помечается в адресе вкладки sublime_kind=movies|shows - дополнение пометку не читает."""
    match = re.search(r'[?&]sublime_kind=(movies|shows)', src or '')
    kind = match.group(1) if match else ''
    if not kind:
        # категория вкладки из раскладки (widget_kind) - точное совпадение адреса
        try:
            from . import widget_kinds
            kind = widget_kinds.load().get(str(src or '').strip(), '')
        except Exception:
            kind = ''
    if kind not in ('movies', 'shows'):
        return rows
    want_show = kind == 'shows'
    return [row for row in rows or [] if mirror.is_navigation(row) or _row_is_show(row) == want_show]


def hub_subs(handle, params):
    """Лента подписок YouTube, собранная нами. См. hub/youtube_subs.py.

    Дополнение YouTube строит «Мои подписки» из ленты RSS, а YouTube отдаёт на
    неё 404 с января 2026 года (открытая тема в форуме Google, замер на обеих
    коробках). Здесь та же лента, но из плейлистов загрузок каналов - через
    обычные маршруты дополнения, без единой правки в нём.
    """
    from . import youtube_subs
    return _publish_stored_rows(handle, _newest_first(youtube_subs.rows()))


def hub_trending(handle, params):
    """«В тренде» YouTube, собранное нами. См. hub/youtube_trending.py.

    Замер на .30 07.09.2026: у дополнения этот раздел отдаётся 3.3-4.2 с (на
    каждый вызов - свой процесс и импорт 38 800 строк), прямой запрос к API -
    0.3-0.5 с. Воспроизведение остаётся за дополнением: путь строки ведёт в
    него.
    """
    from . import youtube_trending
    return _publish_stored_rows(handle, _newest_first(youtube_trending.rows()))


def hub_ytlane(handle, params):
    """Полоса YouTube без ключа: kind=live|news|charts. См. hub/youtube_inner.py."""
    from . import youtube_inner
    return _publish_stored_rows(handle, _newest_first(youtube_inner.rows(str(params.get('kind') or ''))))


def hub_search(handle, params):
    """Поиск фильмов и сериалов одной вкладкой при любых источниках.

    m и s - адреса поиска фильмов и сериалов у источника (без запроса на конце), q - запрос.
    У Elementum и при разных источниках фильмов и сериалов это два разных поиска; скин
    спрашивает оба сразу и отдаёт одним списком: сначала фильмы, потом сериалы."""
    import threading
    from .provider import get_directory
    query = str(params.get('q') or params.get('query') or '').strip()
    bases = []
    for key in ('m', 's'):
        base = str(params.get(key) or '').replace('&amp;', '&')
        if base and base not in bases:
            bases.append(base)
    if not query or not bases:
        xbmcplugin.endOfDirectory(handle, succeeded=bool(bases))
        return bool(bases)
    found = [[] for _ in bases]

    def ask(index, base):
        try:
            found[index] = get_directory(base + quote(query), timeout=40) or []
        except Exception as exc:
            log('поиск %s: %s' % (base[:60], exc), xbmc.LOGWARNING)

    workers = [threading.Thread(target=ask, args=(i, b)) for i, b in enumerate(bases)]
    for worker in workers:
        worker.daemon = True
        worker.start()
    for worker in workers:
        worker.join(45)
    rows, seen = [], set()
    for index, files in enumerate(found):
        for row in files:
            path = str(row.get('file') or '')
            if not path or path in seen or mirror.is_navigation(row):
                continue
            if row.get('filetype') == 'directory' and 'page=' in path and not row.get('uniqueid'):
                continue                        # «Следующая страница»
            seen.add(path)
            row = dict(row)
            kind = str(row.get('type') or row.get('mediatype') or '')
            if kind in ('', 'unknown'):
                kind = 'tvshow' if (len(bases) > 1 and index == 1) else 'movie'
            row['mediatype'] = kind
            rows.append(row)
    return _publish_stored_rows(handle, rows)


def hub_wrap(handle, params):
    """Результаты поиска любого дополнения - строками, собранными как в хабах.

    Окно поиска брало список прямо у дополнения, и фон, цвет, логотип и сведения ждали
    службу: на экране то фон прошлой карточки, то пусто (.20, 21.11.2026). Здесь каждая
    строка несёт готовые Sublime.* (hub/search_rows.py), разметка рисует их в кадре смены
    фокуса. Адрес дополнения - всё после src= как есть: в нём свои ? и &."""
    import sys
    from . import search_rows
    raw = sys.argv[2] if len(sys.argv) > 2 else ''
    src = raw.split('src=', 1)[1] if 'src=' in raw else ''
    src = src.replace('&amp;', '&')
    if not src.startswith('plugin://'):
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return True
    rows, rest = search_rows.rows(src)
    # та же выдача, что у строк хабов: качество релиза из каталога по номеру поста (а не разбор
    # названия службой), отметки просмотра, меню, без экранок (владелец, 21.11.2026)
    for row in rows:
        if not row.get('mediatype'):
            kind = str(row.get('type') or '')
            if kind and kind != 'unknown':
                row['mediatype'] = kind
    if 'plugin.video.youtube' in src:
        _publish_stored_rows(handle, rows)      # ролики - как полосы YouTube хабов
    else:
        enrichment = dict((str(r.get('file') or ''), r['sublime']) for r in rows if r.get('sublime'))
        _publish_rows(handle, rows, 'search', 'videos', enrichment)
    search_rows.finish(rest)                # недособранное - в память, к следующему разу
    return True


def hub_ytsearch(handle, params):
    """Поиск YouTube без ключа для общего поиска скина (q=...)."""
    from . import youtube_inner
    return _publish_stored_rows(handle, youtube_inner.search(str(params.get('q') or params.get('query') or '')))


def _apply_live_state(row, seen):
    """Наложить на строку снимка то, что база Kodi говорит СЕЙЧАС.

    Отметку живое состояние перебивало и раньше, а вот недосмотр - нет, и это
    владелец увидел: ролик «Почему ястребы не могут придушить...» он досмотрел
    до конца (в базе playCount=2, закладки нет), а на строке висела метка
    незаконченного просмотра - потому что в снимке осталась старая resume
    2244 из 2607, и мы её применяли поверх.

    Правило простое: живое состояние - единственный источник. Досмотрено или
    закладки нет - недосмотр снимается; закладка есть - ставится она.
    """
    playcount, position, total = seen
    row['playcount'] = playcount
    if playcount or not (position > 0 and total > 0):
        row.pop('resume', None)
    else:
        row['resume'] = {'position': position, 'total': total}
    return row


def _newest_first(rows):
    """Свои полосы YouTube - новое сверху и при выдаче: снимок мог записать прошлый код, и до
    его обновления (час и больше) порядок оставался бы старым (.20, 17.11.2026: «видео ютуб не
    сортированы по убыванию даты»). Строки без даты - в конце, в прежнем порядке."""
    rows = [row for row in (rows or []) if isinstance(row, dict)]
    dated = [row for row in rows if str(row.get('dateadded') or '')]
    if len(dated) < 2:
        return rows
    undated = [row for row in rows if not str(row.get('dateadded') or '')]
    dated.sort(key=lambda row: str(row.get('dateadded')), reverse=True)
    return dated + undated


def _row_is_show_card(row):
    """Карточка сериала (не серия и не сезон) в чужом списке - по типу или адресу."""
    kind = str(row.get('mediatype') or row.get('type') or '')
    if kind in ('season', 'episode'):
        return False
    path = str(row.get('file') or '')
    return bool(row.get('year')) and (kind == 'tvshow' or '/series/' in path or '/serials/' in path
                                      or re.search(r'plugin\.video\.elementum/show/\d+/seasons', path) is not None)


_RELEASE_IN_TITLE = re.compile(r'\s*\[[^\]]*(?:rip|web|bd|hd|uhd|4k|2160|1080|720|480|cam|ts)[^\]]*\]\s*$', re.I)


def _attach_row_store(rows):
    """Строки, которых сборщик не собирал (личные списки, подписки, продолжить просмотр), берут
    готовые данные из общего хранилища строк по адресу; недостающие - в очередь на сборку.
    Один механизм для всех выдач хаба (владелец, 21.11.2026)."""
    try:
        from . import row_store
        rows = [r for r in rows if isinstance(r, dict) and r.get('file')]
        if not rows:
            return
        known = row_store.get_many([r['file'] for r in rows])
        ask = []
        for r in rows:
            block = known.get(str(r['file']))
            if r.get('sublime'):
                # собранная строка снимка добирает пустые поля из хранилища: логотип, найденный
                # очередью дополнений, иначе ждал пересборки полосы («Вествуд» во «Все», 22.11.2026)
                if block:
                    r['sublime'] = row_store._merged(block, r['sublime'])
            elif block:
                r['sublime'] = block
            else:
                ask.append(r)
        if ask:
            row_store.ask(ask)
    except Exception as exc:
        log('хранилище строк для выдачи: %s' % exc, xbmc.LOGDEBUG)


def _publish_stored_rows(handle, rows):
    """Отдать готовые строки снимка - чужого виджета или своей ленты."""
    rows = [row for row in (rows or []) if not mirror.is_navigation(row)]
    _attach_row_store(rows)
    # Состояние просмотра берётся ЖИВЬЁМ, а не из снимка. Снимок несёт то, что
    # было в момент сборки, и на .30 04.09.2026 это значило: «Сценарий
    # следующей войны» просмотрен в 22:05, в базе Kodi playcount 1, а на строке
    # ноль - маркера владелец не увидел. Ещё у четырёх строк ленты снимок
    # расходился с базой в ту же сторону. Один запрос на полосу: снимок истории
    # кешируется на 45 с (hub/history.py).
    live, by_title, episodes_state = {}, {}, {'episodes': {}, 'shows': {}}
    try:
        live = history.state_by_path()
        by_title = history.state_by_title()
        episodes_state = history.episode_states()
    except Exception as exc:
        log('состояние просмотра не прочитано: %s' % exc, xbmc.LOGWARNING)
    # Сериалы - тем же расчётом, что во «Все», «Рекомендациях» и «Продолжить просмотр»
    # (_watch_state / _publish_watch_state): начат, сколько серий не просмотрено, просмотрен.
    # Своя упрощённая отметка давала другие значки в чужих списках («Сейчас смотрят»).
    show_rows = [dict(row, label=row.get('title') or row.get('label') or '')
                 for row in rows if _row_is_show_card(row)]
    show_state = None
    if show_rows:
        try:
            show_state = _watch_state(show_rows)
        except Exception as exc:
            log('состояние сериалов не прочитано: %s' % exc, xbmc.LOGWARNING)
    try:
        # Канал YouTube проставляется и при выдаче, а не только при сборке
        # снимка: снимок мог быть собран прошлой версией, а сборщик при
        # активном зрителе стоит в стороне - и тогда ждать его пришлось бы час.
        # Ответы кешируются в памяти, поэтому это один проход по базе на полосу.
        from . import youtube_meta
        youtube_meta.fill_channels(rows)
    except Exception:
        pass
    for row in rows:
        # Эмодзи в названиях и описаниях роликов YouTube: в шрифтах скина их
        # нет, Kodi рисует пустые квадраты (см. hub/youtube_text.py).
        row = clean_row(row)
        # вид релиза в квадратных скобках («Сингапур [WEB-DLRip 1080]») - не часть названия: его
        # показывает плашка; без этого в «Избранном» стояло сырое название (21.11.2026)
        for _key in ('label', 'title'):
            if row.get(_key):
                row[_key] = _RELEASE_IN_TITLE.sub('', str(row[_key])).strip() or row[_key]
        li = xbmcgui.ListItem(label=row.get('label') or row.get('title') or '', offscreen=True)
        art = _own_art(row)
        if art:
            try:
                li.setArt(art)
            except Exception:
                pass
        # Номер канала YouTube: по нему служба находит аватар канала в кэше
        # дополнения (vcl_service, _youtube_channel_avatar). Без него логотип
        # канала внизу справа не появлялся у наших строк подписок и трендов.
        channel_id = str(row.get('channel_id') or '')
        if channel_id:
            try:
                li.setProperty('channel_id', channel_id)
            except Exception:
                pass
            # «Перейти к КАНАЛУ» у ролика (владелец 06.11.2026) - тот же адрес канала,
            # что строит само дополнение 8 (router._video_menu: browse?id=UC...&title=...).
            channel_name = row.get('studio')
            if isinstance(channel_name, (list, tuple)):
                channel_name = channel_name[0] if channel_name else ''
            channel_name = str(channel_name or '').strip()
            if channel_name and 'plugin.video.youtube' in str(row.get('file') or ''):
                try:
                    li.addContextMenuItems([(
                        tr(31924) % channel_name,
                        'ActivateWindow(Videos,plugin://plugin.video.youtube/browse'
                        '?id=%s&title=%s,return)' % (channel_id, quote(channel_name)))])
                except Exception:
                    pass
        kind = _kind_of_row(row)
        if kind:
            try:
                li.setProperty('sublime_kind', kind)
            except Exception:
                pass
        tag = li.getVideoInfoTag()
        for key, setter in (('title', 'setTitle'), ('plot', 'setPlot')):
            value = row.get(key)
            if key == 'plot':
                value = _plot_text(value)
            if value:
                try:
                    getattr(tag, setter)(value)
                except Exception:
                    pass
        # Живое состояние перебивает снимок - см. выше. Ничего не выдумываем:
        # берём ровно то, что записала Kodi по этому пути.
        seen = live.get(history.canon_path(str(row.get('file') or '')))
        # в общей базе только фильмы; сериалы и серии не трогаем (тип строки по адресу у
        # HDRezka не определяется - «Одиссея» в снимке «Сейчас смотрят» оставалась без отметки)
        if row.get('year') and str(row.get('mediatype') or row.get('type') or '') not in (
                'tvshow', 'season', 'episode') and '/series/' not in str(row.get('file') or '')                 and _kind_of_row(row) not in ('shows', 'tv', 'video'):
            # тот же фильм мог быть начат или досмотрен в другом источнике: «просмотрено» -
            # если так говорит любой, позиция - своя, а если своей нет - общая
            shared = None
            try:
                from . import identity as _identity
                key = _identity.key_for(title=row.get('title') or row.get('label') or '',
                                        year=row.get('year'))[0]
                shared = by_title.get(key) if key else None
            except Exception:
                shared = None
            if shared is not None:
                seen = shared       # уже сведено по всем источникам, самое свежее действие
        elif show_state is not None and _row_is_show_card(row):
            try:
                _publish_watch_state(li, tag, dict(row, label=row.get('title') or row.get('label') or ''),
                                     show_state)
                row = dict(row)
                row.pop('playcount', None)      # отметку сериала уже поставил расчёт выше
            except Exception as exc:
                log('отметка сериала не поставлена: %s' % exc, xbmc.LOGDEBUG)
        if seen is not None:
            row = _apply_live_state(dict(row), seen)
        for key, setter in (('year', 'setYear'), ('playcount', 'setPlaycount'),
                            ('season', 'setSeason'), ('episode', 'setEpisode')):
            value = row.get(key)
            if value in (None, ''):
                continue
            try:
                getattr(tag, setter)(int(value))
            except Exception:
                pass
        for key, setter in (('dateadded', 'setDateAdded'),
                            ('premiered', 'setPremiered'),
                            ('lastplayed', 'setLastPlayed')):
            value = row.get(key)
            if not value:
                continue
            try:
                getattr(tag, setter)(str(value))
            except Exception:
                pass
        studio = row.get('studio')
        if studio:
            # Канал YouTube. Чип инфо-строки читает именно Studio - тот же, что
            # у строк, построенных самим дополнением YouTube.
            try:
                tag.setStudios([studio] if isinstance(studio, str) else list(studio))
            except Exception:
                pass
        if str(row.get('filetype') or 'file') == 'file':
            # Узкий признак «эта строка - ролик, у которого бывает отметка
            # просмотра». Нужен ровно для галочки: разметка рисует её только для
            # известных типов (DBType), а у строк ютуба тип пустой.
            #
            # ТИП СТАВИТЬ НЕЛЬЗЯ - это уже проверено на владельце. В 
            # я выставил mediatype=video, и по пустому типу скин со службой
            # узнают ютубовскую строку: из инфостроки пропали названия каналов,
            # потом даты. Здесь только своё свойство, которого не знает никто,
            # кроме условия галочки, - оно не может задеть ни одну другую строку.
            li.setProperty('SublimeVideoRow', 'true')
        media = row.get('type') or row.get('mediatype') or ''
        if media and media != 'unknown':
            try:
                tag.setMediaType(media)
            except Exception:
                pass
        resume = row.get('resume') or {}
        try:
            position = float(resume.get('position') or 0)
            total = float(resume.get('total') or 0)
            if position > 0 and total > 0:
                tag.setResumePoint(position, total)
                # «Воспроизвести с начала» у начатого ролика YouTube (владелец
                # 14.11.2026): у фильмов Filmix этот пункт даёт Kodi, у роликов
                # YouTube рядом с «Продолжить с ...» его нет, а «Сбросить
                # позицию» - пункт самого дополнения и воспроизведения не
                # запускает.
                if 'plugin.video.youtube' in str(row.get('file') or ''):
                    li.addContextMenuItems([(
                        tr(31925),
                        'PlayMedia(%s,noresume)' % row.get('file'))])
        except Exception:
            pass
        # Everything the builder finished for this row travels with it, as
        # ordinary list-item properties. The skin reads them directly, which is
        # what removes Python from the hot path entirely.
        for name, value in mirror.row_properties(row).items():
            li.setProperty(name, value)
        _set_release_props(li, row)
        built = row.get('sublime') or {}
        if built:
            for name, value in _row_rating_props(built, row.get('mediatype') or row.get('type')).items():
                li.setProperty(name, value)
            for name, value in _row_info_props(built, row).items():
                li.setProperty(name, value)
        is_folder = str(row.get('filetype') or 'file') != 'file'
        xbmcplugin.addDirectoryItem(handle, row.get('file') or '', li, is_folder)
    xbmcplugin.setContent(handle, 'videos')
    xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
    return True


def _art_by_key():
    """Обложки и подложки строк из уже собранных полос (снимки), по ключу фильма/сериала."""
    out = {}
    try:
        for _src, rows in mirror.iter_snapshots():
            for row in rows or []:
                art = row.get('art') or {}
                if not isinstance(art, dict) or not (art.get('poster') or art.get('thumb')):
                    continue
                title = row.get('tvshowtitle') or row.get('title') or row.get('label') or ''
                key = identity.show_key(title, row.get('year'))
                if key and key not in out:
                    out[key] = row
    except Exception as exc:
        log('продолжить просмотр: обложки не собраны: %s' % exc, xbmc.LOGDEBUG)
    return out


def _continue_youtube(handle):
    """«Продолжить просмотр» хаба YouTube: недосмотренные ролики, самые свежие первыми.
    Название и обложка - из собранных полос YouTube, иначе из сведений hub/youtube_meta."""
    from . import youtube_meta
    started = []
    for row in history.in_progress(limit=200):
        vid = youtube_meta.video_id(row.get('path') or '')
        if vid and vid not in [v for v, _ in started]:
            started.append((vid, row))
    known = {}
    try:
        for _src, snap in mirror.iter_snapshots():
            for item in snap or []:
                vid = youtube_meta.video_id(item.get('file') or '')
                if vid and vid not in known and (item.get('title') or item.get('label')):
                    known[vid] = item
    except Exception as exc:
        log('продолжить просмотр YouTube: полосы не прочитаны: %s' % exc, xbmc.LOGDEBUG)
    cached = youtube_meta.video_titles([v for v, _ in started if v not in known])
    rows = []
    for vid, row in started:
        item = dict(known.get(vid) or {})
        title = item.get('title') or item.get('label') or cached.get(vid) or ''
        if not title:
            continue                        # без названия плитка - голый адрес, её не показываем
        item.update({'label': title, 'title': title, 'file': row.get('path'), 'filetype': 'file',
                     '_position': float(row.get('position') or 0), '_total': float(row.get('total') or 0)})
        item.setdefault('mediatype', 'video')
        if not (item.get('art') or {}).get('thumb'):
            item['art'] = {'thumb': 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % vid,
                           'icon': 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % vid}
        rows.append(item)
        if len(rows) >= get_int('widget_size', 30):
            break
    return _publish_stored_rows(handle, rows)


CONTINUE_ART = 'special://profile/addon_data/skin.sublime/continue_art.json'


def _continue_art(rows, budget=8.0):
    """Постеры «Продолжить просмотр» для строк без картинки. Полосы после переустановки
    пусты, и плитки шли серыми (.20, 17.11.2026). Тот же поиск сведений, что у полос
    (builder._resolve: TMDb из кэша метаданных скина), с бюджетом по времени; найденное
    запоминается на диске, второй показ - мгновенный."""
    import time as _time
    import xbmcvfs
    path = xbmcvfs.translatePath(CONTINUE_ART)
    try:
        with open(path, encoding='utf-8') as fh:
            cache = json.load(fh)
    except Exception:
        cache = {}
    changed, started = False, _time.time()
    for row in rows:
        art = row.get('art') or {}
        if art.get('poster') or art.get('thumb'):
            continue
        key = identity.show_key(row.get('title') or row.get('label') or '', row.get('year'))
        hit = cache.get(key)
        if hit and not hit.get('_miss'):
            row['art'] = dict((k, v) for k, v in hit.items() if not k.startswith('_'))
            # без логотипа - перепроверить раз в сутки (логотип мог появиться), картинки пока свои
            if hit.get('clearlogo') or _time.time() - float(hit.get('_t') or 0) < 86400:
                continue
        if hit and _time.time() - float(hit.get('_miss') or 0) < 86400:
            continue                    # не нашлось меньше суток назад
        if _time.time() - started > budget:
            continue
        try:
            # как при наведении: с поиском по Кинопоиску (строк здесь единицы, найденное
            # запоминается) - TMDb по одному русскому названию находит не всё
            # («Таежная повесть» 1979, «Река гнева» 2024 на .20 17.11.2026)
            from . import builder
            from ..sublime_helper.core import fetch_online_metadata
            probe = dict(row, filetype='file', mediatype=row.get('mediatype') or 'movie')
            meta = (fetch_online_metadata({}, builder._local_from_row(probe)) or {})                 if builder._enrichable(probe) else {}
        except Exception as exc:
            log('продолжить просмотр: сведения не найдены: %s' % exc, xbmc.LOGDEBUG)
            meta = {}
        found = {k: v for k, v in (meta.get('art') or {}).items()
                 if k in ('poster', 'fanart', 'landscape', 'clearlogo', 'thumb') and v}
        if found.get('poster') and not found.get('thumb'):
            found['thumb'] = found['poster']
        if found and not found.get('clearlogo'):
            found['_t'] = int(_time.time())
        cache[key] = found or {'_miss': int(_time.time())}
        changed = True
        if found:
            row['art'] = dict((k, v) for k, v in found.items() if not k.startswith('_'))
    if changed:
        try:
            with open(path + '.tmp', 'w', encoding='utf-8') as fh:
                json.dump(cache, fh, ensure_ascii=False)
            os.replace(path + '.tmp', path)
        except Exception as exc:
            log('продолжить просмотр: постеры не записаны: %s' % exc, xbmc.LOGDEBUG)


def _continue_source_rows(rows):
    """Сведения строки «Продолжить просмотр» - из записи самого источника, как в полосах.
    База просмотров даёт только название и адрес, и у фильма не было описания: TMDb по
    русскому названию новинку часто не находит («Иисус из Лос-Анджелеса», «Река гнева»,
    .20, 19.11.2026), а у Filmix описание есть в его же базе. Строка источника проходит
    тот же lanes._entries, что у полос; заполняется только то, чего у строки нет."""
    try:
        found = catalog.rows_for_paths([row.get('file') or '' for row in rows])
    except Exception as exc:
        log('продолжить просмотр: записи источника не прочитаны: %s' % exc, xbmc.LOGDEBUG)
        return
    for row in rows:
        source = found.get(row.get('file') or '')
        if not source:
            continue
        entries = lanes._entries([(None, source)], '', {}, 1)
        if not entries:
            continue
        entry = entries[0]
        for field, value in entry.items():
            if field in ('file', 'filetype', 'mediatype', 'label', 'title'):
                continue
            if field == 'art':
                art = row.get('art') or {}
                if not (art.get('poster') or art.get('thumb')):
                    row['art'] = dict(value, **art)
                continue
            if value and not row.get(field):
                row[field] = value


def _drop_caught_up(rows):
    """Сериал, у которого просмотрены все вышедшие серии, продолжать нечем. Filmix -
    счёт значка (catalog.provider_show_states), HDRezka и Elementum - просмотренные серии
    в Kodi против вышедших по TMDb."""
    ids = [str(r.get('post_id')) for r in rows
           if r.get('post_id') and r.get('mediatype') == 'tvshow'
           and 'plugin.video.filmix/' in str(r.get('file') or '')]
    states = {}
    if ids:
        try:
            states = catalog.provider_show_states(ids) or {}
        except Exception as exc:
            log('продолжить просмотр: счёт серий не прочитан: %s' % exc, xbmc.LOGDEBUG)
    others = [r for r in rows if r.get('mediatype') == 'tvshow'
              and str(r.get('post_id') or '') not in states]
    watched = history.watched_episode_counts() if others else {}
    try:
        totals = _show_totals(others) if others else {}
    except Exception:
        totals = {}
    kept = []
    for row in rows:
        own = states.get(str(row.get('post_id') or ''))
        if (own and own.get('counted') and int(own.get('watched') or 0) > 0
                and int(own.get('unwatched') or 0) <= 0):
            continue
        if own is None and row.get('mediatype') == 'tvshow':
            key = identity.show_key(row.get('label'), row.get('year'))
            seen, total = int(watched.get(key) or 0), int(totals.get(key) or 0)
            if seen and total and seen >= total:
                continue
        kept.append(row)
    return kept


def _addon_installed(path):
    import re as _re
    hit = _re.match(r'plugin://([^/?]+)', path)
    if not hit:
        return True
    try:
        return bool(xbmc.getCondVisibility('System.HasAddon(%s)' % hit.group(1)))
    except Exception:
        return True


def hub_continue(handle, params):
    """Начатое из общей базы просмотров (все источники). Только фильмы и сериалы:
    без роликов YouTube и безымянных адресов; сериал - одной строкой с последней
    начатой серией; вкладка «Фильмы» - фильмы, «Сериалы» - сериалы."""
    category = params.get('category') or ''
    if category == 'youtube':
        return _continue_youtube(handle)
    rows, seen = [], set()
    art_index = None
    # досмотренное сюда не попадает: сериал с отметкой «просмотрен» (на .20 17.11.2026
    # «Король Талсы» и «Вавилон-Берлин» стояли с галочкой) - и фильм, и сериал
    finished = {k for k, v in history.playcounts().items() if v > 0}
    candidates = list(history.in_progress(limit=200))
    if category != 'movies':
        # Сериал продолжают и после досмотренной до конца серии: у «Полураспада» серии
        # 1-6 досмотрены, 7-я не начата - точки остановки нет, и сериал в полосу не
        # попадал, а наверху стояли сериалы с недосмотренной в августе первой серией
        # (.20, 19.11.2026). Досмотренные серии - тем же порядком, по последнему просмотру.
        candidates += [r for r in history.recent_watched(limit=2000, mediatype='episode')
                       if r.get('parent_key')]
        candidates.sort(key=lambda r: r.get('last_watched') or 0, reverse=True)
    for row in candidates:
        key = row.get('item_key') or ''
        path = row.get('path') or ''
        if not key or key.startswith('path|') or 'plugin.video.youtube' in path:
            continue
        mediatype = row.get('mediatype') or ''
        is_episode = mediatype == 'episode'
        if category == 'movies' and mediatype != 'movie':
            continue
        if category == 'shows' and mediatype not in ('episode', 'tvshow'):
            continue
        group = row.get('parent_key') if is_episode else key
        if not group or group in seen or group in finished:
            continue                        # одна строка на фильм/сериал - самая свежая
        seen.add(group)
        if art_index is None:
            art_index = _art_by_key()
        position = float(row.get('position') or 0)
        total = float(row.get('total') or 0)
        label = row.get('label') or ''
        year = row.get('year') or ''
        if not year:
            # год есть в адресе Filmix и HDRezka (…-2025/ или …-2025-latest.html); без него
            # TMDb не опознаёт фильм и плитка остаётся без постера
            hit = re.search(r'-((?:19|20)\d{2})(?:-latest)?(?:\.html|/|$)', unquote(path))
            year = hit.group(1) if hit else ''
        item = {
            'label': label,
            'title': label,
            'file': path,
            'year': year,
            'mediatype': 'episode' if is_episode else (mediatype or 'movie'),
            'filetype': 'file',
            'genre': [], 'country': [],
            '_position': position, '_total': total,
            'art': dict((art_index.get(group) or {}).get('art') or {}),
        }
        if is_episode:
            # сериал - той же строкой, что в «Все» и других полосах (строка полосы целиком: адрес
            # сериала, post_id, счёт серий), иначе значок «начат / N непросмотренных» не совпадал
            # (владелец 17.11.2026, «Город бога»: в «Все» 8, в «Продолжить просмотр» пусто)
            same = art_index.get(group)
            if same:
                item = dict(same)
            else:
                item['file'] = path.split('/play/')[0] + '/open/' if '/serials/' in path else path
            # тип и post_id - как у строк полосы: по ним считается «начат / N непросмотренных»
            item.update(mediatype='tvshow', filetype='directory')
            item.pop('_position', None)
            item.pop('_total', None)
            post = re.search(r'plugin\.video\.filmix/serials/(\d+)-', str(item.get('file') or path))
            if post and not item.get('post_id'):
                item['post_id'] = post.group(1)
        rows.append(item)
        if len(rows) >= get_int('widget_size', 30):
            break
    rows = _drop_caught_up(rows)
    _continue_source_rows(rows)
    _continue_art(rows)
    content = 'tvshows' if category == 'shows' else 'movies'
    # история общая для коробок: строки дополнений, которых на этой коробке нет, открыть нечем
    # (Filmix в «Продолжить просмотр» сетапа с HDRezka/Elementum, .20, 21.11.2026)
    rows = [r for r in rows if _addon_installed(str(r.get('file') or ''))]
    return _publish_rows(handle, rows, category or 'movies', content)


def hub_root(handle, params):
    for name in sorted(lanes.LANES):
        title = lanes.lane_title(name)
        li = xbmcgui.ListItem(label=title, offscreen=True)
        xbmcplugin.addDirectoryItem(handle, _url('hub_lane', name=name), li, True)
    for category, title in (('movies', tr(31912)),
                            ('shows', tr(31913))):
        li = xbmcgui.ListItem(label=title, offscreen=True)
        xbmcplugin.addDirectoryItem(handle, _url('hub_widget', category=category),
                                    li, True)
    li = xbmcgui.ListItem(label=tr(31914), offscreen=True)
    xbmcplugin.addDirectoryItem(handle, _url('hub_continue'), li, True)
    li = xbmcgui.ListItem(label=tr(31915), offscreen=True)
    li.setArt({'icon': 'DefaultAddonProgram.png'})
    xbmcplugin.addDirectoryItem(handle, _url('hub_settings'), li, False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
    return True


def _refresh(category=''):
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass


def _paths(params):
    """One path, or many - a whole season is one action to the user.

    The provider passes every episode path of the season it is marking, because
    Kodi keys by path and there is no such thing as a season row in its
    database. Newline-separated: paths contain almost everything else.
    """
    raw = params.get('paths') or params.get('path') or ''
    return [p for p in (part.strip() for part in raw.splitlines()) if p]


def hub_mark_watched(handle, params):
    """One writer: Kodi. The tick the skin draws and the resume the player
    offers then cannot disagree, because they are the same row."""
    done = 0
    for path in _paths(params):
        if history.mark_watched(path):
            done += 1
    if done:
        xbmcgui.Dialog().notification(
            tr(31926),
            params.get('label') or (tr(31927) % done if done > 1 else ''),
            xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh(params.get('category'))
    return True


def hub_mark_unwatched(handle, params):
    done = 0
    for path in _paths(params):
        if history.is_episode_path(path):
            if history.clear_watched(path):
                done += 1
        # сериал целиком - все его серии (у папки сериала своих отметок нет)
        elif history.clear_watched_show(path, params.get('label') or '', params.get('year') or ''):
            done += 1
        elif history.clear_watched(path):
            done += 1
    if done:
        xbmcgui.Dialog().notification(
            tr(31928),
            params.get('label') or (tr(31927) % done if done > 1 else ''),
            xbmcgui.NOTIFICATION_INFO, 2000)
    _refresh(params.get('category'))
    return True


def hub_feedback(handle, params):
    kind = params.get('kind') or ''
    label = identity.clean_label(params.get('label'))
    if kind not in ('like', 'dislike') or not label:
        return True
    year = params.get('year') or ''
    item_key = identity.show_key(label, year)
    if not item_key:
        return True
    db().set_feedback(item_key, kind, label=label, genres=params.get('genre') or '',
                      countries=params.get('country') or '', year=year,
                      mediatype=params.get('mediatype') or '')
    xbmcgui.Dialog().notification(
        tr(31929), tr(31930) if kind == 'like' else tr(31931),
        xbmcgui.NOTIFICATION_INFO, 2000)
    category = params.get('category') or ''
    if category:
        try:
            recommend.refresh_category(category, force=True)
        except Exception as exc:
            log('пересборка после оценки не удалась: %s' % exc, xbmc.LOGWARNING)
    _refresh(category)
    return True


def hub_why(handle, params):
    label = params.get('label') or ''
    reasons = params.get('reasons') or ''
    xbmcgui.Dialog().textviewer(
        label or tr(31932),
        reasons.replace(' • ', '\n') or tr(31933))
    return True


def hub_rebuild(handle, params):
    for category in ('movies', 'shows'):
        try:
            recommend.refresh_category(category, force=True)
        except Exception as exc:
            log('пересборка %s не удалась: %s' % (category, exc), xbmc.LOGWARNING)
    for category in ('movies', 'shows'):
        try:
            lanes.build_lanes(category)
        except Exception as exc:
            log('полосы %s не собраны: %s' % (category, exc), xbmc.LOGWARNING)
    xbmcgui.Dialog().notification(tr(31934), tr(31935),
                                  xbmcgui.NOTIFICATION_INFO, 2500)
    return True


def hub_import_history(handle, params):
    """One-off: put the history that predates Kodi holding it into Kodi."""
    from . import import_legacy
    result = import_legacy.run()
    if not result.get('total'):
        xbmcgui.Dialog().notification(tr(31934), tr(31936),
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    xbmcgui.Dialog().notification(
        tr(31934), tr(31937) % (result['written'], result['total']),
        xbmcgui.NOTIFICATION_INFO, 4000)
    return True


def hub_sync_now(handle, params):
    ok = False
    try:
        ok = sync.run_once(force=True)
    except Exception as exc:
        log('обмен не удался: %s' % exc, xbmc.LOGWARNING)
    xbmcgui.Dialog().notification(tr(31934), tr(31938) if ok else tr(31939),
                                  xbmcgui.NOTIFICATION_INFO, 2500)
    return True


def hub_repair_paths(handle, params):
    """Give the shared history the paths it is missing (see hub/repair.py)."""
    from . import repair
    report = repair.run()
    if report.get('ok'):
        message = (tr(31940)
                   % (report.get('fixed') or 0, report.get('missing') or 0,
                      report.get('applied') or 0))
    else:
        message = report.get('reason') or tr(31941)
    xbmcgui.Dialog().notification(tr(31942), message,
                                  xbmcgui.NOTIFICATION_INFO, 4000)
    return True


def hub_settings(handle, params):
    """The hub's own settings, including where its materials live."""
    from . import settings_ui
    return settings_ui.route(handle, params)


ROUTES = {
    'hub_lane': hub_lane,
    'hub_mirror': hub_mirror,
    'hub_subs': hub_subs,
    'hub_trending': hub_trending,
    'hub_ytlane': hub_ytlane,
    'hub_ytsearch': hub_ytsearch,
    'hub_search': hub_search,
    'hub_wrap': hub_wrap,
    'hub_widget': hub_widget,
    'hub_continue': hub_continue,
    'hub_smart': hub_smart,
    'hub_root': hub_root,
    'hub_feedback': hub_feedback,
    'hub_mark_watched': hub_mark_watched,
    'hub_mark_unwatched': hub_mark_unwatched,
    'hub_why': hub_why,
    'hub_rebuild': hub_rebuild,
    'hub_sync_now': hub_sync_now,
    'hub_import_history': hub_import_history,
    'hub_settings': hub_settings,
    'hub_repair_paths': hub_repair_paths,
}


def run(handle, params):
    info = params.get('info') or params.get('action') or ''
    handler = ROUTES.get(info)
    if handler is None:
        return False
    # Готовую выдачу (hub/listing_cache.py) точка входа плагина отдаёт раньше, без импорта этого
    # модуля (vcl_variables_plugin.py); сюда доходит только пересчёт.
    return bool(handler(handle, params))
