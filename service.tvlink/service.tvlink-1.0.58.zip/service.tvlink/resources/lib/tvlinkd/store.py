"""Files of the daemon. Everything lives in the add-on's userdata folder."""
import json
import os
import tempfile
import time

DEFAULTS = {
    "host": "127.0.0.1",          # host written into the playlist for streams and logos
    "port": 2020,                 # playlist / xmltv / logos (pvr.tvlink default)
    "stream_port": 2021,          # MPEG-TS streams
    "user_agent": "SmartSDK",
    "playlists": [],              # [{name, url, catchup, days}], order = priority
    "epg": [],                    # [{name, url}], order = priority
    "epg_from_playlist": True,    # also take url-tvg / x-tvg-url from playlist headers
    "refresh_hours": 8,
    "epg_past_days": 1,           # these three come from Kodi's TV settings
    "epg_future_days": 3,
    "epg_interval_min": 720,
    "archive_days": 8,
    "strip_suffixes": ["orig"],
    "logo_pack": "http://epg.one/epgone_transparent_logo.zip",
    # same style, more channels: the guide's channel list (display names + icon), only its head is read
    "logo_guide": "https://iptvx.one/EPG",
    "auto_add": True,             # fallback when a playlist entry has no add_new
    "live_edge": 2,               # HLS segments behind live when a stream starts
    "timeout": 5,                 # seconds per upstream request
    "switch_after": 12,           # seconds without data before the next source is tried
    "min_group": 7,               # groups with fewer channels are dissolved (channels stay in "all")
    "logo_mixed": False,          # False: only the pack's logos (one style); True: playlist logos as fallback
}


class Paths:
    def __init__(self, root):
        self.root = root
        self.cache = os.path.join(root, "cache")
        self.logos = os.path.join(root, "logos")
        for d in (self.root, self.cache, self.logos):
            os.makedirs(d, exist_ok=True)
        self.config = os.path.join(root, "config.json")
        self.channels = os.path.join(root, "channels.json")
        self.status = os.path.join(root, "status.json")
        self.log = os.path.join(root, "tvlinkd.log")
        self.playlist = os.path.join(self.cache, "playlist.m3u")
        self.xmltv = os.path.join(self.cache, "xmltv.xml.gz")
        self.clients = os.path.join(self.cache, "xmltv.clients.json")

    def source(self, name):
        return os.path.join(self.cache, "src_%s.m3u" % _safe(name))

    def epg_source(self, name):
        return os.path.join(self.cache, "epg_%s.xml.gz" % _safe(name))


def _safe(name):
    return "".join(c if c.isalnum() or c in "-_" else "_" for c in name) or "x"


def read_json(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def write_atomic(path, data, binary=False):
    d = os.path.dirname(path)
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".tmp_")
    try:
        with os.fdopen(fd, "wb" if binary else "w", **({} if binary else {"encoding": "utf-8"})) as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def write_json(path, obj):
    write_atomic(path, json.dumps(obj, ensure_ascii=False, indent=1))


def load_config(paths):
    cfg = dict(DEFAULTS)
    cfg.update(read_json(paths.config, {}) or {})
    return cfg


def mtime(path):
    try:
        return os.path.getmtime(path)
    except OSError:
        return 0.0


def age_hours(path):
    m = mtime(path)
    return (time.time() - m) / 3600.0 if m else 1e9
