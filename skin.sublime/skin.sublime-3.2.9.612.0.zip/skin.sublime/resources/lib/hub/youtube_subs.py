# -*- coding: utf-8 -*-
"""Своя лента подписок YouTube - из ленты подписок дополнения, по входу в аккаунт.

Дополнение YouTube (с версии 8) ключей Data API не знает вовсе: после входа по коду
телевизора оно отдаёт готовую ленту новых видео всех каналов подписки с описаниями
(browse?id=FEsubscriptions); hub/youtube_tvfeed.py добавляет к ней точное время и
крупную обложку, новое сверху.

Прежде (дополнение 7) лента собиралась из плейлистов загрузок каждого канала через Data API
ключом владельца, а список каналов - из `subscriptions/list` дополнения. В 8 у дополнения нет
ни ключа, ни этого списка в прежнем виде (каналы - адреса browse?id=UC...), поэтому тот путь
убран целиком (26.11.2026, переход на дополнение 8).

Снимок ленты (mirror, SRC) показывается сразу; служба обновляет его по заявке запроса виджета
(refresh_if_stale) и по своим часам. Обогащение сборщика и крупные обложки, добытые в сети,
переносятся со старых строк (_store_feed).
"""
from __future__ import absolute_import, unicode_literals

import json
import threading
import time

import xbmc

from . import mirror
from .config import log
from ..sublime_helper import tls as _tls

_tls.install()   # https при испорченном хранилище сертификатов системы (Windows)

# Ключ снимка склеенной ленты. Это НЕ адрес для Kodi: строку никто не открывает,
# она только даёт снимку имя файла (mirror._file считает от неё хеш).
SRC = 'sublime://youtube_subs'
# Сколько строк в ленте.
LIMIT = 60
# Бюджет одного прохода (служба, fill_caches): страница подписок - один-три запроса.
BUDGET_SECONDS = 90
# Сколько строк за раз поднимает качество картинок (upgrade_pass).
UPGRADE_LIMIT = 10
# Из них - сколько подложек пересобирать за проход. Скачивание картинки идёт
# через xbmcvfs.copy, у которого таймаута нет: 05.09.2026 на .20 поток залип на
# нём и заблокировал все следующие проходы - в ленте осталось 15 строк с низким
# фоном, хотя крупная картинка у них есть. Тяжёлую часть держим малой, а служба
# больше не полагается на один поток (service.py, upgrade_thread).
UPGRADE_BUILD_LIMIT = 4


def _when(row):
    return str((row or {}).get('premiered')
               or (row or {}).get('dateadded') or '')


def _upgrade_art(fresh):
    """Взять самую крупную из существующих обложек ролика.

    Здесь и сейчас, потому что проход ленты - фоновая работа с сетью, а
    посточечная сборка до дальних строк не доходит: она обрывается по занятости
    коробки. Замер на .20 05.09.2026: 31 строка ленты из 60 несла hqdefault
    (480x360) и как обложку, и как источник подложки, а подложка 1920x1080
    строилась растягиванием вчетверо - владелец назвал это «ужасным качеством
    фона». В «Рекомендациях», которые обходит сборщик, подложек из maxres было
    46 из 50, то есть дело не в сборщике, а в том, что до строки он не дошёл.

    Если картинка стала крупнее, готовая подложка больше не годится - она
    построена из мелкой. Блок снимается, и сборщик делает подложку заново.
    """
    art = dict(fresh.get('art') or {})
    if not art:
        return fresh
    changed = False
    for key, value in list(art.items()):
        better = mirror.youtube_art_fallback(value, probe=mirror.probe_art)
        if better != value:
            art[key] = better
            changed = True
    if changed:
        fresh['art'] = art
        fresh.pop('sublime', None)
    return fresh


def _art_rank(value):
    """Насколько крупна обложка YouTube. Меньше - крупнее; -1 - не про YouTube."""
    text = str(value or '')
    for index, name in enumerate(mirror._YT_BEST):
        if name in text:
            return index
    return -1


def _keep_better_art(fresh, previous):
    """Оставить строке ту обложку, которая крупнее.

    Зачем. Сбор ленты берёт строки у дополнения заново, а оно отдаёт hqdefault
    (480x360) даже там, где есть maxresdefault - и это затирало работу сборщика,
    который крупную обложку уже нашёл и проверил в сети. Замер на .30
    05.09.2026: подложки построены из maxres у 59 строк из 60, а обложки самих
    плиток скатились обратно в hqdefault у 23. Владелец видел это как «ужасное
    качество фонов».

    Сравниваются только имена обложек YouTube одного и того же ролика, поэтому
    подменить картинку на чужую здесь нечем.
    """
    old_art = (previous or {}).get('art') or {}
    new_art = dict(fresh.get('art') or {})
    changed = False
    for key, old_value in old_art.items():
        if key == 'clearlogo':
            # Ни при каких условиях - см. _videos.
            continue
        old_rank = _art_rank(old_value)
        if old_rank < 0:
            continue
        new_rank = _art_rank(new_art.get(key))
        if new_rank < 0 or old_rank < new_rank:
            new_art[key] = old_value
            changed = True
    if changed:
        fresh['art'] = new_art
    return fresh


def _store_feed(unique):
    """Сохранить ленту, перенеся обогащение сборщика со старых строк."""
    # Готовое не выбрасываем. Сборщик (hub/builder.py) дописывает в строку
    # подложку, цвет и логотип, а склейка идёт своими часами и перезаписывает
    # снимок целиком: замер на .20 04.09.2026 - в ленте 60 строк и НОЛЬ
    # обогащённых, потому что каждый сбор стирал работу сборщика. Обогащение
    # переносится по пути строки, как это делает и сам сборщик.
    previous_rows = {}
    try:
        stored, _stamp = mirror.load(SRC)
        for row in stored or []:
            key = str((row or {}).get('file') or '')
            if key:
                previous_rows[key] = row
    except Exception:
        previous_rows = {}
    kept = 0
    for row in unique:
        was = previous_rows.get(str(row.get('file') or ''))
        if not was:
            continue
        # Крупная обложка так же ценна, как готовая подложка: и то и другое
        # сборщик добыл в сети, и сбор ленты не должен это стирать.
        _keep_better_art(row, was)
        if row.get('sublime'):
            continue
        ready = (was.get('sublime') or {})
        if ready:
            row['sublime'] = ready
            kept += 1
    if kept:
        log('подписки YouTube: перенесено готовых строк %d' % kept,
            xbmc.LOGDEBUG)
    mirror.store(SRC, unique)
    return len(unique)


def refresh(cancel=None, budget=BUDGET_SECONDS, force=False):
    """Собрать ленту со страницы подписок телевизора и сохранить.

    Возвращает (1, строк в ленте) при удаче, иначе (0, 0). Без входа в аккаунт в дополнении
    YouTube лента не собирается: подписки - личные. cancel, budget и force - для совместимости с
    вызывающими (служба, fill_caches): страница подписок - один-три запроса, бюджета хватает.
    """
    from . import youtube_tvfeed
    if not youtube_tvfeed.signed_in():
        log('подписки YouTube: нет входа в дополнении YouTube - ленту не собираю', xbmc.LOGDEBUG)
        return 0, 0
    fresh = youtube_tvfeed.subscriptions(LIMIT)
    if not fresh:
        return 0, 0
    if _FEED_LOCK.acquire(timeout=FEED_LOCK_WAIT):
        try:
            total = _store_feed(fresh)
        finally:
            _FEED_LOCK.release()
        log('подписки YouTube: строк в ленте %d' % total)
        return 1, total
    log('подписки YouTube: снимок занят другим проходом, сохранение отложено', xbmc.LOGWARNING)
    return 0, 0


def _needs_upgrade(row):
    """Есть ли у строки картинка, которую можно взять крупнее."""
    if (row or {}).get('_art_checked'):
        return False
    art = (row or {}).get('art') or {}
    for value in art.values():
        text = str(value or '')
        if 'i.ytimg.com' not in text:
            continue
        if mirror._YT_BEST[0] not in text:
            return True
    return False


# Замок на снимок ленты. Его берёт КАЖДЫЙ, кто переписывает снимок
# целиком: склейка после сбора (assemble), подъём качества обложек
# (upgrade_pass) и обогащение строк сборщиком (hub/builder.build_ours).
#
# Раньше хватало одного: сбор и обогащение шли на одном и том же
# потоке службы и потому не могли встретиться. С сбор идёт в
# своём потоке (hub/service.py - там замер), и без замка последний
# записавший стирал бы работу остальных - готовые подложки и крупные
# обложки, добытые в сети.
_FEED_LOCK = threading.Lock()
# Столько ждём чужой проход, прежде чем отложить склейку до следующего раза.
FEED_LOCK_WAIT = 30


def feed_lock():
    """Замок снимка ленты - для тех, кто пишет его снаружи этого файла."""
    return _FEED_LOCK


def upgrade_pass(limit=UPGRADE_LIMIT, cancel=None):
    """Поднять качество картинок у нескольких строк ленты и пересобрать подложку.

    Отдельно от общего прохода и БЕЗ требования простоя. Так пришлось сделать по
    факту: замер на .20 05.09.2026 - коробка в руках владельца, проход ленты
    ждёт минуты молчания пульта и не выполняется ни разу за час, а в ленте 31
    строка из 60 с hqdefault (480x360) и подложкой, растянутой из неё вчетверо.
    Владелец назвал это «фоны низкого разрешения» и был прав.

    Работа тут дешёвая и вся в сети: HEAD-запрос «есть ли картинка крупнее»
    (mirror.probe_art, один вопрос на адрес за сеанс) и, если есть, пересборка
    размытой подложки из неё. Поэтому проход идёт малыми порциями и его можно
    держать на коротких часах; служба зовёт его в отдельном потоке, чтобы не
    задерживать публикацию строки под курсором.

    Возвращает, сколько строк поправлено.
    """
    if not _FEED_LOCK.acquire(blocking=False):
        # Прошлый проход ещё не закончил. Два прохода на один снимок писать
        # нельзя: они затрут работу друг друга.
        return 0
    try:
        return _upgrade_locked(limit, cancel)
    finally:
        _FEED_LOCK.release()


def _upgrade_locked(limit, cancel):
    kept, _stamp = mirror.load(SRC)
    if not kept:
        return 0
    from . import builder
    done = 0
    built = 0
    changed = False
    for row in kept:
        if done >= max(1, int(limit)):
            break
        if cancel is not None:
            try:
                if cancel():
                    break
            except Exception:
                pass
        if not _needs_upgrade(row):
            continue
        before = json.dumps(row.get('art') or {}, sort_keys=True)
        _upgrade_art(row)
        after = json.dumps(row.get('art') or {}, sort_keys=True)
        if before == after:
            # Крупнее не существует - помечаем строку, чтобы не спрашивать
            # сервер о ней снова на каждом проходе.
            row['_art_checked'] = True
            changed = True
            continue
        art = row.get('art') or {}
        source = str(art.get('fanart') or art.get('thumb')
                     or art.get('landscape') or art.get('poster') or '')
        block = dict(row.get('sublime') or {})
        if source:
            block['background'] = source
            block['fanart'] = source
            if built < max(1, int(UPGRADE_BUILD_LIMIT)):
                prepared = builder._background(source)
                built += 1
                if prepared:
                    block['prepared'] = prepared
                    block['wash'] = builder._wash_colour(prepared)
            else:
                # Подложку сделает следующий проход или сборщик: адрес уже
                # правильный, а тяжёлую работу за один заход не гоним.
                block.pop('prepared', None)
            row['sublime'] = block
        done += 1
        changed = True
    if changed:
        mirror.store(SRC, kept)
    if done:
        log('подписки YouTube: качество картинок поднято у %d строк' % done)
    return done

# Сколько лента может простоять, прежде чем её запрос сам вызовет сбор. Четверть часа - как у
# прохода зеркала (hub/service.MIRROR_REFRESH_SECONDS).
FEED_TTL = 15 * 60
REQUEST_FLAG = 'subs_refresh_requested'


def request_refresh():
    """Попросить СЛУЖБУ собрать ленту. Возвращает True, если заявка записана.

    Почему заявка, а не сбор на месте и не поток.

    Маршрут виджета выполняется в отдельном коротком процессе плагина: Kodi
    запускает его, забирает список и выгружает. Первая версия этой правки
    заводила там поток - и он умирал вместе с процессом: замер на .20
    05.09.2026, запрос вернул 60 строк и записал «запрос виджета завёл сбор», а
    снимок спустя 130 секунд остался того же возраста, потому что до склейки
    дело не дошло. Собирать на месте тоже нельзя: тридцать запросов по сети -
    это не то, что виджет может заставить себя ждать.

    Поэтому запрос лишь ставит отметку в общей базе, а выполняет её служба -
    процесс, который живёт всё время. И выполняет БЕЗ гейтов по занятости: если
    человек открыл хаб, значит лента нужна ему сейчас.
    """
    try:
        from .store import db
        db().set_flag(REQUEST_FLAG, str(int(time.time())))
        return True
    except Exception as exc:
        log('заявка на сбор ленты не записана: %s' % exc, xbmc.LOGWARNING)
        return False


def refresh_requested_at():
    """Когда просили собрать ленту. 0 - не просили."""
    try:
        from .store import db
        return int(db().get_flag(REQUEST_FLAG) or 0)
    except Exception:
        return 0


def clear_request():
    try:
        from .store import db
        db().set_flag(REQUEST_FLAG, '0')
    except Exception as exc:
        log('заявка на сбор ленты не снята: %s' % exc, xbmc.LOGDEBUG)


def refresh_if_stale():
    """Отдать ленту и, если снимок устарел, попросить службу её собрать.

    Зовётся САМИМ запросом виджета - так же, как полосы каталога доливает их
    собственный запрос (lanes.top_up_if_stale). Полосы свежие именно поэтому:
    открыл хаб - полоса обновилась. У ленты подписок этого не было, она целиком
    зависела от фонового прохода, а у того есть гейты по занятости, и за два дня
    они подвели трижды по трём разным причинам: проход не шёл при
    воспроизведении; проход держал поток публикации; проход встал вместе с
    зеркалом и обменом на три часа при простаивающей коробке.

    Разница с полосами одна: долив полосы - две таблицы sqlite и его можно
    сделать здесь же, а сбор ленты - сеть, и его делает служба по заявке.
    Показ остаётся прежним, следующий будет свежим.
    """
    kept, stamp = mirror.load(SRC)
    age = time.time() - float(stamp or 0)
    if not kept or age >= FEED_TTL:
        if request_refresh():
            log('подписки YouTube: снимок устарел на %d с, заявка службе на '
                'сбор' % int(age if kept else 0))
    return kept or []


def rows():
    """Строки ленты для маршрута. Устаревший снимок обновляется сам."""
    return refresh_if_stale()


def stored_rows():
    """Только то, что лежит в снимке. Для сборщика: ему нужно обогатить то, что
    есть, а не заводить сбор."""
    kept, _stamp = mirror.load(SRC)
    return kept or []


def stamp():
    return mirror.stamp_of(SRC)
