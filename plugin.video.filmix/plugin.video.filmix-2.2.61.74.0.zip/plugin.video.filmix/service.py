# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import json
import hashlib
import os
import threading
import time

import simplemedia
import xbmc
import xbmcvfs
from future.utils import python_2_unicode_compatible, iteritems
from simplemedia import py2_decode, Addon

from resources.libs.cache import FilmixCache
from resources.libs.web import Filmix, FilmixError, signed_in, set_background_process
from resources.libs import kodi_link
from resources.libs.prewarm import FilmixPrewarm
from resources.libs.manual_overrides import apply_manual_overrides_to_cache


def _manifest_version(fallback=''):
    """The version Kodi actually installed, for the STARTUP marker line."""
    try:
        import xbmcaddon
        return xbmcaddon.Addon(id='plugin.video.filmix').getAddonInfo('version') or fallback
    except Exception:
        return fallback


BUILD_VERSION = _manifest_version()
BUILD_MARKER = ''

# Single shared Addon for the whole long-lived service process. simpleplugin's
# get_setting/set_setting read live from xbmcaddon, so one instance still sees
# settings changes; this just avoids constructing a fresh native Addon per call.
SERVICE_ADDON = Addon()

FILMIX_WATCHED_PENDING_PREFIX = 'filmix_watched_pending_'
FILMIX_WATCHED_JOB = 'filmix_watched'
BACKGROUND_JOB_KINDS = (
    FilmixPrewarm.JOB_FORCE,
    FilmixPrewarm.JOB_FILTER_AVAIL,
    FilmixPrewarm.JOB_PLAYER_TOPOLOGY,
)


def _clear_background_jobs(cache, include_leased=False):
    states = ('queued', 'leased') if include_leased else ('queued',)
    removed = 0
    for kind in BACKGROUND_JOB_KINDS:
        try:
            for row in cache.list_jobs(kind, states=states):
                if cache.delete_job(kind, row.get('identity')):
                    removed += 1
        except Exception:
            pass
    return removed


def _queue_filmix_watched(addon, cache, post_id, season=None, episode=None, translation=None):
    payload = {
        'post_id': str(post_id),
        'season': season,
        'episode': episode,
        'translation': translation,
    }
    identity = json.dumps([str(post_id), season, episode, translation], ensure_ascii=False,
                          separators=(',', ':'))
    key = hashlib.sha1(identity.encode('utf-8')).hexdigest()
    cache.enqueue_job(FILMIX_WATCHED_JOB, key, payload, due_ts=0, priority=100)
    try:
        addon.log_debug('Filmix watched queued post_id={0} s={1} e={2}'.format(post_id, season, episode))
    except Exception:
        pass


def _write_build_status(addon, event='startup'):
    try:
        profile_dir = addon.profile_dir
        if profile_dir and not os.path.exists(profile_dir):
            os.makedirs(profile_dir)
        path = os.path.join(profile_dir, 'filmix_build_status.txt')
        payload = [
            'addon=plugin.video.filmix',
            'version=' + BUILD_VERSION,
            'marker=' + BUILD_MARKER,
            'event=' + str(event),
            'time=' + time.strftime('%Y-%m-%d %H:%M:%S'),
        ]
        with open(path, 'w') as f:
            f.write('\n'.join(payload) + '\n')
        xbmc.log('[plugin.video.filmix] BUILD_STATUS_FILE ' + path + ' ' + BUILD_MARKER, xbmc.LOGINFO)
    except Exception as e:
        try:
            xbmc.log('[plugin.video.filmix] BUILD_STATUS_FILE failed: ' + str(e), xbmc.LOGWARNING)
        except Exception:
            pass


@python_2_unicode_compatible
class FilmixPlayer(xbmc.Player):

    PENDING_PLAYBACK_TIMEOUT = 30

    def __init__(self, addon):
        super(FilmixPlayer, self).__init__()
        self._addon = addon
        self._current = None
        self._playback_state = 'idle'
        self._pending_since = 0.0
        self._last_position = 0.0
        self._last_total = 0.0
        self._last_progress_ts = 0.0
        self._resume_seek = 0.0
        self._resume_total = 0.0
        self._resume_seek_done = False
        self._resume_seek_tries = 0
        self._resume_last_seek_ts = 0.0
        self._resume_playback_started_ts = 0.0
        self._resume_ready_after = 0.0

    def __str__(self):
        return '<FilmixPlayer>'

    def set_current(self, data):
        self._current = data or None
        self._playback_state = 'pending' if self._current else 'idle'
        self._pending_since = time.time() if self._current else 0.0
        self._last_position = 0.0
        self._last_total = 0.0
        self._last_progress_ts = 0.0
        self._resume_seek = 0.0
        self._resume_total = 0.0
        self._resume_seek_done = False
        self._resume_seek_tries = 0
        self._resume_last_seek_ts = 0.0
        self._resume_playback_started_ts = 0.0
        self._resume_ready_after = 0.0
        try:
            if isinstance(data, dict) and data.get('resume_requested'):
                self._resume_seek = float(data.get('resume_seek') or 0.0)
                self._resume_total = float(data.get('resume_total') or 0.0)
                xbmc.log('[plugin.video.filmix] ResumeSeek: pending seek={0:.3f} total={1:.3f} source={2} post_id={3} s={4} e={5}'.format(
                    self._resume_seek, self._resume_total, data.get('resume_source'), data.get('post_id'), data.get('season'), data.get('episode')), xbmc.LOGINFO)
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] ResumeSeek: pending parse failed: {0}'.format(e), xbmc.LOGINFO)
            except Exception:
                pass

    def clear_current(self):
        self._current = None
        self._playback_state = 'idle'
        self._pending_since = 0.0
        self._last_position = 0.0
        self._last_total = 0.0
        self._last_progress_ts = 0.0
        self._resume_seek = 0.0
        self._resume_total = 0.0
        self._resume_seek_done = False
        self._resume_seek_tries = 0
        self._resume_last_seek_ts = 0.0
        self._resume_playback_started_ts = 0.0
        self._resume_ready_after = 0.0

    def has_pending_resume_seek(self):
        try:
            return bool(self._current and self._playback_state == 'playing'
                        and (not self._resume_seek_done)
                        and float(self._resume_seek or 0.0) > 5.0)
        except Exception:
            return False


    def needs_fast_poll(self):
        # секундный такт нужен только пока отслеживается воспроизведение Filmix:
        # повтор перемотки к точке продолжения и позиция для остановки (21.11.2026)
        return bool(self._current)

    def is_filmix_playback_active(self):
        if not self._current or self._playback_state != 'playing':
            return False
        try:
            return bool(self.isPlaying())
        except Exception:
            return False

    @staticmethod
    def _stream_identity(value):
        value = str(value or '').strip()
        if '|' in value:
            value = value.split('|', 1)[0]
        return value

    def _matches_current_stream(self):
        current = self._current or {}
        expected = self._stream_identity(current.get('stream_path'))
        if not expected:
            # Backward-compatible notifications from an older plugin process.
            return True
        try:
            actual = self._stream_identity(self.getPlayingFile())
        except Exception:
            actual = ''
        # Some Kodi builds expose the file only after AVStarted.  An empty value
        # is therefore not proof of a mismatch, while a different non-empty URL is.
        return not actual or actual == expected

    def _mark_playing(self):
        if self._current and self._matches_current_stream():
            self._playback_state = 'playing'
            self._pending_since = 0.0
            return True
        return False

    def _cache(self):
        return FilmixCache(self._addon.profile_dir)


    def _apply_resume_seek(self, reason='poll'):
        if not self._current:
            return
        if self._resume_seek_done:
            return
        try:
            seek = float(self._resume_seek or 0.0)
        except Exception:
            seek = 0.0
        if seek <= 5.0:
            self._resume_seek_done = True
            return

        now = time.time()

        # CoreELEC/Kodi can fire onPlayBackStarted before the resolved HTTP
        # stream/demuxer is actually ready. In 47.20 seekTime() was sent there,
        # Kodi logged success, but playback still started from 0. Do not mark
        # resume as done on that early event; wait for AVStarted or poll retry.
        if reason == 'onPlayBackStarted':
            self._resume_playback_started_ts = now
            try:
                xbmc.log('[plugin.video.filmix] ResumeSeek: onPlayBackStarted wait for stream-ready seek={0:.3f}'.format(seek), xbmc.LOGINFO)
            except Exception:
                pass
            return

        if reason == 'onAVStarted':
            # Do not block Kodi's player callback. The service poll performs the
            # same verified seek after the demuxer has had time to become ready.
            self._resume_ready_after = max(float(self._resume_ready_after or 0.0), now + 1.0)
            try:
                xbmc.log('[plugin.video.filmix] ResumeSeek: scheduled after AVStarted seek={0:.3f}'.format(seek), xbmc.LOGINFO)
            except Exception:
                pass
            return

        if self._resume_ready_after and now < float(self._resume_ready_after):
            return

        try:
            if not self.isPlaying():
                return
        except Exception:
            return

        try:
            pos_before = float(self.getTime() or 0.0)
        except Exception:
            pos_before = 0.0
        if pos_before >= max(0.0, seek - 6.0):
            self._last_position = pos_before
            self._resume_seek_done = True
            try:
                xbmc.log('[plugin.video.filmix] ResumeSeek: verified existing pos={0:.3f} seek={1:.3f} reason={2} tries={3}'.format(pos_before, seek, reason, self._resume_seek_tries), xbmc.LOGINFO)
            except Exception:
                pass
            return

        # If the only event so far was onPlayBackStarted, give the real stream a
        # moment to open before first poll attempt. AVStarted bypasses this.
        if reason == 'poll' and self._resume_playback_started_ts and (now - self._resume_playback_started_ts) < 2.0:
            return

        if self._resume_seek_tries >= 12:
            self._resume_seek_done = True
            try:
                xbmc.log('[plugin.video.filmix] ResumeSeek: giveup seek={0:.3f} pos={1:.3f} reason={2}'.format(seek, pos_before, reason), xbmc.LOGINFO)
            except Exception:
                pass
            return

        # Avoid hammering seekTime if callbacks/poll arrive too close together.
        if self._resume_last_seek_ts and (now - self._resume_last_seek_ts) < 1.2:
            return

        try:
            total = float(self.getTotalTime() or self._resume_total or 0.0)
        except Exception:
            total = float(self._resume_total or 0.0)
        try:
            if total > 0 and seek >= (total - 10.0):
                xbmc.log('[plugin.video.filmix] ResumeSeek: skip near end seek={0:.3f} total={1:.3f}'.format(seek, total), xbmc.LOGINFO)
                self._resume_seek_done = True
                return
        except Exception:
            pass

        self._resume_seek_tries += 1
        self._resume_last_seek_ts = time.time()
        try:
            self.seekTime(seek)
            try:
                pos_after = float(self.getTime() or 0.0)
            except Exception:
                pos_after = 0.0
            try:
                total_after = float(self.getTotalTime() or total or 0.0)
            except Exception:
                total_after = total

            if pos_after >= max(0.0, seek - 8.0):
                self._last_position = pos_after
                if total_after > 0:
                    self._last_total = total_after
                self._resume_seek_done = True
                xbmc.log('[plugin.video.filmix] ResumeSeek: applied verified seek={0:.3f} pos={1:.3f} total={2:.3f} reason={3} tries={4}'.format(seek, pos_after, total_after, reason, self._resume_seek_tries), xbmc.LOGINFO)
            else:
                # Kodi accepted the call but did not move yet. Keep pending so
                # the service poll can retry after the stream is fully ready.
                if total_after > 0:
                    self._last_total = total_after
                xbmc.log('[plugin.video.filmix] ResumeSeek: sent_unverified seek={0:.3f} pos_before={1:.3f} pos_after={2:.3f} total={3:.3f} reason={4} tries={5}'.format(seek, pos_before, pos_after, total_after, reason, self._resume_seek_tries), xbmc.LOGINFO)
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] ResumeSeek: seek failed seek={0:.3f} reason={1} err={2}'.format(seek, reason, e), xbmc.LOGINFO)
            except Exception:
                pass

    def onPlayBackStarted(self):
        try:
            super(FilmixPlayer, self).onPlayBackStarted()
        except Exception:
            pass
        if self._mark_playing():
            self._apply_resume_seek('onPlayBackStarted')

    def onAVStarted(self):
        try:
            super(FilmixPlayer, self).onAVStarted()
        except Exception:
            pass
        if self._mark_playing():
            self._apply_resume_seek('onAVStarted')

    def poll_progress(self):
        # Kodi can raise/log "Kodi is not playing any media file" if getTime()
        # is called after playback has already stopped. Cache progress only while
        # media is definitely playing, then reuse this value in stop/end callbacks.
        if not self._current:
            return
        playing = False
        try:
            playing = bool(self.isPlaying())
        except Exception:
            playing = False
        if not playing:
            if self._playback_state == 'pending':
                age = time.time() - float(self._pending_since or 0.0)
                if age >= float(self.PENDING_PLAYBACK_TIMEOUT):
                    try:
                        xbmc.log('[plugin.video.filmix] PlaybackPending: timeout clear post_id={0} age={1:.1f}s'.format(
                            (self._current or {}).get('post_id'), age), xbmc.LOGWARNING)
                    except Exception:
                        pass
                    self.clear_current()
            return
        if not self._mark_playing():
            return
        self._apply_resume_seek('poll')
        try:
            self._last_position = float(self.getTime() or self._last_position or 0.0)
        except Exception:
            pass
        try:
            self._last_total = float(self.getTotalTime() or self._last_total or 0.0)
        except Exception:
            pass
        self._last_progress_ts = time.time()

    def _save_state(self, ended=False):
        # Ignore Stop/Ended callbacks from unrelated players while a Filmix
        # resolve is still pending.  A failed resolve is cleared by the timeout.
        if self._playback_state != 'playing':
            return
        current = self._current or {}
        post_id = current.get('post_id')
        if not post_id:
            self.clear_current()
            return

        season = current.get('season')
        episode = current.get('episode')
        cache = None
        try:
            # Do not call getTime()/getTotalTime() here after stop. Use the last
            # cached values collected from the service loop while playback was active.
            position = float(self._last_position or 0.0)
            total = float(self._last_total or 0.0)

            complete = ended
            if not complete and total > 0:
                complete = (position / total) >= 0.92

            if complete:
                cache = self._cache()
                # Kodi holds the history now, and it records this playback
                # itself - which is also the copy the boxes share. The local
                # playcount below is only what draws this add-on's own marks,
                # so the toggle keeps it available without a second writer.
                if self._addon.get_setting('watched_tracking_enabled'):
                    cache.increment_playcount(post_id, season=season, episode=episode)
                else:
                    self._addon.log_debug(
                        'watched tracking disabled: skipped local playcount for '
                        '{0} s{1}e{2} (Kodi owns the history)'.format(
                            post_id, season or '', episode or ''))
                try:
                    _queue_filmix_watched(self._addon, cache, post_id, season=season,
                                          episode=episode, translation=current.get('translation'))
                except Exception as e:
                    self._addon.log_debug('Filmix watched queue failed: {0}'.format(e))
        finally:
            try:
                if cache is not None:
                    cache.close()
            except Exception:
                pass
            self.clear_current()

    def _drop_resume_index(self):
        """Throw away the saved resume index: this playback just changed it.

        The index is kept in a file so a route does not rescan Kodi's bookmarks
        every time (0.7 s of a 3.1 s episode list, measured on .30). Its whole
        risk is going stale, and the one moment it certainly goes stale is when
        something stops playing - so that is where it is dropped.
        """
        try:
            import os
            path = xbmcvfs.translatePath(
                'special://profile/addon_data/plugin.video.filmix/resume_index.json')
            if path and os.path.isfile(path):
                os.remove(path)
        except Exception:
            pass

    def onPlayBackStopped(self):
        try:
            super(FilmixPlayer, self).onPlayBackStopped()
        except Exception:
            pass
        self._drop_resume_index()
        self._save_state(False)

    def onPlayBackEnded(self):
        try:
            super(FilmixPlayer, self).onPlayBackEnded()
        except Exception:
            pass
        self._drop_resume_index()
        self._save_state(True)


@python_2_unicode_compatible
class FilmixMonitor(xbmc.Monitor):

    def __init__(self, player=None):

        super(FilmixMonitor, self).__init__()
        addon = SERVICE_ADDON
        addon.log_debug('Started {0}'.format(self))

        self._settings = self._get_settings()
        self._player = player
        # настройки фоновой работы читаются здесь и в onSettingsChanged, а не
        # каждый такт главного цикла (21.11.2026)
        self.prewarm_settings = self._get_prewarm_settings()

    def __del__(self):
        SERVICE_ADDON.log_debug('Stopped {0}'.format(self))

    def __str__(self):
        return '<FilmixMonitor>'

    def onNotification(self, sender, method, data):
        super(FilmixMonitor, self).onNotification(sender, method, data)

        addon = SERVICE_ADDON
        addon.log_debug('{0}.onNotification({1}, {2}, {3})'.format(self, sender, method, py2_decode(data)))

        if sender == addon.id:
            if method == 'Other.OnPlay':
                if data != 'nill':
                    try:
                        data = json.loads(data)
                    except (TypeError, ValueError) as e:
                        addon.log_debug('Ignored invalid Other.OnPlay payload: {0}'.format(e))
                    else:
                        if self._player is not None:
                            self._player.set_current(data)

    def onSettingsChanged(self):
        super(FilmixMonitor, self).onSettingsChanged()

        self.prewarm_settings = self._get_prewarm_settings()

        new_settings = self._get_settings()

        for key, val in iteritems(new_settings):
            if self._settings[key] != val:
                self.check_device()
                break

        self._settings.update(new_settings)

    @staticmethod
    def _get_prewarm_settings():
        return {'background': FilmixPrewarm.is_background_prewarm_enabled(),
                'topology': FilmixPrewarm._bool_setting('player_topology_prewarm_enabled', False)}

    @staticmethod
    def _get_settings():
        addon = SERVICE_ADDON

        settings = {'user_dev_id': addon.get_setting('user_dev_id'),
                    'user_dev_token': addon.get_setting('user_dev_token'),
                    }
        return settings

    def check_device(self):
        addon = SERVICE_ADDON
        addon.log_debug('{0}.check_device()'.format(self))

        # Единственный шаг главного цикла службы, который не был обёрнут, - и
        # именно он её убил: 26.09.2026 на .20 ответ 500 на user_profile кончился
        # исключением из уведомления, и цикл встал на четыре с половиной дня.
        # Проверка устройства повторится через полчаса сама.
        try:
            Filmix().check_device()
        except (FilmixError, simplemedia.WebClientError):
            return False
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] check_device failed: {0}'.format(e), xbmc.LOGWARNING)
            except Exception:
                pass
            return False
        else:
            return True


def _start_server_watch(monitor, addon):
    """Сведения о серверах API раз в минуту (resources/libs/server_watch.py): текущий не
    отвечает 15 минут при живом интернете - служба переходит на работающий; после смены или
    возврата связи - добор пропущенного (FilmixPrewarm.recover_after_outage)."""
    import threading
    from resources.libs.web.filmix import server_watch, probe_api

    def _loop():
        if monitor.waitForAbort(60):
            return
        while not monitor.abortRequested():
            try:
                watch = server_watch()
                if watch is not None:
                    dev_id = addon.get_setting('user_dev_id') or 'probe'
                    event = watch.tick(lambda base: probe_api(base, dev_id))
                    if event:
                        worker = FilmixPrewarm(addon)
                        try:
                            worker.recover_after_outage(event)
                        finally:
                            worker.cache.close()
            except Exception as e:
                addon.log_debug('Filmix server watch failed: {0}'.format(e))
            if monitor.waitForAbort(60):
                break

    t = threading.Thread(target=_loop, name='FilmixServerWatch')
    t.daemon = True
    t.start()


def run():
    set_background_process(True)
    # 21.11.2026: такт 1 с только пока отслеживается воспроизведение Filmix
    # (FilmixPlayer.needs_fast_poll), в простое 5 с. Сроки шагов - один
    # планировщик {шаг: когда пора}, вместо девяти счётчиков в двух местах.
    FAST_TICK_SEC = 1
    IDLE_TICK_SEC = 5
    _start = time.time()
    next_due = {
        # Avoid startup service blocking exactly while user opens a resume item.
        'device': _start + 30,
        'account': _start,
        'filmix_watched': _start + 5,
        # Active serial widget counters need a faster, independent refresh lane.
        'player_topology': _start + 5,
        # Posts we have never cached: their own description arrives only with
        # Filmix.post, and nothing else asks for it in source-only mode.
        'post_details': _start + 20,
        'post_details_sweep': _start + 15,
        # Сериалы виджетов главной (FilmixPrewarm.warm_home_series).
        'home_warm': _start + 45,
        'filter_availability': _start + 30,
        # Favorites/watch-later must still get checked while the recent-Home-widget
        # guard below is pausing the heavier catalog tick - see
        # FilmixPrewarm.tick_personal_sections() for why.
        'personal_prewarm': _start + 20,
        'prewarm_start': _start + 105,
    }

    def _due(name):
        return time.time() >= next_due[name]

    def _again(name, seconds):
        next_due[name] = time.time() + seconds

    no_account = True
    prewarm_start_logged = False
    last_background_pause_log = {'reason': '', 'ts': 0}

    addon = SERVICE_ADDON
    try:
        xbmc.log('[plugin.video.filmix] STARTUP v' + BUILD_VERSION, xbmc.LOGINFO)
    except Exception:
        pass
    _write_build_status(addon, event='service_start')
    try:
        def _ov_log(msg):
            xbmc.log('[plugin.video.filmix] ManualIDOverride cache: ' + str(msg), xbmc.LOGINFO)
        startup_cache = FilmixCache(addon.profile_dir)
        try:
            applied = apply_manual_overrides_to_cache(startup_cache, log_func=_ov_log)
        finally:
            startup_cache.close()
        xbmc.log('[plugin.video.filmix] ManualIDOverride cache applied={0}'.format(applied), xbmc.LOGINFO)
    except Exception as e:
        try:
            xbmc.log('[plugin.video.filmix] ManualIDOverride cache failed: {0}'.format(e), xbmc.LOGWARNING)
        except Exception:
            pass
    player = FilmixPlayer(addon)
    monitor = FilmixMonitor(player)
    prewarm = FilmixPrewarm(addon)
    _start_server_watch(monitor, addon)
    # Reuse the service-owned cache connection for control flags. Worker
    # threads create their own FilmixPrewarm objects and connections.
    service_cache = prewarm.cache
    try:
        prewarm.clear_stale_busy_flags(force=True)
    except Exception as e:
        addon.log_debug('Filmix stale busy startup cleanup failed: {0}'.format(e))
    # Migrate persistent work written by .  Identity-based jobs make
    # this safe to repeat after an interrupted upgrade.
    try:
        for row in service_cache.list_control_flags(FILMIX_WATCHED_PENDING_PREFIX) or []:
            key = row.get('flag_key') or ''
            try:
                payload = json.loads(row.get('flag_value') or '{}')
            except Exception:
                payload = {}
            identity = key[len(FILMIX_WATCHED_PENDING_PREFIX):] or hashlib.sha1(
                json.dumps(payload, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()
            migrated = service_cache.enqueue_job(FILMIX_WATCHED_JOB, identity, payload,
                                                 due_ts=int(payload.get('next_try') or 0),
                                                 priority=100,
                                                 attempts=int(payload.get('attempts') or 0))
            if migrated:
                service_cache.clear_control_flag(key)
    except Exception as e:
        addon.log_debug('Filmix legacy queue migration failed: {0}'.format(e))
    background_prewarm_enabled = monitor.prewarm_settings['background']
    # Обогащение метаданных делает скин (настройка filmix_source_only_metadata),
    # поэтому своей очереди обогащения у дополнения больше нет.
    try:
        xbmc.log('[plugin.video.filmix] CachePrewarmSetting: background_prewarm={0}'.format(
            int(bool(background_prewarm_enabled))), xbmc.LOGINFO)
    except Exception:
        pass
    if not background_prewarm_enabled:
        try:
            _clear_background_jobs(service_cache, include_leased=True)
            for _flag in (FilmixPrewarm.FORCE_FLAG, FilmixPrewarm.BUSY_FLAG,
                          FilmixPrewarm.FILTER_AVAIL_BUSY_FLAG,
                          FilmixPrewarm.FILTER_AVAIL_QUEUE_FLAG):
                try:
                    service_cache.clear_control_flag(_flag)
                except Exception:
                    pass
            xbmc.log('[plugin.video.filmix] CachePrewarmSetting: background jobs disabled', xbmc.LOGINFO)
        except Exception as e:
            addon.log_debug('Filmix background job cleanup failed: {0}'.format(e))
    # 2.2.39 AM8_4GB_STARTUP_QUIET:
    # Do not warm category/country indexes synchronously at service start.
    # The first delayed prewarm round or manual menu open can refresh them later.
    try:
        xbmc.log('[plugin.video.filmix] AM8_4GB_STARTUP_QUIET: skip immediate filter index warm; delayed prewarm will handle it', xbmc.LOGINFO)
    except Exception:
        pass
    try:
        prewarm.requeue_pending_filter_confirmations()
    except Exception as e:
        try:
            xbmc.log('[plugin.video.filmix] filter availability startup confirm retry failed: {0}'.format(e), xbmc.LOGDEBUG)
        except Exception:
            pass

    filmix_watched_worker = {'thread': None, 'running': False, 'started': 0.0}
    AM8_IDLE_DEFER_AFTER_HOME_SEC = 180
    AM8_IDLE_DEFER_AFTER_SEARCH_SEC = 120
    AM8_IDLE_DEFER_AFTER_VIDEO_SEC = 180
    _last_generic_playback_ts = 0

    def _recent_home_widget_route_age(max_age=120):
        # Do not start heavy background work while AF3 is still requesting
        # Filmix Home widgets. On 4GB such overlap made otherwise-fast cache
        # hits finish in 6-10s.
        try:
            cache_flags = service_cache
            if row:
                age = int(time.time()) - int(row.get('updated_ts') or 0)
                if 0 <= age < int(max_age):
                    return age
            latest_age = None
            for r in cache_flags.list_control_flags(FilmixPrewarm.ACTIVE_WIDGET_PREFIX) or []:
                try:
                    ts = int(r.get('updated_ts') or 0)
                    if ts <= 0:
                        continue
                    age = int(time.time()) - ts
                    if latest_age is None or age < latest_age:
                        latest_age = age
                except Exception:
                    continue
            if latest_age is not None and 0 <= latest_age < int(max_age):
                return latest_age
        except Exception:
            pass
        return None

    def _recent_search_route_age(max_age=120):
        try:
            cache_flags = service_cache
            row = cache_flags.get_control_flag('filmix_search_route_seen_any')
            if row:
                age = int(time.time()) - int(row.get('updated_ts') or 0)
                if 0 <= age < int(max_age):
                    return age
        except Exception:
            pass
        return None

    def _recent_video_age(max_age=180):
        try:
            ts = float(_last_generic_playback_ts or 0)
            if ts > 0:
                age = time.time() - ts
                if 0 <= age < int(max_age):
                    return age
        except Exception:
            pass
        return None

    def _background_pause_reason(include_video=False):
        # 2.2.57: AM8 4GB should pause background work only after Home widget/search routes.
        # Generic background video/PVR must not pause Filmix jobs.
        try:
            age = _recent_home_widget_route_age(max_age=AM8_IDLE_DEFER_AFTER_HOME_SEC)
            if age is not None:
                return 'recent_home_widget age={0}s'.format(int(age))
        except Exception:
            pass
        try:
            age = _recent_search_route_age(max_age=AM8_IDLE_DEFER_AFTER_SEARCH_SEC)
            if age is not None:
                return 'recent_search age={0}s'.format(int(age))
        except Exception:
            pass
        if include_video:
            try:
                age = _recent_video_age(max_age=AM8_IDLE_DEFER_AFTER_VIDEO_SEC)
                if age is not None:
                    return 'recent_generic_video_ignored age={0}s'.format(int(age))
            except Exception:
                pass
        return ''

    def _background_pause_log_key(reason):
        """Normalize volatile ages so one pause reason logs at most once/minute."""
        try:
            import re
            return re.sub(r'\bage=\d+s\b', 'age=*', str(reason or ''))
        except Exception:
            return str(reason or '')

    def _log_background_pause(reason, prefix='background paused'):
        try:
            now = int(time.time())
            reason_key = _background_pause_log_key(reason)
            prefix_key = str(prefix or 'background paused')
            current_key = prefix_key + '|' + reason_key
            previous_key = last_background_pause_log.get('reason') or ''
            previous_ts = int(last_background_pause_log.get('ts') or 0)
            if current_key != previous_key or (now - previous_ts) >= 60:
                xbmc.log('[plugin.video.filmix][lite prewarm] {0}: {1}'.format(prefix, reason), xbmc.LOGINFO)
                last_background_pause_log['reason'] = current_key
                last_background_pause_log['ts'] = now
        except Exception:
            pass

    def _filmix_watched_worker_alive():
        try:
            t = filmix_watched_worker.get('thread')
            return bool(filmix_watched_worker.get('running') and t is not None and t.is_alive())
        except Exception:
            return bool(filmix_watched_worker.get('running'))

    def _filmix_watched_worker_main():
        cache = None
        owner = 'filmix-watched:{0}:{1}'.format(int(time.time()), threading.current_thread().name)
        try:
            cache = FilmixCache(SERVICE_ADDON.profile_dir)
            rows = cache.claim_jobs(FILMIX_WATCHED_JOB, limit=20, lease_seconds=10 * 60, owner=owner)
            if not rows:
                return
            api = Filmix()
            processed = 0
            for row in rows:
                identity = row.get('identity') or ''
                payload = cache.job_payload(row, {})
                if not isinstance(payload, dict) or not payload.get('post_id'):
                    cache.fail_job(FILMIX_WATCHED_JOB, identity,
                                   error='invalid payload', owner=owner)
                    continue
                try:
                    api.add_watched(post_id=payload.get('post_id'),
                                    season=payload.get('season'),
                                    episode=payload.get('episode'),
                                    translation=payload.get('translation'))
                except Exception as e:
                    attempts = int(row.get('attempts') or 0) + 1
                    if attempts >= 12:
                        cache.fail_job(FILMIX_WATCHED_JOB, identity, error=e, owner=owner)
                    else:
                        delay = min(3600, 30 * (2 ** min(attempts - 1, 7)))
                        cache.retry_job(FILMIX_WATCHED_JOB, identity,
                                        delay_seconds=delay, error=e, owner=owner)
                    try:
                        xbmc.log('[plugin.video.filmix] FilmixWatchedAsync: retry post_id={0} attempts={1} err={2}'.format(
                            payload.get('post_id'), attempts, e), xbmc.LOGWARNING)
                    except Exception:
                        pass
                else:
                    cache.ack_job(FILMIX_WATCHED_JOB, identity, owner=owner)
                    processed += 1
            if processed:
                xbmc.log('[plugin.video.filmix] FilmixWatchedAsync: processed={0}'.format(processed), xbmc.LOGINFO)
        except Exception as e:
            try:
                xbmc.log('[plugin.video.filmix] FilmixWatchedAsync: failed {0}'.format(e), xbmc.LOGWARNING)
            except Exception:
                pass
        finally:
            try:
                if cache is not None:
                    cache.close()
            except Exception:
                pass
            filmix_watched_worker['running'] = False

    def _start_filmix_watched_worker():
        if _filmix_watched_worker_alive():
            return False
        filmix_watched_worker['running'] = True
        filmix_watched_worker['started'] = time.time()
        t = threading.Thread(target=_filmix_watched_worker_main, name='FilmixWatchedAsync')
        try:
            t.daemon = True
        except Exception:
            pass
        filmix_watched_worker['thread'] = t
        try:
            t.start()
        except Exception:
            filmix_watched_worker['running'] = False
            filmix_watched_worker['thread'] = None
            raise
        return True

    # 2.2.39: no immediate force prewarm on boot.
    # Start after the 'prewarm_start' delay and let FilmixPrewarm.tick() process small batches.
    while not monitor.abortRequested():

        try:
            _new_background_prewarm_enabled = monitor.prewarm_settings['background']
            if _new_background_prewarm_enabled != background_prewarm_enabled:
                background_prewarm_enabled = _new_background_prewarm_enabled
                xbmc.log('[plugin.video.filmix] CachePrewarmSetting: changed background_prewarm={0}'.format(
                    int(bool(background_prewarm_enabled))), xbmc.LOGINFO)
                if not background_prewarm_enabled:
                    try:
                        _clear_background_jobs(service_cache, include_leased=False)
                        for _flag in (FilmixPrewarm.FORCE_FLAG, FilmixPrewarm.BUSY_FLAG,
                                      FilmixPrewarm.FILTER_AVAIL_BUSY_FLAG,
                                      FilmixPrewarm.FILTER_AVAIL_QUEUE_FLAG):
                            try:
                                service_cache.clear_control_flag(_flag)
                            except Exception:
                                pass
                    except Exception as e:
                        xbmc.log('[plugin.video.filmix] CachePrewarmSetting: cleanup failed {0}'.format(e), xbmc.LOGDEBUG)
        except Exception:
            pass

        try:
            player.poll_progress()
        except Exception as e:
            addon.log_debug('Filmix playback progress poll failed: {0}'.format(e))

        sleep_sec = FAST_TICK_SEC if player.needs_fast_poll() else IDLE_TICK_SEC

        # Resume seek must win over all service background work. 47.24 ran
        # a resume sync in this same loop, so pending seek was noticed only
        # after a long sync finished. While a seek is pending or video is active,
        # do not run prewarm/metadata/device jobs.
        resume_pending = False
        try:
            resume_pending = player.has_pending_resume_seek()
            filmix_playback_active = player.is_filmix_playback_active()
            # тот же xbmc.Player службы, а не новый объект каждый такт (21.11.2026)
            generic_playback_active = bool(player.isPlaying())
            if generic_playback_active:
                _last_generic_playback_ts = time.time()
        except Exception:
            filmix_playback_active = False
            generic_playback_active = False
            resume_pending = False

        # Do not let generic background playback (PVR/YouTube/live TV) freeze
        # Filmix catalog refresh for hours.  Only Filmix playback/resume itself
        # blocks catalog jobs, because resume seek must win over addon work.
        if resume_pending or filmix_playback_active:
            if monitor.waitForAbort(sleep_sec):
                break
            continue

        if _due('filmix_watched'):
            try:
                if (not _filmix_watched_worker_alive()) and service_cache.has_due_jobs(FILMIX_WATCHED_JOB):
                    _start_filmix_watched_worker()
            except Exception as e:
                addon.log_debug('Filmix watched async schedule failed: {0}'.format(e))
            _again('filmix_watched', 5)

        # The history lives in Kodi now. watched_state is only the display cache
        # these lists read, so it is made to agree with Kodi - including marks
        # removed elsewhere, which is the half that never used to travel. At
        # most once a minute; the read behind it is a single query.
        # 21.11.2026: единственная сверка с Kodi - kodi_watched.reconcile (раз в
        # 5 мин) только добавлял отметки, которые добавляет и эта, и удалён.
        try:
            kodi_link.mirror(service_cache, interval_seconds=60)
        except Exception as e:
            addon.log_debug('Filmix kodi mirror failed: {0}'.format(e))

        # GUI refreshes requested by metadata/prewarm workers are executed only
        # from this service loop. This preserves widget updates while avoiding
        # Container.Refresh and sleeps inside background threads.

        # 2.2.31: availability queue must not wait behind ordinary prewarm or
        # generic playback. Resume/Filmix playback is already blocked above, so
        # this cannot steal priority from the actual resume seek.
        # без входа в аккаунт фоновой работы нет (настройка перечитывается раз в 15 с)
        if _due('account'):
            _again('account', 15)
            no_account = not signed_in()

        if background_prewarm_enabled and _due('filter_availability') and not no_account:
            paused = False
            try:
                pause_reason = _background_pause_reason(include_video=False)
                if pause_reason:
                    paused = True
                else:
                    try:
                        prewarm.requeue_pending_filter_confirmations(max_tasks=20)
                    except Exception as e:
                        addon.log_debug('Filmix filter availability confirm retry failed: {0}'.format(e))
                    prewarm.tick_filter_availability(limit=1 if generic_playback_active else None)
            except Exception as e:
                try:
                    xbmc.log('[plugin.video.filmix] filter availability tick failed: {0}'.format(e), xbmc.LOGWARNING)
                except Exception:
                    pass
            _again('filter_availability', 30 if (paused or generic_playback_active) else 15)

        prewarm_started = _due('prewarm_start')
        if background_prewarm_enabled and prewarm_started and not no_account:
            try:
                pause_reason = _background_pause_reason(include_video=False)
                if pause_reason:
                    _log_background_pause(pause_reason)
                else:
                    prewarm.tick(max_batch_size=1 if generic_playback_active else None)
            except Exception as e:
                addon.log_debug('Filmix prewarm tick failed: {0}'.format(e))
        elif not no_account:
            if background_prewarm_enabled and not prewarm_start_logged:
                try:
                    xbmc.log('[plugin.video.filmix] AM8_4GB_PREWARM_DELAY: delayed first prewarm by {0}s'.format(
                        int(next_due['prewarm_start'] - time.time())), xbmc.LOGINFO)
                except Exception:
                    pass
                prewarm_start_logged = True

        # favorites/watch-later must not wait behind the same
        # recent-Home-widget pause that guards the heavier movies/serials/genre
        # tick above - a favorite added outside Kodi (the Filmix website, a
        # second device) has no other signal to reach Kodi with, and a
        # continuously-open Home screen can re-arm that pause indefinitely.
        # See FilmixPrewarm.tick_personal_sections() for the measured repro.
        if background_prewarm_enabled and prewarm_started and _due('personal_prewarm') \
                and not no_account:
            try:
                prewarm.tick_personal_sections(limit=1 if generic_playback_active else None)
            except Exception as e:
                addon.log_debug('Filmix personal sections tick failed: {0}'.format(e))
            _again('personal_prewarm', 60 if generic_playback_active else 20)

        # The player-topology lane is the expensive half of background prewarm:
        # it re-fetches each post from the network to keep episode badges exact,
        # and on <коробка> that ran every few seconds and held kodi.bin near
        # 90% CPU, which the owner felt as art arriving late. The catalogue half
        # is what keeps new titles flowing into the cache (~200 posts a day),
        # and Watch Hub's lanes read that cache - turning the whole thing off to
        # quieten the box also froze those lists. Separate switch, off by
        # default: badges then refresh when a series is actually opened.
        if (background_prewarm_enabled and _due('player_topology') and not no_account
                and monitor.prewarm_settings['topology']):
            try:
                # Separate durable lane for current episode topology. The queue is
                # visible-order prioritized and lease-protected, so this refreshes
                # badge counts quickly without repeating or losing jobs on a crash.
                # Periodically discover stale serials in actual Home/widget
                # snapshots. This keeps episode badges current even if the custom
                # hub remains open and Kodi never invokes the plugin route again.
                prewarm.queue_stale_active_player_topologies()
                prewarm.tick_player_topology(
                    limit=1 if generic_playback_active else FilmixPrewarm.PLAYER_TOPOLOGY_BATCH_SIZE)
            except Exception as e:
                addon.log_debug('Filmix player topology tick failed: {0}'.format(e))
            _again('player_topology', 45 if generic_playback_active else 15)

        # A separate, deliberately tiny lane: posts we have never cached at all.
        # It runs even with the topology switch off, because that switch exists
        # to stop RE-fetching posts we already have every few seconds, while
        # this is the only way a new film's own description ever arrives - and
        # without it the newest titles on the first page had no plot anywhere
        # (owner's report, 24.08). One post per pass, never during playback.
        if background_prewarm_enabled and _due('post_details') and not no_account:
            try:
                # Find what is missing, then fetch one of it. The sweep is a few
                # sqlite reads over pages we already hold, so it does not wait
                # for the next page refresh - which is hours away.
                if _due('post_details_sweep'):
                    prewarm.request_post_details_from_pages()
                    prewarm.request_started_serials_refresh()
                    _again('post_details_sweep', 300)
                if service_cache.has_due_jobs(FilmixPrewarm.JOB_POST_DETAILS):
                    prewarm.tick_player_topology(limit=1, kind=FilmixPrewarm.JOB_POST_DETAILS)
            except Exception as e:
                addon.log_debug('Filmix post details tick failed: {0}'.format(e))
            _again('post_details', 30 if generic_playback_active else 12)

        if background_prewarm_enabled and _due('home_warm') and not no_account:
            try:
                prewarm.warm_home_series()
            except Exception as e:
                addon.log_debug('Filmix home series warm failed: {0}'.format(e))
            _again('home_warm', 60 if generic_playback_active else 15)

        if _due('device') and monitor.check_device():
            _again('device', 1800)

        if monitor.waitForAbort(sleep_sec):
            break

    try:
        service_cache.close()
    except Exception:
        pass


if __name__ == '__main__':
    run()
