# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

from urllib.parse import urlencode

import random

import xbmcgui
import xbmcplugin

from . import api as api_module
from . import config
from .api import tmdb
from .core import (
    fetch_online_metadata, get_prop, identity_local_model, make_video_listitem, safe_int,
)
from .model import all_images, image_url, language_code, normalize_tmdb, trailer_rank

from .plugin_routes import HANDLED


def _url(info, **params):
    data = {'info': info}
    data.update({k: v for k, v in params.items() if v not in (None, '')})
    return 'plugin://skin.sublime/?%s' % urlencode(data)


def _add(handle, li, path='', folder=False):
    from .plugin_runtime import normalize_handle
    value = normalize_handle(handle)
    if value < 0:
        return False
    return bool(xbmcplugin.addDirectoryItem(value, path or li.getPath() or '', li, folder))


def _finish(handle, content='videos', succeeded=True):
    from .plugin_runtime import finish_directory
    return finish_directory(handle, content=content, succeeded=succeeded,
                            update_listing=False, cache_to_disc=False)


def _online(params, feature_purpose=''):
    resolved = dict(params or {})
    if feature_purpose:
        resolved['feature_purpose'] = str(feature_purpose)
    fallbacks = {
        'tmdb_id': ('VCL.ActionPopup.TMDB_ID', 'SublimeHelper.ListItem.Monitor.TMDb_ID', 'VCL.Widget.TMDB_ID', 'SublimeHelper.ListItem.TMDB_ID'),
        'tmdb_type': ('VCL.ActionPopup.TMDB_Type', 'SublimeHelper.ListItem.Monitor.TMDb_Type', 'VCL.Widget.TMDB_Type', 'SublimeHelper.ListItem.TMDB_Type'),
        'kinopoisk_id': ('VCL.ActionPopup.Kinopoisk_ID', 'VCL.Widget.Kinopoisk_ID', 'SublimeHelper.ListItem.Kinopoisk_ID'),
        'imdb_id': ('VCL.ActionPopup.IMDb_ID', 'VCL.Widget.IMDb_ID', 'SublimeHelper.ListItem.IMDb_ID'),
        'dbid': ('SublimeHelper.ListItem.Monitor.DBID', 'VCL.ActionPopup.DBID', 'VCL.Widget.DBID', 'SublimeHelper.ListItem.DBID'),
        'dbtype': ('VCL.ActionPopup.DBType', 'VCL.Widget.DBType', 'SublimeHelper.ListItem.DBType'),
        'season': ('SublimeHelper.ListItem.Monitor.Season', 'SublimeHelper.ListItem.Season'),
        'episode': ('SublimeHelper.ListItem.Monitor.Episode', 'SublimeHelper.ListItem.Episode'),
        'title': ('VCL.ActionPopup.Title', 'SublimeHelper.ListItem.Title', 'VCL.Widget.Title', 'SublimeHelper.ListItem.base_title'),
        'year': ('SublimeHelper.ListItem.Year',),
    }
    for key, names in fallbacks.items():
        if resolved.get(key) in (None, '', '0'):
            for name in names:
                value = get_prop(name)
                if value and str(value).strip() not in ('0', 'None', 'null'):
                    resolved[key] = value
                    break
    return fetch_online_metadata(resolved, identity_local_model(resolved))


def _details(handle, params):
    meta = _online(params)
    if meta:
        li = make_video_listitem(meta, meta.get('file') or '')
        _add(handle, li, meta.get('file') or '', False)
    _finish(handle, 'actors' if meta.get('media_type') == 'person' else 'movies' if meta.get('media_type') == 'movie' else 'tvshows')


def _person_item(row, role=''):
    name = row.get('name') or row.get('original_name') or ''
    person_id = row.get('id') or ''
    source = str(row.get('source') or ('tmdb' if person_id else '')).lower()
    tmdb_person_id = person_id if source == 'tmdb' else ''
    li = xbmcgui.ListItem(label=str(name), label2=str(role or row.get('role') or row.get('job') or ''), offscreen=True)
    thumb = row.get('thumb') or image_url(row.get('profile_path'), 'h632')
    if thumb:
        li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
    li.setProperties({
        'Role': str(role or row.get('role') or row.get('job') or ''), 'Job': str(row.get('job') or ''),
        'Department': str(row.get('department') or row.get('known_for_department') or ''), 'Source': source,
        'TMDb_ID': str(tmdb_person_id), 'tmdb_id': str(tmdb_person_id), 'tmdb_type': 'person',
        'Kinopoisk_ID': str(person_id if source == 'kinopoisk' else ''), 'Order': str(row.get('order') or ''),
    })
    if tmdb_person_id:
        path = _url('details', tmdb_type='person', tmdb_id=tmdb_person_id)
    elif source == 'kinopoisk' and person_id:
        path = _url('details', tmdb_type='person', kinopoisk_id=person_id)
    else:
        # A valid plugin path prevents Kodi from translating an empty row action
        # into the invalid builtin PlayMedia("").
        path = _url('details', tmdb_type='person', title=name)
    return li, path, True


def _cast(handle, params):
    meta = _online(params, 'cast')
    rows = list(meta.get('cast') or [])
    if not rows:
        media_type = params.get('tmdb_type') or meta.get('tmdb_type') or get_prop('SublimeHelper.ListItem.Monitor.TMDb_Type')
        media_type = 'tv' if media_type in ('tvshow', 'season', 'episode') else media_type
        tmdb_id = safe_int(params.get('tmdb_id') or meta.get('tmdb_id') or get_prop('SublimeHelper.ListItem.Monitor.TMDb_ID'))
        season = params.get('season') or meta.get('season') or get_prop('SublimeHelper.ListItem.Monitor.Season')
        episode = params.get('episode') or meta.get('episode') or get_prop('SublimeHelper.ListItem.Monitor.Episode')
        if tmdb_id and media_type in ('movie', 'tv'):
            credits, aggregate = tmdb.credits(media_type, tmdb_id, season, episode)
            wrapper = {'id': tmdb_id, 'aggregate_credits' if aggregate else 'credits': credits}
            rows = normalize_tmdb(wrapper, media_type).get('cast') or []
    for row in rows:
        li, path, folder = _person_item(row)
        _add(handle, li, path, folder)
    _finish(handle, 'actors')


def _crew(handle, params):
    meta = _online(params, 'crew')
    crew = meta.get('crew') or {}
    order = ('director','writer','creator','producer','photography','editor','art_department','sound_department')
    for group in order:
        for row in crew.get(group) or []:
            li, path, folder = _person_item(row, row.get('job') or row.get('role') or group.replace('_', ' ').title())
            _add(handle, li, path, folder)
    _finish(handle, 'actors')


def _images(handle, params):
    meta = _online(params, 'gallery')
    for row in all_images(meta):
        li = xbmcgui.ListItem(label=str(row.get('type') or ''), path=str(row.get('url') or ''), offscreen=True)
        li.setArt({'thumb': row.get('thumb') or row.get('url'), 'icon': row.get('thumb') or row.get('url'), 'fanart': row.get('url')})
        li.setProperties({'Type': str(row.get('type') or ''), 'Language': str(row.get('language') or ''), 'Width': str(row.get('width') or ''), 'Height': str(row.get('height') or '')})
        _add(handle, li, row.get('url') or '', False)
    _finish(handle, 'images')


def _videos(handle, params):
    meta = _online(params, 'videos')
    rows = list(meta.get('videos') or [])
    rows.sort(key=lambda row: trailer_rank({
        'language': row.get('iso_639_1') or row.get('language') or '',
        'official': row.get('official'),
        'type': row.get('type'),
    }) + (-safe_int(row.get('size')), str(row.get('name') or '').lower()))
    for row in rows:
        if row.get('site') != 'YouTube' or not row.get('key'):
            continue
        path = config.youtube_play_url(row.get('key'))
        li = xbmcgui.ListItem(label=str(row.get('name') or row.get('type') or ''), path=path, offscreen=True)
        thumb = 'https://i.ytimg.com/vi/%s/hqdefault.jpg' % row.get('key')
        li.setArt({'thumb': thumb, 'icon': thumb})
        li.setProperties({
            'Type': str(row.get('type') or ''),
            'Language': language_code(row.get('iso_639_1') or row.get('language') or ''),
            'Official': str(row.get('official') or ''),
            'PublishedAt': str(row.get('published_at') or ''),
        })
        _add(handle, li, path, False)
    _finish(handle, 'videos')


def _season_model(show_meta, row):
    data = dict(row)
    data['id'] = row.get('id')
    data['name'] = row.get('name') or 'Season %s' % row.get('season_number')
    data['overview'] = row.get('overview') or ''
    data['first_air_date'] = row.get('air_date') or ''
    data['poster_path'] = row.get('poster_path')
    model = normalize_tmdb(data, 'tv')
    model.update({'media_type': 'tv', 'tmdb_type': 'tv', 'tmdb_id': show_meta.get('tmdb_id'), 'season': safe_int(row.get('season_number')), 'dbtype': 'season', 'title': data['name']})
    return model


def _seasons(handle, params, flat=False):
    meta = _online(params)
    show_id = meta.get('tmdb_id') or safe_int(params.get('tmdb_id'))
    seasons = meta.get('seasons') or tmdb.seasons(show_id)
    if flat:
        for season in seasons:
            season_number = safe_int(season.get('season_number'))
            season_data = tmdb.season(show_id, season_number)
            for ep in season_data.get('episodes') or []:
                model = normalize_tmdb(ep, 'tv')
                model.update({'tmdb_id': show_id, 'tmdb_type': 'tv', 'dbtype': 'episode', 'season': season_number, 'episode': safe_int(ep.get('episode_number')), 'tvshowtitle': meta.get('title')})
                path = _url('details', tmdb_type='tv', tmdb_id=show_id, season=season_number, episode=model.get('episode'))
                _add(handle, make_video_listitem(model, path), path, True)
        _finish(handle, 'episodes')
        return
    for row in seasons:
        model = _season_model(meta, row)
        season_number = model.get('season')
        path = _url('episodes', tmdb_type='tv', tmdb_id=show_id, season=season_number)
        _add(handle, make_video_listitem(model, path), path, True)
    _finish(handle, 'seasons')


def _episodes(handle, params):
    meta = _online(params)
    show_id = meta.get('tmdb_id') or safe_int(params.get('tmdb_id'))
    season = safe_int(params.get('season') or meta.get('season'))
    season_data = tmdb.season(show_id, season)
    show_title = meta.get('title') or params.get('query') or ''
    show_art = meta.get('art') or {}
    show_landscape = show_art.get('landscape') or show_art.get('fanart') or ''
    show_fanart = show_art.get('fanart') or show_art.get('landscape') or ''
    for ep in season_data.get('episodes') or []:
        model = normalize_tmdb(ep, 'tv')
        # When TMDb has no still for the episode, the card should fall back to the
        # show's landscape (not a cropped poster). Publish the show landscape as
        # per-row tvshow art so the skin resolves it correctly even in mixed lists.
        ep_art = model.get('art') or {}
        if show_landscape and not ep_art.get('tvshow.landscape'):
            ep_art['tvshow.landscape'] = show_landscape
        if show_fanart and not ep_art.get('tvshow.fanart'):
            ep_art['tvshow.fanart'] = show_fanart
        model['art'] = ep_art
        model.update({'tmdb_id': show_id, 'tmdb_type': 'tv', 'dbtype': 'episode', 'season': season, 'episode': safe_int(ep.get('episode_number')), 'tvshowtitle': show_title})
        path = _url('details', tmdb_type='tv', tmdb_id=show_id, season=season, episode=model.get('episode'))
        _add(handle, make_video_listitem(model, path), path, True)
    _finish(handle, 'episodes')


def _collection(handle, params):
    collection_id = safe_int(params.get('tmdb_id'))
    data = tmdb.collection(collection_id)
    for row in data.get('parts') or []:
        model = normalize_tmdb(row, 'movie')
        path = _url('details', tmdb_type='movie', tmdb_id=model.get('tmdb_id'))
        _add(handle, make_video_listitem(model, path), path, True)
    _finish(handle, 'movies')


def _media_rows(handle, rows, limit=0):
    count = 0
    for row in rows or []:
        media_type = row.get('media_type') or ('tv' if row.get('name') and not row.get('title') else 'movie')
        if media_type not in ('movie','tv'):
            continue
        model = normalize_tmdb(row, media_type)
        path = _url('details', tmdb_type=media_type, tmdb_id=model.get('tmdb_id'))
        _add(handle, make_video_listitem(model, path), path, True)
        count += 1
        if limit and count >= limit:
            break
    return count


def _recommendations(handle, params, one=False):
    meta = _online(params)
    rows = meta.get('recommendations') or tmdb.recommendations(meta.get('tmdb_type'), meta.get('tmdb_id')).get('results') or []
    _media_rows(handle, rows, 1 if one else safe_int(params.get('limit')))
    _finish(handle, 'movies' if meta.get('tmdb_type') == 'movie' else 'tvshows')


def _credits(handle, params, mode):
    person_id = safe_int(params.get('tmdb_id'))
    data = tmdb.details('person', person_id)
    credits = data.get('combined_credits') or {}
    rows = []
    if mode in ('stars_in_movies','stars_in_tvshows','stars_in_both'):
        rows = credits.get('cast') or []
    else:
        rows = credits.get('crew') or []
        filter_key = params.get('filter_key')
        filter_value = params.get('filter_value')
        if filter_key and filter_value:
            rows = [x for x in rows if str(x.get(filter_key) or '').lower() == str(filter_value).lower()]
    if mode == 'stars_in_movies':
        rows = [x for x in rows if x.get('media_type') == 'movie']
    elif mode == 'stars_in_tvshows':
        rows = [x for x in rows if x.get('media_type') == 'tv']
    rows.sort(key=lambda x: x.get('release_date') or x.get('first_air_date') or '', reverse=True)
    _media_rows(handle, rows, safe_int(params.get('limit')))
    _finish(handle, 'videos')


def _search(handle, params):
    media_type = params.get('tmdb_type') or params.get('type') or 'multi'
    media_type = 'tv' if media_type in ('tvshow','show') else media_type
    query = params.get('query') or params.get('q') or ''
    page = safe_int(params.get('page'), 1)
    if params.get('with_genres') or params.get('with_keywords'):
        discover_params = {'page': page}
        if params.get('with_genres'):
            discover_params['with_genres'] = params.get('with_genres')
        if params.get('with_keywords'):
            discover_params['with_keywords'] = params.get('with_keywords')
        rows = tmdb.discover(media_type, discover_params).get('results') or []
        _media_rows(handle, rows, safe_int(params.get('limit')))
        _finish(handle, 'videos')
        return

    rows = tmdb.search(media_type, query, params.get('year'), page).get('results') or []
    if media_type == 'person':
        for row in rows:
            li, path = _person_item(row)
            _add(handle, li, path, True)
        _finish(handle, 'actors')
        return
    if media_type == 'collection':
        for row in rows:
            label = row.get('name') or row.get('original_name') or ''
            li = xbmcgui.ListItem(label=str(label), offscreen=True)
            poster = image_url(row.get('poster_path'), 'w780')
            fanart = image_url(row.get('backdrop_path'), 'original')
            li.setArt({k: v for k, v in {'poster': poster, 'thumb': poster, 'fanart': fanart}.items() if v})
            li.setProperties({'TMDb_ID': str(row.get('id') or ''), 'tmdb_id': str(row.get('id') or ''), 'tmdb_type': 'collection'})
            path = _url('collection', tmdb_id=row.get('id'))
            _add(handle, li, path, True)
        _finish(handle, 'sets')
        return
    if media_type == 'keyword':
        for row in rows:
            li = xbmcgui.ListItem(label=str(row.get('name') or ''), offscreen=True)
            path = _url('search', tmdb_type='movie', with_keywords=row.get('id'))
            li.setProperties({'TMDb_ID': str(row.get('id') or ''), 'tmdb_type': 'keyword'})
            _add(handle, li, path, True)
        _finish(handle, 'genres')
        return
    _media_rows(handle, rows, safe_int(params.get('limit')))
    _finish(handle, 'videos')


def _directory(handle, info, params):
    page = safe_int(params.get('page'), 1)
    if info == 'random_genres':
        media_type = params.get('tmdb_type') or 'movie'
        genres = tmdb.genres(media_type).get('genres') or []
        for row in genres:
            li = xbmcgui.ListItem(label=str(row.get('name') or ''), offscreen=True)
            path = _url('search', tmdb_type=media_type, with_genres=row.get('id'))
            _add(handle, li, path, True)
        _finish(handle, 'genres')
        return
    elif info == 'random_keyword':
        media_type = params.get('tmdb_type') or 'movie'
        rows = tmdb.discover(media_type, {'with_keywords': params.get('keyword') or params.get('id') or '', 'page': page}).get('results') or []
    else:
        rows = []
    _media_rows(handle, rows, safe_int(params.get('limit')))
    _finish(handle, 'videos')


def _truthy(value):
    return str(value or '').strip().lower() in ('1', 'true', 'yes', 'on')


def run(handle, params):
    info = params.get('info') or ''
    if info not in HANDLED:
        return False
    api_module.set_cache_only(_truthy(params.get('cacheonly')))
    try:
        if info == 'details': _details(handle, params)
        elif info == 'cast': _cast(handle, params)
        elif info == 'crew': _crew(handle, params)
        elif info in ('fanart','images'): _images(handle, params)
        elif info == 'videos': _videos(handle, params)
        elif info == 'seasons': _seasons(handle, params, False)
        elif info == 'flatseasons': _seasons(handle, params, True)
        elif info == 'episodes': _episodes(handle, params)
        elif info == 'collection': _collection(handle, params)
        elif info == 'recommendations': _recommendations(handle, params, False)
        elif info == 'next_recommendation': _recommendations(handle, params, True)
        elif info in ('stars_in_movies','stars_in_tvshows','stars_in_both','crew_in_both'): _credits(handle, params, info)
        elif info == 'search': _search(handle, params)
        else: _directory(handle, info, params)
        return True
    finally:
        api_module.set_cache_only(False)
