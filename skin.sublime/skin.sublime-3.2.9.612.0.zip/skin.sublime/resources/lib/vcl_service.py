# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

import os
import sys
import copy
import re
import time
import shutil
import json
import hashlib
import threading
import xml.etree.ElementTree as ET
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcaddon
try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

_ADDON_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
if _ADDON_ROOT not in sys.path:
    sys.path.insert(0, _ADDON_ROOT)

from resources.lib.sublime_helper.core import sync_metadata_properties, sync_player_properties, _current_item_fingerprint, prewarm_widget_neighbors, prewarm_widget_span, refresh_ui_snapshot, read_labels, read_label, invalidate_labels, demote_publication, set_focus_settled
from resources.lib.sublime_helper.image_wash import default_wash_color, request_wash_color
from resources.lib.hub import service as hub_service
from resources.lib.l10n import is_russian as _l10n_is_russian
from resources.lib.sublime_helper.poster_background import request_poster_background, request_pvr_background
from resources.lib.sublime_helper.hubs import (
    REAL_HUB_IDS, REAL_HUB_ID_SET, HUB_SERVICE_UI_VISIBILITY_CONDITION,
    HUB_AND_LOCAL_WINDOW_IDS, hub_from_window_id, local_window_id, valid_hub_id,
)

# Home plus every hub window, in both the logical (1103) and the runtime
# (11103) numbering Kodi reports for a custom window. Properties published by
# the helper already live on these windows, so mirroring into them is a no-op.
HOMEISH_WINDOW_IDS = frozenset([10000]) | HUB_AND_LOCAL_WINDOW_IDS

TARGET_ID = 'skin.sublime'
try:
    BUILD = xbmcaddon.Addon(id=TARGET_ID).getAddonInfo('version') or 'unknown'
except Exception:
    BUILD = 'unknown'


def _target_skin_active():
    try:
        return xbmc.getSkinDir() == TARGET_ID
    except Exception:
        return False


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('[sublime service %s] %s' % (BUILD, msg), level)
    except Exception:
        pass

def _translate_path(path):
    try:
        return xbmc.translatePath(path)
    except AttributeError:
        return xbmcvfs.translatePath(path) if xbmcvfs else path
    except Exception:
        return path


def _builtin_escape(value):
    try:
        value = '' if value is None else str(value)
        value = value.replace('\\', '\\\\').replace('"', '\\"')
        return '"%s"' % value
    except Exception:
        return '""'


def _run_skin_set_string(key, value):
    try:
        if not key:
            return False
        xbmc.executebuiltin('Skin.SetString(%s,%s)' % (key, _builtin_escape(value)))
        return True
    except Exception as exc:
        log('Skin.SetString failed %s: %s' % (key, exc), xbmc.LOGWARNING)
        return False


def _sync_keyboard_recent_skin_strings():
    """Load saved keyboard history into Skin.Strings once at startup/open.

    3.2.9.10.619: no DialogKeyboard GUI polling; search text is saved from
    extras/scripts/af3_no_sidemenu_search.py after xbmc.Keyboard confirmation.
    """
    try:
        path = _translate_path('special://profile/addon_data/skin.sublime/keyboard_history.json')
        items = []
        if path and os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as fh:
                data = json.load(fh)
            seen = set()
            if isinstance(data, list):
                for item in data:
                    item = (item or '').strip()
                    key = item.casefold()
                    if item and key not in seen:
                        items.append(item)
                        seen.add(key)
                    if len(items) >= 10:
                        break
        for idx in range(10):
            key = 'Sublime.KeyboardRecent.%02d' % (idx + 1)
            if idx < len(items):
                _run_skin_set_string(key, items[idx])
            else:
                try:
                    xbmc.executebuiltin('Skin.Reset(%s)' % key)
                except Exception:
                    pass
        log('keyboard recent skin strings synced: %s' % len(items))
    except Exception as exc:
        log('keyboard recent sync failed: %s' % exc, xbmc.LOGWARNING)


def _read_text_file(path):
    try:
        with open(path, 'rb') as fh:
            return fh.read().decode('utf-8', 'ignore')
    except Exception:
        return ''


_BUNDLED_VIDEO_DEFAULT_LABELS = set(['On Deck', 'In-Progress', 'New Movies', 'New Shows', 'Recent Shows', 'Top 250'])


_SEARCH_DEFAULT_MARKERS = set(['DefaultSearch-Movies', 'DefaultSearch-TvShows', 'DefaultSearch-Albums', 'DefaultSearch-Artists', 'DefaultSearch-TMDBMovies', 'DefaultSearch-TMDBShows'])


def patch_pvr_guide_onclicks(base):
    """Patch only PVR TV-group category onclicks to open the VCL true popup.

    VCL_SL 3.2.9.10.575: native tvguide is left untouched globally. Only
    category links whose own path is pvr://channels/tv/... are redirected to
    the Python popup directly, without the old Custom_1131 proxy.
    This removes the visible pre-popup flicker while normal TV Guide /
    MyPVRGuide remains native.
    """
    candidates = []
    try:
        candidates.append(os.path.join(base, '1080i'))
        candidates.append(os.path.join(base, 'shortcuts'))
    except Exception:
        pass
    for extra in (
        'special://profile/addon_data/skin.sublime',
        'special://profile/addon_data/skin.sublime',
    ):
        try:
            candidates.append(xbmc.translatePath(extra))
        except Exception:
            pass

    files = []
    for folder in candidates:
        if not folder or not os.path.isdir(folder):
            continue
        for dirpath, dirnames, filenames in os.walk(folder):
            if any(skip in dirpath for skip in ('__pycache__', '/resources/media', '/extras/')):
                continue
            for name in filenames:
                low = name.lower()
                if not (low.endswith('.xml') or low.endswith('.json') or low.endswith('.properties')):
                    continue
                files.append(os.path.join(dirpath, name))

    changed_files = 0
    replacements = 0

    def direct_repl(match):
        cond = match.group(1) or ''
        path = match.group(2)
        return '<onclick%s>RunScript(skin.sublime,pvr_action=open,pvr_path=%s)</onclick>' % (cond, path)

    # Exact onclicks where the pvr:// path is inside ActivateWindow(...).
    rx_direct = re.compile(
        r'<onclick([^>]*)>\s*ActivateWindow\((?:tvchannels|tvguide|TVGuide|pvrguide),\s*(pvr://channels/tv/(?!\*|\?|$)[^,\)<]+@1[^,\)<]*)\s*(?:,return)?\)\s*</onclick>',
        re.U
    )
    # Generated Custom_Submenu runtime onclicks: path is ListItem.FolderPath.
    runtime_cond = 'String.IsEqual(ListItem.Property(target),tvguide) + String.StartsWith(ListItem.FolderPath,pvr://channels/tv/)'
    runtime_old = '<onclick condition="%s">ActivateWindow(tvguide)</onclick>' % runtime_cond
    runtime_new = '<onclick condition="%s">RunScript(skin.sublime,pvr_action=open,pvr_path=$ESCINFO[ListItem.FolderPath])</onclick>' % runtime_cond
    # Some generated files may already have a simpler pvr FolderPath condition.
    rx_runtime_simple = re.compile(
        r'<onclick([^>] condition="[^"]*String\.StartsWith\(ListItem\.FolderPath,pvr://channels/tv/\)[^"]*"[^>]*)>\s*ActivateWindow\(tvguide\)\s*</onclick>',
        re.U | re.I
    )

    def runtime_simple_repl(match):
        attrs = match.group(1)
        return '<onclick%s>RunScript(skin.sublime,pvr_action=open,pvr_path=$ESCINFO[ListItem.FolderPath])</onclick>' % attrs

    # Clean up files already patched by older builds: SetProperty(...)+ActivateWindow(1131)
    # becomes one direct RunScript call, so no empty proxy dialog flashes before the popup.
    rx_old_bridge = re.compile(
        r'<onclick(?P<attrs>[^>]*)>\s*SetProperty\(VCL\.PVRPopup\.Path,\s*(?P<path>[^,\)\n]+)\s*,\s*Home\)\s*</onclick>\s*\n?\s*<onclick(?P=attrs)>\s*ActivateWindow\(1131\)\s*</onclick>',
        re.U | re.I
    )

    def old_bridge_repl(match):
        return '<onclick%s>RunScript(skin.sublime,pvr_action=open,pvr_path=%s)</onclick>' % (match.group('attrs'), match.group('path'))

    for path in files:
        try:
            with open(path, 'rb') as fh:
                old = fh.read().decode('utf-8', 'ignore')
            new = old
            # Migrate already-generated links from older builds to the registered
            # skin script entrypoint so Kodi does not invoke Python without addon context.
            new = new.replace(
                'RunScript(special://skin/resources/lib/vcl_pvr_guide_popup.py,action=open,path=',
                'RunScript(skin.sublime,pvr_action=open,pvr_path=')
            new = new.replace(
                'RunScript(special://skin/resources/lib/vcl_pvr_guide_popup.py,action=open)',
                'RunScript(skin.sublime,pvr_action=open)')
            new, c1 = rx_direct.subn(direct_repl, new)
            c2 = 0
            if runtime_old in new:
                new = new.replace(runtime_old, runtime_new)
                c2 = 1
            new, c3 = rx_runtime_simple.subn(runtime_simple_repl, new)
            new, c4 = rx_old_bridge.subn(old_bridge_repl, new)
            if new != old:
                with open(path, 'wb') as fh:
                    fh.write(new.encode('utf-8'))
                changed_files += 1
                replacements += c1 + c2 + c3 + c4
        except Exception as exc:
            log('pvr popup link patch skipped %s: %s' % (path, exc), xbmc.LOGWARNING)
    if changed_files or replacements:
        log('pvr popup link patch: files=%d replacements=%d' % (changed_files, replacements))
    return replacements


def _home_window():
    try:
        return xbmcgui.Window(10000)
    except Exception:
        return xbmcgui.Window(xbmcgui.getCurrentWindowId())


def _action_buttons_any_enabled():
    try:
        trailer_available = xbmc.getCondVisibility(
            '!Skin.HasSetting(VCL.ActionButtons.DisableTrailer) + '
            '[!String.IsEmpty(Window(Home).Property(SublimeHelper.ListItem.Trailer)) | '
            '!String.IsEmpty(Window(Home).Property(SublimeHelper.ListItem.TrailerFallback)) | '
            '!String.IsEmpty(Window(Home).Property(SublimeHelper.ListItem.TrailerCandidates))]'
        )
        return (
            trailer_available or
            not xbmc.getCondVisibility('Skin.HasSetting(VCL.ActionButtons.DisableDetails)') or
            not xbmc.getCondVisibility('Skin.HasSetting(VCL.ActionButtons.DisablePlot)') or
            not xbmc.getCondVisibility('Skin.HasSetting(VCL.ActionButtons.DisableCast)') or
            not xbmc.getCondVisibility('Skin.HasSetting(VCL.ActionButtons.DisableGallery)')
        )
    except Exception:
        return True


def _action_button_has_focus():
    try:
        return xbmc.getCondVisibility('Control.HasFocus(692) | Control.HasFocus(693) | Control.HasFocus(694) | Control.HasFocus(695) | Control.HasFocus(696) | ControlGroup(690).HasFocus()')
    except Exception:
        return False


# Полосы категорий: у хаба - 601, у комбинированных видов - 52x (одно и то же
# включение Categories_Selector, Includes_Categories.xml). Это НЕ медиа-строки:
# у вкладки «Все» нет ни арта, ни логотипа.
_SELECTOR_FOCUS = ' | '.join(
    'Control.HasFocus(%d)' % cid for cid in (601,) + tuple(range(521, 529)))


# В каком окне снят снимок, который разрешено держать, пока фокус стоит на
# полосе категорий или всплывающих кнопках. Между окнами он не переезжает.
_KEEP_SNAPSHOT = {'window': 0}


def _selector_has_focus():
    """Фокус на полосе категорий, а не на строке с содержимым.

    08.09.2026 владелец: «Что это за поведение фона при навигации с виджета на
    категорию и обратно?» Замер на .30, хаб 1100: на плитках фон, подложка и
    логотип есть; шаг вверх на полосу категорий (контрол 601, метка «Все») -
    ВСЁ ТРИ пропадают; шаг вниз - возвращаются. Причина: служба публиковала
    вкладку как строку, а у вкладки арта нет, и публикация честно всё снимала.

    Правило для такого уже было - им живут всплывающие кнопки (692-696):
    пока фокус на не-медиа контроле, снимок держится. Полоса категорий - тот
    же случай, поэтому правило одно на оба.
    """
    try:
        return xbmc.getCondVisibility(_SELECTOR_FOCUS)
    except Exception:
        return False


def _freeze_action_popup_snapshot(win):
    """Freeze one source media item for the whole popup/dialog lifecycle."""
    try:
        source_key = win.getProperty('SublimeHelper.ListItem.Key') or ''
        if not source_key:
            return
        if win.getProperty('VCL.ActionPopup.SourceKey') == source_key:
            return
        destinations = (
            'VCL.ActionPopup.DBID', 'VCL.ActionPopup.DBType', 'VCL.ActionPopup.TMDB_ID',
            'VCL.ActionPopup.TMDB_Type', 'VCL.ActionPopup.Kinopoisk_ID',
            'VCL.ActionPopup.IMDb_ID', 'VCL.ActionPopup.Title',
            'VCL.ActionPopup.Fanart', 'VCL.ActionPopup.Trailer', 'VCL.ActionPopup.TrailerFallback',
            'VCL.ActionPopup.TrailerCandidates',
        )
        for name in destinations:
            win.clearProperty(name)
        mappings = {
            'VCL.ActionPopup.DBID': ('SublimeHelper.ListItem.DBID', 'VCL.Widget.DBID'),
            'VCL.ActionPopup.DBType': ('SublimeHelper.ListItem.DBType', 'VCL.Widget.DBType'),
            'VCL.ActionPopup.TMDB_ID': ('SublimeHelper.ListItem.TMDB_ID', 'VCL.Widget.TMDB_ID'),
            'VCL.ActionPopup.TMDB_Type': ('SublimeHelper.ListItem.TMDB_Type', 'VCL.Widget.TMDB_Type'),
            'VCL.ActionPopup.Kinopoisk_ID': ('SublimeHelper.ListItem.Kinopoisk_ID', 'VCL.Widget.Kinopoisk_ID'),
            'VCL.ActionPopup.IMDb_ID': ('SublimeHelper.ListItem.IMDb_ID', 'VCL.Widget.IMDb_ID'),
            'VCL.ActionPopup.Title': ('SublimeHelper.ListItem.Title', 'VCL.Widget.Title'),
            'VCL.ActionPopup.Fanart': ('SublimeHelper.ListItem.Fanart', 'VCL.Widget.Fanart'),
            'VCL.ActionPopup.Trailer': ('SublimeHelper.ListItem.Trailer',),
            'VCL.ActionPopup.TrailerFallback': ('SublimeHelper.ListItem.TrailerFallback',),
            'VCL.ActionPopup.TrailerCandidates': ('SublimeHelper.ListItem.TrailerCandidates',),
        }
        for destination, sources in mappings.items():
            value = ''
            for source in sources:
                value = win.getProperty(source) or ''
                if value:
                    break
            if value:
                win.setProperty(destination, value)
        win.setProperty('VCL.ActionPopup.SourceKey', source_key)
        log('action popup snapshot: key=%s trailer=%s trailer_fallback=%s fanart=%s' % (
            source_key[:80], 'yes' if win.getProperty('VCL.ActionPopup.Trailer') else 'no',
            'yes' if win.getProperty('VCL.ActionPopup.TrailerFallback') else 'no',
            'yes' if win.getProperty('VCL.ActionPopup.Fanart') else 'no'))
    except Exception as exc:
        log('action popup snapshot skipped: %s' % exc, xbmc.LOGWARNING)


def _focused_widget_row():
    try:
        for cid in range(501, 551):
            if xbmc.getCondVisibility('Control.HasFocus(%d)' % cid):
                return cid
    except Exception:
        pass
    return 0


def _media_nav_active_row_id():
    """Return the container id that actually holds focus inside MyVideoNav.

    Control 500 is the normal list/grid view. Combined view types (521/522/
    524/526/528, see Includes_Views_Combined.xml) render their season/category
    selector in that container and their episode/content row in a second,
    separate container (531/532/534/536/538 respectively) - never in 500.
    Assuming 500 unconditionally leaves every Combined-view row (e.g. a
    plugin's seasons/episodes list) without the fanart/clearlogo/ratings sync
    below, since the probe was reading an unfocused, often empty container.

    Sublime 893: the hardcoded id set was still incomplete. A plain (non-Combined)
    view type renders its rows in its own container - "Ряд: панель" uses 504, and
    the other row/list views use their own 50x ids - none of which appear above,
    so every helper property was published for empty container 500 while the user
    was looking at 504. The published fingerprint then never matched the focused
    row, which is what kept an episode list on its poster fallback background even
    though validated fanart was available (see _container_has_real_fanart). Ask
    Kodi which control actually has focus instead of guessing, and only fall back
    to the known-id probe when focus is not on a populated container at all.
    """
    chosen = 0
    try:
        focused = int(str(read_label('System.CurrentControlId') or '0').strip() or 0)
        if focused > 0 and read_label('Container(%d).NumItems' % focused):
            chosen = focused
    except Exception:
        chosen = 0
    if not chosen:
        try:
            for cid in (500, 531, 532, 534, 536, 538, 521, 522, 524, 526, 528):
                if xbmc.getCondVisibility('Control.HasFocus(%d)' % cid):
                    chosen = cid
                    break
        except Exception:
            chosen = 0
    # Список серий главнее фокуса. Записано на .20 2026-08-29: на входе в
    # сериал служба публиковала сезон с кадром сериала (65.7, 83.3, 95.4,
    # 111.4 с записи), а один раз посреди прохода - сам сериал (107.5 с).
    # Kodi считает текущим селектор сезонов - его ListItem «Сезон 1» держится
    # всё время, пока владелец идёт по сериям. Пока на экране есть список,
    # показывающий серию, публикуем его строку.
    episodes = _episode_container_id(chosen)
    if episodes:
        return _steady_nav_row(episodes)
    return _steady_nav_row(chosen or 500)


def _episode_container_id(preferred=0):
    """Список, текущая строка которого - серия. 0, если такого нет.

    Найденный список запоминается: пока он всё ещё показывает серию, стоит
    одно чтение метки, а перебор идёт только на входе в сериал и на выходе.
    """
    memo = _NAV_ROW_MEMO
    cached = int(memo.get('episode_id') or 0)
    if cached and not _container_on_screen(cached):
        # Окно сменилось (список серий -> канал YouTube, другой вид): невидимая
        # полоса серий хранит серию прошлого сериала.
        memo['episode_id'] = 0
        cached = 0
    if cached and _strip_is_stale(cached):
        return 0
    if cached:
        if _container_item_is_episode(cached):
            return cached
        # Пока полоса серий на экране, держимся её, даже если строка на такт
        # не прочиталась или курсор стоит на заголовке сезона внутри той же
        # полосы. Записано на .20 2026-08-29 (диагностика публикаций): пока
        # владелец шёл по сериям в списке 531, служба публиковала соседний
        # список сериалов 502 - «В Филадельфии всегда солнечно» с его
        # лендскейпом - и пустой 500. Это и есть подменённый фон.
        if _container_alive(cached):
            return cached
        memo['episode_id'] = 0
    for cid in (preferred, int(memo.get('id') or 0), 500, 504, 531, 532, 534,
                536, 538, 521, 522, 524, 526, 528):
        if (cid and _container_on_screen(cid) and _container_item_is_episode(cid)
                and not _strip_is_stale(cid)):
            memo['episode_id'] = cid
            return cid
    memo['episode_id'] = 0
    return 0


# Контейнер, для которого мы публикуем, и кандидат на смену.
_NAV_ROW_MEMO = {'id': 0, 'pending': 0}


def _steady_nav_row(chosen):
    """Не менять контейнер по одному кадру.

    В списке серий Kodi на отдельных тактах называет текущим родительский
    контейнер - сезон или сам сериал. Служба публиковала данные этого
    родителя, и на экран на мгновение возвращались картинка и логотип
    сериала вместо кадра серии. Замерено на .20 2026-08-29 (75 с, 7 замеров
    в секунду): подпись шла по сериям - «Бумага», «Укрытие», «Первый танец», -
    и дважды за минуту сменялась на «Сезон 1», а один раз на «Джек Ричер».

    Новый контейнер принимается сразу, если прежний потерял фокус, и только
    со второго подтверждения, если прежний фокус держит.
    """
    memo = _NAV_ROW_MEMO
    last = int(memo.get('id') or 0)
    if not chosen or chosen == last:
        memo['pending'] = 0
        return chosen or last or 500
    keeps_focus = False
    if last:
        try:
            keeps_focus = bool(xbmc.getCondVisibility('Control.HasFocus(%d)' % last))
        except Exception:
            keeps_focus = False
    # Записано на .20 2026-08-29: контейнер тот же, а публикация на два такта
    # сменилась с серии на сезон, и фоном встал кадр сериала. В этом окне два
    # списка - селектор сезонов и полоса серий, - и Kodi на отдельных тактах
    # называет текущим селектор. Пока прежний список показывает серию, а новый
    # нет, остаёмся на прежнем: строка на экране не менялась.
    if last and _container_item_is_episode(last) and not _container_item_is_episode(chosen):
        memo['pending'] = 0
        return last
    if keeps_focus and memo.get('pending') != chosen:
        memo['pending'] = chosen
        return last
    memo['id'] = chosen
    memo['pending'] = 0
    return chosen


# Номер серии в адресе строки: `.../play/?s=1&e=3`.
_EPISODE_ROUTE = re.compile(r'[?&]e=(\d+)')


def _container_on_screen(cid):
    """Список виден в окне сейчас - не только существует в памяти Kodi.

    06.11.2026 владелец: «Во всех роликах - Улей» (канал YouTube на .20).
    Окно «Видео» держит в памяти все виды сразу, и невидимый контейнер 531
    (полоса серий вида 521) хранил серию «Улей» 1x2 от прошлого захода в сезон
    Filmix: Control.IsVisible(531) = false, а ListItem - живая серия. Перебор
    кандидатов в _episode_container_id видимость не проверял и называл этот
    контейнер «списком серий», поэтому служба публиковала его строку вместо
    ролика: чужой логотип, жанры «детектив / криминал», фон сериала.
    """
    if not cid:
        return False
    try:
        return bool(xbmc.getCondVisibility('Control.IsVisible(%d)' % int(cid)))
    except Exception:
        return False


def _container_alive(cid):
    """Список ещё на экране и не пуст."""
    if not cid:
        return False
    try:
        if not xbmc.getCondVisibility('Control.IsVisible(%d)' % int(cid)):
            return False
    except Exception:
        return False
    try:
        return bool(read_label('Container(%d).NumItems' % int(cid)))
    except Exception:
        return False


_POST_OF_PATH = re.compile(r'/(\d+)-[^/?]*/')


def _strip_is_stale(cid):
    """Полоса серий ещё держит прежнее содержимое.

    Окно видео Kodi держит в памяти, и при новом открытии полоса серий под
    сезонами (531 и соседние) какое-то время показывает серии ПРОШЛОГО
    сериала, пока не перечитает свой адрес. Записано на .30 17.10.2026 при
    открытии «Квеста Вижна» после «Медленных лошадей»: на +1.10 с сезоны уже
    свои, а в 531 всё ещё s1e1 «Лошадей» (Container(531).IsUpdating), на
    +1.81 с служба опубликовала её - «Недотепство заразно», логотип, фон и
    Apple TV, - и только на +2.52 с правильное. Владелец снял это на .20:
    «вылезает чужой фон, сериала, который открывался недавно».

    Такая полоса не годится, пока обновляется или пока её серия от другого
    сериала, чем строка с фокусом.
    """
    try:
        if xbmc.getCondVisibility('Container(%d).IsUpdating' % int(cid)):
            return True
    except Exception:
        return True
    try:
        own = _POST_OF_PATH.search(str(
            read_label('Container(%d).ListItem.FileNameAndPath' % int(cid)) or ''))
        focused = int(str(read_label('System.CurrentControlId') or '0').strip() or 0)
        parent = ''
        if focused and focused != int(cid):
            parent = (read_label('Container(%d).ListItem.FolderPath' % focused)
                      or read_label('Container(%d).ListItem.FileNameAndPath' % focused) or '')
        if not parent:
            parent = read_label('Container.FolderPath') or ''
        theirs = _POST_OF_PATH.search(str(parent))
        if own and theirs and own.group(1) != theirs.group(1):
            return True
    except Exception:
        pass
    return False


def _container_item_is_episode(cid):
    """Показывает ли этот список серию - по адресу его текущей строки."""
    if not cid:
        return False
    try:
        path = read_label('Container(%d).ListItem.FileNameAndPath' % int(cid)) or ''
        if not path:
            path = read_label('Container(%d).ListItem.FolderPath' % int(cid)) or ''
    except Exception:
        return False
    hit = _EPISODE_ROUTE.search(str(path))
    try:
        return bool(hit) and int(hit.group(1)) > 0
    except Exception:
        return False


def _last_hub_window_id(default='1100'):
    try:
        value = (_home_window().getProperty('Sublime.LastHub') or
                 read_label('Skin.String(Sublime.LastHub)') or '').strip()
        if value in REAL_HUB_IDS:
            return value
    except Exception:
        pass
    return default


def _is_homeish_window():
    try:
        return xbmc.getCondVisibility(HUB_SERVICE_UI_VISIBILITY_CONDITION)
    except Exception:
        return False


def _is_media_nav_window():
    try:
        return bool(xbmc.getCondVisibility('Window.IsVisible(MyVideoNav.xml) | Window.IsVisible(10025) | Window.IsVisible(videos)'))
    except Exception:
        return False


def _mirror_listitem_props_to_current_window(win):
    # Dead since 851/852: it called an undefined HOMEISH_WINDOW_IDS, the
    # NameError hit its own except, and it returned before copying anything.
    # 940 defined that name and the mirroring started working - and the first
    # thing it did was paint a wrong identity into a list window: a «Безумцы»
    # episode had resolved to Harry Potter, and where 938 kept that on Home
    # only, 940 copied its clearlogo onto the open episode list. The identity
    # bug is fixed separately (core.py: an episode is identified by its series
    # title, never by "Серия 1"); this stays off, because "mirror whatever Home
    # currently holds onto whatever window is open" has no per-row validation
    # of its own and every list window already reads Window(Home) directly.
    # Kept as a defined no-op so the call site and the intent stay visible.
    return
    try:  # noqa: unreachable - see above
        cur_id = int(xbmcgui.getCurrentWindowId())
        if cur_id in HOMEISH_WINDOW_IDS:
            return
        cur = xbmcgui.Window(cur_id)
    except Exception:
        return
    names = (
        'SublimeHelper.ListItem.CropImage', 'SublimeHelper.ListItem.ClearLogo',
        'SublimeHelper.ListItem.BlurImage', 'SublimeHelper.ListItem.BlurImage.Original',
        'SublimeHelper.ListItem.Current.BlurImage', 'SublimeHelper.ListItem.Current.BlurImage.Original',
        'SublimeHelper.ListItem.Fanart', 'SublimeHelper.ListItem.TVShow.Fanart',
        'SublimeHelper.ListItem.IMDb_Rating', 'SublimeHelper.ListItem.TMDb_Rating',
        'SublimeHelper.ListItem.Kinopoisk_Rating', 'SublimeHelper.ListItem.MDBList_Rating',
        'SublimeHelper.ListItem.Trakt_Rating', 'SublimeHelper.ListItem.MetaCritic_Rating',
        'SublimeHelper.ListItem.RottenTomatoes_Rating', 'SublimeHelper.ListItem.RottenTomatoes_UserMeter',
        'SublimeHelper.ListItem.Letterboxd_Rating', 'SublimeHelper.ListItem.Top250',
        'SublimeHelper.ListItem.IdentityPending', 'SublimeHelper.ListItem.IdentityRejected',
    )
    try:
        for name in names:
            value = win.getProperty(name)
            if value:
                cur.setProperty(name, value)
            else:
                cur.clearProperty(name)
    except Exception:
        pass


def _normal_hub_window_id(value):
    value_text = str(value or '').strip().lower()
    if value_text in ('home', '10000'):
        # Legacy/system Home means the last active peer, never hub 1100.
        return _last_hub_window_id()
    return hub_from_window_id(value_text)


def _source_hub_window_id():
    try:
        current_id = int(xbmcgui.getCurrentWindowId())
        if current_id == 10000:
            return _last_hub_window_id()
        current_hub = _normal_hub_window_id(current_id)
        if current_hub:
            return current_hub
    except Exception:
        pass
    try:
        for wid in REAL_HUB_IDS:
            cond = 'Window.IsVisible(%s) | Window.IsVisible(%s)' % (wid, int(wid) + 10000)
            if xbmc.getCondVisibility(cond):
                return wid
    except Exception:
        pass
    return ''


def _remember_last_hub(win, source=''):
    try:
        source = valid_hub_id(source) or _source_hub_window_id()
        if source not in REAL_HUB_ID_SET:
            return
        current = (win.getProperty('Sublime.LastHub') or
                   read_label('Skin.String(Sublime.LastHub)') or '').strip()
        if current == source:
            return
        win.setProperty('Sublime.LastHub', source)
        xbmc.executebuiltin('Skin.SetString(Sublime.LastHub,%s)' % source)
        log('last active hub: %s' % source)
    except Exception as exc:
        log('last hub update skipped: %s' % exc, xbmc.LOGWARNING)

def _clear_widget_keepalive(win):
    for name in ('VCL.Widget.KeepAliveActive', 'VCL.Widget.KeepAliveHub', 'VCL.Widget.KeepAliveRow', 'VCL.Widget.KeepAliveReturning'):
        try:
            win.clearProperty(name)
        except Exception:
            pass


def _set_widget_keepalive(win, hub_id, row_id):
    hub_id = valid_hub_id(hub_id)
    try:
        row_id = int(row_id or 0)
    except (TypeError, ValueError):
        row_id = 0
    if not hub_id or not 501 <= row_id <= 550:
        _clear_widget_keepalive(win)
        return False
    win.setProperty('VCL.Widget.KeepAliveHub', hub_id)
    win.setProperty('VCL.Widget.KeepAliveRow', str(row_id))
    win.setProperty('VCL.Widget.KeepAliveActive', 'true')
    return True


_NAV_TRANSIENT_ALARMS = (
    'AF3VerticalNav.Clear', 'AF3VerticalNav.ClearFromMenu',
    'AF3VerticalNav.ClearFromWidgets', 'AF3VerticalNav.ClearMenuScroll',
    'AF3VerticalNav.ClearMenuScrollOnload', 'AF3VerticalNav.ContentRefocus',
    'AF3VerticalNav.Guard300Content', 'AF3VerticalNav.Guard300Empty',
    'AF3VerticalNav.MenuHoldRefocus', 'AF3VerticalNav.MenuRefocus',
    'AF3IconCarousel.Clear', 'AF3IconCarousel.FadeStart',
    'AF3IconWheel.DownClear', 'AF3IconWheel.DownPreClear',
    'AF3IconWheel.DownStart', 'AF3IconWheel.DownStarted',
    'AF3IconWheel.UpClear', 'AF3IconWheel.UpPreClear',
    'AF3IconWheel.UpStart', 'AF3IconWheel.UpStarted',
)

_NAV_TRANSIENT_PROPERTIES = (
    'AF3VerticalNav.Direction', 'AF3VerticalNav.FromMenu',
    'AF3VerticalNav.FromWidgets', 'AF3VerticalNav.MenuScroll',
    'AF3IconCarousel.Direction', 'AF3IconCarousel.FadeHold',
    'AF3IconWheel.PreDown', 'AF3IconWheel.PreUp',
    'AF3IconWheel.Started', 'AF3IconWheel.UpPulse',
    'AF3IconWheel.DownPulse', 'AF3IconWheel.OldCenter',
    'AF3IconWheel.OldFar', 'AF3IconWheel.OldNear',
    'AF3IconWheel.OldTop',
)


def _refresh_after_playback(win, row_id, was_pvr):
    """Перерисовать полосу, с которой ушли смотреть, сразу после просмотра.

    Требование владельца дословно: «Маркер просмотрено и неоконченного прогресса
    должен появляться СРАЗУ ПОСЛЕ ПРОСМОТРА». Сам по себе он не появляется:
    строка виджета - это то, что контейнер загрузил при своём создании, и Kodi
    не перечитывает её, пока окно живо. Замер на .30 04.09.2026: «Сценарий
    следующей войны» просмотрен в 22:05, в базе Kodi playcount 1, на экране
    отметки нет.

    Момент выбран единственный безопасный - край окончания воспроизведения:
    владелец только что сам нажал стоп, полоса под курсором известна
    (VCL.Widget.KeepAliveRow), и опустошение плиток на полсекунды здесь не
    выглядит миганием на пустом месте. Курсор возвращается на прежнюю позицию:
    именно его потерю владелец называл главной бедой Container.Refresh.

    PVR пропускается: у телеканала нет состояния просмотра.
    """
    try:
        from resources.lib.hub import history
        # Снимок истории кешируется на 45 с. Без сброса маршрут отдал бы то же
        # состояние, что и до просмотра, и обновление оказалось бы пустым.
        history.invalidate()
    except Exception as exc:
        log('сброс снимка истории не удался: %s' % exc)
    if was_pvr:
        return
    try:
        row = int(row_id or 0)
    except Exception:
        return
    if not (501 <= row <= 550):
        return
    try:
        if not xbmc.getCondVisibility('Control.HasFocus(%d)' % row):
            return
        position = int(xbmc.getInfoLabel('Container(%d).CurrentItem' % row) or 0)
        # Курсор НЕ трогаем. Container.Refresh сохраняет его сам - проверено на
        # .30 05.09.2026: строка 5 до обновления, строка 5 после. А SetFocus без
        # флага absolute считает позиции относительно и уезжает (SetFocus(501,4)
        # даёт строку 6, SetFocus(501,4,absolute) - строку 5), и владелец увидел
        # это как «после выключения фокус виджета сдвигается вправо».
        xbmc.executebuiltin('Container.Refresh')
        for _ in range(20):
            xbmc.sleep(100)
            if not xbmc.getCondVisibility('Container(%d).IsUpdating' % row):
                break
        log('полоса %d перерисована после просмотра, курсор остался на %d'
            % (row, position))
    except Exception as exc:
        log('перерисовка после просмотра не удалась: %s' % exc)

# Что под курсором - для контекстного меню (DialogContextMenu.xml и
# sublime_helper/actions.hide_context_information). Внутри открытого меню
# Kodi сведений о плитке не отдаёт: Container(501).ListItem.* там пуст, и
# ControlList.getSelectedItem() возвращает None (проверено на .30 06.11.2026).
# Поэтому тип плитки публикуется заранее, пока меню закрыто:
#   pvr    - телеканал (меню не открывается вовсе, владелец 06.11.2026);
#   movie / tvshow / ... - DBType плитки.
CONTEXT_KIND_PROPERTY = 'Sublime.ContextKind'


def _publish_context_kind(win):
    try:
        if xbmc.getCondVisibility('Window.IsVisible(DialogContextMenu.xml)'):
            return
        focus = xbmcgui.Window(xbmcgui.getCurrentWindowId()).getFocusId()
    except Exception:
        focus = 0
    kind = ''
    if focus:
        prefix = 'Container(%d).ListItem.' % focus
        got = read_labels([prefix + 'FileNameAndPath', prefix + 'FolderPath',
                           prefix + 'DBType'])
        path = got.get(prefix + 'FileNameAndPath') or got.get(prefix + 'FolderPath') or ''
        if path.startswith('pvr://channels/'):
            kind = 'pvr'
        else:
            kind = got.get(prefix + 'DBType') or ''
    if win.getProperty(CONTEXT_KIND_PROPERTY) != kind:
        win.setProperty(CONTEXT_KIND_PROPERTY, kind)


def _clear_playback_navigation_transients(win):
    """Cancel stale vertical-navigation callbacks while playback owns focus.

    AlarmClock callbacks created by a last Up/Down action can survive the switch to
    fullscreen playback. When they fire during/after PVR shutdown they activate an
    adjacent custom hub and Kodi rebuilds every plugin container in that window.
    This function only clears transient animation/navigation state; it never opens,
    closes or replaces a window.
    """
    for name in _NAV_TRANSIENT_ALARMS:
        try:
            xbmc.executebuiltin('CancelAlarm(%s,silent)' % name)
        except Exception:
            pass
    for name in _NAV_TRANSIENT_PROPERTIES:
        try:
            win.clearProperty(name)
        except Exception:
            pass


def _hub_window_visible(window_id):
    """True when the given hub is on screen under either of its window ids.

    Kodi exposes a custom hub as both its logical id (1103) and its runtime id
    (11103); hubs.py owns that mapping, so ask it rather than listing ids here.
    """
    hub_id = hub_from_window_id(window_id) or valid_hub_id(window_id)
    if not hub_id:
        return False
    try:
        return bool(xbmc.getCondVisibility('Window.IsVisible(%s) | Window.IsVisible(%s)' % (
            hub_id, local_window_id(hub_id))))
    except Exception:
        return False

def _row_fingerprint(row_id):
    """«Та же ли это строка» - самым дешёвым вопросом, какой есть.

    Полный ключ (_current_item_key) читает пять полей строки, а у строки PVR
    каждое поле - обращение к клиенту телегида: замерено на .30, зонд стоил
    18 мс на КАЖДОМ такте цикла, то есть около 7% ядра.

    Здесь спрашивается номер позиции в контейнере - это просто число, Kodi не
    трогает саму строку, - и её имя, чтобы заметить подмену содержимого без
    перемещения фокуса. Обе метки берутся одной выборкой.
    """
    try:
        cid = int(row_id)
    except Exception:
        return ''
    position = 'Container(%d).CurrentItem' % cid
    label = 'Container(%d).ListItem.Label' % cid
    got = read_labels([position, label])
    return '%s|%s|%s' % (cid, got.get(position) or '', got.get(label) or '')


def _current_item_key(row_id):
    # Read identity from the actual focused widget container. Global ListItem.* can
    # lag one or two GUI frames behind a vertical row change and previously kept
    # the action/metadata state attached to the old item.
    try:
        prefix = 'Container(%s).ListItem.' % int(row_id)
        # This runs on every turn of the loop, so it asks once for everything
        # it needs rather than six times in a row.
        got = read_labels([prefix + name for name in (
            'Label', 'Title', 'FileNameAndPath', 'FolderPath', 'DBID')])
        pick = lambda name: got.get(prefix + name) or ''
        label = pick('Label') or pick('Title')
        path = pick('FileNameAndPath') or pick('FolderPath')
        dbid = pick('DBID')
        # No tmdb id here, and that is the whole point: this key answers "which
        # row is this", not "how far has its enrichment got". It used to include
        # Property(tmdb_id) and Property(SublimeHelper.ListItem.TMDB_ID), which
        # WE publish onto the row once it resolves - so about a second and a half
        # after focus the key changed by itself, the loop read that as a new row
        # and demoted the identity it had just published. Caught on .20 at 20 Hz:
        # Fanart, Landscape, BlurImage and ClearLogo all went empty together and
        # came back 80 ms later, with IdentityPending raised in between. That is
        # the blink the owner filmed. The row's own path already identifies it.
        return '%s|%s|%s|%s' % (row_id, label, path, dbid)
    except Exception:
        return '%s|' % row_id


def _first_studio(value):
    try:
        value = _clean_info_value(value)
        if not value:
            return ''
        value = value.replace('[CR]', ' / ')
        parts = re.split(r'\s*/\s*|\s*•\s*|\s*,\s*|\s*;\s*|\s*\|\s*', value)
        for part in parts:
            part = re.sub(r'\s+', ' ', (part or '').strip(), flags=re.U)
            if part:
                return part
    except Exception:
        pass
    return ''


def _first_nonempty_studio_from_labels(labels):
    for label in labels:
        try:
            studio = _first_studio(read_label(label))
            if studio:
                return studio
        except Exception:
            pass
    return ''


def _container_first_studio(cid):
    studio = _first_nonempty_studio_from_labels([
        'Container(%s).ListItem.Studio' % cid,
        'Container(%s).ListItem.Property(Studio)' % cid,
        'Container(%s).ListItem.Property(studio)' % cid,
        'Container(%s).ListItem.Property(Studios)' % cid,
        'Container(%s).ListItem.Property(studios)' % cid,
        'Container(%s).ListItem.Property(network)' % cid,
        'Container(%s).ListItem.Property(Network)' % cid,
        'Container(%s).ListItem.Property(production_company)' % cid,
        'Container(%s).ListItem.Property(production_companies)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Studio)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Studio.1.Name)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Network.1.Name)' % cid,
    ])
    if studio:
        return studio
    try:
        for label in (
            'Container(%s).ListItem.Property(studio.0.name)' % cid,
            'Container(%s).ListItem.Property(studios.0.name)' % cid,
            'Container(%s).ListItem.Property(production_companies.0.name)' % cid,
            'Container(%s).ListItem.Property(networks.0.name)' % cid,
        ):
            studio = _first_studio(read_label(label))
            if studio:
                return studio
    except Exception:
        pass
    return ''


def _vfs_exists(path):
    try:
        if xbmcvfs:
            return bool(xbmcvfs.exists(path))
    except Exception:
        pass
    try:
        translated = _translate_path(path)
        return bool(translated and os.path.exists(translated))
    except Exception:
        return False


_YOUTUBE_AVATAR_CACHE = {}
_YOUTUBE_AVATAR_WANTED = {'id': ''}


def _youtube_channel_avatar(channel_id):
    """Аватар канала для правого нижнего угла.

    Строка YouTube несёт только кадр ролика, а аватар нужен канала. Дополнение 7 держало его в
    своём data_cache.sqlite; у дополнения 8 (с 26.11.2026) такого кэша нет, поэтому аватар - из
    своего кэша скина (sublime_helper/youtube_channels: внутренний интерфейс сайта, без ключа), а
    при промахе - запрос в фоне, и ответ публикуется, если на экране всё ещё этот канал.
    """
    channel_id = str(channel_id or '').strip()
    if not channel_id:
        return ''
    if channel_id in _YOUTUBE_AVATAR_CACHE:
        return _YOUTUBE_AVATAR_CACHE[channel_id]
    url = ''
    if not url:
        from resources.lib.sublime_helper import youtube_channels
        known = youtube_channels.get(channel_id)
        if known is None:
            _YOUTUBE_AVATAR_WANTED['id'] = channel_id

            def _ready(item, channel_id=channel_id):
                _YOUTUBE_AVATAR_CACHE.pop(channel_id, None)
                avatar = item.get('avatar') or ''
                if avatar and _YOUTUBE_AVATAR_WANTED['id'] == channel_id:
                    try:
                        _home_window().setProperty('Sublime.Widget.ChannelLogoPath', avatar)
                    except Exception:
                        pass
            youtube_channels.request(channel_id, _ready)
            return ''                       # не запоминать промах: ответ ещё в пути
        url = known.get('avatar') or ''
    # Промах тоже запоминается: канал без аватара не ищется заново на каждом фокусе.
    if len(_YOUTUBE_AVATAR_CACHE) > 512:
        _YOUTUBE_AVATAR_CACHE.clear()
    _YOUTUBE_AVATAR_CACHE[channel_id] = url
    return url


def _youtube_channel_id_for_video(video_id):
    """id канала ролика для строк без Property(channel_id) - из сведений hub/youtube_meta: свой
    кэш скина и описания дополнения 8 (descriptions.json). Без запросов в сеть: это фокус; строки
    наших полос несут channel_id сами, остальным его проставляет публикация (fill_channels)."""
    try:
        from resources.lib.hub import youtube_meta
        return youtube_meta.channel_id(str(video_id or '').strip())
    except Exception as exc:
        log('youtube video channel lookup failed: %s' % exc)
        return ''


def _update_channel_logo_props(win, row_id=0):
    """Publish the channel avatar for the bottom-right corner.

    Kept strictly apart from the studio logo - its own property, its own control
    in the skin, its own try/except. An earlier attempt routed the avatar through
    Sublime.Widget.StudioLogoPath and film studio logos stopped appearing
    altogether, so nothing here may read or write that path.
    """
    try:
        if not _is_homeish_window():
            if win.getProperty('Sublime.Widget.ChannelLogoPath'):
                win.clearProperty('Sublime.Widget.ChannelLogoPath')
            return
        try:
            container = int(str(row_id or 0).strip() or 0)
        except Exception:
            container = 0
        channel_id = ''
        if container:
            channel_id = read_label(
                'Container(%d).ListItem.Property(channel_id)' % container) or ''
        if not channel_id:
            channel_id = read_label('ListItem.Property(channel_id)') or ''
        if not channel_id:
            # Нет Property(channel_id): строка дополнения YouTube 8 (его строки channel_id не несут)
            # или чужого дополнения. В адресе есть id ролика, по нему - id канала.
            if container:
                path = (read_label('Container(%d).ListItem.FileNameAndPath' % container) or
                        read_label('Container(%d).ListItem.FolderPath' % container) or '')
            else:
                path = (read_label('ListItem.FileNameAndPath') or
                        read_label('ListItem.FolderPath') or '')
            from resources.lib.sublime_helper.config import youtube_video_id
            video_id = youtube_video_id(path)
            if video_id:
                channel_id = _youtube_channel_id_for_video(video_id)
        _YOUTUBE_AVATAR_WANTED['id'] = channel_id
        avatar = _youtube_channel_avatar(channel_id) if channel_id else ''
        if not avatar:
            # Rows built by an add-on other than plugin.video.youtube itself
            # (e.g. plugin.video.ai.recommend's own YouTube widget) never carry
            # a channel_id property, but they resolve and attach their own
            # channel avatar directly as ListItem art(clearlogo). DBType empty
            # + that art present is exactly the same signal the skin's own
            # widget-card clearlogo override uses for these rows, so reuse it
            # here instead of guessing at a second heuristic.
            if container:
                dbtype = read_label('Container(%d).ListItem.DBType' % container) or ''
                clearlogo = read_label('Container(%d).ListItem.Art(clearlogo)' % container) or ''
            else:
                dbtype = read_label('ListItem.DBType') or ''
                clearlogo = read_label('ListItem.Art(clearlogo)') or ''
            if not dbtype and clearlogo:
                avatar = clearlogo
        if avatar:
            if win.getProperty('Sublime.Widget.ChannelLogoPath') != avatar:
                win.setProperty('Sublime.Widget.ChannelLogoPath', avatar)
        elif win.getProperty('Sublime.Widget.ChannelLogoPath'):
            win.clearProperty('Sublime.Widget.ChannelLogoPath')
    except Exception as exc:
        log('channel logo update failed: %s' % exc)


def _studio_logo_candidates(studio):
    from resources.lib.hub import studio_logo
    return studio_logo.candidates(_first_studio(studio))


def _studio_logo_path(studio):
    # only expose verified logo files to the hub image.
    # This prevents Kodi from repeatedly trying missing resource PNGs.
    for cand in _studio_logo_candidates(studio):
        path = 'resource://resource.images.studios.coloured/%s.png' % cand
        if _vfs_exists(path):
            return path
    return ''


# Наследование арта между экранами запрещено при любых условиях (владелец,
# 08.09.2026, трижды). Опубликованный арт живёт в свойствах ОКНА Home, а
# публикует его служба только для строк в фокусе на хабах. Экран сезонов и
# серий - другое окно, своих свойств он не публикует, и на Home оставались
# прошлые: скин честно рисовал их, и владелец видел фон чужого фильма при
# заголовке «Бункер».
#
# Поэтому при смене экрана арт снимается весь и сразу. Местные двойники хабов
# (11100-11108) - тот же экран, что и 1100-1108, между ними чистить нечего.
_ART_PROPS_TO_CLEAR = (
    'Fanart', 'Landscape', 'TVShow.Fanart', 'TVShow.Landscape',
    'BlurImage', 'BlurImage.Original', 'Current.BlurImage',
    'Current.BlurImage.Original', 'CropImage', 'Current.CropImage',
    'ClearLogo', 'Poster', 'Base_Poster', 'Base_Clearlogo', 'Base_Icon',
)


def _screen_of(window_id):
    """Один экран = один номер. Местный двойник хаба - тот же экран."""
    try:
        value = int(window_id or 0)
    except Exception:
        return 0
    if 11100 <= value <= 11108:
        return value - 10000
    return value


def _apply_saved_view_on_folder_change(last_path):
    """Сохранённый вид списка - на каждой новой папке, а не только при открытии окна.

    08.11.2026 владелец: «В каких-то разделах ютуб всё равно иногда появляется
    базовый список. Надо сделать для всех видео landscape по умолчанию». Вид
    по типу содержимого применял только <onload> окна видео
    (Action_Media_Onload -> action=applyview). Переходы внутри окна - канал,
    поиск, подписки - его не вызывают, и для пути, у которого в ViewModes6.db
    нет своей записи (на .20 у шести путей YouTube viewMode 0), Kodi ставит
    вид по умолчанию для списка - «Базовый список» (506), хотя для роликов
    YouTube сохранён «Ряд landscape» (501).

    Решение то же, что у <onload>, - ViewTypes.apply_pluginview с выбором
    владельца по типу содержимого, - но по смене пути, когда список догрузился.
    Возвращает путь, для которого вид уже применён.
    """
    try:
        if not xbmc.getCondVisibility('Window.IsActive(videos)'):
            return ''
        if xbmc.getCondVisibility('Container.IsUpdating'):
            return last_path
        path = xbmc.getInfoLabel('Container.FolderPath') or ''
        if not path.startswith('plugin://') or path == last_path:
            return path or last_path
        from resources.lib.vcl_variables.viewtypes import ViewTypes
        ViewTypes().apply_pluginview(pluginname=xbmc.getInfoLabel('Container.PluginName'))
        return path
    except Exception as exc:
        log('вид списка не применён: %s' % exc, xbmc.LOGWARNING)
        return last_path


_MEDIA_READY = {}


def _drop_inherited_art(win, reason=''):
    """Снять весь опубликованный арт: он принадлежит прошлому экрану."""
    dropped = 0
    for suffix in _ART_PROPS_TO_CLEAR:
        name = 'SublimeHelper.ListItem.%s' % suffix
        if win.getProperty(name):
            win.clearProperty(name)
            dropped += 1
    if dropped:
        log('арт прошлого экрана снят (%s): свойств %d' % (reason, dropped))
    return dropped


def _clear_studio_logo_props(win):
    try:
        win.clearProperty('Sublime.Widget.StudioLogoPath')
        win.clearProperty('Sublime.Widget.StudioLogoKey')
        win.clearProperty('Sublime.Widget.StudioLogoFor')
        win.clearProperty('Sublime.Widget.StudioLogoItemKey')
        win.clearProperty('Sublime.Widget.StudioLogoReady')
        win.clearProperty('Sublime.Widget.StudioLogoSuppressed')
        win.clearProperty('Sublime.Widget.StudioLogoActiveWindow')
        # Do not clear VCL.Widget.Studio itself here: it is a general widget
        # metadata property used by other UI pieces. The studio-logo renderer
        # uses only Sublime.Widget.StudioLogoPath.
    except Exception:
        pass


def _studio_logo_hide_active():
    # searchbar/system notifications hide studio logo;
    # popup action buttons intentionally do not.
    try:
        return xbmc.getCondVisibility(
            '!String.IsEmpty(Window(Home).Property(HomeSwitcher.IsVisible)) | '
            'Control.HasFocus(9300) | Control.HasFocus(9311) | '
            'Window.IsActive(DialogNotification.xml) | Window.IsVisible(DialogNotification.xml) | '
            'Window.IsActive(DialogBusy.xml) | Window.IsVisible(DialogBusy.xml) | '
            'Window.IsActive(DialogExtendedProgressBar.xml) | Window.IsVisible(DialogExtendedProgressBar.xml) | '
            'Window.IsActive(DialogVolumeBar.xml) | Window.IsVisible(DialogVolumeBar.xml)'
        )
    except Exception:
        return False


def _update_studio_logo_delay(win, now_ts):
    try:
        if not _is_homeish_window():
            win.clearProperty('Sublime.Widget.StudioLogoReady')
            win.clearProperty('Sublime.Widget.StudioLogoSuppressed')
            _update_studio_logo_delay._last_hidden = 0.0
            return
        if _studio_logo_hide_active():
            _update_studio_logo_delay._last_hidden = now_ts
            win.clearProperty('Sublime.Widget.StudioLogoReady')
            win.setProperty('Sublime.Widget.StudioLogoSuppressed', 'true')
            return
        # Хвоста больше нет. Раньше здесь стояло «показать не раньше чем через
        # 0.6 с после того, как исчез диалог», и это владелец помнил как
        # намеренную задержку. Смысл был - не мигать логотипом рядом с
        # уведомлением, спиннером и регулятором громкости, которые всплывают в
        # том же правом нижнем углу. Беда в том, что спиннер DialogBusy
        # появляется при КАЖДОЙ загрузке полосы, поэтому хвост срабатывал
        # постоянно, и логотип студии приезжал с опозданием на каждом шаге.
        #
        # Логотип канала YouTube рисуется в том же углу и вовсе без этой
        # защиты - у владельца к нему претензий нет. Поэтому осталось только
        # «не показывать, пока диалог реально на экране» (ветка выше), а
        # задержка после него убрана.
        win.setProperty('Sublime.Widget.StudioLogoReady', 'true')
        win.clearProperty('Sublime.Widget.StudioLogoSuppressed')
    except Exception as exc:
        log('studio logo delay guard skipped: %s' % exc, xbmc.LOGWARNING)


def _row_item_label(cid):
    try:
        return _clean_info_value(
            read_label('Container(%s).ListItem.Label' % cid) or
            read_label('Container(%s).ListItem.Title' % cid) or ''
        )
    except Exception:
        return ''


def _row_item_path(cid):
    try:
        return _clean_info_value(
            read_label('Container(%s).ListItem.FileNameAndPath' % cid) or
            read_label('Container(%s).ListItem.FolderPath' % cid) or ''
        )
    except Exception:
        return ''


def _sublimehelper_meta_matches_row(win, cid):
    """True only when SublimeHelper's published metadata describes THIS row.

    SublimeHelper.ListItem.* on Window(Home) is a single slot holding whatever
    item was enriched last. Reading it unconditionally is how one tab's genre
    and country ended up on every row of another tab. SublimeHelper.WidgetContainer
    is not a usable guard here - measured live on <коробка> it was empty while
    a fully enriched row was focused - but SublimeHelper.ListItem.Key already
    encodes the owning container id, the item path and the item label
    ("503|<hash>|movie|0|0|plugin://...|Остров сокровищ|<hash>"), so the key is
    matched against the focused row instead.
    """
    try:
        cid = str(int(cid or 0))
    except Exception:
        return False
    if cid == '0':
        return False
    try:
        key = win.getProperty('SublimeHelper.ListItem.Key') or ''
    except Exception:
        return False
    if not key or key.startswith('transition|'):
        return False
    parts = key.split('|')
    if not parts or parts[0] != cid:
        return False
    cur_path = _row_item_path(cid)
    cur_label = _row_item_label(cid)
    for part in parts[1:]:
        part = _clean_info_value(part)
        if not part:
            continue
        if cur_path and part == cur_path:
            return True
        if cur_label and part == cur_label:
            return True
    return False


def _widgetmeta_row_studio(win, cid):
    # Row-specific fallback only. It is accepted only when the metadata key
    # matches the current focused row item; this avoids leaking old FX/AMC/etc
    # into PVR, YouTube or any page with no studio/network.
    try:
        cid = str(int(cid))
        studio = _first_studio(win.getProperty('WidgetMeta.%s.Studio' % cid))
        if not studio:
            return ''
        cur_label = _row_item_label(cid)
        cur_path = _row_item_path(cid)
        meta_label = _clean_info_value(win.getProperty('WidgetMeta.%s.Label' % cid) or win.getProperty('WidgetMeta.%s.Title' % cid))
        meta_path = _clean_info_value(win.getProperty('WidgetMeta.%s.FileNameAndPath' % cid) or win.getProperty('WidgetMeta.%s.FolderPath' % cid))
        if cur_path and meta_path and cur_path == meta_path:
            return studio
        if cur_label and meta_label and cur_label == meta_label:
            return studio
    except Exception:
        pass
    return ''


def _vcl_widget_studio_if_matches(win, cid):
    # 540: use the row focus metadata only when it belongs to the same
    # currently focused item. This forbids studio logo on hubs/items where
    # the focused item did not provide studio/network data, instead of
    # inheriting the previous logo.
    try:
        studio = _first_studio(win.getProperty('VCL.Widget.Studio'))
        if not studio:
            return ''
        cur_label = _row_item_label(cid)
        cur_path = _row_item_path(cid)
        meta_label = _clean_info_value(win.getProperty('VCL.Widget.Label') or win.getProperty('VCL.Widget.Title'))
        meta_path = _clean_info_value(win.getProperty('VCL.Widget.FileNameAndPath') or win.getProperty('VCL.Widget.FolderPath'))
        if cur_path and meta_path and cur_path == meta_path:
            return studio
        if cur_label and meta_label and cur_label == meta_label:
            return studio
    except Exception:
        pass
    return ''


_WIDGET_ART_AT = [0.0]


def _safe_int(value):
    try:
        return int(str(value or '0').strip() or 0)
    except Exception:
        return 0


def _shown_widget_id():
    """Виджет, показанный под строкой категорий: у выбранной вкладки он записан в widget_id
    (SublimeHelper.WidgetContainer при смене вкладки переставляется не во всех хабах - в ТВ
    оставался виджет прошлой группы)."""
    if _safe_int(read_label('System.CurrentControlId')) == 601:
        wid = str(read_label('Container(601).ListItem.Property(widget_id)') or '').strip()
        if wid.isdigit():
            # показанный виджет окна - по выбранной вкладке: от него берут название, описание и
            # инфостроку (Includes_Hubs.xml, WidgetContainer); строка категорий сама переставляет
            # его не во всех хабах - в ТВ под «Избранным» стояла передача «Србиjи» (21.11.2026)
            own = xbmcgui.Window(xbmcgui.getCurrentWindowId())
            if own.getProperty('SublimeHelper.WidgetContainer') != wid:
                own.setProperty('SublimeHelper.WidgetContainer', wid)
            return wid
    return read_label('Window.Property(SublimeHelper.WidgetContainer)')


def _publish_widget_art(win, row_id):
    """Фон и цвет выбранной строки виджета - для кадров, когда фокус не на виджете (боковое
    меню, строка поиска, вход в хаб): слой строки берёт их у элемента в фокусе, а его тогда
    нет - хабы стояли без фонов (владелец, 21.11.2026). Строка в фокусе рисуется по-прежнему
    своими свойствами; эти - только когда фокуса на виджете нет (Includes_Background.xml).
    Строка - показанный виджет окна (SublimeHelper.WidgetContainer: его переставляет и строка
    категорий при смене вкладки), то есть та же карточка, чьи название и описание на экране."""
    try:
        values = {}
        row_id = str(row_id or '').strip()
        if row_id.isdigit():
            names = ('Background', 'Prepared', 'Wash', 'Fanart')
            addresses = ['Container(%s).ListItem.Property(Sublime.%s)' % (row_id, n) for n in names]
            addresses.append('Container(%s).ListItem.ChannelName' % row_id)
            got = read_labels(addresses, fresh=True) or {}
            values = dict((n, got.get(a) or '') for n, a in zip(names, addresses))
            # канал ТВ: его картинка и цвет - файлы pvr_bg по имени, запоминаем имя
            values['Channel'] = got.get(addresses[-1]) or ''
        if not values.get('Background'):
            values = {'Channel': values.get('Channel', '')}
        # Свойство своего окна хаба, не Home: при смене хаба в Home оставался фон карточки прошлого
        # хаба («Довженко» из «Фильмов» в «Сериалах», .20, 21.11.2026). Окно хаба помнит только свою.
        own = xbmcgui.Window(xbmcgui.getCurrentWindowId())
        # для какого виджета это опубликовано: разметка сверяет с виджетом выбранной вкладки и до
        # публикации ничего не показывает (логотип канала прошлой группы мигал, .30, 21.11.2026)
        if own.getProperty('Sublime.WidgetFor') != str(row_id or ''):
            own.setProperty('Sublime.WidgetFor', str(row_id or ''))
        for name in ('Background', 'Prepared', 'Wash', 'Fanart', 'Channel'):
            value = values.get(name) or ''
            prop = 'Sublime.Widget' + name
            if own.getProperty(prop) != value:
                if value:
                    own.setProperty(prop, value)
                else:
                    own.clearProperty(prop)
    except Exception as exc:
        log('фон выбранной строки не опубликован: %s' % exc, xbmc.LOGDEBUG)


def _focused_widget_row_cached(win, allow_unfocused=False):
    """Return only the row that owns focus without rescanning 50 controls per loop.

    XML updates VCL.ActionButtonsFocusedWidget on real row focus.  We verify that
    cheap candidate first. A full 501-550 scan is shared/throttled across the
    action and washed-colour monitor threads. During the small throttle window we
    return 0 rather than a previous row, so metadata can never bleed across items.
    """
    # Kodi знает ответ одной меткой, и это дешевле всего остального здесь.
    # Замерено на .30: поиск сфокусированного контейнера стоил 12,6 мс на каждом
    # такте цикла (перебор Control.HasFocus по 501-550), тогда как весь отпечаток
    # строки - 3,6 мс. Если System.CurrentControlId уже указывает на строку
    # виджета, никакого перебора не нужно.
    try:
        current = int(read_label('System.CurrentControlId') or 0)
    except Exception:
        current = 0
    if 501 <= current <= 550:
        _focused_widget_row_cached._last_scan = current
        _focused_widget_row_cached._last_scan_at = time.monotonic()
        return current
    cached = 0
    try:
        cached = int(win.getProperty('VCL.ActionButtonsFocusedWidget') or 0)
    except Exception:
        cached = 0
    if 501 <= cached <= 550:
        try:
            if xbmc.getCondVisibility('Control.HasFocus(%d)' % cached):
                _focused_widget_row_cached._last_scan = cached
                _focused_widget_row_cached._last_scan_at = time.monotonic()
                return cached
        except Exception:
            pass
        if allow_unfocused:
            return cached
    now = time.monotonic()
    last_at = float(getattr(_focused_widget_row_cached, '_last_scan_at', 0.0) or 0.0)
    if now - last_at < 0.12:
        return 0
    row = _focused_widget_row()
    _focused_widget_row_cached._last_scan = row
    _focused_widget_row_cached._last_scan_at = now
    return row


def _row_has_video_identity(cid):
    try:
        cid = int(cid or 0)
    except Exception:
        return False
    labels = [
        'Container(%s).ListItem.DBType' % cid,
        'Container(%s).ListItem.Property(DBType)' % cid,
        'Container(%s).ListItem.Property(tmdb_id)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.TMDB_ID)' % cid,
        'Container(%s).ListItem.Property(imdb_id)' % cid,
        'Container(%s).ListItem.Property(IMDBNumber)' % cid,
        'Container(%s).ListItem.IMDBNumber' % cid,
        'Container(%s).ListItem.DBID' % cid,
    ]
    try:
        for label in labels:
            v = _clean_info_value(read_label(label))
            if not v:
                continue
            low = v.lower()
            if low in ('movie','tvshow','episode','season','video'):
                return True
            if v not in ('0','-1') and (v.isdigit() or low.startswith('tt') or len(v) > 3):
                return True
    except Exception:
        pass
    return False


def _update_studio_logo_props(win, row_id=0):
    try:
        if not _is_homeish_window():
            _clear_studio_logo_props(win)
            return

        # Popup action buttons are an extension of the same focused item.
        # Keep the last valid logo while these buttons are focused.
        if _action_button_has_focus() and win.getProperty('Sublime.Widget.StudioLogoPath'):
            return

        try:
            row_id = int(row_id or 0)
        except Exception:
            row_id = 0
        if row_id < 501 or row_id > 550:
            row_id = _focused_widget_row_cached(win)
        if row_id < 501 or row_id > 550:
            _clear_studio_logo_props(win)
            return

        candidates = []
        def add_candidate(value, source):
            value = _first_studio(value)
            if value and not any(x[0] == value for x in candidates):
                candidates.append((value, source))

        # Готовое имя из снимка - первым: оно уже лежит в строке (сборщик
        # положил его вместе с фоном и цветом), поэтому логотип студии
        # появляется сразу, как у канала ютуб, а не после опознания в TMDB.
        add_candidate(read_label(
            'Container(%s).ListItem.Property(Sublime.Studio)' % row_id),
            'snapshot')
        add_candidate(_container_first_studio(row_id), 'container')
        # Общая память студий: имя, узнанное когда-то в любой полосе. Живые
        # списки провайдера («Избранное», «Отложенные») сборщик не трогает, и
        # логотип там ждал опознания в TMDB - владелец увидел это как
        # «в избранном логотипы появляются сильно позже, чем в списке Все».
        try:
            from resources.lib.hub import studios as _studios
            add_candidate(_studios.lookup(
                read_label('Container(%s).ListItem.Title' % row_id)
                or read_label('Container(%s).ListItem.Label' % row_id),
                read_label('Container(%s).ListItem.Year' % row_id)), 'память')
        except Exception:
            pass
        add_candidate(_widgetmeta_row_studio(win, row_id), 'widgetmeta')
        add_candidate(_vcl_widget_studio_if_matches(win, row_id), 'widgetprop')
        # Глобальные свойства берём ТОЛЬКО если они про эту же строку. Это
        # лекарство от залипания: конвейер метаданных публикует их для «текущего
        # опознанного элемента», и при переходе на новую строку они ещё держат
        # предыдущий фильм - служба честно находила по ним старый логотип и
        # показывала его, пока публикация не догонит. Владелец: «иногда залипает
        # старый и не меняется на новый». У логотипа канала такого нет именно
        # потому, что он берётся из самой строки.
        # Сравнение ДЕШЁВОЕ - по названию. Первая версия звала здесь
        # _current_item_fingerprint(row_id), а он делает prefetch_labels на
        # четыре десятка меток контейнера и садится в тот же кеш меток, из
        # которого читает публикация: та начинала видеть «отпечаток не
        # изменился» и выходила раньше времени. Замер на .30 05.09.2026: у
        # четырёх подряд строк фильмов фон был ОДИН И ТОТ ЖЕ, а владелец на
        # своей коробке увидел чужой лендскейп и пикон PVR на фильме. Мост
        # логотипа не имеет права трогать этот кеш.
        published_for_this_row = False
        try:
            published_title = str(
                win.getProperty('SublimeHelper.ListItem.Title') or '').strip()
            row_title = str(_row_item_label(row_id) or '').strip()
            published_for_this_row = bool(
                published_title and row_title
                and published_title.lower() == row_title.lower())
        except Exception:
            published_for_this_row = False
        if published_for_this_row and _row_has_video_identity(row_id):
            for index in range(1, 6):
                add_candidate(win.getProperty('SublimeHelper.ListItem.Network.%d.Name' % index), 'sublime-network')
            for index in range(1, 11):
                add_candidate(win.getProperty('SublimeHelper.ListItem.Studio.%d.Name' % index), 'sublime-studio')
            add_candidate(win.getProperty('SublimeHelper.ListItem.Studio'), 'sublime-studio')

        studio = ''
        path = ''
        source = ''
        for candidate, candidate_source in candidates:
            candidate_path = _studio_logo_path(candidate)
            if candidate_path:
                studio = candidate
                path = candidate_path
                source = candidate_source
                break
        if not path:
            _clear_studio_logo_props(win)
            return

        item_key = _current_item_key(row_id) or str(row_id)
        try:
            active_window = str(xbmcgui.getCurrentWindowId())
        except Exception:
            active_window = ''
        key = '%s|%s|%s|%s|%s' % (row_id, active_window, item_key, studio, path)
        win.setProperty('VCL.Widget.Studio', studio)
        win.setProperty('Sublime.Widget.StudioLogoPath', path)
        win.setProperty('Sublime.Widget.StudioLogoItemKey', item_key)
        # адрес строки, для которой выбран логотип: разметка показывает его только у неё, иначе при
        # переходе логотип прошлой карточки мелькал на новой («Здесь был Юра», .20, 22.11.2026)
        win.setProperty('Sublime.Widget.StudioLogoFor', _row_item_path(row_id))
        if active_window:
            win.setProperty('Sublime.Widget.StudioLogoActiveWindow', active_window)
        else:
            win.clearProperty('Sublime.Widget.StudioLogoActiveWindow')
        if win.getProperty('Sublime.Widget.StudioLogoKey') != key:
            win.setProperty('Sublime.Widget.StudioLogoKey', key)
            log('studio logo bridge: row=%s source=%s window=%s studio=%s' % (row_id or '-', source, active_window or '-', studio))
    except Exception as exc:
        log('studio logo bridge skipped: %s' % exc, xbmc.LOGWARNING)
        try:
            _clear_studio_logo_props(win)
        except Exception:
            pass

def _is_unresolved_info_label(value):
    # Kodi can echo an unresolved InfoLabel string instead of returning ''.
    # Never let raw label syntax such as Container(503).ListItem.FirstAired
    # become visible in AF3SL infoline properties.
    try:
        value = re.sub(r'\s+', ' ', (value or '').replace('[CR]', ' ').strip(), flags=re.U)
        if not value:
            return False
        low = value.lower()
        if value.startswith('$INFO[') or value.startswith('$VAR['):
            return True
        if re.match(r'^(container\(\d+\)\.listitem\.|listitem\.|videoplayer\.|window\([^)]+\)\.property\()', low, re.I):
            return True
        if ('container(' in low and '.listitem.' in low) or ('window(' in low and '.property(' in low):
            return True
        if '.listitem.' in low and ('firstaired' in low or 'premiered' in low or 'genre' in low or 'country' in low or 'date' in low):
            return True
    except Exception:
        pass
    return False


def _clean_info_value(value):
    try:
        value = re.sub(r'\s+', ' ', (value or '').replace('[CR]', ' ').strip(), flags=re.U)
        if not value or _is_unresolved_info_label(value):
            return ''
        return value
    except Exception:
        return ''


def _cap_first(value):
    try:
        value = (value or '').strip()
        if not value:
            return ''
        return value[:1].upper() + value[1:]
    except Exception:
        return value


def _first_two_clean(value, skip_func=None, cap_parts=False, keep=2):
    """Первые `keep` значений из перечисления через / , ; |.

    10.09.2026 владелец: «вся строка не помещается … один жанр, одна страна».
    Замер на .30: «Драмы / Криминал» стоило ~110 px из 924 - четверть свободного
    места в инфостроке. Жанр и страна показываются по одному (keep=1); сама
    функция осталась общей."""
    try:
        value = _clean_info_value(value)
        if not value:
            return ''
        value = value.replace('[CR]', ' / ')
        # Normalize common separators used by Kodi/TMDb/plugin items and return the first two values.
        parts = re.split(r'\s*/\s*|\s*•\s*|\s*,\s*|\s*;\s*|\s*\|\s*', value)
        clean = []
        for part in parts:
            part = re.sub(r'\s+', ' ', (part or '').strip(), flags=re.U)
            if not part:
                continue
            if skip_func and skip_func(part):
                continue
            if cap_parts:
                part = _cap_first(part)
            if part and part not in clean:
                clean.append(part)
            if len(clean) >= keep:
                break
        if clean:
            return ' / '.join(clean)
    except Exception:
        pass
    return ''


# Передаётся как значение (skip_func=_is_junk_genre_part), поэтому обход
# графа вызовов в ee602e5 её не увидел и удалил вместе с миграцией. На
# боксе это NameError в _first_genre при каждом чтении жанра.
def _is_junk_genre_part(value):
    try:
        norm = re.sub(r'[\s\W_]+', '', (value or '').lower().replace('ё', 'е'), flags=re.U)
        return norm in (
            'другое', 'неизвестно', 'другоенеизвестно',
            'other', 'unknown', 'otherunknown', 'nongenre', 'nogeneres', 'nogenre'
        )
    except Exception:
        return False


def _first_genre(value):
    # Один жанр: см. _first_two_clean (владелец, 10.09.2026).
    return _first_two_clean(value, skip_func=_is_junk_genre_part,
                            cap_parts=True, keep=1)


# словарь стран - одна копия в hub/row_store.py (его подключают и дополнения)
from resources.lib.hub.row_store import COUNTRY_RU as _COUNTRY_RU_MAP  # noqa: E402


def _country_key(value):
    try:
        value = _clean_info_value(value).lower()
        value = re.sub(r'[^a-zа-яё0-9]+', ' ', value, flags=re.U).strip()
        value = re.sub(r'\s+', ' ', value, flags=re.U)
        return value
    except Exception:
        return ''


def _translate_country_part(value):
    try:
        cleaned = _clean_info_value(value)
        if not cleaned:
            return ''
        # The map turns English country names into Russian ones; on a Kodi in
        # any other language the name is left as the source gave it.
        if not _l10n_is_russian():
            return cleaned
        key = _country_key(cleaned)
        if key in _COUNTRY_RU_MAP:
            return _COUNTRY_RU_MAP[key]
        return cleaned
    except Exception:
        return value


def _first_country(value):
    try:
        value = _clean_info_value(value)
        if not value:
            return ''
        value = value.replace('[CR]', ' / ')
        parts = re.split(r'\s*/\s*|\s*•\s*|\s*,\s*|\s*;\s*|\s*\|\s*', value)
        clean = []
        for part in parts:
            part = re.sub(r'\s+', ' ', (part or '').strip(), flags=re.U)
            if not part:
                continue
            part = _translate_country_part(part)
            if part and part not in clean:
                clean.append(part)
            # Одна страна - по той же причине, что и один жанр.
            if len(clean) >= 1:
                break
        if clean:
            return ' / '.join(clean)
    except Exception:
        pass
    return ''


def _first_nonempty_genre_from_labels(labels):
    for label in labels:
        try:
            first = _first_genre(read_label(label))
            if first:
                return first
        except Exception:
            pass
    return ''


def _first_nonempty_genre_from_props(win, props):
    for prop in props:
        try:
            first = _first_genre(win.getProperty(prop))
            if first:
                return first
        except Exception:
            pass
    return ''


def _first_nonempty_country_from_labels(labels):
    for label in labels:
        try:
            first = _first_country(read_label(label))
            if first:
                return first
        except Exception:
            pass
    return ''


def _first_nonempty_country_from_props(win, props):
    for prop in props:
        try:
            first = _first_country(win.getProperty(prop))
            if first:
                return first
        except Exception:
            pass
    return ''


def _container_first_genre(cid):
    full = _first_nonempty_genre_from_labels([
        'Container(%s).ListItem.Genre' % cid,
        'Container(%s).ListItem.Property(Genre)' % cid,
        'Container(%s).ListItem.Property(genre)' % cid,
        'Container(%s).ListItem.Property(Genres)' % cid,
        'Container(%s).ListItem.Property(genres)' % cid,
        'Container(%s).ListItem.Property(tmdb_genres)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Genres)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Genre)' % cid,
    ])
    if full:
        return full
    try:
        parts = []
        for label in (
            'Container(%s).ListItem.Property(genres.0.name)' % cid,
            'Container(%s).ListItem.Property(genres.1.name)' % cid,
            'Container(%s).ListItem.Property(Genre.0)' % cid,
            'Container(%s).ListItem.Property(Genre.1)' % cid,
        ):
            value = _first_genre(read_label(label))
            if value and value not in parts:
                parts.append(value)
            if len(parts) >= 2:
                break
        return ' / '.join(parts)
    except Exception:
        return ''


def _listitem_first_genre(win):
    full = _first_nonempty_genre_from_labels([
        'ListItem.Genre',
        'ListItem.Property(Genre)',
        'ListItem.Property(genre)',
        'ListItem.Property(Genres)',
        'ListItem.Property(genres)',
        'ListItem.Property(tmdb_genres)',
        'ListItem.Property(SublimeHelper.ListItem.Genres)',
        'ListItem.Property(SublimeHelper.ListItem.Genre)',
        'Window(Home).Property(SublimeHelper.ListItem.Genre)',
        'Window(Home).Property(SublimeHelper.ListItem.Genres)',
    ])
    if full:
        return full
    try:
        parts = []
        for label in (
            'Window(Home).Property(SublimeHelper.ListItem.Genres.0.Name)',
            'Window(Home).Property(SublimeHelper.ListItem.Genres.1.Name)',
        ):
            value = _first_genre(read_label(label))
            if value and value not in parts:
                parts.append(value)
            if len(parts) >= 2:
                break
        if parts:
            return ' / '.join(parts)
    except Exception:
        pass
    return _first_nonempty_genre_from_props(win, [
        'SublimeHelper.ListItem.Genre',
        'SublimeHelper.ListItem.Genres',
        'SublimeHelper.ListItem.Genres.1.Name',
        'SublimeHelper.ListItem.Genres.0.Name',
        'ListItem.Genre',
    ])


def _container_first_country(cid):
    full = _first_nonempty_country_from_labels([
        'Container(%s).ListItem.Country' % cid,
        'Container(%s).ListItem.Property(Country)' % cid,
        'Container(%s).ListItem.Property(country)' % cid,
        'Container(%s).ListItem.Property(Countries)' % cid,
        'Container(%s).ListItem.Property(countries)' % cid,
        'Container(%s).ListItem.Property(origin_country)' % cid,
        'Container(%s).ListItem.Property(production_countries)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Country)' % cid,
    ])
    if full:
        return full
    try:
        parts = []
        for label in (
            'Container(%s).ListItem.Property(countries.0.name)' % cid,
            'Container(%s).ListItem.Property(countries.1.name)' % cid,
            'Container(%s).ListItem.Property(production_countries.0.name)' % cid,
            'Container(%s).ListItem.Property(production_countries.1.name)' % cid,
            'Container(%s).ListItem.Property(origin_country.0)' % cid,
            'Container(%s).ListItem.Property(origin_country.1)' % cid,
            'Container(%s).ListItem.Property(Country.0)' % cid,
            'Container(%s).ListItem.Property(Country.1)' % cid,
        ):
            value = _first_country(read_label(label))
            if value and value not in parts:
                parts.append(value)
            if len(parts) >= 2:
                break
        return ' / '.join(parts)
    except Exception:
        return ''


def _listitem_first_country(win):
    full = _first_nonempty_country_from_labels([
        'ListItem.Country',
        'ListItem.Property(Country)',
        'ListItem.Property(country)',
        'ListItem.Property(Countries)',
        'ListItem.Property(countries)',
        'ListItem.Property(origin_country)',
        'ListItem.Property(production_countries)',
        'ListItem.Property(SublimeHelper.ListItem.Country)',
        'Window(Home).Property(SublimeHelper.ListItem.Country)',
    ])
    if full:
        return full
    try:
        parts = []
        for label in (
            'Window(Home).Property(SublimeHelper.ListItem.Country.0.Name)',
            'Window(Home).Property(SublimeHelper.ListItem.Country.1.Name)',
            'Window(Home).Property(SublimeHelper.ListItem.Countries.0.Name)',
            'Window(Home).Property(SublimeHelper.ListItem.Countries.1.Name)',
        ):
            value = _first_country(read_label(label))
            if value and value not in parts:
                parts.append(value)
            if len(parts) >= 2:
                break
        if parts:
            return ' / '.join(parts)
    except Exception:
        pass
    return _first_nonempty_country_from_props(win, [
        'SublimeHelper.ListItem.Country',
        'SublimeHelper.ListItem.Countries',
        'ListItem.Country',
    ])


def _first_year(value):
    try:
        value = (value or '').strip()
        if not value:
            return ''
        m = re.search(r'(19|20)\d{2}', value)
        if m:
            return m.group(0)
    except Exception:
        pass
    return ''


def _date_or_year(value, year_only=False):
    try:
        value = _clean_info_value(value)
        if not value:
            return ''
        if year_only:
            return _first_year(value)
        m = re.search(r'(19|20)\d{2}[-./]\d{1,2}[-./]\d{1,2}', value)
        if m:
            return m.group(0)
        m = re.search(r'\d{1,2}[-./]\d{1,2}[-./](19|20)\d{2}', value)
        if m:
            return m.group(0)
        # For non movie/tvshow/season items keep the full date text if Kodi/plugin supplied it.
        year = _first_year(value)
        if year and value == year:
            return year
        return value
    except Exception:
        return ''


def _dbtype_from_hint(value):
    try:
        value = _clean_info_value(value).lower()
        if not value:
            return ''
        value = value.replace('_', ' ').replace('-', ' ')
        # Search popup generated rows can miss DBType; infer only from explicit media hints.
        if 'tmdb_type=movie' in value or 'type=movie' in value or 'type=movies' in value:
            return 'movie'
        if 'tmdb_type=tv' in value or 'type=tvshow' in value or 'type=tvshows' in value or 'type=shows' in value:
            return 'tvshow'
        if 'videodb://movies' in value:
            return 'movie'
        if 'videodb://tvshows' in value:
            return 'tvshow'
        if re.search(r'(^|[^a-zа-яё])(movie|movies|film|films|фильм|фильмы|кино)([^a-zа-яё]|$)', value, flags=re.U):
            return 'movie'
        if re.search(r'(^|[^a-zа-яё])(tvshow|tvshows|tv show|tv shows|show|shows|series|сериал|сериалы)([^a-zа-яё]|$)', value, flags=re.U):
            return 'tvshow'
        if re.search(r'(^|[^a-zа-яё])(season|seasons|сезон|сезоны)([^a-zа-яё]|$)', value, flags=re.U):
            return 'season'
        if re.search(r'(^|[^a-zа-яё])(episode|episodes|эпизод|серия)([^a-zа-яё]|$)', value, flags=re.U):
            return 'episode'
        if re.search(r'(^|[^a-zа-яё])(album|albums|artist|artists|song|songs|music|youtube|ютуб)([^a-zа-яё]|$)', value, flags=re.U):
            return 'other'
        return ''
    except Exception:
        return ''


def _normalize_dbtype(value):
    try:
        value = _clean_info_value(value).lower()
        if not value:
            return ''
        explicit = {
            'movie': 'movie', 'movies': 'movie', 'film': 'movie', 'films': 'movie', 'фильм': 'movie', 'фильмы': 'movie',
            'tv': 'tvshow', 'show': 'tvshow', 'shows': 'tvshow', 'series': 'tvshow', 'tvshow': 'tvshow', 'tvshows': 'tvshow', 'tv show': 'tvshow', 'tv shows': 'tvshow', 'сериал': 'tvshow', 'сериалы': 'tvshow',
            'season': 'season', 'seasons': 'season', 'сезон': 'season', 'сезоны': 'season',
            'episode': 'episode', 'episodes': 'episode', 'эпизод': 'episode', 'серия': 'episode',
        }
        if value in explicit:
            return explicit[value]
        return _dbtype_from_hint(value) or value
    except Exception:
        return ''


def _year_only_dbtype(value):
    return _normalize_dbtype(value) in ('movie', 'tvshow', 'season')


def _first_nonempty_label(labels):
    """First non-empty of these labels, asked in ONE request.

    Was a loop of xbmc.getInfoLabel calls - the exact call that segfaults this
    Kodi (see docs/CRASH_GETINFOLABEL_2026-08-23.md). One JSON-RPC request for
    the whole list is both safer and fewer round trips than the loop was.
    """
    names = [str(l) for l in (labels or []) if l]
    if not names:
        return ''
    values = read_labels(names)
    for name in names:
        value = _clean_info_value(values.get(name))
        if value:
            return value
    return ''


def _container_dbtype(cid):
    dbtype = _normalize_dbtype(_first_nonempty_label([
        'Container(%s).ListItem.DBType' % cid,
        'Container(%s).ListItem.Property(DBType)' % cid,
        'Container(%s).ListItem.Property(dbtype)' % cid,
        'Container(%s).ListItem.Property(mediatype)' % cid,
        'Container(%s).ListItem.Property(MediaType)' % cid,
        'Container(%s).ListItem.Property(type)' % cid,
        'Container(%s).ListItem.Property(Type)' % cid,
        'Container(%s).ListItem.Property(tmdb_type)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.DBType)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Type)' % cid,
    ]))
    if dbtype:
        return dbtype
    for label in (
        'Container(%s).ListItem.FolderPath' % cid,
        'Container(%s).ListItem.FileNameAndPath' % cid,
        'Container(%s).ListItem.Path' % cid,
        'Container(%s).ListItem.Property(path)' % cid,
        'Container(%s).ListItem.Property(url)' % cid,
    ):
        dbtype = _dbtype_from_hint(read_label(label))
        if dbtype:
            return dbtype
    try:
        # Search popup selector category is the reliable fallback for TMDb Movies / Shows rows.
        selector_id = read_label('Container(601).ListItem.Property(widget_id)') or ''
        if selector_id and str(selector_id) == str(cid):
            dbtype = _dbtype_from_hint(read_label('Container(601).ListItem.Label'))
            if dbtype:
                return dbtype
    except Exception:
        pass
    return ''


def _listitem_dbtype(win):
    dbtype = _normalize_dbtype(_first_nonempty_label([
        'ListItem.DBType',
        'ListItem.Property(DBType)',
        'ListItem.Property(dbtype)',
        'ListItem.Property(mediatype)',
        'ListItem.Property(MediaType)',
        'ListItem.Property(type)',
        'ListItem.Property(Type)',
        'ListItem.Property(tmdb_type)',
        'Window(Home).Property(SublimeHelper.ListItem.DBType)',
        'Window(Home).Property(SublimeHelper.ListItem.Type)',
    ]))
    if dbtype:
        return dbtype
    for label in ('ListItem.FolderPath', 'ListItem.FileNameAndPath', 'ListItem.Path', 'ListItem.Property(path)', 'ListItem.Property(url)'):
        dbtype = _dbtype_from_hint(read_label(label))
        if dbtype:
            return dbtype
    for prop in ('SublimeHelper.ListItem.DBType', 'SublimeHelper.ListItem.Type', 'ListItem.DBType', 'ListItem.Property(tmdb_type)'):
        try:
            dbtype = _normalize_dbtype(win.getProperty(prop))
            if dbtype:
                return dbtype
        except Exception:
            pass
    return ''


def _path_is_pvr(value):
    try:
        value = _clean_info_value(value).lower()
        return value.startswith('pvr://')
    except Exception:
        return False


def _container_has_pvr_path(cid):
    try:
        for label in (
            'Container(%s).ListItem.FileNameAndPath' % cid,
            'Container(%s).ListItem.FolderPath' % cid,
            'Container(%s).ListItem.Path' % cid,
            'Container(%s).ListItem.Property(path)' % cid,
        ):
            if _path_is_pvr(read_label(label)):
                return True
    except Exception:
        pass
    return False


def _listitem_has_pvr_path():
    try:
        for label in (
            'ListItem.FileNameAndPath',
            'ListItem.FolderPath',
            'ListItem.Path',
            'ListItem.Property(path)',
        ):
            if _path_is_pvr(read_label(label)):
                return True
    except Exception:
        pass
    return False


def _container_is_pvr_item(cid):
    # Keep this deliberately narrow. YouTube and other plugins can expose
    # ChannelName/StartTime labels, so do not use those as PVR detectors.
    try:
        dbtype = _container_dbtype(cid)
        if dbtype in ('pvr', 'tvchannel', 'epg', 'programme', 'program'):
            return True
        if _container_has_pvr_path(cid):
            return True
    except Exception:
        pass
    return False


def _listitem_is_pvr_item(win):
    # Narrow PVR detection only: PVR dbtype or pvr:// path. This prevents
    # movie/series/plugin dates from being suppressed accidentally.
    try:
        dbtype = _listitem_dbtype(win)
        if dbtype in ('pvr', 'tvchannel', 'epg', 'programme', 'program'):
            return True
        if _listitem_has_pvr_path():
            return True
    except Exception:
        pass
    return False


def _first_nonempty_date_from_labels(labels, year_only=False):
    for label in labels:
        try:
            date = _date_or_year(read_label(label), year_only=year_only)
            if date:
                return date
        except Exception:
            pass
    return ''


def _first_nonempty_year_from_labels(labels):
    return _first_nonempty_date_from_labels(labels, year_only=True)


def _row_kind(cid=0):
    """Категория того, что сейчас на экране: «video», «movies», «tv» и так далее.

    Категории виджетам владелец назначил сам (hub/widget_kinds.py), и решать
    такие вопросы надо один раз по категории, а не подпирать у каждого
    поставщика - его же указание от 08.09.2026: «Ты должен был решить этот
    вопрос просто и однозначно, когда присваивал категории виджетам».
    """
    try:
        # Именно так, а не относительным импортом: этот файл лежит вне пакета
        # hub, и «from .hub import» молча падал в except - 08.09.2026 из-за
        # этого правило по категории не срабатывало вовсе.
        from resources.lib.hub import widget_kinds
    except Exception:
        return ''
    for label in ([('Container(%s).FolderPath' % cid), ('Container(%s).ListItem.FolderPath' % cid),
                   ('Container(%s).ListItem.FileNameAndPath' % cid)] if cid else
                  ['Container.FolderPath', 'ListItem.FolderPath', 'ListItem.FileNameAndPath']):
        try:
            kind = widget_kinds.kind_of(read_label(label) or '')
        except Exception:
            kind = ''
        if kind:
            return kind
    return ''


def _container_release_display(cid):
    if _container_is_pvr_item(cid):
        return ''
    year_only = _year_only_dbtype(_container_dbtype(cid))
    full_date_labels = [
        'Container(%s).ListItem.Premiered' % cid,
        'Container(%s).ListItem.FirstAired' % cid,
        'Container(%s).ListItem.Date' % cid,
        'Container(%s).ListItem.Property(premiered)' % cid,
        'Container(%s).ListItem.Property(first_air_date)' % cid,
        'Container(%s).ListItem.Property(release_date)' % cid,
        'Container(%s).ListItem.Property(date)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Premiered)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.FirstAired)' % cid,
    ]
    year_labels = [
        'Container(%s).ListItem.Year' % cid,
        'Container(%s).ListItem.Property(year)' % cid,
        'Container(%s).ListItem.Property(Year)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Year)' % cid,
    ]
    labels = year_labels + full_date_labels if year_only else full_date_labels + year_labels
    # У видео дата выхода - это дата публикации, и лежит она в DateAdded: своей
    # Premiered у ролика нет ни у наших строк, ни у строк дополнения. Для кино
    # и сериалов DateAdded означает совсем другое (когда попало в библиотеку),
    # поэтому он допущен ТОЛЬКО в категории «Видео».
    if _row_kind(cid) == 'video':
        labels = labels + ['Container(%s).ListItem.DateAdded' % cid]
    return _first_nonempty_date_from_labels(labels, year_only=year_only)


def _listitem_release_display(win):
    if _listitem_is_pvr_item(win):
        return ''
    year_only = _year_only_dbtype(_listitem_dbtype(win))
    full_date_labels = [
        'ListItem.Premiered',
        'ListItem.FirstAired',
        'ListItem.Date',
        'ListItem.Property(premiered)',
        'ListItem.Property(first_air_date)',
        'ListItem.Property(release_date)',
        'ListItem.Property(date)',
        'Window(Home).Property(SublimeHelper.ListItem.Premiered)',
        'Window(Home).Property(SublimeHelper.ListItem.FirstAired)',
    ]
    year_labels = [
        'ListItem.Year',
        'ListItem.Property(year)',
        'ListItem.Property(Year)',
        'Window(Home).Property(SublimeHelper.ListItem.Year)',
    ]
    labels = year_labels + full_date_labels if year_only else full_date_labels + year_labels
    # То же правило, что и для контейнера: у категории «Видео» дата выхода
    # лежит в DateAdded (см. _container_release_display).
    if _row_kind() == 'video':
        labels = labels + ['ListItem.DateAdded']
    date = _first_nonempty_date_from_labels(labels, year_only=year_only)
    if date:
        return date
    props = [
        'SublimeHelper.ListItem.Premiered',
        'SublimeHelper.ListItem.FirstAired',
        'SublimeHelper.ListItem.Year',
        'ListItem.Year',
    ] if not year_only else [
        'SublimeHelper.ListItem.Year',
        'SublimeHelper.ListItem.Premiered',
        'SublimeHelper.ListItem.FirstAired',
        'ListItem.Year',
    ]
    for prop in props:
        try:
            date = _date_or_year(win.getProperty(prop), year_only=year_only)
            if date:
                return date
        except Exception:
            pass
    return ''


# Backwards-compatible aliases used by older code paths.


def _unwrap_art_source(value):
    value = str(value or '').strip()
    if not value:
        return ''
    # Kodi may wrap PVR artwork as image://pvrchannel_tv@http%3A.../. Decode
    # first, then strip the internal cache namespace. Repeat once because the
    # namespace can appear only after image:// URL decoding.
    for _ in range(2):
        low = value.lower()
        if low.startswith('image://'):
            value = unquote(value[8:])
            if value.endswith('/'):
                value = value[:-1]
            continue
        changed = False
        for scheme in ('http://', 'https://', 'special://', 'smb://', 'nfs://'):
            marker = '@' + scheme
            index = low.find(marker)
            if index >= 0:
                value = value[index + 1:]
                changed = True
                break
        if not changed:
            break
    return _normalize_fallback_art_url(value)


def _normalize_fallback_art_url(value):
    value = str(value or '').strip()
    if not value:
        return ''
    path, sep, suffix = value.partition('|')
    path = path.strip()
    low = path.lower()
    if not path:
        return ''
    if low.startswith(('http://', 'https://', 'special://', 'resource://', 'plugin://',
                       'pvr://', 'smb://', 'nfs://', 'file://', 'image://')):
        fixed = path
    elif low.startswith('//'):
        fixed = 'https:' + path
    elif low.startswith('/image.tmdb.org/'):
        fixed = 'https:/' + path
    elif low.startswith('image.tmdb.org/'):
        fixed = 'https://' + path
    elif re.match(r'^/?s/\d+/', low, re.IGNORECASE) or low.startswith(('s/', '/s/')):
        fixed = 'http://filmixapp.vip/' + path.lstrip('/')
    elif low.startswith(('/posters/', '/thumbs/', '/uploads/')):
        fixed = 'http://filmixapp.vip' + path
    elif low.startswith(('posters/', 'thumbs/', 'uploads/')):
        fixed = 'http://filmixapp.vip/' + path.lstrip('/')
    elif re.match(r'^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}(?::\d+)?/', low, re.IGNORECASE):
        fixed = 'https://' + path
    else:
        fixed = path
    return fixed + (sep + suffix if sep else '')


def _fallback_clean_art(value):
    try:
        value = _unwrap_art_source(_clean_info_value(value))
        if not value:
            return ''
        low = value.lower()
        # Ignore common skin/Kodi placeholder art. Real plugin/art URLs and picon paths pass through.
        bad = (
            'overlayspoiler.png', 'defaultvideo.png', 'defaultfolder.png', 'defaulttvshows.png',
            'defaultmovies.png', 'defaultpicture.png', 'defaultprogram.png',
            'special://skin/extras/icons/folder.png',
            # Provider/plugin placeholders must never outrank the focused row's
            # real poster. They are often non-empty URLs which return 404 and in
            # 718 suppressed a valid VCL.Widget.Poster fallback completely.
            '/no-poster.', '/no_poster.', '/noposter.', '/no-image.', '/no_image.',
            '/noimage.', '/placeholder.', 'image-not-found', 'image_not_found',
            'kinopoiskapiunofficial.tech/images/posters/kp/no-poster.png',
        )
        if any(x in low for x in bad):
            return ''
        # TVLink can expose a synthetic missing-picon URL which answers 404 and
        # was repeatedly fed into the background preparation loop.
        if low.endswith('/logo/0000.png'):
            return ''
        if low.endswith('/.') or low.endswith(',.png'):
            return ''
        return value
    except Exception:
        return ''


# Which label answered last, so a trace can say where a picture came from.
_ART_SOURCE = ['']


def _first_nonempty_art_from_labels(labels):
    for label in labels:
        try:
            value = _fallback_clean_art(read_label(label))
            if value:
                _ART_SOURCE[0] = label
                return value
        except Exception:
            pass
    _ART_SOURCE[0] = ''
    return ''


def _container_has_real_fanart(cid, current_fallback=''):
    # 877: fallback may be suppressed only by enriched background that is
    # published for the same focused row fingerprint. Global helper art from the
    # previous item must never hide fallback for the current item (this was the
    # remaining no-background case for short/ambiguous titles such as "Сезон").
    try:
        # Sublime 893: do not require SublimeHelper.WidgetContainer here. Only
        # widget-like hosts publish it (hubs, search, dialogs, OSD, PVR and the
        # Combined views); an ordinary MyVideoNav view never does, so this gate
        # was permanently closed in film/series/episode lists and the poster
        # fallback won there even with validated fanart available. The
        # fingerprint comparison below is the stronger check anyway: it is
        # computed for this exact container id (see _current_item_fingerprint,
        # whose first hashed value is the container id), so a match already
        # proves the published art belongs to this row of this container.
        current_fp = _current_item_fingerprint(cid)
        published_fp = _home_window().getProperty('SublimeHelper.ListItem.Fingerprint') or ''
        if not current_fp or not published_fp or current_fp != published_fp:
            return False
        # BlurImage/Current.BlurImage can be stale or generated from poster/fallback.
        # Only real validated background properties are allowed to suppress fallback.
        primary_art = _first_nonempty_art_from_labels([
            'Window.Property(SublimeHelper.ListItem.Landscape)',
            'Window.Property(SublimeHelper.ListItem.Fanart)',
            'Window.Property(SublimeHelper.ListItem.TVShow.Landscape)',
            'Window.Property(SublimeHelper.ListItem.TVShow.Fanart)',
            'Window(Home).Property(SublimeHelper.ListItem.Landscape)',
            'Window(Home).Property(SublimeHelper.ListItem.Fanart)',
            'Window(Home).Property(SublimeHelper.ListItem.TVShow.Landscape)',
            'Window(Home).Property(SublimeHelper.ListItem.TVShow.Fanart)',
        ])
        if not primary_art:
            return False
        if current_fallback and primary_art == current_fallback:
            return False
        return True
    except Exception:
        return False


def _current_widgetcontainer_matches(cid):
    try:
        cid = str(int(cid or 0))
    except Exception:
        cid = str(cid or '')
    if not cid:
        return False
    values = []
    try:
        values.append(_home_window().getProperty('SublimeHelper.WidgetContainer') or '')
    except Exception:
        pass
    for label in (
        'Window.Property(SublimeHelper.WidgetContainer)',
        'Window(Home).Property(SublimeHelper.WidgetContainer)',
    ):
        try:
            values.append(read_label(label) or '')
        except Exception:
            pass
    for value in values:
        try:
            if str(int(value or 0)) == cid:
                return True
        except Exception:
            if str(value or '') == cid:
                return True
    return False


def _current_focused_real_fanart_loaded(cid, current_fallback=''):
    """Clear fallback only when real validated background art is available for the same focused row."""
    loaded = _container_has_real_fanart(cid, current_fallback)
    if loaded:
        try:
            key = _current_item_key(cid)
            if key:
                if len(_ENRICHED_SEEN) >= ENRICHED_SEEN_MAX:
                    _ENRICHED_SEEN.clear()
                _ENRICHED_SEEN[key] = True
        except Exception:
            pass
    return loaded


def _container_is_pvr_fallback_item(cid):
    # Broader than the date filter, but used only to choose picon geometry.
    # This keeps the narrow PVR-date filter intact while recognising EPG rows
    # that do not expose pvr:// in all CoreELEC/Kodi states.
    try:
        if _container_is_pvr_item(cid):
            return True
        if _first_nonempty_label(['Container(%s).ListItem.ChannelNumberLabel' % cid]):
            return True
        chan = _first_nonempty_label(['Container(%s).ListItem.ChannelName' % cid])
        start = _first_nonempty_label(['Container(%s).ListItem.StartTime' % cid])
        end = _first_nonempty_label(['Container(%s).ListItem.EndTime' % cid])
        return bool(chan and start and end)
    except Exception:
        return False


def _container_fallback_art(cid):
    """Return (kind, art) for the currently focused row item only.

    VCL_SL_3.2.9.10.575: no stale SublimeHelper/Home fanart is used here.
    This lets fallback re-arm when the user leaves a movies/series row and later returns.
    """
    try:
        if not cid:
            return '', ''
        # While the row is being identified there used to be no fallback either
        # (`_background_is_resolving_for_current_row` returned nothing here), so
        # the screen stayed empty for as long as identification took - seconds on
        # a row the provider has not resolved, which is most of a fresh lane. The
        # picture published below belongs to the row in focus, not to the one
        # before it, so showing it during that wait is not the flash the rule
        # forbids: it is the difference between this row's poster and nothing.
        current_fallback = ''
        try:
            current_fallback = _home_window().getProperty('AF3SL.FallbackArt') or ''
        except Exception:
            current_fallback = ''
        if _current_focused_real_fanart_loaded(cid, current_fallback):
            return '', ''
        # The fingerprint check above can be a moment behind: it compares a
        # published fingerprint that the metadata layer writes after the art. So
        # ask the other question too - does the enrichment ON SCREEN belong to
        # THIS row, and does it carry a background? If it does, this row already
        # has its picture and a placeholder on top of it is the third picture
        # the owner reported: «выводит обогащенный фон, потом фолбек, потом
        # опять обогащенный фон».
        try:
            win_home = _home_window()
            if _sublimehelper_meta_matches_row(win_home, cid):
                enriched = (win_home.getProperty('SublimeHelper.ListItem.Fanart')
                            or win_home.getProperty('SublimeHelper.ListItem.Landscape'))
                if enriched and enriched != current_fallback:
                    return '', ''
        except Exception:
            pass
        if _container_is_pvr_fallback_item(cid):
            # VCL.Widget.Poster was tried FIRST here on the theory that the
            # skin's onfocus handler names the focused row's art sooner than
            # Kodi's container labels. Measured on .20 over a full sweep, it was
            # worse where it counts - from keypress to picture, YouTube went
            # 0.55 s -> 1.20 s - and the trace showed that property answering
            # not once: the same handler clears it before setting it, so the
            # publisher kept reading it empty or stale. It stays last.
            art = _first_nonempty_art_from_labels([
                'Container(%s).ListItem.Art(icon)' % cid,
                'Container(%s).ListItem.Icon' % cid,
                'Container(%s).ListItem.Art(thumb)' % cid,
                'Container(%s).ListItem.Thumb' % cid,
                'Container(%s).ListItem.Property(ChannelIcon)' % cid,
                'Container(%s).ListItem.Property(channelicon)' % cid,
                'Container(%s).ListItem.Property(icon)' % cid,
                'Container(%s).ListItem.Property(thumb)' % cid,
            ])
            return ('pvr', art) if art else ('', '')
        # During identity validation, and after an explicit-id rejection, raw
        # plugin artwork is not a fallback source. It may belong to the wrong
        # (including adult) provider card. Only already validated helper art is safe.
        identity_guard = bool(
            _home_window().getProperty('SublimeHelper.ListItem.IdentityPending') or
            _home_window().getProperty('SublimeHelper.ListItem.IdentityRejected'))
        if identity_guard:
            # A rejected provider identity must block provider fanart, logo and
            # trailer, but not the focused plugin item's own poster. The latter is
            # the safe source used for the blurred fallback while identity is pending
            # or rejected (703 behaviour restored without re-exposing raw fanart).
            art = _first_nonempty_art_from_labels([
                'Container(%s).ListItem.Property(PosterOriginal)' % cid,
                'Container(%s).ListItem.Art(poster)' % cid,
                'Container(%s).ListItem.Art(tvshow.poster)' % cid,
                'Container(%s).ListItem.Art(season.poster)' % cid,
                'Container(%s).ListItem.Art(thumb)' % cid,
                'Container(%s).ListItem.Thumb' % cid,
                'Container(%s).ListItem.Icon' % cid,
                'Container(%s).ListItem.Property(poster)' % cid,
                'Container(%s).ListItem.Property(thumb)' % cid,
            ])
            return ('poster', art) if art else ('', '')
        # Movies/series/non-PVR widgets: prefer the focused plugin row's own
        # visible poster exactly as AF3 does. Provider-enriched PosterOriginal is
        # only a fallback because it can be a non-empty no-poster placeholder.
        #
        # VCL.Widget.Poster is added as the final fallback here to match the
        # identity_guard branch above. It is set by an XML onfocus handler
        # (Includes_Lists.xml) the instant a row gains focus - native Kodi
        # skinning, not this Python loop - from whichever of Art(poster)/
        # tvshow.poster/season.poster/thumb/Icon is first non-empty, so it is
        # populated for a plain folder/action row (e.g. a YouTube "Watch later"
        # or "Recommendations" entry) that carries none of the fields above and
        # never gets a SublimeHelper.ListItem.PosterOriginal (that property is
        # only ever published by the metadata pipeline for real media rows).
        # Before this branch could be reached without IdentityPending having
        # been set for at least one tick first, so it always inherited whatever
        # the identity_guard branch had already resolved; once
        # sync_metadata_properties stopped setting IdentityPending on first
        # sight (see the plan step-1 comment on that function), a content-less
        # folder row could land here directly and come up with nothing. Measured
        # A/B on <коробка>: 0/36 blank on the unmodified build, 2/36 blank
        # (both were exactly this kind of row) once IdentityPending's one-tick
        # wait was removed without this fallback.
        art = _first_nonempty_art_from_labels([
            'Container(%s).ListItem.Art(poster)' % cid,
            'Container(%s).ListItem.Art(tvshow.poster)' % cid,
            'Container(%s).ListItem.Art(season.poster)' % cid,
            'Container(%s).ListItem.Art(thumb)' % cid,
            'Container(%s).ListItem.Thumb' % cid,
            'Container(%s).ListItem.Icon' % cid,
            'Container(%s).ListItem.Property(poster)' % cid,
            'Container(%s).ListItem.Property(thumb)' % cid,
            'Container(%s).ListItem.Property(PosterOriginal)' % cid,
            'Window(Home).Property(SublimeHelper.ListItem.PosterOriginal)',
            # VCL.Widget.Poster не источник: снимок входа в ряд, а не этой карточки - держал
            # чужой постер из окна поиска (.20, 20.11.2026)
        ])
        return ('poster', art) if art else ('', '')
    except Exception:
        return '', ''


def _set_wash_color_smooth(win, prop, target, duration=0.0):
    """Publish a ready wash colour immediately; artwork focus must not lag behind."""
    target = str(target or '').strip().upper()
    if not target:
        return
    if win.getProperty(prop) != target:
        win.setProperty(prop, target)
    _clear_wash_transition(win, prop)


def _clear_wash_transition(win, prop):
    for suffix in ('.Target', '.From', '.Start'):
        try:
            win.clearProperty('%s%s' % (prop, suffix))
        except Exception:
            pass


def _clear_fallback_art(win, reason=''):
    try:
        if win.getProperty('AF3SL.FallbackArt') or win.getProperty('AF3SL.FallbackPreparedArt'):
            log('bg-trace снял фолбек: %s' % (reason or 'без причины'))
        for name in (
            'AF3SL.FallbackArt', 'AF3SL.FallbackArtKind', 'AF3SL.FallbackKey',
            'AF3SL.FallbackSourceKey', 'AF3SL.FallbackPrepareNextPoll', 'AF3SL.FallbackPrepared', 'AF3SL.FallbackPreparedArt',
            'AF3SL.FallbackColorNextPoll', 'AF3SL.FallbackSourceArt', 'AF3SL.FallbackWashColor', 'AF3SL.FallbackWashColorSource',
            'AF3SL.FallbackPrimaryReal',
            # Clear legacy 669-672 grayscale properties during an in-place update.
            'AF3SL.FallbackArtWashed', 'AF3SL.FallbackArtWashedSource',
        ):
            win.clearProperty(name)
        _clear_wash_transition(win, 'AF3SL.FallbackWashColor')
    except Exception:
        pass


# How long the service keeps its hands off the GUI after it has appeared.
# Measured against the crash logs: the segfaults land in the first twenty
# seconds of a Kodi start, while windows and provider services are still coming
# up. Nothing this service does is urgent at that moment.
STARTUP_SETTLE_SECONDS = 12.0
_STARTUP_READY_WINDOWS = ' | '.join(
    ['Window.IsVisible(home)', 'Window.IsVisible(MyVideoNav.xml)'] +
    ['Window.IsVisible(Custom_%s_Hub.xml)' % _n for _n in ('1100', '1101', '1102', '1103', '1104', '1106', '1107', '1108')])
# How often the loop looks around. It was a flat 250 ms, and that alone is most
# of what a warm row costs: the data is in the cache, the wait is the poll. The
# owner's requirement is «после наполнения кеша мгновенно при смене фокуса», so
# the loop watches closely right after something changes and backs off when the
# screen has been still - the labels it reads are batched and briefly cached, so
# looking often is cheap.
POLL_ACTIVE = 0.06
POLL_SETTLED = 0.25
# Видео на весь экран, без меню плеера, полосы перемотки и диалогов: строк под
# курсором нет, публиковать нечего. Аудит на .20 17.10.2026: при ТВ на весь
# экран служба делала ~2 такта в секунду по ~460 мс (почти без отдыха). Здесь
# такт реже; любое меню возвращает обычный темп со следующего такта.
POLL_FULLSCREEN = 1.0
_PLAIN_FULLSCREEN = ('Window.IsActive(fullscreenvideo) + Player.HasVideo'
                     ' + !Window.IsVisible(videoosd) + !Window.IsVisible(seekbar)'
                     ' + !Window.IsVisible(osdvideosettings) + !Window.IsVisible(osdaudiosettings)'
                     ' + !Window.IsVisible(pvrosdchannels) + !Window.IsVisible(pvrosdguide)'
                     ' + !Window.IsVisible(fullscreeninfo) + !System.HasActiveModalDialog'
                     ' + !System.HasVisibleModalDialog')


def _plain_fullscreen_video():
    try:
        return bool(xbmc.getCondVisibility(_PLAIN_FULLSCREEN))
    except Exception:
        return False
POLL_ACTIVE_WINDOW = 2.5
# Третья ступень - «пульт давно не трогали, спим по секунде» - здесь была
# 30.08.2026 и снята по решению владельца, не поставленной ни на одну коробку.
#
# Замер, ради которого она писалась: простой стоил 58.7 % ядра, из них kodi.bin
# 32.8 % и наш Python 17.0 %. Отступ убрал бы бо́льшую часть вторых. Но платой
# было опоздание до секунды на первом такте после пробуждения, а главный расход
# - отрисовка - от этого не меняется вовсе: Kodi гоняет интерфейс на полной
# частоте развёртки (System.FPS = 50.00 на хабе), потому что обработка всех
# элементов идёт каждый кадр независимо от того, изменилось ли что-нибудь.
# Владелец отказался платить отзывчивостью за долю меньшего слагаемого.
# How long the cursor must rest before a clearlogo that is not cached is worth
# fetching. Nothing else waits for this.
SETTLE_SECONDS = 0.7


# How long the fallback background waits for the metadata layer to publish for
# the newly focused row before painting its own placeholder.
#
# It was 0.6 s to avoid a middle picture: blurred poster first, enriched fanart
# a moment later. That reasoning no longer holds. The enriched background is now
# published only once Kodi actually holds the picture (see core._texture_ready),
# so on a row that is not already cached there is nothing to show for a second
# or more - and during a scroll the placeholder never appeared at all, which is
# what the owner reported watching.
#
# Now zero, by the owner's own call: «сделай так, чтобы фолбек загружался первым
# для всех виджетов на главной - он дешёвый - а полное обогащение уже после».
# That is the right order. The placeholder is built from the row's OWN poster,
# which Kodi already holds (it is drawn in the row), so it costs nothing to show
# and it is never the wrong film. The enriched background then replaces it when
# it is actually available - and only then, see core.HOLD_BACKGROUND_UNTIL_CACHED.
# The reads this costs are cheap again since labels are asked in batches through
# a short-lived cache (core.read_labels), so waiting is no longer a safety
# measure either.
# Zero, and measured: a 0.18 s window for an enrichable row to publish its own
# background before the placeholder went up cost far more than it saved - films
# went from 0.30 s to 1.10 s from keypress to picture, with 8 of 32 rows past
# five seconds against 3 of 40. Whatever the second picture costs the eye, the
# wait costs more.
FALLBACK_METADATA_GRACE = 0.0
# How often the publisher may be asked while the focused row has not changed.
FALLBACK_POLL_SECONDS = 1.5
# Last row the trace announced, so one line marks each focus change.
_TRACE_ROW = ['', 0.0, '']
# Until when this loop should tick at POLL_ACTIVE. Set the moment a row change is
# noticed at the TOP of the turn, because the bottom of the turn - where the old
# pacing lived - is not always reached: several branches sleep and continue.
_FAST_UNTIL = [0.0]


# сколько последний такт проспал на видео во весь экран: в «долгий такт» сон не входит - иначе
# при каждом просмотре журнал получал строку в секунду (Windows, 23.11.2026)
_FULLSCREEN_SLEPT = [0.0]


def _nap_wait(mon, nap):
    """Сон такта. На видео во весь экран тяжёлый такт раз в секунду, но каждые 0,25 с дешёвая
    проверка: открылось меню плеера, перемотка или диалог - сон обрывается, и отклик как прежде.
    Возвращает True, если Kodi останавливают."""
    if nap < POLL_FULLSCREEN:
        return mon.waitForAbort(nap)
    t0 = time.monotonic()
    left = nap
    try:
        while left > 0:
            step = min(POLL_SETTLED, left)
            if mon.waitForAbort(step):
                return True
            left -= step
            if not _plain_fullscreen_video():
                break
        return False
    finally:
        _FULLSCREEN_SLEPT[0] = time.monotonic() - t0


def _tick_sleep(now=None):
    now = now if now is not None else time.monotonic()
    nap = POLL_ACTIVE if now < _FAST_UNTIL[0] else POLL_SETTLED
    # видео на весь экран - и для ранних выходов такта, не только для последнего сна: они спали по
    # 0,25 с, и при просмотре было 2512 тактов за 15 минут, цикл занят почти всё время (.20, 23.11.2026)
    if nap < POLL_FULLSCREEN and _plain_fullscreen_video():
        nap = POLL_FULLSCREEN
    return nap
# One empty reading is not proof that a row has no picture. Kodi updates a row's
# ListItem.Label before its ListItem.Art, so a call that lands in between reads
# no art at all - and clearing on that reading is what the owner saw as a pause:
# traced on .20, the background was published and then wiped 20-200 ms later by
# the very next call, leaving the screen empty until the 1.5 s poll came round.
# The picture is therefore taken down only when the same row reads empty twice.
_NO_ART = {'key': '', 'strikes': 0, 'published': ''}
# When a PVR row's picture was first asked for, so a channel whose blurred
# version cannot be made still ends up with something on screen.
_RAW_WAIT = {}
RAW_PICON_GRACE = 2.0
# Rows that were seen with an enriched background of their own. Those need no
# placeholder at all - showing one only means the eye gets two pictures for one
# keypress. Rows not in here (a first-ever visit) get the placeholder at once,
# because waiting on the chance that enrichment might arrive is what took a film
# from 0.30 s to 0.94 s. Bounded, and keyed by the row's identity.
# Такт, в котором ничего не изменилось, пропускается целиком - но не дольше
# трёх секунд подряд, чтобы любая ветка, о которой мы не подумали, всё равно
# получала свой полный такт.
IDLE_TURN_LIMIT = 3.0
_IDLE_TURN = {'key': '', 'at': 0.0}
# Сколько стадия фона имеет право доверять прошлому ответу для той же строки.
BG_STAGE_LIMIT = 10.0


class _WarmSkipped(Exception):
    """Прогрев отменён у самого вызова: пульт тронули."""

# Сколько курсор должен простоять, прежде чем греть соседей. Меньше
# такта цикла на покое (0.25 с), поэтому на обычной остановке прогрев
# начинается сразу же, а на скролле не начинается вовсе.
PREWARM_SETTLE_SECONDS = 0.4
# С какого такта он считается долгим и попадает в обычный журнал.
SLOW_TURN_LOG_MS = 700.0

# Сводка по ВСЕМ тактам, а не только по долгим.
#
# Аудит 07.09.2026 показал перекос выборки: в журнал попадали лишь такты
# дольше 700 мс, и по ним нельзя сказать, каков обычный такт - те же 14 долгих
# тактов за прогон могли быть и на фоне 60 мс, и на фоне 400 мс. Здесь
# считаются все такты и раз в четверть часа печатается одна строка: медиана,
# 95-й процентиль и самые дорогие стадии. Память постоянная - хвост из
# последних значений.
_TURN_STATS = {'ms': [], 'stages': {}, 'next_report': 0.0, 'turns': 0}
_TURN_STATS_KEEP = 4000
_TURN_STATS_PERIOD = 900.0


def _percentile(values, share):
    if not values:
        return 0.0
    data = sorted(values)
    index = min(len(data) - 1, max(0, int(round(share * (len(data) - 1)))))
    return data[index]


def _turn_stats_add(total_ms, marks):
    stats = _TURN_STATS
    stats['turns'] += 1
    stats['ms'].append(total_ms)
    if len(stats['ms']) > _TURN_STATS_KEEP:
        del stats['ms'][:len(stats['ms']) - _TURN_STATS_KEEP]
    previous = 0.0
    for name, at_ms in marks or ():
        cost = at_ms - previous
        previous = at_ms
        if cost <= 0:
            continue
        bucket = stats['stages'].setdefault(name, [0.0, 0])
        bucket[0] += cost
        bucket[1] += 1


def _turn_stats_report(now_ts):
    stats = _TURN_STATS
    stats['next_report'] = now_ts + _TURN_STATS_PERIOD
    values = stats['ms']
    if not values:
        return
    top = sorted(stats['stages'].items(), key=lambda item: -item[1][0])[:3]
    log('такты за %d мин: %d, медиана %.0f мс, 95%% %.0f мс, худший %.0f мс; '
        'дороже всего: %s'
        % (int(_TURN_STATS_PERIOD / 60), stats['turns'],
           _percentile(values, 0.5), _percentile(values, 0.95), max(values),
           ', '.join('%s %.0f мс/такт' % (name, total / max(1, count))
                     for name, (total, count) in top) or 'нечего'))
    stats['ms'] = []
    stats['stages'] = {}
    stats['turns'] = 0
_BG_DONE = {'key': '', 'at': 0.0}
# Как часто цикл вообще заходит в такт хаба. Вся его работа - по своим часам
# (полосы, зеркало, обмен), и ни одна из них не измеряется секундами.
HUB_TICK_SECONDS = 5.0
# Через столько зависший поток такта хаба перестаёт считаться работающим.
HUB_TICK_STUCK_SECONDS = 300.0
_HUB_TICK = {'at': 0.0, 'thread': None, 'started': 0.0}
_ENRICHED_SEEN = {}
ENRICHED_SEEN_MAX = 600
# The window a row the provider enriches gets before its placeholder goes up.
# Raised from 0.12 s once the dark gaps were gone and the only thing left was
# two pictures in quick succession on a row change - the owner: «фон предыдущего
# очень быстро сменяется». That row's own background arrives in 0.18-0.22 s
# (measured on .20 over 48 focus changes), so this is the width that lets it win
# and leaves the eye with one picture. Rows nobody enriches never wait. A cached enriched background is published by the metadata stage of
# this very turn, so this is exactly enough to let it win and leave the eye with
# one picture instead of two. Rows nobody enriches - a channel, a clip - never
# see it. A first attempt at this used 0.18 s and measured far worse (films
# 0.30 s -> 1.10 s), but that was while the loop still ticked at a fixed quarter
# second in the branch it actually took; with the pacing fixed the cost is one
# turn, about a tenth of a second.
ENRICH_GRACE = 0.30


def _update_fallback_art(win, row_id):
    try:
        # Home and MyVideoNav share one fallback-art publisher.
        # The previous split made lists lose fallback background art while Home
        # worked.  Keep one code path and only clear outside media/home windows.
        # Нажали канал, фильм или ролик: пока идёт запуск (окно ожидания, видео ещё ни разу
        # не было на весь экран), подложку не трогать. Снятие её «не окно медиа или нет
        # строки» через 0.18 с после нажатия оставляло пустой фон до полноэкранного видео -
        # 0.47 с у «Известий», 3 с у RT News (запись состояний на .20, 17.11.2026, владелец:
        # «фон всё ещё на мгновение пропадает при включении канала»)
        try:
            if xbmc.getCondVisibility(
                    'Window.IsVisible(DialogBusy.xml) | [Player.HasMedia + '
                    'String.IsEmpty(Window(Home).Property(Sublime.VideoShown))]'):
                return
        except Exception:
            pass
        if not (_is_homeish_window() or _is_media_nav_window()) or not row_id:
            _clear_fallback_art(win, 'не окно медиа или нет строки')
            return
        # Строка, собранная заранее, приносит готовую подложку в
        # Property(Sublime.Background) - её публикует sublime_helper/core.py
        # быстрым путём. Заглушка нужна там, где такой строки нет: PVR, чужие
        # некаталожные списки, ещё не собранные строки. Для готовой строки здесь
        # не делается ни размытия, ни опроса текстур.
        try:
            address = ('Container(%s).ListItem.Property(Sublime.Background)' % row_id
                       if str(row_id).isdigit()
                       else 'ListItem.Property(Sublime.Background)')
            if xbmc.getInfoLabel(address):
                _clear_fallback_art(win, 'строка принесла свою подложку')
                return
            # канал ТВ: фон и цвет - готовые файлы pvr_bg/<канал>.png и .wash.png, разметка берёт
            # их по имени канала (Includes_Background.xml); строить здесь то же - впустую (аудит)
            channel = ('Container(%s).ListItem.ChannelName' % row_id
                       if str(row_id).isdigit() else 'ListItem.ChannelName')
            if xbmc.getInfoLabel(channel):
                _clear_fallback_art(win, 'канал: фон из pvr_bg')
                return
        except Exception:
            pass
        current_fallback = ''
        try:
            current_fallback = win.getProperty('AF3SL.FallbackArt') or ''
        except Exception:
            current_fallback = ''
        if _current_focused_real_fanart_loaded(row_id, current_fallback):
            _clear_fallback_art(win, 'обогащённый фон готов')
            win.setProperty('AF3SL.FallbackPrimaryReal', 'true')
            return
        else:
            win.clearProperty('AF3SL.FallbackPrimaryReal')

        # Plan step 1 (docs/PLAN_INSTANT_ART_2026-08-13.md): added a
        # one-tick wait here - "Kodi updates a row's ListItem.Label before its
        # ListItem.Art(poster), so right after focus moves the freshly focused
        # row can still report the previous row's poster" - by requiring the
        # same (row, focus_path, art) signature on two consecutive ticks before
        # trusting it. This is a second, independent two-tick guard of exactly
        # the kind sync_metadata_properties had (fixed separately in the same
        # commit), and PVR/YouTube rows - which never touch that other guard at
        # all - still measured the same ~700-1100 ms latency, because THIS is
        # the guard that governs when their background actually appears.
        #
        # _current_item_key already covers label + path + dbid + tmdb (a
        # superset of the folder-path check above) and is read once per loop
        # iteration by the caller before this function runs. Read it again here,
        # before and after picking `art`, instead of waiting a whole extra tick:
        # if identity moved while `art` was being read, `art` may belong to the
        # row that just lost focus, so discard exactly as before and let the
        # next tick retry.
        identity_before = _current_item_key(row_id)
        kind, art = _container_fallback_art(row_id)
        if not art:
            row_key = '%s|%s' % (row_id, identity_before)
            published = _NO_ART.get('published') or ''
            if published and published != row_key:
                # A different row from the one whose picture is showing, and it
                # has no art of its own yet: what is on screen belongs to the
                # row before it. Keeping it is what made a foreign background
                # flash past when the widget changed mid-scroll. Empty is
                # honest, and the right picture follows on the next turn.
                _NO_ART.update({'key': '', 'strikes': 0, 'published': ''})
                _clear_fallback_art(win, 'пустое чтение на другой строке')
                return
            if _NO_ART['key'] == row_key:
                _NO_ART['strikes'] += 1
            else:
                _NO_ART.update({'key': row_key, 'strikes': 1})
            if _NO_ART['strikes'] < 2:
                # The same row read empty once. Kodi refreshes a row's label
                # before its art, so one empty reading proves nothing, and
                # wiping the picture on it is what the owner saw as a pause.
                return
            _clear_fallback_art(win, 'две пустых подряд')
            return
        _NO_ART.update({'key': '', 'strikes': 0,
                        'published': '%s|%s' % (row_id, identity_before)})
        if _current_item_key(row_id) != identity_before:
            return

        now_ts = time.monotonic()
        source_key = '%s|%s|%s' % (row_id, kind, art)
        source_changed = win.getProperty('AF3SL.FallbackSourceKey') != source_key
        if not source_changed:
            pass
        if source_changed:
            # If the blurred version already exists, publish THAT as the one and
            # only fallback picture. Publishing the sharp poster first and the
            # blurred one a tick later is two paints for one row, and with the
            # background now prepared ahead of time the second paint was landing
            # ~90 ms after the first - visible as a flick. Traced on
            # <коробка> before this change: poster at 1.42 s, blur at 1.51 s.
            prepared = ''
            try:
                prepared = (request_poster_background(art) if kind == 'poster'
                            else request_pvr_background(art)) or ''
            except Exception:
                prepared = ''
            # A channel picon used to be published raw while its blurred version
            # was being made, and the two do not render the same size - the
            # picture appeared large and then shrank («сначала выдаются крупнее,
            # потом уменьшаются»). One picture per row: wait for the prepared
            # one, which is normally already in the cache, and fall back to the
            # raw picon only if preparation has not produced anything for two
            # seconds - so a channel whose blur cannot be made still gets a
            # background instead of none.
            if not prepared and kind == 'pvr':
                first_seen = _RAW_WAIT.get(source_key)
                if first_seen is None:
                    _RAW_WAIT.clear()
                    _RAW_WAIT[source_key] = now_ts
                    first_seen = now_ts
                if now_ts - first_seen < RAW_PICON_GRACE:
                    win.setProperty('AF3SL.FallbackWashColorSource', art)
                    win.setProperty('AF3SL.FallbackPrepareNextPoll', '0')
                    return
            if not prepared and kind != 'pvr':
                # Never hand a full-size poster to a full-screen background: Kodi
                # decodes it on the way to the screen and the interface waits -
                # measured on .30, the row itself stopped changing for up to
                # 9.4 s. The prepared 1920x1080 version costs nothing to draw.
                #
                # And while it is being made, the previous picture must GO. The
                # first version of this kept it, which is how a film's
                # background ended up behind a YouTube row: those rows have no
                # prepared blur at all, so nothing ever replaced what was there
                # («идёшь вверх на ютуб - появляется фон какого-то фильма»).
                # Empty is honest; someone else's film is not.
                _clear_fallback_art(win, 'блюр готовится')
                win.setProperty('AF3SL.FallbackSourceKey', source_key)
                win.setProperty('AF3SL.FallbackWashColorSource', art)
                win.setProperty('AF3SL.FallbackPrepareNextPoll', '0')
                log('fallback art: row=%s kind=%s quality=готовится' % (row_id, kind))
                return
            win.setProperty('AF3SL.FallbackSourceKey', source_key)
            # Whose picture this is, in the one form both sides can compare: the
            # row's own path. The metadata publisher needs it to know whether
            # clearing its layer will reveal THIS row's placeholder or a black
            # screen (see core._publish).
            try:
                win.setProperty('AF3SL.FallbackRowPath',
                                _row_item_path(row_id) or '')
            except Exception:
                pass
            win.setProperty('AF3SL.FallbackSourceArt', art)
            win.setProperty('AF3SL.FallbackArtKind', kind)
            win.setProperty('AF3SL.FallbackArt', prepared or art)
            win.setProperty('AF3SL.FallbackKey', '%s|%s' % (source_key, prepared or art))
            win.setProperty('AF3SL.FallbackPrepareNextPoll',
                            str(now_ts + 30.0) if prepared else '0')
            if prepared:
                win.setProperty('AF3SL.FallbackPrepared', 'true')
                win.setProperty('AF3SL.FallbackPreparedArt', prepared)
            else:
                win.clearProperty('AF3SL.FallbackPrepared')
                win.clearProperty('AF3SL.FallbackPreparedArt')
            win.setProperty('AF3SL.FallbackWashColorSource', art)
            # The wash colour belongs to the same moment as the picture it
            # washes. It used to be left for the poll below, so it arrived a
            # tick or more after the background - the owner saw the colour catch
            # up afterwards, which reads as sloppy. The colour is extracted from
            # this very poster and the warm-up has usually done it already, so
            # ask now: a cached answer comes back immediately and goes out with
            # the art. If it is not ready, the poll still handles it.
            washed = ''
            try:
                washed = request_wash_color(art) or ''
            except Exception:
                washed = ''
            if washed:
                win.setProperty('AF3SL.FallbackWashColor', washed)
                win.setProperty('AF3SL.FallbackColorNextPoll', str(now_ts + 30.0))
            else:
                win.setProperty('AF3SL.FallbackColorNextPoll', '0')
                if not win.getProperty('AF3SL.FallbackWashColor'):
                    win.setProperty('AF3SL.FallbackWashColor', default_wash_color())
            _clear_wash_transition(win, 'AF3SL.FallbackWashColor')
            win.clearProperty('AF3SL.FallbackArtWashed')
            win.clearProperty('AF3SL.FallbackArtWashedSource')
            log('fallback art: row=%s kind=%s quality=%s wash=%s' % (
                row_id, kind, 'prepared-cached' if prepared else 'source',
                'сразу' if washed else 'позже'))
            # Sublime 869 diagnostic: log the real state the background/fallback
            # expressions read (raw conditions - $EXP is not valid in getCondVisibility).
            try:
                fb_art = win.getProperty('AF3SL.FallbackArt')
                cur_blur = (win.getProperty('SublimeHelper.ListItem.Current.BlurImage.Original')
                            or win.getProperty('SublimeHelper.ListItem.Current.BlurImage'))
                blur_win = read_label('Window.Property(SublimeHelper.ListItem.BlurImage.Original)')
                try:
                    wid = int(xbmcgui.getCurrentWindowId())
                except Exception:
                    wid = 0
                hub_visible = xbmc.getCondVisibility(
                    'Window.IsVisible(1100) | Window.IsVisible(1101) | Window.IsVisible(1102) | '
                    'Window.IsVisible(1103) | Window.IsVisible(1104) | Window.IsVisible(1106) | '
                    'Window.IsVisible(1107) | Window.IsVisible(1108) | Window.IsVisible(11100) | '
                    'Window.IsVisible(11101) | Window.IsVisible(11102) | Window.IsVisible(11103) | '
                    'Window.IsVisible(11104) | Window.IsVisible(11106) | Window.IsVisible(11107) | '
                    'Window.IsVisible(11108) | Window.IsVisible(1105) | Window.IsVisible(11105)')
                log('fallback diag: row=%s label=%r wid=%s hub=%s fallback_art=%s cur_blur=%s blur_win=%s show=%s art=%r'
                    % (row_id, (read_label('ListItem.Label') or '')[:36], wid,
                       1 if hub_visible else 0, 1 if fb_art else 0, 1 if cur_blur else 0,
                       1 if blur_win else 0,
                       1 if xbmc.getCondVisibility('Skin.HasSetting(AF3SL.Background.ShowFallbackArt)') else 0,
                       (fb_art or '')[-60:]))
            except Exception:
                pass

        if not win.getProperty('AF3SL.FallbackPrepared'):
            try:
                prepare_next = float(win.getProperty('AF3SL.FallbackPrepareNextPoll') or 0)
            except Exception:
                prepare_next = 0.0
            if now_ts >= prepare_next:
                prepared = ''
                quality_mode = ''
                if kind == 'poster':
                    prepared = request_poster_background(art)
                    quality_mode = 'prepared-4k-blur'
                elif kind == 'pvr':
                    prepared = request_pvr_background(art)
                    quality_mode = 'prepared-2x-blur'
                if prepared:
                    # 856: keep the visible texture stable for the whole current
                    # focus.  The prepared fallback is still generated/cached, but
                    # it must not replace source art mid-focus because that reads
                    # as a scale/image jump.  On a later focus the cached prepared
                    # file may be used by the background worker, but this publisher
                    # exposes one texture per source_key only.
                    win.setProperty('AF3SL.FallbackPrepared', 'true')
                    win.setProperty('AF3SL.FallbackPreparedArt', prepared)
                    win.setProperty('AF3SL.FallbackPrepareNextPoll', str(now_ts + 30.0))
                    log('fallback art: row=%s kind=%s quality=%s cached_only=yes' % (
                        row_id, kind, quality_mode or 'prepared'))
                else:
                    win.setProperty('AF3SL.FallbackPrepareNextPoll', str(now_ts + 0.5))

        try:
            next_poll = float(win.getProperty('AF3SL.FallbackColorNextPoll') or 0)
        except Exception:
            next_poll = 0.0
        if now_ts >= next_poll:
            color = request_wash_color(art)
            if color:
                _set_wash_color_smooth(win, 'AF3SL.FallbackWashColor', color)
                win.setProperty('AF3SL.FallbackWashColorSource', art)
                win.setProperty('AF3SL.FallbackColorNextPoll', str(now_ts + 30.0))
            else:
                win.setProperty('AF3SL.FallbackColorNextPoll', str(now_ts + 0.5))
    except Exception as exc:
        log('fallback art update skipped: %s' % exc, xbmc.LOGWARNING)
        _clear_fallback_art(win, 'прочее')


def _global_is_pvr_item():
    try:
        path = _clean_info_value(
            read_label('ListItem.FileNameAndPath') or
            read_label('ListItem.FolderPath') or
            read_label('ListItem.Path')
        ).lower()
        if path.startswith('pvr://'):
            return True
        channel = _clean_info_value(read_label('ListItem.ChannelName'))
        start = _clean_info_value(read_label('ListItem.StartTime'))
        end = _clean_info_value(read_label('ListItem.EndTime'))
        return bool(channel and (start or end))
    except Exception:
        return False


def _container_background_fanart(cid):
    """Return only real fanart for Home/hub rows; fallback art is handled separately."""
    return _first_nonempty_art_from_labels([
        'Container(%s).ListItem.Art(fanart)' % cid,
        'Container(%s).ListItem.Art(tvshow.fanart)' % cid,
        'Container(%s).ListItem.Art(artist.fanart)' % cid,
        'Container(%s).ListItem.Property(fanart)' % cid,
        'Container(%s).ListItem.Property(Fanart)' % cid,
        'Container(%s).ListItem.Property(SublimeHelper.ListItem.Fanart)' % cid,
    ])


def _global_background_source():
    source = _first_nonempty_art_from_labels([
        'ListItem.Art(fanart)',
        'ListItem.Art(tvshow.fanart)',
        'ListItem.Art(artist.fanart)',
        'ListItem.Property(fanart)',
        'ListItem.Property(Fanart)',
        'ListItem.Property(SublimeHelper.ListItem.Fanart)',
    ])
    if source:
        return source
    if not _global_is_pvr_item():
        return ''
    # Match the PVR source chain used by Action_Blur_Onload.
    return _first_nonempty_art_from_labels([
        'ListItem.EPGEventIcon',
        'ListItem.Art(icon)',
        'ListItem.Icon',
        'ListItem.Art(thumb)',
        'ListItem.Thumb',
        'ListItem.Property(ChannelIcon)',
        'ListItem.Property(channelicon)',
    ])


def _clear_background_wash(win):
    for name in (
        'AF3SL.WashColor', 'AF3SL.WashColorSource',
        # Legacy 669-672 properties are no longer read by the skin.
        'AF3SL.WashedBackground', 'AF3SL.WashedBackgroundSource',
        'SublimeHelper.ListItem.DesaturateImage',
        'SublimeHelper.ListItem.DesaturateImage.Original',
    ):
        try:
            if win.getProperty(name):
                win.clearProperty(name)
        except Exception:
            pass
    _clear_wash_transition(win, 'AF3SL.WashColor')


def _background_wash_source(win, row_id=0, preserve=False):
    if preserve:
        return win.getProperty('AF3SL.WashColorSource') or ''
    identity_guard = bool(
        win.getProperty('SublimeHelper.ListItem.IdentityPending') or
        win.getProperty('SublimeHelper.ListItem.IdentityRejected'))
    if row_id:
        source = '' if identity_guard else _container_background_fanart(row_id)
        if not source and _current_widgetcontainer_matches(row_id):
            source = _fallback_clean_art(
                win.getProperty('SublimeHelper.ListItem.Fanart') or
                win.getProperty('SublimeHelper.ListItem.TVShow.Fanart')
            )
        return source or ''
    if identity_guard:
        return _fallback_clean_art(
            win.getProperty('SublimeHelper.ListItem.Fanart') or
            win.getProperty('SublimeHelper.ListItem.TVShow.Fanart'))
    return _global_background_source() or ''


def _update_background_wash(win, row_id=0, preserve=False, source=None):
    """Publish a colour wash without replacing the source fanart texture."""
    try:
        # Строка хаба несёт свой цвет (Sublime.Wash, его читает Color_BackgroundWash первым):
        # считать его заново по картинке - чтение с диска на каждом такте впустую.
        if row_id and (read_label('Container(%s).ListItem.Property(Sublime.Wash)' % row_id)
                       or read_label('Container(%s).ListItem.ChannelName' % row_id)):
            return
        source = _background_wash_source(win, row_id, preserve) if source is None else source
        if not source:
            if not preserve:
                _clear_background_wash(win)
            return
        previous = win.getProperty('AF3SL.WashColorSource') or ''
        if previous != source:
            win.setProperty('AF3SL.WashColorSource', source)
            # Do not show the previous item's colour while the new artwork is resolved.
            win.setProperty('AF3SL.WashColor', default_wash_color())
            _clear_wash_transition(win, 'AF3SL.WashColor')
            win.clearProperty('AF3SL.WashedBackground')
            win.clearProperty('AF3SL.WashedBackgroundSource')
            win.clearProperty('SublimeHelper.ListItem.DesaturateImage')
            win.clearProperty('SublimeHelper.ListItem.DesaturateImage.Original')
        # Цвет считается по локальной подложке, если она уже готова: иначе
        # extraction сначала копирует удалённую картинку, и цвет приходит
        # позже фона - ровно то, на что пожаловался владелец.
        wash_from = source
        try:
            from resources.lib.sublime_helper.poster_background import prepared_path
            local = (win.getProperty('AF3SL.FallbackPreparedArt') or ''
                     if win.getProperty('AF3SL.FallbackRowPath') else '')
            wash_from = local or prepared_path('poster', source) or source
        except Exception:
            wash_from = source
        color = request_wash_color(wash_from)
        if color:
            _set_wash_color_smooth(win, 'AF3SL.WashColor', color)
            win.setProperty('AF3SL.WashColorSource', source)
    except Exception as exc:
        log('background wash update skipped: %s' % exc, xbmc.LOGWARNING)


def _row_info_is_own(row_id):
    """Собранная строка (Sublime.Background) с готовыми жанром, страной и датой.

    Разметка берёт эти три значения у самой строки (row_store.info_props) и значение службы
    AF3SL.* показывает только строке без своего значения (Label_Hub_*, Info_Combined_Row).
    Для такой строки _update_first_genre_props - десяток запросов к Kodi, результат которых
    никто не рисует."""
    if not row_id:
        return False
    prefix = 'Container(%s).ListItem.Property(Sublime.' % row_id
    for name in ('Background', 'Genres2', 'Country2', 'ReleaseDateDisplay'):
        if not read_label(prefix + name + ')'):
            return False
    return True


def _update_first_genre_props(win, row_id=0):
    try:
        ids = set(['502', '503'])
        try:
            widget_id = win.getProperty('SublimeHelper.WidgetContainer') or ''
            if widget_id:
                ids.add(str(widget_id))
        except Exception:
            pass
        if row_id:
            ids.add(str(row_id))

        # The focused row is the only legitimate source for the info line.
        # Previously this list always ended in the hardcoded containers 502/503,
        # so a row that simply has no genre/country of its own (YouTube and
        # plugin.video.ai.recommend rows never do) silently displayed the first
        # item of an unrelated tab instead - which is why every AI movie
        # recommendation showed the same country. 502/503 stay only as the
        # last-resort guess for when no focused row is known at all.
        current = ''
        preferred = []
        widget_id = ''
        try:
            widget_id = win.getProperty('SublimeHelper.WidgetContainer') or ''
        except Exception:
            widget_id = ''
        if row_id:
            preferred.append(str(row_id))
        elif widget_id:
            preferred.append(str(widget_id))
        else:
            preferred.extend(['502', '503'])
        # SublimeHelper's Window(Home) metadata describes whichever item it
        # enriched last. Reading it for a row it does not describe is the second
        # way another tab's values leaked in here, so it is gated on the
        # enrichment actually belonging to the focused row.
        allow_global = (not row_id) or _sublimehelper_meta_matches_row(win, row_id)
        # Ключ этих значений - путь карточки, прочитанный ДО них. Разметка показывает жанр, страну
        # и дату службы только при равенстве ключа карточке в фокусе: пока фокус стоял на собранных
        # строках, служба их не обновляла, и новый виджет без своих данных показывал строку
        # давно ушедшей карточки (владелец, 21.11.2026).
        meta_path = xbmc.getInfoLabel('Container(%s).ListItem.FileNameAndPath' % preferred[0]) if preferred else ''

        # Своё значение строки (Sublime.Genres2/Country2/ReleaseDateDisplay) разметка рисует сама и
        # дописывает к нему значение службы (Info_Combined_Row: $INFO[строки]$VAR[службы]). Условие
        # переменной смотрит ListItem - при фокусе на категориях это не строка виджета, и выходило
        # «20272027 ФантастикаФантастика ИспанияИспания» (.30, 25.11.2026). Поэтому для строки со
        # своим значением служба своё не выставляет вовсе - склеивать нечего при любом фокусе.
        own = {}
        if preferred:
            for name in ('Genres2', 'Country2', 'ReleaseDateDisplay'):
                own[name] = bool(read_label('Container(%s).ListItem.Property(Sublime.%s)'
                                            % (preferred[0], name)))

        # AF3SL.FirstGenre(.N), AF3SL.Country2.N, AF3SL.ReleaseYear не читает ни один XML - сняты
        # (аудит 21.11.2026): по два запроса к Kodi на каждый список каждые 5 с впустую.
        for cid in preferred:
            first = _container_first_genre(cid)
            if first:
                current = first
                break
        if not current and allow_global:
            current = _listitem_first_genre(win)

        if current and not own.get('Genres2'):
            win.setProperty('AF3SL.Genres2', current)
        else:
            win.clearProperty('AF3SL.Genres2')

        country_current = ''
        for cid in preferred:
            country_current = _container_first_country(cid)
            if country_current:
                break
        if not country_current and allow_global:
            country_current = _listitem_first_country(win)
        if country_current and not own.get('Country2'):
            win.setProperty('AF3SL.Country2', country_current)
        else:
            win.clearProperty('AF3SL.Country2')

        date_display = ''
        for cid in preferred:
            date_display = _container_release_display(cid)
            if date_display:
                break
        if not date_display and allow_global:
            date_display = _listitem_release_display(win)
        if date_display and not own.get('ReleaseDateDisplay'):
            win.setProperty('AF3SL.ReleaseDateDisplay', date_display)
        else:
            win.clearProperty('AF3SL.ReleaseDateDisplay')
        if meta_path:
            win.setProperty('AF3SL.MetaPath', meta_path)
        else:
            # без ключа значения не принадлежат ни одной карточке: на вкладках категорий путь пуст,
            # пустое равнялось пустому, и строка выходила «20262026 ДрамаДрама» (.20, 25.11.2026)
            win.clearProperty('AF3SL.MetaPath')
            for name in ('AF3SL.Genres2', 'AF3SL.Country2', 'AF3SL.ReleaseDateDisplay'):
                win.clearProperty(name)
    except Exception as exc:
        log('first genre/date/country update skipped: %s' % exc, xbmc.LOGWARNING)


# Что играет следующим. До 2026-08-28 это решала разметка: скрытый список 450 в
# Custom_1143_OSD_NextOverlay держал весь плейлист, а имя нужного элемента
# выбиралось из 51 развёрнутой переменной вида Image_Landscape_LIA_C450_<номер> -
# по одной на каждую возможную позицию, потому что индекс в $INFO обязан быть
# литералом. Это 534 КБ разметки, которые Kodi разбирал при каждой загрузке
# скина ради одной плашки «Далее».
#
# Здесь тот же ответ считается один раз за такт и кладётся в свойство. Порядок
# индексов сохранён ровно как был: VideoPlayer.PlaylistPosition считается от
# единицы, поэтому следующий элемент - это индекс, равный позиции.
_NEXT_PROPS = ('SublimeHelper.Player.Next.Title',
               'SublimeHelper.Player.Next.SubTitle',
               'SublimeHelper.Player.Next.Landscape')
_NEXT_STATE = {'key': None}


def _next_in_playlist_row(position):
    """Строка плейлиста, которая пойдёт следующей. Пусто - значит следующей нет."""
    try:
        answer = json.loads(xbmc.executeJSONRPC(json.dumps({
            'jsonrpc': '2.0', 'id': 1, 'method': 'Playlist.GetItems',
            'params': {'playlistid': 1,
                       'limits': {'start': int(position), 'end': int(position) + 1},
                       'properties': ['title', 'season', 'episode', 'showtitle',
                                      'year', 'rating', 'art', 'thumbnail']}})))
    except Exception:
        return {}
    items = ((answer.get('result') or {}).get('items') or [])
    return items[0] if items and isinstance(items[0], dict) else {}


def _next_in_playlist_values(row):
    art = row.get('art') or {}
    landscape = (art.get('landscape') or art.get('tvshow.landscape')
                 or art.get('season.landscape') or art.get('fanart')
                 or art.get('tvshow.fanart') or row.get('thumbnail')
                 or art.get('thumb') or art.get('poster') or '')
    title = str(row.get('title') or row.get('label') or '')
    dot = ' [COLOR=panel_fg_30]•[/COLOR] '
    parts = []
    show = str(row.get('showtitle') or '')
    if show:
        parts.append(show)
    try:
        season, episode = int(row.get('season') or 0), int(row.get('episode') or 0)
    except Exception:
        season = episode = 0
    if season > 0 and episode > 0:
        parts.append('%d×%02d' % (season, episode))
    year = str(row.get('year') or '')
    if year and year != '0':
        parts.append(year)
    try:
        rating = float(row.get('rating') or 0)
    except Exception:
        rating = 0
    if rating > 0:
        parts.append('%.1f' % rating)
    return {'SublimeHelper.Player.Next.Title': title,
            'SublimeHelper.Player.Next.SubTitle': dot.join(parts),
            'SublimeHelper.Player.Next.Landscape': str(landscape)}


_PLAYER_PROPS_SET = [True]       # True - свойства плеера могли остаться, снять ещё раз


def _update_next_in_playlist(win):
    try:
        length = int(xbmc.getInfoLabel('VideoPlayer.PlaylistLength') or 0)
        position = int(xbmc.getInfoLabel('VideoPlayer.PlaylistPosition') or 0)
    except Exception:
        length = position = 0
    if not xbmc.getCondVisibility('Player.HasVideo') or position <= 0 or position >= length:
        if _NEXT_STATE['key'] is not None:
            for prop in _NEXT_PROPS:
                try:
                    win.clearProperty(prop)
                except Exception:
                    pass
            _NEXT_STATE['key'] = None
        return
    key = (position, length)
    if _NEXT_STATE['key'] == key:
        return
    values = _next_in_playlist_values(_next_in_playlist_row(position))
    for prop in _NEXT_PROPS:
        try:
            win.setProperty(prop, values.get(prop, ''))
        except Exception:
            pass
    _NEXT_STATE['key'] = key


_PLAYER_INFO_STATE = {'key': None, 'at': 0.0}


def _update_player_info_props(win):
    try:
        if not xbmc.getCondVisibility('Player.HasMedia'):
            # Sublime.VideoShown ставит VideoFullScreen.xml при открытии: видео фоном
            # показывается только после того, как оно хоть раз было на весь экран
            # (Exp_Video_IsNotPlaying). Просмотр закончился - снова ждём полноэкранного
            for prop in ('AF3SL.Player.Genres2', 'AF3SL.Player.ReleaseYear', 'Sublime.VideoShown'):
                try:
                    win.clearProperty(prop)
                except Exception:
                    pass
            _PLAYER_INFO_STATE['key'] = None
            return
        # жанр и год не меняются, пока тот же файл и та же передача: 17 меток VideoPlayer.* (у PVR
        # каждая через клиент телегида) раз в секунду - главная часть «долгих тактов» при просмотре.
        # Перечитываются при смене файла/названия, при открытии меню или сведений и раз в 30 с
        key = (xbmc.getInfoLabel('Player.FilenameAndPath'), xbmc.getInfoLabel('VideoPlayer.Title'),
               xbmc.getCondVisibility('Window.IsActive(videoosd) | Player.ShowInfo'))
        now = time.monotonic()
        if key == _PLAYER_INFO_STATE['key'] and now - _PLAYER_INFO_STATE['at'] < 30.0:
            return
        _PLAYER_INFO_STATE['key'] = key
        _PLAYER_INFO_STATE['at'] = now
        genre = _first_nonempty_genre_from_labels([
            'VideoPlayer.Genre',
            'VideoPlayer.Property(Genre)',
            'VideoPlayer.Property(genre)',
            'VideoPlayer.Property(Genres)',
            'VideoPlayer.Property(genres)',
            'VideoPlayer.Property(SublimeHelper.ListItem.Genres)',
            'VideoPlayer.Property(SublimeHelper.ListItem.Genre)',
        ])
        year = _first_nonempty_year_from_labels([
            'VideoPlayer.Year',
            'VideoPlayer.Premiered',
            'VideoPlayer.FirstAired',
            'VideoPlayer.Property(year)',
            'VideoPlayer.Property(Year)',
            'VideoPlayer.Property(premiered)',
            'VideoPlayer.Property(first_air_date)',
            'VideoPlayer.Property(release_date)',
            'VideoPlayer.Property(SublimeHelper.ListItem.Year)',
            'VideoPlayer.Property(SublimeHelper.ListItem.Premiered)',
        ])
        if genre:
            win.setProperty('AF3SL.Player.Genres2', genre)
        else:
            win.clearProperty('AF3SL.Player.Genres2')
        if year:
            win.setProperty('AF3SL.Player.ReleaseYear', year)
        else:
            win.clearProperty('AF3SL.Player.ReleaseYear')
    except Exception as exc:
        log('player genre/year update skipped: %s' % exc, xbmc.LOGWARNING)

def _clear_action_buttons(win):
    for prop in ('VCL.ActionButtonsVisible', 'VCL.ActionButtonsReady', 'VCL.ActionButtonsReadyKey',
                 'VCL.ActionButtonsCurrentKey', 'VCL.ActionButtonsStableLoaded'):
        try:
            win.clearProperty(prop)
        except Exception:
            pass


SMART_STILL_SECONDS = 10.0  # плитка «Для вас» - через 10 с после остановки (владелец 26.11.2026)
ACTION_BUTTONS_DELAY = 5.0


_SMART_FOCUS = {'key': None, 'since': 0.0}
_SMART_PATH_CONTROLS = ('549', '690', '692', '693', '694', '695', '696')


def _update_smart_still(win):
    """Фокус стоит на месте SMART_STILL_SECONDS - по ряду, между рядами и категориями, по категориям
    (владелец 25.11.2026). Пишет Sublime.SmartStillId/Label - где стоял фокус: разметка показывает плитку
    «Для вас», только пока фокус там же, и уводит её в том же кадре, когда фокус сдвинулся (такт службы
    для этого слишком редкий). Выезд - через SMART_STILL_SECONDS после остановки."""
    try:
        cid = xbmc.getInfoLabel('System.CurrentControlID')
        label = xbmc.getInfoLabel('System.CurrentControl')
    except Exception:
        return
    # кнопки действий и сама плитка - не движение: путь ряд -> кнопки -> плитка не прячет её и не
    # начинает отсчёт заново (иначе до плитки было не дойти: «вниз» к кнопкам её убирал)
    if cid in _SMART_PATH_CONTROLS:
        return
    key = '%s|%s' % (cid, label)
    now = time.time()
    if key != _SMART_FOCUS['key']:
        _SMART_FOCUS['key'] = key
        _SMART_FOCUS['since'] = now
    still = now - _SMART_FOCUS['since'] >= SMART_STILL_SECONDS
    try:
        if still:
            if win.getProperty('Sublime.SmartStillId') != cid:
                win.setProperty('Sublime.SmartStillId', cid)
            if win.getProperty('Sublime.SmartStillLabel') != label:
                win.setProperty('Sublime.SmartStillLabel', label)
        _set_smart_still(win, still)
    except Exception:
        pass


def _set_smart_still(win, still):
    """Window(Home).Property(Sublime.SmartStill): фокус стоит на месте - показывать плитку «Для вас»
    (Includes_Hubs.xml, Hub_SmartStrip). Пишется только при смене значения."""
    want = 'true' if still else ''
    try:
        if win.getProperty('Sublime.SmartStill') != want:
            if want:
                win.setProperty('Sublime.SmartStill', want)
            else:
                win.clearProperty('Sublime.SmartStill')
    except Exception:
        pass


def _action_buttons_searchbar_inactive():
    try:
        return xbmc.getCondVisibility(
            'String.IsEmpty(Window(Home).Property(HomeSwitcher.IsVisible)) + '
            '!Control.HasFocus(300) + !Control.HasFocus(303) + !Control.HasFocus(308) + '
            '!Control.HasFocus(9300) + !Control.HasFocus(9311)'
        )
    except Exception:
        return False


def _action_buttons_widget_loaded(row_id):
    try:
        row_id = int(row_id or 0)
    except Exception:
        row_id = 0
    if row_id < 501 or row_id > 550:
        return False
    try:
        if xbmc.getCondVisibility('Container(%d).IsUpdating' % row_id):
            return False
        if xbmc.getCondVisibility('Integer.IsEqual(Container(%d).NumItems,0)' % row_id):
            return False
        if xbmc.getCondVisibility(
                'Integer.IsEqual(Container(%d).NumItems,1) + '
                'String.IsEqual(Container(%d).ListItemAbsolute(0).Label,$LOCALIZE[31046])'
                % (row_id, row_id)):
            return False
        # Some Kodi builds can briefly return an empty InfoLabel while the container is
        # being rebuilt even when the condition parser has not flipped IsUpdating yet.
        label = read_label('Container(%d).ListItemAbsolute(0).Label' % row_id) or ''
        path = read_label('Container(%d).ListItemAbsolute(0).FileNameAndPath' % row_id) or ''
        folder = read_label('Container(%d).ListItemAbsolute(0).FolderPath' % row_id) or ''
        if not label and not path and not folder:
            return False
        return True
    except Exception:
        return False


_SHORTCUT_REBUILD_MARKER = 'VCL.ShortcutsBuilt'
_SHORTCUT_REBUILD_STAMP = 'VCL.ShortcutsRebuildStamp'
_SHORTCUT_REBUILD_VERSION = 'VCL.ShortcutsBuildVersion'
_SHORTCUT_REBUILD_MIN_INTERVAL = 30.0
_SHORTCUT_REBUILD_STABLE_DELAY = 4.0
_SHORTCUT_REBUILD_TIMEOUT = 120.0
_SHORTCUT_RELOAD_IDLE_SECONDS = 2
_SHORTCUT_REBUILD_STATE_FILE = 'special://profile/addon_data/skin.sublime/shortcuts_rebuild_state.json'
_SHORTCUT_GENERATED_BACKUP_DIR = 'special://profile/addon_data/skin.sublime/generated_includes'
_SHORTCUT_REBUILD_STATE_CACHE = None
_SHORTCUT_LAYOUT_CHECK_INTERVAL = 60.0
_SHORTCUT_PLACEHOLDER_GRACE = 8.0


def _shortcut_rebuild_state_path():
    try:
        return _translate_path(_SHORTCUT_REBUILD_STATE_FILE)
    except Exception:
        return ''


def _load_shortcut_rebuild_state():
    global _SHORTCUT_REBUILD_STATE_CACHE
    if _SHORTCUT_REBUILD_STATE_CACHE is not None:
        return copy.deepcopy(_SHORTCUT_REBUILD_STATE_CACHE)
    try:
        path = _shortcut_rebuild_state_path()
        if not path or not os.path.exists(path):
            _SHORTCUT_REBUILD_STATE_CACHE = {}
            return {}
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        _SHORTCUT_REBUILD_STATE_CACHE = data if isinstance(data, dict) else {}
    except Exception:
        _SHORTCUT_REBUILD_STATE_CACHE = {}
    return copy.deepcopy(_SHORTCUT_REBUILD_STATE_CACHE)


def _save_shortcut_rebuild_state(state):
    global _SHORTCUT_REBUILD_STATE_CACHE
    _SHORTCUT_REBUILD_STATE_CACHE = copy.deepcopy(state or {})
    try:
        path = _shortcut_rebuild_state_path()
        if not path:
            return
        folder = os.path.dirname(path)
        if folder and not os.path.exists(folder):
            os.makedirs(folder)
        tmp = '%s.tmp' % path
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(state or {}, fh, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(tmp, path)
    except Exception as exc:
        log('shortcut rebuild state save failed: %s' % exc, xbmc.LOGWARNING)


def _skin_string(name):
    try:
        return read_label('Skin.String(%s)' % name) or ''
    except Exception:
        return ''


def _skin_has(name):
    try:
        return xbmc.getCondVisibility('Skin.HasSetting(%s)' % name)
    except Exception:
        return False


def _skin_set_bool(name):
    try:
        xbmc.executebuiltin('Skin.SetBool(%s)' % name)
    except Exception:
        pass


def _skin_set_string(name, value):
    try:
        safe = (value or '').replace(',', '_').replace(')', '_').replace('(', '_')
        xbmc.executebuiltin('Skin.SetString(%s,%s)' % (name, safe))
    except Exception:
        pass


def _shortcut_rebuild_block_reason(for_reload=False):
    try:
        if xbmc.getCondVisibility('Player.HasMedia'):
            return 'Player.HasMedia'
        if xbmc.getCondVisibility(
                'Window.IsVisible(videoosd) | Window.IsVisible(pvrosdchannels) | '
                'Window.IsVisible(pvrosdguide) | Window.IsVisible(1105) | '
                'Window.IsVisible(1131) | Window.IsVisible(12005)'):
            return 'OSD/popup/search_visible'
        if xbmc.getCondVisibility(
                'Window.IsActive(virtualkeyboard) | Window.IsActive(yesnodialog) | '
                'Window.IsActive(okdialog) | Window.IsActive(selectdialog) | '
                'Window.IsActive(progressdialog)'):
            return 'modal_dialog_visible'
        if for_reload and xbmc.getCondVisibility(
                'Window.IsVisible(1109) | Window.IsVisible(1115) | '
                'Window.IsVisible(1118) | Window.IsVisible(1119) | '
                'Window.IsVisible(1124) | Window.IsVisible(skinsettings) | '
                'Window.IsVisible(settings)'):
            # Перезагрузка скина посреди настроек выбросила бы владельца на
            # домашний экран прямо во время правки. Ждём, пока он выйдет:
            # 1109 - экран настроек скина, 1115 - редактор виджетов,
            # 1118/1119 - его диалоги, 1124 - настройки ярлыка.
            return 'settings_or_editor_visible'
        if for_reload and not xbmc.getCondVisibility(
                'System.IdleTime(%d)' % _SHORTCUT_RELOAD_IDLE_SECONDS):
            return 'input_not_idle'
    except Exception:
        return 'visibility_check_exception'
    return ''


def _parse_shortcuts_stamp_to_ts(stamp):
    try:
        import datetime
        stamp = stamp or ''
        if len(stamp) != 19 or stamp[4] != '-' or stamp[7] != '-' or stamp[10] != '_' or stamp[13] != ':' or stamp[16] != ':':
            return 0.0
        dt = datetime.datetime.strptime(stamp, '%Y-%m-%d_%H:%M:%S')
        return time.mktime(dt.timetuple())
    except Exception:
        return 0.0


def _generated_shortcuts_base():
    skin_path = _translate_path('special://home/addons/%s' % TARGET_ID)
    return os.path.join(skin_path, '1080i')


def _active_generated_shortcuts_path():
    try:
        skin_user = (
            read_label('Skin.String(VCLVariables.SkinUser)')
            or read_label('Skin.String(SkinVariables.SkinUser)')
            or ''
        )
    except Exception:
        skin_user = ''
    name = 'vclvariables-generator-includes-%s.xml' % skin_user
    return os.path.join(_generated_shortcuts_base(), name)


def _generated_shortcuts_candidates():
    try:
        base = _generated_shortcuts_base()
        active = _active_generated_shortcuts_path()
        paths = [active]
        default = os.path.join(base, 'vclvariables-generator-includes-.xml')
        if default not in paths:
            paths.append(default)
        try:
            for name in sorted(os.listdir(base)):
                if name.startswith('vclvariables-generator-includes-') and name.endswith('.xml'):
                    path = os.path.join(base, name)
                    if path not in paths:
                        paths.append(path)
        except Exception:
            pass
        return paths
    except Exception:
        return []


def _file_signature(path):
    try:
        if not path or not os.path.exists(path):
            return {'exists': False, 'mtime_ns': 0, 'size': 0, 'sha256': ''}
        stat = os.stat(path)
        digest = hashlib.sha256()
        with open(path, 'rb') as fh:
            for chunk in iter(lambda: fh.read(1024 * 1024), b''):
                digest.update(chunk)
        return {
            'exists': True,
            'mtime_ns': int(getattr(stat, 'st_mtime_ns', int(stat.st_mtime * 1000000000))),
            'size': int(stat.st_size),
            'sha256': digest.hexdigest(),
        }
    except Exception:
        return {'exists': False, 'mtime_ns': 0, 'size': 0, 'sha256': ''}


def _shortcut_inputs_signature(force=False):
    """Hash only persistent shortcut inputs, not volatile dialog timestamps."""
    now_ts = time.time()
    cached_at = getattr(_shortcut_inputs_signature, '_cached_at', 0.0)
    if not force and now_ts - cached_at < 2.0:
        return getattr(_shortcut_inputs_signature, '_cached_value', '')
    roots = (
        _translate_path('special://profile/addon_data/skin.sublime/nodes'),
        _translate_path('special://profile/addon_data/skin.sublime/viewtypes.json'),
    )
    digest = hashlib.sha256()
    found = False
    for root in roots:
        if not root:
            continue
        if os.path.isfile(root):
            paths = [root]
            base = os.path.dirname(root)
        elif os.path.isdir(root):
            paths = []
            base = root
            for current_root, dirs, files in os.walk(root):
                dirs[:] = sorted(d for d in dirs if not d.startswith('.'))
                for name in sorted(files):
                    if name.startswith('.') or name.endswith(('.tmp', '.bak', '.lock')):
                        continue
                    paths.append(os.path.join(current_root, name))
        else:
            continue
        for path in paths:
            try:
                rel = os.path.relpath(path, base).replace(os.sep, '/')
                digest.update(rel.encode('utf-8', 'ignore'))
                with open(path, 'rb') as fh:
                    for chunk in iter(lambda: fh.read(256 * 1024), b''):
                        digest.update(chunk)
                found = True
            except Exception:
                continue
    value = digest.hexdigest() if found else 'empty'
    _shortcut_inputs_signature._cached_at = now_ts
    _shortcut_inputs_signature._cached_value = value
    return value


def _generated_layout_state_for_path(path):
    try:
        if not path or not os.path.exists(path):
            return 'generated_missing'
        text = _read_text_file(path)
        if not text or not text.strip():
            return 'generated_empty'
        try:
            ET.fromstring(text)
        except Exception:
            return 'generated_invalid_xml'
        lowered = text.lower()
        if 'SublimeBundledGeneratedPlaceholder' in text:
            return 'generated_bundled_placeholder'
        if ('<include name="vclvariables-homewidgets-combined">' in text and
                '<visible>false</visible>' in text and
                'plugin://' not in text and 'pvr://channels/tv/' not in text):
            return 'generated_placeholder'
        if ('vclvariables-homewidgets-combined' in text and '<container' not in lowered and
                'plugin://' not in text and 'pvr://' not in text):
            return 'generated_no_containers'
        return ''
    except Exception as exc:
        log('generated layout validation failed for %s: %s' % (path, exc), xbmc.LOGWARNING)
        return 'generated_validation_exception'


def _generated_backup_base():
    try:
        return _translate_path(_SHORTCUT_GENERATED_BACKUP_DIR)
    except Exception:
        return ''


def _atomic_copy_file(source, target):
    """Copy one generated include atomically, including an fsync before replace."""
    try:
        if not source or not target or not os.path.isfile(source):
            return False
        folder = os.path.dirname(target)
        if folder:
            os.makedirs(folder, exist_ok=True)
        tmp = '%s.tmp.%s.%s' % (target, os.getpid(), threading.get_ident())
        try:
            with open(source, 'rb') as src, open(tmp, 'wb') as dst:
                shutil.copyfileobj(src, dst, 1024 * 1024)
                dst.flush()
                os.fsync(dst.fileno())
            os.replace(tmp, target)
            return True
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
    except Exception as exc:
        log('generated include atomic copy failed: %s -> %s: %s' % (
            source, target, exc), xbmc.LOGWARNING)
        return False


_BACKUP_CHECKED = {}


def _backup_valid_generated_shortcuts():
    """Persist generated menus outside the replaceable addon directory."""
    backup_base = _generated_backup_base()
    if not backup_base:
        return 0
    copied = 0
    for source in _generated_shortcuts_candidates():
        try:
            name = os.path.basename(source)
            if not name.startswith('vclvariables-generator-includes-') or not name.endswith('.xml'):
                continue
            target = os.path.join(backup_base, name)
            # пара файлов не менялась с прошлой сверки - разбор и sha256 обоих не нужны
            # (служба зовёт это раз в 3 с, и при просмотре тоже)
            tokens = (_file_stat_token(source), _file_stat_token(target))
            if _BACKUP_CHECKED.get(source) == tokens:
                continue
            if _generated_layout_state_for_path(source):
                continue
            source_sig = _file_signature(source)
            target_sig = _file_signature(target)
            if (target_sig.get('exists') and
                    source_sig.get('sha256') == target_sig.get('sha256')):
                _BACKUP_CHECKED[source] = tokens
                continue
            if _atomic_copy_file(source, target):
                copied += 1
                _BACKUP_CHECKED[source] = (_file_stat_token(source), _file_stat_token(target))
        except Exception:
            continue
    return copied


def _restore_generated_shortcuts_backup_if_needed():
    """Restore the exact active generated include before Home opens its first hub."""
    target = _active_generated_shortcuts_path()
    current_state = _generated_layout_state_for_path(target)
    if not current_state:
        return False
    backup = os.path.join(_generated_backup_base(), os.path.basename(target))
    if _generated_layout_state_for_path(backup):
        return False
    if not _atomic_copy_file(backup, target):
        return False
    for attr in ('_path', '_stat_token', '_checked_at', '_state'):
        try:
            delattr(_generated_shortcuts_layout_state, attr)
        except Exception:
            pass
    if _generated_layout_state_for_path(target):
        return False
    state = _load_shortcut_rebuild_state()
    state.update({
        'pending': False,
        'pending_reload': False,
        'built_marker': _SHORTCUT_REBUILD_MARKER,
        'build': BUILD,
        'last_success_at': int(time.time()),
        'last_success_reason': 'restored_generated_backup',
        'last_success_path': target,
        'last_error': '',
    })
    for key in (
            'pending_started_at', 'pending_target_stamp', 'pending_reason',
            'pending_path', 'pending_signature', 'attempt_build',
            'placeholder_observation', 'reload_reason', 'reload_requested_at',
            'retry_after'):
        state.pop(key, None)
    _skin_set_bool(_SHORTCUT_REBUILD_MARKER)
    _skin_set_string(_SHORTCUT_REBUILD_VERSION, BUILD)
    _save_shortcut_rebuild_state(state)
    # This restore is documented as running "before Home opens its first hub",
    # and when it does, no reload is needed. It cannot be relied on: measured on
    # 2026-08-15, the restore logged at 22:28:18 on an already-loaded skin, so
    # Kodi had parsed the bundled placeholder and Home came up with no menu and
    # no widgets until a manual ReloadSkin. Queue the skin's own recovery reload
    # so a late restore repairs itself instead of leaving an empty screen. The
    # install procedure additionally restores this file before Kodi starts (see
    # docs/OPERATIONS.md), which is what keeps the normal deploy flash-free -
    # this is the safety net for every other install path.
    try:
        _set_reload_pending(state, 'shortcuts_recovery_restored_backup', time.time())
    except Exception as exc:
        log('reload request after generated-include restore failed: %s' % exc, xbmc.LOGWARNING)
    return True


def _file_stat_token(path):
    try:
        stat = os.stat(path)
        return (
            int(getattr(stat, 'st_mtime_ns', int(stat.st_mtime * 1000000000))),
            int(stat.st_size),
        )
    except OSError:
        return (0, 0)


def _generated_shortcuts_layout_state(now_ts=None, force=False):
    active = _active_generated_shortcuts_path()
    now_ts = time.time() if now_ts is None else float(now_ts)
    stat_token = _file_stat_token(active)
    cached_path = getattr(_generated_shortcuts_layout_state, '_path', '')
    cached_token = getattr(_generated_shortcuts_layout_state, '_stat_token', None)
    cached_at = getattr(_generated_shortcuts_layout_state, '_checked_at', 0.0)
    if (not force and active == cached_path and stat_token == cached_token and
            now_ts - cached_at < _SHORTCUT_LAYOUT_CHECK_INTERVAL):
        return getattr(_generated_shortcuts_layout_state, '_state', '')
    state = _generated_layout_state_for_path(active)
    _generated_shortcuts_layout_state._path = active
    _generated_shortcuts_layout_state._stat_token = stat_token
    _generated_shortcuts_layout_state._checked_at = now_ts
    _generated_shortcuts_layout_state._state = state
    return state


def _shortcut_stamp_already_materialized(stamp):
    ts = _parse_shortcuts_stamp_to_ts(stamp)
    if not ts:
        return False
    active = _active_generated_shortcuts_path()
    try:
        return not _generated_layout_state_for_path(active) and os.path.getmtime(active) >= (ts - 2.0)
    except OSError:
        return False


def _set_reload_pending(state, reason, now_ts):
    """Queue reload for first-start recovery or an explicit user change.

    07.09.2026: сюда добавлен `shortcuts_user` - правка виджетов домашнего
    экрана. До этого она сюда не попадала вовсе: служба ставила свойство
    `VCL.SkinReloadRequired`, которое НИКТО не читает (ни разметка, ни код), и
    новая раскладка подхватывалась только при следующей загрузке скина. Со
    стороны владельца это выглядело как «пишет, что генерирует, а виджеты
    меняются только после перезагрузки».
    """
    reason = reason or 'shortcuts_recovery'
    if not (reason.startswith('shortcuts_recovery_') or reason in ('viewtypes_user', 'shortcuts_user')):
        state['pending_reload'] = False
        _save_shortcut_rebuild_state(state)
        return
    state['pending_reload'] = True
    state['reload_reason'] = reason
    state['reload_requested_at'] = int(now_ts)
    _save_shortcut_rebuild_state(state)
    try:
        win = _home_window()
        win.setProperty('VCL.ShortcutsReloadPending', 'true')
        win.setProperty('VCL.ShortcutsReloadReason', reason)
    except Exception:
        pass


def _maybe_safe_skin_reload(now_ts, state):
    try:
        win = _home_window()
        property_pending = bool(win.getProperty('VCL.ShortcutsReloadPending'))
        pending = bool(state.get('pending_reload')) or property_pending
        if not pending:
            return False
        reason = win.getProperty('VCL.ShortcutsReloadReason') or state.get('reload_reason') or 'vcl'
        allowed_reload = (reason.startswith('shortcuts_recovery_')
                          or reason in ('viewtypes_user', 'shortcuts_user'))
        if not allowed_reload:
            state['pending_reload'] = False
            state['last_reload_suppressed_reason'] = reason
            _save_shortcut_rebuild_state(state)
            win.clearProperty('VCL.ShortcutsReloadPending')
            win.clearProperty('VCL.ShortcutsReloadReason')
            win.clearProperty('VCL.ShortcutsReloadRequestedAt')
            log('automatic ReloadSkin suppressed: reason=%s' % reason)
            return False
        if _shortcut_rebuild_block_reason(for_reload=True):
            return False
        requested = float(
            win.getProperty('VCL.ShortcutsReloadRequestedAt')
            or state.get('reload_requested_at')
            or 0
        )
        stable_delay = 0.0 if reason == 'viewtypes_user' else _SHORTCUT_REBUILD_STABLE_DELAY
        if requested and now_ts - requested < stable_delay:
            return False
        state['pending_reload'] = False
        state['last_reload_at'] = int(now_ts)
        state['last_reload_reason'] = reason
        _save_shortcut_rebuild_state(state)
        win.clearProperty('VCL.ShortcutsReloadPending')
        win.clearProperty('VCL.ShortcutsReloadReason')
        win.clearProperty('VCL.ShortcutsReloadRequestedAt')
        win.clearProperty('VCL.SkinReloadRequired')
        win.clearProperty('VCL.SkinReloadReason')
        log('safe ReloadSkin: reason=%s' % reason)
        xbmc.executebuiltin('ReloadSkin()')
        return True
    except Exception as exc:
        log('safe ReloadSkin failed: %s' % exc, xbmc.LOGWARNING)
        return False


def _wait_after_skin_reload(mon):
    """Дождаться, пока ReloadSkin() отработает и окна хаба появятся снова.

    Сначала - пока Kodi начнёт выгрузку (окно перестаёт быть видимым), затем -
    пока главный экран снова виден, и короткая пауза сверху: как при старте
    службы, только без 12 секунд - кэши уже прогреты.
    """
    for _ in range(30):
        if mon.waitForAbort(0.1):
            return
        try:
            if not xbmc.getCondVisibility(_STARTUP_READY_WINDOWS):
                break
        except Exception:
            break
    for _ in range(200):
        if mon.abortRequested():
            return
        try:
            if xbmc.getCondVisibility(_STARTUP_READY_WINDOWS):
                break
        except Exception:
            pass
        mon.waitForAbort(0.1)
    mon.waitForAbort(1.5)
    log('skin reload finished, service resumed')


def _include_misses_nodes():
    """Вкладки хабов из узлов (nodes/*widgets.json), которых нет в готовом меню.

    17.11.2026 на .20: установщик выбрал HDRezka и записал её вкладки в узлы, а на экране
    осталось меню Filmix - новая версия скина сочла прежнее готовое меню годным и отметила
    перестройку выполненной. Сверка по содержимому ловит любой такой путь, а не один."""
    import glob
    from urllib.parse import quote
    try:
        with open(_active_generated_shortcuts_path(), encoding='utf-8', errors='replace') as fh:
            text = fh.read().replace('&amp;', '&')
    except Exception:
        return []
    base = xbmcvfs.translatePath('special://profile/addon_data/skin.sublime/nodes/skin.sublime/')
    missing = []
    for name in glob.glob(os.path.join(base, 'vclvariables-shortcut-*widgets.json')):
        try:
            with open(name, encoding='utf-8') as fh:
                tabs = json.load(fh)
        except Exception:
            continue
        for tab in tabs if isinstance(tabs, list) else ():
            path = str((tab or {}).get('path') or '').strip().replace('&amp;', '&')
            if not path.startswith('plugin://') or str(tab.get('disabled') or '').lower() == 'true':
                continue
            if path not in text and quote(path, safe='') not in text:
                missing.append(path)
    return missing


def _rebuild_changed_and_valid(state):
    path = state.get('pending_path') or _active_generated_shortcuts_path()
    current = _file_signature(path)
    previous = state.get('pending_signature') or {}
    changed = bool(current.get('exists')) and (
        current.get('sha256') != previous.get('sha256')
        or current.get('mtime_ns') != previous.get('mtime_ns')
        or current.get('size') != previous.get('size')
    )
    return changed and not _generated_layout_state_for_path(path)


def _complete_pending_rebuild(now_ts, state):
    if not state.get('pending'):
        return False
    if _rebuild_changed_and_valid(state):
        target_stamp = state.get('pending_target_stamp') or ('version_%s' % BUILD)
        reason = state.get('pending_reason') or 'shortcuts'
        state.update({
            'pending': False,
            'built_marker': _SHORTCUT_REBUILD_MARKER,
            'applied_stamp': target_stamp,
            'last_success_at': int(now_ts),
            'last_success_reason': reason,
            'last_success_path': state.get('pending_path') or _active_generated_shortcuts_path(),
            'last_error': '',
            'build': BUILD,
            'input_signature': _shortcut_inputs_signature(force=True),
        })
        for key in ('pending_started_at', 'pending_target_stamp', 'pending_reason', 'pending_path', 'pending_signature', 'attempt_build', 'placeholder_observation'):
            state.pop(key, None)
        _skin_set_bool(_SHORTCUT_REBUILD_MARKER)
        _skin_set_string(_SHORTCUT_REBUILD_STAMP, target_stamp)
        _skin_set_string(_SHORTCUT_REBUILD_VERSION, BUILD)
        _backup_valid_generated_shortcuts()
        if str(reason).startswith('generated_'):
            # Kodi parsed the placeholder/invalid include at skin load. Reload only
            # after the replacement file has changed and validated successfully.
            _set_reload_pending(state, 'shortcuts_recovery_%s' % reason, now_ts)
        elif str(reason) == 'dirty':
            # Владелец сам поменял виджеты (сменился Shortcuts.RebuildDateTime).
            # Kodi читает включения только при загрузке скина, поэтому без
            # перезагрузки новая раскладка на экран не попадёт - и раньше не
            # попадала до перезапуска. Заявку ставим здесь; когда её исполнить,
            # решает _maybe_safe_skin_reload: не во время воспроизведения, не
            # при открытых диалогах и настройках и только после двух секунд
            # покоя пульта.
            try:
                win = _home_window()
                win.setProperty('VCL.SkinReloadRequired', 'true')
                win.setProperty('VCL.SkinReloadReason', 'shortcuts_%s' % reason)
            except Exception:
                pass
            _set_reload_pending(state, 'shortcuts_user', now_ts)
        else:
            state['pending_reload'] = False
            _save_shortcut_rebuild_state(state)
            try:
                win = _home_window()
                win.setProperty('VCL.SkinReloadRequired', 'true')
                win.setProperty('VCL.SkinReloadReason', 'shortcuts_%s' % reason)
            except Exception:
                pass
        log('shortcuts rebuild verified: reason=%s stamp=%s' % (reason, target_stamp))
        return True
    started = float(state.get('pending_started_at') or 0)
    if started and now_ts - started >= _SHORTCUT_REBUILD_TIMEOUT:
        state['pending'] = False
        state['last_error'] = 'generation_timeout_or_invalid_output'
        state['last_error_at'] = int(now_ts)
        state['retry_after'] = int(now_ts + _SHORTCUT_REBUILD_MIN_INTERVAL)
        for key in ('pending_started_at', 'pending_target_stamp', 'pending_reason', 'pending_path', 'pending_signature', 'attempt_build'):
            state.pop(key, None)
        _save_shortcut_rebuild_state(state)
        log('shortcuts rebuild timed out; output was unchanged or invalid', xbmc.LOGWARNING)
    return False


def _launch_shortcuts_rebuild(now_ts, state, reason, target_stamp, layout_state):
    path = _active_generated_shortcuts_path()
    state.update({
        'pending': True,
        'pending_started_at': float(now_ts),
        'pending_target_stamp': target_stamp,
        'pending_reason': reason,
        'pending_path': path,
        'pending_signature': _file_signature(path),
        'last_attempt_at': int(now_ts),
        'last_attempt_reason': reason,
        'last_attempt_stamp': target_stamp,
        'layout_state': layout_state,
        'attempt_build': BUILD,
    })
    _save_shortcut_rebuild_state(state)
    force_build = bool(layout_state)
    args = [
        'action=buildtemplate',
        'background=true',
        'no_reload=true',
        'force=%s' % ('true' if force_build else 'false'),
        'inputsignature=%s' % _shortcut_inputs_signature(force=True),
        'lastbuildtime=%s' % (target_stamp or ''),
        'sublime_build=%s' % BUILD,
    ]
    quoted = ','.join('"%s"' % str(arg).replace('"', '\\"') for arg in args)
    log('launching controlled shortcuts rebuild: reason=%s stamp=%s layout_state=%s' % (
        reason, target_stamp, layout_state))
    xbmc.executebuiltin('RunScript(%s,%s)' % (TARGET_ID, quoted))


def _maybe_controlled_shortcuts_rebuild(now_ts):
    if not _target_skin_active():
        return
    try:
        state = _load_shortcut_rebuild_state()
        if _maybe_safe_skin_reload(now_ts, state):
            return True
        if state.get('pending'):
            _complete_pending_rebuild(now_ts, state)
            return
        if now_ts < float(state.get('retry_after') or 0):
            return

        requested_stamp = _skin_string('Shortcuts.RebuildDateTime')
        applied_stamp = _skin_string(_SHORTCUT_REBUILD_STAMP) or state.get('applied_stamp', '')
        layout_state = _generated_shortcuts_layout_state(now_ts)
        if not layout_state:
            missing = _include_misses_nodes()
            inputs = _shortcut_inputs_signature(force=True)
            tried = state.get('nodes_mismatch_tried')
            tried = tried if isinstance(tried, dict) else {}
            if tried.get('sig') != inputs:
                tried = {'sig': inputs, 'n': 0, 'at': 0}
            # до трёх принудительных попыток на набор узлов, не чаще раза в 5 минут: попытку мог
            # оборвать перезапуск Kodi (установщик), а бесконечного круга быть не должно, если
            # какой-то путь генератор в меню не переносит
            if missing and tried['n'] < 3 and now_ts - float(tried.get('at') or 0) >= 300:
                tried.update(n=tried['n'] + 1, at=int(now_ts))
                state['nodes_mismatch_tried'] = tried
                _save_shortcut_rebuild_state(state)
                log('готовое меню не совпадает с узлами (нет %d вкладок, напр. %s) - перестраиваю'
                    % (len(missing), missing[0][:100]), xbmc.LOGWARNING)
                layout_state = 'nodes_mismatch'
        if not layout_state:
            _backup_valid_generated_shortcuts()
        built = bool(
            _skin_has(_SHORTCUT_REBUILD_MARKER)
            or state.get('built_marker') == _SHORTCUT_REBUILD_MARKER
        )

        # A valid generated include remains valid across Sublime patch versions.
        # Migrate/create markers in place instead of rebuilding/reloading the Home screen.
        if not layout_state and (not built or state.get('build') != BUILD):
            # Перенос отметок на новую версию не должен гасить запрошенную перестройку: после
            # установщика (новый скин + новые вкладки + новая отметка Shortcuts.RebuildDateTime)
            # отметка считалась выполненной, а отпечаток - снятым с новых вкладок, и на экране
            # оставалось меню прежнего источника.
            pending_request = bool(requested_stamp and requested_stamp != applied_stamp)
            state.update({
                'build': BUILD,
                'built_marker': _SHORTCUT_REBUILD_MARKER,
                'applied_stamp': applied_stamp or ('' if pending_request else requested_stamp)
                                 or ('existing_%s' % BUILD),
                'last_success_reason': 'valid_existing_generated',
                'last_success_at': int(now_ts),
            })
            if not pending_request:
                state['input_signature'] = _shortcut_inputs_signature(force=True)
            _skin_set_bool(_SHORTCUT_REBUILD_MARKER)
            _skin_set_string(_SHORTCUT_REBUILD_VERSION, BUILD)
            if state.get('applied_stamp'):
                _skin_set_string(_SHORTCUT_REBUILD_STAMP, state.get('applied_stamp'))
            _save_shortcut_rebuild_state(state)
            built = True
            applied_stamp = state.get('applied_stamp', applied_stamp)

        if layout_state == 'generated_placeholder':
            # A generator can expose a placeholder-like file briefly while replacing
            # it. Observe the exact signature first; recover only when the same file
            # remains unchanged beyond the grace period.
            signature = _file_signature(_active_generated_shortcuts_path())
            token = '%s:%s:%s' % (
                signature.get('sha256') or '', signature.get('size') or 0,
                signature.get('mtime_ns') or 0)
            observed = state.get('placeholder_observation') or {}
            if observed.get('token') != token:
                state['placeholder_observation'] = {
                    'token': token,
                    'first_seen': float(now_ts),
                    'path': _active_generated_shortcuts_path(),
                }
                _save_shortcut_rebuild_state(state)
                return
            if now_ts - float(observed.get('first_seen') or now_ts) < _SHORTCUT_PLACEHOLDER_GRACE:
                return
        elif state.pop('placeholder_observation', None) is not None:
            _save_shortcut_rebuild_state(state)
        if layout_state:
            reason = layout_state
            target_stamp = '%s_%s' % (layout_state, BUILD)
        elif requested_stamp and requested_stamp != applied_stamp:
            current_inputs = _shortcut_inputs_signature(force=True)
            previous_inputs = state.get('input_signature') or ''
            if previous_inputs and current_inputs == previous_inputs:
                state.update({
                    'built_marker': _SHORTCUT_REBUILD_MARKER,
                    'applied_stamp': requested_stamp,
                    'last_success_reason': 'dirty_timestamp_only_suppressed',
                    'last_success_at': int(now_ts),
                    'build': BUILD,
                    'input_signature': current_inputs,
                })
                _skin_set_bool(_SHORTCUT_REBUILD_MARKER)
                _skin_set_string(_SHORTCUT_REBUILD_STAMP, requested_stamp)
                _skin_set_string(_SHORTCUT_REBUILD_VERSION, BUILD)
                _save_shortcut_rebuild_state(state)
                log('shortcuts rebuild suppressed: timestamp changed but node inputs are unchanged')
                return
            if _shortcut_stamp_already_materialized(requested_stamp):
                state.update({
                    'built_marker': _SHORTCUT_REBUILD_MARKER,
                    'applied_stamp': requested_stamp,
                    'last_success_reason': 'dirty_already_materialized',
                    'last_success_at': int(now_ts),
                    'build': BUILD,
                    'input_signature': current_inputs,
                })
                _skin_set_bool(_SHORTCUT_REBUILD_MARKER)
                _skin_set_string(_SHORTCUT_REBUILD_STAMP, requested_stamp)
                _skin_set_string(_SHORTCUT_REBUILD_VERSION, BUILD)
                _save_shortcut_rebuild_state(state)
                return
            reason = 'dirty'
            target_stamp = requested_stamp
        else:
            return

        last_seen = getattr(_maybe_controlled_shortcuts_rebuild, '_last_seen_stamp', None)
        last_seen_time = getattr(_maybe_controlled_shortcuts_rebuild, '_last_seen_time', 0.0)
        if target_stamp != last_seen:
            _maybe_controlled_shortcuts_rebuild._last_seen_stamp = target_stamp
            _maybe_controlled_shortcuts_rebuild._last_seen_time = now_ts
            return
        if now_ts - last_seen_time < _SHORTCUT_REBUILD_STABLE_DELAY:
            return
        if now_ts - float(state.get('last_attempt_at') or 0) < _SHORTCUT_REBUILD_MIN_INTERVAL:
            return
        if _shortcut_rebuild_block_reason():
            return
        _launch_shortcuts_rebuild(now_ts, state, reason, target_stamp, layout_state)
    except Exception as exc:
        log('controlled shortcuts rebuild failed: %s' % exc, xbmc.LOGWARNING)


def monitor_action_buttons(mon, base=None):
    win = _home_window()
    _clear_studio_logo_props(win)
    last_key = ''
    last_time = 0.0
    loaded_key = ''
    loaded_since = 0.0
    loaded_delay = 1.20
    shortcuts_check_next = 0.0
    player_sync_next = 0.0
    player_had_video = bool(xbmc.getCondVisibility('Player.HasVideo'))
    playback_source_window = ''
    playback_source_row = 0
    playback_return_guard_until = 0.0
    playback_keepalive_until = 0.0
    playback_start_guard_until = 0.0
    playback_was_pvr = False
    last_observed_window = None
    last_observed_hub = ''
    last_view_path = ''
    last_ui_hub = ''
    last_ui_row = 0
    detail_key = ''
    detail_updated_at = 0.0
    metadata_probe_key = ''
    metadata_sync_at = 0.0
    poll_last_key = ''
    poll_changed_at = 0.0
    settled_key = ''
    widget_prewarm_key = ''
    widget_warm_row = 0
    widget_warm_next = 0
    widget_warm_at = 0.0
    widget_warm_key = ''
    widget_warm_done_at = 0.0
    fallback_wait_key = ''
    fallback_seen_key = ''
    fallback_seen_at = 0.0
    fallback_wait_until = 0.0
    widget_warm_progress = {}
    wash_fingerprint = None
    studio_probe_key = ''
    studio_updated_at = 0.0
    player_info_next = 0.0
    player_sync_key = ''
    player_sync_gap = 0.75
    _turn_t0 = 0.0
    _turn_marks = []
    row_changed_at = 0.0
    offhub_seen_at = 0.0
    offhub_cleared_at = 0.0
    while not mon.abortRequested():
        try:
            # One look at the GUI per turn, shared by everything below: the row
            # model, the fingerprint, the fallback publisher, the wash source.
            # See core.invalidate_labels.
            # Длительность такта считается ЗДЕСЬ, на входе в следующий, а не
            # в конце предыдущего. Причина замерена 05.09.2026 на .20: на полосе
            # PVR цикл уходит в `continue` раньше конца такта (ветка кнопок
            # действия, строка ~4553), поэтому запись в конце не выполнялась
            # НИ РАЗУ - при пороге даже в 200 мс в журнале не было ни строки,
            # хотя строка под курсором менялась раз в 1.1 с. Сверху такт
            # достижим всегда, и в счёт входит сон - то есть ровно то, с какой
            # частотой цикл вообще способен заметить смену строки.
            _turn_now = time.monotonic()
            if _turn_t0:
                _prev_ms = (_turn_now - _turn_t0 - _FULLSCREEN_SLEPT[0]) * 1000.0
                _FULLSCREEN_SLEPT[0] = 0.0
                _turn_stats_add(_prev_ms, _turn_marks)
                if _prev_ms >= SLOW_TURN_LOG_MS:
                    log('долгий такт %.0fмс: %s' % (_prev_ms, ' | '.join(
                        '%s %.0f' % (n, v) for n, v in _turn_marks)))
                if _turn_now >= _TURN_STATS['next_report']:
                    _turn_stats_report(_turn_now)
            # Отсчёт начинается ПОСЛЕ записи в журнал, а не до неё. Запись
            # блокирующая, и когда предыдущий такт оказывался долгим, её
            # полсекунды приписывались первой стадии следующего: в журнале
            # появлялись «метки 592» и «метки 415», хотя invalidate_labels -
            # это очистка словаря на микросекунды. Мерить надо работу, а не
            # собственную диагностику.
            _turn_t0 = time.monotonic()
            _turn_marks = []
            _mark = lambda name: _turn_marks.append(
                (name, (time.monotonic() - _turn_t0) * 1000.0))
            invalidate_labels()
            _mark('метки')
            if win.getProperty('Sublime.Hold'):
                # Пауза по просьбе дополнения: такт уступает Kodi, который в эти
                # секунды открывает поток и аппаратный декодер (10.10.2026 такт
                # 2,8 с совпал с открытием декодера 2,6 с вместо долей секунды).
                mon.waitForAbort(0.5)
                continue
            if not _target_skin_active():
                _clear_action_buttons(win)
                _clear_fallback_art(win, 'скин не активен')
                _clear_studio_logo_props(win)
                _clear_background_wash(win)
                metadata_probe_key = ''
                wash_fingerprint = None
                studio_probe_key = ''
                mon.waitForAbort(1.0)
                continue
            now_ts = time.time()
            # остановка фокуса для плитки «Для вас» - в начале такта: ниже у такта несколько ранних
            # выходов (простой, окна вне хаба), и на категориях он до конца не доходил (.20, 25.11.2026)
            _update_smart_still(win)
            player_has_video = bool(xbmc.getCondVisibility('Player.HasVideo'))
            try:
                current_window_id = int(xbmcgui.getCurrentWindowId())
            except Exception:
                current_window_id = 0
            source_hub_now = hub_from_window_id(current_window_id)
            if current_window_id == 10025:
                last_view_path = _apply_saved_view_on_folder_change(last_view_path)
            if current_window_id != last_observed_window:
                if _screen_of(current_window_id) != _screen_of(last_observed_window):
                    # Экран сменился - арт прошлого экрана снимаем целиком,
                    # включая слой-заглушку, лого студии и подложку. Наследовать
                    # его нельзя ни при каких условиях; новый экран опубликует
                    # своё на этом же такте.
                    _drop_inherited_art(win, 'экран %s -> %s'
                                        % (last_observed_window, current_window_id))
                    _clear_fallback_art(win, 'сменился экран')
                    _clear_studio_logo_props(win)
                    _clear_background_wash(win)
                    metadata_probe_key = ''
                    studio_probe_key = ''
                    wash_fingerprint = None
                last_observed_window = current_window_id
                if source_hub_now and source_hub_now != last_observed_hub:
                    _remember_last_hub(win, source_hub_now)
                    last_observed_hub = source_hub_now
            if not player_has_video and source_hub_now:
                last_ui_hub = source_hub_now
                focused_row = _focused_widget_row_cached(win)
                if 501 <= int(focused_row or 0) <= 550:
                    last_ui_row = int(focused_row)
            fullscreen_video = bool(xbmc.getCondVisibility(
                'Window.IsVisible(fullscreenvideo) | Window.IsVisible(videoosd) | '
                'Window.IsVisible(pvrosdchannels) | Window.IsVisible(pvrosdguide) | '
                'Window.IsVisible(12005)'))
            pvr_playback = bool(xbmc.getCondVisibility('Pvr.IsPlayingTV | Pvr.IsPlayingRadio'))
            if player_has_video and not player_had_video:
                stored_source = (
                    win.getProperty('VCL.Playback.SourceHubKey') or
                    win.getProperty('VCL.Playback.SourceHubRuntime')
                )
                playback_source_window = (
                    _normal_hub_window_id(stored_source) or last_ui_hub or source_hub_now)
                playback_source_row = int(
                    win.getProperty('VCL.Widget.KeepAliveRow') or last_ui_row or
                    _focused_widget_row_cached(win) or 0)
                _set_widget_keepalive(win, playback_source_window, playback_source_row)
                playback_was_pvr = pvr_playback
                playback_start_guard_until = now_ts + 2.0
                _clear_playback_navigation_transients(win)
                win.setProperty('VCL.PlaybackNavigationGuard', 'true')
                log('playback navigation guard start: source=%s row=%s pvr=%s' % (
                    playback_source_window or '-', playback_source_row or 0,
                    'yes' if playback_was_pvr else 'no'))
            elif not player_has_video and player_had_video:
                _clear_playback_navigation_transients(win)
                # Cancel transition callbacks once. Keep only the source row alive
                # while Kodi restores the custom hub; do not block fresh Up/Down.
                playback_return_guard_until = now_ts
                playback_keepalive_until = now_ts + 2.0
                win.clearProperty('VCL.PlaybackNavigationGuard')
                win.setProperty('VCL.Widget.KeepAliveReturning', 'true')
                # Отметка просмотра появляется здесь и сейчас, а не через
                # четверть часа - см. _refresh_after_playback.
                _refresh_after_playback(win, playback_source_row, playback_was_pvr)
                # Do not schedule a delayed SetFocus here. It can fire after the user
                # has already moved Up/Down and steal focus back to the old PVR row.
                log('playback navigation guard stop: source=%s visible=%s row=%s pvr=%s' % (
                    playback_source_window or '-',
                    'yes' if _hub_window_visible(playback_source_window) else 'no',
                    playback_source_row or 0,
                    'yes' if playback_was_pvr else 'no'))
            guard_active = bool(
                pvr_playback
                or (player_has_video and fullscreen_video)
                or now_ts < playback_start_guard_until
                or now_ts < playback_return_guard_until
            )
            if guard_active:
                # Transition-edge cleanup above is sufficient. Repeating it every
                # service tick cancels the user's first legitimate Up/Down after return.
                win.setProperty('VCL.PlaybackNavigationGuard', 'true')
            elif win.getProperty('VCL.PlaybackNavigationGuard'):
                win.clearProperty('VCL.PlaybackNavigationGuard')
            if not player_has_video and playback_keepalive_until and now_ts >= playback_keepalive_until:
                playback_keepalive_until = 0.0
                win.clearProperty('VCL.Widget.KeepAliveReturning')
                _clear_widget_keepalive(win)
                playback_source_window = ''
                playback_source_row = 0
                playback_was_pvr = False
                for prop in (
                        'VCL.Playback.SourceHubKey', 'VCL.Playback.SourceHubRuntime',
                        'VCL.PVRPopup.SourceHubRuntime'):
                    win.clearProperty(prop)
            if not player_has_video:
                _publish_context_kind(win)
            player_had_video = player_has_video

            _mark('окно/плеер')
            if now_ts >= shortcuts_check_next:
                reloading = _maybe_controlled_shortcuts_rebuild(now_ts)
                shortcuts_check_next = now_ts + 3.0
                _mark('ярлыки')
                if reloading:
                    # ReloadSkin() асинхронный: окна хаба удаляются и создаются
                    # заново уже после возврата. До их появления такт не трогает
                    # ни одного окна - иначе SIGSEGV в CGUIWindow::SetProperty.
                    _wait_after_skin_reload(mon)
                    continue
            if now_ts >= player_info_next:
                # Ничего не играет и свойства уже сняты - нечего делать: раньше каждую секунду
                # снимались одни и те же свойства (аудит 21.11.2026).
                playing = xbmc.getCondVisibility('Player.HasMedia')
                if playing or _PLAYER_PROPS_SET[0]:
                    _update_player_info_props(win)
                    _update_next_in_playlist(win)
                    _PLAYER_PROPS_SET[0] = playing
                player_info_next = now_ts + 1.00
                _mark('плеер-инфо')
            if now_ts >= player_sync_next:
                # Пока играет одно и то же - спрашиваем реже.
                #
                # Замер на .20 06.09.2026: стадия «плеер-свойства» стоит
                # 270-390 мс (в среднем 340) и вызывалась каждые 0.75 с, пока
                # идёт воспроизведение - то есть почти половину времени служба
                # занималась ею одной. Сперва я сложил метки о плеере в один
                # пакет вместо девятнадцати отдельных вопросов ();
                # это правильно само по себе, но времени не вернуло: столько
                # стоит ОДИН ответ Kodi о VideoPlayer.* во время
                # воспроизведения, а у PVR он идёт через клиент телегида.
                #
                # Значит спрашивать надо не быстрее, а реже. Пока отпечаток тот
                # же - фильм не сменился, и публиковать нечего: шаг растёт до
                # трёх секунд. Любая смена (начало, конец, следующая серия)
                # немедленно возвращает шаг к 0.75 с, поэтому на экране это
                # незаметно.
                player_sync_seen = sync_player_properties(win)
                if player_sync_seen and player_sync_seen == player_sync_key:
                    player_sync_gap = min(3.0, player_sync_gap * 1.5)
                else:
                    player_sync_gap = 0.75
                player_sync_key = player_sync_seen
                player_sync_next = now_ts + player_sync_gap
                _mark('плеер-свойства')

            # Такт хаба стоит около 0,5 с процессорного времени: он читает флаги
            # из своей базы (hub_state.db), подливает полосы, сверяет проводку
            # зеркала. Поэтому у него свои часы (HUB_TICK_SECONDS) - иначе он
            # выполнялся бы на каждой смене фокуса, и человек, ведущий по
            # строкам, каждый раз ждал бы полсекунды.
            #
            # СТОИТ ОН ЗДЕСЬ, ДО ВСЕХ ВЫХОДОВ ПО ТИПУ ОКНА, и это главное.
            # Раньше он стоял ниже - после проверки «мы в хабе?» - и во время
            # полноэкранного воспроизведения цикл уходил в `continue` задолго до
            # него. Из-за этого ВСЯ фоновая работа замирала, пока идёт
            # просмотр: и лента подписок, и зеркало, и обмен, и дописывание
            # сведений. Замер на .20 06.09.2026: одиннадцать минут просмотра
            # канала - ни одного прохода, покрытие студий стояло на 44 % при 566
            # строках, ждущих очереди, и в единственной строке часов хаба за это
            # время значилось «такт -678 с», то есть просрочено на одиннадцать
            # минут. Все правила «при воспроизведении реже, но ходить»
            # (MIRROR_REFRESH_PLAYING_SECONDS, SUBS_PLAYING_SECONDS,
            # TOPUP_META_PLAYING_SECONDS) при этом были написаны и не работали
            # вовсе - до них просто не доходило.
            #
            # Своей занятостью такт распоряжается сам: внутри у него и часы, и
            # проверки пульта с медиа.
            # Такт хаба идёт В СВОЁМ ПОТОКЕ, а не в цикле.
            #
            # Замер на .30 07.09.2026, навигация под фоновой работой: «долгий
            # такт 1502мс: ... такт хаба 1006» и «957мс: ... такт хаба 437». Эта
            # секунда - чтение флагов из своей sqlite, долив полос и сверка
            # проводки зеркала; на отклик пульта она не влияет (давление по
            # диску 0.0-1.2 %, отклик интерфейса 117 мс в худшем случае), но
            # публикацию строки под курсором задерживает ровно на столько же.
            # Всё, что делает такт, - фоновая работа со своей базой и своими
            # часами; меток интерфейса он не читает, поэтому общий кеш меток
            # (core.invalidate_labels) ему не мешает и он не мешает ему.
            #
            # Занятость проверяется по живости потока, как у сбора подписок и
            # дописывателя сведений: зависший поток не блокирует следующие.
            if now_ts - _HUB_TICK['at'] >= HUB_TICK_SECONDS:
                thread = _HUB_TICK.get('thread')
                alive = bool(thread is not None and thread.is_alive())
                if alive and now_ts - _HUB_TICK.get('started', 0.0) > HUB_TICK_STUCK_SECONDS:
                    log('такт хаба работает уже %d с - запускаю новый'
                        % int(now_ts - _HUB_TICK.get('started', 0.0)), xbmc.LOGWARNING)
                    alive = False
                if not alive:
                    _HUB_TICK['at'] = now_ts
                    _HUB_TICK['started'] = now_ts

                    def _hub_tick():
                        try:
                            hub_service.tick()
                        except Exception as exc:
                            log('hub tick skipped: %s' % exc, xbmc.LOGWARNING)

                    try:
                        fresh_tick = threading.Thread(target=_hub_tick, daemon=True)
                        fresh_tick.start()
                        _HUB_TICK['thread'] = fresh_tick
                    except Exception as exc:
                        log('поток такта хаба не запущен: %s' % exc, xbmc.LOGWARNING)
                _mark('такт хаба')

            preserve_action_buttons = bool(win.getProperty('VCL.ActionButtonsPreserve')) or xbmc.getCondVisibility('Window.IsVisible(1123) | Window.IsVisible(1127) | Window.IsVisible(1128) | Window.IsVisible(1129) | Window.IsVisible(1130)')
            _mark('диалоги')
            if preserve_action_buttons:
                win.setProperty('VCL.ActionButtonsVisible', 'true')
                win.setProperty('VCL.ActionButtonsStableLoaded', 'true')
                _nap_wait(mon, _tick_sleep())
                continue

            # Kodi строит новый список (вход в сериал, сезон, раздел): всё, что такт
            # опубликует сейчас, относится к уходящему списку и будет выброшено, а сам такт
            # (фон, метаданные, студия, прогрев соседей - до 1,5 с) отнимает процессор у
            # маршрута дополнения, который этот список строит (.20, 20.11.2026, вход в
            # «Закон и порядок: Торонто»: такты по 1,3-2,1 с во время маршрутов Filmix).
            # Только в окне «Видео»: в хабах обновление виджета (после просмотра, перестроение
            # списков) оставляет те же карточки, а пропуск такта и скрытый фон давали виджеты без
            # фонов на всё время обновления (владелец, 21.11.2026).
            if xbmc.getCondVisibility('Container.IsUpdating + Window.IsActive(videos)'):
                # окно «Видео» перезагружает список - после этого его содержимое своё (MyVideoNav.xml)
                if not win.getProperty('SublimeHelper.MediaSawUpdate'):
                    win.setProperty('SublimeHelper.MediaSawUpdate', '1')
                mon.waitForAbort(0.1)
                continue

            if not _is_homeish_window():
                if _is_media_nav_window():
                    # Sublime 851: restore fanart/clearlogo/ratings enrichment
                    # inside MyVideoNav without importing the 837 navigation
                    # cluster. No applyview, no SetViewMode, no delayed focus,
                    # no async episode bridge, no keepalive guard.
                    # MyVideoNav normally uses the plain media list control 500,
                    # but a Combined view type renders its content row in a
                    # separate container (531/532/534/536/538) instead - see
                    # _media_nav_active_row_id(). Do not read the last Home widget
                    # row here: that keeps stale Home metadata and leaves fanart/
                    # clearlogo/ratings blank inside film/series lists. Following
                    # whichever container actually has focus keeps the 731
                    # navigation lifecycle but enriches the currently focused list item.
                    row_id = _media_nav_active_row_id()
                    probe_key = _current_item_key(row_id)
                    identity_waiting = bool(
                        win.getProperty('SublimeHelper.ListItem.IdentityPending') or
                        str(win.getProperty('SublimeHelper.ListItem.Key') or '').startswith('transition|'))
                    if probe_key != metadata_probe_key or identity_waiting or now_ts - metadata_sync_at >= 3.0:
                        sync_metadata_properties(win, row_id)
                        metadata_probe_key = probe_key
                        metadata_sync_at = now_ts
                    # опубликовано для этого экрана - фон окна можно показывать (MyVideoNav.xml), но
                    # не для прошлого списка, с которым Kodi открывает окно до загрузки нового пути
                    if not win.getProperty('SublimeHelper.MediaScreenReady'):
                        onload_path = win.getProperty('SublimeHelper.MediaOnloadPath') or ''
                        folder = read_label('Container.FolderPath') or ''
                        first_seen = _MEDIA_READY.setdefault(onload_path, now_ts)
                        # тот же путь 2 с - это и есть нужный список (повторный вход в тот же сериал,
                        # перезагрузку которого такт мог не застать)
                        if (win.getProperty('SublimeHelper.MediaSawUpdate')
                                or not onload_path or folder != onload_path
                                or now_ts - first_seen >= 2.0):
                            win.setProperty('SublimeHelper.MediaScreenReady', '1')
                            _MEDIA_READY.clear()
                    _mirror_listitem_props_to_current_window(win)
                    # Sublime 852: lists must expose the same secondary info row and
                    # fallback background data as Home. 851 only mirrored helper
                    # metadata (ratings/logo/blur), but skipped the AF3SL genre/date/
                    # country and fallback fanart publishers in MyVideoNav. That left
                    # the list infoline empty and disabled fallback background art.
                    _update_fallback_art(win, row_id)
                    _update_background_wash(win, row_id=row_id, preserve=False)
                    if probe_key != detail_key or now_ts - detail_updated_at >= 5.0:
                        if not _row_info_is_own(row_id):
                            _update_first_genre_props(win, row_id)
                        detail_key = probe_key
                        detail_updated_at = now_ts
                    mon.waitForAbort(0.25)
                    continue
                # вне хаба (видео во весь экран, PVR, настройки) чистка нужна на входе в это
                # состояние и для страховки раз в 3 с: на каждом такте это ~40 обращений под
                # замком GUI впустую
                if now_ts - offhub_seen_at > 2.0 or now_ts - offhub_cleared_at >= 3.0:
                    _clear_action_buttons(win)
                    _clear_fallback_art(win, 'вне хаба')
                    _clear_studio_logo_props(win)
                    _clear_background_wash(win)
                    offhub_cleared_at = now_ts
                offhub_seen_at = now_ts
                last_key = ''
                loaded_key = ''
                loaded_since = 0.0
                detail_key = ''
                detail_updated_at = 0.0
                metadata_probe_key = ''
                wash_fingerprint = None
                studio_probe_key = ''
                # сон через _nap_wait: на видео во весь экран 1 с с проверкой меню плеера каждые
                # 0,25 с, и этот сон не попадает в «долгий такт»; в остальных окнах как было
                _nap_wait(mon, max(0.35, _tick_sleep()))
                continue

            # фокус вне виджета (строка категорий/групп, меню): выбранная строка показанного виджета
            # меняется без смены фокуса - публикуем её фон раз в 0,2 с, ветка ниже сюда не доходит
            if now_ts - _WIDGET_ART_AT[0] >= 0.2 and not (501 <= _safe_int(read_label('System.CurrentControlId')) <= 550):
                _shown_widget_id()      # показанный виджет по вкладке; картинки разметка берёт сама
                _WIDGET_ART_AT[0] = now_ts
            # Такт, в котором ничего не изменилось, не должен ничего делать.
            #
            # Ниже каждый такт вызывается _update_fallback_art, и она сама по
            # себе стоит около 15 мс: сравнивает арт строки с
            # AF3SL.FallbackSourceKey и выходит. При четырёх тактах в секунду
            # это ~6% ядра, а в активном режиме (0,06 с) - до 25%. Измерено на
            # .30 в покое: служба 22,5% ядра при полностью молчащем журнале.
            #
            # Условия выхода намеренно строгие. Пропускаем такт только если:
            # строка та же, что в прошлый раз; опознание не в процессе и не в
            # переходе; картинка на экране уже есть; и полный такт всё равно
            # выполняется не реже раза в три секунды - как страховка от
            # состояния, о котором мы не подумали.
            try:
                _idle_row = _focused_widget_row_cached(win)
                _idle_key = _row_fingerprint(_idle_row) if _idle_row else ''
                _picture = (win.getProperty('SublimeHelper.ListItem.BlurImage')
                            or win.getProperty('AF3SL.FallbackPreparedArt')
                            or win.getProperty('AF3SL.FallbackArt'))
                _pending = (win.getProperty('SublimeHelper.ListItem.IdentityPending')
                            or str(win.getProperty('SublimeHelper.ListItem.Key') or ''
                                   ).startswith('transition|'))
                if (_idle_key and _picture and not _pending
                        and _idle_key == _IDLE_TURN['key']
                        and now_ts - _IDLE_TURN['at'] < IDLE_TURN_LIMIT):
                    _nap_wait(mon, _tick_sleep())
                    continue
                _IDLE_TURN['key'] = _idle_key
                _IDLE_TURN['at'] = now_ts
            except Exception as exc:
                log('idle turn check skipped: %s' % exc, xbmc.LOGDEBUG)

            # The background goes out FIRST, before enrichment - and on every
            # turn, not only when this loop decides the row changed.
            #
            # Traced on .20 over a full sweep of Home: a "row changed" gate here
            # fired 19 times for about 130 focus changes, because the comparison
            # it shares with the metadata layer is settled further down the same
            # turn and fast scrolling always won the race. So the picture kept
            # being published by the late gate, behind identity, logo and
            # ratings - a whole turn (0.2-0.7 s at rest, seconds under a held
            # key) for art that was already in the cache.
            #
            # The publisher has its own cheap answer to "is this the same
            # picture": it compares the row's art against AF3SL.FallbackSourceKey
            # and returns. Traced cost of a call, median: 15 ms. That is what a
            # turn can afford, and it makes the background independent of every
            # slow stage below.
            _mark('до фона')
            # Стадия фона для строки PVR стоит около 180 мс: она читает пять-шесть
            # полей строки, а у канала каждое поле идёт через клиент телегида.
            # Пока строка та же и её картинка на экране, спрашивать это заново
            # незачем - но не дольше десяти секунд, чтобы подмена содержимого
            # контейнера без перемещения фокуса всё равно была замечена.
            _bg_same = bool(
                _idle_key and _idle_key == _BG_DONE['key']
                and (win.getProperty('AF3SL.FallbackPreparedArt')
                     or win.getProperty('AF3SL.FallbackArt')
                     or win.getProperty('SublimeHelper.ListItem.BlurImage'))
                and now_ts - _BG_DONE['at'] < BG_STAGE_LIMIT)
            if not _bg_same and not _action_button_has_focus():
                try:
                    early_row_id = _focused_widget_row_cached(win)
                    _WIDGET_ART_AT[0] = now_ts
                    if early_row_id:
                        _early_key = _current_item_key(early_row_id)
                        # Строка хаба несёт свои данные (Sublime.*): разметка рисует их в
                        # кадре смены фокуса, снимать и подменять нечего - иначе три смены
                        # текста и пустые оценки до следующего такта.
                        _own_bg = read_label('Container(%s).ListItem.Property(Sublime.Background)'
                                             % early_row_id)
                        _own = bool(_own_bg)
                        if _early_key and _early_key != _TRACE_ROW[0]:
                            _TRACE_ROW[0] = _early_key
                            _TRACE_ROW[1] = now_ts
                            _FAST_UNTIL[0] = time.monotonic() + POLL_ACTIVE_WINDOW
                            log('bg-trace строка сменилась: %s' % _early_key[:70])
                            # Чужие сведения снимаются ЗДЕСЬ - в тот же миг,
                            # когда строка названа новой, и раньше всякой
                            # работы с картинками. Ниже это стояло после
                            # публикации подложки, и замер на .30 10.09.2026
                            # показал разброс: обычно 0.06-0.12 с, но на
                            # тяжёлом такте - 0.42 с, всё это время оценки
                            # прошлого фильма стояли при новой строке.
                            # Фон при этом не трогается: demote_publication
                            # его не снимает (keep_suffixes), так что тёмного
                            # провала, ради которого перенос делали в обратную
                            # сторону, здесь нет.
                            if _early_key != _TRACE_ROW[2]:
                                _TRACE_ROW[2] = _early_key
                                try:
                                    if not _own:
                                        demote_publication(win, early_row_id, _early_key)
                                except Exception as exc:
                                    log('demote skipped: %s' % exc, xbmc.LOGDEBUG)
                                fallback_seen_key = ''
                                fallback_seen_at = 0.0
                        # One picture per focus where that is possible. A row the
                        # provider enriches almost always has its enriched
                        # background in the metadata cache, and publishing the
                        # blurred poster first meant the eye caught two pictures
                        # for one keypress - «проскакивают другие фоны, иногда по
                        # два раза». So an enrichable row whose metadata pass has
                        # not run yet gets a short window to publish its own
                        # picture, and the placeholder follows only if it misses.
                        # Rows nobody enriches - PVR, YouTube - wait for nothing:
                        # the placeholder IS their picture.
                        # Who publishes here, and who waits for the metadata
                        # stage a few lines below.
                        #
                        # A row nobody enriches - PVR, YouTube - has no second
                        # picture coming: the placeholder IS its picture, and
                        # publishing it at the top of the turn is what took those
                        # rows from seconds to tenths.
                        #
                        # A row the provider enriches almost always has its
                        # enriched background in the metadata cache, one stage
                        # below in this very turn. Publishing the blurred poster
                        # first means the eye gets two pictures for one keypress:
                        # measured off the owner's video, the second one landed
                        # 2.4 s after the focus change with no focus change of
                        # its own. So those rows are left to the publisher that
                        # runs AFTER enrichment - no timer, no waiting: if the
                        # enriched picture is there it goes up alone, and if it
                        # is not the placeholder follows in the same turn.
                        # Everything publishes here except a row we have seen
                        # with an enriched background before: that one gets its
                        # own picture from the metadata layer a moment later, and
                        # a placeholder in between is the second picture the
                        # owner sees. A row we have not seen enriched - a first
                        # visit, a YouTube clip, a channel - never waits.
                        # No memo skip any more. Remembering that a row was
                        # enriched once told us nothing about whether its picture
                        # is on screen NOW, and a row skipped on that memory sat
                        # under the previous film's backdrop until something else
                        # happened to publish. The publisher already refuses to
                        # cover this row's own enriched art (see
                        # _container_fallback_art), which is the same question
                        # asked about the present instead of the past.
                        _skip = _own      # у строки свой фон - подложка не нужна
                        if (not _skip and any(_m in _early_key for _m in (
                                'plugin.video.filmix', 'plugin.video.hdrezka.tv', 'plugin.video.elementum'))
                                and now_ts - (_TRACE_ROW[1] or 0.0) < ENRICH_GRACE):
                            # Still inside the grace: the metadata stage runs a
                            # few lines below and publishes this row's own
                            # background if it is cached.
                            _skip = True
                        if not _skip:
                            _update_fallback_art(win, early_row_id)
                        # Снятие личности переехало наверх, к самому
                        # обнаружению смены строки (см. выше). Здесь остаётся
                        # только отметка о том, для какой строки уже
                        # опубликована подложка.
                        fallback_seen_key = _current_item_key(early_row_id)
                        fallback_seen_at = now_ts
                except Exception as exc:
                    log('early background skipped: %s' % exc, xbmc.LOGDEBUG)
            if not _bg_same:
                _BG_DONE['key'] = _idle_key
                _BG_DONE['at'] = now_ts
            _mark('фон')

            # Снимок держится только в том окне, где он и был снят. Иначе он
            # переезжает в следующее окно: 08.09.2026 владелец увидел заголовок
            # и описание фильма при фоне и логотипе прошлого ролика YouTube -
            # «почему фоны зависают и наследуются». Вход в другое окно снимок
            # больше не удерживает.
            _keep_window = int(xbmcgui.getCurrentWindowId())
            action_buttons_focused = (
                (_action_button_has_focus() or _selector_has_focus())
                and _KEEP_SNAPSHOT.get('window') == _keep_window)
            if action_buttons_focused:
                # Ни всплывающие кнопки (692-696), ни полоса категорий (601, 52x)
                # медиа-контейнерами не являются. Пока фокус на них, держим уже
                # опубликованный снимок: у вкладки «Все» арта нет, и публикация
                # сняла бы фон, подложку и логотип - именно это владелец и видел
                # 08.09.2026 при переходе с виджета на категорию и обратно.
                row_id = _focused_widget_row_cached(win, allow_unfocused=True)
                probe_key = metadata_probe_key
            else:
                row_id = _focused_widget_row_cached(win)
                probe_key = _current_item_key(row_id) if row_id else ''
                if row_id:
                    _KEEP_SNAPSHOT['window'] = _keep_window
                identity_waiting = bool(
                    win.getProperty('SublimeHelper.ListItem.IdentityPending') or
                    str(win.getProperty('SublimeHelper.ListItem.Key') or '').startswith('transition|'))
                # AF3 itself does not continuously rescan every ListItem label. Keep the
                # custom metadata layer event/fingerprint driven: immediate on focus
                # change, rapid only while the two-tick identity guard is pending, and
                # a slow safety poll for late plugin enrichment/provider retries.
                if (probe_key != metadata_probe_key or identity_waiting or
                        now_ts - metadata_sync_at >= 3.0):
                    if probe_key != metadata_probe_key:
                        row_changed_at = now_ts
                    sync_metadata_properties(win, row_id)
                    _mark('метаданные')
                    metadata_probe_key = probe_key
                    metadata_sync_at = now_ts
                # Прогрев соседей ждёт остановки курсора, и это измерено, а не
                # предположено. Замер на .20 05.09.2026, полоса PVR, разбивка
                # такта в журнале:
                #
                #   такт 2420мс: до фона 62 | фон 142 | метаданные 240 |
                #                прогрев соседей 2255 | студия/канал 2279
                #
                # То есть картинка строки готова к 142 мс, а следующую строку
                # цикл не может даже увидеть ещё две секунды - он читает поля
                # соседей, а у канала PVR каждое поле идёт через клиент
                # телегида. Внешний замер это подтвердил: Kodi переименовывал
                # строку каждые 0.55 с, а цикл замечал смену раз в 1.1-1.5 с и
                # каждую вторую строку пропускал. Владелец увидел это как «при
                # скролле по PVR фоны подгружаются с задержкой».
                #
                # Работа сама по себе полезная (сосед, опознанный заранее,
                # показывается мгновенно), но она НЕ срочная: пока курсор едет,
                # соседи всё равно останутся позади. Ждём, пока курсор
                # остановится, и делаем ровно один раз на строку - как и
                # раньше.
                if (probe_key and probe_key != widget_prewarm_key
                        and now_ts - row_changed_at >= PREWARM_SETTLE_SECONDS):
                    # Dedicated prewarm queue/thread (see 897/submit_prewarm
                    # in core.py) - cannot delay or invalidate the focused
                    # item's own job above. Only on an actual focus change,
                    # never the slow safety-poll branch, so this cannot spin.
                    prewarm_widget_neighbors(row_id)
                    _mark('прогрев соседей')
                    widget_prewarm_key = probe_key
                    # A different row is focused. Warming resumes where
                    # this container left off rather than starting over:
                    # measured on <коробка>, a cold row costs 3.2 s
                    # median (8.3 s worst) against 0.42 s once cached, and
                    # restarting the sweep on every keypress meant the far
                    # end of a lane was never reached at all.
                    widget_warm_row = row_id
                    # Keyed by hub as well as by control id: every hub on
                    # Home owns a control with the same id (501), so keying
                    # progress by the id alone let a finished sweep in the
                    # TV hub mark the film lane as already warmed - it never
                    # warmed a single film row.
                    widget_warm_key = '%s|%s' % (
                        row_id, read_label('Skin.String(Sublime.LastHub)') or '')
                    widget_warm_next = widget_warm_progress.get(widget_warm_key, 4)
                    if not widget_warm_next and now_ts - widget_warm_done_at >= 10.0:
                        # The sweep is capped at the rows near the focus, so
                        # a finished sweep is finished only for where the
                        # cursor was. Once the user has moved on, the rows
                        # now near them deserve the same treatment - but not
                        # more often than every ten seconds, because the
                        # rows already warmed still cost their identity
                        # reads to recognise as warm.
                        widget_warm_next = 4
                    widget_warm_at = 0.0

            # Warm the rest of the focused widget while nobody is touching the
            # remote. Measured on <коробка>: a freshly built lane had 30% of
            # its rows in the metadata cache against 82% for the long-standing
            # recommendation list, and that gap - not which add-on served the
            # rows - is what made one widget feel instant and the other slow.
            # Walking the whole container in the idle gaps closes it. Runs on
            # the same background prewarm queue as the neighbours, so it can
            # never delay the focused row's own resolution.
            if not action_buttons_focused:
                try:
                    # Two seconds, not six: the pause between two keypresses is
                    # exactly when there is room to work, and the rows the user
                    # is about to reach are the ones worth having ready. Never
                    # while something plays - decoding needs those cores more.
                    # Three seconds, matching the prewarm worker's own gate:
                    # two was inside the window where the freshly focused row is
                    # still fetching and scaling its textures, and the warm-up
                    # was taking the cores it needed (measured: kodi.bin at 91%
                    # while the owner waited ~5 s for art whose metadata was
                    # already cached).
                    # Восемь секунд, не три. Замер на .20 06.09.2026: даже по
                    # одной строке за такт обход стоит 0.45-0.81 с внутри
                    # такта («долгий такт 1080мс: ... прогрев виджета 814»), и
                    # при пороге в три секунды нажатие после короткой паузы
                    # попадало в него. Восемь секунд - это уже осознанная
                    # пауза, а не заминка между нажатиями; прогрев от этого
                    # почти не теряет, потому что идёт он всё равно долго и по
                    # кругу.
                    idle_enough = (xbmc.getGlobalIdleTime() >= 8
                                   and not xbmc.getCondVisibility('Player.HasMedia'))
                except Exception:
                    idle_enough = False
                # Watch Hub raises this while it reads the provider's whole
                # catalogue (~12600 rows, kodi.bin near 120% CPU measured on
                # <коробка>). Warming metadata on the same cores at the same
                # time is how the row under the cursor ended up waiting, so the
                # warm-up simply stands aside until the pass is done.
                if win.getProperty('WatchHub.Rebuilding'):
                    idle_enough = False
                # Not while a dialog is up either: the first of these crashes
                # happened with the cast dialog filling its own container while
                # this code read rows (kodi_crashlog_20260820190811).
                if xbmc.getCondVisibility('System.HasActiveModalDialog | '
                                          'System.HasVisibleModalDialog'):
                    idle_enough = False
                if idle_enough and now_ts - widget_warm_at >= 1.0:
                    # Only the focused widget. Sweeping all of 501-550 to warm
                    # the neighbouring lanes as well was tried and reverted: it
                    # added 50 Container(N).NumItems reads per pass, moved the
                    # cached share of those lanes by nothing at all, and the
                    # box took a SIGSEGV inside GetMultiInfoLabel while it ran
                    # (crashlog kodi_crashlog_20260820203221 - the render
                    # thread this time). Not worth it.
                    if widget_warm_row and widget_warm_next:
                        try:
                            # Ещё одна проверка вплотную к вызову: между
                            # вычислением idle_enough наверху такта и этой
                            # строкой проходят сотни миллисекунд, и за них
                            # владелец успевает нажать.
                            if xbmc.getGlobalIdleTime() < 8:
                                raise _WarmSkipped()
                            # По ОДНОЙ строке за такт, не по две. Замер на .30
                            # 06.09.2026: обход виджета на простое стоил
                            # 0.6-1.0 с внутри такта, и первое нажатие после
                            # паузы могло попасть ровно в него. На скролл это
                            # не влияет (обход идёт только после 3 с покоя), но
                            # полтакта отклика на пустом месте терять незачем.
                            widget_warm_next = prewarm_widget_span(
                                widget_warm_row, widget_warm_next, 1)
                            _mark('прогрев виджета')
                            widget_warm_progress[widget_warm_key] = widget_warm_next
                            if not widget_warm_next:
                                widget_warm_done_at = now_ts
                            if len(widget_warm_progress) > 32:
                                widget_warm_progress.clear()
                        except _WarmSkipped:
                            pass
                        except Exception as exc:
                            log('widget warm-up skipped: %s' % exc, xbmc.LOGWARNING)
                            widget_warm_next = 0
                    widget_warm_at = now_ts

            # The hub's scheduled work rides this loop instead of a service of
            # its own: it checks the clock, does nothing unless the box is idle
            # and nothing is playing, and rebuilds at most once an interval.
            # The worker threads must never ask Kodi about GUI state: doing so
            # off the script's own thread is what segfaults Kodi 22-BETA1
            # (four crash logs on .20, the last one crashing inside the
            # metadata worker). They read this snapshot instead, and it is
            # taken here, on the right thread, once per turn of the loop.
            try:
                refresh_ui_snapshot()
            except Exception as exc:
                log('ui snapshot skipped: %s' % exc, xbmc.LOGWARNING)

            _mark('до студии')
            _update_studio_logo_delay(win, now_ts)
            if (probe_key != studio_probe_key or now_ts - studio_updated_at >= 0.75):
                _update_studio_logo_props(win, row_id)
                _update_channel_logo_props(win, row_id)
                _mark('студия/канал')
                studio_probe_key = probe_key
                studio_updated_at = now_ts

            cooldown_for_widget = bool(win.getProperty('Sublime.ActionButtonsReturnCooldown'))
            if cooldown_for_widget:
                # hard-hide popup action buttons while returning
                # to the source widget/searchbar. This must run before the
                # action-button focus branch; otherwise the 0.2s monitor loop can
                # re-set Visible/StableLoaded for one frame while focus is still
                # on 692-696.
                _clear_action_buttons(win)
                last_key = ''
                loaded_key = ''
                loaded_since = 0.0
                _nap_wait(mon, _tick_sleep())
                continue

            if action_buttons_focused:
                # Keep one immutable source item while moving between buttons and dialogs.
                _freeze_action_popup_snapshot(win)
                # Keep panel alive while user is on it and remember the source hub.
                src = _source_hub_window_id()
                if src:
                    win.setProperty('VCL.ActionButtonsSourceWindow', src)
                win.setProperty('VCL.ActionButtonsStableLoaded', 'true')
                win.setProperty('VCL.ActionButtonsVisible', 'true')
                _nap_wait(mon, _tick_sleep())
                continue

            key = _current_item_key(row_id) if row_id else ''
            # Do not paint an intermediate background. Traced on <коробка>:
            # the fallback publisher reacts to a focus change about two ticks
            # sooner than the metadata layer, so the eye got the previous row's
            # enriched art, then this row's blurred poster, then this row's
            # enriched art - three pictures for one keypress. The blurred one
            # only exists to cover a wait; if the metadata layer is about to
            # publish (its probe key has not caught up yet), waiting a moment is
            # exactly what removes the middle picture. Cold rows still get their
            # placeholder once the grace runs out.
            fallback_holds = False
            if key and key != metadata_probe_key:
                if key != fallback_wait_key:
                    fallback_wait_key = key
                    fallback_wait_until = now_ts + FALLBACK_METADATA_GRACE
                fallback_holds = now_ts < fallback_wait_until
            # The publisher reads about a dozen info labels per call, and the
            # loop turns four times a second. Nothing about a row's own poster
            # changes in between, so it is asked when the row changes and at
            # most every FALLBACK_POLL_SECONDS otherwise. Fewer reads is also
            # fewer chances to hit the Kodi 22-BETA1 crash in GetMultiInfoLabel.
            if not fallback_holds and (key != fallback_seen_key
                                       or now_ts - fallback_seen_at >= FALLBACK_POLL_SECONDS):
                fallback_seen_key = key
                fallback_seen_at = now_ts
                _update_fallback_art(win, row_id)
            # Deliberately NOT skipping the rest of the iteration while the
            # fallback holds: the wash colour is published below, and cutting
            # the iteration short pushed it a whole tick behind the picture it
            # belongs to - measured as a 0.17-0.34 s lag even when the colour
            # was already cached.
            preserve_wash = bool(win.getProperty('VCL.ActionButtonsPreserve')) or action_buttons_focused
            wash_source = _background_wash_source(win, row_id, preserve_wash)
            current_wash_fingerprint = (wash_source, int(row_id or 0), bool(preserve_wash))
            if current_wash_fingerprint != wash_fingerprint:
                _update_background_wash(
                    win, row_id=row_id, preserve=preserve_wash, source=wash_source)
                wash_fingerprint = current_wash_fingerprint
            # Genre/country/date extraction touches many Kodi labels. Recompute
            # immediately on item change, then at a low cadence so late plugin
            # enrichment still appears without consuming every navigation frame.
            if key != detail_key or now_ts - detail_updated_at >= 5.0:
                # у собранной строки жанр, страна и дата свои - разметка службу не читает
                if not _row_info_is_own(row_id):
                    _update_first_genre_props(win, row_id)
                detail_key = key
                detail_updated_at = now_ts
            disabled_for_widget = bool(win.getProperty('VCL.ActionButtonsWidgetDisabled'))
            if (not row_id or disabled_for_widget or not _action_buttons_any_enabled() or
                    not _action_buttons_searchbar_inactive() or
                    not _action_buttons_widget_loaded(row_id)):
                _clear_action_buttons(win)
                last_key = ''
                loaded_key = ''
                loaded_since = 0.0
                _nap_wait(mon, _tick_sleep())
                continue

            win.setProperty('VCL.ActionButtonsCurrentKey', key)
            # xbmc.getGlobalIdleTime is coarse and may not reset for internal list moves on some builds;
            # use wall clock from time module instead.
            t = time.time()
            if key != last_key:
                last_key = key
                last_time = t
                loaded_key = ''
                loaded_since = 0.0
                _clear_action_buttons(win)
                win.setProperty('VCL.ActionButtonsCurrentKey', key)
            elif loaded_key != key:
                loaded_key = key
                loaded_since = t
                _clear_action_buttons(win)
                win.setProperty('VCL.ActionButtonsCurrentKey', key)
            # кнопки действий - через ACTION_BUTTONS_DELAY после остановки фокуса (владелец 25.11.2026: 5 с)
            elif t - loaded_since >= loaded_delay and t - last_time >= ACTION_BUTTONS_DELAY:
                win.setProperty('VCL.ActionButtonsReadyKey', key)
                win.setProperty('VCL.ActionButtonsStableLoaded', 'true')
                win.setProperty('VCL.ActionButtonsVisible', 'true')
            if key != poll_last_key:
                poll_last_key = key
                poll_changed_at = t
                settled_key = ''
                set_focus_settled(False)
                if key and key != _TRACE_ROW[2]:
                    # Only if the early publisher never saw this row - it does
                    # the demote itself, in the same breath as the picture.
                    _TRACE_ROW[2] = key
                    log('bg-trace снял личность (поздний): %s' % key[:60])
                    try:
                        demote_publication(win, row_id, key)
                    except Exception as exc:
                        log('demote skipped: %s' % exc, xbmc.LOGDEBUG)
                    # Demoting clears the background too, so the publisher is
                    # allowed to speak again for this row instead of being held
                    # by its own throttle.
                    fallback_seen_key = ''
                    fallback_seen_at = 0.0

                    # Deliberately below the early publisher: this sets
                    # IdentityPending, which the art picker reads, so running it
                    # first would put that flag between a row change and its
                    # picture.
            # The cursor has stopped: the one thing that was left out - a
            # clearlogo that was not in the cache - may now be fetched, so this
            # row is resolved once more. Only when it is actually missing.
            if (key and key != settled_key
                    and (t - poll_changed_at) >= SETTLE_SECONDS):
                settled_key = key
                set_focus_settled(True)
                if not win.getProperty('SublimeHelper.ListItem.ClearLogo'):
                    try:
                        sync_metadata_properties(win, row_id, force=True)
                        metadata_probe_key = _current_item_key(row_id)
                        metadata_sync_at = t
                    except Exception as exc:
                        log('settled logo resolve skipped: %s' % exc, xbmc.LOGDEBUG)

            _turn_ms = (time.monotonic() - _turn_t0) * 1000.0

            # One line per turn while the hunt is on: the rate of these lines IS
            # the loop's tick rate, which is what decides how late a row change
            # can be noticed. Measured externally, Kodi names a new row in 0.01 s
            # and the publisher needs 0.03 s, yet the picture reached the screen
            # in about half a second - so the missing time is here.
            # Считается один раз и используется дважды: раньше то же выражение
            # стояло и в строке журнала, и в самом ожидании, и «сон=» мог
            # разойтись с тем, сколько цикл спал на самом деле.
            _nap = (POLL_ACTIVE if (t - poll_changed_at) < POLL_ACTIVE_WINDOW
                    else POLL_SETTLED)
            if _nap < POLL_FULLSCREEN and _plain_fullscreen_video():
                _nap = POLL_FULLSCREEN
            log('turn-beat %.0fмс сон=%.2f' % (_turn_ms, _nap), xbmc.LOGDEBUG)
            if _turn_ms >= 150.0:
                log('turn %.0fмс: %s' % (_turn_ms, ' | '.join(
                    '%s %.0f' % (n, v) for n, v in _turn_marks)), xbmc.LOGDEBUG)
            # По-настоящему долгий такт виден в обычном журнале, без включения
            # отладки. Это не шум: пока такт укладывается в свои 0.2-0.5 с,
            # строки здесь нет вовсе, а когда владелец говорит «фоны
            # подгружаются с задержкой», нужен ответ, КАКАЯ стадия столько
            # заняла, - и нужен он на его коробке, а не на воспроизведённом
            # случае.
            _nap_wait(mon, _nap)
        except Exception as exc:
            log('action buttons monitor error: %s' % exc, xbmc.LOGWARNING)
            try:
                _clear_action_buttons(win)
            except Exception:
                pass
            last_key = ''
            loaded_key = ''
            loaded_since = 0.0
            mon.waitForAbort(1.0)


def main():
    mon = xbmc.Monitor()
    try:
        addon = xbmcaddon.Addon(id=TARGET_ID)
        base = addon.getAddonInfo('path')
    except Exception as exc:
        log('addon lookup failed: %s' % exc, xbmc.LOGERROR)
        return

    # Do not run skin migrations or template generation while another skin is active.
    # In that state special://skin points to the other skin and breaks the Sublime menu build.
    while not mon.abortRequested() and not _target_skin_active():
        mon.waitForAbort(1.0)
    if mon.abortRequested():
        return

    # _target_skin_active() only says which skin is CONFIGURED - it becomes true
    # while Kodi is still building the GUI. Reading a parameterised info label in
    # that window took the whole process down twice on 22-BETA1: SIGSEGV inside
    # CGUIInfoManager::GetMultiInfoLabel, one frame under xbmc.getInfoLabel,
    # constructing a std::string from a pointer that is not there yet
    # (crashlogs kodi_crashlog_20260820190811 and ...194539 - the second one
    # right after this service logged "providers configured" on a cold boot, and
    # it repeated every boot). Waiting for a window to actually exist costs one
    # moment at startup and nothing afterwards.
    for _ in range(300):
        if mon.abortRequested():
            return
        try:
            if xbmc.getCondVisibility('!String.IsEmpty(System.CurrentWindow)'):
                break
        except Exception:
            break
        mon.waitForAbort(0.1)

    # And a window being named is still not the same as the GUI being safe to
    # ask questions of. Two more crash logs on .20 tonight
    # (kodi_crashlog_20260823175107 and ...175125) are the same SIGSEGV inside
    # CGUIInfoManager::GetMultiInfoLabel, fourteen and eighteen seconds after
    # their own Kodi start - past the gate above, while the home window was
    # still being built and the provider services were still starting. So the
    # home window has to be actually visible, and then the service waits a
    # little longer before it asks anything: at startup nothing here is urgent.
    for _ in range(200):
        if mon.abortRequested():
            return
        try:
            # Окна хаба - тоже главный экран: Kodi стартует прямо в них
            # (Custom_1100_Hub.xml и соседние), и без них это условие не
            # выполнялось никогда - служба ждала до таймаута 20 с. Владелец
            # 17.10.2026: «после перезагрузки долго не загружаются
            # инфостроки»; на .20 служба поднималась через 43 с после Kodi.
            if xbmc.getCondVisibility(_STARTUP_READY_WINDOWS):
                break
        except Exception:
            break
        mon.waitForAbort(0.1)
    if mon.waitForAbort(STARTUP_SETTLE_SECONDS):
        return

    # One-shot PVR path sanitation before embedded VCL variables update_xml; no forced reload loop.
    log('started')
    try:
        if _restore_generated_shortcuts_backup_if_needed():
            log('restored generated shortcuts include from persistent backup')
        _backup_valid_generated_shortcuts()
    except Exception as exc:
        log('generated shortcuts backup restore failed: %s' % exc, xbmc.LOGWARNING)
    try:
        from resources.lib.vcl_variables.viewtypes import ViewTypes
        if ViewTypes().migrate_saved():
            log('умолчания видов перенесены в сохранённый выбор')
    except Exception as exc:
        log('перенос умолчаний видов не удался: %s' % exc, xbmc.LOGWARNING)
    try:
        _sync_keyboard_recent_skin_strings()
    except Exception as exc:
        log('keyboard recent startup sync failed: %s' % exc, xbmc.LOGWARNING)
    try:
        patch_pvr_guide_onclicks(base)
    except Exception as exc:
        log('startup pvr path sanitize failed: %s' % exc, xbmc.LOGWARNING)
    try:
        # Кеши прошлых версий скина: их никто не пишет и не читает, а места они
        # занимают больше сотни мегабайт на коробку.
        from resources.lib.sublime_helper.cache import sweep_retired
        freed = sweep_retired()
        if freed:
            log('кеши прошлых версий убраны: освобождено %d МБ' % freed)
    except Exception as exc:
        log('уборка кешей прошлых версий не удалась: %s' % exc, xbmc.LOGWARNING)
    # цвета подложки - из 10905 файлов по 8 байт в одну базу; в отдельном потоке, чтобы не держать
    # запуск службы (image_wash.migrate_legacy, 23.11.2026)
    def _migrate_wash():
        try:
            from resources.lib.sublime_helper.image_wash import migrate_legacy
            moved = migrate_legacy()
            if moved:
                log('цвета подложки перенесены в одну базу: %d' % moved)
        except Exception as exc:
            log('цвета подложки не перенесены: %s' % exc, xbmc.LOGWARNING)
    try:
        threading.Thread(target=_migrate_wash, daemon=True).start()
    except Exception:
        pass
    try:
        # Своё окно «Следующая серия» вместо service.upnext, которому Filmix
        # ничего не сообщает. Отдельный поток: пока не играет серия Filmix, он
        # раз в две секунды спрашивает плеер и больше ничего не делает.
        from resources.lib.sublime_helper import next_episode
        next_episode.start(mon)
    except Exception as exc:
        log('next episode watcher failed to start: %s' % exc, xbmc.LOGWARNING)
    try:
        # Фокус при открытии сериала Filmix - на серии, которую смотреть дальше
        # (у Kodi это есть только для библиотеки).
        from resources.lib.sublime_helper import series_focus
        series_focus.start(mon)
    except Exception as exc:
        log('series focus watcher failed to start: %s' % exc, xbmc.LOGWARNING)
    try:
        # фоны и цвет подложки всех каналов ТВ - заранее (pvr_background_warm.py)
        from resources.lib import pvr_background_warm
        pvr_background_warm.start()
    except Exception as exc:
        log('pvr background warm failed to start: %s' % exc, xbmc.LOGWARNING)
    try:
        # все кэши разом по просьбе установщика, с прогрессом (fill_caches.py)
        from resources.lib import fill_caches
        fill_caches.start()
    except Exception as exc:
        log('fill caches failed to start: %s' % exc, xbmc.LOGWARNING)
    # Keep one monitor loop. AF3 relies on Kodi/XML for widget lifecycle; extra
    # skin-owned polling threads only duplicate label scans and compete with
    # navigation/plugin containers on low-power boxes.
    monitor_action_buttons(mon)


if __name__ == '__main__':
    main()
