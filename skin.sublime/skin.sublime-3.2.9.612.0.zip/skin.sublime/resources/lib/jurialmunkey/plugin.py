import xbmc
from xbmcaddon import Addon as KodiAddon


class KodiPlugin():
    def __init__(self, addon_id):
        self._addon_id = addon_id
        self._addon = KodiAddon(addon_id)
        self._addon_name = self._addon.getAddonInfo('name')
        self._addon_path = self._addon.getAddonInfo('path')


    def set_setting(self, setting, data, mode='bool'):
        def set_func():
            if mode == 'bool':
                return self._addon.setSettingBool
            if mode == 'int':
                return self._addon.setSettingInt
            if mode == 'str':
                return self._addon.setSettingString
        return set_func()(setting, data)

    def get_localized(self, localize_int=0):
        if localize_int < 30000 or localize_int >= 33000:
            return xbmc.getLocalizedString(localize_int)
        return self._addon.getLocalizedString(localize_int)


