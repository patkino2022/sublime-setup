# -*- coding: utf-8 -*-
"""Catalogue lanes - "new films", "new series" - served from the local cache.

Why here and not from the provider's own routes: with source-only metadata on,
its listing rows publish `rating: 0.0`, `votes: "0"` and no cast, so a widget
built from them has to wait for the skin to resolve everything over the
network. The same titles in its local cache carry ratings, votes, genres,
countries, plot and poster, so a row published from here is complete the
moment it appears.

The trade the owner accepted explicitly: this is a view of the cache, so a
title the provider has not cached yet will not be here, and the order is by
the cache's own `date_atom` rather than by the site's live ordering (which
leads with re-uploads of older posts). Freshness therefore lags by however
stale the provider's cache is.

Identity is preserved rather than dropped: rows carry the provider's own
resolved IMDb/TMDb ids where it has them, so the skin identifies them the same
way it identifies the provider's rows.
"""
# Ported from plugin.video.watchhub. The algorithm is unchanged; the
# sources it reads are not: settings come from config.py, the built
# lists and the feedback from store.py, and the watched history from
# history.py - which reads and writes Kodi's own database.
from __future__ import absolute_import, unicode_literals

import json
import time

import xbmc
import xbmcgui

from . import catalog, identity
from .config import get_bool, get_int, log, pause, stopping
from .store import db

# The ex-Yugoslav set, decoded from what the provider's own c68-c218 widget
# actually returns: Сербия 37 / Югославия 13 for films, Сербия 21 with single
# entries from Черногория and Босния for series. The provider never publishes
# what its filter codes mean, so this was read off the content rather than
# guessed from the numbers.
# Likewise c6-c64: Россия 41 / СССР 9 for films, Россия 46 / СССР 4 for series.
RUSSIAN = ('Россия', 'СССР')

# A lane is a category, a sort order, a title, and optionally the countries it
# is restricted to.
LANES = {
    'new_movies': ('movies', 'added', 'Новинки фильмов', ()),
    'new_shows': ('shows', 'added', 'Новинки сериалов', ()),
    'top_movies': ('movies', 'rating', 'Фильмы с высоким рейтингом', ()),
    'top_shows': ('shows', 'rating', 'Сериалы с высоким рейтингом', ()),
    'ru_movies': ('movies', 'added', 'Российские фильмы', RUSSIAN),
    'ru_shows': ('shows', 'added', 'Российские сериалы', RUSSIAN),
}
# The title above stays the Russian original; what the user sees comes from the
# skin strings, so an English Kodi gets an English lane name.
_LANE_TITLE_IDS = {
    'new_movies': 31904, 'new_shows': 31905,
    'top_movies': 31906, 'top_shows': 31907,
    'ru_movies': 31908, 'ru_shows': 31909,
    'rs_movies': 31910, 'rs_shows': 31911,
}


def lane_title(name):
    """The lane's display title in Kodi's language."""
    from ..l10n import tr
    string_id = _LANE_TITLE_IDS.get(name)
    return (tr(string_id) if string_id else '') or LANES[name][2]

CACHE_FLAG = 'lane_cache_%s'
CACHE_TS_FLAG = 'lane_cache_ts_%s'
# Из какого источника собрана полоса. Сменили источник (Filmix -> HDrezka и т.п.) -
# старая полоса не годится ни отдаваться, ни доливаться: строится заново.
CACHE_SRC_FLAG = 'lane_cache_src_%s'


def source_signature():
    from . import provider
    return '%s|%s|%s' % (provider.video_addon(), provider.catalog_path('movies'),
                         provider.catalog_path('shows'))


def _skin_build():
    try:
        import xbmcaddon
        return xbmcaddon.Addon('skin.sublime').getAddonInfo('version') or ''
    except Exception:
        return ''


def lane_signature():
    """Источник и версия скина, собравшая полосу. После обновления скина полосы собираются заново:
    иначе исправление отбора доходило до экрана только с плановой пересборкой - до refresh_hours
    («Чебурашка 3» без потока в «Новых фильмах» после выкладки 3.2.9.556, .20 25.11.2026)."""
    return '%s|%s' % (source_signature(), _skin_build())


def _same_provider(store, name):
    """Источник тот же (версия скина могла смениться)."""
    flag = store.get_flag(CACHE_SRC_FLAG % name) or ''
    return bool(flag) and (flag == source_signature() or flag.rsplit('|', 1)[0] == source_signature())


def _same_source(store, name):
    flag = store.get_flag(CACHE_SRC_FLAG % name)
    if not flag:
        # полоса без отметки: считаем своей и отмечаем, без пересборки на показе
        store.set_flag(CACHE_SRC_FLAG % name, lane_signature())
        return True
    return flag == lane_signature()
# The provider's own list is a network read, so it tops the lanes up on its own
# clock rather than on every service tick.
LISTING_TS_FLAG = 'lane_listing_ts_%s'
LISTING_INTERVAL = 120
# How many rows the cheap id window may add in one pass.
ID_WINDOW_CAP = 12

# Новинка со страницы списка, полной записи которой источник ещё не сохранил
# (нет описания), ждёт её столько секунд, а не встаёт в полосу пустой: полоса на
# экране обновляется только в тишине у пульта, и пустая карточка так и висела
# («Всегда говори Да на Рождество», .20, 19.11.2026 - список прочитан в 16:04:57,
# запись Filmix сохранил в 16:05:01). Дольше не ждём - фильм важнее описания.
THIN_GRACE_SECONDS = 600
THIN_SEEN_FLAG = 'lane_thin_seen_%s'


# A rating on its own ranks nothing: measured, «Переруг» carries imdb 9.4 from
# FIFTEEN voters and outranked «Побег из Шоушенка» (9.3 from three million).
# Pulling each rating toward a prior in proportion to how thin its vote is - the
# standard shrinkage - fixes that. The prior is deliberately unflattering, so a
# title has to earn its way up with real votes rather than with three of them.
RATING_PRIOR = 6.5
RATING_PRIOR_VOTES = 2000.0


def weighted_rating(row):
    """Rating shrunk toward the prior by how few people voted."""
    imdb = float(row.get('imdb_rating') or 0.0)
    imdb_votes = float(row.get('imdb_votes') or 0.0)
    kp = float(row.get('kp_rating') or 0.0)
    kp_votes = float(row.get('kp_votes') or 0.0)
    # Whichever source the larger audience actually used.
    rating, votes = (imdb, imdb_votes) if imdb_votes >= kp_votes else (kp, kp_votes)
    if rating <= 0 or votes <= 0:
        return 0.0
    return ((votes / (votes + RATING_PRIOR_VOTES)) * rating
            + (RATING_PRIOR_VOTES / (votes + RATING_PRIOR_VOTES)) * RATING_PRIOR)


def _sort_key(kind):
    if kind == 'rating':
        return weighted_rating
    return lambda row: (row.get('added_ts') or 0, row.get('post_number') or 0)


_LEARNED = {'ids': None, 'plots': None, 'at': 0.0}
# The learned tables are read for every lane of every pass - eight lanes twice a
# category - and each read parses a JSON document of a few thousand entries. Once
# per pass is enough: nothing writes them while a pass is running.
_LEARNED_TTL = 20.0


def _learned_cached(kind, loader):
    now = time.time()
    if _LEARNED.get(kind) is None or now - _LEARNED['at'] > _LEARNED_TTL:
        _LEARNED['ids'] = None
        _LEARNED['plots'] = None
        _LEARNED['at'] = now
    if _LEARNED.get(kind) is None:
        try:
            _LEARNED[kind] = loader() or {}
        except Exception:
            _LEARNED[kind] = {}
    return _LEARNED[kind]


def _learned_ids():
    """Ids the warm-up has already resolved, keyed by the provider's post id.

    The provider runs in source-only mode by design, so identity is the skin's
    job - and a row without ids costs a title search, a details call, a cross-id
    lookup and a logo lookup at the moment it is focused. Measured on .20 with
    the machine at a load average of three, that is where the two to eight
    seconds went. Once the builder has found the ids, publishing them with the
    row means nobody pays that again.
    """
    def _load():
        from . import learned
        return learned.ids()
    return _learned_cached('ids', _load)


def _learned_plots():
    """Descriptions already resolved, for rows the provider has not cached."""
    def _load():
        from . import learned
        return learned.plots()
    return _learned_cached('plots', _load)


def _entries(rows, category, external, limit):
    """Turn kept catalogue rows into the payload the widget publishes."""
    items = []
    learned = _learned_ids()
    learned_plots = _learned_plots()
    for _key, row in rows[:limit]:
        post_id = str(row.get('post_id') or '')
        ids = dict(external.get(post_id) or {})
        # What the provider resolved wins; what warming learned fills the gaps.
        for name, value in (learned.get(post_id) or {}).items():
            ids.setdefault(name, value)
        # id, которые дал сам источник в строке каталога (Elementum, библиотека Kodi,
        # HDrezka со страницы): по ним скин опознаёт запись сразу, без поиска по названию
        for name, value in (row.get('uniqueid') or {}).items():
            value = str(value or '').strip()
            if not value or value == '0':
                continue
            if name in ('tmdb', 'imdb', 'kinopoisk'):
                ids.setdefault(name, value)
            elif value.startswith('tt'):
                ids.setdefault('imdb', value)
        rating = max(row.get('imdb_rating') or 0.0, row.get('kp_rating') or 0.0)
        votes = max(row.get('imdb_votes') or 0.0, row.get('kp_votes') or 0.0)
        entry = {
            'label': identity.clean_label(row.get('label')),
            'title': identity.clean_label(row.get('title')) or identity.clean_label(row.get('label')),
            'file': row.get('file') or '',
            'year': row.get('year'),
            # A row straight off the provider's listing page has no plot of its
            # own; if warming has since resolved one, publish that rather than
            # an empty description.
            'plot': (row.get('plot') or learned_plots.get(post_id) or ''),
            'genre': [v.strip() for v in str(row.get('genre') or '').split(',') if v.strip()],
            'country': [v.strip() for v in str(row.get('country') or '').split(',') if v.strip()],
            'mediatype': row.get('mediatype') or ('tvshow' if category == 'shows' else 'movie'),
            'filetype': row.get('filetype') or 'file',
            # The provider's own post id: the skin resolves a row far faster
            # when it is told which post this is than when it has to search a
            # title blind.
            'post_id': str(row.get('post_id') or ''),
        }
        original = (row.get('originaltitle') or '').strip()
        if original:
            entry['originaltitle'] = original
        poster = row.get('poster') or ''
        if poster:
            entry['art'] = {'poster': poster, 'thumb': poster}
        own_art = row.get('art') if isinstance(row.get('art'), dict) else {}
        if own_art:
            entry['art'] = dict(entry.get('art') or {}, **own_art)
        if rating > 0:
            entry['rating'] = rating
        if votes > 0:
            entry['votes'] = int(votes)
        if ids.get('imdb') or ids.get('tmdb') or ids.get('kinopoisk'):
            entry['uniqueid'] = dict((k, v) for k, v in
                                     (('imdb', ids.get('imdb')), ('tmdb', ids.get('tmdb')),
                                      ('kinopoisk', ids.get('kinopoisk')))
                                     if v)
        items.append(entry)
    return items


class _busy_signal(object):
    """Tell the rest of the system that a catalogue pass is running.

    Measured on <коробка>: a catalogue pass holds kodi.bin near 120% CPU,
    and the skin's metadata warm-up runs on the same cores - together they
    starved the row the user was actually looking at. The skin reads
    Window(Home).Property(WatchHub.Rebuilding) and stands aside while it is
    set. Nothing breaks if the reader is absent; the property is just ignored.
    """

    PROP = 'WatchHub.Rebuilding'

    def __init__(self):
        self._win = None
        try:
            self._win = xbmcgui.Window(10000)
            self._win.setProperty(self.PROP, '1')
        except Exception:
            self._win = None

    def done(self):
        if self._win is None:
            return
        try:
            self._win.clearProperty(self.PROP)
        except Exception:
            pass
        self._win = None


def build_lanes(category, limit=0):
    """Build every lane of one category in a SINGLE catalogue pass.

    One pass per lane meant eight full reads of a 12603-row catalogue per
    cycle. Measured on <коробка>: each pass took 30-80 s and held kodi.bin
    at ~120% CPU, and the skin's metadata worker - which shares those cores -
    fell far enough behind that art and plot stayed on the previously focused
    row. The per-lane part is the filter and the sort key; the read is not, so
    the read happens once and every lane of the category is filled from it.
    """
    names = [n for n in sorted(LANES) if LANES[n][0] == category]
    if not names:
        return {}
    busy = _busy_signal()
    limit = limit or get_int('widget_size', 30)
    store = db()

    # A catalogue lane shows the catalogue. The rating floor, the year floor,
    # the blocked genres and the excluded countries are recommendation
    # settings; applying them here was my own decision and it was wrong -
    # measured on <коробка> it removed 52.6% of the 12604 films and 25.4%
    # of the 4224 series from lists whose whole job is to show what the
    # provider has. The owner can ask for the old behaviour with one toggle.
    from .recommend import settings_filters, rejected_reason
    filters = settings_filters()
    filtered = get_bool('filter_lanes', False)
    if filtered:
        hard = {'blocked_genres': filters['blocked_genres'],
                'excluded_countries': filters['excluded_countries'],
                'min_rating': filters['min_rating'],
                'min_year': filters['min_year']}
        disliked = store.feedback_keys('dislike')
    else:
        hard = {'blocked_genres': set(), 'excluded_countries': set(),
                'min_rating': 0.0, 'min_year': 0}
        disliked = set()
    external = catalog.resolved_external_ids()

    wanted = dict((n, set(c.lower() for c in LANES[n][3])) for n in names)
    key_fn = dict((n, _sort_key(LANES[n][1])) for n in names)
    kept = dict((n, []) for n in names)
    considered = 0
    dropped = 0
    for row in catalog.iter_candidates(category):
        considered += 1
        # The skin's metadata worker shares these cores. A pass that never
        # yields starved it badly enough that art stayed on the previous row,
        # so the pass steps aside briefly every few thousand rows - measured
        # cost of the whole pass grows by well under a second.
        if considered % 2000 == 0:
            # Та же уступка процессора, но прерываемая: проход по каталогу
            # длинный, и при остановке Kodi досматривать его до конца незачем.
            if pause(0.06) or stopping():
                break
        label = identity.clean_label(row.get('label'))
        if not label:
            continue
        item_key = identity.show_key(label, row.get('year'))
        if item_key and item_key in disliked:
            dropped += 1
            continue
        if rejected_reason(row, hard, unknown_rating_ok=True):
            dropped += 1
            continue
        countries = set(c.strip().lower() for c in
                        str(row.get('country') or '').split(',') if c.strip())
        for name in names:
            if wanted[name] and not (countries & wanted[name]):
                continue
            bucket = kept[name]
            bucket.append((key_fn[name](row), row))
            # Keep each working set small: sort down whenever it grows past a
            # comfortable multiple of what is needed.
            if len(bucket) > limit * 20:
                bucket.sort(key=lambda pair: pair[0], reverse=True)
                del bucket[limit * 4:]

    busy.done()
    built = {}
    for name in names:
        rows = kept[name]
        rows.sort(key=lambda pair: pair[0], reverse=True)
        items = _entries(rows, category, external, limit)
        built[name] = items
        if not items:
            # пусто - источник ещё не ответил (нет входа, нет кэша после переустановки):
            # такое не кэшируется, полоса строится заново при следующем запросе и проходе
            # службы (.20, 17.11.2026: после перезагрузки полосы HDRezka стояли пустыми)
            log('полоса %s: пусто, в кэш не пишу - соберу заново' % name)
            continue
        store.set_flag(CACHE_FLAG % name, json.dumps(items, ensure_ascii=False))
        store.set_flag(CACHE_TS_FLAG % name, str(int(time.time())))
        store.set_flag(CACHE_SRC_FLAG % name, lane_signature())
        log('полоса %s: отобрано=%d (ids у %d)'
            % (name, len(items), sum(1 for i in items if i.get('uniqueid'))))
    # A rebuild orders lanes by the provider's POSTS table, and that table lags
    # its own cached first PAGE - measured on .20: the page held films from
    # 24.08 01:20 while the newest post was from 23.08 15:52. So a rebuild
    # leaves the lane a day behind until the page is merged back in, and the
    # clock that gates that merge is cleared here to make it happen at once.
    try:
        store.set_flag(LISTING_TS_FLAG % category, '0')
    except Exception as exc:
        log('часы списка не сброшены: %s' % exc, xbmc.LOGWARNING)
    log('%s: один проход по каталогу, рассмотрено=%d, отброшено=%d, полос=%d, фильтры=%s'
        % (category, considered, dropped, len(names), 'да' if filtered else 'нет'))
    return built


def build_lane(name, limit=0):
    """One lane by name - built together with the rest of its category, since
    the catalogue read is the cost and it is the same read for all of them."""
    if name not in LANES:
        return []
    return build_lanes(LANES[name][0], limit).get(name) or []


def top_up_if_stale(category):
    """Merge the provider's page in now, if it has not been merged recently.

    Called from the widget request itself. Kodi loads its Home widgets within
    seconds of starting, while the service's own top-up reached the lane 85
    seconds later - measured on .20, Kodi up at 08:06, first top-up at 08:07:25.
    Everything in between was served from yesterday's lane, which is exactly the
    «новые айтемы не появились» the owner kept seeing after every restart. Two
    sqlite reads is a price a widget can pay; being a day stale is not.
    """
    try:
        age = int(time.time()) - int(db().get_flag(LISTING_TS_FLAG % category) or 0)
    except Exception:
        age = LISTING_INTERVAL + 1
    if age < LISTING_INTERVAL:
        return False
    try:
        return bool(top_up(category))
    except Exception as exc:
        log('долив при запросе полосы не удался: %s' % exc, xbmc.LOGWARNING)
        return False


def get_lane(name, max_age_seconds):
    """Cached lane, rebuilt only when stale - never on a widget request path
    unless there is nothing at all to show."""
    if name in LANES:
        top_up_if_stale(LANES[name][0])
    store = db()
    raw = store.get_flag(CACHE_FLAG % name)
    if raw and not _same_source(store, name) and not _same_provider(store, name):
        log('полоса %s: источник сменился, строю заново' % name)
        return build_lane(name)
    # сменилась только версия скина: полоса отдаётся как есть, служба пересоберёт (is_stale)
    if raw:
        try:
            items = json.loads(raw)
        except Exception:
            items = None
        if isinstance(items, list) and items:
            try:
                age = int(time.time()) - int(store.get_flag(CACHE_TS_FLAG % name) or 0)
            except (TypeError, ValueError):
                age = max_age_seconds + 1
            if age < max_age_seconds:
                return items
            log('полоса %s: кэш устарел (%d с), отдаю как есть' % (name, age))
            return items
    log('полоса %s: кэша нет, разовое построение' % name)
    return build_lane(name)


def is_stale(name, max_age_seconds):
    store = db()
    raw = store.get_flag(CACHE_FLAG % name)
    if not raw or raw.strip() in ('[]', 'null') or not _same_source(store, name):
        return True
    try:
        age = int(time.time()) - int(store.get_flag(CACHE_TS_FLAG % name) or 0)
    except (TypeError, ValueError):
        return True
    return age >= max_age_seconds


def _defer_thin(store, category, listed):
    """Убрать из списка новинки без полной записи источника, пока не вышла отсрочка."""
    if not listed:
        return listed
    try:
        seen = json.loads(store.get_flag(THIN_SEEN_FLAG % category) or '{}')
        if not isinstance(seen, dict):
            seen = {}
    except Exception:
        seen = {}
    now = int(time.time())
    kept, waiting, fresh = [], 0, {}
    for row in listed:
        post_id = str(row.get('post_id') or '')
        if row.get('_thin') and post_id:
            first = int(seen.get(post_id) or now)
            fresh[post_id] = first
            if now - first < THIN_GRACE_SECONDS:
                waiting += 1
                continue
        kept.append(row)
    try:
        store.set_flag(THIN_SEEN_FLAG % category, json.dumps(fresh))
    except Exception:
        pass
    if waiting:
        log('список %s: %d новинок ждут полной записи источника' % (category, waiting))
    return kept


def top_up(category, limit=0):
    """Bring the cached lanes of one category up to date, cheaply.

    A full rebuild reads the whole catalogue, so it runs on the slow schedule -
    and measured on <коробка> that left thirty of the fifty films on the
    provider's own first page out of the «Фильмы» widget while every one of them
    was already cached. This closes that gap from two sources:

    * the provider's cached listing pages, which give its own order including
      the re-uploads it leads with, and
    * the tail of the post id order, which catches anything cached after that
      page was last fetched.

    The provider's order wins the head of the lane, because that list is what
    the owner compares the widget against.
    """
    names = [n for n in sorted(LANES) if LANES[n][0] == category]
    if not names:
        return 0
    limit = limit or get_int('widget_size', 30)
    store = db()

    # The id window exists to catch posts cached after the provider's page was
    # last fetched - a handful, not four hundred. Reading four hundred rows out
    # of a 168 MB database every pass was work nobody asked for.
    rows = list(catalog.recent_rows(max(limit * 2, 120)))
    listed = []
    try:
        age = int(time.time()) - int(store.get_flag(LISTING_TS_FLAG % category) or 0)
        if age >= LISTING_INTERVAL:
            listed = catalog.provider_list_rows(category, pages=1)
            store.set_flag(LISTING_TS_FLAG % category, str(int(time.time())))
    except Exception as exc:
        log('список провайдера не прочитан: %s' % exc, xbmc.LOGWARNING)
    listed = _defer_thin(store, category, listed)
    listed_ids = set(str(r.get('post_id') or '') for r in listed)
    rows = [r for r in rows if str(r.get('post_id') or '') not in listed_ids]
    want_serial = (category == 'shows')
    listed = [r for r in listed if bool(r.get('is_serial')) == want_serial]
    rows = [r for r in rows if bool(r.get('is_serial')) == want_serial]
    if not listed and not rows:
        return 0
    log('долив %s: из списка провайдера %d, из окна id %d'
        % (category, len(listed), len(rows)))

    external = catalog.resolved_external_ids()
    # Same rule as a full build: a catalogue lane shows the catalogue, unless
    # the owner asked for the recommendation filters.
    from .recommend import settings_filters, rejected_reason
    if get_bool('filter_lanes', False):
        f = settings_filters()
        hard = {'blocked_genres': f['blocked_genres'],
                'excluded_countries': f['excluded_countries'],
                'min_rating': f['min_rating'], 'min_year': f['min_year']}
        disliked = store.feedback_keys('dislike')
    else:
        hard = {'blocked_genres': set(), 'excluded_countries': set(),
                'min_rating': 0.0, 'min_year': 0}
        disliked = set()

    def _passes(row, wanted):
        label = identity.clean_label(row.get('label'))
        if not label:
            return False
        item_key = identity.show_key(label, row.get('year'))
        if item_key and item_key in disliked:
            return False
        if rejected_reason(row, hard, unknown_rating_ok=True):
            return False
        if wanted:
            countries = set(c.strip().lower() for c in
                            str(row.get('country') or '').split(',') if c.strip())
            if not (countries & wanted):
                return False
        return True

    changed = 0
    for name in names:
        # A lane sorted by date takes new rows at its head; one sorted by rating
        # has no cheap way to place them among rows whose sort keys are not
        # kept, so it waits for the full rebuild rather than lying about order.
        if LANES[name][1] != 'added':
            continue
        raw = store.get_flag(CACHE_FLAG % name)
        if not raw or not _same_source(store, name):
            continue  # nothing cached yet (or another source): the full build owns this lane
        try:
            current = json.loads(raw)
        except Exception:
            continue
        if not isinstance(current, list) or not current:
            continue
        wanted = set(c.lower() for c in LANES[name][3])
        key_fn = _sort_key(LANES[name][1])
        # The bar for the cheap id window: only a post NEWER than everything the
        # lane already holds may go in front of it. Without this bar the window
        # put twelve arbitrary rows at the head on every pass - measured on .20:
        # a pass at 07:51:25 applied the provider's fifty-row page, and the very
        # next pass thirty seconds later pushed twelve older rows in front of it
        # and the newest films fell off the end of the lane. That is exactly the
        # «с каждой перезагрузкой всё старее» the owner reported. The provider
        # numbers its posts in order, so the largest id in the lane is the bar.
        newest_known = 0
        for entry in current:
            try:
                newest_known = max(newest_known, int(str(entry.get('post_id') or '0')))
            except (TypeError, ValueError):
                continue

        head = [row for row in listed if _passes(row, wanted)]
        head_ids = set(str(row.get('post_id') or '') for row in head)
        # Rows the lane already holds are not "new by id" - without this the
        # same twelve jumped to the head on every tick and the lane reshuffled
        # itself once a minute for no reason.
        have = set(str(entry.get('post_id') or '') for entry in current)
        def _newer_than_lane(row):
            try:
                return int(str(row.get('post_id') or '0')) > newest_known
            except (TypeError, ValueError):
                return False

        window = [row for row in rows
                  if str(row.get('post_id') or '') not in head_ids
                  and str(row.get('post_id') or '') not in have
                  and _newer_than_lane(row)
                  and _passes(row, wanted)]
        window.sort(key=key_fn, reverse=True)
        # The whole listing goes in, not only the part missing from the lane:
        # taking just the missing rows pushed the rest out on the trim and the
        # widget still did not match the provider's page.
        ordered = head + window[:ID_WINDOW_CAP]
        if not ordered:
            continue
        added = _entries([(-index, row) for index, row in enumerate(ordered)],
                         category, external, limit)
        if not added:
            continue
        added_ids = set(str(entry.get('post_id') or '') for entry in added)
        merged = added + [entry for entry in current
                          if str(entry.get('post_id') or '') not in added_ids]
        merged = merged[:limit]
        if merged == current:
            continue
        store.set_flag(CACHE_FLAG % name, json.dumps(merged, ensure_ascii=False))
        store.set_flag(CACHE_TS_FLAG % name, str(int(time.time())))
        changed += 1
        log('полоса %s: долив, из списка %d, по id %d'
            % (name, len(head), min(len(window), ID_WINDOW_CAP)))
    return changed
