# -*- coding: utf-8 -*-
"""The hub's own scheduled work, driven from the skin's service loop.

This is what plugin.video.watchhub's service.py used to do. It keeps the same
discipline, which was learned the hard way on these boxes:

* nothing is rebuilt while something is playing - a catalogue read during
  playback is exactly the stutter this code exists to avoid;
* nothing is rebuilt while the remote is being used - the rebuild holds a core
  and the art of the row under the cursor arrives late;
* one pass per category builds every lane of that category, because the
  catalogue read is the cost and it is the same read for all of them.
"""
from __future__ import absolute_import, unicode_literals

import threading
import time

import xbmc
import xbmcgui

from ..sublime_helper import hubs
from . import (builder, catalog, lanes, mirror, mirror_wire, recommend, sync,
               youtube_subs)
from .config import get_bool, get_int, log, stopping

CATEGORIES = ('movies', 'shows')
TICK_SECONDS = 60
IDLE_SECONDS = 60
# Warming has its own clock, and a much shorter one. The rest of this file waits
# for a full minute of quiet because it reads the whole catalogue; warming stops
# at the first keypress by itself (see warm._busy), so making it wait for that
# same minute meant it almost never ran on a box someone is actually using -
# measured, not a single pass in four minutes of ordinary poking.
WARM_SECONDS = 30
# The lane top-up reads two sqlite tables and writes a flag - hundreds of
# milliseconds, no network. It used to sit behind the same minute of idle as the
# catalogue rebuild, and that is what made the lists grow older with every
# restart: a rebuild orders the lane by the provider's POSTS table, which lags
# its cached first PAGE by up to a day, and the top-up that repairs that never
# ran while the box was being used. It now has its own short clock and no idle
# requirement.
# Every thirty seconds was chosen when the top-up was the only thing keeping the
# lanes fresh. It is not: the widget request tops up by itself when the page has
# not been merged recently (lanes.top_up_if_stale), so this clock only has to
# cover a box sitting on the home screen. Ninety seconds does that at a third of
# the cost - and the owner reported .30 feeling laggy with the old cadence.
TOPUP_SECONDS = 90
# After a lane really changes, the screen still shows what Kodi loaded earlier:
# a Home widget is re-queried only when its container reloads. The owner saw
# exactly that - the stored lane matched the provider's page item for item while
# the widget on screen did not. Container.Refresh reloads the focused container
# (the same builtin the provider uses for its own widgets), and it is only used
# when the remote has been quiet for a while, because it also returns the cursor
# to the start of the row.
REFRESH_IDLE_SECONDS = 12
# How often a mirrored widget's stored rows are refreshed, and where that clock
# is kept.
#
# 30.08.2026 это ненадолго стало 1800 вместе с пропуском свежих строк в
# hub/builder.py - ради процессора на простаивающей коробке. Замер показал, что
# сделка плохая: обе правки вместе дали 64.5 % -> 58.7 %, всего 5.8 пункта, а
# свежесть срезали вдвое. Настоящий расход - отрисовка Kodi: 33 % из 58.7, и
# скину она неподвластна (docs/PERFORMANCE_2026-08-28.md называет её «две трети
# всего» ещё двумя днями раньше). Владелец распорядился вернуть свежесть, и это
# правильно: платить четвертью часа свежести за неполные два пункта не за что.
MIRROR_REFRESH_SECONDS = 900
# То же, но пока загружено медиа. Раньше здесь не было ничего: проход при
# воспроизведении не шёл вовсе, потому что _busy() считает занятостью само
# наличие медиа.
#
# Чего это стоило. 03.09.2026 владелец оставил ТВ-канал открытым с 21:11 до
# 06:39 - в журнале ровно две строки, `VideoPlayer::OpenFile` и через девять с
# половиной часов `CloseFile`. Последний завершённый проход зеркала - 21:10, за
# минуту до включения. Утром хаб был вчерашним: полосы с пометкой «кэш устарел
# (40659 с)», снимок ленты подписок девятичасовой. Владелец увидел это как
# «виджет подписки устаревший опять».
#
# Почему час, а не 15 минут. Проход во время просмотра - риск, и его цена
# измерена нагрузочным опытом на .30 03.09.2026: канал ТВ занимает 14-16 %
# одного ядра, а под полным обходом всех 17 маршрутов сразу - 110-120 %, то
# есть 1.2 ядра из пяти, при этом воспроизведение не сбилось ни на кадр (дрейф
# времени плеера ноль, поток держал 25 к/с, троттлинга нет). Запас есть, но
# частить незачем: час превращает «весь хаб вчерашний» в «отстаёт не больше
# часа», а это уже незаметно. Одна константа, если понадобится иначе.
MIRROR_REFRESH_PLAYING_SECONDS = 3600
MIRROR_STAMP_FLAG = 'mirror_refreshed_at'
# Своя лента подписок YouTube (hub/youtube_subs.py). Проход спрашивает плейлисты
# загрузок каналов - по 1.5-14 с на канал, - поэтому идёт по кругу с бюджетом
# времени и не чаще раза в десять минут: свежее этого лента всё равно не бывает,
# YouTube сам отдаёт её порциями.
SUBS_SECONDS = 600
# То же во время просмотра. Правило владельца («разрешать проход при ТВ и видео,
# но реже») касается и этой ленты: 04.09.2026 на .20 последний сбор случился в
# 13:51, а к 18:12 не было ни одного - всё это время шло воспроизведение, и
# _busy() глушил проход целиком. Полоса за вечер успевала состариться на четыре
# часа. Тридцать запросов по сети декодеру не мешают (нагрузочный опыт на .30:
# канал ТВ - 14-16 % одного ядра, полный обход всех маршрутов - 110-120 %, и
# воспроизведение не сбилось ни на кадр), но частить незачем.
SUBS_PLAYING_SECONDS = 3600
# Бюджет одного прохода. Во время просмотра - вдвое короче. Бюджет
# проверяется ПЕРЕД каналом, поэтому проход его перекрывает на время
# последнего канала: замер на .20 05.09.2026 - бюджет 90 с, проход
# занял 204.7 с.
# Бюджет поднят с 90 до 180 с вместе с переходом на параллельный опрос:
# он ограничивает не длительность запроса, а момент, когда поток берёт
# СЛЕДУЮЩИЙ канал, а на .30 один канал отвечает по 20-60 с. При 90 с
# проход успевал 12 каналов из 30 - то есть треть подписок оставалась
# несвежей, и именно это владелец видел как «протухший виджет».
SUBS_BUDGET = 180
SUBS_BUDGET_PLAYING = 90
# Через столько зависший поток сбора перестаёт считаться работающим.
# Больше самого долгого замеренного прохода с запасом.
SUBS_STUCK_SECONDS = 420
# Подъём качества картинок в ленте идёт СВОИМ проходом и БЕЗ требования простоя.
# Замер на .20 05.09.2026: коробка в руках владельца, общий проход ленты ждёт
# минуты молчания пульта и не выполняется ни разу за час - а в ленте 31 строка
# из 60 с обложкой 480x360 и подложкой, растянутой из неё вчетверо. Работа тут
# вся в сети (HEAD-запрос и пересборка подложки), поэтому идёт малыми порциями в
# отдельном потоке и не задерживает публикацию строки под курсором.
UPGRADE_SECONDS = 60
# Через столько зависший поток перестаёт считаться работающим.
UPGRADE_STUCK_SECONDS = 120
# Дописывание сведений в уже собранные строки (студия, дата, оценка) - тоже без
# требования простоя. Замер на .20 05.09.2026: сборщик не отработал ни разу,
# потому что ждёт минуты молчания пульта, и в 749 собранных строках studio и
# premiered отсутствовали полностью. Владелец видел «логотипы студий пропали» и
# «инфострока грузится через минуту после фона и цвета». Здесь нет ни
# скачивания, ни размытия - только ответ провайдера, обычно из его кеша.
TOPUP_META_SECONDS = 60
# То же при загруженном медиа: раз в три минуты и малой порцией.
TOPUP_META_PLAYING_SECONDS = 180
TOPUP_META_PLAYING_LIMIT = 5
LISTINGS_SECONDS = 15           # готовые выдачи вкладок - проверка входов
LISTINGS_PLAYING_SECONDS = 60
STATE_WARM_SECONDS = 600         # живые вкладки хабов - запрос в фоне раз в 10 мин
STATE_WARM_PLAYING_SECONDS = 1800  # во время просмотра раз в 30 мин
# HDRezka - нет: её служба сама прогревает свои списки раз в 2 часа, бережно к сайту (тот закрывал
# адрес за частые запросы); второй прогрев отсюда только удваивал запросы (аудит 23.11.2026)
STATE_WARM_ADDONS = ('plugin://plugin.video.filmix/', 'plugin://skin.sublime/')
QUEUE_PLAYING_LIMIT = 2         # строк очереди дополнений за проход во время просмотра
QUEUE_PLAYING_SECONDS = 45      # и не чаще
TOPUP_META_STUCK_SECONDS = 120
# Пересчёт каталога (полосы, рекомендации, словарь) при ЗАГРУЖЕННОМ медиа.
# Замер на .20 05.09.2026: с 02:18 до 08:32 был открыт фильм - шесть часов
# подряд, - и всё это время _busy() считал коробку занятой, хотя пульт владелец
# не трогал вовсе. Полосы каталога состарились на десять часов, кеш полос - на
# семь. Зеркало этот случай уже переживает (MIRROR_REFRESH_PLAYING_SECONDS),
# каталог - нет. Правило владельца то же: «разрешать проход при ТВ и видео, но
# реже». Час - и «полосы вчерашние» превращается в «отстают не больше часа».
CATALOG_PLAYING_SECONDS = 3600
CATALOG_PLAYING_FLAG = 'catalog_refreshed_at'
# Список сериалов в виджетах главной для прогрева в Filmix
# (FilmixPrewarm.warm_home_series): раз в десять минут, сначала начатые
# владельцем, потом первые строки каждой полосы. Владелец 17.10.2026: «списки
# эпизодов сериалов, находящихся в виджетах главного экрана, ... чтобы быстро
# открывались, не теряя актуальности». Сеть Filmix трогает сам, мы только
# говорим, что на экране.
HOME_SERIES_SECONDS = 600
HOME_SERIES_PER_WIDGET = 8
HOME_SERIES_MAX = 80
# Начатые недавно идут первыми; давно брошенные - после первых строк полос.
# Первый замер на .30 17.10.2026: 35 начатых из 60 мест, и на видимые первые
# строки полос оставалось по пять.
HOME_SERIES_RECENT_DAYS = 30
HOME_SERIES_FILE = 'special://profile/addon_data/skin.sublime/home_series.json'
# How often the widget paths are checked against the setting.
WIRE_SECONDS = 120
REFRESH_MIN_GAP = 60

_STATE = {'next_tick': 0.0, 'next_warm': 0.0, 'next_topup': 0.0, 'next_wire': 0.0,
          'next_subs': 0.0, 'subs_thread': None, 'subs_started': 0.0,
          'next_report': 0.0, 'subs_done_at': 0.0,
          'next_upgrade': 0.0, 'upgrade_thread': None,
          'upgrade_started': 0.0, 'next_meta': 0.0, 'meta_thread': None,
          'meta_started': 0.0, 'meta_ran_at': 0.0,
          'started': False, 'started_at': 0.0, 'refreshed_at': 0.0,
          'refresh_pending': False}


def _max_age():
    return max(3600, get_int('refresh_hours', 12) * 3600)


def _media_loaded():
    try:
        return bool(xbmc.getCondVisibility('Player.HasMedia'))
    except Exception:
        return True


def _idle_seconds():
    """Сколько секунд молчит пульт. -1 - Kodi не ответил."""
    try:
        return int(xbmc.getGlobalIdleTime())
    except Exception:
        return -1


def _held():
    """Пауза по просьбе дополнения (Window(Home).Property(Sublime.Hold))."""
    try:
        return bool(xbmc.getInfoLabel('Window(Home).Property(Sublime.Hold)'))
    except Exception:
        return False


def _refresh_show_totals():
    """Число вышедших серий для начатых сериалов HDRezka и Elementum (в эфире - не старше
    часа, завершённые - суток: routes._show_totals) и общий файл серий с ним."""
    try:
        from . import history, routes
        shows = history.started_other_shows()
        if shows:
            routes._show_totals(shows, budget=4.0)
            history.republish_episode_states()
    except Exception as exc:
        log('число серий не обновлено: %s' % exc, xbmc.LOGDEBUG)


def _build_new_rows(category):
    """Новинки, попавшие в полосу доливом, собираются сразу, в фоне: фон, цвет, логотип,
    оценки - в самой строке, и смена фокуса на них мгновенная (builder.build_category_lanes)."""
    def _run():
        try:
            from . import builder
            done = builder.build_category_lanes(category)
            if done:
                log('новинки %s собраны сразу: %d строк' % (category, done))
                _STATE['refresh_pending'] = True
        except Exception as exc:
            log('новинки %s не собраны: %s' % (category, exc), xbmc.LOGWARNING)
    try:
        threading.Thread(target=_run, daemon=True).start()
    except Exception as exc:
        log('поток сборки новинок не запущен: %s' % exc, xbmc.LOGWARNING)


def _remote_busy():
    """Пультом работали недавно - уступаем, что бы мы ни делали."""
    try:
        # Пауза по просьбе дополнения - тоже «владелец ждёт сейчас»: см. builder._busy.
        if xbmc.getInfoLabel('Window(Home).Property(Sublime.Hold)'):
            return True
    except Exception:
        pass
    idle = _idle_seconds()
    if idle < 0:
        # Kodi не ответил. Считать это занятостью нельзя: гейт замолчал бы
        # навсегда, а именно так и выглядел случай 05.09.2026 - проходы встали
        # и не пошли сами. Не знаем - значит не мешаем.
        return False
    return idle < IDLE_SECONDS


def _busy():
    """True while the box is doing something the owner can see.

    Осталась для тяжёлых работ - пересчёта каталога и рекомендаций. Их при
    воспроизведении по-прежнему не запускаем: проход по каталогу читает 12
    тысяч строк и, по замеру в hub/lanes.py, держит kodi.bin около 120 % ядра
    десятки секунд. Разрежён (и разрешён при просмотре) только проход зеркала -
    он снимает готовые строки и стоит несравнимо меньше.
    """
    return _media_loaded() or _remote_busy()


def _refresh_widgets(now):
    """Ask the focused container to reload, if that cannot disturb anyone.

    Never while a hub is on screen. Rebuilding a container empties its tiles for
    a moment, re-runs the add-on behind it and hands focus back to the start of
    the row, which republishes a different item's art under a cursor that never
    moved. The owner filmed exactly that and called it flashing, and photographed
    the empty tile it leaves behind. A lane that changed can wait for the screen
    to be somewhere else - nothing is lost, because the widget re-queries when
    its container next loads anyway.
    """
    if now - _STATE['refreshed_at'] < REFRESH_MIN_GAP:
        return False
    try:
        if xbmc.getCondVisibility('Player.HasMedia'):
            return False
        if xbmc.getCondVisibility(hubs.HUB_SERVICE_UI_VISIBILITY_CONDITION):
            return False
        if xbmc.getGlobalIdleTime() < REFRESH_IDLE_SECONDS:
            return False
        if xbmc.getCondVisibility('System.HasActiveModalDialog | '
                                  'System.HasVisibleModalDialog'):
            return False
    except Exception:
        return False
    _STATE['refreshed_at'] = now
    try:
        xbmc.executebuiltin('Container.Refresh()')
        log('виджет обновлён: полосы изменились')
        return True
    except Exception as exc:
        log('обновление виджета не удалось: %s' % exc, xbmc.LOGWARNING)
        return False


# Обмен с сервером просмотренных ходит в сеть, а такт хаба выполняется внутри
# главного цикла службы скина - того самого, который публикует данные строки
# при смене фокуса. Пока обмен ждёт ответа (таймаут по умолчанию 30 секунд),
# цикл не делает ничего: на экране это выглядит как «коробка периодически
# зависает в покое». Владелец сообщил об этом 03.09.2026 про .30, и заметнее
# стало ровно после того, как её обмен направили на .20: до этого запрос на
# 127.0.0.1 отказывался мгновенно, а теперь может висеть.
_SYNC_THREAD = {'handle': None}


def _sync_in_background():
    """Один проход обмена в своём потоке. Второй не запускается."""
    handle = _SYNC_THREAD.get('handle')
    if handle is not None and handle.is_alive():
        return False

    def run():
        try:
            sync.run_once()
        except Exception as exc:
            log('обмен не удался: %s' % exc, xbmc.LOGWARNING)

    handle = threading.Thread(target=run, name='SublimeHubSync')
    handle.daemon = True
    _SYNC_THREAD['handle'] = handle
    handle.start()
    return True


def _live_sources():
    """Источники, которые сейчас нужны: виджеты владельца и наши полосы."""
    import glob
    import json as _json
    import xbmcvfs
    found = set()
    base = xbmcvfs.translatePath(
        'special://profile/addon_data/skin.sublime/nodes/skin.sublime/')
    # Файлы виджетов текущего вида имени. Рядом лежат старые копии
    # `skinvariables-shortcut-*` того же содержимого - читать обе пары незачем
    # (проверено на .30 08.09.2026).
    for path in glob.glob(base + 'vclvariables-shortcut-*widgets.json'):
        try:
            with open(path, 'r', encoding='utf-8') as handle:
                data = _json.load(handle)
        except Exception:
            continue
        items = data if isinstance(data, list) else (data.get('items') or [])
        for item in items:
            if not isinstance(item, dict):
                continue
            target = str(item.get('widget_path') or item.get('path') or '').strip()
            if target:
                found.add(target)
    # Наши собственные источники в списке виджетов не значатся, но живы всегда.
    for name in ('new_movies', 'top_movies', 'ru_movies',
                 'new_shows', 'top_shows', 'ru_shows'):
        found.add('plugin://skin.sublime/?info=hub_lane&name=%s' % name)
    for category in ('movies', 'shows'):
        found.add('plugin://skin.sublime/?info=hub_widget&category=%s' % category)
    found.add('sublime://youtube_subs')
    found.add('sublime://youtube_trending')
    return found


def _write_home_series():
    """Записать home_series.json: какие сериалы Filmix стоят в виджетах."""
    import json as _json
    import os
    import re
    import xbmcvfs
    from . import history
    pattern = re.compile(r'plugin://plugin\.video\.filmix/(?:serials|multserials)/(\d+)-')
    live = _live_sources()
    per_widget = []
    for src, rows in mirror.iter_snapshots():
        if src not in live:
            continue
        ids = []
        for row in rows or []:
            hit = pattern.search(str((row or {}).get('file') or ''))
            if hit and hit.group(1) not in ids:
                ids.append(hit.group(1))
        if ids:
            per_widget.append(ids)
    present = set(pid for ids in per_widget for pid in ids)
    started = history.started_post_ids()
    recent_after = time.time() - HOME_SERIES_RECENT_DAYS * 86400
    by_recency = [pid for pid, _ts in sorted(started.items(), key=lambda kv: -kv[1])
                  if pid in present]
    ordered = [pid for pid in by_recency if started[pid] >= recent_after]
    for position in range(HOME_SERIES_PER_WIDGET):
        for ids in per_widget:
            if position < len(ids) and ids[position] not in ordered:
                ordered.append(ids[position])
    ordered += [pid for pid in by_recency if pid not in ordered]
    ordered = ordered[:HOME_SERIES_MAX]
    path = xbmcvfs.translatePath(HOME_SERIES_FILE)
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as handle:
        _json.dump({'ts': int(time.time()), 'ids': ordered}, handle)
    os.replace(tmp, path)
    log('сериалы главной для прогрева: %d (начатых %d, виджетов %d)'
        % (len(ordered), len([p for p in ordered if p in started]), len(per_widget)))
    return ordered


_SUBS_LOCK = threading.Lock()
_SUBS_WATCH = {'thread': None}


def _serve_subs_request(now):
    """Заявка виджета на ленту подписок YouTube -> сбор в своём потоке. Зовётся из такта и из
    сторожа заявок (_watch_subs_requests): такт сразу после установки занят первой сборкой полос,
    и заявка ждала его около двух минут - «подписки не успевают собираться» (23.11.2026)."""
    served = False
    with _SUBS_LOCK:
        asked = 0
        try:
            asked = youtube_subs.refresh_requested_at()
        except Exception:
            asked = 0
        if asked and asked > int(_STATE.get('subs_done_at', 0.0)):
            thread = _STATE.get('subs_thread')
            alive = bool(thread is not None and thread.is_alive())
            if alive and now - _STATE.get('subs_started', 0.0) > SUBS_STUCK_SECONDS:
                alive = False
            if not alive:
                _STATE['subs_started'] = now
                _STATE['subs_done_at'] = now
                _STATE['next_subs'] = now + SUBS_SECONDS
                try:
                    youtube_subs.clear_request()
                except Exception:
                    pass

                def _asked_collect():
                    try:
                        done, _total = youtube_subs.refresh(budget=SUBS_BUDGET)
                        log('подписки YouTube: сбор по заявке виджета, обновлено '
                            'каналов %d' % done)
                    except Exception as exc:
                        log('подписки YouTube: сбор по заявке не удался: %s' % exc,
                            xbmc.LOGWARNING)

                try:
                    asked_thread = threading.Thread(target=_asked_collect,
                                                    daemon=True)
                    asked_thread.start()
                    _STATE['subs_thread'] = asked_thread
                    served = True
                except Exception as exc:
                    log('подписки YouTube: поток по заявке не запущен: %s' % exc,
                        xbmc.LOGWARNING)

    return served


def _watch_subs_requests():
    """Лёгкий сторож: раз в 2 с смотрит заявку на подписки, не дожидаясь такта."""
    if _SUBS_WATCH['thread'] is not None and _SUBS_WATCH['thread'].is_alive():
        return

    def run():
        mon = xbmc.Monitor()
        while not mon.abortRequested():
            try:
                _serve_subs_request(time.time())
            except Exception as exc:
                log('сторож заявок подписок: %s' % exc, xbmc.LOGDEBUG)
            if mon.waitForAbort(2):
                break

    handle = threading.Thread(target=run, name='SublimeSubsWatch')
    handle.daemon = True
    _SUBS_WATCH['thread'] = handle
    handle.start()


def tick(now=None):
    """Called often, does something rarely. Returns True when it worked."""
    now = now or time.time()
    did = False
    _watch_subs_requests()      # заявки на подписки YouTube - без ожидания такта

    # Часы хаба в обычном журнале, раз в пять минут. Появилось 05.09.2026
    # после случая, который иначе не разобрать: подписки, зеркало и обмен
    # встали ВСЕ ТРОЕ в 13:42-13:45 и не пошли три часа, при полностью
    # простаивающей коробке (System.IdleTime(120) = да) и без единой ошибки в
    # журнале. Общее у этих трёх - только гейты по занятости, а их значения
    # снаружи не видны никак: ни состояние _STATE, ни то, что вернул
    # getGlobalIdleTime внутри процесса службы. Одна строка раз в пять минут
    # стоит дешевле ещё одного круга догадок.
    # Тренды YouTube: свой снимок раз в полчаса, обычным HTTP (0.3-0.5 с).
    # Дополнение на этот же раздел тратило 3.3-4.2 с на каждый показ.
    # Просмотры Elementum - имя по номеру TMDb (history.name_elementum_by_tmdb), раз в минуту
    # по нескольку: без имени начатое через Elementum не видно ни в «Продолжить просмотр»,
    # ни в значках сериалов.
    if now >= _STATE.get('next_elementum_names', 0.0):
        _STATE['next_elementum_names'] = now + 60
        if not _media_loaded():
            try:
                from . import history
                if history.name_elementum_by_tmdb(limit=3, cancel=stopping):
                    did = True
            except Exception as exc:
                log('имена Elementum не получены: %s' % exc)

    if now >= _STATE.get('next_trending', 0.0):
        _STATE['next_trending'] = now + 1800
        if not _remote_busy() and not _media_loaded():
            try:
                from . import youtube_trending
                youtube_trending.refresh()
                did = True
            except Exception as exc:
                log('тренды YouTube не обновлены: %s' % exc)

    # Раз в пять минут - жив ли хост картинок поставщика. 08.09.2026 у Filmix
    # лёг собственный сервер картинок (521 от Cloudflare, корнем хоста, с обеих
    # коробок и из другой сети), а его API продолжал выдавать ровно этот адрес.
    # Ссылка непустая - значит разметка считала её годной, и плитки стояли
    # пустыми двенадцать часов, хотя наши постеры с TMDb лежали рядом. Пока
    # хост числится мёртвым, строки берут наш постер (hub/routes.py, _own_art);
    # ответит - вернутся его картинки сами.
    #
    # Хост берём ИЗ САМИХ СТРОК, а не зашиваем: один снимок по кругу, первая
    # найденная ссылка не на наши источники метаданных.
    if now >= _STATE.get('next_hosts', 0.0):
        _STATE['next_hosts'] = now + 300
        try:
            from . import host_health
            # Собираем до трёх НАСТОЯЩИХ адресов на хост. Одного мало:
            # 08.09.2026 проба по одному файлу записала хосту 200, а четыре его
            # файла в ту же минуту не ответили вовсе - их CDN отдаёт часть путей
            # с края, до склада не доходя.
            samples = {}
            for src, rows in mirror.iter_snapshots():
                for row in (rows or [])[:24]:
                    art = (row or {}).get('art') or {}
                    for key in ('poster', 'thumb', 'fanart'):
                        sample = str(art.get(key) or '')
                        host = host_health.host_of(sample)
                        # Наши источники проверять незачем, а местные файлы в
                        # обёртке image:// хостом и не считаются.
                        if not host or 'tmdb' in host or 'ytimg' in host or 'ggpht' in host:
                            continue
                        seen = samples.setdefault(host, [])
                        if len(seen) < 3 and sample not in seen:
                            seen.append(sample)
                        other = host_health.mirror_url(sample)
                        other_host = host_health.host_of(other)
                        if other_host:
                            seen_other = samples.setdefault(other_host, [])
                            if len(seen_other) < 3 and other not in seen_other:
                                seen_other.append(other)
                        break
                if samples and min(len(v) for v in samples.values()) >= 3:
                    break
            for host, urls in samples.items():
                if host_health.due(host):
                    host_health.probe(host, samples=urls)
        except Exception as exc:
            log('проверка хостов картинок не выполнена: %s' % exc)

    # Раз в сутки - уборка снимков виджетов, которых больше нет на экране.
    # Аудит .30 07.09.2026: 353 строки из 967 лежали в снимках возрастом 23
    # часа и 3 суток, то есть треть работы доливки сведений уходила на строки,
    # которых владелец не увидит. Живой список берём из настроек виджетов
    # самого владельца (nodes/skin.sublime/*widgets.json) плюс наши источники.
    if now >= _STATE.get('next_prune', 0.0):
        _STATE['next_prune'] = now + 24 * 3600
        try:
            mirror.prune_orphans(_live_sources(), now=now)
        except Exception as exc:
            log('уборка снимков не выполнена: %s' % exc)

    if now >= _STATE.get('next_home_series', 0.0):
        _STATE['next_home_series'] = now + HOME_SERIES_SECONDS
        try:
            _write_home_series()
        except Exception as exc:
            log('сериалы главной не записаны: %s' % exc, xbmc.LOGWARNING)

    if now >= _STATE.get('next_report', 0.0):
        _STATE['next_report'] = now + 300
        try:
            last_m = 0.0
            try:
                from .store import db as _rdb
                last_m = float(_rdb().get_flag(MIRROR_STAMP_FLAG) or 0)
            except Exception:
                last_m = -1.0
            thread = _STATE.get('subs_thread')
            def _when(key):
                # Ноль значит «ещё ни разу», а не «минус пятьдесят семь лет»:
                # до первого прохода в _STATE лежит 0.0, и разность с ним
                # печаталась мусорным числом.
                planned = float(_STATE.get(key, 0.0) or 0.0)
                if planned <= 0:
                    return 'не запланировано'
                return '%+d с' % int(planned - now)

            started_at = float(_STATE.get('subs_started', 0.0) or 0.0)
            log('часы хаба: подписки %s, поток сбора=%s (%s), зеркало %s, '
                'такт %s, пульт занят=%s, медиа=%s, простой=%s'
                % (_when('next_subs'),
                   'жив' if (thread is not None and thread.is_alive()) else 'нет',
                   ('%d с назад' % int(now - started_at)) if started_at > 0
                   else 'не запускался',
                   ('%d с назад' % int(now - last_m)) if last_m > 0
                   else 'не проходило',
                   _when('next_tick'),
                   _remote_busy(), _media_loaded(),
                   _idle_seconds()))
        except Exception as exc:
            log('часы хаба не показаны: %s' % exc, xbmc.LOGWARNING)

    # The very first tick after a start reads the provider's page immediately.
    # Without this the lane shows whatever it held before the restart until the
    # listing clock ages out - up to two minutes of yesterday's films, which is
    # exactly what the owner saw as «пропали новые айтемы» after every install.
    if not _STATE['started']:
        _STATE['started'] = True
        _STATE['started_at'] = now
        # A start is exactly when the widgets are empty, so the first pass runs
        # once the interface has settled rather than waiting out the interval.
        _STATE['next_topup'] = 0.0
        _STATE['next_tick'] = 0.0
        for category in CATEGORIES:
            try:
                from .store import db
                db().set_flag(lanes.LISTING_TS_FLAG % category, '0')
            except Exception as exc:
                log('часы списка не сброшены при старте: %s' % exc, xbmc.LOGWARNING)

    # Freshness first, and cheaply: whatever the provider has cached joins the
    # date-sorted lanes within half a minute, whether or not anyone is using the
    # box. Nothing here touches the network.
    if now >= _STATE['next_topup']:
        _STATE['next_topup'] = now + TOPUP_SECONDS
        changed = False
        for category in CATEGORIES:
            try:
                if lanes.top_up(category):
                    did = True
                    changed = True
                    _build_new_rows(category)
            except Exception as exc:
                log('долив полос %s не удался: %s' % (category, exc),
                    xbmc.LOGWARNING)
        if changed:
            # Remember it rather than refreshing on the spot: lanes change on
            # their own clock, and the odds of that instant also being a quiet
            # one are poor - measured, not a single refresh fired. The pending
            # flag waits for the first quiet moment instead.
            _STATE['refresh_pending'] = True

    if _STATE['refresh_pending'] and _refresh_widgets(now):
        _STATE['refresh_pending'] = False

    # число серий начатых сериалов HDRezka и Elementum - раз в 5 минут, в фоне
    if now >= _STATE.get('next_totals', 0.0) and not _remote_busy():
        _STATE['next_totals'] = now + 300
        _refresh_show_totals()

    # Wiring the mirrored widgets is a file check, and it runs BEFORE the gates
    # below - it used to sit after them and therefore never ran at all while the
    # box was in use: the tick returns early on its minute clock, on the
    # auto-refresh setting and on _busy(), which is true whenever the remote was
    # touched in the last minute. Measured on .20: 0 paths ever rewritten, which
    # is exactly why the owner saw no difference.
    #
    # No ReloadSkin here either. The edited file is read when the skin next
    # loads; forcing a reload would be a jolt on screen, and this work is never
    # urgent enough for that.
    if now >= _STATE.get('next_wire', 0.0):
        _STATE['next_wire'] = now + WIRE_SECONDS
        try:
            wanted = get_bool('mirror_widgets', False)
            changed = mirror_wire.apply(wanted)
            if changed:
                log('зеркало виджетов %s: путей изменено %d (вступит в силу '
                    'при следующей загрузке скина)'
                    % ('включено' if wanted else 'выключено', changed))
        except Exception as exc:
            log('зеркало виджетов не настроено: %s' % exc, xbmc.LOGWARNING)

    if now >= _STATE.get('next_upgrade', 0.0):
        # Занятость потока проверяется ПО ЖИВОСТИ, а не по флагу. 05.09.2026 на
        # .20 поток залип внутри скачивания картинки (xbmcvfs.copy без
        # таймаута), флаг остался поднятым, и проходы прекратились совсем:
        # 15 строк остались с низким фоном при живой крупной картинке. Теперь
        # зависший поток не блокирует новые - сам проход защищён замком на
        # снимок (youtube_subs._FEED_LOCK), поэтому двое не столкнутся.
        thread = _STATE.get('upgrade_thread')
        alive = bool(thread is not None and thread.is_alive())
        if alive and now - _STATE.get('upgrade_started', 0.0) > UPGRADE_STUCK_SECONDS:
            log('подписки YouTube: прошлый поток качества работает уже %d с - '
                'запускаю новый' % int(now - _STATE.get('upgrade_started', 0.0)),
                xbmc.LOGWARNING)
            alive = False
        if not alive:
            _STATE['next_upgrade'] = now + UPGRADE_SECONDS
            _STATE['upgrade_started'] = now

            def _upgrade_rows():
                try:
                    youtube_subs.upgrade_pass(cancel=stopping)
                except Exception as exc:
                    log('подписки YouTube: качество не поднято: %s' % exc,
                        xbmc.LOGWARNING)

            try:
                fresh = threading.Thread(target=_upgrade_rows, daemon=True)
                fresh.start()
                _STATE['upgrade_thread'] = fresh
            except Exception as exc:
                log('подписки YouTube: поток качества не запущен: %s' % exc,
                    xbmc.LOGWARNING)
        else:
            _STATE['next_upgrade'] = now + 10

    # Дописыватель сведений при воспроизведении: чаще, но малой порцией.
    #
    # История этой настройки - в три захода, и все три замерены на .20
    # 06.09.2026. Шесть строк в минуту были слишком медленны: полный обход 850
    # строк занимал два с половиной часа, и владелец видел «студия у 27 из 50».
    # Двадцать пять в минуту оказались слишком тяжелы: load average 4.9 на пяти
    # ядрах, и владелец сказал «интерфейс лагает, канал включается долго». Тогда
    # я отодвинул проход при воспроизведении на четверть часа - и заполнение
    # ВСТАЛО: плеер у владельца работает почти всё время, и за два часа студия
    # осталась на тех же 44 %.
    #
    # Поэтому не «редко», а «мелко»: пять строк раз в три минуты, пока играет
    # медиа, и десять раз в минуту, когда не играет. Это около сотни строк в
    # час даже при непрерывном просмотре - заполнение идёт, а декодеру нечего
    # заметить: пять ответов поставщика, обычно из его кеша.
    meta_playing = _media_loaded()
    meta_gap = TOPUP_META_PLAYING_SECONDS if meta_playing else TOPUP_META_SECONDS
    if now - _STATE.get('meta_ran_at', 0.0) < meta_gap:
        pass
    elif now >= _STATE.get('next_meta', 0.0):
        thread = _STATE.get('meta_thread')
        alive = bool(thread is not None and thread.is_alive())
        if alive and now - _STATE.get('meta_started', 0.0) > TOPUP_META_STUCK_SECONDS:
            alive = False
        if not alive:
            _STATE['next_meta'] = now + TOPUP_META_SECONDS
            _STATE['meta_started'] = now
            _STATE['meta_ran_at'] = now

            def _top_up_meta(portion=(TOPUP_META_PLAYING_LIMIT if meta_playing
                                      else 0)):
                try:
                    if portion:
                        builder.top_up_meta(limit=portion, cancel=stopping)
                    else:
                        builder.top_up_meta(cancel=stopping)
                except Exception as exc:
                    log('сведения не дописаны: %s' % exc, xbmc.LOGWARNING)

            try:
                fresh_meta = threading.Thread(target=_top_up_meta, daemon=True)
                fresh_meta.start()
                _STATE['meta_thread'] = fresh_meta
            except Exception as exc:
                log('поток сведений не запущен: %s' % exc, xbmc.LOGWARNING)
        else:
            _STATE['next_meta'] = now + 10

    # Очередь строк от дополнений (hub/row_store.py): списки окна «Видео» (Filmix, HDRezka)
    # просят собрать свои строки; собранное они при следующем показе берут готовым. Свой поток,
    # мелкими порциями. Во время просмотра тоже, но по две строки раз в 45 с (как дозаполнение
    # сведений): владелец листает хаб при играющем ТВ, и строки, на которые он смотрит, не собирались
    # вовсе - «Вествуд» на .20 часами без логотипа (22.11.2026).
    queue_playing = _media_loaded()
    if now >= _STATE.get('next_queue', 0.0):
        thread = _STATE.get('queue_thread')
        if thread is None or not thread.is_alive():
            _STATE['next_queue'] = now + (QUEUE_PLAYING_SECONDS if queue_playing else 15)
            queue_portion = QUEUE_PLAYING_LIMIT if queue_playing else 6

            def _build_queue():
                try:
                    from . import row_store
                    rows = row_store.take(queue_portion)
                    if not rows:
                        return
                    built, failed = {}, []
                    for row in rows:
                        if stopping():
                            return
                        try:
                            block = builder._enrich_one(dict(row), force=True)
                        except Exception as exc:
                            # причина - в журнал всегда: строку снимают из очереди, и без записи
                            # «Вествуд» на .20 пропадал молча (22.11.2026)
                            log('строка очереди не собрана: %s - %r' % (row.get('title') or row.get('label') or '', exc),
                                xbmc.LOGWARNING)
                            block = None
                        path = str(row.get('file') or '')
                        if block:
                            built[path] = block
                        else:
                            if block is not None:
                                log('строка очереди без данных: %s' % (row.get('title') or row.get('label') or ''),
                                    xbmc.LOGWARNING)
                            failed.append(path)
                    row_store.put_merged(built)
                    row_store.drop(failed)
                    if built:
                        log('очередь дополнений: собрано %d' % len(built), xbmc.LOGINFO)
                except Exception as exc:
                    log('очередь дополнений: %s' % exc, xbmc.LOGWARNING)
            try:
                worker = threading.Thread(target=_build_queue, daemon=True)
                worker.start()
                _STATE['queue_thread'] = worker
            except Exception as exc:
                log('поток очереди не запущен: %s' % exc, xbmc.LOGWARNING)

    # Живые вкладки хабов («Смотреть позже», «Избранное», «Продолжить просмотр») снимком не
    # зеркалятся - их содержимое обязано быть сегодняшним. Но их строки собирались, только когда
    # Kodi открывал список, то есть после первого захода в хаб (владелец, 22.11.2026). Теперь служба
    # сама запрашивает эти списки: дополнение при выдаче ставит несобранные строки в очередь
    # (row_store.attach / routes._attach_row_store), очередь собирает, и к заходу всё готово. Только
    # свои источники: чужие списки (рекомендации YouTube) от лишних запросов портят себе листание.
    if now >= _STATE.get('next_state_warm', 0.0):
        thread = _STATE.get('state_warm_thread')
        if thread is None or not thread.is_alive():
            playing_now = _media_loaded()
            _STATE['next_state_warm'] = now + (STATE_WARM_PLAYING_SECONDS if playing_now
                                               else STATE_WARM_SECONDS)
            def _warm_state():
                try:
                    asked = 0
                    for src in sorted(_live_sources()):
                        # пульт здесь не помеха: запросы лёгкие, а после запуска Kodi простой
                        # всегда нулевой, и проход обрывался до первой вкладки (.30, 22.11.2026)
                        if stopping():
                            return
                        # все вкладки хабов из своих источников - и живые, и каталожные: первый
                        # заход в хаб иначе ждал холодную выдачу 3,7 с (замер .30, 22.11.2026)
                        # поиск - никогда: пустой запрос открывал клавиатуру и вешал проход (.30)
                        low = src.lower()
                        if (src.startswith(STATE_WARM_ADDONS) and 'search' not in low
                                and 'keyword=' not in low and 'text=' not in low):
                            if mirror.fetch(src):
                                asked += 1
                    if asked:
                        log('вкладки хабов запрошены в фоне: %d' % asked)
                except Exception as exc:
                    log('живые вкладки не запрошены: %s' % exc, xbmc.LOGWARNING)

            try:
                warm = threading.Thread(target=_warm_state, daemon=True)
                warm.start()
                _STATE['state_warm_thread'] = warm
            except Exception as exc:
                log('поток живых вкладок не запущен: %s' % exc, xbmc.LOGWARNING)

    # Готовые выдачи вкладок хабов (hub/listing_cache.py): пересобираются в фоне, как только
    # изменились их входы, - открытие хаба и вкладки отдаёт готовое без пересчёта (22.11.2026).
    if now >= _STATE.get('next_listings', 0.0):
        thread = _STATE.get('listings_thread')
        if thread is None or not thread.is_alive():
            _STATE['next_listings'] = now + (LISTINGS_PLAYING_SECONDS if _media_loaded()
                                             else LISTINGS_SECONDS)

            def _render_listings():
                try:
                    from . import listing_cache
                    done = listing_cache.refresh_all(_live_sources(), cancel=stopping)
                    if done:
                        log('готовые выдачи вкладок пересобраны: %d' % done)
                except Exception as exc:
                    log('готовые выдачи не собраны: %s' % exc, xbmc.LOGWARNING)

            try:
                lt = threading.Thread(target=_render_listings, daemon=True)
                lt.start()
                _STATE['listings_thread'] = lt
            except Exception as exc:
                log('поток готовых выдач не запущен: %s' % exc, xbmc.LOGWARNING)

    # Своя лента подписок YouTube: дополнение строит её из ленты RSS, а YouTube
    # отдаёт на ту 404 (hub/youtube_subs.py - там замеры и открытая тема в
    # форуме Google).
    #
    # СВОЙ ПОТОК, и это главное здесь. Раньше проход шёл прямо в такте, то есть
    # НА ТОМ ЖЕ потоке, который замечает смену фокуса и публикует строку.
    # Замер на .20 05.09.2026 по журналу: между 09:46:10 и 09:49:35 поток
    # службы не сделал ни одной записи - 204.7 с внутри одного прохода, - и
    # ровно в конце этого разрыва он впервые увидел, что строка давно другая
    # («bg-trace строка сменилась: 501|Назначение» в 09:49:35.9). Владелец всё
    # это время смотрел на фон и дату от прошлой строки, чужой ленты YouTube,
    # поверх названия и описания нового фильма: «залипший фон в фокусе», «висел
    # больше минуты». В предыдущем журнале то же самое дважды: 136.1 с и 60.3 с,
    # и оба разрыва тоже заканчиваются строкой этого прохода.
    #
    # Работа тут вся в сети (плейлист загрузок канала - 1.5-14 с, плюс
    # HEAD-запросы за крупной обложкой), ускорить её нечем. Но держать на ней
    # публикацию незачем: снимок каждого канала хранится отдельно, склейка
    # берёт общий замок (youtube_subs._FEED_LOCK), и такту ждать нечего.
    # Заявка от запроса виджета идёт вперёд часов и вперёд гейтов по занятости:
    # человек открыл хаб, значит лента нужна ему сейчас, а не через десять минут
    # и не «когда пульт помолчит минуту». Саму заявку ставит
    # youtube_subs.refresh_if_stale - там же, почему это заявка, а не поток.
    if _serve_subs_request(now):
        did = True

    if now >= _STATE.get('next_subs', 0.0):
        thread = _STATE.get('subs_thread')
        alive = bool(thread is not None and thread.is_alive())
        if alive and now - _STATE.get('subs_started', 0.0) > SUBS_STUCK_SECONDS:
            log('подписки YouTube: прошлый поток сбора работает уже %d с - '
                'запускаю новый' % int(now - _STATE.get('subs_started', 0.0)),
                xbmc.LOGWARNING)
            alive = False
        if alive:
            _STATE['next_subs'] = now + 10
        elif _remote_busy():
            # Пульту уступаем всегда, но это не стоит десяти минут: первая
            # версия двигала часы до проверки, и на .20 04.09.2026 первый же
            # такт пришёлся на работу с пультом - сбор отодвинулся на десять
            # минут, а владелец смотрел на пустую полосу и спрашивал «ну что?».
            _STATE['next_subs'] = now + 60
        else:
            playing = _media_loaded()
            _STATE['next_subs'] = now + (SUBS_PLAYING_SECONDS if playing
                                         else SUBS_SECONDS)
            _STATE['subs_started'] = now

            def _refresh_subs(playing=playing):
                try:
                    done, _total = youtube_subs.refresh(
                        cancel=_remote_busy,
                        budget=(SUBS_BUDGET_PLAYING if playing
                                else SUBS_BUDGET))
                    if done:
                        log('подписки YouTube: проход %s'
                            % ('во время воспроизведения' if playing
                               else 'на покое'), xbmc.LOGDEBUG)
                except Exception as exc:
                    log('подписки YouTube не обновлены: %s' % exc,
                        xbmc.LOGWARNING)

            try:
                fresh_subs = threading.Thread(target=_refresh_subs, daemon=True)
                fresh_subs.start()
                _STATE['subs_thread'] = fresh_subs
            except Exception as exc:
                log('подписки YouTube: поток сбора не запущен: %s' % exc,
                    xbmc.LOGWARNING)

    # The rows of every widget actually wired to the mirror are kept fresh here,
    # and nothing else is touched: a route nobody mirrored is never asked in the
    # background. That distinction is the lesson from the preloader, which asked
    # them all and disturbed the YouTube recommendations widget's own paging.
    try:
        store_m = None
        last_m = 0.0
        try:
            from .store import db as _mdb
            store_m = _mdb()
            last_m = float(store_m.get_flag(MIRROR_STAMP_FLAG) or 0)
        except Exception:
            last_m = 0.0
        # Воспроизведение больше не запрещает проход, а только разрежает его:
        # пока медиа загружено, интервал часовой вместо четвертьчасового.
        # Уступать пульту обязательно в любом случае - там владелец ждёт
        # отклика сейчас, - но проход при этом не откладывается, а идёт
        # медленнее (builder.REMOTE_ROW_PAUSE); ждёт он только паузы Sublime.Hold.
        playing = _media_loaded()
        need = (MIRROR_REFRESH_PLAYING_SECONDS if playing
                else MIRROR_REFRESH_SECONDS)
        if now - last_m >= need and not _held():
            # Not merely re-asked: BUILT. Every row gets its background, colour,
            # logo and identity written into it, so that when focus lands there
            # is nothing left to compute - see hub/builder.py. This is what
            # replaced hub/warm.py and hub/preload.py.
            sources = mirror_wire.sources()
            builder.playback_tolerant(playing)
            try:
                done = builder.build_all(sources) + builder.build_ours()
            finally:
                # Терпимость снимается всегда, даже если проход упал: иначе она
                # осталась бы включённой на весь сеанс и следующий проход
                # работал бы при просмотре без спроса.
                builder.playback_tolerant(False)
            if store_m is not None:
                store_m.set_flag(MIRROR_STAMP_FLAG, str(int(now)))
            if done:
                log('зеркало виджетов: собрано строк %d в %d виджетах%s'
                    % (done, len(sources), ' (во время воспроизведения)'
                       if playing else ''))
                did = True
    except Exception as exc:
        log('зеркало виджетов не обновлено: %s' % exc, xbmc.LOGWARNING)

    if now < _STATE['next_tick']:
        return False
    _STATE['next_tick'] = now + TICK_SECONDS
    if not get_bool('auto_refresh', True):
        return False
    # Пульту уступаем всегда. Загруженное медиа больше не значит «никогда»: оно
    # только разрежает пересчёт до раза в час - см. CATALOG_PLAYING_SECONDS.
    if _remote_busy():
        return False
    if _media_loaded():
        last_catalog = 0.0
        try:
            from .store import db as _cdb
            last_catalog = float(_cdb().get_flag(CATALOG_PLAYING_FLAG) or 0)
        except Exception:
            last_catalog = 0.0
        if now - last_catalog < CATALOG_PLAYING_SECONDS:
            return False
        try:
            from .store import db as _cdb2
            _cdb2().set_flag(CATALOG_PLAYING_FLAG, str(int(now)))
        except Exception:
            pass

    try:
        if sync.enabled():
            _sync_in_background()
    except Exception as exc:
        log('обмен не удался: %s' % exc, xbmc.LOGWARNING)


    # The shared history carries rows without a path, and those can never be
    # applied on any box - see hub/repair.py. One bounded slice per day, while
    # the box is quiet, until there is nothing left to repair.
    try:
        from . import repair
        from .store import db as _db
        last = int(_db().get_flag(repair.DONE_FLAG) or 0)
        if now - last > 24 * 3600:
            repair.run()
    except Exception as exc:
        log('восстановление путей не выполнено: %s' % exc, xbmc.LOGWARNING)

    try:
        if catalog.refresh_vocabulary_if_stale(_max_age()):
            log('словарь каталога пересчитан')
            did = True
    except Exception as exc:
        log('словарь не пересчитан: %s' % exc, xbmc.LOGWARNING)

    for category in CATEGORIES:
        if _remote_busy():
            return did
        try:
            stale = [name for name in lanes.LANES
                     if lanes.LANES[name][0] == category
                     and lanes.is_stale(name, _max_age())]
            if stale:
                log('плановое обновление полос: %s' % category)
                lanes.build_lanes(category)
                _build_new_rows(category)
                did = True
        except Exception as exc:
            log('полосы %s не собраны: %s' % (category, exc), xbmc.LOGWARNING)

    for category in CATEGORIES:
        if _remote_busy():
            return did
        try:
            if (recommend.is_stale(category, _max_age())
                    and not recommend.blocked_recently(category)):
                log('плановое обновление: %s' % category)
                recommend.refresh_category(category)
                did = True
        except Exception as exc:
            log('рекомендации %s не собраны: %s' % (category, exc), xbmc.LOGWARNING)
    return did
