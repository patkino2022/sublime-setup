"""Upstream HTTP for the streamer: kept-alive connections and a DNS cache.

A channel switch costs DNS + TCP (+TLS) for the redirect, the master playlist,
the media playlist and every segment. Reusing connections and answers removes
most of that. The DNS cache also keeps the last good address when the router
stops resolving names (seen on <роутер>), so a playing stream survives it.
"""
import http.client
import socket
import ssl
import threading
import time
from urllib.parse import urljoin, urlsplit

DNS_TTL = 600
_dns, _dns_lock = {}, threading.Lock()
_pool, _pool_lock = {}, threading.Lock()
from . import tls

tls.install()
_ctx = tls.context()
# Stream hosts whose certificate chain python cannot verify (RTV Bap's streamlock
# server sends an incomplete chain, 20.10.2026). Only this module talks to them,
# and only for video: such a host is retried once without verification.
_noverify = tls.context()
_noverify.check_hostname = False
_noverify.verify_mode = ssl.CERT_NONE
_insecure = set()
# Session cookies per host: TV Marsh answers 302 ?cookieCheck=1 + Set-Cookie
# hlsSession and 401 to every request without it.
_cookies, _cookie_lock = {}, threading.Lock()


class HttpError(OSError):
    def __init__(self, code, url):
        super().__init__("HTTP %s" % code)
        self.code = code
        self.url = url


def resolve(host, port):
    now = time.time()
    with _dns_lock:
        hit = _dns.get(host)
    if hit and now - hit[1] < DNS_TTL:
        return hit[0]
    try:
        addrs = [a[4][0] for a in socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_STREAM)]
    except OSError:
        if hit:
            return hit[0]   # stale but known: better than no stream
        raise
    with _dns_lock:
        _dns[host] = (addrs, now)
    return addrs


class _Conn(http.client.HTTPConnection):
    def connect(self):
        err = None
        for ip in resolve(self.host, self.port):
            try:
                self.sock = socket.create_connection((ip, self.port), self.timeout)
                self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                return
            except OSError as e:
                err = e
        raise err or OSError("no address")


class _TlsConn(_Conn):
    default_port = 443

    def connect(self):
        super().connect()
        ctx = _noverify if self.host in _insecure else _ctx
        self.sock = ctx.wrap_socket(self.sock, server_hostname=self.host)


def _take(key, timeout):
    with _pool_lock:
        idle = _pool.get(key) or []
        while idle:
            conn, t = idle.pop()
            if time.time() - t < 30:
                conn.timeout = timeout
                if conn.sock:
                    conn.sock.settimeout(timeout)
                return conn
            conn.close()
    scheme, host, port = key
    cls = _TlsConn if scheme == "https" else _Conn
    return cls(host, port, timeout=timeout)


def _give(key, conn):
    with _pool_lock:
        lst = _pool.setdefault(key, [])
        if len(lst) < 4:
            lst.append((conn, time.time()))
            return
    conn.close()


class Response:
    """Open response; read() then close() returns the connection to the pool."""

    def __init__(self, key, conn, resp, url):
        self.key, self.conn, self.resp, self.url = key, conn, resp, url
        self.headers = resp.headers
        self.status = resp.status

    def read(self, n=-1):
        return self.resp.read(n) if n >= 0 else self.resp.read()

    def close(self, reuse=True):
        if reuse and self.resp.isclosed() and not self.resp.will_close:
            _give(self.key, self.conn)
        else:
            self.conn.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close(reuse=a[0] is None)


def _headers(ua):
    h = {"User-Agent": ua} if isinstance(ua, str) else dict(ua)
    h.setdefault("Accept", "*/*")
    h.setdefault("Accept-Encoding", "identity")   # ZICO TV gzips otherwise
    h["Connection"] = "keep-alive"
    return h


def open_url(url, ua, timeout, redirects=5):
    """ua: a User-Agent string, or a dict of request headers (per-channel
    Referer/Origin/User-Agent from #EXTVLCOPT)."""
    hdrs = _headers(ua)
    for _ in range(redirects + 1):
        u = urlsplit(url)
        scheme = u.scheme or "http"
        port = u.port or (443 if scheme == "https" else 80)
        key = (scheme, u.hostname, port)
        path = (u.path or "/") + ("?" + u.query if u.query else "")
        req = dict(hdrs)
        with _cookie_lock:
            jar = _cookies.get(u.hostname)
            if jar:
                req["Cookie"] = "; ".join("%s=%s" % kv for kv in jar.items())
        for attempt in (0, 1, 2):
            conn = _take(key, timeout)
            fresh = conn.sock is None
            try:
                conn.request("GET", path, headers=req)
                resp = conn.getresponse()
                break
            except ssl.SSLCertVerificationError:
                conn.close()
                if u.hostname in _insecure or attempt == 2:
                    raise
                _insecure.add(u.hostname)
            except (http.client.HTTPException, OSError):
                conn.close()
                if fresh or attempt:
                    raise
                # a pooled connection the server already closed: retry once on a new one
        _keep_cookies(u.hostname, resp)
        if resp.status in (301, 302, 303, 307, 308) and resp.headers.get("Location"):
            resp.read()
            Response(key, conn, resp, url).close()
            url = urljoin(url, resp.headers["Location"])
            continue
        if resp.status >= 400:
            resp.read(65536)
            conn.close()
            raise HttpError(resp.status, url)
        return Response(key, conn, resp, url)
    raise HttpError(310, url)


def _keep_cookies(host, resp):
    for raw in resp.headers.get_all("Set-Cookie") or ():
        pair = raw.split(";", 1)[0]
        if "=" in pair:
            k, v = pair.split("=", 1)
            with _cookie_lock:
                _cookies.setdefault(host, {})[k.strip()] = v.strip()


def get_text(url, ua, timeout, limit=2 * 1024 * 1024):
    with open_url(url, ua, timeout) as r:
        return r.read(limit).decode("utf-8", "replace"), r.url
