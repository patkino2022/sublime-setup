# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import re

# Manual metadata overrides for Filmix posts where automatic TMDb title fallback
# produced a valid-but-wrong TMDb identity.  These overrides are intentionally
# tiny and only touch the exact known Filmix series; the normal resolver,
# ListItem builder, art fallback, playback, resume and routes are not
# changed.

ART_KEYS = (
    'resolved_fanart', 'resolved_landscape', 'resolved_backdrop',
    'resolved_poster', 'resolved_clearlogo', 'resolved_logo',
    'fanart', 'landscape', 'backdrop', 'backdrop_path', 'clearlogo',
    'clearart', 'logo', 'tmdb_fanart', 'tmdb_landscape', 'tmdb_backdrop',
    'tmdb_poster', 'tmdb_clearlogo', 'tmdb_logo', 'art',
)
ID_KEYS = (
    'resolved_tmdb_id', 'tmdb_id', 'tmdb',
    'resolved_imdb_id', 'imdb_id', 'imdb',
    'resolved_tmdb_type', 'tmdb_type',
)

OVERRIDES = {
    '183264': {
        'key': 'rooster_2026',
        'title_tokens': ('petuh', 'rooster', 'петух', 'боевой петух'),
        'alt_tokens': ('petuh-2026', 'rooster-2026'),
        'resolved_tmdb_id': '254953',
        'resolved_imdb_id': 'tt32420734',
        'resolved_tmdb_type': 'tv',
        'resolved_year': 2026,
        'resolved_premiered': '2026-03-08',
    },
    '181358': {
        'key': 'tvrdjava_2025',
        'title_tokens': ('крепость', 'tvrdjava', 'tvrđava', 'tvrdava', 'fortress'),
        'alt_tokens': ('tvrdjava-2025', 'tvrdava-2025', 'krepost-2025'),
        'resolved_tmdb_id': '306425',
        'resolved_imdb_id': 'tt34377374',
        'resolved_tmdb_type': 'tv',
        'resolved_year': 2025,
        'resolved_premiered': '2025-11-14',
    },
    '182440': {
        'key': 'zvaces_se_varvara_2026',
        'title_tokens': ('меня зовут варвара', 'её зовут варвара', 'ее зовут варвара',
                         'zvaces se varvara', 'zvaćeš se varvara', 'the name is varvara'),
        'alt_tokens': ('menya-zovut-varvara-2026', 'zvaces-se-varvara'),
        'resolved_tmdb_id': '290278',
        'resolved_imdb_id': 'tt33984346',
        'resolved_tmdb_type': 'tv',
        'resolved_year': 2026,
        'resolved_premiered': '2026-01-10',
    },
}


def _norm(value):
    if value is None:
        return ''
    try:
        value = str(value)
    except Exception:
        return ''
    value = value.lower()
    value = value.replace('ć', 'c').replace('č', 'c').replace('đ', 'dj').replace('š', 's').replace('ž', 'z')
    value = value.replace('ё', 'е')
    value = re.sub(r'[^0-9a-zа-я]+', ' ', value, flags=re.UNICODE)
    return re.sub(r'\s+', ' ', value, flags=re.UNICODE).strip()


def find_manual_override(payload=None, post_id=None):
    pid = str(post_id or '')
    if payload and isinstance(payload, dict):
        pid = pid or str(payload.get('id') or payload.get('post_id') or '')
    if pid in OVERRIDES:
        return OVERRIDES[pid]
    if not isinstance(payload, dict):
        return None
    hay = ' '.join([
        _norm(payload.get('title')),
        _norm(payload.get('original_title')),
        _norm(payload.get('alt_name')),
        _norm(payload.get('post_url')),
    ])
    year = str(payload.get('year') or payload.get('resolved_year') or '')
    for ov in OVERRIDES.values():
        if year and str(ov.get('resolved_year')) != year:
            continue
        for token in list(ov.get('title_tokens') or ()) + list(ov.get('alt_tokens') or ()):
            if _norm(token) and _norm(token) in hay:
                return ov
    return None


def apply_manual_override(payload, hint=None, post_id=None):
    """Return payload copy with the known-correct IDs and no stale TMDb art.

    The function is deliberately conservative: only exact post_id or very strict
    title/year matches are changed. It does not touch Filmix title, plot, poster,
    playback links, watched/resume markers or menu fields.
    """
    if not isinstance(payload, dict):
        return payload, False
    ov = find_manual_override(payload, post_id=post_id)
    if ov is None and isinstance(hint, dict):
        ov = find_manual_override(hint, post_id=post_id)
    if ov is None:
        return payload, False
    data = dict(payload)
    for key in ART_KEYS:
        data.pop(key, None)
    # Preserve Filmix poster if present under normal poster/thumb keys.
    # Remove only TMDb identity/art and then write the correct identity.
    for key in ID_KEYS:
        data.pop(key, None)
    data.update({
        'resolved_tmdb_id': str(ov['resolved_tmdb_id']),
        'tmdb_id': str(ov['resolved_tmdb_id']),
        'resolved_imdb_id': str(ov['resolved_imdb_id']),
        'imdb_id': str(ov['resolved_imdb_id']),
        'resolved_tmdb_type': 'tv',
        'tmdb_type': 'tv',
        'resolved_year': ov.get('resolved_year'),
        'resolved_premiered': ov.get('resolved_premiered'),
        'first_air_date': ov.get('resolved_premiered'),
        '_filmix_manual_override': ov.get('key'),
        '_filmix_resolve_source': 'manual_override',
        '_filmix_resolve_trust': '100',
    })
    return data, True


def apply_manual_overrides_to_cache(cache, log_func=None):
    """Persist the three correct resolved_ids rows and sanitize cached posts.

    This is safe to run on every startup. It does not delete cache4.db and does
    not clear metadata globally.
    """
    changed = 0
    for pid, ov in OVERRIDES.items():
        try:
            current = cache.get_resolved_ids(pid) or {}
            fixed, touched = apply_manual_override(current, post_id=pid)
            # Ensure a minimal row exists even if current was empty.
            if not touched:
                fixed = {}
                fixed, touched = apply_manual_override(fixed, post_id=pid)
            cache.set_resolved_ids(pid, fixed)
            changed += 1
        except Exception as e:
            if log_func:
                log_func('resolved_ids post_id={0} failed: {1}'.format(pid, e))
        try:
            post = cache.get_post_details(pid)
            if isinstance(post, dict):
                fixed_post, touched_post = apply_manual_override(post, post_id=pid)
                if touched_post:
                    # Restore Filmix poster/thumb fields if they existed; apply_manual_override
                    # removes only art fields, but poster is not in ART_KEYS.
                    cache.set_post_details(pid, fixed_post)
                    changed += 1
        except Exception as e:
            if log_func:
                log_func('post_details post_id={0} failed: {1}'.format(pid, e))
    return changed
