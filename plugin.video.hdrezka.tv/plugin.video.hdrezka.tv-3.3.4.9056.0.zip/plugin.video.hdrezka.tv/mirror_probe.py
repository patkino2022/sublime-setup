# -*- coding: utf-8 -*-
"""Проба зеркала HDRezka - та же, что у установщика (sublime-box/installer/install.py,
MIRROR_PROBE): страница /films/ с проходом Anubis. 'open' - каталог виден гостю, 'login' -
зеркало для зарегистрированных (страница входа), 'closed' - отказ или бан адреса."""

import hashlib, json, re, sys, urllib.parse, urllib.request
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36'
def get(url, jar):
    h = {'User-Agent': UA}
    if jar:
        h['Cookie'] = '; '.join('%s=%s' % kv for kv in jar.items())
    try:
        r = urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=15)
        code, body, hdrs = r.status, r.read(), r.headers
    except urllib.error.HTTPError as e:
        code, body, hdrs = e.code, e.read(), e.headers
    except Exception:
        return 0, ''
    for c in hdrs.get_all('Set-Cookie') or []:
        k, _, v = c.split(';')[0].partition('=')
        jar[k.strip()] = v.strip()
    if body[:2] == b'\x1f\x8b':
        import gzip
        body = gzip.decompress(body)
    return code, body.decode('utf-8', 'replace')
def pow_(data, diff):
    n = 0
    while True:
        d = hashlib.sha256((data + str(n)).encode()).digest()
        if all(b == 0 for b in d[:diff // 2]) and (not diff % 2 or d[diff // 2] >> 4 == 0):
            return d.hex(), n
        n += 1
def rezka(domain):
    jar = {}
    base = 'https://' + domain
    code, text = get(base + '/films/', jar)
    m = re.search(r'id=["\']anubis_challenge["\'][^>]*>(.{0,10000}?)</', text, re.S)
    if m:
        try:
            ch = json.loads(m.group(1))['challenge']
            h, n = pow_(ch['randomData'], ch['difficulty'])
            get(base + '/.within.website/x/cmd/anubis/api/pass-challenge?' + urllib.parse.urlencode(
                {'id': ch['id'], 'response': h, 'nonce': n, 'elapsedTime': 60, 'redir': '/'}), jar)
            code, text = get(base + '/films/', jar)
        except Exception:
            return 'error'
    head = text[:4000]
    if code == 200 and 'b-content__inline_item"' in text:
        return 'open'
    if code == 200 and '<title>Вход' in head:
        return 'login'
    return 'closed'
