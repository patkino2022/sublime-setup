# -*- coding: utf-8 -*-
from __future__ import absolute_import, unicode_literals

"""Generate a localized transparent title-logo when providers have no matching logo."""

import hashlib
import os
import re
import tempfile

try:
    from PIL import Image, ImageDraw, ImageFont
except Exception:
    Image = ImageDraw = ImageFont = None

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

_CACHE_URI = 'special://profile/addon_data/skin.sublime/title_logos_v2/'
_CANVAS = (1600, 360)
_MARGIN_X = 36
_MARGIN_Y = 24


def _translate(path):
    try:
        return xbmcvfs.translatePath(path) if xbmcvfs else path
    except Exception:
        return path


def _font_path():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir, os.pardir))
    for filename in ('Manrope-Regular.ttf', 'Manrope-Light.ttf'):
        path = os.path.join(root, 'fonts', filename)
        if os.path.isfile(path):
            return path
    return ''


def _clean_title(value):
    value = re.sub(r'\s+', ' ', str(value or '')).strip()
    # вид релиза в скобках («[BDRip 1080+]») - не часть названия: логотип рисовался вместе с ним
    # (Filmix «Смотреть позже», 21.11.2026)
    value = re.sub(r'\s*\[[^\]]*(?:rip|web|bd|hd|uhd|4k|2160|1080|720|480|cam|ts)[^\]]*\]\s*$', '', value,
                   flags=re.I).strip() or value
    return value[:140]


def _measure(draw, text, font):
    bbox = draw.textbbox((0, 0), text, font=font, stroke_width=1)
    return max(1, bbox[2] - bbox[0]), max(1, bbox[3] - bbox[1])


def _wrap_two_lines(title):
    """Split a title into two balanced lines on a word boundary."""
    words = title.split()
    if len(words) < 2:
        return [title]
    best = None
    for i in range(1, len(words)):
        first = ' '.join(words[:i])
        second = ' '.join(words[i:])
        diff = abs(len(first) - len(second))
        if best is None or diff < best[0]:
            best = (diff, [first, second])
    return best[1]


def _fit_lines(draw, lines, font_path, max_width, max_height):
    """Largest font (and its size) at which all lines fit the box."""
    gap = 10
    for size in range(230, 35, -4):
        try:
            font = ImageFont.truetype(font_path, size=size)
        except Exception:
            return None, 0
        widths = []
        line_h = 0
        for line in lines:
            w, h = _measure(draw, line, font)
            widths.append(w)
            line_h = max(line_h, h)
        total_h = line_h * len(lines) + gap * (len(lines) - 1)
        if max(widths) <= max_width and total_h <= max_height:
            return font, size
    return ImageFont.truetype(font_path, size=36), 36


def request_title_logo(title, language=''):
    """Return a cached transparent PNG path for a localized title.

    Long titles are laid out on up to two lines so the text stays large instead of
    shrinking to a tiny single line.
    """
    title = _clean_title(title)
    if not title or not Image or not ImageDraw or not ImageFont:
        return ''
    font_path = _font_path()
    if not font_path:
        return ''
    digest = hashlib.sha1(('%s|%s|v3' % (language or '', title)).encode('utf-8', 'ignore')).hexdigest()
    folder = _translate(_CACHE_URI)
    destination = os.path.join(folder, digest + '.png')
    if os.path.isfile(destination) and os.path.getsize(destination) > 100:
        return destination
    try:
        os.makedirs(folder, exist_ok=True)
        image = Image.new('RGBA', _CANVAS, (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)
        max_w = _CANVAS[0] - 2 * _MARGIN_X
        max_h = _CANVAS[1] - 2 * _MARGIN_Y
        # One line first; if it forces a small font, try two balanced lines.
        lines = [title]
        font, size = _fit_lines(draw, lines, font_path, max_w, max_h)
        if size < 120 and len(title.split()) > 1:
            two = _wrap_two_lines(title)
            if len(two) == 2:
                font2, size2 = _fit_lines(draw, two, font_path, max_w, max_h)
                if size2 > size:
                    lines, font, size = two, font2, size2
        if not font:
            return ''
        gap = 10
        line_h = max(_measure(draw, line, font)[1] for line in lines)
        block_h = line_h * len(lines) + gap * (len(lines) - 1)
        y = (_CANVAS[1] - block_h) // 2
        for line in lines:
            bbox = draw.textbbox((0, 0), line, font=font, stroke_width=1)
            x = _MARGIN_X - bbox[0]
            draw.text(
                (x, y - bbox[1]), line, font=font,
                fill=(255, 255, 255, 255),
                stroke_width=1, stroke_fill=(0, 0, 0, 110),
            )
            y += line_h + gap
        # Crop transparent margins while preserving a small safety pad.
        alpha = image.getchannel('A')
        crop = alpha.getbbox()
        if crop:
            left = max(0, crop[0] - 12)
            top = max(0, crop[1] - 12)
            right = min(_CANVAS[0], crop[2] + 12)
            bottom = min(_CANVAS[1], crop[3] + 12)
            image = image.crop((left, top, right, bottom))
        fd, tmp = tempfile.mkstemp(prefix=digest + '.', suffix='.tmp', dir=folder)
        os.close(fd)
        image.save(tmp, 'PNG', optimize=True)
        os.replace(tmp, destination)
        tmp = ''
        return destination
    except Exception:
        try:
            if 'tmp' in locals() and tmp and os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return ''
