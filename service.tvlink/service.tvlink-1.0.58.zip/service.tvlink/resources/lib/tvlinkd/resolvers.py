"""Streams whose address the broadcaster hands out per visitor.

A playlist line `resolve:<site>:<id>` is turned into the real URL right before
the stream starts (and cached for a few minutes).

rtsplaneta: RTS's own site. Its anonymous demo session gets only RTS Svet
(video 16889); signed in, every RTS channel (RTS 1/2/3, Drama, Život, Kolo,
Muzika, Poletarac, Nauka, Trezor, Klasika) is plain HLS (TS segments, no
EXT-X-KEY) behind the site's cenc_manifest.mpd asked as playlist.m3u8 - checked
in a signed-in browser, 20.10.2026.

How the site signs in: every device has a uuid and always logs in with
username = password = uuid. Signing in with Google or e-mail happens on the
site's /obw page and binds THAT uuid to the account; the same API login then
returns a full session (is_demo_user empty) instead of the demo one. So each box
keeps one uuid (<userdata>/rtsplaneta.json) and the owner binds it once on /obw
in a browser that uses the box's uuid. No password is stored.
"""
import hashlib
import json
import os
import threading
import time
import urllib.error
import urllib.request

TTL = 300
SESSION_TTL = 6 * 3600
_cache, _lock = {}, threading.Lock()
_session = {}
API = "https://rtsplaneta.rs/client_api.php"
ROOT = None          # userdata dir, set by the daemon


class LoginFailed(Exception):
    pass


def _call(method, url, body, ua):
    req = urllib.request.Request(url, data=json.dumps(body).encode() if body is not None else None,
                                 method=method, headers={"Content-Type": "application/json", "User-Agent": ua,
                                                         "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read(1024 * 1024).decode("utf-8", "replace"))


def _find(obj, key):
    """First value of `key` anywhere in a nested JSON answer."""
    if isinstance(obj, dict):
        if key in obj and obj[key] not in (None, ""):
            return obj[key]
        obj = list(obj.values())
    if isinstance(obj, list):
        for v in obj:
            r = _find(v, key)
            if r not in (None, ""):
                return r
    return None


def _state_path():
    return os.path.join(ROOT, "rtsplaneta.json") if ROOT else None


def device_uuid(ua):
    """This box's uuid on the site, created once and kept."""
    p = _state_path()
    try:
        with open(p, encoding="utf-8") as f:
            u = json.load(f).get("uuid")
        if u:
            return u
    except (OSError, ValueError, TypeError):
        pass
    u = _find(_call("POST", API + "/config/identify/format/json", {"application_publication_id": "web"}, ua), "uuid")
    if p:
        tmp = p + ".part"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump({"uuid": u}, f)
        os.replace(tmp, p)
    return u


def _login(ua):
    """(session_id, access_token, signed_in), cached. signed_in is False while
    the box's uuid is not bound to an account (demo session: RTS Svet only)."""
    with _lock:
        if _session and time.time() - _session["at"] < SESSION_TTL:
            return _session["sid"], _session["access"], _session["signed"]
    uuid = device_uuid(ua)
    sid = _find(_call("PUT", API + "/config/identify/format/json", {"uuid": uuid}, ua), "session_id")
    try:
        login = _call("POST", API + "/user/login/session_id/%s/format/json" % sid,
                      {"username": uuid, "password": uuid}, ua)
    except urllib.error.HTTPError as e:
        raise LoginFailed("login refused (HTTP %s)" % e.code)
    token = _find(login, "session_token")
    if not token:
        raise LoginFailed("login refused: %s" % (_find(login, "message") or "no token"))
    signed = not _find(login, "is_demo_user")
    access = hashlib.sha1((uuid + token).encode()).hexdigest()
    with _lock:
        _session.update(sid=sid, access=access, signed=signed, at=time.time())
    _remember(signed)
    return sid, access, signed


def _remember(signed):
    """Keep in rtsplaneta.json whether the box was ever bound and is bound now,
    so the Kodi side can tell the owner when a binding is lost."""
    p = _state_path()
    if not p:
        return
    try:
        with open(p, encoding="utf-8") as f:
            st = json.load(f)
    except (OSError, ValueError):
        return
    new = dict(st, signed=bool(signed), checked=int(time.time()))
    if signed:
        new["bound_once"] = True
    if new == st:
        return
    tmp = p + ".part"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(new, f)
    os.replace(tmp, p)


def recheck(ua):
    """Daemon calls this every few hours: a fresh login shows whether the
    binding still holds even when nobody watches RTS."""
    if not os.path.exists(_state_path() or ""):
        return
    with _lock:
        _session.clear()
    try:
        _login(ua)
    except Exception:
        pass


def set_uuid(uuid):
    """The owner pastes the device code of a browser where they signed in."""
    p = _state_path()
    tmp = p + ".part"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump({"uuid": uuid.strip(), "bound_once": False}, f)
    os.replace(tmp, p)
    with _lock:
        _session.clear()
        _cache.clear()


def status(ua):
    """For the /setup page: (uuid, signed_in, text)."""
    with _lock:
        _session.clear()
    try:
        _, _, signed = _login(ua)
        return device_uuid(ua), signed, ("коробка привязана к аккаунту - все каналы RTS доступны" if signed
                                        else "коробка не привязана - доступен только RTS Svet")
    except Exception as e:
        return None, False, "ошибка: %s" % e


def _rtsplaneta(video_id, ua):
    sid, access, signed = _login(ua)
    got = _call("GET", API + "/video/get_streaming_url/session_id/%s/access_token/%s/video_id/%s/format/json"
                % (sid, access, video_id), None, ua)
    url = _find(got, "url")
    if not url:
        with _lock:
            _session.clear()      # a stale session answers without url: sign in again next time
        raise ValueError("rtsplaneta: no url for video %s" % video_id)
    if "promo" in url.lower():
        raise ValueError("rtsplaneta: video %s needs a signed-in account (got the promo clip)" % video_id)
    return url.replace("cenc_manifest.mpd", "playlist.m3u8")


RUTUBE_API = "https://rutube.ru/api/play/options/%s/?no_404=true&referer=https%%3A%%2F%%2Frutube.ru"


def _rutube(video_id, ua):
    """Прямой эфир RuTube: адрес HLS из play/options. Подпись в нём долгая и к адресу
    зрителя не привязана (проверено 16.11.2026 с домашнего адреса и через WARP), но
    RuTube может её сменить - поэтому адрес берётся заново при каждом запуске."""
    got = _call("GET", RUTUBE_API % video_id, None, ua)
    hls = (got.get("live_streams") or {}).get("hls") or []
    url = hls[0].get("url") if hls else None
    if not url:
        raise ValueError("rutube: no live stream for %s (%s)" % (
            video_id, (got.get("acl_access") or {}).get("err_text") or got.get("detail") or "offline"))
    return url


SITES = {"rutube": _rutube}


def resolve(url, ua):
    if not url.startswith("resolve:"):
        return url
    with _lock:
        hit = _cache.get(url)
    if hit and time.time() - hit[1] < TTL:
        return hit[0]
    _, site, arg = url.split(":", 2)
    real = SITES[site](arg, ua)
    with _lock:
        _cache[url] = (real, time.time())
    return real


def forget(url):
    with _lock:
        _cache.pop(url, None)
