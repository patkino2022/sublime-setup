# -*- coding: utf-8 -*-
"""Результаты поиска любого дополнения, собранные как строки хабов.

Окно поиска брало списки прямо у дополнений (Filmix, RuTor, YouTube), и всё, что рисуется
вокруг карточки - фон, цвет подложки, логотип, оценки, жанр, - ждало службу скина. Она
описывает карточку на своём такте, поэтому после шага на экране стоял фон прошлой карточки,
потом пусто, потом свой (.20, 21.11.2026). Владелец: «сделай точно так же, как в главных
хабах, старый глючный и медленный механизм убери».

Здесь каждая строка проходит тот же сборщик, что строки хабов (builder._enrich_one): готовый
локальный фон, цвет из него, логотип, оценки, жанр, страна. Собранное запоминается по адресу
строки, поэтому повторный поиск и возврат в окно отдаются сразу. Новые строки собираются
параллельно в пределах BUDGET секунд; что не успело - досбирается после выдачи списка и
попадает в память к следующему разу.
"""
import json
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, wait

import xbmc
import xbmcvfs

from . import mirror

BUDGET = 6.0            # секунд на сборку новых строк до выдачи списка
FINISH = 90.0           # сколько ещё досбирать после выдачи
WORKERS = 6
KEEP_SECONDS = 7 * 24 * 3600
KEEP_ROWS = 800
STORE = 'special://profile/addon_data/skin.sublime/search_built4.json'   # 4: опознание только по совпавшему номеру
_LOCK = threading.Lock()


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('[sublime search rows] %s' % message, level)


def _path():
    return xbmcvfs.translatePath(STORE)


def _load_for(paths):
    from . import row_store
    return row_store.get_many(paths)


def _save(update):
    """Собранное - в общее хранилище строк (hub/row_store.py), его же читают хабы и дополнения."""
    if not update:
        return
    from . import row_store
    try:
        row_store.put_merged(update)
    except Exception as exc:
        _log('память не записана: %s' % exc, xbmc.LOGWARNING)


def _fetch(src):
    from .provider import get_directory
    rows = []
    props = ['art', 'year', 'plot', 'genre', 'country', 'rating', 'playcount', 'title',
             'originaltitle', 'studio', 'mpaa', 'uniqueid', 'premiered']
    for row in get_directory(src, properties=props, timeout=40) or []:
        path = str(row.get('file') or '')
        if not path or mirror.is_navigation(row):
            continue
        if row.get('filetype') == 'directory' and 'page=' in path and not row.get('uniqueid'):
            continue                            # «Следующая страница»
        rows.append(dict(row))
    return rows


def _enrich(row):
    from . import builder
    path = str(row.get('file') or '')
    block = builder._enrich_one(dict(row), force='plugin.video.youtube' not in path)
    # дата ролика YouTube (и любой строки, которую источник датировал сам): инфострока
    # показывает дату, а не год, как у строк хабов
    if block is not None and not block.get('premiered') and row.get('premiered'):
        block['premiered'] = str(row.get('premiered'))
    return block


def rows(src):
    """(строки с блоком sublime у собранных, недособранные (строка, задача))."""
    started = time.time()
    found = _fetch(src)
    known = _load_for([r.get('file') for r in found])
    pool, pending, out = None, [], []
    for row in found:
        block = known.get(str(row.get('file') or ''))
        if block:
            row['sublime'] = block
        else:
            if pool is None:
                pool = ThreadPoolExecutor(max_workers=WORKERS)
            pending.append((row, pool.submit(_enrich, row)))
        out.append(row)
    rest, update = [], {}
    if pending:
        wait([f for _, f in pending], timeout=max(0.5, BUDGET - (time.time() - started)))
        for row, future in pending:
            if future.done():
                try:
                    block = future.result()
                except Exception as exc:
                    _log('%s: %s' % (str(row.get('label'))[:40], exc), xbmc.LOGWARNING)
                    block = None
                if block:
                    row['sublime'] = block
                    update[str(row.get('file') or '')] = block
            else:
                rest.append((row, future))
        pool.shutdown(wait=False)
    _save(update)
    _log('%s: строк %d, из памяти %d, собрано %d, досборка %d за %.1f с' % (
        src[:60], len(out), len(out) - len(pending), len(update), len(rest), time.time() - started))
    return out, rest


def finish(rest):
    """Досборка после выдачи списка - в память, к следующему разу."""
    if not rest:
        return
    wait([f for _, f in rest], timeout=FINISH)
    update = {}
    for row, future in rest:
        try:
            block = future.result(timeout=0) if future.done() else None
        except Exception:
            block = None
        if block:
            update[str(row.get('file') or '')] = block
    _save(update)
    if update:
        # адрес списков поиска несёт эту отметку (Includes_Search.xml): она меняется - Kodi
        # перечитывает список, и досборанные строки приходят со своими фоном и цветом
        try:
            import xbmcgui
            xbmcgui.Window(10000).setProperty('Sublime.SearchBuilt', str(int(time.time())))
        except Exception:
            pass
