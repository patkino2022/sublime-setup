# -*- coding: utf-8 -*-
"""Зеркала HDRezka для server_watch.py. Отдельно от default.py, чтобы служба не грузила
дополнение целиком ради проверки раз в минуту (21.11.2026)."""

import re

import helpers

# Зеркала для автовыбора (как в установщике); «для зарегистрированных» - только с логином
AUTO_MIRRORS = ('kinopub.me', 'hdrezka.ag', 'rezka.ag', 'hdrezka.me', 'hdrezka.website', 'hdrezka.sh',
                'hdrezka.kim', 'hdrezka.name', 'hdrezka.club')
AUTO_LOGIN_MIRRORS = ('rezka.fi', 'hdrezka.cm', 'standby-rezka.tv')


def server_watch(profile, addon):
    """Сведения о зеркалах (server_watch.py): текущее выбирает служба, а не отказ запроса -
    отказавшее 15 минут при живом интернете меняется на точно работающее."""
    import server_watch as _sw
    login = bool(addon.getSetting('username') and addon.getSetting('password'))
    domain = re.sub(r'^https?://', '', (addon.getSetting('domain') or 'kinopub.me').strip()).rstrip('/')
    mirrors = [domain] + [m for m in AUTO_MIRRORS + (AUTO_LOGIN_MIRRORS if login else ()) if m != domain]
    # запасные - только когда текущее не отвечает (по настоящим запросам): сайт уже закрывал
    # этот адрес, лишние загрузки /films/ с Anubis раз в 6 ч ему не нужны (21.11.2026)
    watch = _sw.Watch(profile, mirrors, default=domain, log=lambda m: helpers.log('зеркала: ' + m),
                      spares_when_ok=False)
    # «Автовыбор зеркала» выключен - только зеркало из настроек, без проверок и переключений
    watch.auto = addon.getSetting('auto_server') != 'false'
    return watch
