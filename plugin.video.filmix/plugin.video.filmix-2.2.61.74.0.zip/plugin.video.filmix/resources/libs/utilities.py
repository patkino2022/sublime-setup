# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import simplemedia
import xbmcgui
from future.utils import iteritems
from simplemedia import py2_decode, WebClientError

plugin = simplemedia.RoutedPlugin()
_ = plugin.initialize_gettext()

__all__ = ['plugin', 'py2_decode', '_', 'WebClientError', 'Utilities']


import sys
import os
import json
import re
import xbmc
import xbmcplugin
import xbmcvfs


def _filmix_safe_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


_FILMIX_RESUME_INDEX = None
_FILMIX_RESUME_DB_PATH = None


def _filmix_locked_set_info(li, media_type, info_labels):
    # Kodi 22/CoreELEC can crash in GUIInfoManager/ListItem.setInfo when many
    # Filmix widget directories are rendered in parallel. Serialize this small
    # critical section across plugin processes; if locking is unavailable, fall
    # back to the normal call.
    fh = None
    locked = False
    try:
        try:
            import fcntl
            lock_dir = plugin.profile_dir or '/tmp'
            if lock_dir and not os.path.exists(lock_dir):
                os.makedirs(lock_dir)
            fh = open(os.path.join(lock_dir, 'filmix_listitem_setinfo.lock'), 'w')
            fcntl.flock(fh, fcntl.LOCK_EX)
            locked = True
        except Exception:
            fh = None
        li.setInfo(media_type, info_labels)
    finally:
        if locked and fh is not None:
            try:
                import fcntl
                fcntl.flock(fh, fcntl.LOCK_UN)
            except Exception:
                pass
        if fh is not None:
            try:
                fh.close()
            except Exception:
                pass


def _filmix_as_list(value):
    if value in [None, '']:
        return []
    if isinstance(value, (list, tuple, set)):
        result = []
        for item in value:
            if item not in [None, '']:
                result.append(str(item))
        return result
    return [str(value)]


def _filmix_as_int(value):
    try:
        return int(value)
    except Exception:
        try:
            return int(float(value))
        except Exception:
            return None


def _filmix_as_float(value):
    try:
        return float(value)
    except Exception:
        return None


def _filmix_item_mediatype_hint(item, info_block=None, props=None):
    """Best-effort mediatype detection for Kodi directory rows.

    2.2.25: movie rows use Filmix's own resume prompt for playback,
    but still attach resume row properties so Arctic Fuse can show thumbnail
    progress markers. Episodes keep the native Kodi prompt.
    """
    try:
        if isinstance(props, dict):
            for key in ('dbtype', 'DBTYPE', 'mediatype', 'MediaType'):
                value = props.get(key)
                if value not in [None, '']:
                    value = str(value).strip().lower()
                    if value:
                        return value
    except Exception:
        pass
    try:
        if isinstance(info_block, dict):
            for value in info_block.values():
                if isinstance(value, dict):
                    mt = value.get('mediatype') or value.get('MediaType') or value.get('dbtype') or value.get('DBTYPE')
                    if mt not in [None, '']:
                        return str(mt).strip().lower()
    except Exception:
        pass
    try:
        for key in ('mediatype', 'MediaType', 'dbtype', 'DBTYPE', 'type'):
            value = item.get(key) if isinstance(item, dict) else None
            if value not in [None, '']:
                return str(value).strip().lower()
    except Exception:
        pass
    return ''

def _filmix_set_video_info_tag(li, media_type, info_labels):
    """Kodi 20+/22-safe replacement for ListItem.setInfo(video, ...).

    2.2.23: restores the useful 2.2.16 metadata warning cleanup, but keeps
    resumetime/totaltime ListItem properties later in create_list_item() because
    CoreELEC/Kodi ae-fork needs them for the native resume prompt.
    """
    if media_type != 'video' or not isinstance(info_labels, dict):
        try:
            _filmix_locked_set_info(li, media_type, info_labels)
        except Exception:
            pass
        return

    try:
        tag = li.getVideoInfoTag()
    except Exception:
        try:
            _filmix_locked_set_info(li, media_type, info_labels)
        except Exception:
            pass
        return

    def call(name, value, conv=None):
        if value in [None, '']:
            return
        try:
            if conv is not None:
                value = conv(value)
                if value in [None, '']:
                    return
            getattr(tag, name)(value)
        except Exception:
            pass

    for key, value in list(info_labels.items()):
        if value is None or key in ('date', 'overlay'):
            continue
        if key == 'dbid':
            call('setDbId', value, _filmix_as_int)
        elif key == 'year':
            call('setYear', value, _filmix_as_int)
        elif key == 'episode':
            call('setEpisode', value, _filmix_as_int)
        elif key == 'season':
            call('setSeason', value, _filmix_as_int)
        elif key == 'sortepisode':
            call('setSortEpisode', value, _filmix_as_int)
        elif key == 'sortseason':
            call('setSortSeason', value, _filmix_as_int)
        elif key == 'episodeguide':
            call('setEpisodeGuide', value)
        elif key == 'top250':
            call('setTop250', value, _filmix_as_int)
        elif key == 'setid':
            call('setSetId', value, _filmix_as_int)
        elif key == 'tracknumber':
            call('setTrackNumber', value, _filmix_as_int)
        elif key == 'rating':
            call('setRating', value, _filmix_as_float)
        elif key == 'userrating':
            call('setUserRating', value, _filmix_as_int)
        elif key == 'playcount':
            call('setPlaycount', value, _filmix_as_int)
        elif key == 'mpaa':
            call('setMpaa', value)
        elif key == 'plot':
            call('setPlot', value)
        elif key == 'plotoutline':
            call('setPlotOutline', value)
        elif key == 'title':
            call('setTitle', value)
        elif key == 'originaltitle':
            call('setOriginalTitle', value)
        elif key == 'sorttitle':
            call('setSortTitle', value)
        elif key == 'tagline':
            call('setTagLine', value)
        elif key == 'tvshowtitle':
            call('setTvShowTitle', value)
        elif key == 'status':
            call('setTvShowStatus', value)
        elif key == 'genre':
            call('setGenres', value, _filmix_as_list)
        elif key == 'country':
            call('setCountries', value, _filmix_as_list)
        elif key == 'director':
            call('setDirectors', value, _filmix_as_list)
        elif key == 'studio':
            call('setStudios', value, _filmix_as_list)
        elif key in ('writer', 'credits'):
            call('setWriters', value, _filmix_as_list)
        elif key == 'duration':
            call('setDuration', value, _filmix_as_int)
        elif key == 'premiered':
            call('setPremiered', value)
        elif key == 'set':
            call('setSet', value)
        elif key == 'setoverview':
            call('setSetOverview', value)
        elif key == 'tag':
            call('setTags', value, _filmix_as_list)
        elif key == 'code':
            call('setProductionCode', value)
        elif key == 'aired':
            call('setFirstAired', value)
        elif key == 'lastplayed':
            call('setLastPlayed', value)
        elif key == 'album':
            call('setAlbum', value)
        elif key == 'votes':
            call('setVotes', value)
        elif key == 'trailer':
            call('setTrailer', value)
        elif key == 'path':
            call('setPath', value)
        elif key == 'filenameandpath':
            call('setFilenameAndPath', value)
        elif key == 'imdbnumber':
            call('setIMDBNumber', value)
        elif key == 'dateadded':
            call('setDateAdded', value)
        elif key == 'mediatype':
            call('setMediaType', value)
        elif key == 'showlink':
            call('setShowLinks', value, _filmix_as_list)
        elif key == 'artist':
            call('setArtists', value, _filmix_as_list)
        elif key == 'cast':
            try:
                actors = []
                cast_values = value if isinstance(value, (list, tuple)) else [value]
                for actor in cast_values:
                    if actor in [None, '']:
                        continue
                    if isinstance(actor, dict):
                        name = actor.get('name') or actor.get('actor') or ''
                        role = actor.get('role') or ''
                        order = _filmix_as_int(actor.get('order')) or 0
                        thumb = actor.get('thumbnail') or actor.get('thumb') or ''
                    else:
                        name, role, order, thumb = str(actor), '', 0, ''
                    if name:
                        actors.append(xbmc.Actor(name, role, order, thumb))
                if actors:
                    tag.setCast(actors)
            except Exception:
                pass

# Centralised in textutils (single source of truth); aliased here for existing
# internal call sites within this module.
from .textutils import filmix_resume_norm as _filmix_resume_norm
from .textutils import filmix_query_dict as _filmix_query_dict


def _filmix_play_parts(url):
    """Return (post_id, season, episode, section) for Filmix play plugin URLs."""
    text = _filmix_resume_norm(url)
    if not text:
        return None
    try:
        m = re.search(r'plugin://plugin\.video\.filmix/([^/]+)/([0-9]+)-[^/]*/play/?(?:\?([^#]*))?', text)
    except Exception:
        m = None
    if not m:
        return None
    section = m.group(1) or ''
    post_id = m.group(2) or ''
    params = _filmix_query_dict(m.group(3) or '')
    return post_id, params.get('s', ''), params.get('e', ''), section


def _filmix_resume_keys_for_url(url):
    keys = []
    raw = ''
    try:
        raw = str(url or '')
    except Exception:
        raw = ''
    norm = _filmix_resume_norm(raw)
    for key in (raw, norm):
        if key and key not in keys:
            keys.append(key)
    parts = _filmix_play_parts(norm or raw)
    if parts:
        post_id, season, episode, section = parts
        # v47.22: episode resume must be strict.  v47.19 added a broad
        # filmix-post-any key so stream bookmarks could be mapped back to a
        # Filmix row, but for TV shows that makes a bookmark from S01E01
        # appear on every episode of the same post_id.  Keep broad fallback
        # only for non-episode/movie-style routes.
        if season or episode:
            key = 'filmix-post:{0}:s:{1}:e:{2}'.format(post_id, season, episode)
            if key not in keys:
                keys.append(key)
        else:
            key = 'filmix-movie:{0}'.format(post_id)
            if key not in keys:
                keys.append(key)
            key = 'filmix-post-any:{0}'.format(post_id)
            if key not in keys:
                keys.append(key)
    return keys


def _filmix_profile_file(name):
    try:
        profile_dir = plugin.profile_dir
    except Exception:
        profile_dir = ''
    if not profile_dir:
        return ''
    try:
        return os.path.join(profile_dir, name)
    except Exception:
        return ''


def _filmix_load_resume_url_map():
    path = _filmix_profile_file('filmix_resume_url_map.json')
    if not path:
        return {}
    try:
        if not os.path.exists(path):
            return {}
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            return data
    except Exception:
        return {}
    return {}


def filmix_save_resume_url_map(stream_url, route_url, post_id=None, season=None, episode=None):
    """Map Kodi's final stream path back to the Filmix plugin route.

    Kodi may store bookmarks under the resolved HTTP stream instead of the
    plugin:// route. The point still stays in Kodi MyVideos; this small map lets
    us attach that native bookmark back to Filmix rows on the next directory draw.
    """
    if not stream_url or not route_url:
        return
    path = _filmix_profile_file('filmix_resume_url_map.json')
    if not path:
        return
    try:
        data = _filmix_load_resume_url_map()
        if not isinstance(data, dict):
            data = {}
        try:
            import time
            ts = int(time.time())
        except Exception:
            ts = 0
        entry = {'route': str(route_url),
                 'post_id': str(post_id or ''),
                 'season': str(season or ''),
                 'episode': str(episode or ''),
                 'ts': ts}
        for key in (str(stream_url), _filmix_resume_norm(stream_url)):
            if key:
                data[key] = entry
        # keep the file small
        try:
            items = sorted(data.items(), key=lambda kv: int((kv[1] or {}).get('ts') or 0), reverse=True)[:300]
            data = dict(items)
        except Exception:
            pass
        parent = os.path.dirname(path)
        if parent and not os.path.exists(parent):
            os.makedirs(parent)
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        try:
            xbmc.log('[plugin.video.filmix] ResumeMap: saved stream->route post_id={0} s={1} e={2} route={3}'.format(post_id, season, episode, route_url), xbmc.LOGINFO)
        except Exception:
            pass
    except Exception as e:
        try:
            xbmc.log('[plugin.video.filmix] ResumeMap: save failed: {0}'.format(e), xbmc.LOGINFO)
        except Exception:
            pass


def _filmix_add_resume_hit(index, url, pos, total, bid):
    for key in _filmix_resume_keys_for_url(url):
        if key and key not in index:
            index[key] = (pos, total, bid)


_FILMIX_RESUME_INDEX_TTL = 45.0


def _filmix_resume_index_path():
    try:
        import xbmcvfs
        return xbmcvfs.translatePath(
            'special://profile/addon_data/plugin.video.filmix/resume_index.json')
    except Exception:
        return ''


def _filmix_resume_index_from_disk():
    """The index as saved by a recent route, or None if there is nothing fresh."""
    path = _filmix_resume_index_path()
    if not path:
        return None
    try:
        import json
        import os
        import time as _time
        if not os.path.isfile(path):
            return None
        if _time.time() - os.path.getmtime(path) > _FILMIX_RESUME_INDEX_TTL:
            return None
        with open(path, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict):
            return None
        try:
            xbmc.log('[plugin.video.filmix] ResumeTag: db index reused keys={0}'.format(
                len(payload)), xbmc.LOGINFO)
        except Exception:
            pass
        return payload
    except Exception:
        return None


def _filmix_resume_index_to_disk(index):
    path = _filmix_resume_index_path()
    if not path or not isinstance(index, dict):
        return
    try:
        import json
        import os
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(index, handle, ensure_ascii=False)
        os.replace(tmp, path)
    except Exception:
        pass


def _filmix_load_resume_index():
    """Read Kodi's own MyVideos resume bookmarks once per directory build.

    v47.19: match exact plugin URLs, decoded/canonical post keys, and resolved
    HTTP stream URLs previously mapped to their Filmix route. The resume point is
    still taken from Kodi's native MyVideos bookmark table.
    """
    global _FILMIX_RESUME_INDEX, _FILMIX_RESUME_DB_PATH
    if _FILMIX_RESUME_INDEX is not None:
        return _FILMIX_RESUME_INDEX
    # The module cache above only lives as long as this plugin instance, and a
    # route IS one instance - so the scan below ran on every single directory
    # build. Measured on <коробка>: 0.7 s of the 3.1 s an episode list took,
    # 269 bookmarks scanned to produce 171 keys, every time. The result is a
    # small dictionary that changes only when something is watched, so it is
    # kept in a file next to the cache and reused for a short while.
    cached = _filmix_resume_index_from_disk()
    if cached is not None:
        _FILMIX_RESUME_INDEX = cached
        return _FILMIX_RESUME_INDEX
    index = {}
    try:
        import sqlite3
        from .kodi_state import newest_myvideos_db
        db_path = newest_myvideos_db()
        if not db_path:
            _FILMIX_RESUME_INDEX = index
            return index
        _FILMIX_RESUME_DB_PATH = db_path
        stream_map = _filmix_load_resume_url_map()
        # только чтение: база принадлежит Kodi (21.11.2026)
        conn = sqlite3.connect('file:%s?mode=ro' % db_path, uri=True, timeout=5)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            # Полный адрес строки: Kodi кладёт весь plugin://-адрес в ИМЯ файла,
            # и склейка «путь + имя» его удваивала (…/play/plugin://…/play/?s=1…).
            # На таком адресе разбор s/e не срабатывал, серия попадала в индекс
            # как фильм, и строка серии не получала точку продолжения: 16.10.2026
            # у «Войны» 1x1 (досмотрено до 21 %) не было маркера в полосе серий
            # под сезоном, где Kodi сам из базы ничего не подставляет.
            cur.execute("""SELECT b.idBookmark AS bid,
                                  b.timeInSeconds AS pos,
                                  b.totalTimeInSeconds AS total,
                                  (CASE WHEN f.strFilename LIKE 'plugin://%' THEN f.strFilename ELSE p.strPath || f.strFilename END) AS url
                           FROM bookmark b
                           JOIN files f ON f.idFile = b.idFile
                           JOIN path p ON p.idPath = f.idPath
                           WHERE b.type = 1
                           ORDER BY b.idBookmark DESC LIMIT 1000""")
            scanned = 0
            mapped = 0
            for row in cur.fetchall() or []:
                raw_url = str(row['url'] or '')
                if not raw_url:
                    continue
                scanned += 1
                try:
                    pos = float(row['pos'] or 0.0)
                    total = float(row['total'] or 0.0)
                except Exception:
                    continue
                if pos <= 5.0:
                    continue
                if total > 0 and pos >= max(0.0, total - 30.0):
                    continue
                bid = int(row['bid'] or 0)
                # Native plugin URL bookmark.
                if raw_url.startswith('plugin://plugin.video.filmix/') or _filmix_resume_norm(raw_url).startswith('plugin://plugin.video.filmix/'):
                    before = len(index)
                    _filmix_add_resume_hit(index, raw_url, pos, total, bid)
                    if len(index) > before:
                        mapped += 1
                    continue
                # Kodi may bookmark the resolved stream. Use our route map.
                entry = None
                for mk in (raw_url, _filmix_resume_norm(raw_url)):
                    if mk and isinstance(stream_map, dict) and mk in stream_map:
                        entry = stream_map.get(mk)
                        break
                if isinstance(entry, dict) and entry.get('route'):
                    before = len(index)
                    _filmix_add_resume_hit(index, entry.get('route'), pos, total, bid)
                    if len(index) > before:
                        mapped += 1
        finally:
            try:
                conn.close()
            except Exception:
                pass
        _filmix_resume_index_to_disk(index)
        try:
            xbmc.log('[plugin.video.filmix] ResumeTag: db index loaded keys={0} scanned={1} mapped={2} db={3}'.format(len(index), scanned, mapped, _FILMIX_RESUME_DB_PATH), xbmc.LOGINFO)
        except Exception:
            pass
    except Exception as e:
        try:
            xbmc.log('[plugin.video.filmix] ResumeTag: db index failed: {0}'.format(e), xbmc.LOGINFO)
        except Exception:
            pass
    _FILMIX_RESUME_INDEX = index
    return index


def _filmix_latest_videos_db_info():
    try:
        from .kodi_state import newest_myvideos_db
        db_path = newest_myvideos_db()
        if not db_path:
            return '', 0
        try:
            db_mtime = int(os.path.getmtime(db_path))
        except Exception:
            db_mtime = 0
        return db_path, db_mtime
    except Exception:
        return '', 0


def _filmix_resume_map_mtime():
    try:
        path = _filmix_profile_file('filmix_resume_url_map.json')
        if path and os.path.exists(path):
            return int(os.path.getmtime(path))
    except Exception:
        pass
    return 0


def _filmix_snapshot_to_resume_index(data):
    index = {}
    try:
        raw = data.get('index') if isinstance(data, dict) else None
        if not isinstance(raw, dict):
            return index
        for key, value in raw.items():
            if not key:
                continue
            if isinstance(value, (list, tuple)) and len(value) >= 3:
                try:
                    index[str(key)] = (float(value[0] or 0.0), float(value[1] or 0.0), int(value[2] or 0))
                except Exception:
                    pass
    except Exception:
        return {}
    return index


def _filmix_read_resume_snapshot(max_age=180, require_fresh=True):
    path = _filmix_profile_file('filmix_resume_index_snapshot.json')
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        if not isinstance(data, dict):
            return None
        index = _filmix_snapshot_to_resume_index(data)
        if not index:
            return None
        if require_fresh:
            import time
            now = int(time.time())
            ts = int(data.get('ts') or 0)
            if ts <= 0 or (now - ts) > int(max_age or 180):
                return None
            db_path, db_mtime = _filmix_latest_videos_db_info()
            if db_path and str(data.get('db_path') or '') != str(db_path):
                return None
            if db_mtime and int(data.get('db_mtime') or 0) != int(db_mtime):
                return None
            map_mtime = _filmix_resume_map_mtime()
            if int(data.get('map_mtime') or 0) != int(map_mtime or 0):
                return None
        return index
    except Exception:
        return None


def _filmix_write_resume_snapshot(index, db_path=None, db_mtime=None, max_items=1200):
    path = _filmix_profile_file('filmix_resume_index_snapshot.json')
    if not path or not isinstance(index, dict):
        return
    try:
        import time
        if db_path is None or db_mtime is None:
            db_path, db_mtime = _filmix_latest_videos_db_info()
        payload_index = {}
        count = 0
        for key, value in index.items():
            if count >= int(max_items or 1200):
                break
            try:
                payload_index[str(key)] = [float(value[0] or 0.0), float(value[1] or 0.0), int(value[2] or 0)]
                count += 1
            except Exception:
                pass
        parent = os.path.dirname(path)
        if parent and not os.path.exists(parent):
            os.makedirs(parent)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump({'ts': int(time.time()),
                       'db_path': str(db_path or ''),
                       'db_mtime': int(db_mtime or 0),
                       'map_mtime': int(_filmix_resume_map_mtime() or 0),
                       'index': payload_index}, fh, ensure_ascii=False)
        try:
            os.replace(tmp, path)
        except Exception:
            try:
                os.rename(tmp, path)
            except Exception:
                pass
        try:
            xbmc.log('[plugin.video.filmix] ResumeSnapshot: stored keys={0} file={1}'.format(len(payload_index), path), xbmc.LOGINFO)
        except Exception:
            pass
    except Exception as e:
        try:
            xbmc.log('[plugin.video.filmix] ResumeSnapshot: store failed: {0}'.format(e), xbmc.LOGINFO)
        except Exception:
            pass


def _filmix_load_resume_index_snapshot(max_age=180):
    """Fast shared resume snapshot for Home/widget progress markers.

    2.2.33: cache-only widget rows still need thumbnail progress properties,
    but 2.2.32 skipped the MyVideos lookup completely.  This function lets all
    parallel widget routes share one short-lived snapshot instead of scanning
    MyVideos separately in every plugin process.
    """
    global _FILMIX_RESUME_INDEX, _FILMIX_RESUME_DB_PATH
    if _FILMIX_RESUME_INDEX is not None:
        return _FILMIX_RESUME_INDEX
    db_path, db_mtime = _filmix_latest_videos_db_info()
    _FILMIX_RESUME_DB_PATH = db_path or _FILMIX_RESUME_DB_PATH
    cached = _filmix_read_resume_snapshot(max_age=max_age, require_fresh=True)
    if cached is not None:
        _FILMIX_RESUME_INDEX = cached
        try:
            xbmc.log('[plugin.video.filmix] ResumeSnapshot: hit keys={0} ttl={1}s'.format(len(cached), int(max_age or 180)), xbmc.LOGINFO)
        except Exception:
            pass
        return cached

    lock_path = _filmix_profile_file('filmix_resume_index_snapshot.lock')
    fh = None
    locked = False
    try:
        if lock_path:
            parent = os.path.dirname(lock_path)
            if parent and not os.path.exists(parent):
                os.makedirs(parent)
            fh = open(lock_path, 'w')
            try:
                import fcntl
                fcntl.flock(fh, fcntl.LOCK_EX)
                locked = True
            except Exception:
                locked = False
        # Another route may have built the snapshot while we waited for the lock.
        cached = _filmix_read_resume_snapshot(max_age=max_age, require_fresh=True)
        if cached is not None:
            _FILMIX_RESUME_INDEX = cached
            try:
                xbmc.log('[plugin.video.filmix] ResumeSnapshot: hit_after_lock keys={0} ttl={1}s'.format(len(cached), int(max_age or 180)), xbmc.LOGINFO)
            except Exception:
                pass
            return cached
        index = _filmix_load_resume_index()
        try:
            _filmix_write_resume_snapshot(index, db_path=db_path, db_mtime=db_mtime)
        except Exception:
            pass
        return index
    except Exception as e:
        try:
            xbmc.log('[plugin.video.filmix] ResumeSnapshot: build failed: {0}'.format(e), xbmc.LOGINFO)
        except Exception:
            pass
        stale = _filmix_read_resume_snapshot(max_age=max_age, require_fresh=False)
        if stale is not None:
            _FILMIX_RESUME_INDEX = stale
            return stale
        return {}
    finally:
        if locked and fh is not None:
            try:
                import fcntl
                fcntl.flock(fh, fcntl.LOCK_UN)
            except Exception:
                pass
        if fh is not None:
            try:
                fh.close()
            except Exception:
                pass


def _filmix_lookup_resume_for_url_snapshot(item_url):
    if not item_url:
        return 0.0, 0.0, 0
    index = _filmix_load_resume_index_snapshot(max_age=180)
    if not index:
        return 0.0, 0.0, 0
    keys = _filmix_resume_keys_for_url(item_url)
    for key in keys:
        hit = index.get(key)
        if hit:
            try:
                return float(hit[0] or 0.0), float(hit[1] or 0.0), int(hit[2] or 0)
            except Exception:
                return 0.0, 0.0, 0
    return 0.0, 0.0, 0

# Файлы единой базы просмотров читает скин (row_store.title_states/episode_states): он держит
# их между вызовами и перечитывает по времени изменения.

def _filmix_title_states():
    """({ключ фильма: [playcount, позиция, длительность]}, key_for) по всем источникам - единая
    база просмотров скина (row_store.title_states, общее с HDRezka)."""
    store = _skin_row_store()
    if store is None or not hasattr(store, 'title_states'):
        return {}, None
    try:
        return store.title_states()
    except Exception:
        return {}, None


def _filmix_episode_states():
    """Серии и сериалы по всем источникам (row_store.episode_states, общее с HDRezka)."""
    store = _skin_row_store()
    if store is None or not hasattr(store, 'episode_states'):
        return {'episodes': {}, 'shows': {}}
    try:
        return store.episode_states()
    except Exception:
        return {'episodes': {}, 'shows': {}}


def _filmix_shared_series(info_block, li, props):
    """Серия - позиция и отметка по самому свежему действию в любом источнике (HDRezka,
    Filmix, Elementum); сериал - значок «начат», если начат где угодно (владелец
    17.11.2026: «Филмикс и элементум тоже должны быть в этой единой схеме»)."""
    try:
        info = (info_block or {}).get('video') if isinstance(info_block, dict) else None
        if not isinstance(info, dict):
            return
        media = str(info.get('mediatype') or '').lower()
        if media not in ('episode', 'tvshow'):
            return
        _states, key_for = _filmix_title_states()
        if not key_for or not info.get('year'):
            return
        data = _filmix_episode_states()
        if media == 'tvshow':
            title = info.get('tvshowtitle') or info.get('title')
            entry = data.get('shows', {}).get(key_for(tvshowtitle=title, year=str(info['year']))[0]) if title else None
            if entry:
                # «Начат» - SeriesStarted: по нему скин рисует число непросмотренных или галочку.
                props['SeriesStarted'] = 'true'
                store = _skin_row_store()
                if not props.get('TotalEpisodes') and store is not None and hasattr(store, 'show_count_props'):
                    # своего счёта нет (сериал смотрели в другом источнике) - счёт из общего файла,
                    # тем же правилом, что у HDRezka: сериал, досмотренный в HDRezka, был здесь
                    # только «начат» - без числа и без галочки (аудит 22.11.2026)
                    shared, done = store.show_count_props(entry)
                    shared.pop('WatchedProgress', None)     # часы - только у HDRezka без счёта
                    props.update(shared)
                    if done:
                        li.getVideoInfoTag().setPlaycount(1)
            return
        if info.get('episode') in (None, '') or not info.get('tvshowtitle'):
            return
        found = data.get('episodes', {}).get(key_for(
            tvshowtitle=info['tvshowtitle'], year=str(info['year']),
            season=int(info.get('season') or 0), episode=int(info['episode']))[0])
        if not found:
            return
        count, pos, total = int(found[0] or 0), float(found[1] or 0), float(found[2] or 0)
        props['FilmixSharedState'] = 'true'
        tag = li.getVideoInfoTag()
        if pos > 5 and total > 0:
            props['ResumeTime'] = '{0:.3f}'.format(pos)
            props['TotalTime'] = '{0:.3f}'.format(total)
            props['resumetime'] = props['ResumeTime']
            props['totaltime'] = props['TotalTime']
            props['PercentPlayed'] = '{0:.2f}'.format(max(0.0, min(100.0, pos * 100.0 / total)))
            tag.setResumePoint(pos, total)
            tag.setPlaycount(0)
        else:
            tag.setPlaycount(count)
    except Exception:
        pass


def _filmix_title_resume(info_block, item, rpos, rtotal, li=None):
    """Позиция и отметка фильма из общей базы (по всем источникам, самое свежее действие).
    Общая запись главнее своей: иначе Filmix показывал «просмотрено», а HDRezka у того же
    фильма - недосмотр (владелец 17.11.2026). Отметку «просмотрено» кладёт в info_block."""
    try:
        info = (info_block or {}).get('video') if isinstance(info_block, dict) else None
        info = info if isinstance(info, dict) else (info_block if isinstance(info_block, dict) else {})
        title = info.get('title') or (item.get('label') if isinstance(item, dict) else '')
        year = info.get('year')
        if not title or not year:
            return rpos, rtotal
        states, key_for = _filmix_title_states()
        if not key_for:
            return rpos, rtotal
        found = states.get(key_for(title=title, year=str(year))[0])
        if not found:
            return rpos, rtotal
        info['playcount'] = int(found[0] or 0)
        if li is not None:
            try:
                li.getVideoInfoTag().setPlaycount(int(found[0] or 0))
            except Exception:
                pass
        return float(found[1] or 0), float(found[2] or 0)
    except Exception:
        pass
    return rpos, rtotal


def _filmix_lookup_resume_for_url(item_url):
    if not item_url:
        return 0.0, 0.0, 0
    index = _filmix_load_resume_index()
    if not index:
        return 0.0, 0.0, 0
    keys = _filmix_resume_keys_for_url(item_url)
    for key in keys:
        hit = index.get(key)
        if hit:
            try:
                return float(hit[0] or 0.0), float(hit[1] or 0.0), int(hit[2] or 0)
            except Exception:
                return 0.0, 0.0, 0
    return 0.0, 0.0, 0


def _filmix_is_widget_route_resume_sanitize_context():
    """
    2.2.39 AM8_4GB_WIDGET_ROUTE_RESUME_PROP_STRICT_CLEAN:
    Some cache-only Home widget rows arrive without FilmixCacheOnlyWidget in
    the final property dict after SimpleMedia/ListItemInfo merging, so the
    2.2.38 per-row flag did not catch every row and Kodi 22 still logged
    deprecated lowercase resumetime/totaltime warnings.  Detect safe list
    routes by plugin path and resume:false.  Do not apply to play/open/episodes
    routes where Kodi native episode resume behaviour is intentionally left as
    close to the old behaviour as possible.
    """
    try:
        argv0 = str(sys.argv[0] if len(sys.argv) > 0 else '')
        argv3 = str(sys.argv[3] if len(sys.argv) > 3 else '')
    except Exception:
        return False
    if 'plugin.video.filmix' not in argv0:
        return False
    if 'resume:false' not in argv3:
        return False
    # Never sanitize playback/open/episode rows by route context; these are not
    # Home widget catalog rows and can rely on the old native resume hints.
    blocked = ('/play/', '/open/', '/episodes/', '/translations/', '/mark_watched', '/mark_unwatched')
    for token in blocked:
        if token in argv0:
            return False
    allowed = (
        '/movies/', '/serials/', '/deferred/', '/favorites/', '/watch_later/',
        '/genres_movies/', '/genres_serials/', '/countries_movies/', '/countries_serials/'
    )
    return any(token in argv0 for token in allowed)

def _selftest():
    # по каждому вызову: интерпретатор дополнения переиспользуется (reuselanguageinvoker)
    return 'selftest=1' in (sys.argv[2] if len(sys.argv) > 2 else '')


def reset_call_state():
    """Сбросить то, что рассчитано на один вызов маршрута. Kodi держит интерпретатор
    дополнения между вызовами (reuselanguageinvoker): без сброса отметки просмотра и списки
    пользователя остались бы от прошлого вызова."""
    global _FILMIX_RESUME_INDEX, _FILMIX_RESUME_DB_PATH
    _FILMIX_RESUME_INDEX = None
    _FILMIX_RESUME_DB_PATH = None
    _DRAWS_RESET()
    try:
        from . import kodi_state
        kodi_state.invalidate()
    except Exception:
        pass
    try:
        # сверка с базой Kodi перед списком - раз на вызов маршрута, а не раз на жизнь
        # интерпретатора: иначе отметки после просмотра ждали службу до минуты
        from . import kodi_link
        kodi_link._synced_this_process[0] = False
    except Exception:
        pass


def _DRAWS_RESET():
    try:
        from . import image_host
        image_host._DRAWS.clear()
    except Exception:
        pass
_SELFTEST_KEYS = ('SeriesStarted', 'WatchedProgress', 'WatchedEpisodes', 'UnWatchedEpisodes',
                  'TotalEpisodes', 'WatchedEpisodePercent', 'PercentPlayed', 'ResumeTime')


_SKIN_ROWS = {}


def _skin_row_store():
    """Общее хранилище собранных строк скина (skin.sublime/resources/lib/hub/row_store.py),
    подключается файлом, как identity.py. Перечитывается, когда файл изменился: после обновления
    скина дополнение иначе работало со старым кодом до перезапуска Kodi (аудит 22.11.2026)."""
    try:
        path = xbmcvfs.translatePath('special://home/addons/skin.sublime/resources/lib/hub/row_store.py')
        stamp = os.path.getmtime(path) if os.path.exists(path) else 0
    except Exception:
        path, stamp = '', 0
    if 'mod' in _SKIN_ROWS and _SKIN_ROWS.get('stamp') == stamp:
        return _SKIN_ROWS['mod']
    mod = None
    try:
        import importlib.util
        if stamp:
            spec = importlib.util.spec_from_file_location('sublime_row_store', path)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
    except Exception as exc:
        xbmc.log('[plugin.video.filmix] row_store: %s' % exc, xbmc.LOGWARNING)
        mod = None
    _SKIN_ROWS['mod'] = mod
    _SKIN_ROWS['stamp'] = stamp
    return mod


def _attach_skin_rows(store_rows):
    """Готовые свойства строки (фон, цвет, логотип, оценки, жанр, дата, чистое название, плашка
    качества - Sublime.* и sublime_release_*) из хранилища скина одним вызовом на страницу
    (row_store.attach - общий с HDRezka); недостающие скин соберёт к следующему показу."""
    if not store_rows:
        return
    store = _skin_row_store()
    if store is None or not hasattr(store, 'attach'):
        return
    try:
        store.attach(store_rows)
    except Exception as exc:
        xbmc.log('[plugin.video.filmix] свойства строк скина: %s' % exc, xbmc.LOGWARNING)


def _filmix_native_create_directory(items=None, total_items=None, content='', category='',
                                    sort_methods=None, succeeded=True, update_listing=False,
                                    cache_to_disc=True, **kwargs):
    """
    Kodi-native directory builder used to preserve real ResumePoint on Kodi 20+.
    This bypasses the simplemedia renderer, which only pushed resumetime/totaltime
    through properties and did not reliably trigger Kodi's native resume prompt.
    """
    handle = _filmix_safe_int(sys.argv[1], -1)
    if handle < 0:
        return

    if items is None:
        items = []
    if not isinstance(items, list):
        items = list(items)

    tuples = []
    store_rows = []
    for item in items:
        if not isinstance(item, dict):
            continue

        label = item.get('label') or ''
        # offscreen=True: элемент строится для списка дополнения, а не для окна.
        # Без него каждый setProperty/setArt ждёт блокировку интерфейса Kodi, пока
        # главный поток рисует экран: замер на .30 17.10.2026 - 828 setProperty
        # РуТора то 0.35 с, то 2.75 с при открытом окне поиска.
        li = xbmcgui.ListItem(label=label, offscreen=True)

        # Basic path/url
        item_url = item.get('url') or item.get('path') or ''
        item_path = item.get('path')
        if item_path:
            try:
                li.setPath(item_path)
            except Exception:
                pass

        # Art
        art = {}
        item_art = item.get('art')
        if isinstance(item_art, dict):
            art.update(item_art)
        for key in ('thumb', 'icon', 'poster', 'fanart'):
            value = item.get(key)
            if value:
                art.setdefault(key, value)
        if art:
            try:
                li.setArt(art)
            except Exception:
                pass

        # Info labels
        info_block = item.get('info') or {}
        try:
            for media_type, info_labels in info_block.items():
                if isinstance(info_labels, dict):
                    _filmix_set_video_info_tag(li, media_type, info_labels)
                    break
        except Exception:
            pass

        # Context menu
        context_menu = item.get('context_menu')
        if context_menu:
            try:
                li.addContextMenuItems(context_menu)
            except Exception:
                pass

        # Content lookup
        if 'content_lookup' in item:
            try:
                li.setContentLookup(bool(item.get('content_lookup')))
            except Exception:
                pass

        # ResumePoint + remaining properties
        props = {}
        raw_props = item.get('properties') or {}
        if isinstance(raw_props, dict):
            props.update(raw_props)
        cache_only_widget = False
        try:
            cache_only_widget = str(props.get('FilmixCacheOnlyWidget') or '').lower() == 'true'
        except Exception:
            cache_only_widget = False
        # 2.2.39: also treat known Home/widget catalog routes as sanitize-safe
        # when the per-row flag was lost during property merging.
        route_resume_sanitize = _filmix_is_widget_route_resume_sanitize_context()
        if route_resume_sanitize:
            cache_only_widget = True
        # единая база просмотров: серия и сериал - по всем источникам (скин)
        _filmix_shared_series(info_block, li, props)

        # Kodi-native resume prompt for plugin:// Filmix items. Episodes keep
        # Kodi's native dialog. Movies are different on CoreELEC/Kodi ae-fork:
        # Kodi often passes resume:false without showing a dialog, and 2.2.23
        # then resumed silently. 2.2.24 removed movie row resume properties,
        # but that also removed thumbnail progress markers. 2.2.25 restores
        # row properties for skin progress while play_video() keeps the single
        # Filmix prompt for movies.
        if not cache_only_widget:
            try:
                media_hint = _filmix_item_mediatype_hint(item, info_block=info_block, props=props)
                is_movie_row = (media_hint == 'movie')
                playable_hint = bool(item.get('is_playable') or
                                     str(props.get('IsPlayable') or props.get('isPlayable') or props.get('isplayable') or '').lower() == 'true')
                if is_movie_row and playable_hint:
                    # 2.2.25 MOVIE_PROGRESS_MARKERS_RESTORED:
                    # Keep movie progress markers on normal/non-widget routes.
                    try:
                        rpos, rtotal, rbm = _filmix_lookup_resume_for_url(item_url)
                        rpos, rtotal = _filmix_title_resume(info_block, item, rpos, rtotal, li)
                        if rpos > 5.0:
                            props['resumetime'] = '{0:.3f}'.format(rpos)
                            props['ResumeTime'] = '{0:.3f}'.format(rpos)
                            props['totaltime'] = '{0:.3f}'.format(rtotal) if rtotal > 0 else '0'
                            props['TotalTime'] = '{0:.3f}'.format(rtotal) if rtotal > 0 else '0'
                            props['FilmixResumeTime'] = '{0:.3f}'.format(rpos)
                            props['FilmixResumeTotal'] = '{0:.3f}'.format(rtotal) if rtotal > 0 else '0'
                            try:
                                if rtotal and float(rtotal) > 0:
                                    _pct = max(0.0, min(100.0, (float(rpos) * 100.0) / float(rtotal)))
                                    props['PercentPlayed'] = '{0:.2f}'.format(_pct)
                                    props['percentplayed'] = '{0:.2f}'.format(_pct)
                                    props['ResumePercent'] = '{0:.2f}'.format(_pct)
                                    props['WatchedPercent'] = '{0:.2f}'.format(_pct)
                            except Exception:
                                pass
                            xbmc.log('[plugin.video.filmix] MovieProgressMarker: restored seek={0:.3f} total={1:.3f} bookmark={2} url={3}'.format(rpos, rtotal, rbm, item_url), xbmc.LOGINFO)
                    except Exception as e:
                        try:
                            xbmc.log('[plugin.video.filmix] MovieProgressMarker: row lookup failed: {0}'.format(e), xbmc.LOGINFO)
                        except Exception:
                            pass
                else:
                    already_has_resume = (props.get('resumetime') not in [None, ''] or
                                          props.get('ResumeTime') not in [None, ''])
                    if (not already_has_resume) and playable_hint:
                        rpos, rtotal, rbm = _filmix_lookup_resume_for_url(item_url)
                        if rpos > 5.0:
                            props['resumetime'] = '{0:.3f}'.format(rpos)
                            props['ResumeTime'] = '{0:.3f}'.format(rpos)
                            props['totaltime'] = '{0:.3f}'.format(rtotal) if rtotal > 0 else '0'
                            props['TotalTime'] = '{0:.3f}'.format(rtotal) if rtotal > 0 else '0'
                            try:
                                xbmc.log('[plugin.video.filmix] ResumeTag: set from Kodi DB seek={0:.3f} total={1:.3f} bookmark={2} url={3}'.format(rpos, rtotal, rbm, item_url), xbmc.LOGINFO)
                            except Exception:
                                pass
            except Exception as e:
                try:
                    xbmc.log('[plugin.video.filmix] ResumeTag: lookup failed: {0}'.format(e), xbmc.LOGINFO)
                except Exception:
                    pass
        else:
            # 2.2.33 AM8_4GB_PROGRESS_SNAPSHOT:
            # Keep Home/widget cache-only rows fast, but restore skin progress
            # markers from one shared short-lived MyVideos snapshot. This avoids
            # the old full DB scan in every parallel widget route while still
            # setting resumetime/totaltime/PercentPlayed for Arctic Fuse.
            props.setdefault('FilmixResumeLookupMode', 'snapshot')
            try:
                media_hint = _filmix_item_mediatype_hint(item, info_block=info_block, props=props)
                playable_hint = bool(item.get('is_playable') or
                                     str(props.get('IsPlayable') or props.get('isPlayable') or props.get('isplayable') or '').lower() == 'true')
                # Movie rows in Home are the main source of thumbnail progress
                # markers; episode rows outside widgets continue using the
                # authoritative live lookup above.
                if playable_hint and media_hint in ['movie', 'episode', 'video']:
                    if props.get('FilmixSharedState'):
                        rpos, rtotal, rbm = 0.0, 0.0, 0
                    else:
                        rpos, rtotal, rbm = _filmix_lookup_resume_for_url_snapshot(item_url)
                    if media_hint == 'movie':
                        rpos, rtotal = _filmix_title_resume(info_block, item, rpos, rtotal, li)
                    if rpos > 5.0:
                        # 2.2.39 AM8_4GB_WIDGET_ROUTE_RESUME_PROP_STRICT_CLEAN:
                        # Home/cache-only widgets must keep progress markers,
                        # but Kodi 22 logs deprecated warnings for lowercase
                        # resumetime/totaltime on every row.  Use the native
                        # InfoTagVideo.setResumePoint below plus uppercase
                        # ResumeTime/TotalTime/PercentPlayed skin properties.
                        props['ResumeTime'] = '{0:.3f}'.format(rpos)
                        props['TotalTime'] = '{0:.3f}'.format(rtotal) if rtotal > 0 else '0'
                        props['FilmixResumeTime'] = '{0:.3f}'.format(rpos)
                        props['FilmixResumeTotal'] = '{0:.3f}'.format(rtotal) if rtotal > 0 else '0'
                        try:
                            if rtotal and float(rtotal) > 0:
                                _pct = max(0.0, min(100.0, (float(rpos) * 100.0) / float(rtotal)))
                                props['PercentPlayed'] = '{0:.2f}'.format(_pct)
                                props['percentplayed'] = '{0:.2f}'.format(_pct)
                                props['ResumePercent'] = '{0:.2f}'.format(_pct)
                                props['WatchedPercent'] = '{0:.2f}'.format(_pct)
                        except Exception:
                            pass
                        try:
                            xbmc.log('[plugin.video.filmix] ResumeSnapshot: set progress seek={0:.3f} total={1:.3f} bookmark={2} url={3}'.format(rpos, rtotal, rbm, item_url), xbmc.LOGDEBUG)
                        except Exception:
                            pass
            except Exception as e:
                try:
                    xbmc.log('[plugin.video.filmix] ResumeSnapshot: row lookup failed: {0}'.format(e), xbmc.LOGINFO)
                except Exception:
                    pass

        # Carry isPlayable explicitly
        if item.get('is_playable'):
            props.setdefault('IsPlayable', 'true')
            props.setdefault('isPlayable', 'true')

        if cache_only_widget:
            resume_time = props.get('ResumeTime', props.get('resumetime'))
            total_time = props.get('TotalTime', props.get('totaltime'))
            try:
                props.pop('resumetime', None)
                props.pop('totaltime', None)
            except Exception:
                pass
        else:
            resume_time = props.get('resumetime', props.get('ResumeTime'))
            total_time = props.get('totaltime', props.get('TotalTime'))
        if resume_time not in [None, ''] and total_time not in [None, '']:
            try:
                video_tag = li.getVideoInfoTag()
                video_tag.setResumePoint(float(resume_time), float(total_time))
            except Exception as e:
                try:
                    xbmc.log('[plugin.video.filmix] ResumeTag: setResumePoint failed: {0}'.format(e), xbmc.LOGINFO)
                except Exception:
                    pass
            # Keep ResumeTime/TotalTime properties as well as InfoTagVideo.
            # Kodi's native resume dialog for plugin directory rows is triggered
            # more reliably by these ListItem properties on CoreELEC/Kodi 22.
            pass

        # Unique IDs
        unique_ids = item.get('unique_ids')
        if isinstance(unique_ids, dict):
            try:
                li.getVideoInfoTag().setUniqueIDs({str(k): str(v) for k, v in unique_ids.items() if v not in [None, '']})
            except Exception:
                pass

        # Ratings
        ratings = item.get('ratings')
        if isinstance(ratings, list):
            try:
                tag = li.getVideoInfoTag()
                default_done = False
                for rating in ratings:
                    if not isinstance(rating, dict):
                        continue
                    rtype = rating.get('type') or 'default'
                    rval = float(rating.get('rating') or 0)
                    votes = int(rating.get('votes') or 0)
                    defaultt = bool(rating.get('defaultt'))
                    tag.setRating(rtype, rval, votes, defaultt)
                    if defaultt:
                        default_done = True
                if not default_done and ratings:
                    rating = ratings[0]
                    if isinstance(rating, dict):
                        tag.setRating(rating.get('type') or 'default',
                                      float(rating.get('rating') or 0),
                                      int(rating.get('votes') or 0),
                                      True)
            except Exception:
                pass

        # 2.2.39: cache-only Home widgets already use InfoTagVideo.setResumePoint
        # above and keep ResumeTime/TotalTime/PercentPlayed for skin markers.
        # Do not also set deprecated lowercase resumetime/totaltime properties
        # on those widget rows; Kodi 22 logs warnings for each one and this was
        # adding noise/latency during parallel AF3 widget rendering.
        if cache_only_widget:
            try:
                props.pop('resumetime', None)
                props.pop('totaltime', None)
            except Exception:
                pass

        for key, value in list(props.items()):
            # 2.2.39: final safety gate.  On cache/widget catalog routes keep
            # InfoTagVideo.setResumePoint + ResumeTime/TotalTime/PercentPlayed
            # but never call ListItem.setProperty('resumetime'/'totaltime'),
            # because Kodi 22 logs a warning for every row and that stalls AF3
            # widget rendering on AM8 4GB.
            if cache_only_widget and str(key).lower() in ('resumetime', 'totaltime'):
                continue
            if value is None:
                value = ''
            elif not isinstance(value, str):
                value = str(value)
            try:
                li.setProperty(key, value)
            except Exception:
                pass

        if _selftest():
            # самопроверка (sublime-box/installer/regress.py): итог строки - в названии,
            # его видно снаружи через Files.GetDirectory; обычные списки не меняются
            video = (info_block or {}).get('video') if isinstance(info_block, dict) else {}
            video = video if isinstance(video, dict) else {}
            seen = dict((k, props.get(k)) for k in _SELFTEST_KEYS if props.get(k) not in (None, ''))
            seen['mediatype'] = video.get('mediatype') or ''
            seen['playcount'] = video.get('playcount') or 0
            seen['plot'] = len(str(video.get('plot') or ''))
            li.setLabel('%s ⟦%s⟧' % (label, json.dumps(seen, ensure_ascii=False)))

        is_folder = bool(item.get('is_folder', not bool(item.get('is_playable'))))
        tuples.append((item_url, li, is_folder))
        _video = (info_block or {}).get('video') if isinstance(info_block, dict) else None
        _video = _video if isinstance(_video, dict) else {}
        if item_url and str(_video.get('mediatype') or '') in ('movie', 'tvshow'):
            store_rows.append((li, {'file': item_url, 'label': label,
                                    'title': _video.get('title') or label,
                                    'originaltitle': _video.get('originaltitle') or '',
                                    'year': _video.get('year') or 0,
                                    'type': _video.get('mediatype'),
                                    'plot': _video.get('plot') or '',
                                    'genre': _video.get('genre') or [],
                                    'country': _video.get('country') or [],
                                    'uniqueid': {str(k): str(v) for k, v in (item.get('unique_ids') or {}).items()
                                                 if v not in (None, '')} if isinstance(item.get('unique_ids'), dict) else {},
                                    'art': dict(art), 'filetype': 'directory' if is_folder else 'file'}))

    if category:
        try:
            xbmcplugin.setPluginCategory(handle, category)
        except Exception:
            pass

    if content:
        try:
            xbmcplugin.setContent(handle, content)
        except Exception:
            pass

    if sort_methods is not None:
        if isinstance(sort_methods, (list, tuple)):
            for method in sort_methods:
                try:
                    xbmcplugin.addSortMethod(handle, method)
                except Exception:
                    pass
        else:
            try:
                xbmcplugin.addSortMethod(handle, sort_methods)
            except Exception:
                pass

    _attach_skin_rows(store_rows)
    xbmcplugin.addDirectoryItems(handle, tuples, totalItems=(total_items if total_items is not None else len(tuples)))
    xbmcplugin.endOfDirectory(handle, succeeded=succeeded, updateListing=update_listing, cacheToDisc=cache_to_disc)


plugin.create_directory = _filmix_native_create_directory


class Utilities(object):

    @classmethod
    def get_sections(cls):
        movie_icon = plugin.get_image('DefaultMovies.png')
        tvshow_icon = plugin.get_image('DefaultTVShows.png')
        favour_icon = plugin.get_image('DefaultFavourites.png')
        search_icon = plugin.get_image('DefaultAddonsSearch.png')

        user_logged = (plugin.get_setting('user_login') != '')
        use_filters = plugin.get_setting('use_filters')

        s = [  # Main Sections
            cls._create_section_item('movies', _('Movies'), movie_icon, 'movies', section_id='999',
                                     use_filters=use_filters),
            cls._create_section_item('serials', _('TV Series'), tvshow_icon, 'tvshows', section_id='7',
                                     use_filters=use_filters),
            cls._create_section_item('genres_movies', 'Жанры фильмов', Utilities.get_filter_icon('categories'), ''),
            cls._create_section_item('genres_serials', 'Жанры сериалов', Utilities.get_filter_icon('categories'), ''),
            cls._create_section_item('countries_movies', 'Страны фильмов', Utilities.get_filter_icon('countries'), ''),
            cls._create_section_item('countries_serials', 'Страны сериалов', Utilities.get_filter_icon('countries'), ''),
            cls._create_section_item('multfilms', _('Cartoons'), movie_icon, 'movies', section_id='14',
                                     use_filters=use_filters),
            cls._create_section_item('multserials', _('Cartoon Series'), tvshow_icon, 'tvshows', section_id='93',
                                     use_filters=use_filters),
            # Popular
            cls._create_section_item('popular', _('Popular'), movie_icon, 'movies'),
            # Top Views
            cls._create_section_item('top_views', _('Top Views'), movie_icon, 'movies'),
            # Favorites
            cls._create_section_item('favorites', _('Favorites'), favour_icon, 'movies', visible=user_logged),
            # Watch Later
            cls._create_section_item('deferred', _('Watch Later'), favour_icon, 'movies', visible=user_logged),
            # Watch History
            cls._create_section_item('history', _('Watch History'), movie_icon, 'movies', visible=user_logged),
            # Search
            cls._create_section_item('search_history', _('Search'), search_icon, ''),
        ]

        return s

    @staticmethod
    def _create_section_item(section, label, icon, content, section_id=None, visible=True, use_filters=False):
        section_item = {'section': section,
                        'label': label,
                        'id': section_id,
                        'is_section': (section_id is not None),
                        'icon': icon,
                        'content': content,
                        'visible': visible,
                        'use_filters': use_filters
                        }

        return section_item

    @classmethod
    def get_section_item(cls, section):
        sections = cls.get_sections()
        for item in sections:
            if item['section'] == section:
                return item


    @classmethod
    def get_content_params(cls, content_name):
        sep = content_name.find('-')

        if sep < 0:
            return {'id': content_name,
                    'alt_name': '',
                    }

        result = {'id': content_name[:sep],
                  'alt_name': content_name[sep + 1:],
                  }

        return result

    @classmethod
    def get_pages(cls, total_items, page, section, **kwargs):
        per_page = 50

        if not isinstance(page, int):
            page = int(page)

        page_params = kwargs or {}

        pages = []
        if page > 1:
            if page == 2:
                url = plugin.url_for(section, **page_params)
            else:
                url = plugin.url_for(section, page=(page - 1), **page_params)
            item_info = {'label': _('Previous page...'),
                         'url': url}
            pages.append(item_info)

        if per_page <= total_items:
            url = plugin.url_for(section, page=(page + 1), **page_params)
            item_info = {'label': _('Next page...'),
                         'url': url}
            pages.append(item_info)

        return pages

    @classmethod
    def get_translation_link(cls, player_links, translation=None):
        if not isinstance(player_links, (list, tuple)) or not player_links:
            return None
        if len(player_links) == 1:
            return player_links[0] if isinstance(player_links[0], dict) else None

        translations = []
        candidates = []

        for link_item in player_links:
            if not isinstance(link_item, dict):
                continue
            link_translation = link_item.get('translation') or ''
            if link_translation == translation:
                return link_item

            link_qualities = cls.get_link_qualities(link_item.get('link') or '')

            if link_qualities:
                translation_title = '{0} [{1}]'.format(link_translation, link_qualities[0])
            else:
                translation_title = link_translation or _('Unknown')

            translations.append(translation_title)
            candidates.append(link_item)

        if not candidates:
            return None
        selected = xbmcgui.Dialog().select(_('Select translation'), translations)

        if 0 <= selected < len(candidates):
            return candidates[selected]

    @classmethod
    def get_link_qualities(cls, link):
        if not link:
            return []
        sub_a = link.find('[')
        sub_b = link.find(']')
        if sub_a < 0 or sub_b <= sub_a:
            return []
        qualities = link[sub_a + 1:sub_b].split(',')

        return [quality for quality in qualities if quality != '']

    @staticmethod
    def _playlist_episode_count(playlist):
        if isinstance(playlist, list):
            return len([item for item in playlist if item not in (None, '', False)])
        if isinstance(playlist, dict):
            numeric = []
            for key, item in iteritems(playlist):
                try:
                    int(str(key))
                except Exception:
                    continue
                if item not in (None, '', False):
                    numeric.append(key)
            return len(numeric) if numeric else len(playlist)
        return 0

    @staticmethod
    def get_tvshow_translations(player_links):

        if isinstance(player_links, dict):

            translations = {}

            for season, season_translations in iteritems(player_links):
                if not isinstance(season_translations, dict):
                    continue
                for translation, playlist in iteritems(season_translations):
                    translation_seasons = translations.get(translation, [])
                    season_info = {'season': season,
                                   'episodes': Utilities._playlist_episode_count(playlist)}
                    translation_seasons.append(season_info)

                    translations[translation] = translation_seasons

            for translation_seasons in translations.values():
                try:
                    translation_seasons.sort(
                        key=lambda row: (0, int(row.get('season')))
                        if str(row.get('season')).isdigit()
                        else (1, str(row.get('season'))))
                except Exception:
                    pass
            return translations

    @staticmethod
    def get_filter_title(filter_name):
        from .filters import Filters
        return Filters.get_filter_title(filter_name)

    @staticmethod
    def get_filter_icon(filter_name):
        from .filters import Filters
        return Filters.get_filter_icon(filter_name)


    @staticmethod
    def use_atl_names():
        return plugin.params.get('atl', '').lower() == 'true' \
               or plugin.get_setting('use_atl_names')

    @staticmethod
    def is_strm():
        is_strm = plugin.params.get('strm') == '1' \
                  and plugin.kodi_major_version() >= '18'
        return is_strm

    @staticmethod
    def is_movie(content_info):
        if content_info.get('player_links') is None:
            try:
                section_id = int(content_info.get('section'))
            except Exception:
                section_id = content_info.get('section')
            return section_id in [0, 14, 999]
        else:
            return len(content_info['player_links']['movie']) != 0

