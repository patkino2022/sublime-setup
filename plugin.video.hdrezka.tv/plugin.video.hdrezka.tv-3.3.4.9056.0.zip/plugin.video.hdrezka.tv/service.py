# -*- coding: utf-8 -*-
# Background service: keeps HDRezkaPlayer alive to report watch progress
# to the site ("continue watching"). No UI here.

import os
import sys

ADDON_PATH = os.path.dirname(__file__)
LIB_PATH = os.path.join(ADDON_PATH, "resources", "lib")
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)
if ADDON_PATH not in sys.path:
    sys.path.insert(0, ADDON_PATH)

import time
import xbmc

import helpers
from helpers import log
from resources.lib.HDRezkaPlayer import HDRezkaPlayer


import json
import threading

import xbmcaddon

WARM_LISTS = 2 * 3600       # первые страницы каталога (было 25 мин: сайт закрыл IP, 15.11.2026)
WARM_SERIES = 2 * 3600      # сезоны и серии начатых сериалов
BASE = 'plugin://plugin.video.hdrezka.tv/?'


def _rpc_dir(path):
    """Открыть список дополнения через Kodi (как это делает скин) - он прогреет кэш страниц."""
    try:
        xbmc.executeJSONRPC(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetDirectory',
                                        'params': {'directory': path, 'media': 'video'}}))
    except Exception as ex:
        log('prewarm fault %s: %s' % (path, ex))


def _started_series():
    """uri начатых сериалов по базе Kodi (просмотры серий HDrezka), самые свежие первыми."""
    from urllib import parse
    found = []
    try:
        con = helpers.open_videos_db()
        if not con:
            return found
        rows = con.execute("SELECT strFilename FROM files WHERE strFilename LIKE "
                           "'plugin://plugin.video.hdrezka.tv/%mode=play_episode%' "
                           "ORDER BY lastPlayed DESC LIMIT 200").fetchall()
        con.close()
        for (name,) in rows:
            q = dict(parse.parse_qsl(parse.urlsplit(name).query))
            item = (q.get('url'), q.get('season_id'))
            if item[0] and item not in found:
                found.append(item)
    except Exception as ex:
        log('prewarm started series fault: %s' % ex)
    return found[:10]


class _Monitor(xbmc.Monitor):
    """Один объект настроек на службу (было: новый каждую минуту в обоих потоках); Kodi
    сообщает об изменении настроек, в том числе из процесса дополнения (вход пишет cookies), -
    тогда берётся новый (21.11.2026)."""

    def __init__(self):
        super(_Monitor, self).__init__()
        self.addon = xbmcaddon.Addon(helpers.ADDON_ID)

    def onSettingsChanged(self):
        self.addon = xbmcaddon.Addon(helpers.ADDON_ID)


def prewarm(monitor, player):
    """Как lite prewarm у Filmix: в фоне, пока ничего не играет."""
    from urllib.parse import urlencode
    last_lists = last_series = 0
    if monitor.waitForAbort(90):          # дать Kodi и скину подняться
        return
    while not monitor.abortRequested():
        try:
            skin_mode = monitor.addon.getSettingBool('skin_mode')
        except Exception:
            skin_mode = True
        if _WARM_NOW:
            # смена зеркала или возврат связи - добрать пропущенное сразу, не ждать 2 часа
            del _WARM_NOW[:]
            last_lists = last_series = 0
        if skin_mode and not player.isPlaying() and helpers.logged_in(monitor.addon):
            now = time.time()
            if now - last_lists > WARM_LISTS:
                for uri, flt in (('/films/', ''), ('/series/', ''), ('/', 'popular'), ('/', 'watching')):
                    if monitor.abortRequested() or player.isPlaying():
                        break
                    _rpc_dir(BASE + urlencode(dict(mode='index', uri=uri, warm='1', **({'query_filter': flt} if flt else {}))))
                    monitor.waitForAbort(3)
                last_lists = now
                log('prewarm: каталог освежён')
            if now - last_series > WARM_SERIES:
                for uri, season in _started_series():
                    if monitor.abortRequested() or player.isPlaying():
                        break
                    _rpc_dir(BASE + urlencode({'mode': 'show', 'uri': uri, 'warm': '1'}))
                    if season:
                        _rpc_dir(BASE + urlencode({'mode': 'show', 'uri': uri, 'season': season}))
                    monitor.waitForAbort(3)
                last_series = now
                log('prewarm: начатые сериалы освежены')
        if monitor.waitForAbort(60):
            break


_WARM_NOW = []


def server_watch_loop(monitor):
    """Сведения о зеркалах раз в минуту (server_watch.py): текущее не отвечает 15 минут при
    живом интернете - переход на точно работающее, у вошедшего - вход на новом зеркале;
    после смены или возврата связи - прогрев каталога и сериалов сразу (добор пропущенного),
    скин видит смену по epoch в servers.json и пересобирает полосы.
    Запасные зеркала щупаются только при отказе текущего (mirrors.server_watch, 21.11.2026)."""
    import xbmcvfs
    import mirror_probe
    import mirrors              # не default.py: служба не грузит дополнение целиком (21.11.2026)
    if monitor.waitForAbort(60):
        return
    addon = watch = None
    while not monitor.abortRequested():
        try:
            if addon is not monitor.addon:
                # сведения о зеркалах - заново только при смене настроек (логин, зеркало, автовыбор)
                addon = monitor.addon
                profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
                login = bool(addon.getSetting('username') and addon.getSetting('password'))
                watch = mirrors.server_watch(profile, addon)
            if not watch.auto:
                if monitor.waitForAbort(60):
                    break
                continue

            def probe(domain):
                state = mirror_probe.rezka(domain)
                return state == 'open' or (login and state == 'login')
            event = watch.tick(probe)
            if event == 'switched' and login:
                try:
                    from default import HdrezkaTV
                    HdrezkaTV()._quiet_login()
                except Exception as ex:
                    log('вход на новом зеркале: %s' % ex)
            if event:
                _WARM_NOW.append(event)
        except Exception as ex:
            log('server watch fault: %s' % ex)
        if monitor.waitForAbort(60):
            break


if __name__ == '__main__':
    player = HDRezkaPlayer()
    monitor = _Monitor()
    last_autosave = time.time()
    threading.Thread(target=prewarm, args=(monitor, player), name='hdrezka-prewarm', daemon=True).start()
    threading.Thread(target=server_watch_loop, args=(monitor,), name='hdrezka-servers', daemon=True).start()

    while not monitor.abortRequested():
        if player.current_video and not player.is_paused and player.isPlaying():
            try:
                pos = player.getTime()
                if pos > 0:
                    player.last_position = pos
                total_time = player.getTotalTime()
                if total_time > 0 and (not player.current_video.get('duration') or player.current_video['duration'] <= 0):
                    player.current_video['duration'] = total_time

                # Periodic cloud sync every 60 seconds
                if time.time() - last_autosave >= 60:
                    player._send_intermediate_save()
                    last_autosave = time.time()
            except Exception as ex:
                log('service fault getTime ex: %s' % ex)
        if monitor.waitForAbort(15):
            break
