"""Kodi side of service.tvlink: settings -> config.json, and the daemon's life.

The daemon is a separate python3 process (streams never wait for Kodi's GIL);
Kodi starts it at startup and stops it on exit. Where no system python3 exists
the daemon runs in a thread here instead.
"""
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
L = ADDON.getLocalizedString
ROOT = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
LIB = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "resources", "lib")
sys.path.insert(0, LIB)

from tvlinkd.store import Paths, read_json, write_json  # noqa: E402
from tvlinkd import tls  # noqa: E402

tls.install()   # https и в этой службе - без хранилища системы, если оно испорчено (tls.py)

CATCHUP = ["auto", "shift", "flussonic", "none"]
PYTHON3 = "/usr/bin/python3"


def _is_elec():
    """Отдельный процесс демона - только на CoreELEC/LibreELEC: на macOS /usr/bin/python3 - заглушка
    Xcode (просит поставить средства разработчика), на настольном Linux - чужой python."""
    try:
        with open("/etc/os-release", encoding="utf-8") as f:
            return "ELEC" in f.read()
    except OSError:
        return False


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[service.tvlink] %s" % msg, level)


def settings_to_config():
    a = xbmcaddon.Addon()
    s, b, i = a.getSetting, a.getSettingBool, a.getSettingInt
    pls = []
    for n in range(1, 6):
        if b("pl%d_enabled" % n) and s("pl%d_url" % n).strip():
            pls.append({"name": s("pl%d_name" % n).strip() or "Плейлист %d" % n,
                        "url": s("pl%d_url" % n).strip(),
                        "catchup": CATCHUP[min(i("pl%d_catchup" % n), 3)],
                        "add_new": b("pl%d_addnew" % n),
                        "check": b("pl%d_check" % n),
                        "days": i("archive_days")})
    epg = []
    for n in range(1, 7):
        if b("epg%d_enabled" % n) and s("epg%d_url" % n).strip():
            epg.append({"name": s("epg%d_name" % n).strip() or "EPG %d" % n, "url": s("epg%d_url" % n).strip()})
    return {
        "host": s("host").strip() or "127.0.0.1",
        "port": i("port"), "stream_port": i("stream_port"),
        "user_agent": s("user_agent").strip() or "SmartSDK",
        "playlists": pls, "epg": epg,
        "epg_from_playlist": b("epg_from_playlist"),
        "refresh_hours": i("refresh_hours"),
        "archive_days": i("archive_days"),
        "strip_suffixes": [x.strip() for x in s("strip_suffixes").split(",") if x.strip()],
        "logo_pack": s("logo_pack").strip(),
        "live_edge": i("live_edge"), "timeout": i("timeout"), "switch_after": i("switch_after"),
    }


# One place per setting. Kodi's own TV settings own the guide window and the
# update interval; this add-on owns sources, order and numbers; pvr.tvlink is
# set from both and never needs to be opened.
KODI_EPG = ("epg.pastdaystodisplay", "epg.futuredaystodisplay", "epg.epgupdate")
KODI_ORDER = {"pvrmanager.backendchannelorder": True,          # our order is the order
              "pvrmanager.backendchannelgroupsorder": True,
              "pvrmanager.usebackendchannelnumbers": True}     # our numbers are the numbers


def kodi_setting(sid):
    r = _rpc("Settings.GetSettingValue", {"setting": sid})
    return (r.get("result") or {}).get("value")


def kodi_epg():
    past, future, update = (kodi_setting(k) for k in KODI_EPG)
    return {"epg_past_days": int(past if past is not None else 1),
            # one day beyond what Kodi shows: the guide is rebuilt once per interval
            # and pvr.tvlink rejects a cache that ends 6 h short of Kodi's window
            "epg_future_days": int(future if future is not None else 2) + 1,
            "epg_interval_min": max(60, int(update or 720))}


def enforce_kodi_order():
    for sid, val in KODI_ORDER.items():
        if kodi_setting(sid) is not None and kodi_setting(sid) != val:
            _rpc("Settings.SetSettingValue", {"setting": sid, "value": val})
            log("Kodi %s -> %s" % (sid, val))


CLIENTS = ("pvr.sublime", "pvr.tvlink")   # own build first, AlexELEC's as fallback


def pvr_client():
    """The TV client in use: pvr.sublime (built from pvr.tvlink, not tied to the
    AlexELEC image) when it is enabled, else the image's pvr.tvlink."""
    for cid in CLIENTS:
        if xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % cid):
            return cid
    return None


def sync_pvr_client(cfg):
    """Point the TV client at this box's daemon and give it Kodi's update interval."""
    cid = pvr_client()
    try:
        pvr = xbmcaddon.Addon(cid) if cid else None
    except RuntimeError:
        pvr = None
    if pvr is None:
        return False
    want = {"tvlinkIP": cfg["host"], "tvlinkPort": str(cfg["port"]), "tvlinkUser": "", "tvlinkToken": "",
            # 21.11.2026: без перечитывания по таймеру (каждые 180 мин весь плейлист и xmltv):
            # клиент перечитывает по любой смене настройки в любом режиме
            # (PVRLinkData::SetSetting), а новые файлы демона ему сообщает nudge_pvr_client.
            # Кэш m3u в режиме 0 начинает действовать (PlaylistLoader) - держим выключенным.
            "m3uRefreshMode": "0", "m3uCache": "false",
            "startNum": "1", "numberByOrder": "false", "directCatchup": "false", "epgTimeShift": "0",
            "connectTimeout": "10"}
    diff = {k: v for k, v in want.items() if pvr.getSetting(k) != v}
    if not diff:
        return False
    log("%s settings: %s" % (cid, ", ".join("%s=%s" % kv for kv in sorted(diff.items()))))
    for k, v in diff.items():
        pvr.setSetting(k, v)   # one reload of the client follows, by Kodi
    return True


def sync_config(paths, pvr=True):
    cfg = settings_to_config()
    cfg.update(kodi_epg())
    if read_json(paths.config) != cfg:
        write_json(paths.config, cfg)
        log("config written: %d playlists, %d guides, guide %d+%d days every %d min"
            % (len(cfg["playlists"]), len(cfg["epg"]), cfg["epg_past_days"], cfg["epg_future_days"],
               cfg["epg_interval_min"]))
    if pvr:
        sync_pvr_client(cfg)
    return cfg


class Daemon:
    def __init__(self, paths):
        self.paths, self.proc, self.thread, self.stop_evt = paths, None, None, None
        self.starts = []

    def start(self):
        self.starts = [t for t in self.starts if time.time() - t < 600] + [time.time()]
        if os.path.exists(PYTHON3) and _is_elec():
            self.proc = subprocess.Popen([PYTHON3, "-I", os.path.join(LIB, "tvlinkd_run.py"), "daemon",
                                          ROOT, str(os.getpid())],
                                         cwd=ROOT, stdin=subprocess.DEVNULL,
                                         stdout=subprocess.DEVNULL, stderr=open(self.paths.log + ".err", "ab"))
            log("daemon started pid=%d" % self.proc.pid)
        else:
            from tvlinkd import daemon
            self.thread = threading.Thread(target=daemon.main, args=(ROOT, os.getpid()), daemon=True)
            self.thread.start()
            log("daemon running in-process (no %s)" % PYTHON3)

    def alive(self):
        if self.proc:
            return self.proc.poll() is None
        return bool(self.thread and self.thread.is_alive())

    def stop(self):
        if self.thread is not None:
            from tvlinkd import daemon
            daemon.stop_all()
            self.thread.join(5)
            log("daemon stopped (in-process)")
            return
        if self.proc and self.proc.poll() is None:
            self.proc.terminate()
            try:
                self.proc.wait(3)
            except subprocess.TimeoutExpired:
                self.proc.kill()
            log("daemon stopped")


class Monitor(xbmc.Monitor):
    def __init__(self, paths):
        super().__init__()
        self.paths = paths

    def onSettingsChanged(self):
        sync_config(self.paths)


def _playlist_ok(cfg):
    try:
        with urllib.request.urlopen("http://127.0.0.1:%d/playlist" % cfg["port"], timeout=3) as r:
            return r.status == 200 and b"#EXTINF" in r.read(4096)
    except OSError:
        return False


def _rpc(method, params):
    return json.loads(xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1, "method": method, "params": params})))


def nudge_pvr_client(why):
    """Make pvr.tvlink reload the playlist and guide in its own thread.

    Any setting change does that. m3uRefreshHour only matters in refresh mode 2
    and we run mode 0 (21.11.2026, was 1), so flipping it changes nothing else. Disabling and
    re-enabling the add-on did the same but tore down Kodi's PVR manager, and a
    Player.Open {channelid} arriving in that second crashes Kodi in
    CPVRChannelGroup::GetByChannelID (twice on .30, 19.10.2026 -> safe mode)."""
    cid = pvr_client()
    try:
        pvr = xbmcaddon.Addon(cid) if cid else None
    except RuntimeError:
        pvr = None
    if pvr is None:
        return
    hour = "5" if pvr.getSetting("m3uRefreshHour") == "4" else "4"
    log("asking %s to reload (%s)" % (cid, why))
    pvr.setSetting("m3uRefreshHour", hour)


def rts_binding_check(paths, last):
    """Tell the owner on the TV when the RTS Planeta binding is lost (RTS
    channels other than RTS Svet then stop). At most every 6 h."""
    return last   # sublime-setup: RTS Planeta не входит
    st = read_json(os.path.join(paths.root, "rtsplaneta.json"), {}) or {}
    if not st.get("bound_once") or st.get("signed", True):
        return last
    if time.time() - last < 6 * 3600:
        return last
    ip = xbmc.getInfoLabel("Network.IPAddress") or L(30140)
    xbmcgui.Dialog().notification("RTS Planeta", L(30139) % ip,
                                  xbmcgui.NOTIFICATION_WARNING, 15000)
    log("RTS Planeta binding lost - owner notified", xbmc.LOGWARNING)
    return time.time()


def _published(paths):
    st = read_json(paths.status, {}) or {}
    return (st.get("epg_built"), st.get("playlist_sig"))


def main():
    paths = Paths(ROOT)
    cfg = sync_config(paths, pvr=False)
    mon = Monitor(paths)
    d = Daemon(paths)
    was_down = not _playlist_ok(cfg)
    d.start()
    # pvr.tvlink reloads the moment its settings change and asks for the playlist
    # once: point it here only when the daemon answers (19.10.2026 on .30 it was
    # pointed 0.9 s too early and stayed without channels)
    t0 = time.time()
    while not _playlist_ok(cfg) and time.time() - t0 < 20 and not mon.waitForAbort(0.2):
        pass
    log("daemon answers after %.1fs" % (time.time() - t0))
    changed = sync_pvr_client(cfg)
    if was_down and not changed and xbmc.getCondVisibility("System.HasPVRAddon"):
        # Kodi creates PVR clients ~1.2 s after start, python services ~2.7 s, so at
        # boot pvr.tvlink always asked before we listened and will not ask again
        # until its next refresh: Kodi's channel list then is a stale database copy
        # that cannot play. (Measured on .30, 19.10.2026; TVLINK hid this by holding
        # Kodi's start 4 s in kodi-tvlink.service.)
        nudge_pvr_client("it started before the daemon answered")
    enforce_kodi_order()
    seen = _published(paths)
    pending_since = None
    tick = 0
    rts_warned = 0.0
    while not mon.waitForAbort(5):
        tick += 1
        # клиент сам плейлист и гид не перечитывает (режим 0 с 21.11.2026):
        # говорим ему о новых файлах демона, но не во время просмотра ТВ
        now = _published(paths)
        if now != seen:
            pending_since = pending_since or time.time()
            watching = xbmc.getCondVisibility("Pvr.IsPlayingTV | Pvr.IsPlayingRadio")
            if time.time() - pending_since >= 10 and not watching:
                nudge_pvr_client("new %s" % ("guide" if now[0] != seen[0] else "channel list"))
                seen, pending_since = now, None
        if tick % 12 == 0:      # Kodi tells add-ons nothing about its own settings: look each minute
            sync_config(paths)
            rts_warned = rts_binding_check(paths, rts_warned)
        if not d.alive():
            if len(d.starts) >= 5:
                log("daemon keeps dying, see %s.err" % paths.log, xbmc.LOGERROR)
                mon.waitForAbort(60)
            d.start()
    d.stop()


main()
