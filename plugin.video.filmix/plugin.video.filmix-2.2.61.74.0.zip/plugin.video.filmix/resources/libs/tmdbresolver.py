# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import html
import json
import re
import copy
import time


from .utilities import plugin


# map Filmix country labels (mostly Russian names) to ISO-3166-1 codes so a
# resolved TMDb identity can be rejected when its origin country cannot match the source
# item's country. Only used to reject on a *clear* mismatch; unknown names are ignored,
# so an incomplete map can never cause a false rejection.
_RU_COUNTRY_TO_ISO = {
    'россия': 'RU', 'russia': 'RU', 'ссср': 'RU', 'рф': 'RU',
    'сша': 'US', 'usa': 'US', 'america': 'US', 'соединённые штаты': 'US', 'соединенные штаты': 'US',
    'великобритания': 'GB', 'англия': 'GB', 'uk': 'GB', 'британия': 'GB',
    'гонконг': 'HK', 'hong kong': 'HK', 'китай': 'CN', 'кнр': 'CN', 'china': 'CN',
    'тайвань': 'TW', 'япония': 'JP', 'japan': 'JP',
    'корея южная': 'KR', 'южная корея': 'KR', 'корея': 'KR', 'республика корея': 'KR',
    'франция': 'FR', 'германия': 'DE', 'фрг': 'DE', 'италия': 'IT', 'испания': 'ES',
    'канада': 'CA', 'австралия': 'AU', 'индия': 'IN', 'турция': 'TR', 'португалия': 'PT',
    'бразилия': 'BR', 'мексика': 'MX', 'аргентина': 'AR', 'чили': 'CL', 'колумбия': 'CO',
    'швеция': 'SE', 'норвегия': 'NO', 'дания': 'DK', 'финляндия': 'FI', 'исландия': 'IS',
    'нидерланды': 'NL', 'голландия': 'NL', 'бельгия': 'BE', 'польша': 'PL', 'украина': 'UA',
    'чехия': 'CZ', 'словакия': 'SK', 'австрия': 'AT', 'швейцария': 'CH', 'ирландия': 'IE',
    'новая зеландия': 'NZ', 'таиланд': 'TH', 'сингапур': 'SG', 'филиппины': 'PH',
    'индонезия': 'ID', 'малайзия': 'MY', 'вьетнам': 'VN', 'иран': 'IR', 'израиль': 'IL',
    'египет': 'EG', 'юар': 'ZA', 'марокко': 'MA', 'греция': 'GR', 'венгрия': 'HU',
    'румыния': 'RO', 'болгария': 'BG', 'сербия': 'RS', 'хорватия': 'HR', 'словения': 'SI',
    'литва': 'LT', 'латвия': 'LV', 'эстония': 'EE', 'грузия': 'GE', 'армения': 'AM',
    'казахстан': 'KZ', 'беларусь': 'BY', 'белоруссия': 'BY',
}


def _country_text_to_isos(value):
    """ISO codes from a free-text country string ("Гонконг / Китай", "US", ...)."""
    isos = set()
    for token in re.split(r'[,/;|]+', str(value or '')):
        token = token.strip().casefold()
        if not token:
            continue
        if len(token) == 2 and token.isalpha():
            isos.add(token.upper())
            continue
        code = _RU_COUNTRY_TO_ISO.get(token)
        if code:
            isos.add(code)
    return isos

__all__ = ['TMDbResolver']


class TMDbResolver(object):
    base_url = 'https://api.themoviedb.org/3'


    @classmethod
    def _csv_set(cls, value):
        result = set()
        for part in str(value or '').split(','):
            part = part.strip()
            if part:
                result.add(part)
        return result

    @classmethod
    def _blocked_tmdb_ids_for_item(cls, item):
        if isinstance(item, dict):
            return cls._csv_set(item.get('_filmix_blocked_tmdb_ids'))
        return set()

    @classmethod
    def _blocked_imdb_ids_for_item(cls, item):
        if isinstance(item, dict):
            return cls._csv_set(item.get('_filmix_blocked_imdb_ids'))
        return set()

    @classmethod
    def _title_resolve_blocked(cls, item):
        if not isinstance(item, dict):
            return False
        return str(item.get('_filmix_block_title_resolve') or '').lower() in ('1', 'true', 'yes')

    @classmethod
    def _resolved_identity_blocked(cls, item, resolved):
        if not isinstance(resolved, dict):
            return False
        tmdb_id = resolved.get('resolved_tmdb_id') or resolved.get('tmdb_id') or resolved.get('tmdb')
        imdb_id = resolved.get('resolved_imdb_id') or resolved.get('imdb_id') or resolved.get('imdb')
        if tmdb_id and str(tmdb_id) in cls._blocked_tmdb_ids_for_item(item):
            return True
        if imdb_id and str(imdb_id) in cls._blocked_imdb_ids_for_item(item):
            return True
        return False


    def __init__(self, api_key=None, language=None, timeout=8):
        self.api_key = api_key if api_key is not None else (plugin.get_setting('tmdb_api_key') or '')
        raw_language = language if language is not None else (plugin.get_setting('tmdb_api_language') or 'ru-RU')
        raw_language = str(raw_language or '').strip().lower()
        if raw_language in ('sr', 'sr-rs', 'sr_rs', 'sr-yu', 'sr_yu'):
            self.language = 'sr-RS'
        else:
            # STRICT_RU_SR: old settings may still contain uk-UA/en/de/etc.; never use them.
            self.language = 'ru-RU'
        self.timeout = timeout
        self._session_obj = None
        self._response_cache = {}
        self.max_resolve_requests = 16
        self.resolve_deadline_seconds = 12.0
        self._resolve_deadline = 0.0
        self._resolve_request_count = 0

    @property
    def _session(self):
        # Сессия (и сама библиотека requests) - при первом настоящем запросе:
        # сверка номера TMDb теперь обычно берётся из сохранённого ответа
        # (_details), и грузить 0.34 с ради неё незачем.
        if self._session_obj is None:
            import requests
            self._session_obj = requests.Session()
            self._session_obj.headers.update({
                'Accept': 'application/json',
                'User-Agent': 'Kodi-Filmix-TMDbResolver/1.1'
            })
        return self._session_obj

    def __del__(self):
        try:
            if self._session_obj is not None:
                self._session_obj.close()
        except Exception:
            pass

    @property
    def enabled(self):
        return bool(self.api_key)

    def _get(self, path, params=None):
        if not self.enabled:
            return {}
        params = dict(params or {})
        params['api_key'] = self.api_key
        if self.language:
            params.setdefault('language', self.language)
        try:
            cache_key = (str(path), tuple(sorted((str(k), str(v)) for k, v in params.items())))
            if cache_key in self._response_cache:
                return copy.deepcopy(self._response_cache[cache_key])
        except Exception:
            cache_key = None
        if self._resolve_deadline:
            remaining = float(self._resolve_deadline) - time.monotonic()
            if remaining <= 0:
                raise RuntimeError('TMDb resolver deadline exceeded')
            if int(self._resolve_request_count or 0) >= int(self.max_resolve_requests):
                raise RuntimeError('TMDb resolver request budget exceeded')
            timeout = max(0.5, min(float(self.timeout or 8), remaining))
            self._resolve_request_count += 1
        else:
            timeout = self.timeout
        r = self._session.get(self.base_url + path, params=params, timeout=timeout)
        r.raise_for_status()
        result = r.json() or {}
        if cache_key is not None:
            try:
                self._response_cache[cache_key] = copy.deepcopy(result)
            except Exception:
                pass
        return result

    @staticmethod
    def _clean_text(value):
        if value is None:
            return ''
        if not isinstance(value, str):
            value = str(value)
        value = html.unescape(value)
        value = value.replace(' ', ' ')
        value = re.sub(r'<[^>]+>', ' ', value)
        value = re.sub(r'\s+', ' ', value, flags=re.UNICODE).strip()
        return value

    @classmethod
    def _normalize(cls, value):
        value = cls._clean_text(value).lower()
        value = value.replace('ё', 'е')
        value = re.sub(r'[^\w\s]+', ' ', value, flags=re.UNICODE)
        value = re.sub(r'\s+', ' ', value, flags=re.UNICODE).strip()
        return value

    @staticmethod
    def _normalize_date(value):
        if not value:
            return None
        value = str(value).strip()
        if re.match(r'^\d{4}-\d{2}-\d{2}$', value):
            return value
        m = re.search(r'(\d{4}-\d{2}-\d{2})', value)
        if m:
            return m.group(1)
        return None

    @staticmethod
    def _date_key(tmdb_type):
        return 'release_date' if tmdb_type == 'movie' else 'first_air_date'

    @classmethod
    def _premiered_from_result(cls, result, tmdb_type):
        if not isinstance(result, dict):
            return None
        return cls._normalize_date(result.get(cls._date_key(tmdb_type)))

    @classmethod
    def _release_dates_from_movie_details(cls, details):
        dates = []
        if not isinstance(details, dict):
            return dates
        release_dates = (details.get('release_dates') or {}).get('results') or []
        country_priority = ['RU', 'RS', 'US', 'GB', 'CA', 'AU', 'DE', 'FR', 'IT', 'ES']
        by_country = {}
        for country in release_dates:
            if not isinstance(country, dict):
                continue
            iso = str(country.get('iso_3166_1') or '').upper()
            country_dates = []
            for entry in country.get('release_dates') or []:
                if not isinstance(entry, dict):
                    continue
                value = cls._normalize_date(entry.get('release_date'))
                if value:
                    country_dates.append(value)
            if country_dates:
                by_country[iso] = sorted(set(country_dates))
        for iso in country_priority:
            for value in by_country.get(iso, []):
                if value not in dates:
                    dates.append(value)
        for values in by_country.values():
            for value in values:
                if value not in dates:
                    dates.append(value)
        return dates

    @classmethod
    def _tv_dates_from_details(cls, details):
        dates = []
        if not isinstance(details, dict):
            return dates
        value = cls._normalize_date(details.get('first_air_date'))
        if value:
            dates.append(value)
        for season in details.get('seasons') or []:
            if not isinstance(season, dict):
                continue
            try:
                if int(season.get('season_number') or 0) <= 0:
                    continue
            except Exception:
                pass
            value = cls._normalize_date(season.get('air_date'))
            if value and value not in dates:
                dates.append(value)
        for key in ('last_episode_to_air', 'next_episode_to_air'):
            episode = details.get(key) or {}
            if isinstance(episode, dict):
                value = cls._normalize_date(episode.get('air_date'))
                if value and value not in dates:
                    dates.append(value)
        return sorted(dates)

    @classmethod
    def _premiered_from_details(cls, details, tmdb_type):
        direct = cls._premiered_from_result(details, tmdb_type)
        if direct:
            return direct
        if tmdb_type == 'movie':
            dates = cls._release_dates_from_movie_details(details)
            return dates[0] if dates else None
        dates = cls._tv_dates_from_details(details)
        return dates[0] if dates else None

    @classmethod
    def _year_from_premiered(cls, premiered):
        if premiered and len(str(premiered)) >= 4 and str(premiered)[:4].isdigit():
            try:
                return int(str(premiered)[:4])
            except Exception:
                return None
        return None

    @classmethod
    def _date_from_year(cls, year):
        if year in [None, '']:
            return None
        try:
            year = int(str(year).strip()[0:4])
        except Exception:
            return None
        if 1900 <= year <= 2100:
            return '{0:04d}-01-01'.format(year)
        return None

    @classmethod
    def _fallback_year_from_item(cls, data):
        if not isinstance(data, dict):
            return None
        for key in ('year', 'release_year', 'production_year'):
            value = data.get(key)
            if value in [None, '']:
                continue
            try:
                year = int(str(value).strip()[0:4])
            except Exception:
                continue
            if 1900 <= year <= 2100:
                return year
        for key in ('premiered', 'release_date', 'first_air_date', 'released', 'date_release', 'air_date'):
            value = cls._clean_text(data.get(key))
            m = re.search(r'\b(19\d{2}|20\d{2}|2100)\b', value or '')
            if m:
                return int(m.group(1))
        return None

    @classmethod
    def _add_year_candidate(cls, years, value):
        try:
            year = int(str(value).strip()[0:4])
        except Exception:
            return
        if 1900 <= year <= 2100 and year not in years:
            years.append(year)

    @classmethod
    def _text_year_candidates_from_item(cls, data):
        years = []
        if not isinstance(data, dict):
            return years
        text_keys = (
            # Prefer Filmix/source fields and slug/post URL.  Do not read
            # resolved_* date fields here: stale TMDb cache may already carry
            # the wrong candidate's year and would hide a mismatch.
            'date_release', 'released', 'release', 'title', 'original_title',
            'name', 'original_name', 'alt_name', 'post_url', 'url', 'link', 'href'
        )
        for key in text_keys:
            value = cls._clean_text(data.get(key))
            if not value:
                continue
            for m in re.finditer(r'(?<!\d)(19\d{2}|20\d{2}|2100)(?!\d)', value):
                cls._add_year_candidate(years, m.group(1))
        return years

    @classmethod
    def _year_candidates_from_item(cls, data):
        if not isinstance(data, dict):
            return []
        years = []
        # Text/slug years are source evidence and take priority over a generic
        # year field, because stale resolved_ids may have already overwritten
        # item['year'] with a wrong TMDb candidate year.
        for year in cls._text_year_candidates_from_item(data):
            cls._add_year_candidate(years, year)
        for key in ('year', 'release_year', 'production_year'):
            value = data.get(key)
            if value not in [None, '']:
                cls._add_year_candidate(years, value)
        return years

    @classmethod
    def _best_item_year(cls, data):
        years = cls._text_year_candidates_from_item(data) or cls._year_candidates_from_item(data)
        return years[0] if years else None

    @staticmethod
    def _episode_collection_count(value):
        if isinstance(value, (list, tuple, set)):
            return len(value)
        if isinstance(value, dict):
            numeric = 0
            for key, item in value.items():
                try:
                    int(str(key))
                except Exception:
                    continue
                if item not in (None, '', False):
                    numeric += 1
            return numeric if numeric else len(value)
        return 0

    @classmethod
    def _tv_shape_from_item(cls, data):
        shape = {'season_count': 0, 'total_episodes': 0, 'season_counts': {}}
        if not isinstance(data, dict):
            return shape
        player_links = data.get('player_links') or {}
        playlist = player_links.get('playlist') if isinstance(player_links, dict) else None
        if not isinstance(playlist, dict):
            return shape
        for season, translations in playlist.items():
            try:
                season_no = int(str(season))
            except Exception:
                continue
            if season_no <= 0 or not isinstance(translations, dict):
                continue
            counts = []
            for episodes in translations.values():
                count = cls._episode_collection_count(episodes)
                if count > 0:
                    counts.append(count)
            if not counts:
                continue
            season_count = max(counts)
            shape['season_counts'][season_no] = season_count
            shape['total_episodes'] += season_count
        shape['season_count'] = len(shape['season_counts'])
        return shape

    @classmethod
    def _tv_shape_from_details(cls, details):
        shape = {'season_count': 0, 'total_episodes': 0, 'season_counts': {}}
        if not isinstance(details, dict):
            return shape
        try:
            total = int(details.get('number_of_episodes') or 0)
        except Exception:
            total = 0
        shape['total_episodes'] = total
        seasons = details.get('seasons') or []
        for season in seasons:
            if not isinstance(season, dict):
                continue
            try:
                season_no = int(season.get('season_number'))
            except Exception:
                continue
            if season_no <= 0:
                continue
            try:
                ep_count = int(season.get('episode_count') or 0)
            except Exception:
                ep_count = 0
            if ep_count > 0:
                shape['season_counts'][season_no] = ep_count
        shape['season_count'] = len(shape['season_counts'])
        if not shape['total_episodes'] and shape['season_counts']:
            shape['total_episodes'] = sum(shape['season_counts'].values())
        return shape

    @classmethod
    def _result_year_from_resolved(cls, resolved, details=None, tmdb_type=None):
        if isinstance(details, dict):
            premiered = cls._premiered_from_details(details, tmdb_type or (resolved or {}).get('resolved_tmdb_type') or (resolved or {}).get('tmdb_type') or 'tv')
            year = cls._year_from_premiered(premiered)
            if year:
                return year
        if isinstance(resolved, dict):
            for key in ('resolved_year', 'year'):
                value = resolved.get(key)
                if value not in [None, '']:
                    try:
                        year = int(str(value)[0:4])
                    except Exception:
                        continue
                    if 1900 <= year <= 2100:
                        return year
            for key in ('resolved_premiered', 'premiered', 'first_air_date', 'release_date', 'date'):
                year = cls._year_from_premiered(resolved.get(key))
                if year:
                    return year
        return None

    @classmethod
    def _tv_last_air_year(cls, resolved=None, details=None):
        """Year a series last aired, from TMDb details or from what was stored.

        Falls back to the newest season air_date, because a still-running show
        reports last_air_date as the most recent episode and an ended one as its
        finale - both are the end of the range this needs. 0 when unknown, which
        keeps the caller on the strict ±1 rule.
        """
        for source in (details or {}, resolved or {}):
            if not isinstance(source, dict):
                continue
            for key in ('last_air_date', 'resolved_last_air', 'resolved_last_air_date'):
                year = cls._year_from_premiered(source.get(key))
                if year:
                    return year
        seasons = (details or {}).get('seasons') if isinstance(details, dict) else None
        newest = 0
        for season in (seasons or []):
            if not isinstance(season, dict):
                continue
            year = cls._year_from_premiered(season.get('air_date'))
            if year and year > newest:
                newest = year
        return newest

    @classmethod
    def validate_resolved_match(cls, item, resolved, details=None, tmdb_type=None, source_countries=None):
        """Reject generic TMDb false positives before they poison cache/art.

        This is intentionally data-driven: no Filmix post ids, no title blacklists.
        A title-only TMDb hit is accepted only if stable facts from Filmix
        (year/slug/player playlist shape) do not contradict the TMDb identity.
        """
        if not isinstance(resolved, dict) or not resolved.get('resolved_tmdb_id'):
            return True, ''
        r_type = (tmdb_type or resolved.get('resolved_tmdb_type') or resolved.get('tmdb_type') or '').lower()
        if r_type in ('show', 'series', 'tvshow'):
            r_type = 'tv'
        if r_type not in ('movie', 'tv'):
            r_type = 'tv'

        item_years = cls._text_year_candidates_from_item(item) or cls._year_candidates_from_item(item)
        result_year = cls._result_year_from_resolved(resolved, details=details, tmdb_type=r_type)
        if item_years and result_year:
            if min(abs(int(result_year) - int(year)) for year in item_years) > 1:
                # A film has one year and ±1 covers festival/premiere/release
                # disagreement. A series does not: TMDb reports the year it
                # FIRST aired, while a Filmix post is one release of it - a dub,
                # a season, a re-run - and carries that year instead. «Безумцы»
                # sits at .../8294-20ll22-bezumcy-2010/ because Fox Life aired
                # it in 2010; Mad Men first aired in 2007 and ran to 2015, so
                # this gate rejected the correct show outright
                # (`year_mismatch:2010!=2007`, recorded in
                # docs/ARCHITECTURE_PLUGIN.md) and the series stayed identityless
                # - no episode names, no stills, and the skin then attached
                # someone else's art to it.
                #
                # The airing range is the honest comparison for a series: accept
                # when the post's year falls inside first_air_date..last_air_date
                # (±1 at both ends). A same-titled series from a different era
                # still fails, because its own range will not contain that year.
                last_year = cls._tv_last_air_year(resolved, details) if r_type == 'tv' else 0
                in_air_range = bool(
                    r_type == 'tv' and last_year and
                    any(int(result_year) - 1 <= int(year) <= int(last_year) + 1
                        for year in item_years))
                if not in_air_range:
                    return False, 'year_mismatch:{0}!={1}'.format('/'.join([str(y) for y in item_years]), result_year)

        if r_type == 'tv':
            expected = cls._tv_shape_from_item(item)
            actual = cls._tv_shape_from_details(details)
            if expected.get('season_count') and actual.get('season_count'):
                e_seasons = int(expected.get('season_count') or 0)
                a_seasons = int(actual.get('season_count') or 0)
                if e_seasons >= 3 and a_seasons + 1 < e_seasons:
                    return False, 'season_count_mismatch:{0}>{1}'.format(e_seasons, a_seasons)
            expected_counts = expected.get('season_counts') or {}
            actual_counts = actual.get('season_counts') or {}
            for season_no, expected_eps in expected_counts.items():
                actual_eps = int(actual_counts.get(season_no) or 0)
                if expected_eps >= 8 and actual_eps > 0 and actual_eps < max(3, int(expected_eps * 0.5)):
                    return False, 'episode_count_mismatch:s{0}:{1}>{2}'.format(season_no, expected_eps, actual_eps)
            if expected.get('total_episodes') and actual.get('total_episodes'):
                e_total = int(expected.get('total_episodes') or 0)
                a_total = int(actual.get('total_episodes') or 0)
                if e_total >= 40 and a_total > 0 and a_total < max(10, int(e_total * 0.4)):
                    return False, 'total_episode_mismatch:{0}>{1}'.format(e_total, a_total)

        # country mismatch. A generic title ("Сезон") can fuzzy-match a
        # same-year show from another country ("Брачный сезон"). When both the Filmix
        # source country and the TMDb origin country are known and share no country,
        # reject - this is the missing guard that let tmdb=290295 poison episode art.
        # Unknown country on either side is ignored, so this never rejects on doubt.
        item_isos = set(source_countries) if source_countries else cls._item_country_isos(item)
        detail_isos = cls._details_country_isos(details)
        if item_isos and detail_isos and not (item_isos & detail_isos):
            return False, 'country_mismatch:{0}!={1}'.format(
                ''.join(sorted(item_isos)), ''.join(sorted(detail_isos)))
        return True, ''

    @classmethod
    def _item_country_isos(cls, item):
        if not isinstance(item, dict):
            return set()
        isos = set()
        for key in ('source_countries', 'filmix_countries', 'source_country',
                    'FilmixSourceCountry', 'FilmixSourceCountries', 'SourceCountry',
                    'countries', 'country'):
            value = item.get(key)
            if not value:
                continue
            if isinstance(value, (list, tuple, set)):
                for entry in value:
                    isos |= _country_text_to_isos(entry)
            else:
                isos |= _country_text_to_isos(value)
        return isos

    @classmethod
    def _details_country_isos(cls, details):
        if not isinstance(details, dict):
            return set()
        isos = set()
        origin = details.get('origin_country')
        if isinstance(origin, (list, tuple, set)):
            for entry in origin:
                if entry:
                    isos.add(str(entry).strip().upper())
        elif origin:
            isos |= _country_text_to_isos(origin)
        for entry in (details.get('production_countries') or []):
            if isinstance(entry, dict):
                iso = str(entry.get('iso_3166_1') or '').strip().upper()
                if iso:
                    isos.add(iso)
        return isos

    @classmethod
    def validate_season_episode_rows(cls, item, season, row_count):
        shape = cls._tv_shape_from_item(item)
        counts = shape.get('season_counts') or {}
        try:
            season_no = int(str(season))
        except Exception:
            season_no = 1
        expected = int(counts.get(season_no) or 0)
        try:
            actual = int(row_count or 0)
        except Exception:
            actual = 0
        if expected >= 8 and actual > 0 and actual < max(3, int(expected * 0.5)):
            return False, 'episode_rows_mismatch:s{0}:{1}>{2}'.format(season_no, expected, actual)
        return True, ''

    @classmethod
    def _set_premiered_fields(cls, result, premiered, tmdb_type):
        if not isinstance(result, dict) or not premiered:
            return
        result['resolved_premiered'] = premiered
        result['premiered'] = premiered
        result['date'] = premiered
        result[cls._date_key(tmdb_type)] = premiered
        year = cls._year_from_premiered(premiered)
        if year:
            result['resolved_year'] = year
            result['year'] = year

    # Kodi composites the skin into a 1920x1080 surface on these boxes
    # ("GUI format 1920x1080, Display 3840x2160" in kodi.log) and advancedsettings
    # caps cached textures at imageres/fanartres 1080. Requesting `original`
    # therefore downloaded up to 3840x2160 and discarded three quarters at the cap.
    #
    # w1920 is undocumented in TMDb's configuration payload but the CDN serves it,
    # returning exactly 1920x1080; w1440, w2160 and h1080 answer HTTP 400. w780 is
    # 780x1170, still above the 720x1080 a 2:3 poster is cached at. Measured:
    # 4K backdrop 2030 KB -> 463 KB, poster 1182 KB -> 300 KB.
    TMDB_IMAGE_BASE = 'https://image.tmdb.org/t/p/'
    TMDB_SIZE_LANDSCAPE = 'w1920'
    TMDB_SIZE_POSTER = 'w780'

    _TMDB_SIZE_RE = re.compile(r"(image\.tmdb\.org/t/p/)([^/]+)(/)", re.IGNORECASE)

    @classmethod
    def tmdb_size_for(cls, kind):
        return cls.TMDB_SIZE_POSTER if str(kind or '') == 'poster' else cls.TMDB_SIZE_LANDSCAPE

    @classmethod
    def normalize_tmdb_size(cls, value, kind='landscape'):
        """Rewrite an absolute TMDb URL to the size this GUI can display.

        Matches any incoming size, so `original` URLs already stored in cache4.db
        by earlier builds are corrected on publish and no cache invalidation is
        needed. Non-TMDb URLs are returned untouched.
        """
        if not value:
            return value
        try:
            text = str(value)
            if 'image.tmdb.org/t/p/' not in text.lower():
                return value
            return cls._TMDB_SIZE_RE.sub(
                lambda m: m.group(1) + cls.tmdb_size_for(kind) + m.group(3), text, count=1)
        except Exception:
            return value

    @classmethod
    def _tmdb_image_url(cls, value, kind='landscape'):
        if not value:
            return None
        value = str(value).strip()
        if not value:
            return None
        if value.startswith('http://') or value.startswith('https://'):
            return cls.normalize_tmdb_size(value, kind)
        if value.startswith('/'):
            return '{0}{1}{2}'.format(cls.TMDB_IMAGE_BASE, cls.tmdb_size_for(kind), value)
        return None

    @classmethod
    def _set_art_fields(cls, result, details):
        if not isinstance(result, dict) or not isinstance(details, dict):
            return
        # Только постер. Задник и ландшафт строились здесь и никуда не шли:
        # listitems.get_fanart() их не публикует, а решение «опознать заново»
        # на них больше не смотрит (navigation.py, need_resolve).
        poster = cls._tmdb_image_url(details.get('poster_path')
                                     or details.get('poster'), 'poster')
        if poster:
            result['resolved_poster'] = poster

    @classmethod
    def _extract_imdb(cls, data):
        if not data:
            return None
        found = [None]
        def walk(obj):
            if found[0]:
                return
            if isinstance(obj, dict):
                for key, val in obj.items():
                    key_l = str(key).lower()
                    if 'imdb' in key_l:
                        if isinstance(val, str):
                            m = re.search(r'\btt\d{6,10}\b', val)
                            if m:
                                found[0] = m.group(0)
                                return
                    walk(val)
            elif isinstance(obj, (list, tuple, set)):
                for val in obj:
                    walk(val)
            elif isinstance(obj, str):
                m = re.search(r'\btt\d{6,10}\b', obj)
                if m:
                    found[0] = m.group(0)
        walk(data)
        return found[0]

    @classmethod
    def _extract_tmdb(cls, data):
        if not data:
            return None
        found = [None]
        def walk(obj, key_name=''):
            if found[0]:
                return
            if isinstance(obj, dict):
                for key, val in obj.items():
                    key_l = str(key).lower()
                    if 'tmdb' in key_l:
                        if isinstance(val, int):
                            found[0] = str(val)
                            return
                        if isinstance(val, str) and val.isdigit():
                            found[0] = val
                            return
                    walk(val, key_l)
            elif isinstance(obj, (list, tuple, set)):
                for val in obj:
                    walk(val, key_name)
        walk(data)
        return found[0]

    @classmethod
    def _get_year_from_item(cls, data):
        return cls._best_item_year(data)

    @classmethod
    def _candidate_titles(cls, data):
        titles = []
        base_titles = []

        def add(value):
            value = cls._clean_text(value)
            if value and value not in titles:
                titles.append(value)

        def add_base(value):
            value = cls._clean_text(value)
            if value and value not in base_titles:
                base_titles.append(value)

        def latin_to_cyrillic(value):
            value = cls._clean_text(value)
            multi = [
                ('Dž', 'Џ'), ('DŽ', 'Џ'), ('dž', 'џ'), ('DZ', 'Џ'), ('dz', 'џ'),
                ('Dj', 'Ђ'), ('DJ', 'Ђ'), ('dj', 'ђ'), ('Đ', 'Ђ'), ('đ', 'ђ'),
                ('Lj', 'Љ'), ('LJ', 'Љ'), ('lj', 'љ'),
                ('Nj', 'Њ'), ('NJ', 'Њ'), ('nj', 'њ'),
            ]
            for src, dst in multi:
                value = value.replace(src, dst)
            table = {
                'A': 'А', 'a': 'а', 'B': 'Б', 'b': 'б', 'C': 'Ц', 'c': 'ц',
                'Č': 'Ч', 'č': 'ч', 'Ć': 'Ћ', 'ć': 'ћ', 'D': 'Д', 'd': 'д',
                'E': 'Е', 'e': 'е', 'F': 'Ф', 'f': 'ф', 'G': 'Г', 'g': 'г',
                'H': 'Х', 'h': 'х', 'I': 'И', 'i': 'и', 'J': 'Ј', 'j': 'ј',
                'K': 'К', 'k': 'к', 'L': 'Л', 'l': 'л', 'M': 'М', 'm': 'м',
                'N': 'Н', 'n': 'н', 'O': 'О', 'o': 'о', 'P': 'П', 'p': 'п',
                'R': 'Р', 'r': 'р', 'S': 'С', 's': 'с', 'Š': 'Ш', 'š': 'ш',
                'T': 'Т', 't': 'т', 'U': 'У', 'u': 'у', 'V': 'В', 'v': 'в',
                'Z': 'З', 'z': 'з', 'Ž': 'Ж', 'ž': 'ж'
            }
            return ''.join(table.get(ch, ch) for ch in value)

        def serbian_variants(value):
            value = cls._clean_text(value)
            variants = [value]
            replacements = [
                ('Dj', 'Đ'), ('DJ', 'Đ'), ('dj', 'đ'),
                ('Dz', 'Dž'), ('DZ', 'DŽ'), ('dz', 'dž'),
            ]
            for src, dst in replacements:
                if src in value:
                    variants.append(value.replace(src, dst))
            deaccent = value
            for src, dst in [('Đ', 'Dj'), ('đ', 'dj'), ('Dž', 'Dz'), ('dž', 'dz'), ('Č', 'C'), ('č', 'c'), ('Ć', 'C'), ('ć', 'c'), ('Š', 'S'), ('š', 's'), ('Ž', 'Z'), ('ž', 'z')]:
                deaccent = deaccent.replace(src, dst)
            if deaccent != value:
                variants.append(deaccent)
            for var in list(variants):
                try:
                    variants.append(latin_to_cyrillic(var))
                except Exception:
                    pass
            return variants

        if isinstance(data, dict):
            for key in ('title', 'original_title', 'name', 'original_name', 'alt_name'):
                value = cls._clean_text(data.get(key))
                if not value:
                    continue
                add_base(value)
                # Slug fallback: Filmix alt_name may be transliterated with dashes.
                # It is not accepted by itself unless TMDb scoring/year also matches.
                if key == 'alt_name' and ('-' in value or '_' in value):
                    add_base(value.replace('-', ' ').replace('_', ' '))
            # Exact Filmix titles always go first.  Add only a small number of
            # genuinely different Serbian transliteration fallbacks afterwards.
            for value in base_titles:
                add(value)
            for value in base_titles:
                for variant in serbian_variants(value):
                    if cls._normalize(variant) != cls._normalize(value):
                        add(variant)
                        break
        return titles

    @classmethod
    def _score_result(cls, result, queries, year=None, tmdb_type='movie'):
        if not result:
            return -999
        name_keys = ['title', 'original_title'] if tmdb_type == 'movie' else ['name', 'original_name']
        names = [cls._normalize(result.get(k)) for k in name_keys if result.get(k)]
        names = [n for n in names if n]
        score = 0
        for query in queries:
            nq = cls._normalize(query)
            if not nq:
                continue
            for name in names:
                if nq == name:
                    score = max(score, 120)
                elif nq in name or name in nq:
                    score = max(score, 90)
        date_key = cls._date_key(tmdb_type)
        result_year = None
        date_val = result.get(date_key) or ''
        if len(date_val) >= 4 and date_val[:4].isdigit():
            result_year = int(date_val[:4])
        if year and result_year:
            # A translated title match alone is not enough.  If Filmix carries a
            # year from its metadata or slug, a TMDb candidate from another year
            # is a false-positive candidate and must not win by exact title.
            #
            # For a series that reasoning does not hold: a search result carries
            # first_air_date, the premiere, while a Filmix post is one release of
            # the show and carries its own year - the Fox Life «Безумцы» is 2010,
            # Mad Men premiered in 2007. Killing the candidate here meant the
            # correct series could never be chosen no matter how exactly the
            # title matched, and the post stayed identityless. A close year is
            # still rewarded; a distant one is simply not rewarded, and
            # validate_resolved_match() then checks the post's year against the
            # show's real airing range, which is the fact this cannot see.
            if abs(int(year) - int(result_year)) > 1:
                if tmdb_type == 'movie':
                    return -999
            elif year == result_year:
                score += 30
            else:
                score += 10
        if result.get('popularity'):
            try:
                score += min(10, int(float(result.get('popularity')) // 10))
            except Exception:
                pass
        return score

    # Сколько живёт сохранённый ответ TMDb о фильме или сериале. Ответ
    # кешировался только в памяти одного запуска дополнения, то есть одного
    # экрана, - и при каждом открытии сериала сверка номера TMDb шла в сеть
    # дважды (_validate_tv_identity_for_episode_lookup и
    # _tmdb_episode_metadata_map), по запросу на каждый язык поиска. Замер на .30
    # 17.10.2026: «Король Талсы», 0.30 с из 1.41 с открытия. Карточка сериала на
    # TMDb за трое суток не меняется так, чтобы это было видно в списке серий.
    DETAILS_TTL = 3 * 24 * 3600
    _DETAILS_STORE = {'cache': None}

    @classmethod
    def _details_store(cls):
        store = cls._DETAILS_STORE.get('cache')
        if store is None:
            try:
                from .cache import FilmixCache
                store = FilmixCache(plugin.profile_dir)
            except Exception:
                store = False
            cls._DETAILS_STORE['cache'] = store
        return store or None

    def _details(self, tmdb_id, tmdb_type):
        if not (self.enabled and tmdb_id and tmdb_type in ('movie', 'tv')):
            return {}
        key = 'tmdb_details|{0}|{1}|{2}'.format(tmdb_type, tmdb_id, self.language)
        store = self._details_store()
        if store is not None:
            try:
                row = store.get_control_flag(key)
                if row and time.time() - int(row.get('updated_ts') or 0) < self.DETAILS_TTL:
                    data = json.loads(row.get('flag_value') or '{}')
                    if isinstance(data, dict) and data:
                        return data
            except Exception:
                pass
        result = self._details_live(tmdb_id, tmdb_type)
        if result and store is not None:
            try:
                store.set_control_flag(key, json.dumps(result, ensure_ascii=False))
            except Exception:
                pass
        return result

    def _details_live(self, tmdb_id, tmdb_type):
        endpoint = '/movie/{0}' if tmdb_type == 'movie' else '/tv/{0}'
        last = {}
        best_with_date = {}
        best_with_overview = {}
        for language in self._search_languages():
            try:
                append = 'external_ids,release_dates' if tmdb_type == 'movie' else 'external_ids'
                data = self._get(endpoint.format(tmdb_id), {'append_to_response': append, 'language': language})
            except Exception:
                continue
            if data:
                last = data
                if self._premiered_from_details(data, tmdb_type) and not best_with_date:
                    best_with_date = data
                if self._clean_text(data.get('overview')) and not best_with_overview:
                    best_with_overview = data
        if best_with_date:
            if best_with_overview and not self._clean_text(best_with_date.get('overview')):
                best_with_date['overview'] = best_with_overview.get('overview')
            return best_with_date
        return best_with_overview or last or {}

    def _movie_release_dates_endpoint(self, tmdb_id):
        if not (self.enabled and tmdb_id):
            return []
        try:
            data = self._get('/movie/{0}/release_dates'.format(tmdb_id), {})
        except Exception:
            return []
        return self._release_dates_from_movie_details({'release_dates': data})

    def _direct_date_without_append(self, tmdb_id, tmdb_type):
        if not (self.enabled and tmdb_id and tmdb_type in ('movie', 'tv')):
            return None
        endpoint = '/movie/{0}' if tmdb_type == 'movie' else '/tv/{0}'
        for language in ['ru-RU', 'en-US']:
            try:
                data = self._get(endpoint.format(tmdb_id), {'language': language})
            except Exception:
                continue
            premiered = self._premiered_from_details(data, tmdb_type)
            if premiered:
                return premiered
        return None

    def enrich_from_details(self, tmdb_id, tmdb_type, imdb_id=None, fallback_year=None, details=None):
        result = {}
        if details is None:
            details = self._details(tmdb_id, tmdb_type)
        if not details:
            fallback = self._date_from_year(fallback_year)
            if fallback:
                self._set_premiered_fields(result, fallback, tmdb_type)
                result['resolved_date_source'] = 'year_fallback_no_details'
            return result
        self._set_art_fields(result, details)
        premiered = self._premiered_from_details(details, tmdb_type)
        date_source = 'tmdb_detail' if premiered else ''
        if not premiered and tmdb_type == 'movie':
            dates = self._movie_release_dates_endpoint(tmdb_id)
            if dates:
                premiered = dates[0]
                date_source = 'tmdb_release_dates_endpoint'
        if not premiered:
            premiered = self._direct_date_without_append(tmdb_id, tmdb_type)
            if premiered:
                date_source = 'tmdb_direct_no_append'
        if not premiered:
            fallback = self._date_from_year(fallback_year)
            if fallback:
                premiered = fallback
                date_source = 'year_fallback'
        if premiered:
            self._set_premiered_fields(result, premiered, tmdb_type)
            if date_source:
                result['resolved_date_source'] = date_source
        overview = self._clean_text(details.get('overview'))
        if overview:
            result['resolved_overview'] = overview
        resolved_imdb = imdb_id or details.get('imdb_id')
        ext_ids = details.get('external_ids') or {}
        if not resolved_imdb:
            resolved_imdb = ext_ids.get('imdb_id')
        if resolved_imdb:
            result['resolved_imdb_id'] = resolved_imdb
        if tmdb_type == 'tv':
            # Stored so the cached-identity re-validation, which runs with
            # details=None, can still see the airing range the year gate needs.
            last_air = details.get('last_air_date')
            if last_air:
                result['resolved_last_air'] = last_air
        return result

    def find_by_imdb(self, imdb_id, preferred_type=None):
        if not (self.enabled and imdb_id):
            return None
        data = self._get('/find/{0}'.format(imdb_id), {'external_source': 'imdb_id'})
        movie_results = data.get('movie_results') or []
        tv_results = data.get('tv_results') or []

        # IMDb is authoritative, but TMDb /find can return both
        # movie_results and tv_results for edge cases. Respect Filmix forced type:
        # serial widgets prefer tv_results; movie widgets prefer movie_results.
        if preferred_type == 'tv':
            ordered = [('tv', tv_results), ('movie', movie_results)]
        elif preferred_type == 'movie':
            ordered = [('movie', movie_results), ('tv', tv_results)]
        else:
            ordered = [('movie', movie_results), ('tv', tv_results)]

        for result_type, results in ordered:
            if not results:
                continue
            result = results[0]
            out = {
                'resolved_tmdb_id': str(result.get('id')),
                'resolved_tmdb_type': result_type,
                'resolved_imdb_id': imdb_id
            }
            self._set_art_fields(out, result)
            premiered = self._premiered_from_result(result, result_type)
            if premiered:
                self._set_premiered_fields(out, premiered, result_type)
            return out
        return None

    def _search_languages(self):
        langs = []
        def add(value):
            value = self._clean_text(value)
            if value and value not in langs:
                langs.append(value)
        add(self.language)
        # Restricted TMDb fallback: only Russian.
        for lang in ('ru-RU',):
            add(lang)
        return langs

    def search_by_title(self, queries, year=None, tmdb_type='movie'):
        if not self.enabled:
            return None

        def finish(best, result_type):
            if not best:
                return None
            out = {
                'resolved_tmdb_id': str(best.get('id')),
                'resolved_tmdb_type': result_type
            }
            self._set_art_fields(out, best)
            premiered = self._premiered_from_result(best, result_type)
            if premiered:
                self._set_premiered_fields(out, premiered, result_type)
            return out

        def run_search(endpoint, params_base, result_type, query, score_type, min_score):
            best = None
            best_score = -999
            for language in self._search_languages():
                params = dict(params_base)
                params['query'] = query
                params['include_adult'] = 'false'
                params['language'] = language
                try:
                    data = self._get(endpoint, params)
                except Exception:
                    continue
                for result in (data.get('results') or [])[:15]:
                    if endpoint.endswith('/multi'):
                        media_type = result.get('media_type')
                        if media_type == 'movie':
                            score_type = 'movie'
                        elif media_type == 'tv':
                            score_type = 'tv'
                        else:
                            continue
                    score = self._score_result(result, [query], year=year, tmdb_type=score_type)
                    if score > best_score:
                        best_score = score
                        best = result
                        result_type = score_type
                if best_score >= 120:
                    break
            if best and best_score >= min_score:
                return best, result_type, best_score
            return None, result_type, best_score

        endpoint = '/search/movie' if tmdb_type == 'movie' else '/search/tv'
        year_param = 'year' if tmdb_type == 'movie' else 'first_air_date_year'
        seen = set()
        selected_queries = []
        for query in queries or []:
            query = self._clean_text(query)
            normalized = self._normalize(query)
            if not query or not normalized or normalized in seen:
                continue
            seen.add(normalized)
            selected_queries.append(query)
            if len(selected_queries) >= 4:
                break
        seen = set()
        best = None
        best_type = tmdb_type
        best_score = -999

        # Preserve strict/relaxed/multi fallbacks, but cap them to a small,
        # deterministic request budget instead of candidates × 3 × languages.
        passes = []
        params = {}
        if year and tmdb_type == 'movie':
            # first_air_date_year would filter a series search down to shows that
            # PREMIERED in the post's year, which for a dub or a later season is
            # the wrong year outright - TMDb then never returns the correct show
            # at all. Movies keep the filter: one release, one year.
            params[year_param] = year
        passes.append((endpoint, params, tmdb_type, 90, selected_queries))
        passes.append((endpoint, {}, tmdb_type, 105 if year else 90, selected_queries[:2]))
        passes.append(('/search/multi', {}, tmdb_type, 110 if year else 95, selected_queries[:1]))

        for endpoint_i, params_i, result_type_i, min_score, pass_queries in passes:
            for query in pass_queries:
                found, found_type, score = run_search(endpoint_i, params_i, result_type_i, query, result_type_i, min_score)
                if score > best_score:
                    best_score = score
                    best = found
                    best_type = found_type
                if found:
                    return finish(found, found_type)
        return finish(best, best_type) if best and best_score >= 120 else None

    def resolve(self, item, forced_type=None):
        resolved = {}
        if not isinstance(item, dict):
            return resolved

        previous_deadline = self._resolve_deadline
        previous_count = self._resolve_request_count
        self._resolve_deadline = time.monotonic() + float(self.resolve_deadline_seconds)
        self._resolve_request_count = 0

        try:
            tmdb_id = self._extract_tmdb(item)
            imdb_id = self._extract_imdb(item)
            if tmdb_id and str(tmdb_id) in self._blocked_tmdb_ids_for_item(item):
                tmdb_id = None
            if imdb_id and str(imdb_id) in self._blocked_imdb_ids_for_item(item):
                imdb_id = None
            if tmdb_id:
                resolved['resolved_tmdb_id'] = str(tmdb_id)
            if imdb_id:
                resolved['resolved_imdb_id'] = imdb_id
            tmdb_type = forced_type or item.get('resolved_tmdb_type')
            if tmdb_type:
                resolved['resolved_tmdb_type'] = tmdb_type

            if not resolved.get('resolved_tmdb_id') and imdb_id:
                try:
                    found = self.find_by_imdb(imdb_id, preferred_type=forced_type or resolved.get('resolved_tmdb_type'))
                except Exception:
                    found = None
                if found and not self._resolved_identity_blocked(item, found):
                    resolved.update({k: v for k, v in found.items() if v})

            title_resolve_blocked = self._title_resolve_blocked(item)
            if not resolved.get('resolved_tmdb_id') and self.enabled and not title_resolve_blocked:
                tmdb_type = forced_type or resolved.get('resolved_tmdb_type') or 'movie'
                titles = self._candidate_titles(item)
                year = self._get_year_from_item(item)
                try:
                    found = self.search_by_title(titles, year=year, tmdb_type=tmdb_type)
                except Exception:
                    found = None
                if found and not self._resolved_identity_blocked(item, found):
                    resolved.update({k: v for k, v in found.items() if v})
            elif not resolved.get('resolved_tmdb_id') and title_resolve_blocked:
                resolved['_tmdb_title_resolve_blocked'] = '1' 

            tmdb_id = resolved.get('resolved_tmdb_id')
            tmdb_type = resolved.get('resolved_tmdb_type') or forced_type
            if tmdb_id and tmdb_type and self.enabled:
                fallback_year = self._fallback_year_from_item(item) or resolved.get('resolved_year') or resolved.get('year')
                raw_details = None
                try:
                    raw_details = self._details(tmdb_id, tmdb_type)
                except Exception:
                    raw_details = None
                valid, reject_reason = self.validate_resolved_match(item, resolved, details=raw_details, tmdb_type=tmdb_type)
                if not valid:
                    return {
                        '_tmdb_miss_reason': reject_reason or 'identity_validation_failed',
                        '_tmdb_rejected_tmdb_id': str(tmdb_id),
                        '_tmdb_rejected_type': str(tmdb_type or '')
                    }
                try:
                    details = self.enrich_from_details(tmdb_id, tmdb_type,
                                                       imdb_id=resolved.get('resolved_imdb_id'),
                                                       fallback_year=fallback_year,
                                                       details=raw_details)
                except Exception:
                    details = None
                if details:
                    resolved.update({k: v for k, v in details.items() if v})
            return resolved
        finally:
            self._resolve_deadline = previous_deadline
            self._resolve_request_count = previous_count
