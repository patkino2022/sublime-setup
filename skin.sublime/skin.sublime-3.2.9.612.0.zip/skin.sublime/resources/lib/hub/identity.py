# -*- coding: utf-8 -*-
"""How one watchable thing gets a stable key.

The key has to survive the same title arriving from different places: the
player (a bare title plus season/episode), a catalogue row, another add-on's
call, and an import from an older database. It therefore cannot contain a
plugin path, a post id or an add-on name - all three differ per source for
the same film.

What it does contain: normalized title, year when known, and the
season/episode coordinate for an episode. A show and its episodes share the
show key via `parent_key`, so "this show has been watched" and "episode 3 has
been watched" stay separate facts.
"""
# Ported from plugin.video.watchhub. The algorithm is unchanged; the
# sources it reads are not: settings come from config.py, the built
# lists and the feedback from store.py, and the watched history from
# history.py - which reads and writes Kodi's own database.
from __future__ import absolute_import, unicode_literals

import re

_QUALITY_TAG = re.compile(r'\s*\[[^\]]*\]\s*$')
# Служебная разметка Kodi в ярлыках дополнений: YouTube пишет папки как
# «[B]Плейлисты[/B]». 06.11.2026 владелец прислал снимок окна канала: заголовок
# «[B]Плейлисты[/B]» знаками, а в чипе качества - «/B»: закрывающий тег
# принимался за скобку релиза («[WEB-DLRip 1080]»). Снимается до разбора.
_KODI_FORMATTING = re.compile(
    r'\[/?(?:B|I|LIGHT|UPPERCASE|LOWERCASE|CAPITALIZE|CR|COLOR(?:\s+[^\]]*)?|TABS(?:\s+[^\]]*)?)\]',
    re.I)
_NON_WORD = re.compile(r'[^\w\s]', re.U)
_SPACES = re.compile(r'\s+', re.U)


def strip_formatting(text):
    """Текст без разметки Kodi ([B], [I], [COLOR ...] и т. п.)."""
    return _KODI_FORMATTING.sub('', str(text or ''))


def clean_label(label):
    """Strip the quality suffix a catalogue search adds ("[WEB-DLRip 1080]").

    Filmix's own catalogue rows never show it, only /search does, so leaving
    it in would key the same film differently depending on where it was
    watched from.
    """
    return _QUALITY_TAG.sub('', strip_formatting(label)).strip()


# Что бывает в этой скобке у filmix и RuTor: качество исходника и высота
# картинки. Замер по строкам владельца 09.09.2026: «[WEB-DLRip 1080]»,
# «[WEB-DLRip 2160]», «[DVDRip 480]», «[TS 1080]», «[1080+]», «[HDTVRip 720]».
# «p» после числа - часть разрешения (HDRezka: «720p», «1080p Ultra»), иначе оставалась в качестве
_RELEASE_RESOLUTION = re.compile(r'(?<!\d)(2160|1440|1080|720|576|480|360)(?!\d)p?')
_RELEASE_NOISE = re.compile(r'[\[\]()+]')


def release_info(label):
    """Качество релиза из ярлыка строки: («WEB-DLRip», «1080»).

    Эту скобку мы срезаем с названия (clean_label), чтобы она не портила
    заголовок и не мешала опознанию. Но сама она - сведения, а не мусор:
    09.09.2026 владелец потребовал показывать её в инфостроке отдельными
    значками, «типа иконок рейтинга». Разбор живёт здесь же, где и срезание, -
    одно место на оба применения.

    Возвращает (качество, разрешение); чего нет - пустая строка.
    """
    text = strip_formatting(label)
    found = _QUALITY_TAG.search(text)
    if not found:
        return '', ''
    return release_parts(found.group(0))


def release_parts(text):
    """То же самое, но из готовой строки вида «WEB-DLRip 1080».

    У провайдера это отдельные поля (`rip` и `quality`), и разбирать название
    ради них не нужно - но разбор должен остаться ОДИН, поэтому оба входа
    сходятся здесь.
    """
    inside = _RELEASE_NOISE.sub(' ', str(text or '')).strip()
    if not inside:
        return '', ''
    resolution = ''
    hit = _RELEASE_RESOLUTION.search(inside)
    if hit:
        resolution = hit.group(1)
        inside = (inside[:hit.start()] + ' ' + inside[hit.end():])
    quality = _SPACES.sub(' ', inside).strip(' ,;-')
    return quality, resolution


# Экранки - запись с экрана кинотеатра или до релиза. 20.10.2026 владелец:
# «Никаких экранок». Тот же разбор, что у провайдера (Navigation._is_screener):
# первое слово вида релиза без «rip» в конце и «HD» в начале.
_SCREENER_KINDS = frozenset(['cam', 'ts', 'tc', 'telesync', 'telecine', 'scr', 'screener',
                             'dvdscr', 'bdscr', 'webscr', 'dvdscreener'])


def is_screener(quality):
    """True, если вид релиза («TS», «CAMRip», «HDTS 720», «DVDScr») - экранка."""
    words = str(quality or '').split()
    if not words:
        return False
    kind = re.sub(r'[^a-z0-9]', '', words[0].lower())
    if kind.endswith('rip'):
        kind = kind[:-3]
    if kind.startswith('hd'):
        kind = kind[2:]
    return kind in _SCREENER_KINDS


def normalize_title(text):
    text = clean_label(text).lower()
    text = _NON_WORD.sub(' ', text)
    return _SPACES.sub(' ', text).strip()


def _year_part(year):
    year = str(year or '').strip()[:4]
    return year if year.isdigit() else ''


def show_key(title, year=''):
    """Key for a series or a film as a whole."""
    norm = normalize_title(title)
    if not norm:
        return ''
    return 'v1|%s|%s' % (norm, _year_part(year))


def episode_key(show_title, season, episode, year='', allow_zero=False):
    """Key for one episode. The show's year is deliberately included so two
    same-titled shows from different eras keep separate episode histories.
    allow_zero: the caller knows it is an episode (key_for) - Filmix has
    seasons numbered from 0."""
    parent = show_key(show_title, year)
    if not parent:
        return ''
    try:
        season = int(season or 0)
        episode = int(episode or 0)
    except (TypeError, ValueError):
        return ''
    if episode < 0 or (episode == 0 and not allow_zero):
        return ''
    return '%s|s%d|e%d' % (parent, season, episode)


def key_for(title='', year='', season=0, episode=None, tvshowtitle=''):
    """The one entry point: returns (item_key, parent_key, mediatype).

    An episode is recognised by having a show title plus an episode number -
    never by a DBType, because Kodi reports no DBType at all for plugin
    playback, which is what every add-on on these boxes uses.

    "No episode" is None, not 0. Filmix numbers some seasons from zero
    (`/play/?s=3&e=0`): 21.10.2026 on .20 «Тед Лассо» S3E0, watched, became a
    mark on the whole show - the hub lane showed the show as watched while
    Filmix (and the show itself) had one episode left, and the lane counted 43
    watched episodes instead of 44.
    """
    show_title = str(tvshowtitle or '').strip()
    try:
        episode_no = None if episode in (None, '') else int(episode)
    except (TypeError, ValueError):
        episode_no = None
    if show_title and episode_no is not None and episode_no >= 0:
        parent = show_key(show_title, year)
        return episode_key(show_title, season, episode_no, year, allow_zero=True), parent, 'episode'
    if show_title:
        key = show_key(show_title, year)
        return key, '', 'tvshow'
    key = show_key(title, year)
    return key, '', 'movie'
