#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys, os, time, json, ast
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
import rutor
import tmdbhelper_ids
import elementum_play
import skin_meta
import release_tech
import ssl

if sys.version_info.major > 2:  # Python 3 or later
	from urllib.parse import quote
	from urllib.parse import unquote
	import urllib.request as urllib2
else:  # Python 2
	import urllib, urlparse
	from urllib import quote
	from urllib import unquote
	import urllib2

handle = int(sys.argv[1])
PLUGIN_NAME   = 'RuTor'

addon = xbmcaddon.Addon(id='plugin.video.RuTor')
__settings__ = xbmcaddon.Addon(id='plugin.video.RuTor')

icon = os.path.join(addon.getAddonInfo('path'), 'icon.png')
thumb = os.path.join( addon.getAddonInfo('path'), "icon.png" )
fanart = os.path.join( addon.getAddonInfo('path'), "fanart.jpg" )
LstDir = os.path.join( addon.getAddonInfo('path'), "playlists" )

siteUrl = __settings__.getSetting('Url')
if siteUrl == "": siteUrl = 'rutor.is'
httpSiteUrl = 'http://' + siteUrl
if __settings__.getSetting('Protokol')=='1': httpSiteUrl = 'https://' + siteUrl

xbmcplugin.setContent(int(sys.argv[1]), 'movies')

# Настройки строк - один раз на вызов, а не по нескольку getSetting на каждую
# строку списка (21.11.2026).
S_ANTIBLOCK2  = __settings__.getSetting("antiblock2") == 'true'
S_TITLE_MODE  = __settings__.getSetting("Title Mode")
S_HIDE_SCR    = __settings__.getSetting("Hide Scr") == 'true'
S_FILTR       = [x.strip() for x in __settings__.getSetting("Filtr").split(',')] if __settings__.getSetting("EnabledFiltr") == 'true' else []
S_SORT        = {'0': '2', '1': '0', '2': '4'}.get(__settings__.getSetting("sort"))

# - ====================================== antizapret ====================================================
if __settings__.getSetting("antiblock") == "1":
	prx='http://proxy-nossl.antizapret.prostovpn.org:29976'
	proxy_support = urllib2.ProxyHandler({"http" : prx, "https" : prx})
	opener = urllib2.build_opener(proxy_support)
	urllib2.install_opener(opener)

if __settings__.getSetting("antiblock") == "2":
	prx=__settings__.getSetting('proxy')
	if 'http' not in prx: prx='http://'+prx
	proxy_support = urllib2.ProxyHandler({"http" : prx, "https": prx})
	opener = urllib2.build_opener(proxy_support)
	urllib2.install_opener(opener)

if __settings__.getSetting("antiblock") == "3":
	# Разблокировка через прокси ТАМа осталась как возможность, но плагин
	# больше не требует ТАМ: если его нет, берётся порт по умолчанию.
	try:
		tam_settings = xbmcaddon.Addon(id='plugin.video.tam')
		tam_port = int(tam_settings.getSetting("serv_port"))
	except: tam_port = 8095
	prx='http://127.0.0.1:'+str(tam_port)
	proxy_support = urllib2.ProxyHandler({"http" : prx, "https": prx})
	opener = urllib2.build_opener(proxy_support)
	urllib2.install_opener(opener)

if __settings__.getSetting("antiblock") == "4":
	prx='http://193.124.130.96:8095'
	proxy_support = urllib2.ProxyHandler({"http" : prx, "https": prx})
	opener = urllib2.build_opener(proxy_support)
	urllib2.install_opener(opener)

def img_to_prx(url):
	if 'yandex.net' in url: url = url.replace('st.kp.yandex.net', 'st-kp-yandex-net.translate.goog')+'?_x_tr_sl=auto&_x_tr_tl=ru&_x_tr_hl=ru&_x_tr_pto=wapp'
	#https://st.kp.yandex.net/images/film_iphone/iphone360_6616329.jpg
	#https://st-kp-yandex-net.translate.goog/images/film_iphone/iphone360_6616329.jpg?_x_tr_sl=auto&_x_tr_tl=ru&_x_tr_hl=ru&_x_tr_pto=wapp
	return url

def mfindal(http, ss, es):
	L=[]
	while http.find(es)>0:
		s=http.find(ss)
		e=http.find(es,s)
		i=http[s:e]
		L.append(i)
		http=http[e+2:]
	return L

def mfind(t,s,e):
	r=t[t.find(s)+len(s):]
	r2=r[:r.find(e)]
	return r2

def ru(x):return unicode(x,'utf8', 'ignore')
def xt(x):
	try: r = xbmc.translatePath(x)
	except: r = xbmcvfs.translatePath(x)
	return r

def mid(s, n):
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.center(n)
	try:s=s.encode('utf-8')
	except: pass
	return s

def mids(s, n):
	l="                                              "
	s=l[:n-len(s)]+s+l[:n-len(s)]
	return s

def lower(s):
	if sys.version_info.major > 2: return s.lower()
	try:s=s.decode('utf-8')
	except: pass
	try:s=s.decode('windows-1251')
	except: pass
	s=s.lower().encode('utf-8')
	return s

def loads(text, kind=dict):
	# Разбор параметра адреса и истории поиска: JSON, а для старых ссылок из
	# Избранного (repr) - ast.literal_eval. eval здесь больше нет: адрес
	# мог выполнить любой код (21.11.2026).
	try: value = json.loads(text)
	except Exception:
		try: value = ast.literal_eval(text)
		except Exception: value = kind()
	return value if isinstance(value, kind) else kind()

def construct_request(params):
	return '%s?%s' % (sys.argv[0], urllib.urlencode(params))

def showMessage(heading, message, times = 3000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, icon))

def GET(target, referer='', post=None):
	try:
		req = urllib2.Request(url = target, data = post)
		req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36 OPR/52.0.2871.64')
		resp = urllib2.urlopen(req, timeout=12)  # без таймаута страница могла висеть
		http = resp.read()
		resp.close()
		return http
	except Exception as e:
		showMessage('HTTP ERROR', e, 5000)
		return ''

def GET2(url, Referer = '', XML = False):
	try:
		opener = urllib2.build_opener() 
		urllib2.install_opener(opener)
		req = urllib2.Request(url)
		req.add_header('User-Agent', 'Opera/10.60 (X11; openSUSE 11.3/Linux i686; U; ru) Presto/2.6.30 Version/10.60')
		req.add_header('Accept', '*/*')
		req.add_header('Accept-Language', 'ru,en;q=0.9')
		req.add_header('Referer', Referer)
		if XML: req.add_header('X-Requested-With', 'XMLHttpRequest')
		response = urllib2.urlopen(req, timeout=12)
		link=response.read()
		response.close()
		return link
	except:
		#print 'ERR: недоступно'
		return ''

def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def showMessage(heading, message, times = 50000):
	xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s, "%s")'%(heading, message, times, thumb))

def inputbox():
	skbd = xbmc.Keyboard()
	skbd.setHeading('Поиск:')
	skbd.doModal()
	if skbd.isConfirmed():
		SearchStr = skbd.getText()
		return SearchStr
	else:
		return ""


_PENDING = []
_SKIN_ROWS = {}


def _skin_row_store():
	"""Общее хранилище строк скина (skin.sublime/resources/lib/hub/row_store.py), как у Filmix,
	HDRezka и Elementum: готовые Sublime.* строки (фон, логотип, оценки, жанр). Перечитывается
	после обновления скина (22.11.2026)."""
	try:
		path = xbmcvfs.translatePath('special://home/addons/skin.sublime/resources/lib/hub/row_store.py')
		stamp = os.path.getmtime(path) if os.path.exists(path) else 0
	except Exception:
		path, stamp = '', 0
	if 'mod' in _SKIN_ROWS and _SKIN_ROWS.get('stamp') == stamp:
		return _SKIN_ROWS['mod']
	mod = None
	if stamp:
		try:
			import importlib.util
			spec = importlib.util.spec_from_file_location('sublime_row_store', path)
			mod = importlib.util.module_from_spec(spec)
			spec.loader.exec_module(mod)
		except Exception as exc:
			xbmc.log('[plugin.video.RuTor] row_store: %s' % exc, xbmc.LOGWARNING)
			mod = None
	_SKIN_ROWS['mod'] = mod
	_SKIN_ROWS['stamp'] = stamp
	return mod


def _skin_row(listitem, id, drawable):
	"""Строка фильма для хранилища скина. Ключ - фильм (mode=Torrents&id=...), общий для строки
	фильма и строк его релизов: адрес строки несёт весь info и меняется, а собирать нужно фильм."""
	if not id or id == '0':
		return None
	try:
		tag = listitem.getVideoInfoTag()
		media = tag.getMediaType() or 'movie'
		title = tag.getTitle() or ''
		ids = {}
		for name in ('kinopoisk', 'tmdb', 'imdb'):
			value = tag.getUniqueID(name)
			if value:
				ids[name] = value
		row = {'file': 'plugin://plugin.video.RuTor/?mode=Torrents&id=' + str(id),
		       'label': title, 'title': title, 'originaltitle': tag.getOriginalTitle() or '',
		       'year': tag.getYear() or 0, 'type': 'tvshow' if media == 'tvshow' else 'movie',
		       'plot': tag.getPlot() or '', 'uniqueid': ids,
		       'art': {k: v for k, v in (drawable or {}).items() if k in ('thumb', 'poster', 'fanart') and v},
		       'release_quality': listitem.getProperty('sublime_release_quality'),
		       'release_resolution': listitem.getProperty('sublime_release_resolution'),
		       'filetype': 'directory'}
	except Exception:
		return None
	return row if title else None


def _flush():
	"""Строки страницы - в список одним проходом, перед этим готовые свойства из хранилища скина
	одним вызовом (row_store.attach); недостающие соберёт служба скина."""
	pairs = [(li, row) for _u, li, _f, _t, row in _PENDING if row]
	store = _skin_row_store() if pairs else None
	if store is not None and hasattr(store, 'attach'):
		try:
			store.attach(pairs)
		except Exception as exc:
			xbmc.log('[plugin.video.RuTor] row_store.attach: %s' % exc, xbmc.LOGWARNING)
	for purl, li, folder, total, _row in _PENDING:
		xbmcplugin.addDirectoryItem(handle, purl, li, folder, total)
	del _PENDING[:]


def _end(**kwargs):
	_flush()
	xbmcplugin.endOfDirectory(handle, **kwargs)


def AddItem(Title = "", mode = "", id='0', url='', inf={}, total=100):
			if id !='0':
				if mode == "Open": 
					info=inf
				else:
					try:    info=get_info(inf, False)
					except: info={}
				try:    cover = info["cover"]
				except: cover = icon
				try:    fanart = info["fanart"]
				except: fanart = cover
				try:    type=info["type"]
				except: type=''
			else:
				cover = icon
				fanart = ''
				info={'id':id}
				type=''
			if S_ANTIBLOCK2 and 'http' in cover: cover = img_to_prx(cover)
			#print cover
			#print (info)
			# offscreen=True: строка для списка дополнения - без него каждый setProperty
			# ждёт блокировку интерфейса Kodi (замер .30 17.10.2026: 828 вызовов до 2.75 с).
			# Старые аргументы iconImage/thumbnailImage Kodi 19+ не принимает.
			listitem = xbmcgui.ListItem(Title, offscreen=True)
			# UI-only copy: Kodi/skin receive the exact RuTor visible row.
			# The original info dict stays unchanged for TAM/native RuTor routes.
			try: ui_info = tmdbhelper_ids.make_ui_info(info, Title, inf)
			except: ui_info = info
			try: tmdbhelper_ids.apply_to_listitem(listitem, info)
			except: pass
			try: tmdbhelper_ids.apply_display_properties(listitem, Title, inf)
			except: pass
			try: listitem.setInfo(type = "Video", infoLabels = tmdbhelper_ids.clean_info_labels(ui_info))
			except:
				try: listitem.setInfo(type = "Video", infoLabels = ui_info)
				except: pass
			# Keep the visible label exactly as RuTor/plugin produced it.
			# Some Kodi skins prefer infoLabels['title'] after setInfo().
			try: tmdbhelper_ids.restore_list_label(listitem, Title)
			except: pass
			# Метки для нашего скина: чистое название, год, страна, жанры,
			# опознание по номерам, качество релиза чипом и арт без адресов
			# молчащих складов - см. skin_meta.py. Ставится ПОСЛЕ setInfo выше,
			# поэтому наши значения последние и они же доедут до скина.
			release = info if mode == "Open" else None
			try: drawable = skin_meta.apply(listitem, info, source=inf, release=release)
			except Exception: drawable = {}
			if not drawable:
				# Своих картинок нет вовсе - Kodi лучше нарисует название, чем
				# будет ждать мёртвый адрес: загрузчик текстур у него один.
				try: listitem.setArt({})
				except: pass
			elif drawable.get('fanart'):
				try:listitem.setProperty('fanart_image', drawable['fanart'])
				except: pass
			purl = sys.argv[0] + '?mode='+mode+'&id='+id+'&info='+quote(json.dumps(info, ensure_ascii=False, default=str))
			if url !="": purl = purl +'&url='+quote(url)
			
			
			playable = False
			if mode=="Open":
				# РЕЛИЗ ИГРАЕТСЯ СРАЗУ И ДВИЖКОМ ELEMENTUM.
				#
				# Было: строка вела в plugin://plugin.video.tam/?mode=open, ТАМ
				# сам строил список файлов и уже он звал движок
				# (main.play_elementum: plugin://plugin.video.elementum/play?uri=).
				# Владелец 11.09.2026: «отвяжи его от TAM, пусть воспроизводит
				# движком Elementum сходу». Теперь адрес движка строится здесь,
				# а строка помечена играбельной - Kodi запускает её нажатием, без
				# промежуточного каталога.
				purl = elementum_play.play_url(url, info)
				playable = True
				listitem.setProperty('IsPlayable', 'true')
				listitem.addContextMenuItems(elementum_play.context_items(url, info))
			if mode=="Torrents":
				listitem.addContextMenuItems([('[B]Обновить описание[/B]', 'Container.Update("plugin://plugin.video.RuTor/?mode=UpdateInfo&id='+id+'&url='+quote(url)+'")'),])
			# Играбельная строка - НЕ каталог: иначе Kodi откроет её как папку.
			_PENDING.append((purl, listitem, not playable, total,
			                 _skin_row(listitem, id, drawable) if mode in ('Torrents', 'Open') else None))

def Root():
	s = S_SORT

	AddItem("[B][COLOR FF00FF00][ ПОИСК ][/COLOR][/B]", "Search")
	if __settings__.getSetting("HistoryON") == 'true': AddItem("[B][COLOR FF00FF00][ ИСТОРИЯ ][/COLOR][/B]", "History")
	AddItem("Иностранные фильмы", 	"List", '0', httpSiteUrl+'/browse/0/1/0/'+s)
	AddItem("Русские фильмы", 		"List", '0', httpSiteUrl+'/browse/0/5/0/'+s)
	AddItem("Иностранные сериалы",	"List", '0', httpSiteUrl+'/browse/0/4/0/'+s)
	AddItem("Русские сериалы", 		"List", '0', httpSiteUrl+'/browse/0/16/0/'+s)
	AddItem("Мультфильмы", 			"List", '0', httpSiteUrl+'/browse/0/7/0/'+s)
	AddItem("Аниме", 				"List", '0', httpSiteUrl+'/browse/0/10/0/'+s)
	AddItem("Научно-Популярное", 	"List", '0', httpSiteUrl+'/browse/0/12/0/'+s)
	AddItem("Телепередачи", 		"List", '0', httpSiteUrl+'/browse/0/6/0/'+s)
	AddItem("Спорт", 				"List", '0', httpSiteUrl+'/browse/0/13/0/'+s)
	AddItem("Юмор", 				"List", '0', httpSiteUrl+'/browse/0/15/0/'+s)
	#AddItem("[COLOR 44999999]Donate: http://paypal.me/tdw1980[/COLOR]", "Donate")
	
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	_end()

def List(url, pb=True):
	if pb:
		if __settings__.getSetting("Progress") == 'false': pb=False
	
	if pb:
		pDialog = xbmcgui.DialogProgressBG()
		try: pDialog.create('Загрузка:', '')
		except: pass
	try:
		L=rutor.get_list(url)
		# Сведения о фильмах - заранее и параллельно, как в Search (21.11.2026).
		_prefetch_infos(L)
		Lid=[]
		dubl=0
		for i in L:
			if pb:
				try:pDialog.update(int(len(Lid)+dubl/len(L)*100), 'Загрузка:', i['title'])
				except: pass
			if '/browse/0/4/0/' in url or '/browse/0/16/0/' in url: i['type']='show'
			Title=get_title(i)#i['fulltitle']#i['title']#+' ('+i['year']+')'
			db_id = rutor.get_db_id(i)
			if db_id not in Lid and filtr(i['fulltitle']):
				#print (Title+':'+db_id)
				Lid.append(db_id)
				AddItem(Title, 'Torrents', db_id, i['id'], i, len(L)-dubl)
			else:
				dubl+=1
		next=get_next_url(url)
		AddItem('Далее >', 'List', '0', next)
	except: pass
	try:pDialog.close()
	except: pass
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	_end()

def Check(n=0):
	try: n=int(__settings__.getSetting("ch_n"))
	except: n=0
	if n>9: n=0
	s = S_SORT
	CL=['1','4','5','6','7','10','12','13','15','16']
	c=CL[n]
	url=httpSiteUrl+'/browse/0/'+c+'/0/'+s
	__settings__.setSetting("ch_n", str(n+1))
	try:
		L=rutor.get_list(url)
		Lid=[]
		tmdb_done=0
		tmdb_start=time.time()
		for i in L:
			if '/browse/0/4/0/' in url or '/browse/0/16/0/' in url: i['type']='show'
			db_id = rutor.get_db_id(i)
			if db_id not in Lid and filtr(i['fulltitle']):
				Lid.append(db_id)
				# AM8 4GB guard: keep native RuTor prewarm/cache, but do not run
				# heavy TMDbHelper parsing in the background by default.
				# TMDb background is available only via explicit slow mode in settings
				# and is capped by item/time budget with pauses.
				resolve_tmdb = False
				try: resolve_tmdb = tmdbhelper_ids.background_can_resolve(tmdb_done, tmdb_start)
				except: resolve_tmdb = False
				try:    info=get_info(i, resolve_tmdb)
				except: info={}
				if resolve_tmdb:
					tmdb_done += 1
					try: tmdbhelper_ids.background_pause()
					except: pass
	except: pass

def Search(t=''):
	if t=='': t=inputbox()
	if t!='':
		if __settings__.getSetting("HistoryON") == 'true': add_history(t)
		Lid=[]
		L=rutor.serch(t)
		_prefetch_infos(L)
		for i in L:
			Title=i['title']#+' ('+i['year']+')'
			db_id = rutor.get_db_id(i)
			if db_id not in Lid and filtr(i['fulltitle']):
				Lid.append(db_id)
				AddItem(Title, 'Torrents', db_id, i['id'], i, len(L))
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	_end()

def Torrents(info):
	try: info = get_info(info, True)
	except: pass
	L=rutor.torrents(info)
	# Размер кадра каждой раздачи - со её страницы. В названии высоты часто нет
	# вовсе («BDRip-AVC от ExKinoRay»), а на странице написано точно: «Видео:
	# 656x352». Владелец 11.09.2026: «как понять какое разрешение у BDRip?».
	# Запросы идут в шесть потоков и кэшируются навсегда - замер на .30:
	# двенадцать страниц за 0.3 с.
	try:    frames = release_tech.for_ids([x.get('id') for x in L], httpSiteUrl)
	except: frames = {}
	for i in L:
		try:
			ft=i['fulltitle']
			label=get_label(ft)
			seeds=mids(i['seeds'], 6)
			size=mids(i['size'], 8)
			
			Title=label+" "+seeds+" | "+size+" | "+ft
			db_id = rutor.get_db_id(i)
			#print (Title+':'+db_id)
			curl=httpSiteUrl+'/download/'+i['id']
			# Своя запись на каждый релиз: раньше правился один и тот же info,
			# и все релизы фильма делили и магнит, и название раздачи. Скину
			# нужно и то и другое по отдельности: магнит - чтобы играть именно
			# этот релиз, название раздачи - чтобы собрать чип качества.
			rel = dict(info)
			rel['magnet'] = i['magnet']
			rel['release_fulltitle'] = ft
			rel['release_seeds'] = i.get('seeds', '')
			rel['release_size'] = i.get('size', '')
			frame = frames.get(str(i.get('id') or ''))
			if frame:
				rel['release_frame'] = '%dx%d' % (frame[0], frame[1])
				rel['release_frame_class'] = release_tech.frame_class(frame[0], frame[1])
			AddItem(Title, 'Open', db_id, curl, rel, len(L))
		except: pass
	
	xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	_end()
	SetViewMode()

def get_next_url(url):
	n1=url[url.find('/browse/')+8:]
	##print n1
	n=str(int(n1[:n1.find('/')])+1)
	t=n1[n1.find('/'):]
	h=url[:url.find('/browse/')+8]
	return h+n+t

# Сведения о фильмах, которых нет в info.db, - заранее и параллельно. Поиск
# запрашивал их по одному: замер на .30 17.10.2026, новый запрос «Ведьмак» -
# ~4 с сетевых ожиданий подряд (страницы раздач по одной). Здесь только сеть; запись в info.db - как и раньше, в основном
# потоке из get_info: соединение sqlite между потоками не делится.
_PREFETCHED = {}
PREFETCH_WORKERS = 6

def _prefetch_infos(items):
	need = []
	seen = set()
	for i in items or []:
		try:
			db_id = rutor.get_db_id(i)
		except Exception:
			continue
		if db_id in seen:
			continue
		seen.add(db_id)
		try:
			get_inf_db(db_id)
			continue
		except Exception:
			need.append((db_id, i))
	if len(need) < 2:
		return
	try:
		from concurrent.futures import ThreadPoolExecutor
	except Exception:
		return
	def one(pair):
		db_id, i = pair
		try: return db_id, rutor.get_info(i)
		except Exception: return db_id, None
	with ThreadPoolExecutor(max_workers=PREFETCH_WORKERS) as pool:
		for db_id, got in pool.map(one, need):
			if got is not None:
				_PREFETCHED[db_id] = got

def get_info(inf, resolve_tmdb=False):
	db_id = rutor.get_db_id(inf)
	info = {}
	from_db = False
	try:
		info = get_inf_db(db_id)
		from_db = True
	except:
		info = _PREFETCHED.pop(db_id, None)
		if info is None:
			info = rutor.get_info(inf)
	try: info['type'] = inf['type']
	except: pass
	try: info['id'] = inf['id']
	except: pass
	# Preserve original RuTor title fields for Kodi/TAM display.
	# TMDbHelper still receives raw candidates separately and does its own matching.
	try: info = tmdbhelper_ids.preserve_plugin_titles(info, inf)
	except: pass
	# Fast mode: list drawing never blocks on TMDbHelper.
	# TMDb IDs are resolved only by native background Check() or after opening a single item.
	if resolve_tmdb and not tmdbhelper_ids.has_tmdb_id(info):
		try: info = tmdbhelper_ids.enrich_info(info, inf)
		except: pass
	try: info = tmdbhelper_ids.preserve_plugin_titles(info, inf)
	except: pass
	if not from_db:
		try: add_to_db(db_id, info)
		except: pass
	elif resolve_tmdb and tmdbhelper_ids.has_tmdb_id(info):
		try: replace_db(db_id, info)
		except: pass
	return info

def get_title(i):
	r=i['title']
	e=i['originaltitle']
	if S_TITLE_MODE == '0':
		if r == e: title = r
		else: title = r+' / '+e
	if S_TITLE_MODE == '1': 
		title = r
	if S_TITLE_MODE == '3': 
		title = r +" [COLOR 33FFFFFF]("+str(i['year'])+")[/COLOR]"
	if S_TITLE_MODE == '2': 
		try: rat = i['seeds']
		except: rat = '--'
		rat = mids(rat, 6)
		title = '['+rat+'] '+r
	return title

import sqlite3 as db
# Кэш сведений о фильмах: одна таблица info(id, json) в addon_data. Было - своя
# таблица n<id> на каждый фильм (схема росла без конца) и файл в папке
# дополнения, которую стирает каждое обновление. Старое не переносим - это
# кэш (21.11.2026).
def _db_name():
	folder = xbmcvfs.translatePath('special://profile/addon_data/plugin.video.RuTor/')
	if not os.path.isdir(folder):
		try: os.makedirs(folder)
		except Exception: pass
	return os.path.join(folder, "info.db")
c = db.connect(database=_db_name(), timeout=5)
cu = c.cursor()
# кэш сведений: запись на строку без двух fsync на каждую (журнал WAL, synchronous NORMAL)
try:
	cu.execute('PRAGMA journal_mode=WAL')
	cu.execute('PRAGMA synchronous=NORMAL')
except Exception:
	pass
# сведения, собранные прежним разбором номера Кинопоиска с хвостом разметки, собираются заново
try:
	if cu.execute('PRAGMA user_version').fetchone()[0] < 1:
		cu.execute("DELETE FROM info WHERE json LIKE '%target=%'")
		cu.execute('PRAGMA user_version=1')
		c.commit()
except Exception:
	pass
cu.execute('CREATE TABLE IF NOT EXISTS info (id TEXT PRIMARY KEY, json TEXT)')
c.commit()

def add_to_db(n, info):
		cu.execute('INSERT OR IGNORE INTO info (id, json) VALUES (?, ?)', (n, json.dumps(info, ensure_ascii=False, default=str)))
		c.commit()

def get_inf_db(n):
		row = cu.execute('SELECT json FROM info WHERE id = ?', (n,)).fetchone()
		if row is None: raise KeyError(n)
		return json.loads(row[0])

def replace_db(n, info):
		cu.execute('INSERT OR REPLACE INTO info (id, json) VALUES (?, ?)', (n, json.dumps(info, ensure_ascii=False, default=str)))
		c.commit()

def rem_inf_db(n):
		try:
			cu.execute('DELETE FROM info WHERE id = ?', (n,))
			c.commit()
		except: pass

def update_info(id):
	rem_inf_db(id)
	xbmc.sleep(300)
	xbmc.executebuiltin('Container.Refresh')

def get_label(text):
	text=lower(text)#.lower()
	#print text
	if 'трейлер'  in text: return FC('[ Трейл.]',    'FF999999')
	if ' кпк'     in text: return FC('[   КПК  ]',   'FFF8888F')
	if 'telesyn'  in text: return FC('[    TS    ]', 'FFFF2222')
	if 'telecin'  in text: return FC('[    TS    ]', 'FFFF2222')
	if 'camrip'   in text: return FC('[    TS    ]', 'FFFF2222')
	if ' ts'      in text: return FC('[    TS    ]', 'FFFF2222')
	if 'dvdscr'   in text: return FC('[    Scr   ]', 'FFFF2222')
	if ' 3d'      in text: return FC('[    3D    ]', 'FC45FF45')
	if '720'      in text: return FC('[  720p  ]',   'FBFFFF55')
	if '1080'     in text: return FC('[ 1080p ]',    'FAFF9535')
	if '2160'     in text: return FC('[ 2160p ]',    'FAF990FF')
	if 'blu-ray'  in text: return FC('[  BRay  ]',   'FF5555FF')
	if 'bdremux'  in text: return FC('[    BD    ]', 'FF5555FF')
	if ' 4k'      in text: return FC('[    4K    ]', 'FF5555FF')
	if 'bdrip'    in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'drip'     in text: return FC('[ BDRip ]',    'FE98FF98')
	if 'hdrip'    in text: return FC('[ HDRip ]',    'FE98FF98')
	if 'webrip'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'WEB'      in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'web-dl'   in text: return FC('[  WEB   ]',   'FEFF88FF')
	if 'hdtv'     in text: return FC('[ HDTV ]',     'FEFFFF88')
	if 'tvrip'    in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'satrip'   in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvb '     in text: return FC('[    TV    ]', 'FEFFFF88')
	if 'dvdrip'   in text: return FC('[DVDRip]',     'FE88FFFF')
	if 'dvd5'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'xdvd'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-5'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd-9'    in text: return FC('[  DVD   ]',   'FE88FFFF')
	if 'dvd9'     in text: return FC('[  DVD   ]',   'FE88FFFF')
	return FC('[   ????  ]', 'FFFFFFFF')

def FC(s, color="FFFFFF00"):
	s="[COLOR "+color+"]"+s+"[/COLOR]"
	return s

def debug(s):
	fl = open(os.path.join( ru(LstDir),"test.txt"), "w")
	fl.write(s)
	fl.close()

def US(text):
	Search(text)

def filtr(title):
	f=True
	Tresh = ["Repack"," PC ","XBOX","RePack","FB2","TXT","DOC"," MP3"," JPG"," PNG"," SCR"]
	for i in Tresh:
		if i in title: f=False
	
	if S_HIDE_SCR:
		Scr = ["CAMRip", ") TS", ") TC", ") ТС", "CamRip", " DVDScr"]
		for i in Scr:
			if i in title: f=False
	
	for i in S_FILTR:
		if i in title: f=False
	
	return f

def SetViewMode():
	n = int(__settings__.getSetting("ListView"))
	if n>0:
		xbmc.executebuiltin("Container.SetViewMode(0)")
		for i in range(1,n):
			xbmc.executebuiltin("Container.NextViewMode")

def History():
	L=loads(__settings__.getSetting("History"), list)
	for i in L:
		AddItem(i, 'HSearch', '0', i)
	xbmcplugin.setPluginCategory(handle, PLUGIN_NAME)
	_end()

def add_history(t):
	L=loads(__settings__.getSetting("History"), list)
	if t not in L:
		NL=[]
		NL.append(t)
		NL.extend(L[:15])
		__settings__.setSetting("History", json.dumps(NL, ensure_ascii=False))


params = get_params()
mode     = ''
url      = ''
title    = ''
ref      = ''
img      = ''
id       = '0'
sort     = '2'
text     = '0'
num      = 0
info  = {}

try:	mode  = unquote(params["mode"])
except:	pass
try:	url  = unquote(params["url"])
except:	pass
try:	title  = unquote(params["title"])
except:	pass
try:	img  = unquote(params["img"])
except:	pass
try:	num  = int(unquote(params["num"]))
except:	pass
try:	id  = unquote(params["id"])
except:	pass
try:	text  = unquote(params["text"])
except:	pass
try:	info  = loads(unquote(params["info"]))
except:	pass


if mode == '': 			Root()
if mode == 'List': 		List(url)
if mode == 'Search':	Search()
if mode == 'HSearch':	Search(url)
if mode == 'History':	History()
if mode == 'Torrents':	Torrents(info)
if mode == "UpdateInfo":update_info(id)
if mode == "GetInfo":	get_info(info)
if mode == 'US':		US(text)
if mode == "Check": Check()
c.close()
































