# -*- coding: utf-8 -*-
"""«В тренде» YouTube - своей полосой, а не через дополнение.

ЗАЧЕМ

Замер на .30 07.09.2026: раздел «В тренде» дополнение YouTube отдаёт за
3.3-4.2 с, потому что на каждый вызов Kodi заводит отдельный процесс и
импортирует 38 800 строк python. Прямой запрос к YouTube Data API
(`videos?chart=mostPopular`) стоит 0.3-0.5 с и даёт те же самые ролики: именно
этот запрос дополнение делает внутри себя, тем же ключом владельца.

Владелец назвал «В тренде» среди того, что ему нужно, и разрешил перенести
(07.09.2026).

ЧТО ОСТАЁТСЯ ЗА ДОПОЛНЕНИЕМ

Воспроизведение: путь строки - это `plugin://plugin.video.youtube/play/...`,
поэтому ролик по-прежнему играет дополнение через InputStream Adapter.

НОРМА API

`videos.list` стоит 1 единицу за запрос, обновление раз в полчаса - 48 единиц
в сутки из 10 000. Дополнение платило ту же единицу за то же самое.
"""
from __future__ import absolute_import, unicode_literals

import io
import json
import re
import time

import xbmc

from . import mirror
from .config import log
from ..sublime_helper import tls as _tls
from ..sublime_helper.config import youtube_play_url

_tls.install()   # https при испорченном хранилище сертификатов системы (Windows)

SRC = 'sublime://youtube_trending'
PLUGIN_SETTINGS = 'special://profile/addon_data/plugin.video.youtube/settings.xml'
# регион дополнения: region у версии 8, youtube.region у 7 (пусто - по языку Kodi)
REGION_PATTERN = re.compile(r'id="(?:youtube\.)?region"[^>]*>([A-Z]{2})<')
TTL_SECONDS = 30 * 60
LIMIT = 50
TIMEOUT = 12.0



_AGO_UNITS = (
    (('секунд', 'second'), 1), (('минут', 'minute'), 60), (('час', 'hour'), 3600),
    (('дн', 'день', 'day'), 86400), (('недел', 'week'), 7 * 86400),
    (('месяц', 'month'), 30 * 86400), (('год', 'лет', 'year'), 365 * 86400),
)


def _published(text):
    """«2 дня назад» / «Streamed 3 hours ago» -> «ГГГГ-ММ-ДД ЧЧ:ММ:СС» (примерно, по местному времени).

    Без ключа Data API YouTube отдаёт в выдаче только относительное время, а инфо-строка
    скина показывает дату из dateadded/premiered - у роликов полос без ключа её не было
    (владелец 15.11.2026: «в ютубе нет дат выпуска роликов в инфостроке»)."""
    text = (text or '').lower()
    m = re.search(r'(\d+)\s*([^\d\s]+)', text)
    if not m:
        return ''
    count, word = int(m.group(1)), m.group(2)
    for stems, seconds in _AGO_UNITS:
        if any(word.startswith(stem) for stem in stems):
            return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time() - count * seconds))
    return ''


def _region():
    """Регион трендов - тот же, что настроен у дополнения (у владельца RU)."""
    cached = getattr(_region, '_value', None)
    if cached:
        return cached
    value = 'RU'
    try:
        import xbmcvfs
        with io.open(xbmcvfs.translatePath(PLUGIN_SETTINGS), encoding='utf-8') as handle:
            found = REGION_PATTERN.search(handle.read())
        if found:
            value = found.group(1)
    except Exception:
        value = 'RU'
    _region._value = value
    return value


INNERTUBE_URL = 'https://www.youtube.com/youtubei/v1/search?prettyPrint=false'
# Без ключа Data API: тот же внутренний интерфейс, через который работает сам сайт и
# воспроизведение дополнения. «В тренде» YouTube убрал в 2025, поэтому «популярное за
# неделю»: поиск без запроса, загружено на этой неделе, по числу просмотров.
INNERTUBE_PARAMS = 'CAMSBAgDEAE='


def _walk(node, out):
    if isinstance(node, dict):
        if 'videoRenderer' in node:
            out.append(node['videoRenderer'])
        for value in node.values():
            _walk(value, out)
    elif isinstance(node, list):
        for value in node:
            _walk(value, out)
    return out


def _text(value):
    value = value or {}
    if value.get('simpleText'):
        return str(value['simpleText'])
    return ''.join(str(run.get('text') or '') for run in value.get('runs') or [])


def _inner_art(video, video_id):
    from .youtube_inner import _best_art
    return _best_art(video_id, (video.get('thumbnail') or {}).get('thumbnails') or [])


def fetch_innertube():
    """Популярное за неделю без ключа. Пустой список - значит не вышло."""
    region = _region()
    body = {'context': {'client': {'clientName': 'WEB', 'clientVersion': '2.20251101.00.00',
                                   'hl': 'ru' if region == 'RU' else 'en', 'gl': region}},
            'query': '', 'params': INNERTUBE_PARAMS}
    try:
        import urllib.request
        request = urllib.request.Request(INNERTUBE_URL, data=json.dumps(body).encode('utf-8'),
                                         headers={'Content-Type': 'application/json',
                                                  'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(request, timeout=TIMEOUT) as answer:
            payload = json.loads(answer.read().decode('utf-8'))
    except Exception as exc:
        log('популярное YouTube (без ключа): запрос не удался: %s' % exc, xbmc.LOGWARNING)
        return []
    rows = []
    for video in _walk(payload, [])[:max(1, min(50, LIMIT))]:
        video_id = str(video.get('videoId') or '')
        title = _text(video.get('title')).strip()
        if not video_id or not title:
            continue
        owner = (((video.get('ownerText') or {}).get('runs') or [{}])[0])
        channel_id = str(((owner.get('navigationEndpoint') or {}).get('browseEndpoint') or {}).get('browseId') or '')
        
        rows.append({
            'label': title,
            'file': youtube_play_url(video_id),
            'filetype': 'file',
            'plot': _text((video.get('detailedMetadataSnippets') or [{}])[0].get('snippetText')),
            'dateadded': _published(_text(video.get('publishedTimeText'))),
            'premiered': _published(_text(video.get('publishedTimeText')))[:10],
            'art': _inner_art(video, video_id),
            'studio': str(owner.get('text') or ''),
            'channel_id': channel_id,
            'genre': [],
            'playcount': 0,
            'episode': -1,
            '_api': True,
        })
    return rows


def fetch():
    """Строки «популярного» без ключа. Пустой список - значит не вышло.

    Путь через YouTube Data API (videos?chart=mostPopular ключом владельца) убран 26.11.2026:
    дополнение YouTube 8 ключей не знает, и установщик их больше не спрашивает."""
    return fetch_innertube()


def refresh(force=False):
    """Обновить снимок, если он устарел. Возвращает число строк."""
    stamp = mirror.stamp_of(SRC)
    if not force and stamp and (time.time() - stamp) < TTL_SECONDS:
        kept, _stamp = mirror.load(SRC)
        return len(kept or [])
    rows = fetch()
    if not rows:
        kept, _stamp = mirror.load(SRC)
        return len(kept or [])
    from .youtube_tvfeed import finish_rows
    rows = finish_rows(rows)
    mirror.store(SRC, rows)
    log('тренды YouTube: %d строк, регион %s' % (len(rows), _region()))
    return len(rows)


def rows():
    """Строки для полосы. Снимок отдаётся сразу, обновление - делом службы."""
    kept, stamp = mirror.load(SRC)
    if not kept:
        refresh(force=True)
        kept, stamp = mirror.load(SRC)
    return kept or []


def stale():
    stamp = mirror.stamp_of(SRC)
    return not stamp or (time.time() - stamp) >= TTL_SECONDS
