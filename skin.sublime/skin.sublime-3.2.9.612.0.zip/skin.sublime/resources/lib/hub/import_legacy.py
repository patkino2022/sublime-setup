# -*- coding: utf-8 -*-
"""Seeding Kodi with the history that predates it holding the history.

Moving the watched state into Kodi's own database left the old rows behind:
2478 of them lived in the retired add-on's store, and the taste profile that
reads Kodi went from thousands of titles to eight. Nothing was lost - it was in
the wrong place.

Kodi keys by path, and the old rows only know a title and a year, so each row is
matched against the provider's catalogue to find the path it would play, and
then written into Kodi through the public API. Rows the catalogue cannot match
are reported rather than guessed at. Run once per set of old data; it is
idempotent, because writing the same playcount twice is the same fact.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import sqlite3

import xbmc
import xbmcvfs

from . import catalog, history, identity
from .config import log

LEGACY_STORES = (
    'special://profile/addon_data/plugin.video.watchhub/watchhub.db',
    '/storage/hub-server/watch_state.db',
)


def _open_ro(path):
    try:
        return sqlite3.connect('file:%s?mode=ro' % path, uri=True, timeout=10)
    except Exception as exc:
        log('%s не открылась: %s' % (os.path.basename(path), exc), xbmc.LOGWARNING)
        return None


def _episode_path(show_path, season, episode):
    """The episode's own URL, derived from the show's row in the catalogue.

    Kodi keys an episode by `.../serials/<id>-<slug>/play/?s=<s>&e=<e>` - the
    same URL the provider opens. Deriving it from the show's catalogue path
    keeps the slug exact instead of rebuilding it from a title.
    """
    base = str(show_path or '')
    if not base:
        return ''
    for tail in ('/open/', '/episodes/', '/play/'):
        if tail in base:
            base = base.split(tail)[0] + '/play/'
            break
    else:
        return ''
    return '%s?s=%s&e=%s' % (base, season, episode)


def _legacy_rows():
    """Watched rows from whichever old store this box can see."""
    for uri in LEGACY_STORES:
        path = xbmcvfs.translatePath(uri) if uri.startswith('special://') else uri
        if not os.path.isfile(path):
            continue
        conn = _open_ro(path)
        if conn is None:
            continue
        try:
            rows = list(conn.execute(
                'SELECT label, year, mediatype, season, episode, playcount,'
                ' last_watched FROM watched WHERE playcount > 0'))
        except Exception as exc:
            log('%s: watched не читается (%s)' % (os.path.basename(path), exc),
                xbmc.LOGWARNING)
            rows = []
        finally:
            try:
                conn.close()
            except Exception:
                pass
        if rows:
            return os.path.basename(path), rows
    return '', []


def _path_index():
    """{(normalised title, year): play path} from the provider's own catalogue."""
    index = {}
    for row in catalog.iter_post_rows():
        label = row.get('label') or row.get('title') or ''
        path = row.get('file') or ''
        if not label or not path:
            continue
        key = (identity.normalize_title(label), str(row.get('year') or '')[:4])
        # First win: the provider lists newer duplicates first and a later
        # same-titled entry must not steal an established mapping.
        index.setdefault(key, path)
    return index


def run(limit=0):
    """Write the old history into Kodi. Returns a short report."""
    source, rows = _legacy_rows()
    if not rows:
        return {'source': '', 'total': 0, 'written': 0, 'unmatched': 0}
    index = _path_index()
    written = unmatched = 0
    seen = set()
    episodes = 0
    for label, year, mediatype, season, episode, playcount, last_watched in rows:
        key = (identity.normalize_title(label or ''), str(year or '')[:4])
        show_path = index.get(key)
        if not show_path:
            unmatched += 1
            continue
        try:
            season_no = int(season or 0)
            episode_no = int(episode or 0)
        except (TypeError, ValueError):
            season_no = episode_no = 0
        if episode_no > 0:
            # An episode is its own row in Kodi, and writing it as one is what
            # keeps the detail: marking the show instead loses which episodes
            # were seen, which is how a thousand-odd marks looked like they had
            # vanished.
            path = _episode_path(show_path, season_no, episode_no)
            if path:
                episodes += 1
        else:
            path = show_path
        if not path or path in seen:
            continue
        seen.add(path)
        if history.mark_watched(path, int(playcount or 1), int(last_watched or 0)):
            written += 1
        if limit and written >= limit:
            break
    history.invalidate()
    if written:
        # The imported rows carry their ORIGINAL watch dates, which are older
        # than the sync's high-water mark - so without this reset they would
        # never be sent to the other boxes: the cursor had already passed them.
        try:
            from . import sync
            from .store import db
            db().set_flag(sync.PUSH_CURSOR, '0')
            log('курсор отправки сброшен, история уедет на другие боксы')
        except Exception as exc:
            log('курсор отправки не сброшен: %s' % exc, xbmc.LOGWARNING)
    log('перенос истории из %s: записано %d (эпизодов %d), без совпадения %d,'
        ' всего %d' % (source, written, episodes, unmatched, len(rows)))
    return {'source': source, 'total': len(rows), 'written': written,
            'episodes': episodes, 'unmatched': unmatched}


def report(result):
    return json.dumps(result, ensure_ascii=False)
