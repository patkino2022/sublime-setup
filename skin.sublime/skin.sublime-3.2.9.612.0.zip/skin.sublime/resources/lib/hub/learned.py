# -*- coding: utf-8 -*-
"""What we have already learned about a post: its ids and its description.

Moved out of hub/warm.py, which no longer exists. Warming used to read a row's
identity off the interface and remember it here; the builder resolves identity
anyway while it prepares the row (hub/builder.py), so it remembers it instead.

Why remember at all: the provider runs in source-only mode by design, so
identity is the skin's job, and a row without ids costs a title search, a
details call, a cross-id lookup and a logo lookup. Once found, the ids travel
with the row and nobody pays that again.
"""
from __future__ import absolute_import, unicode_literals

import json

import xbmc

from .config import log
from .store import db

IDS_FLAG = 'lane_ids'
PLOTS_FLAG = 'lane_plots'
# Two lanes' worth of rows is all that is ever read back; beyond that the oldest
# entries are of no use to anyone.
MAX_IDS = 4000
MAX_PLOTS = 1500
PLOT_LIMIT = 1200


def _read(flag):
    try:
        known = json.loads(db().get_flag(flag) or '{}')
        return known if isinstance(known, dict) else {}
    except Exception:
        return {}


def ids():
    """{post_id: {imdb, tmdb}} for the lane builder."""
    return _read(IDS_FLAG)


def plots():
    """{post_id: plot} for rows the provider has not cached."""
    return _read(PLOTS_FLAG)


def _trim(known, limit):
    if len(known) > limit:
        for stale in list(known)[:len(known) - limit]:
            known.pop(stale, None)
    return known


def remember_ids(post_id, found):
    post_id = str(post_id or '')
    found = {k: str(v) for k, v in (found or {}).items() if v}
    if not post_id or not found:
        return False
    known = ids()
    if known.get(post_id) == found:
        return False
    known[post_id] = found
    try:
        db().set_flag(IDS_FLAG, json.dumps(_trim(known, MAX_IDS)))
        return True
    except Exception as exc:
        log('идентификаторы не сохранены: %s' % exc, xbmc.LOGWARNING)
        return False


def remember_plot(post_id, plot):
    post_id = str(post_id or '')
    plot = str(plot or '').strip()
    if not post_id or not plot:
        return False
    known = plots()
    if known.get(post_id) == plot[:PLOT_LIMIT]:
        return False
    known[post_id] = plot[:PLOT_LIMIT]
    try:
        db().set_flag(PLOTS_FLAG, json.dumps(_trim(known, MAX_PLOTS),
                                             ensure_ascii=False))
        return True
    except Exception as exc:
        log('описание не сохранено: %s' % exc, xbmc.LOGWARNING)
        return False
