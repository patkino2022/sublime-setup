"""TLS context for every https request of the service (net.py, urllib).

ssl.create_default_context() loads the system store. On Windows one broken
certificate in that store makes it raise ([ASN1] nested asn1 error) and python
in Kodi then opens no https address at all (23.11.2026). The fallback verifies
against certifi (a dependency Kodi installs with requests) or the CA bundle Kodi
ships for its own curl (system/certs/cacert.pem next to kodi.exe).
"""
import os
import ssl
import sys


def _bundles():
    try:
        import certifi
        yield certifi.where()
    except Exception:
        pass
    base = os.path.dirname(sys.executable or '')
    yield os.path.join(base, 'system', 'certs', 'cacert.pem')


def _from_bundle():
    for path in _bundles():
        if path and os.path.isfile(path):
            return ssl.create_default_context(cafile=path)
    return None


def context():
    # Windows: хранилище системы не читать вовсе - при перезапуске Kodi его чтение падало уже не
    # SSLError, а SystemError внутри ssl (dictobject.c: bad argument, 23.11.2026)
    if os.name == 'nt':
        ctx = _from_bundle()
        if ctx is not None:
            return ctx
    try:
        return ssl.create_default_context()
    except Exception:
        ctx = _from_bundle()
        if ctx is None:
            raise
        return ctx


def install():
    """urllib.request without an explicit context uses this one too."""
    ssl._create_default_https_context = context
