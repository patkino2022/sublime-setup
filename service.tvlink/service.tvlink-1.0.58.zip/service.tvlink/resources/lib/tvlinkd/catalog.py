"""Playlists -> channels -> the playlist pvr.tvlink reads.

channels.json is the owner's arrangement and the only thing the sorting screen
edits:
  {"version": 1,
   "groups":   [{"name": "Избранное", "enabled": true, "order": ["CEDC5D3C", ...]}],
   "channels": {"CEDC5D3C": {"title": "Первый канал HD", "group": "Эфирные",
                             "hidden": false, "aliases": ["BD01A459"], "epg": "Glanz@pervy"}}}
Group order is list order. Inside a group, ids from "order" go first, the rest by name.
A channel's "also": ["Србија"] shows it in more groups too (one channel, several
groups: group-title="Спорт;Србија", which the client splits on ';').
"numbers" {id: n} keeps channel numbers: a channel keeps its number when groups
or channels move; a new channel takes the next free one.
Links of a channel are its own id plus its aliases, by playlist priority: the
streamer walks them in that order when a source fails.

Naming standard (normalize.py): only for the built-in free playlists - the ones the
installer marks "check" (plN_check). Their titles
are normalized before anything else ("Russia-1 +4 (1080p)" -> "Россия 1 HD (+4)"),
identical channels become one channel with several links (HD and SD stay apart),
groups come from the standard list without «Другие», the guide and the logos are
matched by the normalized name too. The owner's own playlists stay exactly as they
were; a channel that is in both keeps the name and group of the owner's playlist
(its links are still merged). A title or group set in channels.json always wins.
config "normalize_names": false switches the standard off, true applies it to all.
"""
import os
import re
from urllib.parse import quote, urlsplit

from . import groups

from . import ids, m3u, normalize
from .store import read_json, write_json

FALLBACK_GROUP = "Другие"


def _catchup_kind(pl, entry):
    kind = (pl.get("catchup") or "auto").lower()
    if kind != "auto":
        return kind
    a = entry["attrs"]
    kind = (a.get("catchup") or a.get("catchup-type") or "").lower()
    if kind in ("flussonic", "flussonic-ts", "fs"):
        return "flussonic"
    if kind in ("shift", "append", "default"):
        return kind
    if re.search(r"/(video|index|mono)\.m3u8", entry["url"]) and "token=" in entry["url"]:
        return "flussonic"
    return "shift"


def _merge_key(title):
    from .logos import _TRANSLIT
    low = (title or "").casefold().replace("fhd", "hd")
    # пометки сборников - не часть названия: «(720p)», «[Geo-blocked]», «[Not 24/7]»
    low = re.sub(r"\("+r"\d{3,4}[pi]\)|\[[^\]]*\]", " ", low)
    low = "".join(_TRANSLIT.get(ch, ch) for ch in low)
    low = low.replace("kh", "h").replace("iy", "y").replace("yy", "y")
    # сдвиг времени: «(+4)», «(-3)», « +2» - но не дефис в названии («Россия-1»)
    m = re.search(r"(?:\(\s*|\s)([+-])\s*(\d{1,2})\s*\)?\s*$", low)
    shift = m.group(1) + m.group(2) if m else ""
    base = low[:m.start()] if m else low
    return "".join(ch for ch in base if ch.isalnum()) + shift


def normalized(cfg, pl):
    """Naming standard for this playlist? Built-in free playlists only (flag "check");
    config "normalize_names": true/false overrides for all playlists."""
    mode = cfg.get("normalize_names", "auto")
    if isinstance(mode, str) and mode.lower() in ("", "auto"):
        return bool(pl.get("check"))
    if isinstance(mode, str):
        return mode.lower() in ("1", "true", "on", "yes")
    return bool(mode)


def load_links(cfg, paths):
    """{id: [link, ...]} in playlist priority order, plus header attrs per playlist.
    Links of a built-in playlist (normalized()) carry the standard title and "norm"."""
    links, headers, firsts = {}, {}, {}
    canon, owner = {}, {}
    parsed = []
    for prio, pl in enumerate(cfg["playlists"]):
        try:
            with open(paths.source(pl["name"]), "r", encoding="utf-8", errors="replace") as f:
                header, entries = m3u.parse(f.read())
        except OSError:
            continue
        headers[pl["name"]] = header
        parsed.append((prio, pl, normalized(cfg, pl), entries))
    # standard names of the built-in playlists: an owner's line with the same standard
    # name joins that channel as one more link ("Channel One (1080p)" of his list and
    # "Первый канал HD" of the free one), but keeps his own title
    std_keys = {_merge_key(normalize.title(e["title"])) for _p, _pl, norm, entries in parsed if norm
                for e in entries}
    for prio, pl, norm, entries in parsed:
        for e in entries:
            clean = ids.clean_title(e["title"], cfg["strip_suffixes"])
            title = normalize.title(e["title"]) if norm else clean
            # один канал из разных источников: «Россия-1», «Россия 1», «Russia 1» сводятся к
            # первому встреченному id (HD и сдвиг времени остаются отдельными каналами)
            key = _merge_key(title)
            if not norm and std_keys and key not in canon:
                k2 = _merge_key(normalize.title(e["title"]))
                if k2 in std_keys:
                    key = k2
            lid = canon.get(key)
            if lid is None:
                lid = ids.chid(clean)
                if owner.get(lid, key) != key:      # другой канал с тем же id сырого названия
                    lid = ids.chid(title)
                canon[key] = lid
                owner[lid] = key
            a = e["attrs"]
            days = a.get("catchup-days") or a.get("tvg-rec") or a.get("timeshift") or pl.get("days")
            link = {"src": pl["name"], "prio": prio, "url": e["url"], "title": title, "raw_title": e["title"],
                    "clean_title": clean, "norm": norm,
                    "group": e["group"], "logo": e["logo"], "tvg_id": a.get("tvg-id", ""),
                    "headers": e.get("headers") or {},
                    "catchup": _catchup_kind(pl, e), "catchup_source": a.get("catchup-source", ""),
                    "days": int(days) if str(days or "").isdigit() else cfg["archive_days"]}
            links.setdefault(lid, []).append(link)
            firsts.setdefault(lid, link)
    return links, headers, firsts


def load_arrangement(paths):
    arr = read_json(paths.channels, None) or {}
    arr.setdefault("version", 1)
    arr.setdefault("groups", [])
    arr.setdefault("channels", {})
    arr.setdefault("numbers", {})
    return arr


def merge_new(cfg, arr, firsts, links):
    """Add channels the playlists brought since last time. Returns True if changed.
    Only playlists with add_new do this: a big provider list carries hundreds of
    +2/+4 duplicates the owner never wanted, a small one (Serbia) all of them.
    A channel only from built-in playlists gets the standard group, else the owner's
    playlist's title and group."""
    adders = {p["name"] for p in cfg["playlists"] if p.get("add_new", cfg.get("auto_add", True))}
    if not adders:
        return False
    known = set(arr["channels"])
    for ch in arr["channels"].values():
        known.update(ch.get("aliases") or [])
    gnames = {g["name"] for g in arr["groups"]}
    changed = False
    for lid, link in firsts.items():
        if lid in known or link["src"] not in adders:
            continue
        own = [ln for ln in links.get(lid, ()) if not ln.get("norm")]
        if own:
            title, grp = own[0]["title"], own[0]["group"] or FALLBACK_GROUP
        else:
            title = link["title"]
            grp = normalize.group(link["title"], [ln["group"] for ln in links.get(lid, ())])
        arr["channels"][lid] = {"title": title, "group": grp}
        if grp not in gnames:
            arr["groups"].append({"name": grp, "enabled": True})
            gnames.add(grp)
        changed = True
    return changed


_Q = ((re.compile(r"(?<![A-Za-z0-9])(4K|UHD|2160p?)(?![A-Za-z0-9])", re.I), 4),
      (re.compile(r"(?<![A-Za-z0-9])(FHD|1080[pi]?)(?![A-Za-z0-9])", re.I), 3),
      (re.compile(r"(?<![A-Za-z0-9])(HD|HDR|720p?)(?![A-Za-z0-9])", re.I), 2))


def _quality(title):
    for rx, q in _Q:
        if rx.search(title or ""):
            return q
    return 1


def _sort_key(title):
    # plain code-point order, as TVLINK sorted ("BOX Docu" before "Big Planet"),
    # so the owner's channel numbers stay where they were
    return title


def build(cfg, paths, persist=True):
    """Return the catalog: ordered channel list with their links."""
    links, headers, firsts = load_links(cfg, paths)
    arr = load_arrangement(paths)
    if merge_new(cfg, arr, firsts, links) and persist:
        write_json(paths.channels, arr)

    icons = read_json(os.path.join(paths.cache, "epg_icons.json"), {}) or {}
    # единый набор групп (groups.py) - если в папке данных есть флажок standard_groups
    flag = os.path.join(paths.root, "standard_groups")
    shown = None
    try:
        with open(os.path.join(paths.root, "show_groups"), encoding="utf-8") as fh:
            shown = {line.strip() for line in fh if line.strip()} or None
    except OSError:
        shown = None
    standard = os.path.exists(flag)
    lang = ""
    if standard:
        try:
            with open(flag, encoding="utf-8") as fh:
                lang = fh.read().strip().lower()
        except OSError:
            pass
    by_group = {}
    for cid, ch in arr["channels"].items():
        if ch.get("hidden"):
            continue
        chain, seen = [], set()
        for lid in [cid] + list(ch.get("aliases") or []):
            for ln in links.get(lid, ()):
                if ln["url"] not in seen:
                    seen.add(ln["url"])
                    chain.append(ln)
        if not chain:
            continue
        # Owner's order (20.10.2026): HD lines first (HD/FHD/4K tag) by playlist
        # priority - Glanz before Edem - and the longest title first, as TVLINK
        # did ("Первый канал HD PREMIUM+" before "Первый канал HD"); then the rest
        # the same way.
        chain.sort(key=lambda ln: (_quality(ln["raw_title"]) < 2, ln["prio"], -len(ln["raw_title"])))
        # the standard only for a channel whose links all come from built-in playlists;
        # one link of the owner's own playlist and the channel stays his
        norm = all(ln.get("norm") for ln in chain + [ln for lid in [cid] + list(ch.get("aliases") or [])
                                                     for ln in links.get(lid, ())])
        match = [cid] + list(ch.get("aliases") or [])
        if norm:
            title, std = _standard(ch, cid, chain, links)
            gname = groups.label(std, lang)
            # группы встроенных плейлистов, выбранные при установке (файл show_groups): канал
            # не из выбранных не попадает в список
            if shown is not None and std not in shown:
                continue
            # ids the guide and the logo pack may know the channel by: also those of every
            # title it goes by (normalized and raw)
            for t in [title] + [ln["title"] for ln in chain] + [ln["clean_title"] for ln in chain]:
                i = ids.chid(t, cfg["strip_suffixes"])
                if i not in match:
                    match.append(i)
        else:
            title, g = _owners(ch, chain, [ln for lid in [cid] + list(ch.get("aliases") or [])
                                           for ln in links.get(lid, ())])
            gname = (groups.label(groups.normalize(g), lang) if standard else (g or FALLBACK_GROUP))
        target = by_group.setdefault(gname, [])
        target.append(
            {"id": cid, "title": title, "links": chain, "match_ids": match, "norm": norm,
             "epg": ch.get("epg"), "aliases": list(ch.get("aliases") or []),
             "tvg_ids": sorted({ln["tvg_id"] for ln in chain if ln["tvg_id"]}),
             "also": [] if standard else [g for g in (ch.get("also") or []) if g != (ch.get("group") or FALLBACK_GROUP)],
             "logo": next((ln["logo"] for ln in chain if ln["logo"]), "") or icons.get(cid, "")})

    # groups with fewer than min_group channels are dissolved: their channels stay only in
    # Kodi's "all channels" (no group-title), so the TV hub does not get near-empty tabs
    loose = []
    # стандартные группы встроенных плейлистов не распускаются: их каналы иначе пропадали
    # с вкладок хаба ТВ (остаются только в «все каналы»); роспуск - для своих групп плейлистов
    keep = {groups.label(g, lang) for g in groups.STANDARD} if standard else set()
    for name in [n for n, chans in by_group.items()
                 if len(chans) < int(cfg.get("min_group") or 0) and n not in keep]:
        loose.extend(by_group.pop(name))
    out = []
    # порядок групп; в едином наборе - стандартный, сохранённая раскладка не трогается
    if standard:
        # единый набор без пустых групп; «Другие» бывает только у каналов своих плейлистов
        glist = [{"name": groups.label(n, lang), "enabled": True} for n in groups.STANDARD
                 if groups.label(n, lang) in by_group]
    else:
        glist = arr["groups"]
    names = [g["name"] for g in glist]
    for name in [n for n in by_group if n not in names]:
        glist.append({"name": name, "enabled": True})
    for g in glist:
        if not g.get("enabled", True) or g["name"] not in by_group:
            continue
        chans = by_group[g["name"]]
        pos = {cid: i for i, cid in enumerate(g.get("order") or [])}
        chans.sort(key=lambda c: (pos.get(c["id"], len(pos)), _sort_key(c["title"])))
        for c in chans:
            c["group"] = g["name"]
            out.append(c)
    for c in sorted(loose, key=lambda c: _sort_key(c["title"])):
        c["group"] = ""
        c["also"] = []
        out.append(c)
    if _number(arr, out) and persist:
        write_json(paths.channels, arr)
    return {"channels": out, "headers": headers, "groups": glist}


_FROM_ENGLISH = {v: k for k, v in groups.ENGLISH.items()}


def _owners(ch, chain, every):
    """(title, raw group) of a channel of the owner's own playlist, as before the standard:
    channels.json first, else the first link of his playlist (not a built-in one's
    normalized title that merge_new may have stored when the free list came first)."""
    own = [ln for ln in chain if not ln.get("norm")] or [ln for ln in every if not ln.get("norm")] or chain
    auto_t = {ln["title"] for ln in every if ln.get("norm")}
    auto_g = {ln["group"] for ln in every if ln.get("norm")} - {ln["group"] for ln in own}
    t = ch.get("title") or ""
    g = ch.get("group") or ""
    if not t or (t in auto_t and t != own[0]["title"]):
        t = own[0]["title"]
    if not g or g in auto_g:
        g = own[0]["group"] or g
    return t, g


def _standard(ch, cid, chain, links):
    """(title, standard group) of a channel under the naming standard. The owner's title
    and group in channels.json win; one written there automatically (the playlist's raw
    title or group, as merge_new stored it before the standard) does not."""
    own = links.get(cid) or chain
    auto_titles = {""}
    auto_groups = {"", FALLBACK_GROUP, groups.OTHER, groups.ENGLISH[groups.OTHER]}
    for ln in chain:
        auto_titles.update((ln["title"], ln.get("clean_title") or "", ln["raw_title"]))
        auto_groups.add(ln["group"] or "")
    t = ch.get("title") or ""
    title = own[0]["title"] if t in auto_titles else t
    g = ch.get("group") or ""
    std = ""
    if g not in auto_groups:
        g = _FROM_ENGLISH.get(g, g)
        std = g if g in groups.STANDARD else groups.normalize(g)
    if not std or std == groups.OTHER:
        std = normalize.group(own[0]["title"], [ln["group"] for ln in chain])
    return title, std


def _number(arr, out):
    """Stored numbers first; channels without one get the next free numbers in
    list order. Returns True when new numbers were handed out."""
    nums = arr["numbers"]
    taken = set()
    for c in out:
        n = nums.get(c["id"])
        if n and n not in taken:
            c["num"] = n
            taken.add(n)
    nxt = max(list(taken) + [int(v) for v in nums.values()] + [0]) + 1
    new = False
    for c in out:
        if "num" not in c:
            c["num"] = nums[c["id"]] = nxt
            nxt += 1
            new = True
    return new


def dash_link(c):
    """Ссылка канала на манифест DASH (.mpd) или None: такой поток tvlink не ретранслирует."""
    for ln in c.get("links", ()):
        if urlsplit(ln.get("url") or "").path.lower().endswith(".mpd"):
            return ln
    return None


def render_playlist(cfg, catalog, paths):
    host, port, sport = cfg["host"], cfg["port"], cfg["stream_port"]
    # a logo replaced after Kodi cached it needs a new URL, or the old picture stays
    replaced = read_json(os.path.join(paths.cache, "logo_sources.json"), {}) or {}
    enabled = {g["name"] for g in catalog.get("groups", ()) if g.get("enabled", True)}
    lines = ["#EXTM3U"]
    for c in catalog["channels"]:
        logo_id = c["id"] if _has_logo(paths, c) else groups.logo_id(c.get("group") or "")
        if logo_id == c["id"] and c["id"] in replaced:
            logo_id += ".png?v=%s" % replaced[c["id"]].get("v", 1)
        else:
            logo_id += ".png"
        title = c["title"].replace(",", " ")
        glabel = ";".join([g for g in [c["group"]] + [g for g in c.get("also", ()) if not enabled or g in enabled] if g])
        days = max(ln["days"] for ln in c["links"])
        lines.append('#EXTINF:-1 group-title="%s" tvg-id="%s" tvg-name="%s" tvg-logo="http://%s:%d/logo/%s" '
                     'tvg-chno="%d" timeshift="%d",%s'
                     % (glabel.replace('"', "'"), c["id"], title.replace('"', "'"), host, port,
                        logo_id, c["num"], days, title))
        dash = dash_link(c)
        if dash:
            # DASH играет inputstream.adaptive: pvr.sublime отдаёт ему адрес канала,
            # tvlink перенаправляет на манифест (см. daemon.stream)
            lines.append("#KODIPROP:inputstream=inputstream.adaptive")
            # mimetype не задаётся: тип (DASH или запасной HLS) inputstream.adaptive
            # берёт из Content-Type ответа tvlink (daemon.H.adaptive)
            # отставание от края эфира: без него inputstream.adaptive просит сегмент,
            # которого на CDN ещё нет (404), и после шести повторов останавливается
            # (Первый канал советует 40 с - suggestedPresentationDelay)
            # (отдельное свойство live_delay в inputstream.adaptive 22 устарело)
            lines.append('#KODIPROP:inputstream.adaptive.manifest_config={"live_delay":40}')
            hdrs = dict(dash.get("headers") or {})
            hdrs.setdefault("User-Agent", cfg["user_agent"])
            enc = "&".join("%s=%s" % (k, quote(v, safe="")) for k, v in sorted(hdrs.items()) if v)
            lines.append("#KODIPROP:inputstream.adaptive.common_headers=" + enc)
        lines.append("http://%s:%d/%s" % (host, sport, c["id"]))
    return "\n".join(lines) + "\n"


def _has_logo(paths, c):
    # only a file on disk: a logo URL that never answers must end up as the
    # skin's 0000 placeholder, not as a broken picture
    return os.path.exists(os.path.join(paths.logos, c["id"] + ".png"))
