# -*- coding: utf-8 -*-
"""Sharing the hub's materials through a folder instead of a server.

The owner asked to be able to put the recommendations and the watched history
anywhere - locally, on a share, on FTP, over HTTP. Kodi's own VFS already speaks
all of those, so the hub keeps three plain JSON documents in one folder and
merges them the same way the HTTP server does:

    hub_history.json    what each box played: playcount, resume, when
    hub_feedback.json   "recommend / do not recommend such"
    hub_lists.json      the built recommendation lists

Two honest limits, both from Kodi rather than from here:

* over `http://` and `https://` Kodi's VFS can read but not write. A box
  pointed at an HTTP folder therefore consumes what others published and never
  publishes its own - useful when one box owns the data and the rest follow.
* nothing about a network folder is atomic. Writes take a lock file with a
  timeout and write through a temporary name, which makes a lost update
  unlikely rather than impossible. For two boxes a minute apart that is enough;
  the HTTP server exists for when it is not.
"""
from __future__ import absolute_import, unicode_literals

import json
import time

import xbmc
import xbmcvfs

from .config import get_int, get_str, log, pause

HISTORY_DOC = 'hub_history.json'
FEEDBACK_DOC = 'hub_feedback.json'
LISTS_DOC = 'hub_lists.json'
SETTINGS_DOC = 'hub_settings.json'
LOCK_DOC = 'hub.lock'
LOCK_TTL = 120


def base_path():
    """The configured folder, always with a trailing slash."""
    path = (get_str('state_path', '') or '').strip()
    if not path:
        return ''
    return path if path.endswith(('/', '\\')) else path + '/'


def writable():
    """False for the transports Kodi can only read."""
    return not base_path().lower().startswith(('http://', 'https://'))


def _join(name):
    return base_path() + name


def read_doc(name):
    """One document, or an empty dict when it is absent or unreadable."""
    path = _join(name)
    if not path:
        return {}
    handle = None
    try:
        if not xbmcvfs.exists(path):
            return {}
        handle = xbmcvfs.File(path)
        raw = handle.read()
        return json.loads(raw or '{}') or {}
    except Exception as exc:
        log('%s не прочитан: %s' % (name, exc), xbmc.LOGWARNING)
        return {}
    finally:
        try:
            if handle is not None:
                handle.close()
        except Exception:
            pass


def write_doc(name, payload):
    """Write through a temporary name, then move it into place."""
    if not writable():
        return False
    path = _join(name)
    if not path:
        return False
    temp = path + '.tmp'
    handle = None
    try:
        handle = xbmcvfs.File(temp, 'w')
        handle.write(json.dumps(payload, ensure_ascii=False))
    except Exception as exc:
        log('%s не записан: %s' % (name, exc), xbmc.LOGWARNING)
        return False
    finally:
        try:
            if handle is not None:
                handle.close()
        except Exception:
            pass
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
        return bool(xbmcvfs.rename(temp, path))
    except Exception as exc:
        log('%s не переименован: %s' % (name, exc), xbmc.LOGWARNING)
        return False


def acquire_lock(owner, wait=6.0):
    """A cooperative lock: good enough for two boxes, honest about being so."""
    if not writable():
        return False
    deadline = time.time() + wait
    while True:
        current = read_doc(LOCK_DOC)
        stamp = int(current.get('ts') or 0)
        if not current or time.time() - stamp > LOCK_TTL:
            if write_doc(LOCK_DOC, {'owner': owner, 'ts': int(time.time())}):
                back = read_doc(LOCK_DOC)
                if back.get('owner') == owner:
                    return True
        if time.time() >= deadline:
            return False
        # Ждали через xbmc.sleep, а ждать здесь можно до wait=6 секунд - больше,
        # чем те 5, что Kodi даёт скрипту на остановку. Замок не взят - и не
        # надо: при остановке синхронизация всё равно не нужна.
        if pause(0.4):
            return False
    return False


def release_lock(owner):
    if not writable():
        return
    current = read_doc(LOCK_DOC)
    if current.get('owner') == owner:
        try:
            xbmcvfs.delete(_join(LOCK_DOC))
        except Exception:
            pass


def merge_history(local_rows, remote_doc):
    """Newer wins per path. Returns (merged, rows_to_apply_here)."""
    merged = dict(remote_doc.get('rows') or {})
    incoming = []
    for row in local_rows:
        path = str(row.get('path') or '')
        if not path:
            continue
        existing = merged.get(path) or {}
        if int(row.get('last_watched') or 0) >= int(existing.get('last_watched') or 0):
            merged[path] = {
                'path': path,
                'item_key': row.get('item_key') or '',
                'label': row.get('label') or '',
                'year': str(row.get('year') or ''),
                'mediatype': row.get('mediatype') or '',
                'playcount': int(row.get('playcount') or 0),
                'position': float(row.get('position') or 0),
                'total': float(row.get('total') or 0),
                'last_watched': int(row.get('last_watched') or 0),
            }
    local_by_path = dict((str(r.get('path') or ''), r) for r in local_rows)
    for path, row in merged.items():
        mine = local_by_path.get(path)
        if mine is None or int(row.get('last_watched') or 0) > int(mine.get('last_watched') or 0):
            incoming.append(row)
    return {'rows': merged, 'updated_ts': int(time.time())}, incoming


def merge_feedback(local_rows, remote_doc):
    merged = dict(remote_doc.get('rows') or {})
    incoming = []
    for row in local_rows:
        key = str(row.get('item_key') or '')
        if not key:
            continue
        existing = merged.get(key) or {}
        if int(row.get('updated_ts') or 0) >= int(existing.get('updated_ts') or 0):
            merged[key] = dict(row)
    local_by_key = dict((str(r.get('item_key') or ''), r) for r in local_rows)
    for key, row in merged.items():
        mine = local_by_key.get(key)
        if mine is None or int(row.get('updated_ts') or 0) > int(mine.get('updated_ts') or 0):
            incoming.append(row)
    return {'rows': merged, 'updated_ts': int(time.time())}, incoming


def read_list(category):
    doc = read_doc(LISTS_DOC)
    entry = (doc.get(category) or {}) if isinstance(doc, dict) else {}
    return entry or None


def write_list(category, items, signature, built_by):
    doc = read_doc(LISTS_DOC)
    if not isinstance(doc, dict):
        doc = {}
    doc[category] = {'items': items, 'signature': signature,
                     'built_by': built_by, 'updated_ts': int(time.time())}
    return write_doc(LISTS_DOC, doc)


def read_settings():
    doc = read_doc(SETTINGS_DOC)
    return doc if isinstance(doc, dict) else {}


def write_settings(values, updated_by, updated_ts):
    """Набор целиком; более старая правка не перекрывает более новую."""
    doc = read_settings()
    if int(doc.get('updated_ts') or 0) > int(updated_ts or 0):
        return doc
    doc = {'values': values, 'updated_by': updated_by, 'updated_ts': int(updated_ts or 0)}
    write_doc(SETTINGS_DOC, doc)
    return doc


def describe():
    """One line for the log and for a settings screen to show."""
    path = base_path()
    if not path:
        return 'локально (общая папка не задана)'
    return '%s (%s)' % (path, 'чтение и запись' if writable() else 'только чтение')


def timeout():
    return max(5, get_int('sync_timeout', 30))
