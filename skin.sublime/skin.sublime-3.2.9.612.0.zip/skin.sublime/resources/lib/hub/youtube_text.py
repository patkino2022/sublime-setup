# -*- coding: utf-8 -*-
"""Названия и описания роликов YouTube без эмодзи.

В шрифтах скина нет глифов эмодзи, и Kodi рисует на их месте пустые квадраты
(проверка хаба YouTube на чистой установке 15.11.2026: квадраты и в названиях
плиток, и в описании инфопанели). Чистим на выдаче строк, которые строит сам
скин (routes._publish_stored_rows и витрины): так лечатся и старые снимки, и
снимки полос самого дополнения, если они идут через наши маршруты. Строки,
которые Kodi получает прямо от plugin.video.youtube (виджет с адресом
plugin://plugin.video.youtube/...), скин изменить не может.

Убираем всё вне базовой плоскости Юникода (там все цветные эмодзи) и
знакомые блоки символов из неё: разные символы и дингбаты, технические
значки (⌚ ⏰ ⏩), стрелки и звёзды (⭐ ⬆), селекторы вариантов, соединитель
ZWJ и знак клавиши. Кириллица, латиница, пунктуация, ©, ®, ™ и «•» остаются.
"""
from __future__ import absolute_import, unicode_literals

import re

_PICTO = re.compile(
    '[\U00010000-\U0010FFFF'
    '⌀-⏿'       # технические значки: ⌚ ⏰ ⏩ ⏺
    '☀-➿'       # разные символы и дингбаты: ☀ ✅ ❤ ➡
    '⬀-⯿'       # стрелки и звёзды: ⬆ ⭐ ⭕
    '︀-️'       # селекторы вариантов (эмодзи/текст)
    '‍'              # соединитель ZWJ внутри составных эмодзи
    '⃣'              # знак клавиши у 1️⃣
    '〰〽㊗㊙'
    ']')
_SPACES = re.compile(r'[ \t ]{2,}')
_BLANKS = re.compile(r'\n{3,}')


def clean(text, multiline=False):
    """Текст без эмодзи и лишних пробелов. multiline - сохранить переводы строк."""
    if not text or not isinstance(text, str):
        return text
    stripped = _PICTO.sub('', text)
    if stripped == text and '  ' not in text:
        return text
    if not multiline:
        return _SPACES.sub(' ', stripped.replace('\n', ' ')).strip()
    lines = [_SPACES.sub(' ', line).strip() for line in stripped.replace('\r', '').split('\n')]
    return _BLANKS.sub('\n\n', '\n'.join(lines)).strip()


def is_youtube(row):
    return 'plugin.video.youtube' in str((row or {}).get('file') or '')


def clean_row(row):
    """Копия строки YouTube с чистыми label/title/plot; прочие строки как есть."""
    if not is_youtube(row):
        return row
    fixed = None
    for key, multiline in (('label', False), ('title', False), ('plot', True)):
        value = row.get(key)
        if isinstance(value, str) and value:
            new = clean(value, multiline)
            if new != value:
                if fixed is None:
                    fixed = dict(row)
                fixed[key] = new
    return fixed if fixed is not None else row
