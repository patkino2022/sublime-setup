# -*- coding: utf-8 -*-
"""Small local store for the hub: built lists, cursors, explicit feedback.

Deliberately NOT the watched history. That now lives where the player already
keeps it - Kodi's own video database - and is reached through history.py. What
stays here is what Kodi has no place for: the lists this box has built, the sync
cursors, and the owner's "recommend / do not recommend such" answers.
"""
from __future__ import absolute_import, unicode_literals

import os
import sqlite3
import threading
import time

import xbmc
import xbmcvfs

from .config import log

DB_URI = 'special://profile/addon_data/skin.sublime/hub_state.db'
_LOCAL = threading.local()


def _path():
    path = xbmcvfs.translatePath(DB_URI)
    folder = os.path.dirname(path)
    if folder and not os.path.isdir(folder):
        try:
            os.makedirs(folder)
        except Exception:
            pass
    return path


class Store(object):
    """One connection per thread: Kodi calls this from the service, the plugin
    and the player monitor, and sqlite objects are not shared across threads."""

    def __init__(self):
        self._conn = sqlite3.connect(_path(), timeout=15)
        self._conn.execute('PRAGMA journal_mode=WAL')
        self._conn.execute('PRAGMA synchronous=NORMAL')
        self._create()

    def _create(self):
        self._conn.execute(
            'CREATE TABLE IF NOT EXISTS flags ('
            'flag_key TEXT PRIMARY KEY, flag_value TEXT, updated_ts INTEGER)')
        self._conn.execute(
            'CREATE TABLE IF NOT EXISTS feedback ('
            'item_key TEXT PRIMARY KEY, kind TEXT, label TEXT, genres TEXT,'
            ' countries TEXT, year TEXT, mediatype TEXT, updated_ts INTEGER)')
        self._conn.execute(
            'CREATE INDEX IF NOT EXISTS feedback_ts ON feedback (updated_ts)')
        self._conn.commit()

    # ---- flags ---------------------------------------------------------

    def get_flag(self, key):
        row = self._conn.execute(
            'SELECT flag_value FROM flags WHERE flag_key = ?', (key,)).fetchone()
        return row[0] if row else ''

    def set_flag(self, key, value):
        self._conn.execute(
            'INSERT OR REPLACE INTO flags (flag_key, flag_value, updated_ts)'
            ' VALUES (?,?,?)', (key, str(value), int(time.time())))
        self._conn.commit()


    # ---- feedback ------------------------------------------------------

    def set_feedback(self, item_key, kind, label='', genres='', countries='',
                     year='', mediatype=''):
        """"Recommend such" / "do not recommend such", as an explicit fact.

        Kept apart from watched state: disliking something is not the same as
        having seen it, and folding the two together makes a dislike silently
        claim you watched the thing.
        """
        if not item_key or kind not in ('like', 'dislike'):
            return
        self._conn.execute(
            'INSERT OR REPLACE INTO feedback (item_key, kind, label, genres,'
            ' countries, year, mediatype, updated_ts) VALUES (?,?,?,?,?,?,?,?)',
            (item_key, kind, label or '', genres or '', countries or '',
             str(year or ''), mediatype or '', int(time.time())))
        self._conn.commit()


    def feedback_keys(self, kind):
        return set(r[0] for r in self._conn.execute(
            'SELECT item_key FROM feedback WHERE kind = ?', (kind,)))

    def feedback_rows(self, kind='', limit=0):
        cols = ('item_key', 'kind', 'label', 'genres', 'countries', 'year',
                'mediatype', 'updated_ts')
        sql = ('SELECT item_key, kind, label, genres, countries, year,'
               ' mediatype, updated_ts FROM feedback')
        args = []
        if kind:
            sql += ' WHERE kind = ?'
            args.append(kind)
        sql += ' ORDER BY updated_ts DESC'
        if limit:
            sql += ' LIMIT ?'
            args.append(int(limit))
        return [dict(zip(cols, row)) for row in self._conn.execute(sql, args)]

    def feedback_changed_since(self, since_ts, since_key='', limit=2000):
        """Keyset pagination on (timestamp, item_key), not timestamp alone: a
        plain `>` cursor drops every row sharing the newest second."""
        cols = ('item_key', 'kind', 'label', 'genres', 'countries', 'year',
                'mediatype', 'updated_ts')
        return [dict(zip(cols, row)) for row in self._conn.execute(
            'SELECT item_key, kind, label, genres, countries, year, mediatype,'
            ' updated_ts FROM feedback WHERE updated_ts > ?'
            ' OR (updated_ts = ? AND item_key > ?)'
            ' ORDER BY updated_ts ASC, item_key ASC LIMIT ?',
            (int(since_ts or 0), int(since_ts or 0), str(since_key or ''),
             int(limit)))]

    def merge_feedback(self, row):
        item_key = str(row.get('item_key') or '')
        if not item_key:
            return False
        incoming = int(row.get('updated_ts') or 0)
        existing = self._conn.execute(
            'SELECT updated_ts FROM feedback WHERE item_key = ?',
            (item_key,)).fetchone()
        if existing and int(existing[0] or 0) >= incoming:
            return False
        self._conn.execute(
            'INSERT OR REPLACE INTO feedback (item_key, kind, label, genres,'
            ' countries, year, mediatype, updated_ts) VALUES (?,?,?,?,?,?,?,?)',
            (item_key, row.get('kind') or 'dislike', row.get('label') or '',
             row.get('genres') or '', row.get('countries') or '',
             str(row.get('year') or ''), row.get('mediatype') or '',
             incoming or int(time.time())))
        self._conn.commit()
        return True

    def close(self):
        try:
            self._conn.close()
        except Exception:
            pass


def db():
    store = getattr(_LOCAL, 'store', None)
    if store is None:
        try:
            store = Store()
        except Exception as exc:
            log('локальное состояние не открылось: %s' % exc, xbmc.LOGERROR)
            raise
        _LOCAL.store = store
    return store
