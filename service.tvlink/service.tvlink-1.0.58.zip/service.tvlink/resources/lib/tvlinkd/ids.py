"""Channel identity: the same 8-hex id TVLINK used, so pvr.tvlink keeps its channels.

TVLINK id = CRC32 of the title after dropping the configured suffixes
(" orig"), "FHD" read as "HD", keeping letters, digits and + ! ' _ : only,
upper-cased. Checked on all 2527 links of both playlists on .20 (19.10.2026):
"Первый канал HD orig" is CEDC5D3C like "Первый канал HD", "Fashion & Lifestyle HD"
is 6D02A3AF, "НТВ +2" keeps its plus.
"""
import re
import zlib

_FHD = re.compile(r"\bFHD\b")
_KEEP = set("+!'_:")

NO_LOGO = "0000"  # the skin hides art that ends in /logo/0000.png


def clean_title(title, suffixes=()):
    t = " ".join((title or "").split())
    low = t.lower()
    for s in suffixes:
        s = s.strip().lower()
        if s and low.endswith(" " + s):
            t = t[: -len(s) - 1].rstrip()
            low = t.lower()
    return t


def chid(title, suffixes=()):
    t = _FHD.sub("HD", clean_title(title, suffixes))
    t = "".join(ch for ch in t if ch.isalnum() or ch in _KEEP).upper()
    return "%08X" % (zlib.crc32(t.encode("utf-8")) & 0xFFFFFFFF)
