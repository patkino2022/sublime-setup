# -*- coding: utf-8 -*-
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

from __future__ import unicode_literals

import json
import os
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from future.utils import PY3, PY26

if PY3:
    import http.cookiejar as cookielib
else:
    import cookielib

from simpleplugin import Addon

__all__ = ['WebClient', 'WebClientError']


class WebClientError(Exception):

    def __init__(self, error):
        self.message = error
        super(WebClientError, self).__init__(self.message)


# requests (с urllib3, ssl и прочим) грузится 0.34 с из 0.45 с загрузки
# дополнения - замер на .30 17.10.2026. Каждый экран Kodi запускает дополнение
# заново, а при открытии из кеша сеть не нужна вовсе, поэтому библиотека и
# сам класс появляются только при первом обращении к WebClient.
_WEBCLIENT_CLASS = []


def _webclient_class():
    if _WEBCLIENT_CLASS:
        return _WEBCLIENT_CLASS[0]
    import requests

    class WebClient(requests.Session):
        _secret_data = [
            'password', 'token', 'access_token', 'refresh_token', 'api_key',
            'user_dev_token', 'user_dev_id', 'authorization', 'cookie'
        ]

        @classmethod
        def _redact_url(cls, value):
            try:
                parts = urlsplit(str(value))
                query = []
                for key, item in parse_qsl(parts.query, keep_blank_values=True):
                    query.append((key, '<SECRET>' if key.lower() in cls._secret_data else item))
                return urlunsplit((parts.scheme, parts.netloc, parts.path,
                                   urlencode(query), parts.fragment))
            except Exception:
                return str(value)

        @classmethod
        def _redact_headers(cls, headers):
            try:
                result = {}
                for key, value in dict(headers or {}).items():
                    if str(key).lower() in cls._secret_data or str(key).lower() in ('set-cookie',):
                        result[key] = '<SECRET>'
                    else:
                        result[key] = value
                return result
            except Exception:
                return '<REDACTED>'

        @classmethod
        def _redact_payload_text(cls, value):
            def scrub(item):
                if isinstance(item, dict):
                    return {key: ('<SECRET>' if str(key).lower() in cls._secret_data else scrub(val))
                            for key, val in item.items()}
                if isinstance(item, list):
                    return [scrub(val) for val in item]
                return item

            text = str(value or '')
            try:
                return json.dumps(scrub(json.loads(text)), ensure_ascii=False)
            except Exception:
                for field in cls._secret_data:
                    # Cover common JSON and form/query representations in debug
                    # payloads without modifying the actual HTTP response.
                    import re
                    text = re.sub(r'(["\']?{0}["\']?\s*[:=]\s*)[^,&\s}}]+'.format(re.escape(field)),
                                  r'\1<SECRET>', text, flags=re.IGNORECASE)
                return text

        def __init__(self, headers=None, cookie_file=None):
            super(WebClient, self).__init__()

            if cookie_file is not None:
                self.cookies = cookielib.LWPCookieJar(cookie_file)
                if os.path.exists(cookie_file):
                    self.cookies.load(ignore_discard=True, ignore_expires=True)

            if headers is not None:
                self.headers.update(headers)

            self._addon = Addon()

        def __save_cookies(self):
            if isinstance(self.cookies, cookielib.LWPCookieJar) \
                    and self.cookies.filename:
                self.cookies.save(ignore_expires=True, ignore_discard=True)

        def post(self, url, **kwargs):

            func = super(WebClient, self).post
            return self._run(func, url, **kwargs)

        def get(self, url, **kwargs):

            func = super(WebClient, self).get
            return self._run(func, url, **kwargs)

        def put(self, url, **kwargs):

            func = super(WebClient, self).put
            return self._run(func, url, **kwargs)

        def delete(self, url, **kwargs):

            func = super(WebClient, self).delete
            return self._run(func, url, **kwargs)

        def head(self, url, **kwargs):

            func = super(WebClient, self).head
            return self._run(func, url, **kwargs)

        def _run(self, func, url, **kwargs):

            try:
                r = func(url, **kwargs)
                r.raise_for_status()
            except requests.RequestException as e:
                self._log_error(e)
                raise WebClientError(e)
            else:
                self._log_debug(r)
                if r.headers.get('set-cookie') is not None:
                    self.__save_cookies()
                return r

        def _log_debug(self, response):
            debug_info = []

            request = getattr(response, 'request', None)

            if request is not None:
                request_info = self._get_request_info(request)
                if request_info:
                    debug_info.append(request_info)

            if response is not None:
                response_info = self._get_response_info(response)
                if response_info:
                    debug_info.append(response_info)

            self._addon.log_debug('\n'.join(debug_info))

        def _log_error(self, error):
            error_info = [str(error)]

            response = getattr(error, 'response', None)
            request = getattr(error, 'request', None)

            if request is not None:
                request_info = self._get_request_info(request)
                if request_info:
                    error_info.append(request_info)

            if response is not None:
                response_info = self._get_response_info(response)
                if response_info:
                    error_info.append(response_info)

            self._addon.log_error('\n'.join(error_info))

        @staticmethod
        def _get_response_info(response):
            response_info = ['Response info', 'Status code: {0}'.format(response.status_code),
                             'Reason: {0}'.format(response.reason)]
            if not PY26:
                response_info.append('Elapsed: {0:.4f} sec'.format(response.elapsed.total_seconds()))
            if response.url:
                response_info.append('URL: {0}'.format(WebClient._redact_url(response.url)))
            if response.headers:
                response_info.append('Headers: {0}'.format(WebClient._redact_headers(response.headers)))

            if response.text \
                    and response.encoding:
                content = WebClient._redact_payload_text(response.text)
                if len(content) > 2000:
                    content = content[:2000] + '...<TRUNCATED>'
                response_info.append('Content: {0}'.format(content))

            return '\n'.join(response_info)

        @classmethod
        def _get_request_info(cls, request):
            request_info = ['Request info', 'Method: {0}'.format(request.method)]

            if request.url:
                request_info.append('URL: {0}'.format(cls._redact_url(request.url)))
            if request.headers:
                request_info.append('Headers: {0}'.format(cls._redact_headers(request.headers)))
            if request.body:
                raw_body = request.body
                if isinstance(raw_body, bytes):
                    try:
                        raw_body = raw_body.decode('utf-8', 'replace')
                    except Exception:
                        raw_body = str(raw_body)
                try:
                    j = json.loads(raw_body)
                    for field in cls._secret_data:
                        if j.get(field) is not None:
                            j[field] = '<SECRET>'
                    data = json.dumps(j)
                except Exception:
                    data = str(raw_body)
                    for param in data.split('&'):
                        if '=' in param:
                            field, value = param.split('=', 1)
                            if field.lower() in cls._secret_data:
                                data = data.replace(param, '{0}=<SECRET>'.format(field))
                request_info.append('Data: {0}'.format(data))

            return '\n'.join(request_info)

    _WEBCLIENT_CLASS.append(WebClient)
    return WebClient


def __getattr__(name):
    if name == 'WebClient':
        return _webclient_class()
    raise AttributeError(name)
