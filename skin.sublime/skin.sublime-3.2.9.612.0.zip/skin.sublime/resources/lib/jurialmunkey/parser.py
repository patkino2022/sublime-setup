def boolean(string):
    if not isinstance(string, str):
        return bool(string)
    if string.lower() in ('false', '0', ''):
        return False
    return True


def try_int(string, base=None, fallback=0):
    '''helper to parse int from string without erroring on empty or misformed string'''
    try:
        return int(string, base) if base else int(string)
    except Exception:
        return fallback


def try_float(string):
    '''helper to parse float from string without erroring on empty or misformed string'''
    try:
        return float(string or 0)
    except Exception:
        return 0


def try_str(value):
    '''helper to stringify value'''
    try:
        return f'{value}'
    except Exception:
        return ''


def try_type(value, output=None):
    if output == int:
        return try_int(value)
    if output == str:
        return try_str(value)
    if output == float:
        return try_float(value)


def parse_paramstring(paramstring):
    """ helper to assist to standardise urllib parsing """
    from urllib.parse import unquote_plus
    # from unicodedata import normalize
    params = dict()
    paramstring = paramstring.replace('&amp;', '&')  # Just in case xml string
    for param in paramstring.split('&'):
        if '=' not in param:
            continue
        k, v = param.split('=')
        k = unquote_plus(k)
        v = unquote_plus(v)
        v = v.strip('\'').strip('"')  # Strip out quote marks from Kodi string
        # v = normalize('NFKD', v)  # Normalize and decompose combined utf-8 forms such as Arabic (Unsure if needed anymore for edit control)
        params[k] = v
    return params


def merge_two_dicts(x, y, reverse=False, deep=False):
    xx = y or {} if reverse else x or {}
    yy = x or {} if reverse else y or {}
    z = xx.copy()  # start with x's keys and values
    if not deep:   # modifies z with y's keys and values
        z.update(yy)
        return z
    for k, v in yy.items():
        if isinstance(v, dict):
            merge_two_dicts(z.setdefault(k, {}), v, reverse=reverse, deep=True)
        elif v:
            z[k] = v
    return z


def merge_dicts(org, upd, skipempty=False):
    source = org.copy()
    for k, v in upd.items():
        if not k:
            continue
        if skipempty and not v:
            continue
        if isinstance(v, dict):
            if not isinstance(source.get(k), dict):
                source[k] = {}
            source[k] = merge_dicts(source.get(k), v, skipempty=skipempty)
            continue
        source[k] = v
    return source


def del_empty_keys(d, values: list = None):
    values = values or []
    values += [None, '']
    return {k: v for k, v in d.items() if v not in values}


def get_params(item, tmdb_type, tmdb_id=None, params=None, definition=None, base_tmdb_type=None, iso_country=None):
    params = params or {}
    tmdb_id = tmdb_id or item.get('id')
    if params == -1:
        return {}
    definition = definition or {'info': 'details', 'tmdb_type': '{tmdb_type}', 'tmdb_id': '{tmdb_id}'}
    for k, v in definition.items():
        params[k] = v.format(tmdb_type=tmdb_type, tmdb_id=tmdb_id, base_tmdb_type=base_tmdb_type, iso_country=iso_country, **item)
    return del_empty_keys(params)


def split_items(items, separator='/'):
    if items and isinstance(items, str):
        return items.split(f' {separator} ')
    if not isinstance(items, list):
        return [items]
    return items


def math_operators():
    import operator
    _add, _sub, _mul = operator.add, operator.sub, operator.mul
    _truediv, _pow = operator.truediv, operator.pow
    return {
        "+": (2, _add),
        "-": (2, _sub),
        "*": (2, _mul),
        "/": (2, _truediv),
        "**": (2, _pow),
    }


def evaluate_math_expression(expression):
    if isinstance(expression, str):
        expression = expression.split()

    stack = []
    skipnext = False
    operators = math_operators()
    for x, val in enumerate(expression):
        if skipnext:
            skipnext = False
            continue
        if val in operators:
            n, op = operators[val]
            stack.append(float(expression[x + 1]))  # Readahead
            skipnext = True
            if n > len(stack):
                stack.append(0)
                # raise ValueError(F"Not enough data to evaluate $MATH[] expression\nstack: {stack} expr: {expression}")
            args = stack[-n:]
            stack[-n:] = [op(*args)]
            continue
        stack.append(float(val))
    return stack[-1]


def parse_math(string, fstring='{:.0f}'):
    import re
    MATH_REGEX = r'\$MATH\[(.*?)\]'
    match = re.search(MATH_REGEX, string)
    if not match:
        return string
    values = match.group(1)
    string = string.replace(match.group(0), fstring.format(evaluate_math_expression(values)))
    return parse_math(string)


def parse_localize(string):
    import re
    import xbmc
    LOCALIZE_REGEX = r'\$LOCALIZE\[(.*?)\]'
    match = re.search(LOCALIZE_REGEX, string)
    if not match:
        return string
    try:
        localized_id = int(match.group(1))
    except (TypeError, ValueError):
        string = string.replace(match.group(0), '')
    else:
        string = string.replace(match.group(0), xbmc.getLocalizedString(localized_id))
    return parse_localize(string)


