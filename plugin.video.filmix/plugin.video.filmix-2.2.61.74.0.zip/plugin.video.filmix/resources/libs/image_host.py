# -*- coding: utf-8 -*-
"""Не отдавать Kodi адрес картинки, которым нечего нарисовать.

ЗАЧЕМ

08.09.2026 у Filmix лёг собственный склад картинок: `thumbs.filmixapp.vip`
не отвечал ни по HEAD, ни по GET - с обеих коробок владельца и из чужой сети, -
а API продолжал выдавать ровно этот адрес для всех постеров. Kodi судит по
строке, а не по картинке: ссылка непустая, значит годная, - и плитка вставала
пустой рамкой вместо названия. Снимок владельца: полоса из восьми плиток, на
которой нарисовалась одна.

Скин своё уже починил (skin.sublime, hub/host_health.py): в СВОИХ полосах он
подменяет мёртвый адрес постером с TMDb, а если своего нет - снимает адрес, и
плитка рисует название. Но «Избранное», «Смотреть позже», «Жанры» и «Страны» -
это наши собственные листинги, их строки собирает плагин, и до них правка скина
не доходит.

КАК

Решение «этот хост сейчас не отвечает» принимает скин - он и щупает хосты,
по три настоящих адреса, и записывает вердикт в свой
`addon_data/skin.sublime/host_health.json`. Здесь этот вердикт только читается:
второй пробы, второго списка замен и второго мнения о том, жив ли хост, нет.
Файла нет (другой скин, свежая установка) - значит мнения нет, и адреса
отдаются как были: плагин обязан работать с любым скином.

Зачем снимать, а не оставить как было: загрузчик текстур у Kodi ОДИН. По
кадрам записи владельца 08.09.2026 видно, как на строке с мёртвым адресом
гаснут ВСЕ плитки полосы и фон замирает на прошлой строке, - в журнале в эти же
секунды Kodi по кругу ждёт по десять секунд на каждой попытке достучаться до
лёгшего склада. Один мёртвый адрес останавливает отрисовку всего экрана.

Снятие живёт только на время отрисовки: ни кэш плагина, ни ответ API не
правятся, поэтому ответит их склад - картинки вернутся сами.
"""
from __future__ import absolute_import, unicode_literals

import json
import os
import time

import xbmc
import xbmcvfs

VERDICT = 'special://profile/addon_data/skin.sublime/host_health.json'
# Столько живёт отметка «не отвечает». Тот же срок, что у скина: он щупает хосты
# не чаще раза в 3 часа (владелец 19.11.2026), отметка живёт до следующей проверки.
DOWN_FOR = 3 * 3600.0

_STATE = {'stamp': -1.0, 'hosts': {}}
_DRAWS = {}


def _verdict():
    """Хосты, которые скин считает недоступными. Читается по времени файла."""
    try:
        path = xbmcvfs.translatePath(VERDICT)
    except Exception:
        return {}
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        _STATE['stamp'], _STATE['hosts'] = -1.0, {}
        return {}
    if stamp == _STATE['stamp']:
        return _STATE['hosts']
    hosts = {}
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            loaded = json.load(handle)
        if isinstance(loaded, dict):
            now = time.time()
            for host, record in loaded.items():
                if not isinstance(record, dict) or not record.get('down'):
                    continue
                if (now - float(record.get('at') or 0)) < DOWN_FOR:
                    hosts[str(host).lower()] = True
    except Exception:
        hosts = {}
    _STATE['stamp'], _STATE['hosts'] = stamp, hosts
    return hosts


def _plain(url):
    """Адрес без обёртки `image://`."""
    text = str(url or '')
    if text.startswith('image://'):
        try:
            from urllib.parse import unquote
        except ImportError:
            return ''
        try:
            text = unquote(text[8:]).rstrip('/')
        except Exception:
            return ''
    return text


def _host_of(url):
    text = _plain(url)
    if not text.startswith('http://') and not text.startswith('https://'):
        return ''
    host = text.split('://', 1)[1].split('/', 1)[0].lower()
    return host if '.' in host and '%' not in host else ''


def usable(url):
    """Стоит ли отдавать этот адрес Kodi.

    Решение принимает ТОЛЬКО вердикт скина, обновляемый раз в пять минут.
    Проверку «лежит ли картинка в кэше Kodi» я сюда добавлял 08.09.2026 и убрал:
    ответ менялся на каждой отрисовке, пока кэш наполнялся, и владелец увидел
    «постеры загружаются, потом пропадают, потом опять появляются».
    """
    host = _host_of(url)
    return not host or host not in _verdict()


def keep_drawable(art):
    """Из готовых картинок строки убрать те, которыми нечего нарисовать."""
    if not art:
        return art
    kept = {}
    dropped = []
    for key, value in art.items():
        if usable(value):
            kept[key] = value
        else:
            dropped.append(key)
    if dropped:
        xbmc.log('[plugin.video.filmix] сняты картинки без источника (%s): '
                 'склад поставщика молчит, в кэше Kodi их нет'
                 % ', '.join(sorted(dropped)), xbmc.LOGDEBUG)
    return kept
