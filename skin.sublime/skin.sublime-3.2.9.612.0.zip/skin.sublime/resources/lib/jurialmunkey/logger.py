import xbmc
from timeit import default_timer as timer


class Logger():
    def __init__(
            self,
            log_name: str = '',
            notification_head: str = '',
            notification_text: str = '',
            debug_logging: bool = False):
        self._addon_logname = log_name
        self._debug_logging = debug_logging
        self._notification_head = notification_head
        self._notification_text = notification_text

    def kodi_log(self, value, level=0):
        try:
            if isinstance(value, list):
                value = ''.join(map(str, value))
            if isinstance(value, bytes):
                value = value.decode('utf-8')
            logvalue = f'{self._addon_logname}{value}'
            if level == 3 and self._debug_logging:
                import traceback
                xbmc.log(f'{logvalue}\n{traceback.print_stack()}', level=xbmc.LOGINFO)
            elif level == 2 and self._debug_logging:
                xbmc.log(logvalue, level=xbmc.LOGINFO)
            elif level == 1:
                xbmc.log(logvalue, level=xbmc.LOGINFO)
            else:
                xbmc.log(logvalue, level=xbmc.LOGDEBUG)
        except Exception as exc:
            xbmc.log(f'Logging Error: {exc}', level=xbmc.LOGINFO)


class TimerFunc():
    kodi_log = None

    def __init__(self, timer_name, log_threshold=0.05, inline=False, kodi_log=None):
        """ ContextManager for timing code blocks and outputing to log """
        self.inline = ' ' if inline else '\n'
        self.timer_name = timer_name
        self.log_threshold = log_threshold
        self.kodi_log = self.kodi_log or kodi_log or Logger().kodi_log
        self.timer_a = timer()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        timer_z = timer()
        total_time = timer_z - self.timer_a
        if total_time <= self.log_threshold:
            return
        self.kodi_log(f'{self.timer_name}{self.inline}{total_time:.3f} sec', 1)
